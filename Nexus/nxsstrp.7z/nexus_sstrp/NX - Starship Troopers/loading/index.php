<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>
	<?php if($_GET){ ?><script type="text/javascript">var Server = "<?php echo $_GET['server']; ?>";</script><?php } ?>
	<script type="text/javascript" src="main.js"></script>
	<link rel="stylesheet" type="text/css" href="reset.css"/>
	<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	<div id="background"></div>
	<div id="container">
		<div id="logo"></div>
	</div>
	<div id="files"><img src="loading.gif" alt=""/></div>
	<div id="footer">
		<div id="contentpack"></div>
		<div id="loadingtext">Welcome to Duty...</div>
	</div>
	<div id="youtube"></div>
	<!-- Made by Teegee !-->
<body>
<html>