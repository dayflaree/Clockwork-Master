Place everything inside modules into Garrysmod/garrysmod/lua/includes/modules

Put data, gamemodes and lua into : garrysmod/garrysmod/

Set up the SQL and add the sql file to the database.

Add the sql details to the gmod/gmod/data/nexus/mysql.cfg

SORTED, ENJOY