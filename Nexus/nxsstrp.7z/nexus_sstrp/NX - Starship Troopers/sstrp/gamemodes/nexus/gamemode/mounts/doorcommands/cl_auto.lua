--[[
Name: "cl_auto.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

nexus.config.SetOverwatch("default_doors_hidden", "Set whether doors are hidden and unownable by default.");