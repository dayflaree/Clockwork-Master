--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Banned Props";
MOUNT.author = "kuropixel";
MOUNT.description = "A basic mount which allows props to be banned.";