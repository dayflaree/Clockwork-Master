--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Observer Mode";
MOUNT.author = "kuropixel";
MOUNT.description = "Staff can enter observer mode, similiar to noclipping but they\nare teleported back to where they entered it.";