--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Surface Texts";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows three dimensional text to be placed on a surface.";