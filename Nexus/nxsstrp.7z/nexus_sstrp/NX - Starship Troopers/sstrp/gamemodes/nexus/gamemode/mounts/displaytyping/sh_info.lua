--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Display Typing";
MOUNT.author = "kuropixel";
MOUNT.description = "This mount will display whether a character is typing above their head.";