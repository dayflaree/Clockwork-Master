--[[
Name: "sh_config.lua".
Product: "Nexus".
--]]


nexus.config.ShareKey("use_opens_entity_menus");
nexus.config.ShareKey("additional_characters");
nexus.config.ShareKey("raised_weapon_system");
nexus.config.ShareKey("default_inv_weight");
nexus.config.ShareKey("unrecognised_name");
nexus.config.ShareKey("enable_crosshair");
nexus.config.ShareKey("recognise_system");
nexus.config.ShareKey("cash_enabled");
nexus.config.ShareKey("default_physdesc");
nexus.config.ShareKey("cash_weight");
nexus.config.ShareKey("block_inv_binds");
nexus.config.ShareKey("fade_dead_npcs");
nexus.config.ShareKey("enable_headbob");
nexus.config.ShareKey("command_prefix");
nexus.config.ShareKey("default_flags");
nexus.config.ShareKey("minute_time");
nexus.config.ShareKey("local_voice");
nexus.config.ShareKey("talk_radius");
nexus.config.ShareKey("wages_name");
nexus.config.ShareKey("door_cost");