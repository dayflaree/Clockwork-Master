--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Map Scenes";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows snapshots of the map to be displayed to clients in the character menu.";