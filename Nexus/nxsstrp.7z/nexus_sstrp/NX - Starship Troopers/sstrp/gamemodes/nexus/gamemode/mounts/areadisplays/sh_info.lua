--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Area Displays";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows nice three dimensional text to be displayed as characters\nenter new areas.";