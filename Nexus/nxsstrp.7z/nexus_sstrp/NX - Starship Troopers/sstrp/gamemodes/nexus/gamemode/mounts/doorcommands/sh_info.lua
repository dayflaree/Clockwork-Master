--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Door Commands";
MOUNT.author = "kuropixel";
MOUNT.description = "Provides a bunch of useful commands for interacting with doors.";