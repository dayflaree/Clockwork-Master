--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

SCHEMA.name = "Base Schema";
SCHEMA.author = "kuropixel";
SCHEMA.description = "The base Nexus schema. It isn't very fun.";