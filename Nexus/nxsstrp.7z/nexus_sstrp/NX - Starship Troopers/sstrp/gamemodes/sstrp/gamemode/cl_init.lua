--[[
Name: "cl_init.lua".
Product: "Starship Troopers".
--]]

-- Store the current gamemode table here so that nexus can access it internally.
NEXUS = GM;

-- Derive the gamemode from nexus.
DeriveGamemode("nexus");