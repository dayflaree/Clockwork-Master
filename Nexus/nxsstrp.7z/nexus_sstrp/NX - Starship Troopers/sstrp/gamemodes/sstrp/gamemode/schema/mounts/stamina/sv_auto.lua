--[[
Name: "sv_auto.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");