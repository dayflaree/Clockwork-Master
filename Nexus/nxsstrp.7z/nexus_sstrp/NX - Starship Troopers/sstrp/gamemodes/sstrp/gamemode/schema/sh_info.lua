--[[
Name: "sh_info.lua".
Product: "Starship Troopers".
--]]

SCHEMA.name = "Starship Troopers";
SCHEMA.author = "Chewgum";
SCHEMA.description = "DO YOU WANT TO LIVE FOREVER.";