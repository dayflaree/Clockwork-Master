include('shared.lua')
SWEP.Category 			= "Starship Troopers RP"
SWEP.PrintName			= "AVCD 'ARCher' Mk. III"					// 'Nice' Weapon name (Shown on HUD)	
SWEP.Slot				= 3							// Slot in the weapon selection menu
SWEP.SlotPos			= 1							// Position in the slot

