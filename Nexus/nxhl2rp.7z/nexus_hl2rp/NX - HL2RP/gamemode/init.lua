--[[
Name: "init.lua".
Product: "Half-Life 2".
--]]

NEXUS = GM;

AddCSLuaFile("cl_init.lua");

DeriveGamemode("nexus");