--[[
Name: "sh_info.lua".
Product: "Half-Life 2".
--]]

MODULE.name = "Half-Life 2";
MODULE.author = "Kurozael";
MODULE.description = "Something";