--[[
Name: "cl_hooks.lua".
Product: "Half-Life 2".
--]]

local PLUGIN = PLUGIN;