--[[
Name: "sh_info.lua".
Product: "Half-Life 2".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Writing";
PLUGIN.author = "Dazzle Modifications";
PLUGIN.description = "Adds purchasable paper which players can write on.";