--[[
Name: "sh_auto.lua".
Product: "Kyron".
--]]

local PLUGIN = PLUGIN;

PLUGIN.paperIDs = {};
RESISTANCE:IncludePrefixed("cl_hooks.lua");
RESISTANCE:IncludePrefixed("sv_hooks.lua");