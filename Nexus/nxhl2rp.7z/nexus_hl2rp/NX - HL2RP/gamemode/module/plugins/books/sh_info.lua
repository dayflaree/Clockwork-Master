--[[
Name: "sh_info.lua".
Product: "Half-Life 2".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Books";
PLUGIN.author = "Dazzle Modifications";
PLUGIN.description = "Adds books to the module which players can read.";