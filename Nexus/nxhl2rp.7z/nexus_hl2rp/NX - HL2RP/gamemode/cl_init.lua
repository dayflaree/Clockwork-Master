--[[
Name: "cl_init.lua".
Product: "Half-Life 2".
--]]

NEXUS = GM;

DeriveGamemode("nexus");