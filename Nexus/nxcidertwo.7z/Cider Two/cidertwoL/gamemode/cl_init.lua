--[[
Name: "cl_init.lua".
Product: "Experiment".
--]]

NEXUS = GM;

DeriveGamemode("nexus");