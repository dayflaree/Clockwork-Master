--[[
Name: "init.lua".
Product: "Experiment".
--]]

NEXUS = GM;

AddCSLuaFile("cl_init.lua");

DeriveGamemode("nexus");