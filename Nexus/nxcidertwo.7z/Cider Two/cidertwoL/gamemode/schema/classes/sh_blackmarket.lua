--[[
Name: "sh_blackmarket.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 5;
CLASS.limit = 16;
CLASS.color = Color(150, 125, 100, 255);
CLASS.classes = {"Civilian"};
CLASS.description = "An underground blackmarket dealer.\nThey have low wages compared to legal classes.";
CLASS.defaultPhysDesc = "Wearing nice and clean clothes";

CLASS_BLACKMARKET = nexus.class.Register(CLASS, "Blackmarket");