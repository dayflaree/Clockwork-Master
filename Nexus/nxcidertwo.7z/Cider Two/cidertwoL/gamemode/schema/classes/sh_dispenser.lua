--[[
Name: "sh_dispenser.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.ammo = {pistol = 12};
CLASS.wages = 25;
CLASS.color = Color(150, 125, 100, 255);
CLASS.limit = 16;
CLASS.classes = {"Police"};
CLASS.weapons = {"weapon_glock"};
CLASS.description = "Supplies the police force with equipment.\nThey earn more than a civilian\nwith full contraband, without the risk\nof having it destroyed.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a nice, clean police uniform";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group09");
end;

CLASS_DISPENSER = nexus.class.Register(CLASS, "Dispenser");