--[[
Name: "sh_secretary.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 25;
CLASS.color = Color(150, 125, 100, 255);
CLASS.limit = 8;
CLASS.classes = {"Civilian"};
CLASS.description = "A secretary working for the president.\nThey earn more than a civilian\nwith full contraband, without the risk\nof having it destroyed.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a clean, black suit with no tie";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group10");
end;

CLASS_SECRETARY = nexus.class.Register(CLASS, "Secretary");