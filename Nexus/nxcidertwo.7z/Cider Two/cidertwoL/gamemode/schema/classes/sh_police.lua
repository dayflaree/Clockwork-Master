--[[
Name: "sh_police.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 25;
CLASS.ammo = {pistol = 12};
CLASS.color = Color(150, 125, 100, 255);
CLASS.limit = 32;
CLASS.weapons = {"weapon_glock"};
CLASS.classes = {"Civilian"};
CLASS.description = "A hard working police officer of the city.\nThey earn more than a civilian\nwith full contraband, without the risk\nof having it destroyed.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a nice, clean police uniform";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group09");
end;

CLASS_POLICE = nexus.class.Register(CLASS, "Police");