--[[
Name: "sh_heroin_lab.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "generator_base";
ITEM.name = "Heroin Lab";
ITEM.cost = 175;
ITEM.model = "models/props_lab/reciever01a.mdl";
ITEM.classes = {CLASS_HUSTLER};
ITEM.category = "Drug Labs";
ITEM.business = true;
ITEM.description = "Manufactures a temporary flow of heroin.";

ITEM.generator = {
	powerPlural = "Lifetime",
	powerName = "Lifetime",
	uniqueID = "nx_heroinlab",
	maximum = 2,
	health = 100,
	power = 5,
	cash = 35,
	name = "Heroin Lab",
};

nexus.item.Register(ITEM);