--[[
Name: "sh_heartbeat_sensor.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.name = "Heartbeat Sensor";
ITEM.cost = 80;
ITEM.model = "models/gibs/shield_scanner_gib1.mdl";
ITEM.weight = 1.5;
ITEM.classes = {CLASS_BLACKMARKET, CLASS_DISPENSER};
ITEM.category = "Reusables"
ITEM.business = true;
ITEM.description = "A state-of-the-art heartbeat sensor.";

-- Called when the item's local amount is needed.
function ITEM:GetLocalAmount(amount)
	if ( g_LocalPlayer:GetSharedVar("sh_Sensor") ) then
		return amount - 1;
	else
		return amount;
	end;
end;

-- Called to get whether a player has the item equipped.
function ITEM:HasPlayerEquipped(player, arguments)
	return player:GetSharedVar("sh_Sensor");
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, arguments)
	player:SetCharacterData("sensor", nil);
	player:SetSharedVar("sh_Sensor", false);
	
	player:UpdateInventory(self.uniqueID);
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if ( player:Alive() and !player:IsRagdolled() ) then
		player:SetCharacterData("sensor", true);
		player:SetSharedVar("sh_Sensor", true);
		
		player:UpdateInventory(self.uniqueID);
		
		if (itemEntity) then
			return true;
		end;
	else
		nexus.player.Notify(player, "You don't have permission to do this right now!");
	end;
	
	return false;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

nexus.item.Register(ITEM);