--[[
Name: "sh_police_uniform.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 120;
ITEM.name = "Police Uniform";
ITEM.group = "group09";
ITEM.weight = 0.5;
ITEM.classes = {CLASS_BLACKMARKET};
ITEM.business = true;
ITEM.description = "A stolen police uniform on the blackmarket.";

nexus.item.Register(ITEM);