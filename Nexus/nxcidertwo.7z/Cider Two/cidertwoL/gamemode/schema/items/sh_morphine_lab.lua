--[[
Name: "sh_morphine_lab.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "generator_base";
ITEM.name = "Morphine Lab";
ITEM.cost = 250;
ITEM.model = "models/props_lab/reciever01a.mdl";
ITEM.classes = {CLASS_HUSTLER};
ITEM.category = "Drug Labs";
ITEM.business = true;
ITEM.description = "Manufactures a temporary flow of morphine.";

ITEM.generator = {
	powerPlural = "Lifetime",
	powerName = "Lifetime",
	uniqueID = "nx_morphinelab",
	maximum = 2,
	health = 100,
	power = 5,
	cash = 50,
	name = "Morphine Lab",
};

nexus.item.Register(ITEM);