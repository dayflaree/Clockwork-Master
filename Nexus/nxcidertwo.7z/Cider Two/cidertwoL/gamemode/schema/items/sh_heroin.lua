--[[
Name: "sh_heroin.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "drug_base";
ITEM.name = "Heroin";
ITEM.model = "models/katharsmodels/syringe_out/heroine_out.mdl";
ITEM.attributes = {Dexterity = 75};
ITEM.description = "A needle to chase the dragon with, it's good for your dexterity.";

nexus.item.Register(ITEM);