--[[
Name: "sh_weed.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "drug_base";
ITEM.name = "Weed";
ITEM.model = "models/katharsmodels/contraband/zak_wiet/zak_wiet.mdl";
ITEM.attributes = {Medical = 75};
ITEM.description = "A bag of the green stuff, it helps with your medical skill.";

nexus.item.Register(ITEM);