--[[
Name: "sh_angeldust.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "drug_base";
ITEM.name = "Angel Dust";
ITEM.model = "models/katharsmodels/syringe_out/syringe_out.mdl";
ITEM.attributes = {Strength = 75};
ITEM.description = "A needle with a green liquid, it's good for your strength.";

nexus.item.Register(ITEM);