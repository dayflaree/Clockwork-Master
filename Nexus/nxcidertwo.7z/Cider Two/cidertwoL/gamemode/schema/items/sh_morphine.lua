--[[
Name: "sh_morphine.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "drug_base";
ITEM.name = "Morphine";
ITEM.model = "models/jaanus/morphi.mdl";
ITEM.attributes = {Endurance = 75};
ITEM.description = "Some bottled blue pills, they're good for your endurance.";

nexus.item.Register(ITEM);