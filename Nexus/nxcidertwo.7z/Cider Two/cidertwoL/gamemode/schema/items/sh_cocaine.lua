--[[
Name: "sh_cocaine.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "drug_base";
ITEM.name = "Cocaine";
ITEM.model = "models/cocn.mdl";
ITEM.attributes = {Agility = 75};
ITEM.description = "A wrapped up white powder, it's good for your agility.";

nexus.item.Register(ITEM);