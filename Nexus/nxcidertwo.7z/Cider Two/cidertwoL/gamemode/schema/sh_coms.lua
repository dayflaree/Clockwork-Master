--[[
Name: "sh_coms.lua".
Product: "Cider Two".
--]]

local COMMAND = {};

COMMAND = {};
COMMAND.tip = "Add a static prop at your target position.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if ( nexus.entity.IsPhysicsEntity(target) ) then
			for k, v in pairs(SCHEMA.staticProps) do
				if (target == v) then
					nexus.player.Notify(player, "This prop is already static!");
					
					return;
				end;
			end;
			
			SCHEMA.staticProps[#SCHEMA.staticProps + 1] = target;
			SCHEMA:SaveStaticProps();
			
			nexus.player.Notify(player, "You have added a static prop.");
		else
			nexus.player.Notify(player, "This entity is not a physics entity!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "StaticPropAdd");

COMMAND = {};
COMMAND.tip = "Remove static props at your target position.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if ( nexus.entity.IsPhysicsEntity(target) ) then
			for k, v in pairs(SCHEMA.staticProps) do
				if (target == v) then
					SCHEMA.staticProps[k] = nil;
					SCHEMA:SaveStaticProps();
					
					nexus.player.Notify(player, "You have removed a static prop.");
					
					return;
				end;
			end;
		else
			nexus.player.Notify(player, "This entity is not a physics entity!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "StaticPropRemove");

COMMAND = {};
COMMAND.tip = "Search a character if they are tied.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.entity.GetPlayer(player:GetEyeTraceNoCursor().Entity);
	
	if (target) then
		if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
			if (player:GetSharedVar("sh_Tied") == 0) then
				if (target:GetSharedVar("sh_Tied") != 0) then
					if (target:GetSharedVar("sh_Tied") == 2) then
						local team = player:Team();
						
						if (team != CLASS_POLICE and team != CLASS_DISPENSER
						and team != CLASS_SECRETARY and team != CLASS_PRESIDENT) then
							nexus.player.Notify(player, "You cannot search characters tied by a government class!");
							
							return;
						end;
					end;
					
					if (target:GetVelocity():Length() == 0) then
						if (!player.searching) then
							target.beingSearched = true;
							player.searching = target;
							
							nexus.player.OpenStorage( player, {
								name = nexus.player.FormatRecognisedText(player, "%s", target),
								weight = nexus.inventory.GetMaximumWeight(target),
								entity = target,
								distance = 192,
								cash = nexus.player.GetCash(target),
								inventory = nexus.player.GetInventory(target),
								OnClose = function(player, storageTable, entity)
									player.searching = nil;
									
									if ( IsValid(entity) ) then
										entity.beingSearched = nil;
									end;
								end,
								OnTake = function(player, storageTable, itemTable)
									local target = nexus.entity.GetPlayer(storageTable.entity);
									
									if (target) then
										if (target:GetCharacterData("clothes") == itemTable.index) then
											if ( !target:HasItem(itemTable.index) ) then
												target:SetCharacterData("clothes", nil);
												
												itemTable:OnChangeClothes(target, false);
											end;
										elseif ( target:GetSharedVar("sh_SkullMask") ) then
											if ( !target:HasItem(itemTable.index) ) then
												itemTable:OnPlayerUnequipped(target);
											end;
										end;
									end;
								end,
								OnGive = function(player, storageTable, itemTable)
									if (player:GetCharacterData("clothes") == itemTable.index) then
										if ( !player:HasItem(itemTable.index) ) then
											player:SetCharacterData("clothes", nil);
											
											itemTable:OnChangeClothes(player, false);
										end;
									elseif ( player:GetSharedVar("sh_SkullMask") ) then
										if ( !player:HasItem(itemTable.index) ) then
											itemTable:OnPlayerUnequipped(player);
										end;
									end;
								end,
								CanTake = function(target, storageTable, item)
									local itemTable = nexus.item.Get(item);
									local team = player:Team();
									
									if (team == CLASS_POLICE or team == CLASS_DISPENSER
									or team == CLASS_SECRETARY or team == CLASS_PRESIDENT) then
										if ( !itemTable.classes or !table.HasValue(itemTable.classes, CLASS_BLACKMARKET) ) then
											nexus.player.Notify(player, "You can only take illegal items as a government class!");
											
											return false;
										else
											return true;
										end;
									else
										return true;
									end;
								end,
								CanTakeCash = function(target, storageTable, cash)
									local team = player:Team();
									
									if (team == CLASS_POLICE or team == CLASS_DISPENSER
									or team == CLASS_SECRETARY or team == CLASS_PRESIDENT) then
										nexus.player.Notify(player, "You can only take illegal items as a government class!");
										
										return false;
									else
										return true;
									end;
								end
							} );
						else
							nexus.player.Notify(player, "You are already searching a character!");
						end;
					else
						nexus.player.Notify(player, "You cannot search a moving character!");
					end;
				else
					nexus.player.Notify(player, "This character is not tied!");
				end;
			else
				nexus.player.Notify(player, "You don't have permission to do this right now!");
			end;
		else
			nexus.player.Notify(player, "This character is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "CharSearch");

COMMAND = {};
COMMAND.tip = "Heal a character if you own a medical item.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:GetSharedVar("sh_Tied") == 0) then
		local itemTable = nexus.item.Get( arguments[1] );
		local entity = player:GetEyeTraceNoCursor().Entity;
		local healed = nil;
		local target = nexus.entity.GetPlayer(entity);
		
		if (target) then
			if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
				if (itemTable and arguments[1] == "health_vial") then
					if ( player:HasItem("health_vial") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 1.5), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_vial", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a health vial!");
					end;
				elseif (itemTable and arguments[1] == "health_kit") then
					if ( player:HasItem("health_kit") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 2), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_kit", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a health kit!");
					end;
				elseif (itemTable and arguments[1] == "bandage") then
					if ( player:HasItem("bandage") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("bandage", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a bandage!");
					end;
				else
					nexus.player.Notify(player, "This is not a valid item!");
				end;
				
				if (healed) then
					nexus.mount.Call("PlayerHealed", target, player, itemTable);
					
					if (nexus.player.GetAction(target) == "die") then
						nexus.player.SetRagdollState(target, RAGDOLL_NONE);
					end;
					
					player:FakePickup(target);
				end;
			else
				nexus.player.Notify(player, "This character is too far away!");
			end;
		else
			nexus.player.Notify(player, "You must look at a character!");
		end;
	else
		nexus.player.Notify(player, "You don't have permission to do this right now!");
	end;
end;

nexus.command.Register(COMMAND, "CharHeal");

COMMAND = {};
COMMAND.tip = "Demote a character from their position.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local isAdmin = ( player:IsUserGroup("operator") or player:IsAdmin() );
	
	if (player:Team() == CLASS_PRESIDENT or isAdmin) then
		local target = nexus.player.Get( arguments[1] );
		
		if (target) then
			local team = target:Team();
			
			if (team == CLASS_POLICE or team == CLASS_DISPENSER
			or team == CLASS_SECRETARY or isAdmin) then
				local name = g_Team.GetName(team);
				
				nexus.player.Notify(player, "You have demoted "..target:Name().." from "..name..".");
				nexus.player.Notify(target, player:Name().." has demoted you from "..name..".");
				
				nexus.class.Set(target, CLASS_CIVILIAN, true, true);
			else
				nexus.player.Notify(player, target:Name().." cannot be demoted from this position!");
			end;
		else
			nexus.player.Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		nexus.player.Notify(player, "You are not the president, or an administrator!");
	end;
end;

nexus.command.Register(COMMAND, "CharDemote");

COMMAND = {};
COMMAND.tip = "Blacklist a player from a class.";
COMMAND.text = "<string Name> <string Class>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] )
	local class = nexus.class.Get( arguments[2] )
	
	if (target) then
		local blacklist = target:GetData("blacklist");
		
		if (class) then
			if ( table.HasValue(blacklist, class.index) ) then
				nexus.player.Notify(player, target:Name().." is already on the "..class.." blacklist!");
			else
				nexus.player.NotifyAll(player:Name().." has added "..target:Name().." to the "..class.name.." blacklist.");
				
				NEXUS:StartDataStream( {target}, "SetBlacklisted", {class.index, true} );
				
				table.insert(blacklist, class.index);
			end;
		else
			nexus.player.Notify(player, "This is not a valid class!");
		end;
	else
		nexus.player.Notify(player, arguments[1].." is not a valid player!");
	end;
end;

nexus.command.Register(COMMAND, "PlyBlacklist");

COMMAND = {};
COMMAND.tip = "Unlacklist a player from a class.";
COMMAND.text = "<string Name> <string Class>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] )
	local class = nexus.class.Get( arguments[2] )
	
	if (target) then
		local blacklist = target:GetData("blacklist");
		
		if (class) then
			if ( !table.HasValue(blacklist, class.index) ) then
				nexus.player.Notify(player, target:Name().." is not on the "..class.." blacklist!");
			else
				nexus.player.NotifyAll(player:Name().." has removed "..target:Name().." from the "..class.name.." blacklist.");
				
				NEXUS:StartDataStream( {target}, "SetBlacklisted", {class.index, false} );
				
				for k, v in ipairs(blacklist) do
					if (v == class.index) then
						table.remove(blacklist, k);
						
						break;
					end;
				end;
			end;
		else
			nexus.player.Notify(player, "This is not a valid class!");
		end;
	else
		nexus.player.Notify(player, arguments[1].." is not a valid player!");
	end;
end;

nexus.command.Register(COMMAND, "PlyUnblacklist");

COMMAND = {};
COMMAND.tip = "Set your radio frequency, or a stationary radio's frequency.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local radio;
	
	if (IsValid(trace.Entity) and trace.Entity:GetClass() == "nx_radio") then
		if (trace.HitPos:Distance( player:GetShootPos() ) <= 192) then
			radio = trace.Entity;
		else
			nexus.player.Notify(player, "This stationary radio is too far away!");
			
			return;
		end;
	end;
	
	local frequency = arguments[1];
	
	if ( string.find(frequency, "^%d%d%d%.%d$") ) then
		local start, finish, decimal = string.match(frequency, "(%d)%d(%d)%.(%d)");
		
		start = tonumber(start);
		finish = tonumber(finish);
		decimal = tonumber(decimal);
		
		if (start == 1 and finish > 0 and finish < 10 and decimal > 0 and decimal < 10) then
			if (radio) then
				trace.Entity:SetFrequency(frequency);
				
				nexus.player.Notify(player, "You have set this stationary radio's frequency to "..frequency..".");
			else
				player:SetCharacterData("frequency", frequency);
				
				nexus.player.Notify(player, "You have set your radio frequency to "..frequency..".");
			end;
		else
			nexus.player.Notify(player, "The radio frequency must be between 101.1 and 199.9!");
		end;
	else
		nexus.player.Notify(player, "The radio frequency must look like xxx.x!");
	end;
end;

nexus.command.Register(COMMAND, "SetFreq");

COMMAND = {};
COMMAND.tip = "Set your caller ID, or cell phone number.";
COMMAND.text = "<string ID>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local charactersTable = nexus.config.Get("mysql_characters_table"):Get();
	local schemaFolder = NEXUS:GetSchemaFolder();
	local callerID = tmysql.escape( string.gsub(arguments[1], "%s%p", "") );
	
	if (callerID == "911" or callerID == "912") then
		nexus.player.Notify(player, "You cannot set your cell phone number to this!");
		
		return;
	end;
	
	tmysql.query("SELECT * FROM "..charactersTable.." WHERE _Schema = \""..schemaFolder.."\" AND _Data LIKE \"%\\\"callerid\\\":\\\""..callerID.."\\\"\"%", function(result)
		if ( IsValid(player) ) then
			if (result and type(result) == "table" and #result > 0) then
				nexus.player.Notify(player, "The cell phone number '"..callerID.."' already exists!");
			else
				player:SetCharacterData("callerid", callerID);
				
				nexus.player.Notify(player, "You set your cell phone number to '"..callerID.."'.");
			end;
		end;
	end, 1);
end;

nexus.command.Register(COMMAND, "SetCallerID");

COMMAND = {};
COMMAND.tip = "Set the name of a broadcaster.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if (target:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if (target:GetClass() == "nx_broadcaster") then
				target:SetNetworkedString( "sh_Name", arguments[1] );
			else
				nexus.player.Notify(player, "This entity is not a broadcaster!");
			end;
		else
			nexus.player.Notify(player, "This entity is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "SetBroadcasterName");

COMMAND = {};
COMMAND.tip = "Set the active government agenda.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local team = player:Team();
	
	if (team == CLASS_PRESIDENT) then
		NEXUS:SetSharedVar( "sh_Agenda", arguments[1] ); 
	else
		nexus.player.Notify(player, "You are not the president!");
	end;
end;

nexus.command.Register(COMMAND, "SetAgenda");

COMMAND = {};
COMMAND.tip = "Create a new alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	umsg.Start("nx_CreateAlliance", player);
	umsg.End();
end;

nexus.command.Register(COMMAND, "AllyCreate");

COMMAND = {};
COMMAND.tip = "Invite a character to your alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetCharacterData("alliance");
	local target = nexus.entity.GetPlayer(player:GetEyeTraceNoCursor().Entity);
	
	if (target) then
		if (alliance != "") then
			if ( player:GetCharacterData("leader") ) then
				if (target:GetVelocity():Length() == 0) then
					target.allianceAuthenticate = alliance;
					
					NEXUS:StartDataStream( {target}, "InviteAlliance", alliance );
					
					nexus.player.Notify(player, "You have invited this character to your alliance.");
					nexus.player.Notify(target, "A character has invited you to their alliance.");
				else
					nexus.player.Notify(target, "You cannot invite a character while they are moving!");
				end;
			else
				nexus.player.Notify(target, "You are not a leader of this alliance!");
			end;
		else
			nexus.player.Notify(target, "You are not in an alliance!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "AllyInvite");

COMMAND = {};
COMMAND.tip = "Make a character a leader of your alliance.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetCharacterData("alliance");
	local target = nexus.player.Get( table.concat(arguments, " ") );
	
	if (alliance != "") then
		if ( player:GetCharacterData("leader") ) then
			if (target) then
				local targetAlliance = target:GetCharacterData("alliance");
				
				if (targetAlliance == alliance) then
					target:SetCharacterData("leader", true);
					
					nexus.player.Notify(player, "You have made "..target:Name().." a leader of the '"..alliance.."' alliance.");
					nexus.player.Notify(target, player:Name().." has made you a leader of the '"..alliance.."' alliance.");
				else
					nexus.player.Notify(player, target:Name().." is not in your alliance!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You are not a leader of this alliance!");
		end;
	else
		nexus.player.Notify(target, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyMakeLeader");

COMMAND = {};
COMMAND.tip = "Kick a character out of your alliance.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetCharacterData("alliance");
	local target = nexus.player.Get( table.concat(arguments, " ") );
	
	if (alliance != "") then
		if ( player:GetCharacterData("leader") ) then
			if (target) then
				local targetAlliance = target:GetCharacterData("alliance");
				
				if (targetAlliance == alliance) then
					target:SetCharacterData("leader", nil);
					target:SetCharacterData("alliance", "");
					
					nexus.player.Notify(player, "You have kicked "..target:Name().." from the '"..alliance.."' alliance.");
					nexus.player.Notify(target, player:Name().." has kicked you from the '"..alliance.."' alliance.");
				else
					nexus.player.Notify(player, target:Name().." is not in your alliance!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You are not a leader of this alliance!");
		end;
	else
		nexus.player.Notify(player, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyKick");

COMMAND = {};
COMMAND.tip = "Leave your alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetCharacterData("alliance");
	
	if (alliance != "") then
		player:SetCharacterData("alliance", "");
		
		nexus.player.Notify(player, "You have left the '"..alliance.."' alliance.");
	else
		nexus.player.Notify(target, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyLeave");

COMMAND = {};
COMMAND.tip = "Disguise yourself as another character.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( player:HasItem("disguise_kit") ) then
		local curTime = CurTime();
		
		if (!player.nextUseDisguise or curTime >= player.nextUseDisguise) then
			local target = nexus.player.Get( arguments[1] );
			
			if (target) then
				if (player != target) then
					local success, fault = player:UpdateInventory("disguise_kit", -1);
					
					if (success) then
						nexus.player.Notify(player, "You are now disguised as "..target:Name().." for two minutes!");
						
						player.nextUseDisguise = curTime + 600;
						player:SetSharedVar("sh_Disguise", target);
						player.cancelDisguise = curTime + 120;
					end;
				else
					nexus.player.Notify(player, "You cannot disguise yourself as yourself!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You cannot use another disguise kit for "..math.Round( math.ceil(player.nextUseDisguise - curTime) ).." second(s)!");
		end;
	else
		nexus.player.Notify(player, "You do not own a disguise kit!");
	end;
end;

nexus.command.Register(COMMAND, "DisguiseSet");

COMMAND = {};
COMMAND.tip = "Remove your character's active disguise.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( IsValid( player:GetSharedVar("sh_Disguise") ) ) then
		nexus.player.Notify(player, "You have taken off your disguise, your true identity is revealed!");
		
		player:SetSharedVar("sh_Disguise", NULL);
		player.cancelDisguise = nil;
	end;
end;

nexus.command.Register(COMMAND, "DisguiseRemove");

COMMAND = {};
COMMAND.tip = "Use a zip tie from your inventory.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	nexus.player.RunNexusCommand(player, "InvAction", "zip_tie", "use");
end;

nexus.command.Register(COMMAND, "InvZipTie");

COMMAND = {};
COMMAND.tip = "Send a message out to all police.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callerid");
	
	if (playerCallerID and playerCallerID != "") then
		local curTime = CurTime();
		
		if (!player.nextSend911 or curTime >= player.nextSend911) then
			local eavesdroppers = {};
			local talkRadius = nexus.config.Get("talk_radius"):Get();
			local listeners = {};
			local position = player:GetShootPos();
			
			for k, v in ipairs( g_Player.GetAll() ) do
				if (v:Team() == CLASS_POLICE or player == v) then
					listeners[#listeners + 1] = v;
				elseif (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			end;
			
			player.nextSend911 = curTime + 30;
			
			if (#listeners > 0) then
				nexus.player.Notify("The line is busy, or there is nobody to take the call!");
				
				nexus.chatBox.Add( listeners, player, "911", arguments[1], {id = playerCallerID} );
				
				if (#eavesdroppers > 0) then
					nexus.chatBox.Add( eavesdroppers, player, "911_eavesdrop", arguments[1] );
				end;
			end;
		else
			nexus.player.Notify(player, "You can not call 911 for another "..math.Round( math.ceil(player.nextSend911 - curTime) ).." second(s)!");
		end;
	else
		nexus.player.Notify(player, "You have not set a cell phone number!");
	end;
end;

nexus.command.Register(COMMAND, "911");

COMMAND = {};
COMMAND.tip = "Send a message out to all secretaries.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callerid");
	
	if (playerCallerID and playerCallerID != "") then
		local curTime = CurTime();
		
		if (!player.nextSend912 or curTime >= player.nextSend912) then
			local eavesdroppers = {};
			local talkRadius = nexus.config.Get("talk_radius"):Get();
			local listeners = {};
			local position = player:GetShootPos();
			
			for k, v in ipairs( g_Player.GetAll() ) do
				if (v:Team() == CLASS_SECRETARY or player == v) then
					listeners[#listeners + 1] = v;
				elseif (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			end;
			
			player.nextSend912 = curTime + 30;
			
			if (#listeners > 0) then
				nexus.player.Notify("The line is busy, or there is nobody to take the call!");
				
				nexus.chatBox.Add( listeners, player, "912", arguments[1], {id = playerCallerID} );
				
				if (#eavesdroppers > 0) then
					nexus.chatBox.Add( eavesdroppers, player, "912_eavesdrop", arguments[1] );
				end;
			end;
		else
			nexus.player.Notify(player, "You can not call 912 for another "..math.Round( math.ceil(player.nextSend912 - curTime) ).." second(s)!");
		end;
	else
		nexus.player.Notify(player, "You have not set a cell phone number!");
	end;
end;

nexus.command.Register(COMMAND, "912");

COMMAND = {};
COMMAND.tip = "Speak to other members of your class using a headset.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local eavesdroppers = {};
	local talkRadius = nexus.config.Get("talk_radius"):Get();
	local listeners = {};
	local position = player:GetShootPos();
	local class = nexus.class.Get( player:Team() );
	
	if (class and class.headsetGroup) then
		for k, v in ipairs( g_Player.GetAll() ) do
			local targetClass = nexus.class.Get( v:Team() );
			
			if (!targetClass or targetClass.headsetGroup != class.headsetGroup) then
				if (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			else
				listeners[#listeners + 1] = v;
			end;
		end;
		
		if (#eavesdroppers > 0) then
			nexus.chatBox.Add( eavesdroppers, player, "headset_eavesdrop", arguments[1] );
		end;
		
		if (#listeners > 0) then
			nexus.chatBox.Add( listeners, player, "headset", arguments[1] );
		end;
	else
		nexus.player.Notify(player, "Your class does not have a headset!");
	end;
end;

nexus.command.Register(COMMAND, "Headset");

COMMAND = {};
COMMAND.tip = "Send out an advert to all players.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( nexus.player.CanAfford(player, 10) ) then
		nexus.chatBox.Add( nil, player, "advert", arguments[1] );
		
		nexus.player.GiveCash(player, -10, "making an advert");
	else
		nexus.player.Notify(player, "You need another "..FORMAT_CASH(10 - nexus.player.GetCash(player), nil, true).."!");
	end;
end;

nexus.command.Register(COMMAND, "Advert");

COMMAND = {};
COMMAND.tip = "Broadcast a message as the president.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:Team() == CLASS_PRESIDENT) then
		nexus.chatBox.Add( nil, player, "president", arguments[1] );
	else
		nexus.player.Notify(player, "You are not the president!");
	end;
end;

nexus.command.Register(COMMAND, "Broadcast");

COMMAND = {};
COMMAND.tip = "Call another character.";
COMMAND.text = "<string ID> <string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callerid");
	
	if (playerCallerID and playerCallerID != "") then
		local eavesdroppers = {};
		local talkRadius = nexus.config.Get("talk_radius"):Get();
		local listeners = {};
		local position = player:GetShootPos();
		local callerID = string.gsub(arguments[1], "%s%p", "");
		local text = table.concat(arguments, " ", 2);
		
		if (playerCallerID != callerID) then
			for k, v in ipairs( g_Player.GetAll() ) do
				if ( v:HasInitialized() and v:Alive() ) then
					if (v:GetCharacterData("callerid") == callerID) then
						listeners[#listeners + 1] = v;
					elseif (v:GetShootPos():Distance(position) <= talkRadius) then
						if (player != v) then
							eavesdroppers[#eavesdroppers + 1] = v;
						end;
					end;
				end;
			end;
			
			if (#listeners > 0) then
				listeners[#listeners + 1] = player;
				
				nexus.chatBox.Add( listeners, player, "call", text, {id = playerCallerID} );
			
				if (#eavesdroppers > 0) then
					nexus.chatBox.Add(eavesdroppers, player, "call_eavesdrop", text);
				end;
			else
				nexus.player.Notify(player, "The number you dialled could not be found!");
			end;
		else
			nexus.player.Notify(player, "You cannot call your own number!");
		end;
	else
		nexus.player.Notify(player, "You have not set a cell phone number!");
	end;
end;

nexus.command.Register(COMMAND, "Call");