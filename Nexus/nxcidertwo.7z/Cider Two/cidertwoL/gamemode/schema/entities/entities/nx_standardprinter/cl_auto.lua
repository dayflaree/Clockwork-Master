--[[
Name: "cl_auto.lua".
Product: "Cider Two".
--]]

include("sh_auto.lua");