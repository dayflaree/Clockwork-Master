--[[
Name: "cl_auto.lua".
Product: "Cider Two".
--]]

include("sh_auto.lua");

-- Called when the local player attempts to supply the generator.
function ENT:CanSupply()
	return false;
end;