--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

ENT.Type = "anim";
ENT.Base = "nx_generator";
ENT.Model = "models/props_combine/combine_mine01.mdl";
ENT.PrintName = "Standard Printer";