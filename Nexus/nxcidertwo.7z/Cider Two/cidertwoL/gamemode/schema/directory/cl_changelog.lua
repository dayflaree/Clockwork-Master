--[[
Name: "cl_changelog.lua".
Product: "Cider Two".
--]]

nexus.directory.AddCategoryPage( "Changelog", nil, [[
	<p>
		<font size="4">
			<b><i>Changes made on the 4th April 2010.</i></b><br>
		</font>
		<b>+</b> The price is billboards has been reduced.<br>
		<b>+</b> The faster you go, the more fuel you consume.<br>
		<b>+</b> The truck can now seat two more on the back of it.<br>
		<b>+</b> Fined $50 from your ATM when you die for a hospital bill.<br>
		<b>+</b> Added a billboard system. See the Billboards option in the main menu.<br>
		<b>+</b> If the driver of a vehicle leaves, all passengers automatically get out.<br>
		<b>+</b> Added interest for the bank. You gain 1% interest on money in your bank every hour.<br>
		<b>+</b> Added the EvoCity lottery, you can enter the lottery. See the Lottery option in the main menu.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 2nd April 2010.</i></b><br>
		</font>
		<b>+</b> The Civilian class gets no wages.<br>
		<b>+</b> Added more guidelines for the police.<br>
		<b>+</b> Lowered the police starting ammo.<br>
		<b>+</b> Heartbeat Sensor updates at half the speed.<br>
		<b>+</b> The Hustler class limit was reduced by half.<br>
		<b>+</b> All police can lock/unlock any police car.<br>
		<b>+</b> Diguise kits now also show phys desc and alliance.<br>
		<b>+</b> Blackmarket and Hustler classes only get $5 wages.<br>
		<b>+</b> Added a centre dot to the heartbeat sensor.<br>
		<b>+</b> Other players are alerted when you are consuming drugs.<br>
		<b>+</b> Added a disguise kit on the blackmarket and dispenser.<br>
		<b>+</b> Added a fake police uniform on the blackmarket for a high price.<br>
		<b>+</b> All classes are the same color to prevent metagaming.<br>
		<b>+</b> Dexterity affects how quickly you can do drugs.<br>
		<b>+</b> If you go to the police class your money printers explode.<br>
		<b>+</b> Added a hustler class to manufacture and sell drugs.<br>
		<b>+</b> Added a heroin lab to manufacture a temporary flow of heroin.<br>
		<b>+</b> Added a ecstacy lab to manufacture a temporary flow of ecstacy.<br>
		<b>+</b> Added a angel dust lab to manufacture a temporary flow of angel dust.<br>
		<b>+</b> Added a cocaine lab to manufacture a temporary flow of cocaine.<br>
		<b>+</b> Added a morphine to manufacture a temporary flow of morphine.<br>
		<b>+</b> Added a weed to manufacture a temporary flow of weed.<br>
		<b>+</b> Each drug gives you a temporary boost of a different attribute for an hour.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 1st April 2010.</i></b><br>
		</font>
		<b>+</b> Added a heartbeat sensor which you can buy from the blackmarket or dispenser.<br>
		<b>+</b> If you have less than thirty health, you cannot be detected by heartbeat sensors.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 30th March 2010.</i></b><br>
		</font>
		<b>+</b> Added a balaclava item that hides your name and physical description.<br>
		<b>+</b> A notepad that you can use to keep track of things (buy it from the merchant).<br>
		<b>+</b> Made it so you can't set a doors name to This door can be purchased.<br>
		<b>+</b> Added an option to set a door's name for the entire door family.<br>
		<b>+</b> You don't see the president as dead until they respawn.<br>
		<b>+</b> Added a new guideline for the police.<br>
		<b>+</b> Reduced the default falling damage.<br>
		<b>+</b> Added a new guideline for everybody.<br>
		<b>+</b> Added lots of new guidelines.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 29th March 2010.</i></b><br>
		</font>
		<b>+</b> Made it so you don't need a president to get wages as police, but if the president is
		killed you will still not get wages for two intervals.<br>
		<b>+</b> Shooting someone in the leg has a chance to make them fallover.<br>
		<b>+</b> Lowered the Civilian wages heavily, get a job!<br>
		<b>+</b> While your car is in your inventory, you can choose to sell it for half price.<br>
		<b>+</b> Added the Tacoma eight seater vehicle.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 28th March 2010.</i></b><br>
		</font>
		<b>+</b> Fixed the stationary radios and broadcasters.<br>
		<b>+</b> You can't use $command_prefix$fallover when in a vehicle.<br>
		<b>+</b> There is less of a black and white effect on the hunger/thirst.<br>
		<b>+</b> Instead of every hour and a half, you now need to eat/drink every two hours.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 25th March 2010.</i></b><br>
		</font>
		<b>+</b> To use your acrobatics attribute you now have to hold 'sprint' and jump.<br>
		<b>+</b> The more hungry or thirst you are the more noir your screen becomes.<br>
		<b>+</b> Added hunger. When your hunger bar is zero half of your attributes reduce heavily.<br>
		<b>+</b> Added thirst. When your thirst bar is zero the other half reduce heavily.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 23rd March 2010.</i></b><br>
		</font>
		<b>+</b> Made it easier to knock people out with the stunstick.<br>
		<b>+</b> When contraband is destroyed <i>all</i> cops get the profit.<br>
		<b>+</b> All characters in a government class temporarily know eachother.<br>
		<b>+</b> A government character can only take illegal items from a character when searching them.<br>
		<b>+</b> If a character is tied by the government, only the government can search them.<br>
		<b>+</b> Added searching tied characters, press F4 while looking at them.<br>
		<b>+</b> The police classes now start with a glock and some ammo.<br>
		<b>+</b> As a government class, you do not receive any wages if there is no president.<br>
		<b>+</b> If the president is <i>killed</i>, you will not receive any wages as a government class
		for three intervals.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 22nd March 2010.</i></b><br>
		</font>
		<b>+</b> If you don't recognise somebody, their model isn't shown on the scoreboard.<br>
		<b>+</b> The scoreboard players are sorted by recognition, people you know are higher.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 21st March 2010.</i></b><br>
		</font>
		<b>+</b> Added a $command_prefix$advert command that costs money to use.<br>
		<b>+</b> Made it so you cannot see somebody's alliance unless you recognise them.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 08th March 2010.</i></b><br>
		</font>
		<b>+</b> Started work on Cider Two nexus conversion.
	</p>
]] );