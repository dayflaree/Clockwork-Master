--[[
Name: "cl_auto.lua".
Product: "Cider Two".
--]]

SCHEMA.lastHeartbeatAmount = 0;
SCHEMA.nextHeartbeatCheck = 0;
SCHEMA.heartbeatGradient = Material("gui/gradient_down");
SCHEMA.heartbeatOverlay = Material("effects/combine_binocoverlay");
SCHEMA.heartbeatPoints = {};
SCHEMA.nextGetSnipers = 0;
SCHEMA.heartbeatPoint = Material("sprites/glow04_noz");
SCHEMA.laserSprite = Material("sprites/glow04_noz");
SCHEMA.highDistance = 0;
SCHEMA.highEffects = {};
SCHEMA.stunEffects = {};
SCHEMA.highTarget = 5;
SCHEMA.blacklist = {};

NEXUS:IncludePrefixed("sh_auto.lua");

surface.CreateFont("Quirkus", ScaleToWideScreen(2048), 600, true, false, "cid_Large3D2D");
surface.CreateFont("Quirkus", ScaleToWideScreen(32), 600, true, false, "cid_IntroTextSmall");
surface.CreateFont("Quirkus", ScaleToWideScreen(22), 600, true, false, "cid_IntroTextTiny");
surface.CreateFont("Quirkus", ScaleToWideScreen(32), 600, true, false, "cid_CinematicText");
surface.CreateFont("Quirkus", ScaleToWideScreen(62), 600, true, false, "cid_IntroTextBig");
surface.CreateFont("Quirkus", ScaleToWideScreen(22), 600, true, false, "cid_TargetIDText");
surface.CreateFont("Verdana", ScaleToWideScreen(12), 600, true, false, "cid_SmallBarText");
surface.CreateFont("Quirkus", ScaleToWideScreen(50), 600, true, false, "cid_MenuTextBig");
surface.CreateFont("Verdana", ScaleToWideScreen(17), 600, true, false, "cid_ChatBoxText");
surface.CreateFont("Quirkus", ScaleToWideScreen(20), 600, true, false, "cid_MainText");
surface.CreateFont("Quirkus", 36, 600, true, false, "cid_BillboardSmall");
surface.CreateFont("Quirkus", 72, 600, true, false, "cid_BillboardBig");

nexus.config.SetOverwatch("intro_text_small", "The small text displayed for the introduction.");
nexus.config.SetOverwatch("intro_text_big", "The big text displayed for the introduction.");

usermessage.Hook("nx_Frequency", function(msg)
	Derma_StringRequest("Frequency", "What would you like to set the frequency to?", msg:ReadString(), function(text)
		NEXUS:RunCommand("SetFreq", text);
	end);
end);

usermessage.Hook("nx_Disguise", function(msg)
	Derma_StringRequest("Disguise", "Enter part of the character's name that you'd like to disguise as.", "", function(text)
		NEXUS:RunCommand("DisguiseSet", text);
	end);
end);

NEXUS:HookDataStream("Billboards", function(data)
	for k, v in ipairs(data) do
		local wrappedTable = {};
		local unwrapped = v.data.text;
			NEXUS:WrapText(unwrapped, "cid_BillboardSmall", 384, wrappedTable);
		v.data.text = wrappedTable;
		v.data.unwrapped = unwrapped;
		
		SCHEMA.billboards[v.id].data = v.data;
	end;
	
	if ( nexus.menu.GetOpen() ) then
		if (nexus.menu.GetActivePanel() == SCHEMA.billboardPanel) then
			SCHEMA.billboardPanel:Rebuild();
		end;
	end;
end);

NEXUS:HookDataStream("BillboardAdd", function(data)
	local wrappedTable = {};
	local unwrapped = data.data.text;
		NEXUS:WrapText(unwrapped, "cid_BillboardSmall", 384, wrappedTable);
	data.data.text = wrappedTable;
	data.data.unwrapped = unwrapped;
	
	SCHEMA.billboards[data.id].data = data.data;
	
	if ( nexus.menu.GetOpen() ) then
		if (nexus.menu.GetActivePanel() == SCHEMA.billboardPanel) then
			SCHEMA.billboardPanel:Rebuild();
		end;
	end;
end);

NEXUS:HookDataStream("BillboardRemove", function(data)
	if (type(data) == "table") then
		for k, v in ipairs(data) do
			SCHEMA.billboards[v] = nil;
		end;
	else
		SCHEMA.billboards[data] = nil;
	end;
	
	if ( nexus.menu.GetOpen() ) then
		if (nexus.menu.GetActivePanel() == SCHEMA.billboardPanel) then
			SCHEMA.billboardPanel:Rebuild();
		end;
	end;
end);

NEXUS:HookDataStream("GetBlacklist", function(data)
	SCHEMA.blacklist = data;
end);

NEXUS:HookDataStream("SetBlacklisted", function(data)
	if ( data[2] ) then
		if ( !table.HasValue( SCHEMA.blacklist, data[1] ) ) then
			table.insert( SCHEMA.blacklist, data[1] );
		end;
	else
		for k, v in ipairs(SCHEMA.blacklist) do
			if ( v == data[1] ) then
				table.remove(SCHEMA.blacklist, k);
				
				break;
			end;
		end;
	end;
end);

NEXUS:HookDataStream("InviteAlliance", function(data)
	Derma_Query("Do you want to join the '"..data.."' alliance?", "Join Alliance", "Yes", function()
		NEXUS:StartDataStream("JoinAlliance", data);
		
		gui.EnableScreenClicker(false);
	end, "No", function()
		gui.EnableScreenClicker(false);
	end);
	
	gui.EnableScreenClicker(true);
end);

NEXUS:HookDataStream("Notepad", function(data)
	if ( SCHEMA.notepadPanel and SCHEMA.notepadPanel:IsValid() ) then
		SCHEMA.notepadPanel:Close();
		SCHEMA.notepadPanel:Remove();
	end;
	
	SCHEMA.notepadPanel = vgui.Create("nx_Notepad");
	SCHEMA.notepadPanel:Populate(data or "");
	SCHEMA.notepadPanel:MakePopup();
	
	gui.EnableScreenClicker(true);
end);

usermessage.Hook("nx_CreateAlliance", function(msg)
	Derma_StringRequest("Alliance", "What is the name of the alliance?", nil, function(text)
		NEXUS:StartDataStream("CreateAlliance", text);
	end);
end);

usermessage.Hook("nx_Death", function(msg)
	local weapon = msg:ReadEntity();
	
	if ( !IsValid(weapon) ) then
		SCHEMA.deathType = "UNKNOWN CAUSES";
	else
		local itemTable = nexus.item.GetWeapon(weapon);
		local class = weapon:GetClass();
		
		if (itemTable) then
			SCHEMA.deathType = "A "..string.upper(itemTable.name);
		elseif (class == "nx_hands") then
			SCHEMA.deathType = "BEING PUNCHED TO DEATH";
		else
			SCHEMA.deathType = "UNKNOWN CAUSES";
		end;
	end;
end);

usermessage.Hook("nx_Stunned", function(msg)
	local duration = msg:ReadFloat();
	local curTime = CurTime();
	
	if (!duration or duration == 0) then
		duration = 2;
	end;
	
	SCHEMA.stunEffects[#SCHEMA.stunEffects + 1] = {curTime + duration, duration};
	SCHEMA.flashEffect = {curTime + (duration * 2), duration * 2};
end);

usermessage.Hook("nx_Flashed", function(msg)
	local curTime = CurTime();
	
	SCHEMA.stunEffects[#SCHEMA.stunEffects + 1] = {curTime + 10, 10};
	SCHEMA.flashEffect = {curTime + 20, 20};
	
	surface.PlaySound("hl1/fvox/flatline.wav");
end);

usermessage.Hook("nx_TearGassed", function(msg)
	SCHEMA.tearGassed = CurTime() + 20;
end);

usermessage.Hook("nx_GetHigh", function(msg)
	SCHEMA.highEffects[#SCHEMA.highEffects + 1] = CurTime() + msg:ReadLong();
end);

usermessage.Hook("nx_ClearEffects", function(msg)
	SCHEMA.highEffects = {};
	SCHEMA.stunEffects = {};
	SCHEMA.flashEffect = nil;
	SCHEMA.tearGassed = nil;
end);

nexus.chatBox.RegisterClass("call_eavesdrop", "ic", function(info)
	if (info.shouldHear) then
		nexus.chatBox.Add(info.filtered, nil, Color(255, 255, 175, 255), info.name.." talks on their cell, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("call", "ic", function(info)
	if (g_LocalPlayer == info.speaker) then
		nexus.chatBox.Add(info.filtered, nil, Color(125, 255, 100, 255), info.name.." talks on their cell, \""..info.text.."\"");
	elseif (info.data.anon) then
		nexus.chatBox.Add(info.filtered, nil, Color(125, 255, 100, 255), "You are called by somebody, \""..info.text.."\"");
	else
		nexus.chatBox.Add(info.filtered, nil, Color(125, 255, 100, 255), "You are called by "..info.data.id..", \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("912_eavesdrop", "ic", function(info)
	if (info.shouldHear) then
		nexus.chatBox.Add(info.filtered, nil, Color(255, 255, 175, 255), info.name.." calls the secretaries, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("912", "ic", function(info)
	if (info.data.anon) then
		nexus.chatBox.Add(info.filtered, nil, Color(125, 175, 50, 255), "Somebody calls the secretaries, \""..info.text.."\"");
	else
		nexus.chatBox.Add(info.filtered, nil, Color(125, 175, 50, 255), info.data.id.." calls the secretaries, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("911_eavesdrop", "ic", function(info)
	if (info.shouldHear) then
		nexus.chatBox.Add(info.filtered, nil, Color(255, 255, 175, 255), info.name.." calls the police, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("911", "ic", function(info)
	if (info.data.anon) then
		nexus.chatBox.Add(info.filtered, nil, Color(125, 175, 50, 255), "Somebody calls the police, \""..info.text.."\"");
	else
		nexus.chatBox.Add(info.filtered, nil, Color(125, 175, 50, 255), info.data.id.." calls the police, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("headset_eavesdrop", "ic", function(info)
	if (info.shouldHear) then
		nexus.chatBox.Add(info.filtered, nil, Color(255, 255, 175, 255), info.name.." talks into their headset, \""..info.text.."\"");
	end;
end);

nexus.chatBox.RegisterClass("headset", "ic", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(125, 175, 50, 255), info.name.." talks into their headset, \""..info.text.."\"");
end);

nexus.chatBox.RegisterClass("lottery", "ooc", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(150, 100, 255, 255), info.text);
end);

nexus.chatBox.RegisterClass("advert", "ic", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(175, 150, 200, 255), "You notice an advert, it says \""..info.text.."\"");
end);

nexus.chatBox.RegisterClass("radio", "ic", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." radios in \""..info.text.."\"");
end);

nexus.chatBox.RegisterClass("president", "ic", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(200, 75, 125, 255), info.name.." broadcasts \""..info.text.."\"");
end);

nexus.chatBox.RegisterClass("killed", "ooc", function(info)
	local victim = info.data.victim;
	
	if ( IsValid(victim) ) then
		nexus.chatBox.Add(info.filtered, nil, victim, " has been killed by ", info.speaker, " (investigate the death).");
	end;
end);

nexus.chatBox.RegisterClass("broadcast", "ic", function(info)
	if ( IsValid(info.data.entity) ) then
		local name = info.data.entity:GetNetworkedString("sh_Name");
		
		if (name != "") then
			info.name = name;
		end;
	end;
	
	nexus.chatBox.Add(info.filtered, nil, Color(150, 125, 175, 255), info.name.." broadcasts \""..info.text.."\"");
end);

-- A function to get whether a text entry is being used.
function SCHEMA:IsTextEntryBeingUsed()
	if (self.textEntryFocused) then
		if ( self.textEntryFocused:IsValid() and self.textEntryFocused:IsVisible() ) then
			return true;
		end;
	end;
end;