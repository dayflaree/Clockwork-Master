--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

SCHEMA.name = "Cider Two";
SCHEMA.author = "kuropixel";
SCHEMA.description = "Redux of the popular roleplay gamemode cider";