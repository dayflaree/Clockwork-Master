--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Flashlight";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows flashlights to be purchased to allow characters to see in the dark.";