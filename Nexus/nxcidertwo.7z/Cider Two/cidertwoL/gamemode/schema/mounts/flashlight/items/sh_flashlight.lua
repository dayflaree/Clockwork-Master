--[[
Name: "sh_flashlight.lua".
Product: "Cider Two".
--]]

local ITEM = {};

ITEM.base = "weapon_base";
ITEM.name = "Flashlight";
ITEM.cost = 12;
ITEM.model = "models/lagmite/lagmite.mdl";
ITEM.weight = 0.8;
ITEM.classes = {CLASS_MERCHANT};
ITEM.category = "Reusables";
ITEM.uniqueID = "nx_flashlight";
ITEM.business = true;
ITEM.fakeWeapon = true;
ITEM.meleeWeapon = true;
ITEM.description = "A ceiling light, a button has been wired on to it.";

nexus.item.Register(ITEM);