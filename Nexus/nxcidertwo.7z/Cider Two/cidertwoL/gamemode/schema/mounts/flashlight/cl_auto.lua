--[[
Name: "cl_auto.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");