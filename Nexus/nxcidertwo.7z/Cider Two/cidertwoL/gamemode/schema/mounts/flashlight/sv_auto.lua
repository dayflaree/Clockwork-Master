--[[
Name: "sv_auto.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

nexus.hint.Add("Flashlight Item", "If it's dark outside and you can't see, invest in a flashlight.");
nexus.hint.Add("Flashlight Weapons", "Some weapons have a flashlight built into them.");

-- A function to get whether a player has a flashlight.
function MOUNT:PlayerHasFlashlight(player)
	local weapon = player:GetActiveWeapon();
	
	if ( IsValid(weapon) ) then
		local itemTable = nexus.item.GetWeapon(weapon);
		
		if ( weapon:GetClass() == "nx_flashlight" or (itemTable and itemTable.hasFlashlight) ) then
			return true;
		end;
	end;
end;