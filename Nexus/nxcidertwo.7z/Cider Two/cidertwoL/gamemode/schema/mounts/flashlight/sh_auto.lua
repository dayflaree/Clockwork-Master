--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sv_hooks.lua");