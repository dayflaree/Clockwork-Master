--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Storage";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows players to store money and items.";