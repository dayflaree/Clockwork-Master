--[[
Name: "sh_auto.lua".
Product: "EvoCity".
--]]

ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "kuropixel";
ENT.PrintName = "ATM";
ENT.Spawnable = false;
ENT.AdminSpawnable = true;
ENT.PhysgunDisabled = true;