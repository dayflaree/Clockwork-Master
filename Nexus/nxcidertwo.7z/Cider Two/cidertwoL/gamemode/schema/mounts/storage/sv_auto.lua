--[[
Name: "sv_auto.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

nexus.config.Add("max_locker_weight", 60);

nexus.hint.Add("Wire", "You can wire transfer money by using the command $command_prefix$wire.");
nexus.hint.Add("Wire ID", "You can set your wire transfer number by using the command $command_prefix$wireid.");

NEXUS:HookDataStream("ContainerPassword", function(player, data)
	local password = data[1];
	local entity = data[2];
	
	if ( IsValid(entity) ) then
		if ( nexus.entity.IsPhysicsEntity(entity) ) then
			local model = string.lower( entity:GetModel() );
			
			if ( MOUNT.containers[model] ) then
				local containerWeight = MOUNT.containers[model][1];
				
				if (entity.password == password) then
					MOUNT:OpenContainer(player, entity, containerWeight);
				else
					nexus.player.Notify(player, "You have entered an incorrect password!");
				end;
			end;
		end;
	end;
end);

-- A function to get a random item.
function MOUNT:GetRandomItem()
	if (#self.randomItems > 0) then
		local item = self.randomItems[ math.random(1, #self.randomItems) ];
		
		if (item) then
			if ( item[3] ) then
				local chance = (1 / self.highestCost) * math.min(item[3], self.highestCost * 0.99);
				
				if (math.random() >= chance) then
					return item;
				else
					return self:GetRandomItem();
				end;
			else
				return item;
			end;
		end;
	end;
end;

-- A function to save the storage.
function MOUNT:SaveStorage()
	local storage = {};
	
	for k, v in pairs(self.storage) do
		if ( IsValid(v) ) then
			if (v.inventory and v.cash and (table.Count(v.inventory) > 0 or v.cash > 0 or v:GetNetworkedString("nx_StorageName") != "") ) then
				local startPosition = v:GetStartPosition();
				local physicsObject = v:GetPhysicsObject();
				local moveable;
				local model = v:GetModel();
				
				if (v:IsMapEntity() and startPosition) then
					model = nil;
				end;
				
				if ( IsValid(physicsObject) ) then
					moveable = physicsObject:IsMoveable();
				end;
				
				storage[#storage + 1] = {
					name = v:GetNetworkedString("nx_StorageName"),
					model = model,
					color = { v:GetColor() },
					angles = v:GetAngles(),
					position = v:GetPos(),
					moveable = moveable,
					message = v.message,
					password = v.password,
					cash = v.cash,
					inventory = v.inventory,
					startPosition = startPosition
				};
			end;
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/storage/"..game.GetMap(), storage);
end;

-- A function to load the storage.
function MOUNT:LoadStorage()
	self.storage = {};
	
	local storage = NEXUS:RestoreSchemaData( "mounts/storage/"..game.GetMap() );
	-- local k2, v2;
	
	for k, v in pairs(storage) do
		for k2, v2 in pairs(v.inventory) do
			local itemTable = nexus.item.Get(k2);
			
			if (!itemTable) then
				v.inventory[k2] = nil;
			end;
		end;
		
		if (!v.model) then
			local entity = ents.FindInSphere(v.startPosition or v.position, 16)[1];
			
			if ( IsValid(entity) and entity:IsMapEntity() ) then
				self.storage[entity] = entity;
				
				entity.inventory = v.inventory;
				entity.cash = v.cash;
				entity.password = v.password;
				entity.message = v.message;
				
				if ( IsValid( entity:GetPhysicsObject() ) ) then
					if (!v.moveable) then
						entity:GetPhysicsObject():EnableMotion(false);
					else
						entity:GetPhysicsObject():EnableMotion(true);
					end;
				end;
				
				if (v.angles) then
					entity:SetAngles(v.angles);
					entity:SetPos(v.position);
				end;
				
				if (v.color) then
					entity:SetColor( unpack(v.color) );
				end;
				
				if (v.name and v.name != "") then
					entity:SetNetworkedString("nx_StorageName", v.name);
				end;
			end;
		else
			local entity = ents.Create("prop_physics");
			
			entity:SetAngles(v.angles);
			entity:SetModel(v.model);
			entity:SetPos(v.position);
			entity:Spawn();
			
			if ( IsValid( entity:GetPhysicsObject() ) ) then
				if (!v.moveable) then
					entity:GetPhysicsObject():EnableMotion(false);
				end;
			end;
			
			if (v.color) then
				entity:SetColor( unpack(v.color) );
			end;
			
			if (v.name and v.name != "") then
				entity:SetNetworkedString("nx_StorageName", v.name);
			end;
			
			self.storage[entity] = entity;
			
			entity.inventory = v.inventory;
			entity.cash = v.cash;
			entity.password = v.password;
			entity.message = v.message;
		end;
	end;
end;

-- A function to save the personal storage.
function MOUNT:SavePersonalStorage()
	local personalStorage = {};
	
	for k, v in pairs(self.personalStorage) do
		personalStorage[#personalStorage + 1] = {
			position = v.position,
			angles = v.angles,
			isATM = v.isATM
		};
	end;
	
	NEXUS:SaveSchemaData("mounts/personal/"..game.GetMap(), personalStorage);
end;

-- A function to load the personal storage.
function MOUNT:LoadPersonalStorage()
	self.personalStorage = {};
	
	local personalStorage = NEXUS:RestoreSchemaData( "mounts/personal/"..game.GetMap() );
	
	for k, v in pairs(personalStorage) do
		local data = {
			position = v.position,
			angles = v.angles,
			isATM = v.isATM
		};
		
		if (v.isATM) then
			data.entity = ents.Create("nx_atm");
		else
			data.entity = ents.Create("nx_locker");
		end;
		
		data.entity:SetAngles(data.angles);
		data.entity:SetPos(data.position);
		data.entity:Spawn();
		
		data.entity:GetPhysicsObject():EnableMotion(false);
		
		self.personalStorage[#self.personalStorage + 1] = data;
	end;
end;

-- A function to open a container for a player.
function MOUNT:OpenContainer(player, entity, weight)
	local inventory;
	local cash = 0;
	local name = "Locker";
	
	if (entity:GetClass() == "nx_locker") then
		cash = 0;
		weight = nexus.config.Get("max_locker_weight"):Get();
		inventory = player:GetCharacterData("lockerstorage");
	elseif (entity:GetClass() == "nx_atm") then
		cash = player:GetCharacterData("lockercash");
		name = "ATM";
		weight = nexus.config.Get("max_locker_weight"):Get() * 4;
		inventory = {};
	else
		local model = string.lower( entity:GetModel() );
		
		if (!entity.inventory) then
			self.storage[entity] = entity;
			
			entity.inventory = {};
		end;
		
		if (!entity.cash) then
			entity.cash = 0;
		end;
		
		if ( self.containers[model] ) then
			name = self.containers[model][2];
		else
			name = "Container";
		end;
		
		inventory = entity.inventory;
		cash = entity.cash;
		
		if (!weight) then
			weight = 8;
		end;
	end;
	
	if (entity:GetNetworkedString("sh_Name") != "") then
		name = entity:GetNetworkedString("sh_Name");
	end;
	
	if (entity.message) then
		umsg.Start("nx_StorageMessage", player);
			umsg.Entity(entity);
			umsg.String(entity.message);
		umsg.End();
	end;
	
	nexus.player.OpenStorage( player, {
		name = name,
		cash = cash,
		weight = weight,
		entity = entity,
		distance = 192,
		inventory = inventory,
		noCashWeight = true,
		OnGive = function(player, storageTable, itemTable)
			if (player:GetCharacterData("clothes") == itemTable.index) then
				if ( !player:HasItem(itemTable.index) ) then
					player:SetCharacterData("clothes", nil);
					
					itemTable:OnChangeClothes(player, false);
				end;
			end;
		end,
		CanGive = function(player, storageTable, item)
			if (storageTable.entity:GetClass() == "nx_atm") then
				return false;
			end;
		end,
		CanTake = function(player, storageTable, item)
			if (storageTable.entity:GetClass() == "nx_atm") then
				return false;
			end;
		end,
		OnGiveCash = function(player, storageTable, cash)
			if (storageTable.entity:GetClass() == "nx_atm") then
				player:SetCharacterData("lockercash", storageTable.cash);
			else
				storageTable.entity.cash = storageTable.cash;
			end;
		end,
		OnTakeCash = function(player, storageTable, cash)
			if (storageTable.entity:GetClass() == "nx_atm") then
				player:SetCharacterData("lockercash", storageTable.cash);
			else
				storageTable.entity.cash = storageTable.cash;
			end;
		end,
		CanGiveCash = function(player, storageTable, cash)
			if (storageTable.entity:GetClass() == "nx_locker") then
				return false;
			end;
		end,
		CanTakeCash = function(player, storageTable, cash)
			if (storageTable.entity:GetClass() == "nx_locker") then
				return false;
			end;
		end
	} );
end;