--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Writing";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds purchasble paper to the schema that players can write on.";