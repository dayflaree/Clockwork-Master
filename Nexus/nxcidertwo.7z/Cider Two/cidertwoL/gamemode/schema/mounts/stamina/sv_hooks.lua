--[[
Name: "sv_hooks.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

-- Called when a player's character data should be saved.
function MOUNT:PlayerSaveCharacterData(player, data)
	if ( data["stamina"] ) then
		data["stamina"] = math.Round( data["stamina"] );
	end;
end;

-- Called when a player's character data should be restored.
function MOUNT:PlayerRestoreCharacterData(player, data)
	data["stamina"] = data["stamina"] or 100;
end;

-- Called just after a player spawns.
function MOUNT:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("stamina", 100);
	end;
end;

-- Called when a player attempts to throw a punch.
function MOUNT:PlayerCanThrowPunch(player)
	if (player:GetCharacterData("stamina") <= 10) then
		return false;
	end;
end;

-- Called when a player throws a punch.
function MOUNT:PlayerPunchThrown(player)
	local attribute = nexus.attributes.Fraction(player, ATB_STAMINA, 1.5, 0.25);
	local carrying = (nexus.inventory.GetMaximumWeight(player) / 100) * nexus.inventory.GetWeight(player);
	local decrease = ( 5 + (carrying / 5) ) / (1 + attribute);
	local maximum = 100;
	
	player:SetCharacterData( "stamina", math.Clamp(player:GetCharacterData("stamina") - decrease, 0, maximum) );
end;

-- Called when a player's shared variables should be set.
function MOUNT:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "sh_Stamina", math.Round( player:GetCharacterData("stamina") ) );
	
	if ( player:Alive() ) then
		if (player:GetCharacterData("thirst") == 100) then
			player:BoostAttribute("Thirst", ATB_STAMINA, -50);
		else
			player:BoostAttribute("Thirst", ATB_STAMINA, false);
		end;
	end;
end;

-- Called at an interval while a player is connected.
function MOUNT:PlayerThink(player, curTime, infoTable)
	local maximum = 100;
	
	if (infoTable.running or infoTable.jogging) then
		local attribute = nexus.attributes.Fraction(player, ATB_STAMINA, 3, 0.25);
		local carrying = (nexus.inventory.GetMaximumWeight(player) / 100) * nexus.inventory.GetWeight(player);
		local decrease = ( 2 + (carrying / 40) + ( 1 - (math.min(player:Health(), 100) / 100) ) ) / (1 + attribute);
		
		if (jogging) then
			decrease = decrease / 2;
		end;
		
		player:SetCharacterData( "stamina", math.Clamp(player:GetCharacterData("stamina") - decrease, 0, maximum) );
		
		if (player:GetCharacterData("stamina") > 1) then
			if (infoTable.running) then
				player:ProgressAttribute(ATB_STAMINA, 0.125, true);
			elseif (infoTable.jogging) then
				player:ProgressAttribute(ATB_STAMINA, 0.0625, true);
			end;
		end;
	else
		player:SetCharacterData( "stamina", math.Clamp(player:GetCharacterData("stamina") + 2 - ( 1 - (math.min(player:Health(), 100) / 100) ), 0, maximum) );
	end;
	
	if (player:GetCharacterData("stamina") <= 1) then
		infoTable.running = false;
		infoTable.jogging = false;
	end;
end;