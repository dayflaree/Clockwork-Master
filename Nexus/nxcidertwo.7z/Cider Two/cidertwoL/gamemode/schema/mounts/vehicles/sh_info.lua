--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Vehicles";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds a variety of purchasable vehicles to the schema.";