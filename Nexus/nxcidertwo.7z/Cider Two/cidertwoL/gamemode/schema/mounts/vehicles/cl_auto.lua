--[[
Name: "cl_auto.lua".
Product: "Cider Two".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

usermessage.Hook("nx_VehiclePhysDesc", function(msg)
	local entity = msg:ReadEntity();
	
	if ( IsValid(entity) ) then
		Derma_StringRequest("Physical Description", "What is the physical description of this vehicle?", nil, function(text)
			NEXUS:StartDataStream( "VehiclePhysDesc", {entity, text} );
		end);
	end;
end);