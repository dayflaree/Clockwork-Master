--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

SCHEMA.billboards = {
	{
		position = Vector(-7847.8687, -7728.4404, 930.2415),
		angles = Angle(0, 90, 90),
		scale = 0.4375
	},
	{
		position = Vector(-5579.8511 -7212.6436, 816.4194),
		angles = Angle(0, -90, 90),
		scale = 0.4375
	},
	{
		position = Vector(-7719.0088, -4902.2466, 929.4857),
		angles = Angle(0, 90, 90),
		scale = 0.4375
	},
	{
		position = Vector(-5615.9512, -10324.8281, 926.2682),
		angles = Angle(0, -90, 90),
		scale = 0.4375
	},
	{
		position = Vector(-5579.8511, -7214.5537, 815.8289),
		angles = Angle(0, -90, 90),
		scale = 0.4375
	},
	{
		position = Vector(-446.1304, 6122.8198, 342.4596),
		angles = Angle(0, 50, 90),
		scale = 0.4375
	},
	{
		position = Vector(3489.8989, -6673.7188, 499.5970),
		angles = Angle(0, -180, 90),
		scale = 0.4375
	},
	{
		position = Vector(427.7188, 4524.6401, 440.7368),
		angles = Angle(0, -90, 90),
		scale = 0.4375
	},
	{
		position = Vector(790.3043, 7232.0161, 571.6388),
		angles = Angle(0, 90, 90),
		scale = 0.4375
	},
	{
		position = Vector(4208.2612, 5631.6914, 723.6007),
		angles = Angle(0, 90, 90),
		scale = 0.4375
	},
	{
		position = Vector(1861.0153, 3574.7188, 523.0126),
		angles = Angle(0, 0, 90),
		scale = 0.4375
	}
};

for k, v in pairs( g_File.Find("../models/humans/group17/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/humans/group17/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group99/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group99/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group99/"..v);
	end;
end;

for k, v in pairs( g_File.Find("../models/humans/group09/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group09/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group09/"..v);
	end;
end;

for k, v in pairs( g_File.Find("../models/humans/group10/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group10/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group10/"..v);
	end;
end;

for k, v in pairs( g_File.Find("../models/humans/group08/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group08/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group08/"..v);
	end;
end;

for k, v in pairs( g_File.Find("../models/humans/group07/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group07/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group07/"..v);
	end;
end;

for k, v in pairs( g_File.Find("../models/humans/group04/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		nexus.animation.AddFemaleHumanModel("models/humans/group04/"..v);
	else
		nexus.animation.AddMaleHumanModel("models/humans/group04/"..v);
	end;
end;

nexus.schema.SetOption("model_shipment", "models/props_junk/cardboard_box003b.mdl");
nexus.schema.SetOption("html_background", "http://roleplayunion.com/bg.gif");
nexus.schema.SetOption("intro_image", "cidertwo/logo");
nexus.schema.SetOption("name_cash", "Dollars");

nexus.schema.SetFont("bar_text", "cid_TargetIDText");
nexus.schema.SetFont("main_text", "cid_MainText");
nexus.schema.SetFont("hints_text", "cid_IntroTextTiny");
nexus.schema.SetFont("large_3d_2d", "cid_Large3D2D");
nexus.schema.SetFont("chat_box_text", "cid_ChatBoxText");
nexus.schema.SetFont("target_id_text", "cid_TargetIDText");
nexus.schema.SetFont("cinematic_text", "cid_CinematicText");
nexus.schema.SetFont("date_time_text", "cid_IntroTextSmall");
nexus.schema.SetFont("menu_text_big", "cid_MenuTextBig");
nexus.schema.SetFont("menu_text_tiny", "cid_IntroTextTiny");
nexus.schema.SetFont("intro_text_big", "cid_IntroTextBig");
nexus.schema.SetFont("menu_text_small", "cid_IntroTextSmall");
nexus.schema.SetFont("intro_text_tiny", "cid_IntroTextTiny");
nexus.schema.SetFont("intro_text_small", "cid_IntroTextSmall");
nexus.schema.SetFont("player_info_text", "cid_ChatBoxText");

NEXUS:RegisterGlobalSharedVar("sh_NoWagesTime", NWTYPE_NUMBER);
NEXUS:RegisterGlobalSharedVar("sh_Lottery", NWTYPE_NUMBER);
NEXUS:RegisterGlobalSharedVar("sh_Agenda", NWTYPE_STRING);

nexus.player.RegisterSharedVar("sh_BeingChloro", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_SkullMask", NWTYPE_BOOL);
nexus.player.RegisterSharedVar("sh_BeingTied", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Alliance", NWTYPE_STRING);
nexus.player.RegisterSharedVar("sh_Disguise", NWTYPE_ENTITY);
nexus.player.RegisterSharedVar("sh_Clothes", NWTYPE_NUMBER, true);
nexus.player.RegisterSharedVar("sh_Lottery", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Sensor", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Hunger", NWTYPE_NUMBER, true);
nexus.player.RegisterSharedVar("sh_Thirst", NWTYPE_NUMBER, true);
nexus.player.RegisterSharedVar("sh_Leader", NWTYPE_BOOL);
nexus.player.RegisterSharedVar("sh_Tied", NWTYPE_NUMBER);

nexus.quiz.SetName("Roleplay Quiz, and Terms of Playing");
nexus.quiz.SetEnabled(true);
nexus.quiz.AddQuestion("I know that because of the logs, I will never get away with rule-breaking.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("When creating a character, I will use a full and appropriate name.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("I understand that the script has vast logs that are checked often.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("I will read the guidelines and directory in the main menu.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("I understand That this is a passive roleplay experience", 2, "No.", "Yes.");
nexus.quiz.AddQuestion("This is based on Grand Theft auto Liberty City Stories.", 2, "Yes.", "No.");
nexus.quiz.AddQuestion("Do you understand that a character will have 1 Passion, this means you select a job you stay on that job and reselect it next time.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("Will you follow the traffic lights and crossing lights?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("What does OOC stand for.", 2, "Out Of Context.", "Out Of Character.");
nexus.quiz.AddQuestion("Do you understand that roleplaying is slow paced and relaxed?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("Will you buy a house right away. or go raid the Police Station", 1, "I will take the subway to the suburbs and live there", "No, Im fucking rambo, give me a gun im gonna own sum nubz");
nexus.quiz.AddQuestion("Can you type properly, using capital letters and full-stops?", 2, "yes i can", "Yes, I can.");
nexus.quiz.AddQuestion("You do not need weapons to roleplay, do you understand?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("You do not need items, besides food to roleplay, do you understand?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("What do you think serious roleplaying is about?", 2, "Collecting items and upgrades.", "Developing your character.");
nexus.quiz.AddQuestion("What universe is this roleplaying game set in?", 1, "Real Life.", "Apocalypse.");

NEXUS:IncludePrefixed("sh_coms.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");

nexus.flag.Add("q", "Special", "Access to the special items.");