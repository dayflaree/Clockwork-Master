--[[
Name: "sv_auto.lua".
Product: "Cider Two".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");

resource.AddFile("models/katharsmodels/contraband/zak_wiet/zak_wiet.mdl");
resource.AddFile("models/katharsmodels/syringe_out/syringe_out.mdl");
resource.AddFile("models/katharsmodels/syringe_out/heroine_out.mdl");
resource.AddFile("resource/fonts/quirkus.ttf");
resource.AddFile("models/jaanus/morphi.mdl");
resource.AddFile("models/jaanus/ecstac.mdl");
resource.AddFile("models/sprayca2.mdl");
resource.AddFile("models/cocn.mdl");

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/cikizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/cikizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/cirizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/cirizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/ciaizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/ciaizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/cilizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/cilizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/cibizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/cibizen_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/cityadm_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/cityadm_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/freerun_sheet.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/freerun_sheet.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/katharsmodels/contraband/*.*") ) do
	resource.AddFile("materials/katharsmodels/contraband/"..v);
end;

for k, v in pairs( g_File.Find("../materials/katharsmodels/syringe_out/*.*") ) do
	resource.AddFile("materials/katharsmodels/syringe_out/"..v);
end;

for k, v in pairs( g_File.Find("../materials/katharsmodels/syringe_in/*.*") ) do
	resource.AddFile("materials/katharsmodels/syringe_in/"..v);
end;

for k, v in pairs( g_File.Find("../materials/jaanus/ecstac_a.*") ) do
	resource.AddFile("materials/jaanus/"..v);
end;

for k, v in pairs( g_File.Find("../materials/jaanus/morphi_a.*") ) do
	resource.AddFile("materials/jaanus/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/drug/*.*") ) do
	resource.AddFile("materials/models/drug/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/lagmite/*.*") ) do
	resource.AddFile("materials/models/lagmite/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/spraycan3.*") ) do
	resource.AddFile("materials/models/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/deadbodies/*.*") ) do
	resource.AddFile("materials/models/deadbodies/"..v);
end;

for k, v in pairs( g_File.Find("../models/deadbodies/*.*") ) do
	resource.AddFile("models/deadbodies/"..v);
end;

for k, v in pairs( g_File.Find("../models/lagmite/*.*") ) do
	resource.AddFile("models/lagmite/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group17/*.mdl") ) do
	resource.AddFile("models/humans/group17/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group99/*.mdl") ) do
	resource.AddFile("models/humans/group99/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group09/*.mdl") ) do
	resource.AddFile("models/humans/group09/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group10/*.mdl") ) do
	resource.AddFile("models/humans/group10/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group08/*.mdl") ) do
	resource.AddFile("models/humans/group08/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group07/*.mdl") ) do
	resource.AddFile("models/humans/group07/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group04/*.mdl") ) do
	resource.AddFile("models/humans/group04/"..v);
end;

nexus.config.Add("intro_text_small", "Where the rich get famous.", true);
nexus.config.Add("intro_text_big", "DEEP WITHIN EVOCITY, 2010.", true);

nexus.config.Get("change_class_interval"):Set(60);
nexus.config.Get("enable_gravgun_punt"):Set(false);
nexus.config.Get("default_inv_weight"):Set(8);
nexus.config.Get("minimum_physdesc"):Set(16);
nexus.config.Get("scale_prop_cost"):Set(0);
nexus.config.Get("disable_sprays"):Set(false);
nexus.config.Get("wages_interval"):Set(360);
nexus.config.Get("default_cash"):Set(80);

nexus.hint.Add("911", "You can contact the police by using the command $command_prefix$911.");
nexus.hint.Add("912", "You can contact secretaries by using the command $command_prefix$912.");
nexus.hint.Add("Call", "Call somebody by using the command $command_prefix$call.");
nexus.hint.Add("Admins", "The admins are here to help you, please respect them.");
nexus.hint.Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
nexus.hint.Add("Healing", "You can heal players by using the Give command in your inventory.");
nexus.hint.Add("Headset", "You can speak to other characters with your class by using $command_prefix$headset.");
nexus.hint.Add("Alliance", "You can create an alliance by using the command $command_prefix$alliancecreate.");
nexus.hint.Add("Broadcast", "As the president, you can broadcast to the city with $command_prefix$broadcast.");
nexus.hint.Add("F3 Hotkey", "Press F3 while looking at a character to use a zip tie.");
nexus.hint.Add("F4 Hotkey", "Press F4 while looking at a tied character to search them.");
nexus.hint.Add("Caller ID", "Set your cell phone number by using the command $command_prefix$callerid.");

NEXUS:HookDataStream("TakeDownBillboard", function(player, data)
	local billboard = SCHEMA.billboards[data];
	
	if (billboard and billboard.data) then
		if (billboard.data.owner == player) then
			NEXUS:StartDataStream(nil, "BillboardRemove", data);
			
			billboard.uniqueID = nil;
			billboard.data = nil;
			billboard.key = nil;
		end;
	end;
end);

NEXUS:HookDataStream("PurchaseLottery", function(player, data)
	if (type(data) == "table") then
		local numberOne = tonumber( data[1] ) or 1;
		local numberTwo = tonumber( data[2] ) or 1;
		local numberThree = tonumber( data[3] ) or 1;
		
		local nextLotteryTime = NEXUS:GetSharedVar("sh_Lottery");
		local lotteryTicket = player:GetSharedVar("sh_Lottery");
		local curTime = CurTime();
		
		if (nextLotteryTime > curTime and !lotteryTicket) then
			if ( nexus.player.CanAfford(player, 40) ) then
				nexus.player.GiveCash(player, -40, "purchasing a lottery ticket");
				
				SCHEMA.lotteryCash = SCHEMA.lotteryCash + 40;
				
				player:SetSharedVar("sh_Lottery", true);
				player.lottery = {numberOne, numberTwo, numberThree};
			else
				nexus.player.Notify(player, "You need another "..FORMAT_CASH(40 - nexus.player.GetCash(player), nil, true).."!");
			end;
		elseif (!lotteryTicket) then
			nexus.player.Notify(player, "The lottery is currently in progress, please wait!");
		else
			nexus.player.Notify(player, "You have already purchased a lottery ticket, please wait.");
		end;
	end;
end);

NEXUS:HookDataStream("UpdateBillboard", function(player, data)
	if (type(data) == "table") then
		local billboard = SCHEMA.billboards[data.id];
		local color = Color(255, 255, 255, 255);
		local title = string.sub(data.title or "", 0, 18);
		local text = string.sub(data.text or "", 0, 80);
		
		if (data.color) then
			color.r = data.color.r or 255;
			color.g = data.color.g or 255;
			color.b = data.color.b or 255;
		end;
		
		if (billboard) then
			if ( billboard.data and IsValid(billboard.data.owner) ) then
				if (billboard.data.owner == player) then
					billboard.data = {
						color = color,
						owner = player,
						title = title,
						text = text
					};
					
					NEXUS:StartDataStream( nil, "BillboardAdd", {id = data.id, data = billboard.data} );
				end;
			else
				if ( nexus.player.CanAfford(player, 60) ) then
					billboard.uniqueID = player:UniqueID();
					billboard.data = {
						owner = player,
						color = color,
						title = title,
						text = text
					};
					billboard.key = player:QueryCharacter("key");
					
					NEXUS:StartDataStream( nil, "BillboardAdd", {id = data.id, data = billboard.data} );
					
					nexus.player.GiveCash(player, -60, "purchasing a billboard");
				else
					nexus.player.Notify(player, "You need another "..FORMAT_CASH(60 - nexus.player.GetCash(player), nil, true).."!");
				end;
			end;
		end;
	end;
end);

NEXUS:HookDataStream("JoinAlliance", function(player, data)
	if (player.allianceAuthenticate == data) then
		player:SetCharacterData("leader", nil);
		player:SetCharacterData("alliance", data);
		
		nexus.player.Notify(player, "You have joined the '"..data.."' alliance.");
	end;
end);

NEXUS:HookDataStream("Notepad", function(player, data)
	if ( type(data) == "string" and player:HasItem("notepad") ) then
		player:SetCharacterData( "notepad", string.sub(data, 0, 500) );
	end;
end);

NEXUS:HookDataStream("CreateAlliance", function(player, data)
	if (type(data) == "string") then
		local charactersTable = nexus.config.Get("mysql_characters_table"):Get();
		local schemaFolder = NEXUS:GetSchemaFolder();
		local alliance = tmysql.escape( string.gsub(string.sub(data, 1, 32), "[%p%d]", "") );
		
		tmysql.query("SELECT * FROM "..charactersTable.." WHERE _Schema = \""..schemaFolder.."\" AND _Data LIKE \"%\\\"alliance\\\":\\\""..alliance.."\\\"\"%", function(result)
			if ( IsValid(player) ) then
				if (result and type(result) == "table" and #result > 0) then
					nexus.player.Notify(player, "An alliance with the name '"..alliance.."' already exists!");
				else
					player:SetCharacterData("leader", true);
					player:SetCharacterData("alliance", alliance);
					
					nexus.player.Notify(player, "You have created the '"..alliance.."' alliance.");
				end;
			end;
		end, 1);
	end;
end);

-- A function to load the radios.
function SCHEMA:LoadRadios()
	local radios = NEXUS:RestoreSchemaData( "mounts/radios/"..game.GetMap() );
	
	for k, v in pairs(radios) do
		local entity;
		
		if (v.frequency) then
			entity = ents.Create("nx_radio");
		else
			entity = ents.Create("nx_broadcaster");
		end;
		
		nexus.player.GivePropertyOffline(v.key, v.uniqueID, entity);
		
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if ( IsValid(entity) ) then
			entity:SetOff(v.off);
			
			if (v.frequency) then
				entity:SetFrequency(v.frequency);
			end;
		end;
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if ( IsValid(physicsObject) ) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the radios.
function SCHEMA:SaveRadios()
	local radios = {};
	
	for k, v in pairs( ents.FindByClass("nx_radio") ) do
		local physicsObject = v:GetPhysicsObject();
		local moveable;
		
		if ( IsValid(physicsObject) ) then
			moveable = physicsObject:IsMoveable();
		end;
		
		radios[#radios + 1] = {
			off = v:IsOff(),
			key = nexus.entity.QueryProperty(v, "key"),
			angles = v:GetAngles(),
			moveable = moveable,
			uniqueID = nexus.entity.QueryProperty(v, "uniqueID"),
			position = v:GetPos(),
			frequency = v:GetSharedVar("sh_Frequency")
		};
	end;
	
	for k, v in pairs( ents.FindByClass("nx_broadcaster") ) do
		local physicsObject = v:GetPhysicsObject();
		local moveable;
		
		if ( IsValid(physicsObject) ) then
			moveable = physicsObject:IsMoveable();
		end;
		
		radios[#radios + 1] = {
			off = v:IsOff(),
			key = nexus.entity.QueryProperty(v, "key"),
			angles = v:GetAngles(),
			moveable = moveable,
			uniqueID = nexus.entity.QueryProperty(v, "uniqueID"),
			position = v:GetPos()
		};
	end;
	
	NEXUS:SaveSchemaData("mounts/radios/"..game.GetMap(), radios);
end;

-- A function to make an explosion.
function SCHEMA:MakeExplosion(position, scale)
	local explosionEffect = EffectData();
	local smokeEffect = EffectData();
	
	explosionEffect:SetOrigin(position);
	explosionEffect:SetScale(scale);
	smokeEffect:SetOrigin(position);
	smokeEffect:SetScale(scale);
	
	util.Effect("explosion", explosionEffect, true, true);
	util.Effect("nx_effect_smoke", smokeEffect, true, true);
end;

-- A function to get a player's location.
function SCHEMA:PlayerGetLocation(player)
	local areaNames = nexus.mount.Get("Area Names");
	local closest;
	
	if (areaNames) then
		for k, v in pairs(areaNames.areaNames) do
			if ( nexus.entity.IsInBox(player, v.minimum, v.maximum) ) then
				if (string.sub(string.lower(v.name), 1, 4) == "the ") then
					return string.sub(v.name, 5);
				else
					return v.name;
				end;
			else
				local distance = player:GetShootPos():Distance(v.minimum);
				
				if ( !closest or distance < closest[1] ) then
					closest = {distance, v.name};
				end;
			end;
		end;
		
		if (!completed) then
			if (closest) then
				if (string.sub(string.lower( closest[2] ), 1, 4) == "the ") then
					return string.sub(closest[2], 5);
				else
					return closest[2];
				end;
			end;
		end;
	end;
	
	return "unknown location";
end;

-- A function to load the lottery cash.
function SCHEMA:LoadLotteryCash()
	self.lotteryCash = NEXUS:RestoreSchemaData("lottery");
	
	if ( !tonumber(self.lotteryCash) ) then
		self.lotteryCash = 0;
	end;
end;

-- A function to save the lottery cash.
function SCHEMA:SaveLotteryCash()
	NEXUS:SaveSchemaData("lottery", self.lotteryCash);
end;

-- A function to load the static props.
function SCHEMA:LoadStaticProps()
	self.staticProps = NEXUS:RestoreSchemaData( "mounts/props/"..game.GetMap() );
	
	for k, v in pairs(self.staticProps) do
		local entity = ents.Create("prop_physics");
		
		entity:SetAngles(v.angles);
		entity:SetModel(v.model);
		entity:SetPos(v.position);
		entity:Spawn();
		
		entity.PhysgunDisabled = true;
		entity.CanTool = function(entity, player, trace, tool)
			return false;
		end;
		
		if ( IsValid( entity:GetPhysicsObject() ) ) then
			entity:GetPhysicsObject():EnableMotion(false);
		end;
		
		self.staticProps[k] = entity;
	end;
end;

-- A function to save the static props.
function SCHEMA:SaveStaticProps()
	local staticProps = {};
	
	for k, v in pairs(self.staticProps) do
		if ( IsValid(v) ) then
			staticProps[#staticProps + 1] = {
				model = v:GetModel(),
				angles = v:GetAngles(),
				position = v:GetPos()
			};
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/props/"..game.GetMap(), staticProps);
end;

-- A function to get a player's gear.
function SCHEMA:GetPlayerGear(player, class)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		return player[uniqueID];
	end;
end;

-- A function to create a player's gear.
function SCHEMA:CreatePlayerGear(player, class, itemTable)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		player[uniqueID]:Remove();
	end;
	
	if (itemTable.isAttachment) then
		local position = player:GetPos();
		local angles = player:GetAngles();
		
		player[uniqueID] = ents.Create("nx_gear");
		player[uniqueID]:SetParent(player);
		player[uniqueID]:SetAngles(angles);
		player[uniqueID]:SetColor(255, 255, 255, 0);
		player[uniqueID]:SetModel(itemTable.model);
		player[uniqueID]:SetPos(position);
		player[uniqueID]:Spawn();
		
		if (itemTable.color) then
			player[uniqueID]:SetColor( NEXUS:UnpackColor(itemTable.color) );
		end;
		
		if (itemTable.material) then
			player[uniqueID]:SetMaterial(material);
		end;
		
		if ( IsValid( player[uniqueID] ) ) then
			player[uniqueID]:SetOwner(player);
			player[uniqueID]:SetItem(itemTable);
		end;
	end;
end;

-- A function to make a player wear clothes.
function SCHEMA:PlayerWearClothes(player, itemTable)
	local clothes = player:GetCharacterData("clothes");
	local team = player:Team();
	
	if (itemTable) then
		if (team != CLASS_PRESIDENT and team != CLASS_SECRETARY) then
			itemTable:OnChangeClothes(player, true);
			
			player:SetCharacterData("clothes", itemTable.index);
			player:SetSharedVar("sh_Clothes", itemTable.index);
		end;
	else
		itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
			player:SetSharedVar("sh_Clothes", 0);
		end;
	end;
	
	if (itemTable) then
		player:UpdateInventory(itemTable.uniqueID);
	end;
end;

-- A function to get a player's heal amount.
function SCHEMA:GetHealAmount(player, scale)
	local medical = nexus.attributes.Fraction(player, ATB_MEDICAL, 35);
	local healAmount = (15 + medical) * (scale or 1);
	
	return healAmount;
end;

-- A function to get a player's dexterity time.
function SCHEMA:GetDexterityTime(player)
	return 7 - nexus.attributes.Fraction(player, ATB_DEXTERITY, 5, 5);
end;

-- A function to get whether a player has won the lottery.
function SCHEMA:HasWonLottery(player, numbers, winningNumbers)
	local correctNumbers = 0;
	local numbersCopy = table.Copy(winningNumbers);
	
	for i = 1, 3 do
		for o = 1, 3 do
			if ( numbers[i] == numbersCopy[o] ) then
				correctNumbers = correctNumbers + 1;
				numbersCopy[o] = nil;
				
				break;
			end;
		end;
	end;
	
	if (correctNumbers == 3) then
		return true;
	else
		return false;
	end;
end;

-- A function to bust down a door.
function SCHEMA:BustDownDoor(player, door, force)
	door.bustedDown = true;
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if ( IsValid(physicsObject) ) then
		if (!force) then
			if ( IsValid(player) ) then
				physicsObject:ApplyForceCenter( ( door:GetPos() - player:GetPos() ):Normalize() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	nexus.entity.Decay(fakeDoor, 300);
	
	NEXUS:CreateTimer("Reset Door: "..door:EntIndex(), 300, 1, function()
		if ( IsValid(door) ) then
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
			door.bustedDown = nil;
		end;
	end);
end;

-- A function to load the belongings.
function SCHEMA:LoadBelongings()
	local belongings = NEXUS:RestoreSchemaData( "mounts/belongings/"..game.GetMap() );
	
	for k, v in pairs(belongings) do
		local entity = ents.Create("nx_belongings");
		
		if ( v.inventory["human_meat"] ) then
			v.inventory["human_meat"] = nil;
		end;
		
		entity:SetAngles(v.angles);
		entity:SetData(v.inventory, v.cash);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if ( IsValid(physicsObject) ) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the belongings.
function SCHEMA:SaveBelongings()
	local belongings = {};
	
	for k, v in pairs( ents.FindByClass("prop_ragdoll") ) do
		if (v.areBelongings) then
			if (v.cash > 0 or table.Count(v.inventory) > 0) then
				belongings[#belongings + 1] = {
					cash = v.cash,
					angles = Angle(0, 0, -90),
					moveable = true,
					position = v:GetPos() + Vector(0, 0, 32),
					inventory = v.inventory
				};
			end;
		end;
	end;
	
	for k, v in pairs( ents.FindByClass("nx_belongings") ) do
		if ( v.cash and v.inventory and (v.cash > 0 or table.Count(v.inventory) > 0) ) then
			local physicsObject = v:GetPhysicsObject();
			local moveable;
			
			if ( IsValid(physicsObject) ) then
				moveable = physicsObject:IsMoveable();
			end;
			
			belongings[#belongings + 1] = {
				cash = v.cash,
				angles = v:GetAngles(),
				moveable = moveable,
				position = v:GetPos(),
				inventory = v.inventory
			};
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/belongings/"..game.GetMap(), belongings);
end;

-- A function to make a player drop random items.
function SCHEMA:PlayerDropRandomItems(player, ragdoll)
	local defaultModel = nexus.player.GetDefaultModel(player);
	local defaultSkin = nexus.player.GetDefaultSkin(player);
	local inventory = nexus.player.GetInventory(player);
	local clothes = player:GetCharacterData("clothes");
	local model = player:GetModel();
	local cash = nexus.player.GetCash(player);
	local info = {
		inventory = {},
		cash = cash
	};
	
	if ( !IsValid(ragdoll) ) then
		info.entity = ents.Create("nx_belongings");
	end;
	
	for k, v in pairs(inventory) do
		local itemTable = nexus.item.Get(k);
		
		if (itemTable and itemTable.allowStorage != false
		and !itemTable.isRareItem) then
			local success, fault = player:UpdateInventory(k, -v, true, true);
			
			if (success) then
				info.inventory[k] = v;
			end;
		end;
	end;
	
	player:SetCharacterData("cash", 0, true);
	
	if ( !IsValid(ragdoll) ) then
		if (table.Count(info.inventory) > 0 or info.cash > 0) then
			info.entity:SetAngles( Angle(0, 0, -90) );
			info.entity:SetData(info.inventory, info.cash);
			info.entity:SetPos( player:GetPos() + Vector(0, 0, 48) );
			info.entity:Spawn();
		else
			info.entity:Remove();
		end;
	else
		if (ragdoll:GetModel() != model) then
			ragdoll:SetModel(model);
		end;
		
		ragdoll.areBelongings = true;
		ragdoll.clothesData = {clothes, defaultModel, defaultSkin};
		ragdoll.inventory = info.inventory;
		ragdoll.cash = info.cash;
	end;
	
	nexus.player.SaveCharacter(player);
end;

-- A function to tie or untie a player.
function SCHEMA:TiePlayer(player, boolean, reset, government)
	if (boolean) then
		if (government) then
			player:SetSharedVar("sh_Tied", 2);
		else
			player:SetSharedVar("sh_Tied", 1);
		end;
	else
		player:SetSharedVar("sh_Tied", 0);
	end;
	
	if (boolean) then
		nexus.player.DropWeapons(player);
		
		NEXUS:PrintDebug(player:Name().." has been tied.");
		
		player:Flashlight(false);
		player:StripWeapons();
	elseif (!reset) then
		if ( player:Alive() and !player:IsRagdolled() ) then 
			nexus.player.LightSpawn(player, true, true);
		end;
		
		NEXUS:PrintDebug(player:Name().." has been untied.");
	end;
end;