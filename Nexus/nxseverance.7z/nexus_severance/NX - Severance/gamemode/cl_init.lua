--[[
Name: "cl_init.lua".
Product: "Severance".
--]]

NEXUS = GM;

DeriveGamemode("nexus");