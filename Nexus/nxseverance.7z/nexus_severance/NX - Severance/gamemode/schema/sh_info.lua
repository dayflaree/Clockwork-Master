--[[
Name: "sh_info.lua".
Product: "Severance".
--]]

SCHEMA.name = "Severance";
SCHEMA.author = "kuropixel";
SCHEMA.description = "A roleplaying game based on Left 4 Dead.";