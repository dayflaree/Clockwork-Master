--[[
Name: "sh_auto.lua".
Product: "Severance".
--]]

local MOUNT = MOUNT;

MOUNT.paperIDs = {};
NEXUS:IncludePrefixed("cl_hooks.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");