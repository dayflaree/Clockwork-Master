--[[
Name: "sh_info.lua".
Product: "Severance".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Writing";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds paper which players can write on.";