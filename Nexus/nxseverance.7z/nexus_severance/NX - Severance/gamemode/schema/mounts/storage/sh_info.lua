--[[
Name: "sh_info.lua".
Product: "Severance".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Storage";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds containers to allow players to store items.";