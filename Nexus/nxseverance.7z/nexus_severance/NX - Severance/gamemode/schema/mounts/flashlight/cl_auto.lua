--[[
Name: "cl_auto.lua".
Product: "Severance".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");