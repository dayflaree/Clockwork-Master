--[[
Name: "cl_auto.lua".
Product: "Severance".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");