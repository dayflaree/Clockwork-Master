--[[
Name: "sh_auto.lua".
Product: "Severance".
--]]

ENT.Base = "nx_basezombie";
ENT.Type = "ai";
ENT.Author = "kuropixel";
ENT.Spawnable = false;
ENT.PrintName = "Running Zombie";
ENT.Information = "A running zombie, watch out!";
ENT.AdminSpawnable = true;
ENT.AutomaticFrameAdvance = true;