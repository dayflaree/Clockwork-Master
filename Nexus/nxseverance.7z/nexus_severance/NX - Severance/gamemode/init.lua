--[[
Name: "init.lua".
Product: "Severance".
--]]

NEXUS = GM;

AddCSLuaFile("cl_init.lua");

DeriveGamemode("nexus");