--[[
Name: "sh_info.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Flashlight";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds flashlights to allow players to see in the dark.";