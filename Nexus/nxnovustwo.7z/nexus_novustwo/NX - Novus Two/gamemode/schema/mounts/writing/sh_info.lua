--[[
Name: "sh_info.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Writing";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds paper to the schema which players can write on.";