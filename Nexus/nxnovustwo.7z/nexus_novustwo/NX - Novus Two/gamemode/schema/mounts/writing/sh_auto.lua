--[[
Name: "sh_auto.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

MOUNT.paperIDs = {};
NEXUS:IncludePrefixed("cl_hooks.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");