--[[
Name: "sh_info.lua".
Product: "Novus Two".
--]]

SCHEMA.name = "Novus Two";
SCHEMA.author = "kuropixel";
SCHEMA.description = "The world's most catastrophic epidemic.";