--[[
Name: "sv_auto.lua".
Product: "HL2 RP".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");

--[[
	This is where we'd define our own config settings for our
	schema. You can get a full list of config functions and learn
	how they work at:
		nexus/gamemode/core/libraries/sh_config.lua
--]]

--[[
	This is where we change the defaults of some existing config options.
	You can get a full list of existing config options at:
		nexus/gamemode/core/config/sv_config.lua
--]]
nexus.config.Get("disable_sprays"):Set(false); -- We don't wanna disable sprays in this schema!

-- We can add some hints to our schema here.
nexus.hint.Add("Be Good", "Be good and behave otherwise kuropixel will come get ya!"); -- Add an interesting hint.

--[[
	The good thing about nexus schemas and mounts, is that any function
	created like MOUNT:Function or SCHEMA:Function is automatically hooked
	as a Garry's Mod hook (but only if that hook exists). For example:
		function SCHEMA:PlayerSpawn(player)
		end;
--]]

--[[
	Called when a player's weapons should be given.
	This is for people who know what they're doing, check out
	the nexus framework for a complete list of libraries and functions.
--]]
function SCHEMA:PlayerGiveWeapons(player)
	if (player:Team() == CLASS_CITIZEN) then
		player:Give("gmod_camera"); -- Give them a camera if they're a citizen!
	end;
end;

--[[
	A function to scale damage by hit group.
	This is for people who know what they're doing, check out
	the nexus framework for a complete list of libraries and functions.
--]]
function SCHEMA:PlayerScaleDamageByHitGroup(player, attacker, hitGroup, damageInfo, baseDamage)
	--[[
		Get the player's endurance. Find out what the arguments mean at:
			nexus/gamemode/core/libraries/sh_attributes.lua
	--]]
	
	local endurance = nexus.attributes.Fraction(player, ATB_ENDURANCE, 0.75, 0.75);
	
	-- Scale the damage based on their endurance attribute.
	damageInfo:ScaleDamage(1.5 - endurance);
end;