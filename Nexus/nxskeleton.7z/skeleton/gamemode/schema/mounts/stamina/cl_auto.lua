--[[
Name: "cl_auto.lua".
Product: "HL2 RP".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

-- Called when the bars are needed.
function MOUNT:GetBars(bars)
	local stamina = g_LocalPlayer:GetSharedVar("sh_Stamina");
	
	if (!self.stamina) then
		self.stamina = stamina;
	else
		self.stamina = math.Approach(self.stamina, stamina, 1);
	end;
	
	if (self.stamina < 75) then
		bars:Add("STAMINA", Color(100, 175, 100, 255), "", self.stamina, 100, self.stamina < 10);
	end;
end;

-- Called when the schema small bars should be drawn.
function MOUNT:SchemaDrawSmallBars(info)
	local stamina = g_LocalPlayer:GetSharedVar("sh_Stamina");
	
	if (!self.stamina) then
		self.stamina = stamina;
	else
		self.stamina = math.Approach(self.stamina, stamina, 1);
	end;
	
	if (self.stamina < 90) then
		info.y = NEXUS:DrawBar(info.x, info.y, info.width, info.height, Color(100, 175, 100, 255), "", self.stamina, 100) + 12;
	end;
end;