--[[
Name: "cl_auto.lua".
Product: "HL2 RP".
--]]


NEXUS:IncludePrefixed("sh_auto.lua");

--[[
	The good thing about nexus schemas and mounts, is that any function
	created like MOUNT:Function or SCHEMA:Function is automatically hooked
	as a Garry's Mod hook (but only if that hook exists). For example:
		function SCHEMA:PlayerSpawn(player)
		end;
--]]