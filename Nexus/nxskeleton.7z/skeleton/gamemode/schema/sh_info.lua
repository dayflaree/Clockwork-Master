--[[
Name: "sh_info.lua".
Product: "Skeleton".
--]]

SCHEMA.name = "Skeleton";
SCHEMA.author = "kuropixel";
SCHEMA.description = "A base schema made for learning purposes.";