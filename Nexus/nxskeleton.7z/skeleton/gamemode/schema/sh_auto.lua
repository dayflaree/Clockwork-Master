--[[
Name: "sh_auto.lua".
Product: "Skeleton".
--]]

-- Include our commands file (it isn't necessary to have a commands file).
NEXUS:IncludePrefixed("sh_coms.lua");

--[[
	We'd usually add some animations to NPC models here.
	As we're not using any for this script, I won't bother
	but check out the list of functions you can use at:
		nexus/gamemode/core/libraries/sh_animation.lua
		
	nexus.animation.AddCivilProtectionModel("models/eliteghostcp.mdl");
--]]

--[[
	Lets set some schema settings here to customise it a bit.
	You can find all the possible schema settings at:
		nexus/gamemode/core/libraries/sh_schema.lua
--]]
nexus.schema.SetOption( "default_date", {month = 12, year = 2012, day = 21} ); -- Set the default date.
nexus.schema.SetOption( "default_time", {minute = 0, hour = 0, day = 1} ); -- Set the default time.
nexus.schema.SetOption("name_cash", "Jellybabies"); -- Set the name of the cash in this schema.
nexus.schema.SetOption("model_cash", "models/props_lab/box01a.mdl"); -- Set the model of the cash in this schema.
nexus.schema.SetOption("format_cash", "%a %n"); -- Format cash, more complex. %a represents the amount and %n the name of the cash.
nexus.schema.SetOption("model_shipment", "models/items/item_item_crate.mdl"); -- Set the model of shipments in this schema.
nexus.schema.SetOption("intro_image", "skeleton/logo"); -- Set the path to the schema's intro image (not necessary).
--[[
	Format cash that is supposed to be on its own.
	%a represents the amount and %n the name of the cash.
-]]
nexus.schema.SetOption("format_singular_cash", "%a"); 

-- Hmm, let's change the background color of any custom UI we use in our schema.
nexus.schema.SetColor( "background", Color(0, 0, 0, 192) );

--[[
	Lets enable the quiz in our schema, and set some questions and answers.
	You can find all the possible quiz functions at:
		nexus/gamemode/core/libraries/sh_quiz.lua
--]]
nexus.quiz.SetEnabled(true);
nexus.quiz.AddQuestion("Do you like to roleplay?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("Is nexus a good framework?", 1, "Yes.", "No.");

--[[
	If you noticed, we set a few of our items to use M access. That meant that
	only players with M access can see that item in their business menu. Let's define
	our new M flag so the script can tell it exists.
--]]
nexus.flag.Add("M", "Merchanteer", "This flag gives players access to some basic items.");