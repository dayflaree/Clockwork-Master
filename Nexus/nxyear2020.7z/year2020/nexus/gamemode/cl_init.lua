--[[
Name: "cl_init.lua".
Product: "Nexus".
--]]

require("glon");

include("core/cl_auto.lua");