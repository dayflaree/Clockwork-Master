--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Save Cash";
MOUNT.author = "kurozael";
MOUNT.description = "Cash is saved and respawned when the map is loaded again.";