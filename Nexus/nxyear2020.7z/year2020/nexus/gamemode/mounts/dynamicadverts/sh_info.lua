--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Dynamic Adverts";
MOUNT.author = "kurozael";
MOUNT.description = "Allows dynamic images to be placed over the map.";