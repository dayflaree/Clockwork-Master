--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Emote Anims";
MOUNT.author = "kurozael";
MOUNT.description = "With this mount characters can perform a variety of different animations.";