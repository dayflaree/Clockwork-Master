--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Pickup Objects";
MOUNT.author = "kurozael";
MOUNT.description = "Players can pick up light objects with the hands weapon.";