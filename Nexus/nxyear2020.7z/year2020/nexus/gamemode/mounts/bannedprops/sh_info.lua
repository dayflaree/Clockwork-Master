--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Banned Props";
MOUNT.author = "kurozael";
MOUNT.description = "A basic mount which allows props to be banned.";