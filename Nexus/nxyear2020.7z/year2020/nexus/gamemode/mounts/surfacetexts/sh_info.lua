--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Surface Texts";
MOUNT.author = "kurozael";
MOUNT.description = "Allows three dimensional text to be placed on a surface.";