--[[
Name: "sh_auto.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.surfaceTexts = {};
NEXUS:IncludePrefixed("sh_coms.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");