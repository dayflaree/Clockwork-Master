--[[
Name: "cl_auto.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

nexus.config.SetOverwatch("remove_map_physics", "Whether or not physics entities should be removed when the map is loaded.");