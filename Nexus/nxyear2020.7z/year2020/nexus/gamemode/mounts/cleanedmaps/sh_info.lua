--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Cleaned Maps";
MOUNT.author = "kurozael";
MOUNT.description = "A static mount which removes a lot of commonly unwanted entities from maps.";