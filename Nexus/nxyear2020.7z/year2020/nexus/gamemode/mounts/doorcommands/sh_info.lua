--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Door Commands";
MOUNT.author = "kurozael";
MOUNT.description = "Provides a bunch of useful commands for interacting with doors.";