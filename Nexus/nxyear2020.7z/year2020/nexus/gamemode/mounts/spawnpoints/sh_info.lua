--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Spawn Points";
MOUNT.author = "kurozael";
MOUNT.description = "Spawnpoints can be set for each class, faction or by default.";