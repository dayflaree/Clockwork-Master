--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Weapon Select";
MOUNT.author = "kurozael";
MOUNT.description = "A new weapon selection interface for players.";