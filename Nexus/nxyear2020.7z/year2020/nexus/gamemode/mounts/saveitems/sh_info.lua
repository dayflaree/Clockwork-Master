--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Save Items";
MOUNT.author = "kurozael";
MOUNT.description = "Items are saved and respawned when the map is loaded again.";