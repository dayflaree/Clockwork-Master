--[[
Name: "cl_auto.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

nexus.config.SetOverwatch("typing_visible_only", "Whether or not players can only see other players typing if they can see the player.");