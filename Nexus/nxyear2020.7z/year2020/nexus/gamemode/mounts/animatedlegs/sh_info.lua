--[[
Name: "sh_info.lua".
Product: "Nexus".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Animated Legs";
MOUNT.author = "kurozael";
MOUNT.description = "Gives characters animated legs that they can physically see.";