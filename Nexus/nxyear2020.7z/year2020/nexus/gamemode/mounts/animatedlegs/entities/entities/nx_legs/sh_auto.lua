--[[
Name: "sh_auto.lua".
Product: "Nexus".
--]]

ENT.Type = "anim";
ENT.Author = "kurozael";
ENT.Animation = "run_all";
ENT.PrintName = "Legs";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.AutomaticFrameAdvance = true;