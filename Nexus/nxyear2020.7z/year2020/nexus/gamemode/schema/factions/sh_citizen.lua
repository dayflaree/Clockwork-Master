--[[
Name: "sh_citizen.lua".
Product: "Nexus".
--]]

FACTION_CITIZEN = nexus.faction.Register( {}, "Citizen" );