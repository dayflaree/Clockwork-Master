--[[
Name: "cl_auto.lua".
Product: "Nexus".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");