--[[
Name: "sh_auto.lua".
Product: "Nexus".
--]]