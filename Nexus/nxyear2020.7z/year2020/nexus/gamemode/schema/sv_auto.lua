--[[
Name: "sv_auto.lua".
Product: "Nexus".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");