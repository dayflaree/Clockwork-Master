--[[
Name: "init.lua".
Product: "Year 2020".
--]]

NEXUS = GM;

AddCSLuaFile("cl_init.lua");

DeriveGamemode("nexus");