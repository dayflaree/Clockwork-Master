--[[
Name: "sh_info.lua".
Product: "Year 2020".
--]]

SCHEMA.name = "Year 2020";
SCHEMA.author = "kurozael";
SCHEMA.description = "A roleplaying game based on Gordon Freeman's return.";