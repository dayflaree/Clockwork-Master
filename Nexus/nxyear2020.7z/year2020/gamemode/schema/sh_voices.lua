--[[
Name: "sh_voices.lua".
Product: "Year 2020".
--]]

-- A function to add a voice.
function SCHEMA:AddVoice(command, phrase, sound, female, menu)
	self.voices[#SCHEMA.voices + 1] = {
		command = command,
		phrase = phrase,
		female = female,
		sound = sound,
		menu = menu
	};
end;

SCHEMA.voices = {};
SCHEMA:AddVoice("Sweeping", "Sweeping for suspect.", "npc/metropolice/hiding02.wav");
SCHEMA:AddVoice("Isolate", "Isolate!", "npc/metropolice/hiding05.wav");
SCHEMA:AddVoice("You Can Go", "Alright, you can go.", "npc/metropolice/vo/allrightyoucango.wav");
SCHEMA:AddVoice("Need Assistance", "Eleven-ninety-nine, officer needs assistance!", "npc/metropolice/vo/11-99officerneedsassistance.wav");
SCHEMA:AddVoice("Administer", "Administer.", "npc/metropolice/vo/administer.wav");
SCHEMA:AddVoice("Affirmative", "Affirmative.", "npc/metropolice/vo/affirmative.wav");
SCHEMA:AddVoice("All Units Move In", "All units move in!", "npc/metropolice/vo/allunitsmovein.wav");
SCHEMA:AddVoice("Amputate", "Amputate.", "npc/metropolice/vo/amputate.wav");
SCHEMA:AddVoice("Anti-Citizen", "Anti-citizen.", "npc/metropolice/vo/anticitizen.wav");
SCHEMA:AddVoice("Citizen", "Citizen.", "npc/metropolice/vo/citizen.wav");
SCHEMA:AddVoice("Copy", "Copy.", "npc/metropolice/vo/copy.wav");
SCHEMA:AddVoice("Cover Me", "Cover me, I'm going in!", "npc/metropolice/vo/covermegoingin.wav");
SCHEMA:AddVoice("Assist Trespass", "Assist for a criminal trespass!", "npc/metropolice/vo/criminaltrespass63.wav");
SCHEMA:AddVoice("Destroy Cover", "Destroy that cover!", "npc/metropolice/vo/destroythatcover.wav");
SCHEMA:AddVoice("Don't Move", "Don't move!", "npc/metropolice/vo/dontmove.wav");
SCHEMA:AddVoice("Final Verdict", "Final verdict administered.", "npc/metropolice/vo/finalverdictadministered.wav");
SCHEMA:AddVoice("Final Warning", "Final warning!", "npc/metropolice/vo/finalwarning.wav");
SCHEMA:AddVoice("First Warning", "First warning, move away!", "npc/metropolice/vo/firstwarningmove.wav");
SCHEMA:AddVoice("Get Down", "Get down!", "npc/metropolice/vo/getdown.wav");
SCHEMA:AddVoice("Get Out", "Get out of here!", "npc/metropolice/vo/getoutofhere.wav");
SCHEMA:AddVoice("Suspect One", "I got suspect one here.", "npc/metropolice/vo/gotsuspect1here.wav");
SCHEMA:AddVoice("Help", "Help!", "npc/metropolice/vo/help.wav");
SCHEMA:AddVoice("Running", "He's running!", "npc/metropolice/vo/hesrunning.wav");
SCHEMA:AddVoice("Hold It", "Hold it right there!", "npc/metropolice/vo/holditrightthere.wav");
SCHEMA:AddVoice("Move Along Repeat", "I said move along.", "npc/metropolice/vo/isaidmovealong.wav");
SCHEMA:AddVoice("Malcompliance", "Issuing malcompliance citation.", "npc/metropolice/vo/issuingmalcompliantcitation.wav");
SCHEMA:AddVoice("Keep Moving", "Keep moving!", "npc/metropolice/vo/keepmoving.wav");
SCHEMA:AddVoice("Lock Position", "All units, lock your position!", "npc/metropolice/vo/lockyourposition.wav");
SCHEMA:AddVoice("Trouble", "Lookin' for trouble?", "npc/metropolice/vo/lookingfortrouble.wav");
SCHEMA:AddVoice("Look Out", "Look out!", "npc/metropolice/vo/lookout.wav");
SCHEMA:AddVoice("Minor Hits", "Minor hits, continuing prosecution.", "npc/metropolice/vo/minorhitscontinuing.wav");
SCHEMA:AddVoice("Move", "Move!", "npc/metropolice/vo/move.wav");
SCHEMA:AddVoice("Move Along", "Move along!", "npc/metropolice/vo/movealong3.wav");
SCHEMA:AddVoice("Move Back", "Move back, right now!", "npc/metropolice/vo/movebackrightnow.wav");
SCHEMA:AddVoice("Move It", "Move it!", "npc/metropolice/vo/moveit2.wav");
SCHEMA:AddVoice("Hardpoint", "Moving to hardpoint.", "npc/metropolice/vo/movingtohardpoint.wav");
SCHEMA:AddVoice("Officer Help", "Officer needs help!", "npc/metropolice/vo/officerneedshelp.wav");
SCHEMA:AddVoice("Privacy", "Possible level three civil privacy violator here!", "npc/metropolice/vo/possiblelevel3civilprivacyviolator.wav");
SCHEMA:AddVoice("Judgement", "Suspect prepare to receive civil judgement!", "npc/metropolice/vo/prepareforjudgement.wav");
SCHEMA:AddVoice("Priority Two", "I have a priority two anti-citizen here!", "npc/metropolice/vo/priority2anticitizenhere.wav");
SCHEMA:AddVoice("Prosecute", "Prosecute!", "npc/metropolice/vo/prosecute.wav");
SCHEMA:AddVoice("Amputate Ready", "Ready to amputate!", "npc/metropolice/vo/readytoamputate.wav");
SCHEMA:AddVoice("Rodger That", "Rodger that!", "npc/metropolice/vo/rodgerthat.wav");
SCHEMA:AddVoice("Search", "Search!", "npc/metropolice/vo/search.wav");
SCHEMA:AddVoice("Shit", "Shit!", "npc/metropolice/vo/shit.wav");
SCHEMA:AddVoice("Sentence Delivered", "Sentence delivered.", "npc/metropolice/vo/sentencedelivered.wav");
SCHEMA:AddVoice("Sterilize", "Sterilize!", "npc/metropolice/vo/sterilize.wav");
SCHEMA:AddVoice("Take Cover", "Take cover!", "npc/metropolice/vo/takecover.wav");
SCHEMA:AddVoice("Restrict", "Restrict!", "npc/metropolice/vo/restrict.wav");
SCHEMA:AddVoice("Restricted", "Restricted block.", "npc/metropolice/vo/restrictedblock.wav");
SCHEMA:AddVoice("Second Warning", "This is your second warning!", "npc/metropolice/vo/thisisyoursecondwarning.wav");
SCHEMA:AddVoice("Verdict", "You want a non-compliance verdict?", "npc/metropolice/vo/youwantamalcomplianceverdict.wav");
SCHEMA:AddVoice("Backup", "Backup!", "npc/metropolice/vo/backup.wav");
SCHEMA:AddVoice("Apply", "Apply.", "npc/metropolice/vo/apply.wav");
SCHEMA:AddVoice("Restriction", "Terminal restriction zone.", "npc/metropolice/vo/terminalrestrictionzone.wav");
SCHEMA:AddVoice("Complete", "Protection complete.", "npc/metropolice/vo/protectioncomplete.wav");
SCHEMA:AddVoice("Location Unknown", "Suspect location unknown.", "npc/metropolice/vo/suspectlocationunknown.wav");
SCHEMA:AddVoice("Can 1", "Pick up that can.", "npc/metropolice/vo/pickupthecan1.wav");
SCHEMA:AddVoice("Can 2", "Pick... up... the can.", "npc/metropolice/vo/pickupthecan2.wav");
SCHEMA:AddVoice("Wrap It", "That's it, wrap it up.", "npc/combine_soldier/vo/thatsitwrapitup.wav");
SCHEMA:AddVoice("Can 3", "I said pickup the can!", "npc/metropolice/vo/pickupthecan3.wav");
SCHEMA:AddVoice("Can 4", "Now, put it in the trash can.", "npc/metropolice/vo/putitinthetrash1.wav");
SCHEMA:AddVoice("Can 5", "I said put it in the trash can!", "npc/metropolice/vo/putitinthetrash2.wav");
SCHEMA:AddVoice("Now Get Out", "Now get out of here!", "npc/metropolice/vo/nowgetoutofhere.wav");
SCHEMA:AddVoice("Haha", "Haha.", "npc/metropolice/vo/chuckle.wav");
SCHEMA:AddVoice("X-Ray", "X-Ray!", "npc/metropolice/vo/xray.wav");
SCHEMA:AddVoice("Patrol", "Patrol!", "npc/metropolice/vo/patrol.wav");
SCHEMA:AddVoice("Serve", "Serve.", "npc/metropolice/vo/serve.wav");
SCHEMA:AddVoice("Knocked Over", "You knocked it over, pick it up!", "npc/metropolice/vo/youknockeditover.wav");
SCHEMA:AddVoice("Watch It", "Watch it!", "npc/metropolice/vo/watchit.wav");
SCHEMA:AddVoice("Restricted Canals", "Suspect is using restricted canals at...", "npc/metropolice/vo/suspectusingrestrictedcanals.wav");
SCHEMA:AddVoice("505", "Subject is five-oh-five!", "npc/metropolice/vo/subjectis505.wav");
SCHEMA:AddVoice("404", "Possible four-zero-oh here!", "npc/metropolice/vo/possible404here.wav");
SCHEMA:AddVoice("Vacate", "Vacate citizen!", "npc/metropolice/vo/vacatecitizen.wav");
SCHEMA:AddVoice("Escapee", "Priority two escapee.", "npc/combine_soldier/vo/prioritytwoescapee.wav");
SCHEMA:AddVoice("Objective", "Priority one objective.", "npc/combine_soldier/vo/priority1objective.wav");
SCHEMA:AddVoice("Payback", "Payback.", "npc/combine_soldier/vo/payback.wav");
SCHEMA:AddVoice("Got Him Now", "Affirmative, we got him now.", "npc/combine_soldier/vo/affirmativewegothimnow.wav");
SCHEMA:AddVoice("Antiseptic", "Antiseptic.", "npc/combine_soldier/vo/antiseptic.wav");
SCHEMA:AddVoice("Cleaned", "Cleaned.", "npc/combine_soldier/vo/cleaned.wav");
SCHEMA:AddVoice("Engaged Cleanup", "Engaged in cleanup.", "npc/combine_soldier/vo/engagedincleanup.wav");
SCHEMA:AddVoice("Engaging", "Engaging.", "npc/combine_soldier/vo/engaging.wav");
SCHEMA:AddVoice("Full Response", "Executing full response.", "npc/combine_soldier/vo/executingfullresponse.wav");
SCHEMA:AddVoice("Heavy Resistance", "Overwatch advise, we have heavy resistance.", "npc/combine_soldier/vo/heavyresistance.wav");
SCHEMA:AddVoice("Inbound", "Inbound.", "npc/combine_soldier/vo/inbound.wav");
SCHEMA:AddVoice("Lost Contact", "Lost contact!", "npc/combine_soldier/vo/lostcontact.wav");
SCHEMA:AddVoice("Move In", "Move in!", "npc/combine_soldier/vo/movein.wav");
SCHEMA:AddVoice("Harden Position", "Harden that position!", "npc/combine_soldier/vo/hardenthatposition.wav");
SCHEMA:AddVoice("Go Sharp", "Go sharp, go sharp!", "npc/combine_soldier/vo/gosharpgosharp.wav");
SCHEMA:AddVoice("Delivered", "Delivered.", "npc/combine_soldier/vo/delivered.wav");
SCHEMA:AddVoice("Necrotics Inbound", "Necrotics, inbound!", "npc/combine_soldier/vo/necroticsinbound.wav");
SCHEMA:AddVoice("Necrotics", "Necrotics.", "npc/combine_soldier/vo/necrotics.wav");
SCHEMA:AddVoice("Outbreak", "Outbreak!", "npc/combine_soldier/vo/outbreak.wav");
SCHEMA:AddVoice("Copy That", "Copy that.", "npc/combine_soldier/vo/copythat.wav");
SCHEMA:AddVoice("Outbreak Status", "Outbreak status is code.", "npc/combine_soldier/vo/outbreakstatusiscode.wav");
SCHEMA:AddVoice("Overwatch", "Overwatch!", "npc/combine_soldier/vo/overwatch.wav");
SCHEMA:AddVoice("Preserve", "Preserve!", "npc/metropolice/vo/preserve.wav");
SCHEMA:AddVoice("Pressure", "Pressure!", "npc/metropolice/vo/pressure.wav");
SCHEMA:AddVoice("Phantom", "Phantom!", "npc/combine_soldier/vo/phantom.wav");
SCHEMA:AddVoice("Stinger", "Stinger!", "npc/combine_soldier/vo/stinger.wav");
SCHEMA:AddVoice("Shadow", "Shadow!", "npc/combine_soldier/vo/shadow.wav");
SCHEMA:AddVoice("Savage", "Savage!", "npc/combine_soldier/vo/savage.wav");
SCHEMA:AddVoice("Reaper", "Reaper!", "npc/combine_soldier/vo/reaper.wav");
SCHEMA:AddVoice("Victor", "Victor!", "npc/metropolice/vo/victor.wav");
SCHEMA:AddVoice("Sector", "Sector!", "npc/metropolice/vo/sector.wav");
SCHEMA:AddVoice("Inject", "Inject!", "npc/metropolice/vo/inject.wav");
SCHEMA:AddVoice("Dagger", "Dagger!", "npc/combine_soldier/vo/dagger.wav");
SCHEMA:AddVoice("Blade", "Blade!", "npc/combine_soldier/vo/blade.wav");
SCHEMA:AddVoice("Razor", "Razor!", "npc/combine_soldier/vo/razor.wav");
SCHEMA:AddVoice("Nomad", "Nomad!", "npc/combine_soldier/vo/nomad.wav");
SCHEMA:AddVoice("Judge", "Judge!", "npc/combine_soldier/vo/judge.wav");
SCHEMA:AddVoice("Ghost", "Ghost!", "npc/combine_soldier/vo/ghost.wav");
SCHEMA:AddVoice("Sword", "Sword!", "npc/combine_soldier/vo/sword.wav");
SCHEMA:AddVoice("Union", "Union!", "npc/metropolice/vo/union.wav");
SCHEMA:AddVoice("Helix", "Helix!", "npc/combine_soldier/vo/helix.wav");
SCHEMA:AddVoice("Storm", "Storm!", "npc/combine_soldier/vo/storm.wav");
SCHEMA:AddVoice("Spear", "Spear!", "npc/combine_soldier/vo/spear.wav");
SCHEMA:AddVoice("Vamp", "Vamp!", "npc/combine_soldier/vo/vamp.wav");
SCHEMA:AddVoice("Nova", "Nova!", "npc/combine_soldier/vo/nova.wav");
SCHEMA:AddVoice("Mace", "Mace!", "npc/combine_soldier/vo/mace.wav");
SCHEMA:AddVoice("Grid", "Grid!", "npc/combine_soldier/vo/grid.wav");
SCHEMA:AddVoice("Kilo", "Kilo!", "npc/combine_soldier/vo/kilo.wav");
SCHEMA:AddVoice("Echo", "Echo!", "npc/combine_soldier/vo/echo.wav");
SCHEMA:AddVoice("Dash", "Dash!", "npc/combine_soldier/vo/dash.wav");
SCHEMA:AddVoice("Apex", "Apex!", "npc/combine_soldier/vo/apex.wav");
SCHEMA:AddVoice("Jury", "Jury!", "npc/metropolice/vo/jury.wav");
SCHEMA:AddVoice("King", "King!", "npc/metropolice/vo/king.wav");
SCHEMA:AddVoice("Lock", "Lock!", "npc/metropolice/vo/lock.wav");
SCHEMA:AddVoice("Vice", "Vice!", "npc/metropolice/vo/vice.wav");
SCHEMA:AddVoice("Zero", "Zero!", "npc/metropolice/vo/zero.wav");
SCHEMA:AddVoice("Zone", "Zone!", "npc/metropolice/vo/zone.wav");