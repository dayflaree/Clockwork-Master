--[[
Name: "cl_hooks.lua".
Product: "Year 2020".
--]]


-- Called when Nexus has initialized.
function SCHEMA:NexusInitialized()
	for k, v in pairs( nexus.item.GetAll() ) do
		if (!v.isBaseItem and !v.isRareItem) then
			v.business = true;
			v.access = "y";
			v.batch = 1;
		end;
	end;
end;

-- Called when the menu's items should be destroyed.
function SCHEMA:MenuItemsDestroy(menuItems)
	menuItems:Destroy( nexus.schema.GetOption("name_attributes") );
	
	if ( !nexus.player.HasFlags(g_LocalPlayer, "y") ) then
		menuItems:Destroy( nexus.schema.GetOption("name_business") );
	end;
end;

-- Called when the Nexus date and time has been drawn.
function SCHEMA:NexusDateTimeDrawn(info)
	local colorWhite = nexus.schema.GetColor("white");
	local curTime = CurTime();
	
	if ( self:PlayerIsCombine(g_LocalPlayer) ) then
		if (self.combineDisplayLines) then
			local height = draw.GetFontHeight("BudgetLabel");
			
			for k, v in ipairs(self.combineDisplayLines) do
				if ( curTime >= v[2] ) then
					table.remove(self.combineDisplayLines, k);
				else
					draw.SimpleText(string.sub( v[1], 1, v[3] ), "BudgetLabel", info.x, info.y, v[4] or colorWhite);
					
					if ( v[3] < string.len( v[1] ) ) then
						v[3] = v[3] + 1;
					end;
					
					info.y = info.y + height;
				end;
			end;
		end;
	end;
end;

-- Called when the local player is created.
function SCHEMA:LocalPlayerCreated()
	g_LocalPlayer:SetNetworkedVarProxy("sh_Clothes", function(entity, name, oldValue, newValue)
		if (oldValue != newValue) then
			nexus.inventory.Rebuild();
		end;
	end);
end;

-- Called when an entity's menu options are needed.
function SCHEMA:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "prop_ragdoll") then
		local player = nexus.entity.GetPlayer(entity);
		
		if ( !player or !player:Alive() ) then
			options["Loot"] = "nx_corpseLoot";
		end;
	elseif (entity:GetClass() == "nx_breach") then
		options["Charge"] = "nx_breachCharge";
	elseif (entity:GetClass() == "nx_radio") then
		if ( !entity:GetSharedVar("sh_Off") ) then
			options["Turn Off"] = "nx_radioToggle";
		else
			options["Turn On"] = "nx_radioToggle";
		end;
	end;
end;

-- Called when an entity's target ID HUD should be painted.
function SCHEMA:HUDPaintEntityTargetID(entity, info)
	local colorTargetID = nexus.schema.GetColor("target_id");
	local colorWhite = nexus.schema.GetColor("white");
	
	if (entity:GetClass() == "prop_physics") then
		local physDesc = entity:GetNetworkedString("sh_PhysDesc");
		
		if (physDesc != "") then
			info.y = NEXUS:DrawInfo(physDesc, info.x, info.y, colorWhite, info.alpha);
		end;
	elseif ( entity:IsNPC() ) then
		local name = entity:GetNetworkedString("nx_Name");
		local title = entity:GetNetworkedString("nx_Title");
		
		if (name != "" and title != "") then
			info.y = NEXUS:DrawInfo(name, info.x, info.y, Color(255, 255, 100, 255), info.alpha);
			info.y = NEXUS:DrawInfo(title, info.x, info.y, Color(255, 255, 255, 255), info.alpha);
		end;
	end;
end;

-- Called when a Derma skin should be forced.
function SCHEMA:ForceDermaSkin()
	return "blackskin";
end;

-- Called when a text entry has gotten focus.
function SCHEMA:OnTextEntryGetFocus(panel)
	self.textEntryFocused = panel;
end;

-- Called when a text entry has lost focus.
function SCHEMA:OnTextEntryLoseFocus(panel)
	self.textEntryFocused = nil;
end;

-- Called when screen space effects should be rendered.
function SCHEMA:RenderScreenspaceEffects()
	if ( !NEXUS:IsScreenFadedBlack() ) then
		local curTime = CurTime();
		
		if ( self:PlayerIsCombine(g_LocalPlayer) ) then
			render.UpdateScreenEffectTexture();
			
			self.combineOverlay:SetMaterialFloat("$refractamount", 0.3);
			self.combineOverlay:SetMaterialFloat("$envmaptint", 0);
			self.combineOverlay:SetMaterialFloat("$envmap", 0);
			self.combineOverlay:SetMaterialFloat("$alpha", 0.8);
			self.combineOverlay:SetMaterialInt("$ignorez", 1);
			
			render.SetMaterial(self.combineOverlay);
			render.DrawScreenQuad();
		end;
	end;
end;

-- Called when the cinematic intro info is needed.
function SCHEMA:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self.author..".",
		title = nexus.config.Get("intro_text_big"):Get(),
		text = nexus.config.Get("intro_text_small"):Get()
	};
end;

-- Called when a player's scoreboard class is needed.
function SCHEMA:GetPlayerScoreboardClass(player)
	local customClass = player:GetSharedVar("sh_CustomClass");
	
	if (customClass != "") then
		return customClass;
	end;
end;

-- Called when the local player's character screen faction is needed.
function SCHEMA:GetPlayerCharacterScreenFaction(character)
	if (character.customClass and character.customClass != "") then
		return character.customClass;
	end;
end;

-- Called when the local player attempts to zoom.
function SCHEMA:PlayerCanZoom()
	if ( !self:PlayerIsCombine(g_LocalPlayer) ) then
		return false;
	end;
end;

-- Called when a player's scoreboard options are needed.
function SCHEMA:GetPlayerScoreboardOptions(player, options, menu)
	if ( nexus.command.Get("setcustomclass") ) then
		if ( nexus.player.HasFlags(g_LocalPlayer, nexus.command.Get("setcustomclass").access) ) then
			options["Custom Class"] = {};
			options["Custom Class"]["Set"] = function()
				Derma_StringRequest(player:Name(), "What would you like to set their custom class to?", player:GetSharedVar("sh_CustomClass"), function(text)
					NEXUS:RunCommand("CharSetCustomClass", player:Name(), text);
				end);
			end;
			
			if (player:GetSharedVar("sh_CustomClass") != "") then
				options["Custom Class"]["Take"] = function()
					NEXUS:RunCommand( "CharTakeCustomClass", player:Name() );
				end;
			end;
		end;
	end;
	
	if ( nexus.command.Get("CharPermaKill") ) then
		if ( nexus.player.HasFlags(g_LocalPlayer, nexus.command.Get("CharPermaKill").access) ) then
			options["Perma-Kill"] = function()
				RunConsoleCommand( "nx", "CharPermaKill", player:Name() );
			end;
		end;
	end;
end;

-- Called when a player's footstep sound should be played.
function SCHEMA:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	return true;
end;

-- Called when the target's status should be drawn.
function SCHEMA:DrawTargetPlayerStatus(target, alpha, x, y)
	local informationColor = nexus.schema.GetColor("information");
	local thirdPerson = "him";
	local mainStatus = nil;
	local gender = "He";
	local action = nexus.player.GetAction(target);
	
	if (nexus.player.GetGender(target) == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if ( target:Alive() ) then
		if (action == "die") then
			mainStatus = gender.." is in critical condition.";
		end;
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." is clearly unconscious.";
		end;
		
		if (mainStatus) then
			y = NEXUS:DrawInfo(mainStatus, x, y, informationColor, alpha);
		end;
		
		return y;
	end;
end;

-- Called to check if a player does recognise another player.
function SCHEMA:PlayerDoesRecognisePlayer(player, status, simple, default)
	if ( self:PlayerIsCombine(player) ) then
		return true;
	end;
end;

local RADIO_TIMERS = {};
local OPENING_RADIO = {
	"vo/canals/radio_doyoucopy8.wav",
	"vo/canals/radio_thisis8.wav",
	"vo/canals/radio_comein12.wav",
	"vo/canals/premassacre.wav"
};

-- Called each tick.
function SCHEMA:Tick()
	if ( IsValid(g_LocalPlayer) ) then
		if ( NEXUS:IsCharacterScreenOpen(true) ) then
			if (!self.musicSound) then
				self.musicSound = CreateSound(g_LocalPlayer, "music/radio1.mp3");
				self.musicSound:PlayEx(1, 100);
			end;
			
			if (!self.voiceOver) then
				local timerDelay = 0;
				
				for k, v in ipairs(OPENING_RADIO) do
					RADIO_TIMERS[#RADIO_TIMERS + 1] = "Radio: "..k;
					
					NEXUS:CreateTimer(RADIO_TIMERS[#RADIO_TIMERS], timerDelay, 1, function()
						if ( NEXUS:IsCharacterScreenOpen(true) ) then
							self.voiceOver = CreateSound(g_LocalPlayer, v);
							self.voiceOver:PlayEx(1, 100);
						end;
					end);
					
					timerDelay = timerDelay + SoundDuration(v) + 1;
				end;
			end;
		else
			if ( self.musicSound and self.musicSound:IsPlaying() ) then
				self.musicSound:FadeOut(8);
			end;
			
			if ( self.voiceOver and self.voiceOver:IsPlaying() ) then
				self.voiceOver:FadeOut(8);
			end;
			
			for k, v in ipairs(RADIO_TIMERS) do
				NEXUS:DestroyTimer(v);
			end;
		end;
		
		if ( self:PlayerIsCombine(g_LocalPlayer) ) then
			local curTime = CurTime();
			local health = g_LocalPlayer:Health();
			local armor = g_LocalPlayer:Armor();

			if (!self.nextHealthWarning or curTime >= self.nextHealthWarning) then
				if (self.lastHealth) then
					if (health < self.lastHealth) then
						if (health == 0) then
							self:AddCombineDisplayLine( "ERROR! Shutting down...", Color(255, 0, 0, 255) );
						else
							self:AddCombineDisplayLine( "WARNING! Physical bodily trauma detected...", Color(255, 0, 0, 255) );
						end;
						
						self.nextHealthWarning = curTime + 2;
					elseif (health > self.lastHealth) then
						if (health == 100) then
							self:AddCombineDisplayLine( "Physical body systems restored...", Color(0, 255, 0, 255) );
						else
							self:AddCombineDisplayLine( "Physical body systems regenerating...", Color(0, 0, 255, 255) );
						end;
						
						self.nextHealthWarning = curTime + 2;
					end;
				end;
				
				if (self.lastArmor) then
					if (armor < self.lastArmor) then
						if (armor == 0) then
							self:AddCombineDisplayLine( "WARNING! External protection exhausted...", Color(255, 0, 0, 255) );
						else
							self:AddCombineDisplayLine( "WARNING! External protection damaged...", Color(255, 0, 0, 255) );
						end;
						
						self.nextHealthWarning = curTime + 2;
					elseif (armor > self.lastArmor) then
						if (armor == 100) then
							self:AddCombineDisplayLine( "External protection systems restored...", Color(0, 255, 0, 255) );
						else
							self:AddCombineDisplayLine( "External protection systems regenerating...", Color(0, 0, 255, 255) );
						end;
						
						self.nextHealthWarning = curTime + 2;
					end;
				end;
			end;
			
			if (!self.nextRandomLine or curTime >= self.nextRandomLine) then
				local text = self.randomDisplayLines[ math.random(1, #self.randomDisplayLines) ];
				
				if (text and self.lastRandomDisplayLine != text) then
					self:AddCombineDisplayLine(text);
					
					self.lastRandomDisplayLine = text;
				end;
				
				self.nextRandomLine = curTime + 3;
			end;
			
			self.lastHealth = health;
			self.lastArmor = armor;
		end;
	end;
end;

-- Called just before the weapon selection info is drawn.
function SCHEMA:PreDrawWeaponSelectionInfo(info)
	local dirtyTexture = self.dirtyTextureRebel;
	
	if ( self:PlayerIsCombine(g_LocalPlayer) ) then
		dirtyTexture = self.dirtyTextureCP;
	end;
	
	surface.SetDrawColor( 255, 255, 255, math.min(200, info.alpha) );
	surface.SetTexture(dirtyTexture);
	surface.DrawTexturedRect(info.x, info.y, info.width, info.height);
	
	info.drawBackground = false;
end;

-- Called just before the local player's information is drawn.
function SCHEMA:PreDrawPlayerInfo(boxInfo, information, subInformation)
	local dirtyTexture = self.dirtyTextureRebel;
	
	if ( self:PlayerIsCombine(g_LocalPlayer) ) then
		dirtyTexture = self.dirtyTextureCP;
	end;
	
	surface.SetDrawColor(255, 255, 255, 100);
	surface.SetTexture(dirtyTexture);
	surface.DrawTexturedRect(boxInfo.x, boxInfo.y, boxInfo.width, boxInfo.height);
	
	boxInfo.drawBackground = false;
	boxInfo.drawGradient = false;
end;

-- Called when the foreground HUD should be painted.
function SCHEMA:HUDPaintForeground()
	local curTime = CurTime();
	local scrW = ScrW();
	local scrH = ScrH();
	
	if ( g_LocalPlayer:Alive() ) then
		if (self.stunEffects) then
			for k, v in pairs(self.stunEffects) do
				local alpha = math.Clamp( ( 255 / v[2] ) * (v[1] - curTime), 0, 255 );
				
				if (alpha != 0) then
					draw.RoundedBox( 0, 0, 0, scrW, scrH, Color(255, 0, 0, alpha) );
				else
					table.remove(self.stunEffects, k);
				end;
			end;
		end;
	end;
end;

-- Called to get the screen text info.
function SCHEMA:GetScreenTextInfo()
	local blackFadeAlpha = NEXUS:GetBlackFadeAlpha();
	
	if ( g_LocalPlayer:GetSharedVar("sh_PermaKilled") ) then
		return {
			alpha = blackFadeAlpha,
			title = "THIS CHARACTER IS PERMANENTLY KILLED",
			text = "Go to the character menu to make a new one."
		};
	end;
end;

-- Called when the chat box info should be adjusted.
function SCHEMA:ChatBoxAdjustInfo(info)
	if ( IsValid(info.speaker) ) then
		if (info.data.anon) then
			info.name = "Somebody";
		end;
	end;
end;