--[[
Name: "sh_steroids.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.name = "Steroids";
ITEM.model = "models/props_junk/garbage_metalcan002a.mdl";
ITEM.weight = 0.2;
ITEM.useText = "Swallow";
ITEM.category = "Medical";
ITEM.description = "Low caliber steroids produced by Civil Protection.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData("stamina", 100);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

nexus.item.Register(ITEM);