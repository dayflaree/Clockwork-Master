--[[
Name: "sh_auto.lua".
Product: "Year 2020".
--]]

local MOUNT = MOUNT;

nexus.player.RegisterSharedVar("sh_Stamina", NWTYPE_NUMBER, true);

NEXUS:IncludePrefixed("sh_coms.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");