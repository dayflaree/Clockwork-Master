--[[
Name: "sh_info.lua".
Product: "Year 2020".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Stamina";
MOUNT.author = "kurozael";
MOUNT.description = "Adds stamina to limit player movement.";