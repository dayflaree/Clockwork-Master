--[[
Name: "cl_auto.lua".
Product: "Year 2020".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");