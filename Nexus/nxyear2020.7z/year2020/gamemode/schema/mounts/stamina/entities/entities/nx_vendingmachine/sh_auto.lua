--[[
Name: "sh_auto.lua".
Product: "Year 2020".
--]]

ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "kurozael";
ENT.PrintName = "Vending Machine";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.UsableInVehicle = true;
ENT.PhysgunDisabled = true;

-- A function to get the entity's stock.
function ENT:GetStock()
	return self:GetSharedVar("sh_Stock");
end;

-- Called when the entity initializes.
function ENT:SharedInitialize()
	nexus.entity.RegisterSharedVars( self, {
		{"sh_Action", NWTYPE_BOOL},
		{"sh_Stock", NWTYPE_NUMBER},
		{"sh_Flash", NWTYPE_NUMBER}
	} );
end;