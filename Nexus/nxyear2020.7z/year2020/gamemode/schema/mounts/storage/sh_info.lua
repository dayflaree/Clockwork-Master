--[[
Name: "sh_info.lua".
Product: "Year 2020".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Storage";
MOUNT.author = "kurozael";
MOUNT.description = "Adds containers where players can store items.";