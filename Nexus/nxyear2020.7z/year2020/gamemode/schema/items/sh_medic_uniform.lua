--[[
Name: "sh_medic_uniform.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.name = "Medic Uniform";
ITEM.group = "group03m";
ITEM.weight = 3;
ITEM.access = "m";
ITEM.business = true;
ITEM.protection = 0.1;
ITEM.description = "A resistance uniform with a medical insignia on the sleeve.";

nexus.item.Register(ITEM);