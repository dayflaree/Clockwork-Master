--[[
Name: "sh_ammo_xbowbolt.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "Crossbow Bolts";
ITEM.model = "models/items/crossbowrounds.mdl";
ITEM.weight = 2;
ITEM.uniqueID = "ammo_xbowbolt";
ITEM.ammoClass = "xbowbolt";
ITEM.ammoAmount = 4;
ITEM.description = "A set of iron bolts, the coating is rusting away.";

nexus.item.Register(ITEM);