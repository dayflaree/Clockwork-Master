--[[
Name: "sh_ammo_buckshot.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "Shotgun Shells";
ITEM.model = "models/items/boxbuckshot.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_buckshot";
ITEM.ammoClass = "buckshot";
ITEM.ammoAmount = 16;
ITEM.description = "A red box filled with shells.";

nexus.item.Register(ITEM);