
--[[
Name: "sh_ammo_smg1_grenade.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "MP7 Grenade";
ITEM.model = "models/items/ar2_grenade.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_smg1_grenade";
ITEM.ammoClass = "smg1_grenade";
ITEM.ammoAmount = 1;
ITEM.description = "A large bullet shaped item, you'll figure it out.";

nexus.item.Register(ITEM);