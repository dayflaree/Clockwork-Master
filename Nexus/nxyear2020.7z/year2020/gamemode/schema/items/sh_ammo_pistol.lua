--[[
Name: "sh_ammo_pistol.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "9mm Pistol Bullets";
ITEM.model = "models/items/boxsrounds.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_pistol";
ITEM.ammoClass = "pistol";
ITEM.ammoAmount = 20;
ITEM.description = "A container filled with bullets and 9mm printed on the side.";

nexus.item.Register(ITEM);