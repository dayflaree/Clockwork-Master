--[[
Name: "sh_ammo_357.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = ".357 Magnum Bullets";
ITEM.model = "models/items/357ammo.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_357";
ITEM.ammoClass = "357";
ITEM.ammoAmount = 21;
ITEM.description = "A small box filled with bullets and Magnum printed on the side.";

nexus.item.Register(ITEM);