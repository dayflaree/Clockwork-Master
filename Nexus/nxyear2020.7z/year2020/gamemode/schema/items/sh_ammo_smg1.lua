--[[
Name: "sh_ammo_smg1.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "SMG Bullets";
ITEM.model = "models/items/boxmrounds.mdl";
ITEM.weight = 2;
ITEM.uniqueID = "ammo_smg1";
ITEM.ammoClass = "smg1";
ITEM.ammoAmount = 30;
ITEM.description = "A heavy container filled with a lot of bullets.";

nexus.item.Register(ITEM);