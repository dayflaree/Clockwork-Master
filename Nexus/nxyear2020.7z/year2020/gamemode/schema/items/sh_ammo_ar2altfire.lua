--[[
Name: "sh_ammo_ar2altfire.lua".
Product: "Year 2020".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "Pulse-Rifle Orb";
ITEM.model = "models/items/combine_rifle_ammo01.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_ar2altfire";
ITEM.ammoClass = "ar2altfire";
ITEM.ammoAmount = 1;
ITEM.description = "A strange item which an orange glow emitting from it.";

nexus.item.Register(ITEM);