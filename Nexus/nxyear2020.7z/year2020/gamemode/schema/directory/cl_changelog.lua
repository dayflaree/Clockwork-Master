--[[
Name: "cl_changelog.lua".
Product: "Year 2020".
--]]
	
nexus.directory.AddCategoryPage( "Changelog", nil, [[
	<p>
		<font size="4">
			<b><i>Changes made on the 13th June 2010.</i></b><br>
		</font>
		<b>+</b> The Year 2020 server went up live, with an opening event.
	</p>
]] );