--[[
Name: "cl_resistance.lua".
Product: "Year 2020".
--]]
	
nexus.directory.AddCategoryPage( "Resistance", nil, [[
	<p>
		The Resistance has no central command structure, however, there are central figures. Eli Vance, Barney Calhoun,
		Arne Magnusson, Alyx Vance and Gordon Freeman are examples of Resistance leaders. The Resistance is divided into
		two areas: Combat and Research. Scientists such as Eli Vance command the science division, whereas Barney Calhoun
		and Gordon Freeman tend to command the combat section. Gordon Freeman is a man of very high regard among Resistance
		members, something of a personal hero to them, due to the fact that he was able to not only survive the Black Mesa
		ncident (which only half a dozen people confirmed survived, one been put in stasis, and even less confirmed to have
		urvived the Seven Hour War), but actually stop it.

		The core Resistance army is divided into four sections: regular resistance troops who are fully fledged resistance
		members, fully equipped with body armor and supplies; the civilian militia forces, who are citizens who have just
		gained weapons; the refugees, who are tasked with aiding the escape of civilians and fighting the Civil Protection;
		and the Vortigaunts, who are very wise and adept at combat, and are able to use the Vortessence to spy on Combine
		activities. The Resistance is also aided by medics, who hand out medical equipment, and citizens who help the troops
		and refugees by leaving behind caches full of food, weapons, ammo, and medical supplies.

		In the Combine-occupied world, humanity readily utilizes stolen Combine technology. Aside to weapons and armor, the
		Resistance has been seen to utilize the Hopper Mine, the Turret, the Thumper, the Rollermine, and Dr. Breen's Public
		address system, among others. Humanity also uses its existing technology well, scavenging and repairing radios,
		transmitters, receivers, T.V. Screens, cameras, computers, etc. Cars, watercraft, and structures are built by hand.
		Despite the Combine rule, the Resistance science teams have created weapons like the Magnusson Device and the Gravity
		Gun, and a teleporter smaller and more advanced then the Combine's teleporter at Nova Prospekt. Perhaps the greatest
		asset to the Resistance are the Vortigaunts. The Vortigaunts, as stated above, are very wise and very well versed at
		combat, and are able to communicate will all Vortigaunts instantly. Their history with the Antlions could prove handy
		in the future.

		The Resistance was an underground movement in City 17, where most actions were covert. Spies like Barney Calhoun
		infiltrated the Civil Protection, in order to keep attention away from Dr. Kliener's lab, and assist civilians in
		escaping City 17. Outside of the city, however, the Resistance is able to make frequent offenses against the
		Combine, and provide itself with sufficient defense. The Resistance had taken over a vast portion of the Coast,
		taking major bases such as Lighthouse Point and New Little Odessa. The Resistance's lack of numbers in this area
		owever meant that they were frequently under attack by Combine raiding parties, and they struggled to hold onto
		their gains.

		The Resistance generally operates as a shadow movement similar to many terrorists or rebel organizations in the
		modern world; unable to take on the Combine Empire directly, the Resistance seeks to undermine it by strategic
		moves. The Resistance held several strong points in and around City 17, such as Kleiner's Lab and Black Mesa East,
		before both were destroyed by the Combine. Ravenholm was also a major Resistance stronghold, before a Headcrab
		Shell bombardment killed the entire population of the town, with only one known survivor. 
	</p>
]] );