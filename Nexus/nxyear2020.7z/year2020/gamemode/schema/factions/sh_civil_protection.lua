--[[
Name: "sh_civil_protection.lua".
Product: "Year 2020".
--]]

local FACTION = {};

FACTION.whitelist = true;
FACTION.models = {
	female = {"models/police.mdl"},
	male = {"models/police.mdl"}
};

-- Called when a player's name should be assigned for the faction.
function FACTION:GetName(player, character)
	return "CCA-CP.UNIT-"..NEXUS:ZeroNumberToDigits(math.random(1, 99999), 5);
end;

-- Called when a player's model should be assigned for the faction.
function FACTION:GetModel(player, character)
	if (character.gender == GENDER_MALE) then
		return self.models.male[1];
	else
		return self.models.female[1];
	end;
end;

FACTION_CP = nexus.faction.Register(FACTION, "Civil Protection");