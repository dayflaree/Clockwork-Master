--[[
Name: "sh_hooks.lua".
Product: "Year 2020".
--]]

-- Called when Nexus has initialized.
function SCHEMA:NexusInitialized()
	for k, v in pairs( nexus.item.GetAll() ) do
		if (!v.isBaseItem and !v.isRareItem) then
			v.business = true;
			v.access = "y";
			v.batch = 1;
		end;
	end;
end;

-- Called when Nexus has loaded all of the entities.
function SCHEMA:NexusInitPostEntity()
	self:LoadRadios();
	self:LoadNPCs();
end;

-- Called just after data should be saved.
function SCHEMA:PostSaveData()
	self:SaveRadios();
	self:SaveNPCs();
end;

-- Called when an entity's menu option should be handled.
function SCHEMA:EntityHandleMenuOption(player, entity, option, arguments)
	if (entity:GetClass() == "prop_ragdoll" and arguments == "nx_corpseLoot") then
		if (!entity.inventory) then entity.inventory = {}; end;
		if (!entity.cash) then entity.cash = 0; end;
		
		local entityPlayer = nexus.entity.GetPlayer(entity);
		
		if ( !entityPlayer or !entityPlayer:Alive() ) then
			player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
			
			nexus.player.OpenStorage( player, {
				name = "Corpse",
				weight = 8,
				entity = entity,
				distance = 192,
				cash = entity.cash,
				inventory = entity.inventory,
				OnGiveCash = function(player, storageTable, cash)
					entity.cash = storageTable.cash;
				end,
				OnTakeCash = function(player, storageTable, cash)
					entity.cash = storageTable.cash;
				end
			} );
		end;
	elseif (entity:GetClass() == "nx_breach") then
		entity:CreateDummyBreach();
		entity:BreachEntity(player);
	elseif (entity:GetClass() == "nx_radio") then
		if (arguments == "nx_radioToggle") then
			entity:Toggle();
		end;
	end;
end;

-- Called when a player's drop weapon info should be adjusted.
function SCHEMA:PlayerAdjustDropWeaponInfo(player, info)
	if (nexus.player.GetWeaponClass(player) == info.itemTable.weaponClass) then
		info.position = player:GetShootPos();
		info.angles = player:GetAimVector():Angle();
	else
		local gearTable = {
			self:GetPlayerGear(player, "Throwable"),
			self:GetPlayerGear(player, "Secondary"),
			self:GetPlayerGear(player, "Primary"),
			self:GetPlayerGear(player, "Melee")
		};
		
		for k, v in pairs(gearTable) do
			if ( IsValid(v) ) then
				local gearItemTable = v:GetItem();
				
				if (gearItemTable and gearItemTable.weaponClass == info.itemTable.weaponClass) then
					local position, angles = v:GetRealPosition();
					
					if (position and angles) then
						info.position = position;
						info.angles = angles;
						
						break;
					end;
				end;
			end;
		end;
	end;
end;

-- Called when a player has been given a weapon.
function SCHEMA:PlayerGivenWeapon(player, class, uniqueID, forceReturn)
	local itemTable = nexus.item.GetWeapon(class, uniqueID);
	
	if (nexus.item.IsWeapon(itemTable) and !itemTable.fakeWeapon) then
		if ( !itemTable:IsMeleeWeapon() and !itemTable:IsThrowableWeapon() ) then
			if (itemTable.weight <= 2) then
				self:CreatePlayerGear(player, "Secondary", itemTable);
			else
				self:CreatePlayerGear(player, "Primary", itemTable);
			end;
		elseif ( itemTable:IsThrowableWeapon() ) then
			self:CreatePlayerGear(player, "Throwable", itemTable);
		else
			self:CreatePlayerGear(player, "Melee", itemTable);
		end;
	end;
end;

-- Called when a player's typing display has started.
function SCHEMA:PlayerStartTypingDisplay(player, code)
	if ( SCHEMA:PlayerIsCombine(player) ) then
		if (code == "n" or code == "y" or code == "w" or code == "r") then
			if (!player.typingBeep) then
				player.typingBeep = true;
				
				player:EmitSound("npc/overwatch/radiovoice/on1.wav");
			end;
		end;
	end;
end;

-- Called when a player's typing display has finished.
function SCHEMA:PlayerFinishTypingDisplay(player, textTyped)
	if (SCHEMA:PlayerIsCombine(player) and textTyped) then
		if (player.typingBeep) then
			player:EmitSound("npc/overwatch/radiovoice/off4.wav");
		end;
	end;
	
	player.typingBeep = nil;
end;

-- Called when a player's weapons should be given.
function SCHEMA:PlayerGiveWeapons(player)
	if ( self:PlayerIsCombine(player) ) then
		nexus.player.GiveSpawnItemWeapon(player, "weapon_pistol");
		nexus.player.GiveSpawnItemWeapon(player, "weapon_smg1");
		nexus.player.GiveSpawnAmmo(player, "pistol", 256);
		nexus.player.GiveSpawnAmmo(player, "smg", 512);
	end;
end;

-- Called when a player's inventory item has been updated.
function SCHEMA:PlayerInventoryItemUpdated(player, itemTable, amount, force)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes == itemTable.index) then
		if ( !player:HasItem(itemTable.uniqueID) ) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
		end;
	end;
end;

-- Called when a player's footstep sound should be played.
function SCHEMA:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	local running = nil;
	local clothes = player:GetCharacterData("clothes");
	local model = string.lower( player:GetModel() );
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			if ( player:IsRunning() or player:IsJogging() ) then
				if (itemTable.runSound) then
					if (type(itemTable.runSound) == "table") then
						sound = itemTable.runSound[ math.random(1, #itemTable.runSound) ];
					else
						sound = itemTable.runSound;
					end;
				end;
			elseif (itemTable.walkSound) then
				if (type(itemTable.walkSound) == "table") then
					sound = itemTable.walkSound[ math.random(1, #itemTable.walkSound) ];
				else
					sound = itemTable.walkSound;
				end;
			end;
		end;
	end;
	
	if ( player:IsRunning() or player:IsJogging() ) then
		running = true;
	end;
	
	if (running) then
		if ( string.find(model, "police") ) then
			if (foot == 0) then
				local randomSounds = {1, 3, 5};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/metropolice/gear"..randomSounds[randomNumber]..".wav";
			else
				local randomSounds = {2, 4, 6};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/metropolice/gear"..randomSounds[randomNumber]..".wav";
			end;
		elseif ( string.find(model, "combine") ) then
			if (foot == 0) then
				local randomSounds = {1, 3, 5};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
			else
				local randomSounds = {2, 4, 6};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
			end;
		end;
	end;
	
	player:EmitSound(sound);
	
	return true;
end;

-- Called when a player attempts to breach an entity.
function SCHEMA:PlayerCanBreachEntity(player, entity)
	if ( nexus.entity.IsDoor(entity) ) then
		if ( !nexus.entity.IsDoorFalse(entity) ) then
			return true;
		end;
	end;
end;

-- Called when a player attempts to restore a recognised name.
function SCHEMA:PlayerCanRestoreRecognisedName(player, target)
	if ( self:PlayerIsCombine(target) ) then
		return false;
	end;
end;

-- Called when a player attempts to save a recognised name.
function SCHEMA:PlayerCanSaveRecognisedName(player, target)
	if ( self:PlayerIsCombine(target) ) then
		return false;
	end;
end;

-- Called when a player attempts to use an entity in a vehicle.
function SCHEMA:PlayerCanUseEntityInVehicle(player, entity, vehicle)
	if ( entity:IsPlayer() or nexus.entity.IsPlayerRagdoll(entity) ) then
		return true;
	end;
end;

-- Called each frame that a player is dead.
function SCHEMA:PlayerDeathThink(player)
	if ( player:GetCharacterData("permakilled") ) then
		return true;
	end;
end;

-- Called when a player attempts to switch to a character.
function SCHEMA:PlayerCanSwitchCharacter(player, character)
	if ( player:GetCharacterData("permakilled") ) then
		return true;
	end;
end;

-- Called when a player's death info should be adjusted.
function SCHEMA:PlayerAdjustDeathInfo(player, info)
	if ( player:GetCharacterData("permakilled") ) then
		info.spawnTime = 0;
	elseif ( self:PlayerIsCombine(player) ) then
		info.spawnTime = 1;
	end;
end;

-- Called when a player's character screen info should be adjusted.
function SCHEMA:PlayerAdjustCharacterScreenInfo(player, character, info)
	if ( character.data["permakilled"] ) then
		info.details = "This character is permanently killed.";
	end;
	
	if ( character.data["customclass"] ) then
		info.customClass = character.data["customclass"];
	end;
end;

-- Called when a chat box message has been added.
function SCHEMA:ChatBoxMessageAdded(info)
	if (info.class == "ic") then
		local eavesdroppers = {};
		local talkRadius = nexus.config.Get("talk_radius"):Get();
		local listeners = {};
		local players = g_Player.GetAll();
		local radios = ents.FindByClass("nx_radio");
		local data = {};
		
		for k, v in ipairs(radios) do
			if (!v:IsOff() and info.speaker:GetPos():Distance( v:GetPos() ) <= 80) then
				info.shouldSend = false;
				info.listeners = {};
				data.position = v:GetPos();
				data.entity = v;
				
				break;
			end;
		end;
		
		if ( IsValid(data.entity) ) then
			for k, v in ipairs(players) do
				if ( v:HasInitialized() and v:Alive() and !v:IsRagdolled(RAGDOLL_FALLENOVER) ) then
					if (info.speaker == v) then
						listeners[v] = v;
					elseif (v:GetPos():Distance(data.position) <= talkRadius) then
						eavesdroppers[v] = v;
					end;
				end;
			end;
			
			for k, v in ipairs(radios) do
				local radioPosition = v:GetPos();
				
				if ( !v:IsOff() ) then
					for k2, v2 in ipairs(players) do
						if ( v2:HasInitialized() and !listeners[v2] and !eavesdroppers[v2] ) then
							if ( v2:GetPos():Distance(radioPosition) <= (talkRadius * 2) ) then
								eavesdroppers[v2] = v2;
							end;
						end;
					end;
				end;
			end;
			
			if (table.Count(listeners) > 0) then
				nexus.chatBox.Add(listeners, info.speaker, "radio", info.text);
			end;
			
			if (table.Count(eavesdroppers) > 0) then
				nexus.chatBox.Add(eavesdroppers, info.speaker, "radio_eavesdrop", info.text);
			end;
			
			table.Merge(info.listeners, listeners);
			table.Merge(info.listeners, eavesdroppers);
		end;
	end;
	
	if (info.voice) then
		if ( IsValid(info.speaker) and info.speaker:HasInitialized() ) then
			info.speaker:EmitSound(info.voice.sound, info.voice.volume);
		end;
		
		if (info.voice.global) then
			for k, v in pairs(info.listeners) do
				if (v != info.speaker) then
					nexus.player.PlaySound(v, info.voice.sound);
				end;
			end;
		end;
	end;
end;

-- Called when a player attempts to use the radio.
function SCHEMA:PlayerCanRadio(player, text, listeners, eavesdroppers)
	if ( !self:PlayerIsCombine(player) ) then
		nexus.player.Notify(player, "You are not part of the Civil Protection force!");
		
		return false;
	end;
end;

-- Called when a player has used their radio.
function SCHEMA:PlayerRadioUsed(player, text, listeners, eavesdroppers)
	local newEavesdroppers = {};
	local talkRadius = nexus.config.Get("talk_radius"):Get() * 2;
	
	for k, v in ipairs( ents.FindByClass("nx_radio") ) do
		local radioPosition = v:GetPos();
		
		if ( !v:IsOff() ) then
			for k2, v2 in ipairs( g_Player.GetAll() ) do
				if ( v2:HasInitialized() and !listeners[v2] and !eavesdroppers[v2] ) then
					if (v2:GetPos():Distance(radioPosition) <= talkRadius) then
						newEavesdroppers[v2] = v2;
					end;
				end;
				
				break;
			end;
		end;
	end;
	
	if (table.Count(newEavesdroppers) > 0) then
		nexus.chatBox.Add(newEavesdroppers, player, "radio_eavesdrop", text);
	end;
end;

-- Called when a player's radio info should be adjusted.
function SCHEMA:PlayerAdjustRadioInfo(player, info)
	for k, v in ipairs( g_Player.GetAll() ) do
		if ( v:HasInitialized() and self:PlayerIsCombine(v) ) then
			info.listeners[v] = v;
		end;
	end;
end;

-- Called when a player attempts to use a tool.
function SCHEMA:CanTool(player, trace, tool)
	if ( !nexus.player.HasFlags(player, "w") ) then
		if (string.sub(tool, 1, 5) == "wire_" or string.sub(tool, 1, 6) == "wire2_") then
			player:RunCommand("gmod_toolmode \"\"");
			
			return false;
		end;
	end;
end;

-- Called when a player's shared variables should be set.
function SCHEMA:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "sh_CustomClass", player:GetCharacterData("customclass", "") );
	player:SetSharedVar( "sh_Clothes", player:GetCharacterData("clothes", 0) );
end;

-- Called to check if a player does recognise another player.
function SCHEMA:PlayerDoesRecognisePlayer(player, target, status, simple, default)
	if ( self:PlayerIsCombine(target) ) then
		return true;
	end;
end;

-- Called when a player attempts to delete a character.
function SCHEMA:PlayerCanDeleteCharacter(player, character)
	if ( character.data["permakilled"] ) then
		return true;
	end;
end;

-- Called when a player attempts to use a character.
function SCHEMA:PlayerCanUseCharacter(player, character)
	if ( character.data["permakilled"] ) then
		return character.name.." is permanently killed and cannot be used!";
	end;
end;

-- Called when a player attempts to use an entity.
function SCHEMA:PlayerUse(player, entity)
	if (entity.bustedDown) then
		return false;
	end;
end;

-- Called when a player attempts to use an item.
function SCHEMA:PlayerCanUseItem(player, itemTable, noMessage)
	if (nexus.item.IsWeapon(itemTable) and !itemTable.fakeWeapon) then
		local secondaryWeapon;
		local primaryWeapon;
		local sideWeapon;
		local fault;
		
		for k, v in ipairs( player:GetWeapons() ) do
			local weaponTable = nexus.item.GetWeapon(v);
			
			if (weaponTable and !weaponTable.fakeWeapon) then
				if (weaponTable.weight >= 1) then
					if (weaponTable.weight <= 2) then
						secondaryWeapon = true;
					else
						primaryWeapon = true;
					end;
				else
					sideWeapon = true;
				end;
			end;
		end;
		
		if (itemTable.weight >= 1) then
			if (itemTable.weight <= 2) then
				if (secondaryWeapon) then
					fault = "You cannot use another secondary weapon!";
				end;
			elseif (primaryWeapon) then
				fault = "You cannot use another secondary weapon!";
			end;
		elseif (sideWeapon) then
			fault = "You cannot use another melee weapon!";
		end;
		
		if (fault) then
			if (!noMessage) then
				nexus.player.Notify(player, fault);
			end;
			
			return false;
		end;
	end;
end;

-- Called when a player attempts to earn generator cash.
function SCHEMA:PlayerCanEarnGeneratorCash(player, info, cash)
	if ( self:PlayerIsCombine(player) ) then
		return false;
	end;
end;

-- Called when a player's death sound should be played.
function SCHEMA:PlayerPlayDeathSound(player, gender)
	if ( self:PlayerIsCombine(player) ) then
		local sound = "npc/metropolice/die"..math.random(1, 4)..".wav";
		
		for k, v in ipairs( g_Player.GetAll() ) do
			if ( v:HasInitialized() ) then
				if ( self:PlayerIsCombine(v) ) then
					v:EmitSound(sound);
				end;
			end;
		end;
		
		return sound;
	end;
end;

-- Called when a player's pain sound should be played.
function SCHEMA:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
	if ( self:PlayerIsCombine(player) ) then
		return "npc/metropolice/pain"..math.random(1, 4)..".wav";
	end;
end;
-- Called when chat box info should be adjusted.
function SCHEMA:ChatBoxAdjustInfo(info)
	if (info.class != "ooc" and info.class != "looc") then
		if ( IsValid(info.speaker) and info.speaker:HasInitialized() ) then
			if (string.sub(info.text, 1, 1) == "?") then
				info.text = string.sub(info.text, 2);
				info.data.anon = true;
			end;
		end;
	end;
	
	if (info.class == "ic" or info.class == "yell" or info.class == "radio" or info.class == "whisper" or info.class == "request") then
		if ( IsValid(info.speaker) and info.speaker:HasInitialized() ) then
			if ( self:PlayerIsCombine(info.speaker) ) then
				for k, v in pairs(self.voices) do
					if ( string.lower(info.text) == string.lower(v.command) ) then
						local voice = {
							global = false,
							volume = 80,
							sound = v.sound
						};
						
						if (v.female and info.speaker:QueryCharacter("gender") == GENDER_FEMALE) then
							voice.sound = string.Replace(voice.sound, "/male", "/female");
						end;
						
						if (info.class == "request" or info.class == "radio") then
							voice.global = true;
						elseif (info.class == "whisper") then
							voice.volume = 60;
						elseif (info.class == "yell") then
							voice.volume = 100;
						end;
						
						if (playerIsCombine) then
							info.text = "<:: "..v.phrase;
						else
							info.text = v.phrase;
						end;
						
						info.voice = voice;
						
						return true;
					end;
				end;
				
				if (string.sub(info.text, 1, 4) != "<:: ") then
					info.text = "<:: "..info.text;
				end;
			end;
		end;
	elseif (info.class == "dispatch") then
		for k, v in pairs(self.dispatchVoices) do
			if ( string.lower(info.text) == string.lower(v.command) ) then
				nexus.player.PlaySound(nil, v.sound);
				
				info.text = v.phrase;
				
				return true;
			end;
		end;
	end;
end;

-- Called when a player destroys generator.
function SCHEMA:PlayerDestroyGenerator(player, entity, generator)
	if ( self:PlayerIsCombine(player) ) then
		local players = {};
		
		for k, v in ipairs( g_Player.GetAll() ) do
			if ( v:HasInitialized() ) then
				if ( self:PlayerIsCombine(v) ) then
					players[#players + 1] = v;
				end;
			end;
		end;
		
		for k, v in pairs(players) do
			nexus.player.GiveCash( v, generator.cash / 4, "destroying a "..string.lower(generator.name) );
		end;
	else
		nexus.player.GiveCash( v, generator.cash / 4, "destroying a "..string.lower(generator.name) );
	end;
end;

-- Called just before a player dies.
function SCHEMA:DoPlayerDeath(player, attacker, damageInfo)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes) then
		player:UpdateInventory(clothes);
		player:SetCharacterData("clothes", nil);
	end;
end;

-- Called when a player dies.
function SCHEMA:PlayerDeath(player, inflictor, attacker, damageInfo)
	if ( self:PlayerIsCombine(player) ) then
		local location = self:PlayerGetLocation(player);
		
		self:AddCombineDisplayLine("Downloading lost biosignal...", Color(255, 255, 255, 255), nil, player);
		self:AddCombineDisplayLine("WARNING! Biosignal lost for protection team unit at "..location.."...", Color(255, 0, 0, 255), nil, player);
		
		for k, v in ipairs( g_Player.GetAll() ) do
			if ( self:PlayerIsCombine(v) ) then
				v:EmitSound("npc/overwatch/radiovoice/on1.wav");
				v:EmitSound("npc/overwatch/radiovoice/lostbiosignalforunit.wav");
			end;
		end;
		
		timer.Simple(1.5, function()
			for k, v in ipairs( g_Player.GetAll() ) do
				if ( self:PlayerIsCombine(v) ) then
					v:EmitSound("npc/overwatch/radiovoice/off4.wav");
				end;
			end;
		end);
		
		if (math.random() <= 0.5) then
			nexus.entity.CreateItem( player, "ammo_smg1", player:GetPos() + Vector(0, 0, 32) );
		else
			nexus.entity.CreateItem( player, "ammo_pistol", player:GetPos() + Vector(0, 0, 32) );
		end;
	end;
end;

-- Called when a player's character has loaded.
function SCHEMA:PlayerCharacterLoaded(player)
	player:SetSharedVar("sh_PermaKilled", false);
end;

-- Called just after a player spawns.
function SCHEMA:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local clothes = player:GetCharacterData("clothes");
	
	if (!lightSpawn) then
		umsg.Start("nx_ClearEffects", player);
		umsg.End();
		
		if ( self:PlayerIsCombine(player) ) then
			player:SetArmor(100);
		end;
	end;
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		
		if ( itemTable and player:HasItem(itemTable.uniqueID) ) then
			self:PlayerWearClothes(player, itemTable);
		else
			player:SetCharacterData("clothes", nil);
		end;
	end;
end;

-- Called when a player spawns lightly.
function SCHEMA:PostPlayerLightSpawn(player, weapons, ammo, special)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, true);
		end;
	end;
end;

-- Called when an entity has been breached.
function SCHEMA:EntityBreached(entity, activator)
	if ( nexus.entity.IsDoor(entity) ) then
		if (!IsValid(activator) or string.lower( entity:GetClass() ) == "prop_door_rotating") then
			nexus.entity.OpenDoor(entity, 0, true, true);
		else
			self:BustDownDoor(activator, entity);
		end;
	end;
end;

-- Called when a player takes damage.
function SCHEMA:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	if (player:Armor() <= 0) then
		umsg.Start("nx_Stunned", player);
			umsg.Float(0.5);
		umsg.End();
	else
		umsg.Start("nx_Stunned", player);
			umsg.Float(1);
		umsg.End();
	end;
end;

-- Called when an entity takes damage.
function SCHEMA:EntityTakeDamage(entity, inflictor, attacker, amount, damageInfo)
	local player = nexus.entity.GetPlayer(entity);
	local curTime = CurTime();
	
	if (player) then
		if ( attacker:IsPlayer() ) then
			if ( self:PlayerIsCombine(player) ) then
				damageInfo:ScaleDamage(2);
				
				if (attacker != player) then
					local location = SCHEMA:PlayerGetLocation(player);
					
					if (!player.nextUnderFire or curTime >= player.nextUnderFire) then
						player.nextUnderFire = curTime + 15;
						
						SCHEMA:AddCombineDisplayLine("Downloading trauma packet...", Color(255, 255, 255, 255), nil, player);
						SCHEMA:AddCombineDisplayLine("WARNING! Protection team unit enduring physical bodily trauma at "..location.."...", Color(255, 0, 0, 255), nil, player);
					end;
				end;
			elseif ( self:PlayerIsCombine(attacker) ) then
				damageInfo:ScaleDamage(0.25);
			end;
		end;
	end;
	
	if ( attacker:IsPlayer() ) then
		local weapon = nexus.player.GetWeaponClass(attacker);
		
		if (weapon == "weapon_357") then
			damageInfo:ScaleDamage(0.25);
		elseif (weapon == "weapon_crossbow") then
			damageInfo:ScaleDamage(2);
		elseif (weapon == "weapon_shotgun") then
			damageInfo:ScaleDamage(3);
		elseif (weapon == "weapon_crowbar") then
			damageInfo:ScaleDamage(0.25);
		end;
		
		if (damageInfo:IsBulletDamage() and weapon != "weapon_shotgun") then
			if (string.lower( entity:GetClass() ) == "prop_door_rotating") then
				if ( !nexus.entity.IsDoorFalse(entity) ) then
					local damagePosition = damageInfo:GetDamagePosition();
					
					if (entity:WorldToLocal(damagePosition):Distance( Vector(-1.0313, 41.8047, -8.1611) ) <= 8) then
						entity.doorHealth = math.min( (entity.doorHealth or 50) - damageInfo:GetDamage(), 0 );
						
						local effectData = EffectData();
						
						effectData:SetStart(damagePosition);
						effectData:SetOrigin(damagePosition);
						effectData:SetScale(8);
						
						util.Effect("GlassImpact", effectData, true, true);
						
						if (entity.doorHealth <= 0) then
							nexus.entity.OpenDoor( entity, 0, true, true, attacker:GetPos() );
							entity.doorHealth = 50;
						else
							NEXUS:CreateTimer("Reset Door Health: "..entity:EntIndex(), 60, 1, function()
								if ( IsValid(entity) ) then
									entity.doorHealth = 50;
								end;
							end);
						end;
					end;
				end;
			end;
		end;
		
		if ( damageInfo:IsExplosionDamage() ) then
			damageInfo:ScaleDamage(2);
		end;
	elseif ( attacker:IsNPC() ) then
		damageInfo:ScaleDamage(0.5);
	end;
end;