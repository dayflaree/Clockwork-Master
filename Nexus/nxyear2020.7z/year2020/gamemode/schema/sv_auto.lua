--[[
Name: "sv_auto.lua".
Product: "Year 2020".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");

resource.AddFile("resource/fonts/travelingtypewriter.ttf");

for k, v in pairs( g_File.Find("../materials/year2020/*.*") ) do
	resource.AddFile("materials/year2020/"..v);
end;

nexus.config.Add("intro_text_small", "The uprising has occured.", true);
nexus.config.Add("intro_text_big", "NEW LITTLE ODESSA, 2020.", true);

nexus.config.Get("enable_gravgun_punt"):Set(false);
nexus.config.Get("default_inv_weight"):Set(6);
nexus.config.Get("enable_crosshair"):Set(false);
nexus.config.Get("disable_sprays"):Set(false);
nexus.config.Get("cash_enabled"):Set(false, nil, true);
nexus.config.Get("prop_cost"):Set(false);

nexus.hint.Add("Admins", "The admins are here to help you, please respect them.");
nexus.hint.Add("Action", "Action. Stop looking for it, wait until it comes to you.");
nexus.hint.Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
nexus.hint.Add("Healing", "You can heal players by using the Give command in your inventory.");
nexus.hint.Add("Firefights", "When engaged in a firefight, shoot to miss to make it enjoyable.");
nexus.hint.Add("Metagaming", "Metagaming is when you use OOC information in-character.");
nexus.hint.Add("Passive RP", "If you're bored and there's no action, try some passive roleplay.");
nexus.hint.Add("Development", "Develop your character, give them a story to tell.");
nexus.hint.Add("Powergaming", "Powergaming is when you force your actions on others.");

NEXUS:HookDataStream("ObjectPhysDesc", function(player, data)
	if (type(data) == "table" and type( data[1] ) == "string") then
		if ( player.objectPhysDesc == data[2] ) then
			local physDesc = data[1];
			
			if (string.len(physDesc) > 80) then
				physDesc = string.sub(physDesc, 1, 80).."...";
			end;
			
			data[2]:SetNetworkedString("sh_PhysDesc", physDesc);
		end;
	end;
end);

-- A function to get a player's gear.
function SCHEMA:GetPlayerGear(player, class)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		return player[uniqueID];
	end;
end;

-- A function to create a player's gear.
function SCHEMA:CreatePlayerGear(player, class, itemTable)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		player[uniqueID]:Remove();
	end;
	
	if (itemTable.isAttachment) then
		local position = player:GetPos();
		local angles = player:GetAngles();
		
		player[uniqueID] = ents.Create("nx_gear");
		player[uniqueID]:SetParent(player);
		player[uniqueID]:SetAngles(angles);
		player[uniqueID]:SetColor(255, 255, 255, 0);
		player[uniqueID]:SetModel(itemTable.model);
		player[uniqueID]:SetPos(position);
		player[uniqueID]:Spawn();
		
		if (itemTable.color) then
			player[uniqueID]:SetColor( NEXUS:UnpackColor(itemTable.color) );
		end;
		
		if (itemTable.material) then
			player[uniqueID]:SetMaterial(material);
		end;
		
		if ( IsValid( player[uniqueID] ) ) then
			player[uniqueID]:SetOwner(player);
			player[uniqueID]:SetItem(itemTable);
		end;
	end;
end;

-- A function to add a Combine display line.
function SCHEMA:AddCombineDisplayLine(text, color, player, exclude)
	if (player) then
		NEXUS:StartDataStream( player, "CombineDisplayLine", {text, color} );
	else
		local players = {};
		
		for k, v in ipairs( g_Player.GetAll() ) do
			if (self:PlayerIsCombine(v) and v != exclude) then
				players[#players + 1] = v;
			end;
		end;
		
		NEXUS:StartDataStream( players, "CombineDisplayLine", {text, color} );
	end;
end;

-- A function to load the NPCs.
function SCHEMA:LoadNPCs()
	local npcs = NEXUS:RestoreSchemaData( "mounts/npcs/"..game.GetMap() );
	
	for k, v in pairs(npcs) do
		local entity = ents.Create(v.class);
		
		if ( IsValid(entity) ) then
			entity:SetKeyValue("spawnflags", v.spawnFlags or 0);
			entity:SetKeyValue("additionalequipment", v.equipment or "");
			entity:SetAngles(v.angles);
			entity:SetModel(v.model);
			entity:SetPos(v.position);
			entity:Spawn();
			
			if ( IsValid(entity) ) then
				entity:Activate();
				
				entity:SetNetworkedString("nx_Name", v.name);
				entity:SetNetworkedString("nx_Title", v.title);
			end;
		end;
	end;
end;

-- A function to save the NPCs.
function SCHEMA:SaveNPCs()
	local npcs = {};
	
	for k, v in pairs( ents.FindByClass("npc_*") ) do
		local name = v:GetNetworkedString("nx_Name");
		local title = v:GetNetworkedString("nx_Title");
		
		if (name != "" and title != "") then
			local keyValues = table.LowerKeyNames( v:GetKeyValues() );
			
			npcs[#npcs + 1] = {
				spawnFlags = keyValues["spawnflags"],
				equipment = keyValues["additionequipment"],
				position = v:GetPos(),
				angles = v:GetAngles(),
				model = v:GetModel(),
				title = title,
				class = v:GetClass(),
				name = name
			};
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/npcs/"..game.GetMap(), npcs);
end;

-- A function to load the radios.
function SCHEMA:LoadRadios()
	local radios = NEXUS:RestoreSchemaData( "mounts/radios/"..game.GetMap() );
	
	for k, v in pairs(radios) do
		local entity = ents.Create("nx_radio");
		
		nexus.player.GivePropertyOffline(v.key, v.uniqueID, entity);
		
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if ( IsValid(entity) ) then
			entity:SetOff(v.off);
		end;
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if ( IsValid(physicsObject) ) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the radios.
function SCHEMA:SaveRadios()
	local radios = {};
	
	for k, v in pairs( ents.FindByClass("nx_radio") ) do
		local physicsObject = v:GetPhysicsObject();
		local moveable;
		
		if ( IsValid(physicsObject) ) then
			moveable = physicsObject:IsMoveable();
		end;
		
		radios[#radios + 1] = {
			off = v:IsOff(),
			key = nexus.entity.QueryProperty(v, "key"),
			angles = v:GetAngles(),
			moveable = moveable,
			uniqueID = nexus.entity.QueryProperty(v, "uniqueID"),
			position = v:GetPos()
		};
	end;
	
	NEXUS:SaveSchemaData("mounts/radios/"..game.GetMap(), radios);
end;

-- A function to get a player's location.
function SCHEMA:PlayerGetLocation(player)
	local areaNames = nexus.mount.Get("Area Names");
	local closest = nil;
	
	if (areaNames) then
		for k, v in pairs(areaNames.areaNames) do
			if ( nexus.entity.IsInBox(player, v.minimum, v.maximum) ) then
				if (string.sub(string.lower(v.name), 1, 4) == "the ") then
					return string.sub(v.name, 5);
				else
					return v.name;
				end;
			else
				local distance = player:GetShootPos():Distance(v.minimum);
				
				if ( !closest or distance < closest[1] ) then
					closest = {distance, v.name};
				end;
			end;
		end;
		
		if (!completed) then
			if (closest) then
				if (string.sub(string.lower( closest[2] ), 1, 4) == "the ") then
					return string.sub(closest[2], 5);
				else
					return closest[2];
				end;
			end;
		end;
	end;
	
	return "unknown location";
end;

-- A function to check if a player is Combine.
function SCHEMA:PlayerIsCombine(player)
	if ( IsValid(player) and player:GetCharacter() ) then
		return player:QueryCharacter("faction") == FACTION_CP;
	end;
end;

-- A function to make a player wear clothes.
function SCHEMA:PlayerWearClothes(player, itemTable, noMessage)
	local clothes = player:GetCharacterData("clothes");
	
	if (itemTable) then
		local model = nexus.class.GetAppropriateModel(player:Team(), player, true);
		
		if (!model) then
			itemTable:OnChangeClothes(player, true);
			
			player:SetCharacterData("clothes", itemTable.index);
			player:SetSharedVar("sh_Clothes", itemTable.index);
		end;
	else
		itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
			player:SetSharedVar("sh_Clothes", 0);
		end;
	end;
	
	if (itemTable) then
		player:UpdateInventory(itemTable.uniqueID);
	end;
end;

-- A function to get a player's heal amount.
function SCHEMA:GetHealAmount(player, scale)
	return 20 * (scale or 1);
end;

-- A function to get a player's dexterity time.
function SCHEMA:GetDexterityTime(player)
	return 6;
end;

-- A function to bust down a door.
function SCHEMA:BustDownDoor(player, door, force)
	door.bustedDown = true;
	
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	if ( IsValid(door.breach) ) then
		door.breach:BreachEntity();
	end;
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if ( IsValid(physicsObject) ) then
		if (!force) then
			if ( IsValid(player) ) then
				physicsObject:ApplyForceCenter( (door:GetPos() - player:GetPos() ):Normalize() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	nexus.entity.Decay(fakeDoor, 300);
	
	NEXUS:CreateTimer("Reset Door: "..door:EntIndex(), 300, 1, function()
		if ( IsValid(door) ) then
			door.bustedDown = nil;
			
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
		end;
	end);
end;

-- A function to permanently kill a player.
function SCHEMA:PermaKillPlayer(player, ragdoll)
	if ( player:Alive() ) then
		player:Kill(); ragdoll = player:GetRagdollEntity();
	end;
	
	if ( !player:GetCharacterData("permakilled") ) then
		player:SetCharacterData("permakilled", true);
		player:SetCharacterData("inventory", {}, true);
		player:SetCharacterData("cash", 0, true);
		
		nexus.player.SaveCharacter(player);
	end;
end;