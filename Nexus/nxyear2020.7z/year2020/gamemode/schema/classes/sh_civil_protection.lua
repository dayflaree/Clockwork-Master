--[[
Name: "sh_civil_protection.lua".
Product: "Year 2020".
--]]

local CLASS = {};

CLASS.color = Color(50, 100, 150, 255);
CLASS.factions = {FACTION_CP};
CLASS.isDefault = true;
CLASS.description = "A human enslaved to work as Civil Protection.";
CLASS.defaultPhysDesc = "Wearing a metrocop jacket with a radio";

CLASS_CP = nexus.class.Register(CLASS, "Civil Protection");