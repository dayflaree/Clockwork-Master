--[[
Name: "sh_refugee.lua".
Product: "Year 2020".
--]]

local CLASS = {};

CLASS.color = Color(150, 125, 100, 255);
CLASS.factions = {FACTION_REF};
CLASS.isDefault = true;
CLASS.description = "A refugee that is part of the rebellion against the Combine.";
CLASS.defaultPhysDesc = "Wearing dirty clothes.";

CLASS_REF = nexus.class.Register(CLASS, "Refugee");