--[[
Name: "cl_auto.lua".
Product: "Year 2020".
--]]

SCHEMA.dirtyTextureRebel = surface.GetTextureID("year2020/dirty_rebel");
SCHEMA.dirtyTextureCP = surface.GetTextureID("year2020/dirty_civil");
SCHEMA.heartbeatPoint = Material("sprites/glow04_noz");
SCHEMA.combineOverlay = Material("effects/combine_binocoverlay");
SCHEMA.randomDisplayLines = {
	"Transmitting physical transition vector...",
	"Modulating external temperature levels...",
	"Parsing view ports and data arrays...",
	"Translating Union practicalities...",
	"Updating biosignal co-ordinates...",
	"Parsing Nexus protocol messages...",
	"Downloading recent dictionaries...",
	"Pinging connection to network...",
	"Updating mainframe connection...",
	"Synchronizing locational data...",
	"Translating radio messages...",
	"Emptying outgoing pipes...",
	"Sensoring proximity...",
	"Pinging loopback...",
	"Idle connection..."
};

NEXUS:IncludePrefixed("sh_auto.lua");

surface.CreateFont("Verdana", ScaleToWideScreen(17), 600, true, false, "yr_ChatBoxText");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(2048), 600, true, false, "yr_Large3D2D");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(29), 600, true, false, "yr_IntroTextSmall");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(24), 600, true, false, "yr_IntroTextTiny");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(34), 600, true, false, "yr_CinematicText");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(64), 600, true, false, "yr_IntroTextBig");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(18), 600, true, false, "yr_MainText");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(22), 600, true, false, "yr_TargetIDText");
surface.CreateFont("Traveling _Typewriter", ScaleToWideScreen(76), 600, true, false, "yr_MenuTextBig");

nexus.directory.AddCategory("Civil Protection", "Commands");

nexus.config.SetOverwatch("intro_text_small", "The small text displayed for the introduction.");
nexus.config.SetOverwatch("intro_text_big", "The big text displayed for the introduction.");

table.sort(SCHEMA.voices, function(a, b) return a.command < b.command; end);

for k, v in pairs(SCHEMA.voices) do
	nexus.directory.AddCode("Civil Protection", "<b><font color=\"red\">"..v.command.."</font></b>");
	nexus.directory.AddCode("Civil Protection", "<i>"..v.phrase.."</i>");
end;

usermessage.Hook("nx_ObjectPhysDesc", function(msg)
	local entity = msg:ReadEntity();
	
	if ( IsValid(entity) ) then
		Derma_StringRequest("Physical Description", "What is the physical description of this object?", nil, function(text)
			NEXUS:StartDataStream( "ObjectPhysDesc", {text, entity} );
		end);
	end;
end);

usermessage.Hook("nx_Stunned", function(msg)
	SCHEMA:AddStunEffect( msg:ReadFloat() );
end);

-- A function to add a stun effect.
function SCHEMA:AddStunEffect(duration)
	local curTime = CurTime();
	
	if (!duration or duration == 0) then
		duration = 1;
	end;
	
	self.stunEffects[#self.stunEffects + 1] = {curTime + duration, duration};
end;

usermessage.Hook("nx_ClearEffects", function(msg)
	SCHEMA.stunEffects = {};
end);

NEXUS:HookDataStream("CombineDisplayLine", function(data)
	SCHEMA:AddCombineDisplayLine( data[1], data[2] );
end);

-- A function to get whether a text entry is being used.
function SCHEMA:IsTextEntryBeingUsed()
	if (self.textEntryFocused) then
		if ( self.textEntryFocused:IsValid() and self.textEntryFocused:IsVisible() ) then
			return true;
		end;
	end;
end;

-- A function to add a Combine display line.
function SCHEMA:AddCombineDisplayLine(text, color)
	if ( self:PlayerIsCombine(g_LocalPlayer) ) then
		if (!self.combineDisplayLines) then
			self.combineDisplayLines = {};
		end;
		
		table.insert( self.combineDisplayLines, {"<:: "..text, CurTime() + 8, 5, color} );
	end;
end;

-- A function to get whether a player is Combine.
function SCHEMA:PlayerIsCombine(player)
	return nexus.player.GetFaction(player) == FACTION_CP;
end;