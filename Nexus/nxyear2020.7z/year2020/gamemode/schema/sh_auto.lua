--[[
Name: "sh_auto.lua".
Product: "Year 2020".
--]]

nexus.schema.SetOption( "default_date", {month = 1, year = 2020, day = 1} );
nexus.schema.SetOption( "default_time", {minute = 0, hour = 0, day = 1} );
nexus.schema.SetOption("description_business", "Distribute a variety of items.");
nexus.schema.SetOption("model_shipment", "models/items/item_item_crate.mdl");
nexus.schema.SetOption("name_business", "Distribution");
nexus.schema.SetOption("intro_image", "year2020/logo");
nexus.schema.SetOption("gradient", "year2020/gradient");

nexus.config.ShareKey("intro_text_small");
nexus.config.ShareKey("intro_text_big");

nexus.schema.SetFont("bar_text", "yr_TargetIDText");
nexus.schema.SetFont("main_text", "yr_MainText");
nexus.schema.SetFont("hints_text", "yr_IntroTextTiny");
nexus.schema.SetFont("large_3d_2d", "yr_Large3D2D");
nexus.schema.SetFont("chat_box_text", "yr_ChatBoxText");
nexus.schema.SetFont("menu_text_big", "yr_MenuTextBig");
nexus.schema.SetFont("target_id_text", "yr_TargetIDText");
nexus.schema.SetFont("cinematic_text", "yr_CinematicText");
nexus.schema.SetFont("date_time_text", "yr_IntroTextSmall");
nexus.schema.SetFont("intro_text_big", "yr_IntroTextBig");
nexus.schema.SetFont("menu_text_tiny", "yr_IntroTextTiny");
nexus.schema.SetFont("menu_text_small", "yr_IntroTextSmall");
nexus.schema.SetFont("intro_text_tiny", "yr_IntroTextTiny");
nexus.schema.SetFont("intro_text_small", "yr_IntroTextSmall");
nexus.schema.SetFont("player_info_text", "yr_ChatBoxText");

nexus.player.RegisterSharedVar("sh_CustomClass", NWTYPE_STRING);
nexus.player.RegisterSharedVar("sh_Clothes", NWTYPE_NUMBER, true);

NEXUS:IncludePrefixed("sh_coms.lua");
NEXUS:IncludePrefixed("sh_voices.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");

nexus.quiz.SetEnabled(true);
nexus.quiz.AddQuestion("Do you understand that roleplaying is slow paced and relaxed?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("Can you type properly, using capital letters and full-stops?", 2, "yes i can", "Yes, I can.");
nexus.quiz.AddQuestion("You do not need weapons to roleplay, do you understand?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("You do not need items to roleplay, do you understand?", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("What universe is this roleplaying game set in?", 2, "Real Life.", "Half-Life 2.");

nexus.flag.Add("y", "Distribution", "Access to distribute items around the map.");