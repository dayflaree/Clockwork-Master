--[[
Name: "sh_coms.lua".
Product: "Year 2020".
--]]

local COMMAND = {};

COMMAND = {};
COMMAND.tip = "Set the physical description of an object.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if (target:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if ( nexus.entity.IsPhysicsEntity(target) ) then
				if ( player:QueryCharacter("key") == target:GetOwnerKey() ) then
					player.objectPhysDesc = target;
					
					umsg.Start("nx_ObjectPhysDesc", player);
						umsg.Entity(target);
					umsg.End();
				else
					nexus.player.Notify(player, "You are not the owner of this entity!");
				end;
			else
				nexus.player.Notify(player, "This entity is not a physics entity!");
			end;
		else
			nexus.player.Notify(player, "This entity is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "ObjectPhysDesc");

COMMAND = {};
COMMAND.tip = "Heal a character if you own a medical item.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local itemTable = nexus.item.Get( arguments[1] );
	local entity = player:GetEyeTraceNoCursor().Entity;
	local healed;
	
	local target = nexus.entity.GetPlayer(entity);
	
	if (target) then
		if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if (itemTable and arguments[1] == "health_vial") then
				if ( player:HasItem("health_vial") ) then
					target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 1.5), 0, target:GetMaxHealth() ) );
					target:EmitSound("items/medshot4.wav");
					
					player:UpdateInventory("health_vial", -1, true);
					
					healed = true;
				else
					nexus.player.Notify(player, "You do not own a health vial!");
				end;
			elseif (itemTable and arguments[1] == "health_kit") then
				if ( player:HasItem("health_kit") ) then
					target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 2), 0, target:GetMaxHealth() ) );
					target:EmitSound("items/medshot4.wav");
					
					player:UpdateInventory("health_kit", -1, true);
					
					healed = true;
				else
					nexus.player.Notify(player, "You do not own a health kit!");
				end;
			elseif (itemTable and arguments[1] == "bandage") then
				if ( player:HasItem("bandage") ) then
					target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player), 0, target:GetMaxHealth() ) );
					target:EmitSound("items/medshot4.wav");
					
					player:UpdateInventory("bandage", -1, true);
					
					healed = true;
				else
					nexus.player.Notify(player, "You do not own a bandage!");
				end;
			else
				nexus.player.Notify(player, "This is not a valid item!");
			end;
			
			if (healed) then
				nexus.mount.Call("PlayerHealed", target, player, itemTable);
				
				player:FakePickup(target);
			end;
		else
			nexus.player.Notify(player, "This character is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "CharHeal");

COMMAND = {};
COMMAND.tip = "Set a character's custom class.";
COMMAND.text = "<string Name> <string Class>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] )
	
	if (target) then
		target:SetCharacterData( "customclass", arguments[2] );
		
		nexus.player.NotifyAll(player:Name().." set "..target:Name().."'s custom class to "..arguments[2]..".");
	else
		nexus.player.Notify(player, arguments[1].." is not a valid character!");
	end;
end;

nexus.command.Register(COMMAND, "CharSetCustomClass");

COMMAND = {};
COMMAND.tip = "Take a character's custom class.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] )
	
	if (target) then
		target:SetCharacterData("customclass", nil);
		
		nexus.player.NotifyAll(player:Name().." took "..target:Name().."'s custom class.");
	else
		nexus.player.Notify(player, arguments[1].." is not a valid character!");
	end;
end;

nexus.command.Register(COMMAND, "CharTakeCustomClass");

COMMAND = {};
COMMAND.tip = "Permanently kill a character.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] )
	
	if (target) then
		if ( !target:GetCharacterData("permakilled") ) then
			SCHEMA:PermaKillPlayer( target, target:GetRagdollEntity() );
		else
			nexus.player.Notify(player, "This character is already permanently killed!");
			
			return;
		end;
		
		nexus.player.NotifyAll(player:Name().." permanently killed the character '"..target:Name().."'.");
	else
		nexus.player.Notify(player, arguments[1].." is not a valid character!");
	end;
end;

nexus.command.Register(COMMAND, "CharPermaKill");

COMMAND = {};
COMMAND.tip = "Set the name of a non-playable character.";
COMMAND.text = "<string Name> <string Title>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local target = trace.Entity;
	
	if ( target and target:IsNPC() ) then
		if (trace.HitPos:Distance( player:GetShootPos() ) <= 192) then
			target:SetNetworkedString( "nx_Name", arguments[1] );
			target:SetNetworkedString( "nx_Title", arguments[2] );
		else
			nexus.player.Notify(player, "This NPC is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at an NPC!");
	end;
end;

nexus.command.Register(COMMAND, "SetNPCName");