--[[
Name: "cl_init.lua".
Product: "Year 2020".
--]]

NEXUS = GM;

DeriveGamemode("nexus");