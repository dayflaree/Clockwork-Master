--[[
Name: "init.lua".
Product: "eXperim3nt".
--]]

NEXUS = GM;

AddCSLuaFile("cl_init.lua");

DeriveGamemode("nexus");