--[[
Name: "cl_init.lua".
Product: "eXperim3nt".
--]]

NEXUS = GM;

DeriveGamemode("nexus");