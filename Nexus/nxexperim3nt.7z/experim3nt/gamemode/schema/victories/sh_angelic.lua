--[[
Name: "sh_angelic.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Angelic";
VICTORY.image = "victories/angelic";
VICTORY.reward = 80;
VICTORY.maximum = 1;
VICTORY.description = "Get the highest possible honor.\nReceive a reward of 80 codeks.";

VIC_ANGELIC = nexus.victory.Register(VICTORY);