--[[
Name: "sh_devil_hunter.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Devil Hunter";
VICTORY.image = "victories/devilhunter";
VICTORY.reward = 320;
VICTORY.maximum = 20;
VICTORY.description = "Kill twenty characters who have evil honor.\nReceive a reward of 320 codeks.";

VIC_DEVILHUNTER = nexus.victory.Register(VICTORY);