--[[
Name: "sh_paramedic.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Paramedic";
VICTORY.image = "victories/paramedic";
VICTORY.reward = 160;
VICTORY.maximum = 20;
VICTORY.description = "Revive a total of ten characters.\nReceive a reward of 160 codeks.";

VIC_PARAMEDIC = nexus.victory.Register(VICTORY);