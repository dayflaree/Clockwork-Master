--[[
Name: "sh_zip_ninja.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Zip Ninja";
VICTORY.image = "victories/zipninja";
VICTORY.reward = 160;
VICTORY.maximum = 10;
VICTORY.description = "Use zip ties and succeed on ten characters.\nReceive a reward of 160 codeks.";

VIC_ZIPNINJA = nexus.victory.Register(VICTORY);