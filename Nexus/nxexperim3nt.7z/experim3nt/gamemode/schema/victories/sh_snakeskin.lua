--[[
Name: "sh_snakeskin.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Snakeskin";
VICTORY.image = "victories/snakeskin";
VICTORY.reward = 960;
VICTORY.maximum = 1;
VICTORY.description = "Get 100% endurance without using boosts.\nReceive a reward of 960 codeks.";

VIC_SNAKESKIN = nexus.victory.Register(VICTORY);