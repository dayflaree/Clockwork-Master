--[[
Name: "sh_blockbusta.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Block Busta";
VICTORY.image = "victories/blockbusta";
VICTORY.reward = 160;
VICTORY.maximum = 10;
VICTORY.description = "Breach a total of ten doors.\nReceive a reward of 160 codeks.";

VIC_BLOCKBUSTER = nexus.victory.Register(VICTORY);