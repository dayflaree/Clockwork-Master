--[[
Name: "sh_ransacked.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Ransacked";
VICTORY.image = "victories/ransacked";
VICTORY.reward = 160;
VICTORY.maximum = 1;
VICTORY.description = "Successfully loot $1500 from a corpse.\nReceive a reward of 160 codeks.";

VIC_RANSACKED = nexus.victory.Register(VICTORY);