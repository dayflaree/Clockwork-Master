--[[
Name: "sh_bully_victim.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Bully Victim";
VICTORY.image = "victories/bullyvictim";
VICTORY.reward = 160;
VICTORY.maximum = 10;
VICTORY.description = "Get killed by other players ten times.\nReceive a reward of 160 codeks.";

VIC_BULLYVICTIM = nexus.victory.Register(VICTORY);