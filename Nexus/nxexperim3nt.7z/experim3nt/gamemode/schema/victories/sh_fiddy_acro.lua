--[[
Name: "sh_fiddy_acro.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Fiddy Acro";
VICTORY.image = "victories/fiddyacro";
VICTORY.reward = 720;
VICTORY.maximum = 1;
VICTORY.description = "Get 50% acrobatics without using boosts.\nReceive a reward of 720 codeks.";

VIC_FIDDYACRO = nexus.victory.Register(VICTORY);