--[[
Name: "sh_thedon.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "The Don";
VICTORY.image = "victories/thedon";
VICTORY.reward = 240;
VICTORY.maximum = 10;
VICTORY.description = "Invite a total of ten people into your alliance.\nReceive a reward of 240 codeks.";

VIC_THEDON = nexus.victory.Register(VICTORY);