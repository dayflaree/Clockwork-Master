--[[
Name: "sh_bounty_hunter.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Bounty Hunter";
VICTORY.image = "victories/bountyhunter";
VICTORY.reward = 240;
VICTORY.maximum = 10;
VICTORY.description = "Kill ten characters who have a bounty on their head.\nReceive a reward of 240 codeks.";

VIC_BOUNTYHUNTER = nexus.victory.Register(VICTORY);