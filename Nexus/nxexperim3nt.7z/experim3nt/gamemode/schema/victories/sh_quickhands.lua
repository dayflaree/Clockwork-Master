--[[
Name: "sh_quickhands.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Quickhands";
VICTORY.image = "victories/quickhands";
VICTORY.reward = 960;
VICTORY.maximum = 1;
VICTORY.description = "Get 100% dexterity without using boosts.\nReceive a reward of 960 codeks.";

VIC_QUICKHANDS = nexus.victory.Register(VICTORY);