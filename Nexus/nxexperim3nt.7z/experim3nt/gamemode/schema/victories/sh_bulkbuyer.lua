--[[
Name: "sh_bulkbuyer.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Bulkbuyer";
VICTORY.image = "victories/bulkbuyer";
VICTORY.reward = 160;
VICTORY.maximum = 10;
VICTORY.description = "Purchase ten shipments of equipment.\nReceive a reward of 160 codeks.";

VIC_BULKBUYER = nexus.victory.Register(VICTORY);