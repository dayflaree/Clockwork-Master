--[[
Name: "sh_freeman.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Freeman";
VICTORY.image = "victories/freeman";
VICTORY.reward = 80;
VICTORY.maximum = 1;
VICTORY.description = "Be the one to buy a shipment of crowbars.\nReceive a reward of 80 codeks.";

VIC_FREEMAN = nexus.victory.Register(VICTORY);