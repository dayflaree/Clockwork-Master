--[[
Name: "sh_saint_hunter.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Saint Hunter";
VICTORY.image = "victories/sainthunter";
VICTORY.reward = 320;
VICTORY.maximum = 20;
VICTORY.description = "Kill twenty characters who have good honor.\nReceive a reward of 320 codeks.";

VIC_SAINTHUNTER = nexus.victory.Register(VICTORY);