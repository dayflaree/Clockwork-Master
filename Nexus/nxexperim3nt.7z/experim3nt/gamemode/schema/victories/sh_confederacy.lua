--[[
Name: "sh_confederacy.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Confederacy";
VICTORY.image = "victories/confederacy";
VICTORY.reward = 400;
VICTORY.maximum = 20;
VICTORY.description = "Invite a total of twenty people into your alliance.\nReceive a reward of 400 codeks.";

VIC_CONFEDERACY = nexus.victory.Register(VICTORY);