--[[
Name: "sh_mike_tyson.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Mike Tyson";
VICTORY.image = "victories/miketyson";
VICTORY.reward = 960;
VICTORY.maximum = 1;
VICTORY.description = "Get 100% strength without using boosts.\nReceive a reward of 960 codeks.";

VIC_MIKETYSON = nexus.victory.Register(VICTORY);