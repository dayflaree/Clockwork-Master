--[[
Name: "sh_codekguy.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Codek Guy";
VICTORY.image = "victories/codekguy";
VICTORY.reward = 80;
VICTORY.maximum = 1;
VICTORY.description = "Get hold of over two hundred codeks.\nReceive a reward of 80 codeks.";

VIC_CODEKGUY = nexus.victory.Register(VICTORY);