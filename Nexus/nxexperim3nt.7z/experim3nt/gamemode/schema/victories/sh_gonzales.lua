--[[
Name: "sh_gonzales.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Gonzales";
VICTORY.image = "victories/gonzales";
VICTORY.reward = 960;
VICTORY.maximum = 1;
VICTORY.description = "Get 100% agility without using boosts.\nReceive a reward of 960 codeks.";

VIC_GONZALES = nexus.victory.Register(VICTORY);