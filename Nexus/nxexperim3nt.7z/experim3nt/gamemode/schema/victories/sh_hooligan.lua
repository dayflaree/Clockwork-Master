--[[
Name: "sh_hooligan.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Hooligan";
VICTORY.image = "victories/hooligan";
VICTORY.reward = 160;
VICTORY.maximum = 50;
VICTORY.description = "Destroy fifty of other character's props.\nReceive a reward of 160 codeks.";

VIC_HOOLIGAN = nexus.victory.Register(VICTORY);