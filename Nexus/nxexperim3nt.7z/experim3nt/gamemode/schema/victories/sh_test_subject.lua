--[[
Name: "sh_test_subject.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Test Subject";
VICTORY.image = "victories/testsubject";
VICTORY.reward = 240;
VICTORY.maximum = 5;
VICTORY.description = "Purchase a total of five augments.\nReceive a reward of 240 codeks.";

VIC_TESTSUBJECT = nexus.victory.Register(VICTORY);