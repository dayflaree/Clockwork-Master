--[[
Name: "sh_incarnate.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Incarnate";
VICTORY.image = "victories/incarnate";
VICTORY.reward = 80;
VICTORY.maximum = 1;
VICTORY.description = "Get the lowest possible honor.\nReceive a reward of 80 codeks.";

VIC_INCARNATE = nexus.victory.Register(VICTORY);