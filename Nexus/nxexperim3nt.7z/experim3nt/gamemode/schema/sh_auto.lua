--[[
Name: "sh_auto.lua".
Product: "eXperim3nt".
--]]

local modelGroups = {60, 61, 62};

for _, group in pairs(modelGroups) do
	for k, v in pairs( g_File.Find("../models/humans/group"..group.."/*.mdl") ) do
		if ( string.find(string.lower(v), "female") ) then
			nexus.animation.AddFemaleHumanModel("models/humans/group"..group.."/"..v);
		else
			nexus.animation.AddMaleHumanModel("models/humans/group"..group.."/"..v);
		end;
	end;
end;

for k, v in pairs( g_File.Find("../models/napalm_atc/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/napalm_atc/"..v);
end;

for k, v in pairs( g_File.Find("../models/nailgunner/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/nailgunner/"..v);
end;

for k, v in pairs( g_File.Find("../models/salem/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/salem/"..v);
end;

for k, v in pairs( g_File.Find("../models/bio_suit/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/bio_suit/"..v);
end;

for k, v in pairs( g_File.Find("../models/srp/*.mdl") ) do
	nexus.animation.AddMaleHumanModel("models/srp/"..v);
end;

nexus.animation.AddMaleHumanModel("models/humans/group03/male_experim.mdl");
nexus.animation.AddMaleHumanModel("models/pmc/pmc_4/pmc__07.mdl");
nexus.animation.AddMaleHumanModel("models/tactical_rebel.mdl");
nexus.animation.AddMaleHumanModel("models/riot_ex2.mdl");

local MODEL_SPX7 = nexus.animation.AddMaleHumanModel("models/spx7.mdl");
local MODEL_SPX2 = nexus.animation.AddMaleHumanModel("models/spx2.mdl");
local MODEL_SPEX = nexus.animation.AddMaleHumanModel("models/spex.mdl");
	nexus.animation.AddOverride(MODEL_SPX7, "stand_blunt_idle", "LineIdle03");
	nexus.animation.AddOverride(MODEL_SPX7, "stand_fist_idle", "LineIdle03");
	nexus.animation.AddOverride(MODEL_SPX2, "stand_blunt_idle", "LineIdle03");
	nexus.animation.AddOverride(MODEL_SPX2, "stand_fist_idle", "LineIdle03");
	nexus.animation.AddOverride(MODEL_SPEX, "stand_blunt_idle", "LineIdle03");
	nexus.animation.AddOverride(MODEL_SPEX, "stand_fist_idle", "LineIdle03");

nexus.schema.SetOption("description_attributes", "Check on your character's advantages.");
nexus.schema.SetOption("description_inventory", "Manage the items in your belongings.");
nexus.schema.SetOption("description_business", "Purchase a variety of equipment.");
nexus.schema.SetOption("html_background", "http://roleplayunion.com/bg.gif");
nexus.schema.SetOption("intro_image", "eXperim3nt/logo");
nexus.schema.SetOption("name_attributes", "Advantages");
nexus.schema.SetOption("name_attribute", "Advantage");
nexus.schema.SetOption("name_inventory", "Belongings");
nexus.schema.SetOption("name_business", "Equipment");
nexus.schema.SetOption("model_shipment", "models/props_junk/cardboard_box003b.mdl");
nexus.schema.SetOption("model_cash", "models/props_lab/box01a.mdl");
nexus.schema.SetOption("name_cash", "Codeks");
nexus.schema.SetOption("gradient", "eXperim3nt/gradient");

nexus.config.ShareKey("intro_text_small");
nexus.config.ShareKey("intro_text_big");
nexus.config.ShareKey("alliance_cost");

nexus.schema.SetFont("bar_text", "lab_TargetIDText");
nexus.schema.SetFont("main_text", "lab_MainText");
nexus.schema.SetFont("hints_text", "lab_IntroTextTiny");
nexus.schema.SetFont("large_3d_2d", "lab_Large3D2D");
nexus.schema.SetFont("chat_box_text", "lab_ChatBoxText");
nexus.schema.SetFont("target_id_text", "lab_TargetIDText");
nexus.schema.SetFont("cinematic_text", "lab_CinematicText");
nexus.schema.SetFont("date_time_text", "lab_IntroTextSmall");
nexus.schema.SetFont("menu_text_big", "lab_MenuTextBig");
nexus.schema.SetFont("menu_text_tiny", "lab_IntroTextTiny");
nexus.schema.SetFont("intro_text_big", "lab_IntroTextBig");
nexus.schema.SetFont("menu_text_small", "lab_IntroTextSmall");
nexus.schema.SetFont("intro_text_tiny", "lab_IntroTextTiny");
nexus.schema.SetFont("intro_text_small", "lab_IntroTextSmall");
nexus.schema.SetFont("player_info_text", "lab_ChatBoxText");

nexus.player.RegisterSharedVar("sh_BeingChloro", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Ghostheart", NWTYPE_BOOL);
nexus.player.RegisterSharedVar("sh_SkullMask", NWTYPE_BOOL);
nexus.player.RegisterSharedVar("sh_BeingTied", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Alliance", NWTYPE_STRING);
nexus.player.RegisterSharedVar("sh_Disguise", NWTYPE_ENTITY);
nexus.player.RegisterSharedVar("sh_Clothes", NWTYPE_NUMBER, true);
nexus.player.RegisterSharedVar("sh_Implant", NWTYPE_BOOL, true);
nexus.player.RegisterSharedVar("sh_Bounty", NWTYPE_NUMBER);
nexus.player.RegisterSharedVar("sh_Honor", NWTYPE_NUMBER);
nexus.player.RegisterSharedVar("sh_Rank", NWTYPE_NUMBER);
nexus.player.RegisterSharedVar("sh_Tied", NWTYPE_BOOL);

nexus.quiz.SetName("Agreement");
nexus.quiz.SetEnabled(true);
nexus.quiz.AddQuestion("I know that because of the logs, I will never get away with rule-breaking.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("When creating a character, I will use a full and appropriate name.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("I understand that the script has vast logs that are checked often.", 1, "Yes.", "No.");
nexus.quiz.AddQuestion("I will read the directory in the main menu for help and guides.", 1, "Yes.", "No.");

RANK_RCT = 0;
RANK_PVT = 1;
RANK_SGT = 2;
RANK_LT = 3;
RANK_CPT = 4;
RANK_MAJ = 5;

-- A function to get a player's honor text.
function SCHEMA:PlayerGetHonorText(player, honor)
	if (honor >= 90) then
		return "This character is like Jesus!";
	elseif (honor >= 80) then
		return "This character is divine."
	elseif (honor >= 70) then
		return "This character is blessed."
	elseif (honor >= 60) then
		return "This character is a nice guy.";
	elseif (honor >= 50) then
		return "This character is friendly.";
	elseif (honor >= 40) then
		return "This character is nasty.";
	elseif (honor >= 30) then
		return "This character is a bad guy.";
	elseif (honor >= 20) then
		return "This character is cursed.";
	elseif (honor >= 10) then
		return "This character is evil.";
	else
		return "This character is like Hitler!";
	end;
end;

NEXUS:IncludePrefixed("sh_coms.lua");
NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");

NEXUS:IncludeDirectory(NEXUS:GetSchemaFolder().."/gamemode/schema/libraries/");
NEXUS:IncludeDirectory(NEXUS:GetSchemaFolder().."/gamemode/schema/victories/");
NEXUS:IncludeDirectory(NEXUS:GetSchemaFolder().."/gamemode/schema/augments/");