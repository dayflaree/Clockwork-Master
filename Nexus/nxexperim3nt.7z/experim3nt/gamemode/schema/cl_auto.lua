--[[
Name: "cl_auto.lua".
Product: "eXperim3nt".
--]]

SCHEMA.lastHeartbeatAmount = 0;
SCHEMA.nextHeartbeatCheck = 0;
SCHEMA.heartbeatGradient = Material("gui/gradient_down");
SCHEMA.heartbeatOverlay = Material("effects/combine_binocoverlay");
SCHEMA.heartbeatPoints = {};
SCHEMA.nextGetSnipers = 0;
SCHEMA.scratchTexture = surface.GetTextureID("eXperim3nt/scratch");
SCHEMA.heartbeatPoint = Material("sprites/glow04_noz");
SCHEMA.dirtyTexture = surface.GetTextureID("eXperim3nt/dirty");
SCHEMA.damageNotify = {};
SCHEMA.laserSprite = Material("sprites/glow04_noz");
SCHEMA.hotkeyItems = NEXUS:RestoreSchemaData("hotkeys");
SCHEMA.stunEffects = {};

NEXUS:IncludePrefixed("sh_auto.lua");

surface.CreateFont("Subway Haze", ScaleToWideScreen(2048), 600, true, false, "lab_Large3D2D");
surface.CreateFont("Subway Haze", ScaleToWideScreen(32), 600, true, false, "lab_IntroTextSmall");
surface.CreateFont("Subway Haze", ScaleToWideScreen(22), 600, true, false, "lab_IntroTextTiny");
surface.CreateFont("Subway Haze", ScaleToWideScreen(32), 600, true, false, "lab_CinematicText");
surface.CreateFont("Subway Haze", ScaleToWideScreen(62), 600, true, false, "lab_IntroTextBig");
surface.CreateFont("Subway Haze", ScaleToWideScreen(22), 600, true, false, "lab_TargetIDText");
surface.CreateFont("Subway Haze", ScaleToWideScreen(12), 600, true, false, "lab_SmallBarText");
surface.CreateFont("Subway Haze", ScaleToWideScreen(74), 600, true, false, "lab_MenuTextBig");
surface.CreateFont("Subway Haze", ScaleToWideScreen(18), 600, true, false, "lab_ChatBoxText");
surface.CreateFont("Subway Haze", ScaleToWideScreen(20), 600, true, false, "lab_MainText");

nexus.config.SetOverwatch("intro_text_small", "The small text displayed for the introduction.");
nexus.config.SetOverwatch("intro_text_big", "The big text displayed for the introduction.");
nexus.config.SetOverwatch("alliance_cost", "The amount of cash it costs to create an alliance.", 0, 10000);

usermessage.Hook("nx_Frequency", function(msg)
	Derma_StringRequest("Frequency", "What would you like to set the frequency to?", msg:ReadString(), function(text)
		NEXUS:RunCommand("SetFreq", text);
	end);
end);

NEXUS:HookDataStream("Notepad", function(data)
	if ( SCHEMA.notepadPanel and SCHEMA.notepadPanel:IsValid() ) then
		SCHEMA.notepadPanel:Close();
		SCHEMA.notepadPanel:Remove();
	end;
	
	SCHEMA.notepadPanel = vgui.Create("nx_Notepad");
	SCHEMA.notepadPanel:Populate(data or "");
	SCHEMA.notepadPanel:MakePopup();
	
	gui.EnableScreenClicker(true);
end);

usermessage.Hook("nx_HotkeyMenu", function(msg)
	local hotkeyItems = {};
	
	for k, v in pairs(SCHEMA.hotkeyItems) do
		local itemTable = nexus.item.Get(v);
		
		if (itemTable and itemTable.OnUse) then
			hotkeyItems[#hotkeyItems + 1] = itemTable;
		end;
	end;
	
	if (hotkeyItems) then
		local options = {};
		
		for k, v in ipairs(hotkeyItems) do
			options["1. "..v.name] = function()
				if (v.OnHandleUse) then
					v:OnHandleUse(function()
						NEXUS:RunCommand("InvAction", v.uniqueID, "use");
					end);
				else
					NEXUS:RunCommand("InvAction", v.uniqueID, "use");
				end;
			end;
		end;
		
		SCHEMA.hotkeyMenu = NEXUS:AddMenuFromData(nil, options);
		
		if ( IsValid(SCHEMA.hotkeyMenu) ) then
			SCHEMA.hotkeyMenu:SetPos(
				(ScrW() / 2) - (SCHEMA.hotkeyMenu:GetWide() / 2),
				(ScrH() / 2) - (SCHEMA.hotkeyMenu:GetTall() / 2)
			);
		end;
	end;
end);

usermessage.Hook("nx_DealDmg", function(msg)
	local duration = 2;
	local curTime = UnPredictedCurTime();
	local entity = msg:ReadEntity();
	local amount = msg:ReadShort();
	
	if ( IsValid(entity) and entity:IsPlayer() ) then
		SCHEMA.damageNotify[#SCHEMA.damageNotify + 1] = {
			position = entity:GetShootPos() + ( Vector() * math.random(-5, 5) ),
			duration = duration,
			endTime = curTime + duration,
			color = Color(179, 46, 49, 255),
			text = amount.."dmg"
		};
	end;
end);

usermessage.Hook("nx_TakeDmg", function(msg)
	local duration = 2;
	local curTime = UnPredictedCurTime();
	local entity = msg:ReadEntity();
	local amount = msg:ReadShort();
	
	if ( IsValid(entity) and entity:IsPlayer() ) then
		SCHEMA.damageNotify[#SCHEMA.damageNotify + 1] = {
			position = entity:GetShootPos() + ( Vector() * math.random(-5, 5) ),
			duration = duration,
			endTime = curTime + duration,
			color = Color(139, 174, 179, 255),
			text = amount.."dmg"
		};
	end;
end);

usermessage.Hook("nx_Disguise", function(msg)
	Derma_StringRequest("Disguise", "Enter part of the character's name that you'd like to disguise as.", "", function(text)
		NEXUS:RunCommand("DisguiseSet", text);
	end);
end);

NEXUS:HookDataStream("InviteAlliance", function(data)
	Derma_Query("Do you want to join the '"..data.."' alliance?", "Join Alliance", "Yes", function()
		NEXUS:StartDataStream("JoinAlliance", data);
		
		gui.EnableScreenClicker(false);
	end, "No", function()
		gui.EnableScreenClicker(false);
	end);
	
	gui.EnableScreenClicker(true);
end);

NEXUS:HookDataStream("AllyKick", function(data)
	data:SetSharedVar("sh_Alliance", "");
	data:SetSharedVar("sh_Rank", RANK_RCT);
	
	if ( IsValid(SCHEMA.alliancePanel) ) then
		SCHEMA.alliancePanel:Rebuild();
	end;
end);

NEXUS:HookDataStream("AllySetRank", function(data)
	data[1]:SetSharedVar( "sh_Rank", data[2] );
	
	if ( IsValid(SCHEMA.alliancePanel) ) then
		SCHEMA.alliancePanel:Rebuild();
	end;
end);

usermessage.Hook("nx_CreateAlliance", function(msg)
	Derma_StringRequest("Alliance", "What is the name of the alliance?", nil, function(text)
		NEXUS:StartDataStream("CreateAlliance", text);
	end);
end);

usermessage.Hook("nx_Death", function(msg)
	local weapon = msg:ReadEntity();
	
	if ( !IsValid(weapon) ) then
		SCHEMA.deathType = "UNKNOWN CAUSES";
	else
		local itemTable = nexus.item.GetWeapon(weapon);
		local class = weapon:GetClass();
		
		if (itemTable) then
			SCHEMA.deathType = "A "..string.upper(itemTable.name);
		elseif (class == "nx_hands") then
			SCHEMA.deathType = "BEING PUNCHED TO DEATH";
		else
			SCHEMA.deathType = "UNKNOWN CAUSES";
		end;
	end;
end);

usermessage.Hook("nx_ShotEffect", function(msg)
	local duration = msg:ReadFloat();
	local curTime = CurTime();
	
	if (!duration or duration == 0) then
		duration = 0.5;
	end;
	
	SCHEMA.shotEffect = {curTime + duration, duration};
end);

usermessage.Hook("nx_TearGassed", function(msg)
	SCHEMA.tearGassed = CurTime() + 20;
end);

usermessage.Hook("nx_Flashed", function(msg)
	local curTime = CurTime();
	
	SCHEMA.stunEffects[#SCHEMA.stunEffects + 1] = {curTime + 10, 10};
	SCHEMA.flashEffect = {curTime + 20, 20};
	
	surface.PlaySound("hl1/fvox/flatline.wav");
end);

usermessage.Hook("nx_ClearEffects", function(msg)
	SCHEMA.stunEffects = {};
	SCHEMA.flashEffect = nil;
	SCHEMA.tearGassed = nil;
	SCHEMA.shotEffect = nil;
end);

nexus.chatBox.RegisterClass("radio", "ic", function(info)
	nexus.chatBox.Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." radios in \""..info.text.."\"");
end);

nexus.chatBox.RegisterClass("victory", "ooc", function(info)
	nexus.chatBox.Add(info.filtered, {"gui/silkicons/star", "*"}, info.speaker, " has achieved the ", Color(139, 174, 179, 255), info.text, " victory!");
end);

local playerMeta = FindMetaTable("Player");

-- A function to get whether a player is good.
function playerMeta:IsGood()
	return self:GetSharedVar("sh_Honor") >= 50;
end;

-- A function to get whether a player is bad.
function playerMeta:IsBad()
	return self:GetSharedVar("sh_Honor") < 50;
end;

-- A function to get a player's bounty.
function playerMeta:GetBounty()
	return self:GetSharedVar("sh_Bounty");
end;

-- A function to get whether a player is wanted.
function playerMeta:IsWanted()
	return self:GetSharedVar("sh_Bounty") > 0;
end;

-- A function to get whether a player is a leader.
function playerMeta:IsLeader()
	return self:GetSharedVar("sh_Rank") == RANK_MAJ;
end;

-- A function to get a player's rank.
function playerMeta:GetRank(bString)
	local rank = self:GetSharedVar("sh_Rank");
	
	if (bString) then
		if (rank == RANK_PVT) then
			return "Pvt";
		elseif (rank == RANK_SGT) then
			return "Sgt";
		elseif (rank == RANK_LT) then
			return "Lt";
		elseif (rank == RANK_CPT) then
			return "Cpt";
		elseif (rank == RANK_MAJ) then
			return "Maj";
		else
			return "Rct";
		end;
	else
		return rank;
	end;
end;

-- A function to get a player's alliance.
function playerMeta:GetAlliance()
	local alliance = self:GetSharedVar("sh_Alliance");
	
	if (alliance != "") then
		return alliance;
	end;
end;

-- A function to get whether a text entry is being used.
function SCHEMA:IsTextEntryBeingUsed()
	if (self.textEntryFocused) then
		if ( self.textEntryFocused:IsValid() and self.textEntryFocused:IsVisible() ) then
			return true;
		end;
	end;
end;