--[[
Name: "sh_auto.lua".
Product: "eXperim3nt".
--]]

ENT.Type = "anim";
ENT.Base = "nx_generator";
ENT.Model = "models/props_lab/reciever01a.mdl";
ENT.PrintName = "Codek Producer";
ENT.PhysgunDisabled = true;