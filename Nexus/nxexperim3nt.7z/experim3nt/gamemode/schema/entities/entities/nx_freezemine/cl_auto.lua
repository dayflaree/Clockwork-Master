--[[
Name: "cl_auto.lua".
Product: "eXperim3nt".
--]]

NEXUS:IncludePrefixed("sh_auto.lua")

-- Called when the target ID HUD should be painted.
function ENT:HUDPaintTargetID(x, y, alpha)
	local colorTargetID = nexus.schema.GetColor("target_id");
	local colorWhite = nexus.schema.GetColor("white");
	
	y = NEXUS:DrawInfo("Freezemine", x, y, colorTargetID, alpha);
	
	if (g_LocalPlayer:GetPos():Distance( self:GetPos() ) <= 80) then
		y = NEXUS:DrawInfo("You can defuse it from here.", x, y, colorWhite, alpha);
	else
		y = NEXUS:DrawInfo("Damaging it would be dangerous", x, y, colorWhite, alpha);
	end;
end;

-- Called when the entity should draw.
function ENT:Draw()
	SCHEMA:NexusGeneratorEntityDraw( self, Color(0, 0, 255, 5) );
	self:DrawModel();
end;