--[[
Name: "sv_auto.lua".
Product: "eXperim3nt".
--]]

NEXUS:IncludePrefixed("sh_auto.lua");

resource.AddFile("models/humans/group03/male_experim.mdl");
resource.AddFile("materials/victories/achieved.vtf");
resource.AddFile("materials/victories/achieved.vmt");
resource.AddFile("materials/augments/purchased.vtf");
resource.AddFile("materials/augments/purchased.vmt");
resource.AddFile("materials/eXperim3nt/gradient.vtf");
resource.AddFile("materials/eXperim3nt/gradient.vmt");
resource.AddFile("materials/eXperim3nt/scratch.vtf");
resource.AddFile("materials/eXperim3nt/scratch.vmt");
resource.AddFile("materials/eXperim3nt/dirty.vtf");
resource.AddFile("materials/eXperim3nt/dirty.vmt");
resource.AddFile("resource/fonts/subwayhaze.ttf");
resource.AddFile("models/pmc/pmc_3/pmc__07.mdl");
resource.AddFile("models/pmc/pmc_3/pmc__04.mdl");
resource.AddFile("models/tactical_rebel.mdl");
resource.AddFile("models/riot_ex2.mdl");
resource.AddFile("models/sprayca2.mdl");
resource.AddFile("models/spx7.mdl");
resource.AddFile("models/spx2.mdl");
resource.AddFile("models/spex.mdl");

for k, v in pairs( g_File.Find("../materials/models/player/slow/aot/salem/*.*") ) do
	resource.AddFile("materials/models/player/slow/aot/salem/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/player/slow/napalm_atc/*.*") ) do
	resource.AddFile("materials/models/player/slow/napalm_atc/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/player/slow/nailgunner/*.*") ) do
	resource.AddFile("materials/models/player/slow/nailgunner/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/player/slow/bio_suit/*.*") ) do
	resource.AddFile("materials/models/player/slow/bio_suit/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/group01/labcit*.*") ) do
	resource.AddFile("materials/models/humans/male/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/female/group01/labcit*.*") ) do
	resource.AddFile("materials/models/humans/female/group01/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/humans/male/experim/*.*") ) do
	resource.AddFile("materials/models/humans/male/experim/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/player/riex/*.*") ) do
	resource.AddFile("materials/models/player/riex/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/pmc/pmc_shared/*.*") ) do
	resource.AddFile("materials/models/pmc/pmc_shared/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/gasmask/tac_rbe/*.*") ) do
	resource.AddFile("materials/models/gasmask/tac_rbe/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/kevlarvest/*.*") ) do
	resource.AddFile("materials/models/kevlarvest/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/stalker/sx/*.*") ) do
	resource.AddFile("materials/models/stalker/sx/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/stalker/mx/*.*") ) do
	resource.AddFile("materials/models/stalker/mx/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/stalker/fx/*.*") ) do
	resource.AddFile("materials/models/stalker/fx/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/stalker/dx/*.*") ) do
	resource.AddFile("materials/models/stalker/dx/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/banditv/*.*") ) do
	resource.AddFile("materials/models/banditv/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/pmc/pmc_4/*.*") ) do
	resource.AddFile("materials/models/pmc/pmc_4/"..v);
end;

for k, v in pairs( g_File.Find("../materials/models/h3_spartan/*.*") ) do
	resource.AddFile("materials/models/h3_spartan/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group60/*.mdl") ) do
	resource.AddFile("models/humans/group60/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group61/*.mdl") ) do
	resource.AddFile("models/humans/group61/"..v);
end;

for k, v in pairs( g_File.Find("../models/humans/group62/*.mdl") ) do
	resource.AddFile("models/humans/group62/"..v);
end;

for k, v in pairs( g_File.Find("../models/kevlarvest/*.mdl") ) do
	resource.AddFile("models/kevlarvest/"..v);
end;

for k, v in pairs( g_File.Find("../materials/victories/*.*") ) do
	resource.AddFile("materials/victories/"..v);
end;

for k, v in pairs( g_File.Find("../models/napalm_atc/*.mdl") ) do
	resource.AddFile("models/napalm_atc/"..v);
end;

for k, v in pairs( g_File.Find("../models/nailgunner/*.mdl") ) do
	resource.AddFile("models/nailgunner/"..v);
end;

for k, v in pairs( g_File.Find("../materials/augments/*.*") ) do
	resource.AddFile("materials/augments/"..v);
end;

for k, v in pairs( g_File.Find("../models/salem/*.mdl") ) do
	resource.AddFile("models/salem/"..v);
end;

for k, v in pairs( g_File.Find("../models/bio_suit/*.mdl") ) do
	resource.AddFile("models/bio_suit/"..v);
end;

for k, v in pairs( g_File.Find("../models/srp/*.mdl") ) do
	resource.AddFile("models/srp/"..v);
end;

nexus.config.Add("intro_text_small", "You're back, and this time you signed a contract.", true);
nexus.config.Add("intro_text_big", "AN APERTURE SCIENCE EXPERIMENT.", true);
nexus.config.Add("alliance_cost", 2000, true);

nexus.config.Get("scale_attribute_progress"):Set(0.5);
nexus.config.Get("enable_gravgun_punt"):Set(false);
nexus.config.Get("default_inv_weight"):Set(8);
nexus.config.Get("armor_chest_only"):Set(true);
nexus.config.Get("enable_crosshair"):Set(false);
nexus.config.Get("minimum_physdesc"):Set(16);
nexus.config.Get("scale_prop_cost"):Set(0.2);
nexus.config.Get("disable_sprays"):Set(false);
nexus.config.Get("wages_interval"):Set(360);
nexus.config.Get("default_cash"):Set(120);

nexus.hint.Add("Admins", "The admins are here to help you, please respect them.");
nexus.hint.Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
nexus.hint.Add("Healing", "You can heal players by using the Give command in your belongings.");
nexus.hint.Add("Healing", "You will gain honor for healing good characters with medical equipment.");
nexus.hint.Add("Zip Tie", "Press F3 while looking at a character to use a zip tie.");
nexus.hint.Add("Alliance", "You can create an alliance by using the command $command_prefix$AllyCreate.");
nexus.hint.Add("F4 Hotkey", "Press F4 to open up the hotkey menu, you can bind hotkeys in your belongings.");
nexus.hint.Add("Search Char", "Press F3 while looking at a tied character to search them.");

NEXUS:HookDataStream("JoinAlliance", function(player, data)
	if (player.allianceAuthenticate == data) then
		local alliances = player:GetTempData("alliances");
		
		if (!alliances) then
			player:SetTempData( "alliances", {} );
			alliances = player:GetTempData("alliances");
		end;
		
		player:SetRank(RANK_RCT);
		player:SetAlliance(data);
		
		if ( !alliances[data] and IsValid(player.allianceInviter) ) then
			nexus.victories.Progress(player.allianceInviter, VIC_THEDON);
			nexus.victories.Progress(player.allianceInviter, VIC_CONFEDERACY);
			alliances[data] = true;
		end;
		
		nexus.player.Notify(player, "You have joined the '"..data.."' alliance.");
	end;
end);

NEXUS:HookDataStream("Notepad", function(player, data)
	if ( type(data) == "string" and player:HasItem("notepad") ) then
		player:SetCharacterData( "notepad", string.sub(data, 0, 500) );
	end;
end);


NEXUS:HookDataStream("BountyAdd", function(player, data)
	nexus.player.RunNexusCommand( player, "Bounty", tostring(data.name), tostring(data.bounty) );
end);

NEXUS:HookDataStream("GetAugment", function(player, data)
	local augmentTable = nexus.augment.Get(data);
	
	if (augmentTable) then
		if ( nexus.player.CanAfford(player, augmentTable.cost) ) then
			nexus.augments.Give(player, augmentTable.uniqueID);
			
			nexus.player.GiveCash(player, -augmentTable.cost, augmentTable.name);
			nexus.player.Notify(player, "You have gotten the '"..augmentTable.name.."' augment.");
		else
			nexus.player.Notify(player, "You need another "..FORMAT_CASH(augmentTable.cost - nexus.player.GetCash(player), nil, true).."!");
		end;
	end;
end);

NEXUS:HookDataStream("AllyKick", function(player, data)
	if ( player:IsLeader() and IsValid(data) and !data:IsLeader() ) then
		local alliance = player:GetAlliance();
		
		if ( alliance == data:GetAlliance() ) then
			data:SetRank(RANK_RCT);
			data:SetAlliance("");
			
			nexus.player.Notify(player, "You have kicked "..data:Name().." from the '"..alliance.."' alliance.");
			nexus.player.Notify(data, player:Name().." has kicked you from the '"..alliance.."' alliance.");
		
			NEXUS:StartDataStream(player, "AllyKick", data);
		end;
	end;
end);

NEXUS:HookDataStream("AllyMakeLeader", function(player, data)
	if ( player:IsLeader() and IsValid(data) and !data:IsLeader() ) then
		local alliance = player:GetAlliance();
		
		if ( alliance == data:GetAlliance() ) then
			data:SetRank(RANK_MAJ);
			
			nexus.player.Notify(player, "You have made "..data:Name().." a leader of the '"..alliance.."' alliance.");
			nexus.player.Notify(data, player:Name().." has made you a leader of the '"..alliance.."' alliance.");
		
			NEXUS:StartDataStream( player, "AllySetRank", {data, RANK_MAJ} );
		end;
	end;
end);

NEXUS:HookDataStream("AllySetRank", function(player, data)
	if ( player:IsLeader() and IsValid( data[1] ) and !data[1]:IsLeader() ) then
		if ( player:GetAlliance() == data[1]:GetAlliance() ) then
			local rank = tonumber( data[2] );
			
			if (rank and rank >= 0 and rank < 5) then
				data[1]:SetRank(rank);
				
				nexus.player.Notify(player, "You have set "..data[1]:Name().."'s rank to "..data[1]:GetRank(true)..".");
				nexus.player.Notify(data[1], player:Name().." has set your rank within the alliance to "..data[1]:GetRank(true)..".");
			
				NEXUS:StartDataStream(player, "AllySetRank", data);
			end;
		end;
	end;
end);

NEXUS:HookDataStream("CreateAlliance", function(player, data)
	if (type(data) == "string") then
		local charactersTable = nexus.config.Get("mysql_characters_table"):Get();
		local schemaFolder = NEXUS:GetSchemaFolder();
		local alliance = tmysql.escape( string.gsub(string.sub(data, 1, 32), "[%p%d]", "") );
		
		tmysql.query("SELECT * FROM "..charactersTable.." WHERE _Schema = \""..schemaFolder.."\" AND _Data LIKE \"%\\\"alliance\\\":\\\""..alliance.."\\\"\"%", function(result)
			if ( IsValid(player) ) then
				local allianceCost = nexus.config.Get("alliance_cost"):Get();
				
				if (result and type(result) == "table" and #result > 0) then
					nexus.player.Notify(player, "An alliance with the name '"..alliance.."' already exists!");
				elseif ( nexus.player.CanAfford(player, allianceCost) ) then
					player:SetRank(RANK_MAJ);
					player:SetAlliance(alliance);
					
					nexus.player.GiveCash(player, -allianceCost, "creating an alliance");
					nexus.player.Notify(player, "You have created the '"..alliance.."' alliance.");
				else
					nexus.player.Notify(player, "You need another "..FORMAT_CASH(allianceCost - nexus.player.GetCash(player), nil, true).."!");
				end;
			end;
		end, 1);
	end;
end);

local playerMeta = FindMetaTable("Player");

-- A function to get whether a player is good.
function playerMeta:IsGood()
	return self:GetCharacterData("honor") >= 50;
end;

-- A function to get whether a player is bad.
function playerMeta:IsBad()
	return self:GetCharacterData("honor") < 50;
end;

-- A function to get a player's bounty.
function playerMeta:GetBounty()
	return self:GetCharacterData("bounty");
end;

-- A function to get whether a player is wanted.
function playerMeta:IsWanted()
	return self:GetCharacterData("bounty") > 0;
end;

-- A function to add to a player's bounty.
function playerMeta:AddBounty(bounty)
	self:SetCharacterData("bounty", self:GetCharacterData("bounty") + bounty);
end;

-- A function to remove a player's bounty.
function playerMeta:RemoveBounty()
	self:SetCharacterData("bounty", 0);
end;

-- A function to handle a player's honor.
function playerMeta:HandleHonor(honor)
	if ( honor < 0 and nexus.augments.Has(self, AUG_CURSED) ) then
		honor = honor * 2;
	elseif ( honor > 0 and nexus.augments.Has(self, AUG_FAVORED) ) then
		honor = honor * 2;
	end;
	
	self:SetCharacterData( "honor", math.Clamp(self:GetCharacterData("honor") + honor, 0, 100) );
	
	if (self:GetCharacterData("honor") == 100) then
		nexus.victories.Progress(self, VIC_ANGELIC);
	elseif (self:GetCharacterData("honor") == 0) then
		nexus.victories.Progress(self, VIC_INCARNATE);
	end;
end;

-- A function to get whether a player is a leader.
function playerMeta:IsLeader()
	return self:GetCharacterData("rank") == RANK_MAJ;
end;

-- A function to set a player's rank.
function playerMeta:SetRank(rank)
	self:SetCharacterData("rank", rank);
	self:SetSharedVar("sh_Rank", rank);
end;

-- A function to set a player's alliance.
function playerMeta:SetAlliance(alliance)
	self:SetCharacterData("alliance", alliance);
	self:SetSharedVar("sh_Alliance", alliance);
end;

-- A function to get a player's alliance.
function playerMeta:GetAlliance()
	local alliance = self:GetCharacterData("alliance");
	
	if (alliance != "") then
		return alliance;
	end;
end;

-- A function to get a player's rank.
function playerMeta:GetRank(bString)
	local rank = self:GetCharacterData("rank");
	
	if (bString) then
		if (rank == RANK_PVT) then
			return "Pvt";
		elseif (rank == RANK_SGT) then
			return "Sgt";
		elseif (rank == RANK_LT) then
			return "Lt";
		elseif (rank == RANK_CPT) then
			return "Cpt";
		elseif (rank == RANK_MAJ) then
			return "Maj";
		else
			return "Rct";
		end;
	else
		return rank;
	end;
end;

-- A function to make an explosion.
function SCHEMA:MakeExplosion(position, scale)
	local explosionEffect = EffectData();
	local smokeEffect = EffectData();
	
	explosionEffect:SetOrigin(position);
	explosionEffect:SetScale(scale);
	smokeEffect:SetOrigin(position);
	smokeEffect:SetScale(scale);
	
	util.Effect("explosion", explosionEffect, true, true);
	util.Effect("nx_effect_smoke", smokeEffect, true, true);
end;

-- A function to load the static props.
function SCHEMA:LoadStaticProps()
	self.staticProps = NEXUS:RestoreSchemaData( "mounts/props/"..game.GetMap() );
	
	for k, v in pairs(self.staticProps) do
		local entity = ents.Create("prop_physics");
		
		entity:SetAngles(v.angles);
		entity:SetModel(v.model);
		entity:SetPos(v.position);
		entity:Spawn();
		
		entity.PhysgunDisabled = true;
		entity.CanTool = function(entity, player, trace, tool)
			return false;
		end;
		
		if ( IsValid( entity:GetPhysicsObject() ) ) then
			entity:GetPhysicsObject():EnableMotion(false);
		end;
		
		self.staticProps[k] = entity;
	end;
end;

-- A function to save the static props.
function SCHEMA:SaveStaticProps()
	local staticProps = {};
	
	for k, v in pairs(self.staticProps) do
		if ( IsValid(v) ) then
			staticProps[#staticProps + 1] = {
				model = v:GetModel(),
				angles = v:GetAngles(),
				position = v:GetPos()
			};
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/props/"..game.GetMap(), staticProps);
end;

-- A function to get a player's gear.
function SCHEMA:GetPlayerGear(player, class)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		return player[uniqueID];
	end;
end;

-- A function to create a player's gear.
function SCHEMA:CreatePlayerGear(player, class, itemTable)
	local uniqueID = NEXUS:SetCamelCase(class.."Gear");
	
	if ( IsValid( player[uniqueID] ) ) then
		player[uniqueID]:Remove();
	end;
	
	if (itemTable.isAttachment) then
		local position = player:GetPos();
		local angles = player:GetAngles();
		local model = itemTable.model;
		
		if (itemTable.attachmentModel) then
			model = itemTable.attachmentModel;
		end;
		
		player[uniqueID] = ents.Create("nx_gear");
		player[uniqueID]:SetParent(player);
		player[uniqueID]:SetAngles(angles);
		player[uniqueID]:SetColor(255, 255, 255, 0);
		player[uniqueID]:SetModel(model);
		player[uniqueID]:SetPos(position);
		player[uniqueID]:Spawn();
		
		if (itemTable.color) then
			player[uniqueID]:SetColor( NEXUS:UnpackColor(itemTable.color) );
		end;
		
		if (itemTable.material) then
			player[uniqueID]:SetMaterial(material);
		end;
		
		if ( IsValid( player[uniqueID] ) ) then
			player[uniqueID]:SetOwner(player);
			player[uniqueID]:SetItem(itemTable);
		end;
	end;
end;

-- A function to make a player wear clothes.
function SCHEMA:PlayerWearClothes(player, itemTable)
	local clothes = player:GetCharacterData("clothes");
	local team = player:Team();
	
	if (itemTable) then
		itemTable:OnChangeClothes(player, true);
		
		player:SetCharacterData("clothes", itemTable.index);
		player:SetSharedVar("sh_Clothes", itemTable.index);
	else
		itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
			player:SetSharedVar("sh_Clothes", 0);
		end;
	end;
	
	if (itemTable) then
		player:UpdateInventory(itemTable.uniqueID);
	end;
end;

-- A function to get a player's heal amount.
function SCHEMA:GetHealAmount(player, scale)
	return ( 15 + nexus.attributes.Fraction(player, ATB_DEXTERITY, 35) ) * (scale or 1);
end;

-- A function to get a player's dexterity time.
function SCHEMA:GetDexterityTime(player)
	return 7 - nexus.attributes.Fraction(player, ATB_DEXTERITY, 5, 5);
end;

-- A function to bust down a door.
function SCHEMA:BustDownDoor(player, door, force)
	door.bustedDown = true;
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if ( IsValid(physicsObject) ) then
		if (!force) then
			if ( IsValid(player) ) then
				physicsObject:ApplyForceCenter( ( door:GetPos() - player:GetPos() ):Normalize() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	nexus.entity.Decay(fakeDoor, 300);
	
	NEXUS:CreateTimer("Reset Door: "..door:EntIndex(), 300, 1, function()
		if ( IsValid(door) ) then
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
			door.bustedDown = nil;
		end;
	end);
end;

-- A function to load the belongings.
function SCHEMA:LoadBelongings()
	local belongings = NEXUS:RestoreSchemaData( "mounts/belongings/"..game.GetMap() );
	
	for k, v in pairs(belongings) do
		local entity = ents.Create("nx_belongings");
		
		if ( v.inventory["human_meat"] ) then
			v.inventory["human_meat"] = nil;
		end;
		
		entity:SetAngles(v.angles);
		entity:SetData(v.inventory, v.cash);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if ( IsValid(physicsObject) ) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the belongings.
function SCHEMA:SaveBelongings()
	local belongings = {};
	
	for k, v in pairs( ents.FindByClass("prop_ragdoll") ) do
		if (v.areBelongings) then
			if (v.cash > 0 or table.Count(v.inventory) > 0) then
				belongings[#belongings + 1] = {
					cash = v.cash,
					angles = Angle(0, 0, -90),
					moveable = true,
					position = v:GetPos() + Vector(0, 0, 32),
					inventory = v.inventory
				};
			end;
		end;
	end;
	
	for k, v in pairs( ents.FindByClass("nx_belongings") ) do
		if ( v.cash and v.inventory and (v.cash > 0 or table.Count(v.inventory) > 0) ) then
			local physicsObject = v:GetPhysicsObject();
			local moveable;
			
			if ( IsValid(physicsObject) ) then
				moveable = physicsObject:IsMoveable();
			end;
			
			belongings[#belongings + 1] = {
				cash = v.cash,
				angles = v:GetAngles(),
				moveable = moveable,
				position = v:GetPos(),
				inventory = v.inventory
			};
		end;
	end;
	
	NEXUS:SaveSchemaData("mounts/belongings/"..game.GetMap(), belongings);
end;

-- A function to make a player drop random items.
function SCHEMA:PlayerDropRandomItems(player, ragdoll)
	local inventory = nexus.player.GetInventory(player);
	local clothes = player:GetCharacterData("clothes");
	local cash = nexus.player.GetCash(player);
	local info = {
		inventory = {},
		cash = cash
	};
	
	if ( !IsValid(ragdoll) ) then
		info.entity = ents.Create("nx_belongings");
	end;
	
	for k, v in pairs(inventory) do
		local itemTable = nexus.item.Get(k);
		
		if (itemTable and !itemTable.isRareItem) then
			if (itemTable.allowStorage != false) then
				if (clothes == itemTable.index) then
					v = v - 1;
				end;
				
				if (v > 0) then
					local success, fault = player:UpdateInventory(k, -v, true, true);
					
					if (success) then
						info.inventory[k] = v;
					end;
				end;
			end;
		end;
	end;
	
	player:SetCharacterData("cash", 0, true);
	
	if ( !IsValid(ragdoll) ) then
		if (table.Count(info.inventory) > 0 or info.cash > 0) then
			info.entity:SetAngles( Angle(0, 0, -90) );
			info.entity:SetData(info.inventory, info.cash);
			info.entity:SetPos( player:GetPos() + Vector(0, 0, 48) );
			info.entity:Spawn();
		else
			info.entity:Remove();
		end;
	else
		ragdoll.areBelongings = true;
		ragdoll.inventory = info.inventory;
		ragdoll.cash = info.cash;
	end;
	
	nexus.player.SaveCharacter(player);
end;

-- A function to tie or untie a player.
function SCHEMA:TiePlayer(player, boolean, reset, government)
	player:SetSharedVar("sh_Tied", boolean == true);
	
	if (boolean) then
		nexus.player.DropWeapons(player);
		
		NEXUS:PrintDebug(player:Name().." has been tied.");
		
		player:Flashlight(false);
		player:StripWeapons();
	elseif (!reset) then
		if ( player:Alive() and !player:IsRagdolled() ) then 
			nexus.player.LightSpawn(player, true, true);
		end;
		
		NEXUS:PrintDebug(player:Name().." has been untied.");
	end;
end;