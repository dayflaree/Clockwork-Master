--[[
Name: "sh_hooks.lua".
Product: "eXperim3nt".
--]]

-- Called when a player attempts to use a lowered weapon.
function SCHEMA:PlayerCanUseLoweredWeapon(player, weapon, secondary)
	if ( secondary and (weapon.SilenceTime or weapon.PistolBurst) ) then
		return true;
	end;
end;

-- Called when a player switches their flashlight on or off.
function SCHEMA:PlayerSwitchFlashlight(player, on)
	return false;
end;

-- Called when a player's death info should be adjusted.
function SCHEMA:PlayerAdjustDeathInfo(player, info)
	if ( nexus.augments.Has(player, AUG_REINCARNATION) ) then
		info.spawnTime = info.spawnTime * 0.25;
	end;
end;

-- Called each tick.
function SCHEMA:Tick()
	local curTime = CurTime();
	
	if (!self.nextCleanDecals or curTime >= self.nextCleanDecals) then
		self.nextCleanDecals = curTime + 60;
		
		for k, v in ipairs( g_Player.GetAll() ) do
			v:RunCommand("r_cleardecals");
		end;
	end;
end;

-- Called when a player uses an unknown item function.
function SCHEMA:PlayerUseUnknownItemFunction(player, itemTable, itemFunction)
	if (itemFunction == "Cash" and itemTable.cost) then
		local useSounds = {"buttons/button5.wav", "buttons/button4.wav"};
		local cashBack = itemTable.cost;
		
		if ( nexus.augments.Has(player, AUG_BLACKMARKET) ) then
			cashBack = cashBack * 0.2;
		elseif ( nexus.augments.Has(player, AUG_CASHBACK) ) then
			cashBack = cashBack * 0.25;
		else
			return;
		end;
		
		player:UpdateInventory(itemTable.uniqueID, -1, true);
		player:EmitSound( useSounds[ math.random(1, #useSounds) ] );
		
		nexus.player.GiveCash(player, cashBack, "cashed an item");
	end;
end;

-- Called when a player attempts to spawn a prop.
function SCHEMA:PlayerSpawnProp(player, model)
	model = string.Replace(model, "\\", "/");
	model = string.Replace(model, "//", "/");
	model = string.lower(model);
	
	if ( string.find(model, "fence") ) then
		nexus.player.Notify(player, "You cannot spawn fence props!");
		
		return false;
	end;
end;

-- Called when a player's character has initialized.
function SCHEMA:PlayerCharacterInitialized(player)
	umsg.Start("nx_VictoriesClear", player);
	umsg.End();
	
	umsg.Start("nx_AugmentsClear", player);
	umsg.End();
	
	for k, v in pairs( player:GetCharacterData("victories") ) do
		local victoryTable = nexus.victory.Get(k);
		
		if (victoryTable) then
			umsg.Start("nx_VictoriesProgress", player);
				umsg.Long(victoryTable.index);
				umsg.Short(v);
			umsg.End();
		end;
	end;
	
	for k, v in pairs( player:GetCharacterData("augments") ) do
		local augmentTable = nexus.augment.Get(k);
		
		if (augmentTable) then
			umsg.Start("nx_AugmentsGive", player);
				umsg.Long(augmentTable.index);
			umsg.End();
		end;
	end;
end;

-- Called when a player has been given a weapon.
function SCHEMA:PlayerGivenWeapon(player, class, uniqueID, forceReturn)
	local itemTable = nexus.item.GetWeapon(class, uniqueID);
	
	if (nexus.item.IsWeapon(itemTable) and !itemTable.fakeWeapon) then
		if ( !itemTable:IsMeleeWeapon() and !itemTable:IsThrowableWeapon() ) then
			if (itemTable.weight <= 2) then
				self:CreatePlayerGear(player, "Secondary", itemTable);
			else
				self:CreatePlayerGear(player, "Primary", itemTable);
			end;
		elseif ( itemTable:IsThrowableWeapon() ) then
			self:CreatePlayerGear(player, "Throwable", itemTable);
		else
			self:CreatePlayerGear(player, "Melee", itemTable);
		end;
	end;
end;

-- Called when a player's drop weapon info should be adjusted.
function SCHEMA:PlayerAdjustDropWeaponInfo(player, info)
	if (nexus.player.GetWeaponClass(player) == info.itemTable.weaponClass) then
		info.position = player:GetShootPos();
		info.angles = player:GetAimVector():Angle();
	else
		local gearTable = {
			self:GetPlayerGear(player, "Throwable"),
			self:GetPlayerGear(player, "Secondary"),
			self:GetPlayerGear(player, "Primary"),
			self:GetPlayerGear(player, "Melee")
		};
		
		for k, v in pairs(gearTable) do
			if ( IsValid(v) ) then
				local gearItemTable = v:GetItem();
				
				if (gearItemTable and gearItemTable.weaponClass == info.itemTable.weaponClass) then
					local position, angles = v:GetRealPosition();
					
					if (position and angles) then
						info.position = position;
						info.angles = angles;
						
						break;
					end;
				end;
			end;
		end;
	end;
end;

-- Called when an entity is removed.
function SCHEMA:EntityRemoved(entity)
	if (IsValid(entity) and entity:GetClass() == "prop_ragdoll") then
		if (entity.areBelongings) then
			if (table.Count(entity.inventory) > 0 or entity.cash > 0) then
				local belongings = ents.Create("nx_belongings");
				
				belongings:SetAngles( Angle(0, 0, -90) );
				belongings:SetData(entity.inventory, entity.cash);
				belongings:SetPos( entity:GetPos() + Vector(0, 0, 32) );
				belongings:Spawn();
				
				entity.inventory = nil;
				entity.cash = nil;
			end;
		end;
	end;
end;

-- Called when an entity's menu option should be handled.
function SCHEMA:EntityHandleMenuOption(player, entity, option, arguments)
	local mineTypes = {"nx_firemine", "nx_freezemine", "nx_explomine"};
	
	if ( table.HasValue( mineTypes, entity:GetClass() ) ) then
		if ( arguments == "nx_mineDefuse" and !player:GetSharedVar("sh_Tied") ) then
			local defuseTime = SCHEMA:GetDexterityTime(player) * 2;
			
			nexus.player.SetAction(player, "defuse", defuseTime);
			
			nexus.player.EntityConditionTimer(player, entity, entity, defuseTime, 80, function()
				return player:Alive() and !player:IsRagdolled() and !player:GetSharedVar("sh_Tied");
			end, function(success)
				nexus.player.SetAction(player, "defuse", false);
				
				if (success) then
					entity:Defuse();
					entity:Remove();
				end;
			end);
		end;
	elseif (entity:GetClass() == "prop_ragdoll") then
		if (arguments == "nx_corpseLoot") then
			if (!entity.inventory) then entity.inventory = {}; end;
			if (!entity.cash) then entity.cash = 0; end;
			
			local entityPlayer = nexus.entity.GetPlayer(entity);
			
			if ( !entityPlayer or !entityPlayer:Alive() ) then
				player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
				
				nexus.player.OpenStorage( player, {
					name = "Corpse",
					weight = 8,
					entity = entity,
					distance = 192,
					cash = entity.cash,
					inventory = entity.inventory,
					OnTake = function(player, storageTable, itemTable)
						if ( entity.clothesData and itemTable.index == entity.clothesData[1] ) then
							if ( !storageTable.inventory[itemTable.uniqueID] ) then
								entity:SetModel( entity.clothesData[2] );
								entity:SetSkin( entity.clothesData[3] );
							end;
						end;
					end,
					OnGiveCash = function(player, storageTable, cash)
						entity.cash = storageTable.cash;
					end,
					OnTakeCash = function(player, storageTable, cash)
						entity.cash = storageTable.cash;
						
						if (cash >= 1500) then
							nexus.victories.Progress(player, VIC_RANSACKED);
						end;
					end
				} );
			end;
		elseif (arguments == "nx_corpseMutilate") then
			if ( nexus.augments.Has(player, AUG_MUTILATOR) ) then
				local entityPlayer = nexus.entity.GetPlayer(entity);
				local trace = player:GetEyeTraceNoCursor();
				
				if ( !entityPlayer or !entityPlayer:Alive() ) then
					if (!entity.mutilated or entity.mutilated < 3) then
						entity.mutilated = (entity.mutilated or 0) + 1;
							player:SetHealth( math.Clamp( player:Health() + 5, 0, player:GetMaxHealth() ) );
							player:EmitSound("npc/barnacle/barnacle_crunch"..math.random(2, 3)..".wav");
						NEXUS:CreateBloodEffects(entity:NearestPoint(trace.HitPos), 1, entity);
					end;
				end;
			end;
		elseif (arguments == "nx_corpseRevive") then
			if ( nexus.augments.Has(player, AUG_LIFEBRINGER) ) then
				local entityPlayer = nexus.entity.GetPlayer(entity);
				
				if ( entityPlayer and !entityPlayer:Alive() ) then
					local position = nexus.entity.GetPelvisPosition(entity);
					local health = math.Clamp(player:Health() / 2, 1, 100);
					
					entityPlayer:Spawn();
					player:SetHealth(player:Health() - health);
					entityPlayer:SetHealth(health);
					player:EmitSound("ambient/energy/whiteflash.wav");
					
					local effectData = EffectData();
						effectData:SetStart(position);
						effectData:SetOrigin(position);
						effectData:SetScale(32);
					util.Effect("GlassImpact", effectData, true, true);
					
					umsg.Start("nx_Flashed", entityPlayer);
					umsg.End();
					
					nexus.player.SetSafePosition(entityPlayer, position);
					
					if ( ValidEntity(entity) ) then
						entity:Remove();
					end;
				end;
			end;
		end;
	elseif (entity:GetClass() == "nx_belongings" and arguments == "nx_belongingsOpen") then
		player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
		
		nexus.player.OpenStorage( player, {
			name = "Belongings",
			weight = 100,
			entity = entity,
			distance = 192,
			cash = entity.cash,
			inventory = entity.inventory,
			OnGiveCash = function(player, storageTable, cash)
				entity.cash = storageTable.cash;
			end,
			OnTakeCash = function(player, storageTable, cash)
				entity.cash = storageTable.cash;
			end,
			OnClose = function(player, storageTable, entity)
				if ( IsValid(entity) ) then
					if ( (!entity.inventory and !entity.cash) or (table.Count(entity.inventory) == 0 and entity.cash == 0) ) then
						entity:Explode(entity:BoundingRadius() * 2);
						entity:Remove();
					end;
				end;
			end,
			CanGive = function(player, storageTable, itemTable)
				return false;
			end
		} );
	elseif (entity:GetClass() == "nx_breach") then
		entity:CreateDummyBreach();
		entity:BreachEntity(player);
	end;
end;

-- Called when a player's earn generator info should be adjusted.
function SCHEMA:PlayerAdjustEarnGeneratorInfo(player, info)
	if (info.entity:GetClass() == "nx_codekprinter") then
		if ( nexus.augments.Has(player, AUG_THIEVING) ) then
			info.cash = info.cash * 2;
		end;
	elseif (info.entity:GetClass() == "nx_codekproducer") then
		if ( nexus.augments.Has(player, AUG_METALSHIP) ) then
			info.cash = info.cash * 2;
		end;
	end;
end;

-- Called when Nexus has loaded all of the entities.
function SCHEMA:NexusInitPostEntity()
	self:LoadStaticProps();
	self:LoadBelongings();
end;

-- Called just after data should be saved.
function SCHEMA:PostSaveData()
	self:SaveStaticProps();
	self:SaveBelongings();
end;

-- Called when a player's inventory item has been updated.
function SCHEMA:PlayerInventoryItemUpdated(player, itemTable, amount, force)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes and itemTable.uniqueID == clothes) then
		if ( !player:HasItem(itemTable.uniqueID) ) then
			if ( player:Alive() ) then
				itemTable:OnChangeClothes(player, false);
			end;
			
			player:SetCharacterData("clothes", nil);
		end;
	elseif (itemTable.uniqueID == "skull_mask") then
		if ( player:GetSharedVar("sh_SkullMask") ) then
			if ( !player:HasItem(itemTable.uniqueID) ) then
				itemTable:OnPlayerUnequipped(player);
			end;
		end;
	elseif (itemTable.uniqueID == "heartbeat_implant") then
		if ( player:GetSharedVar("sh_Implant") ) then
			if ( !player:HasItem(itemTable.uniqueID) ) then
				itemTable:OnPlayerUnequipped(player);
			end;
		end;
	end;
end;

-- Called when a player switches their flashlight on or off.
function SCHEMA:PlayerSwitchFlashlight(player, on)
	if ( on and player:GetSharedVar("sh_Tied") ) then
		return false;
	end;
end;

-- Called when a player attempts to spray their tag.
function SCHEMA:PlayerSpray(player)
	if ( !player:HasItem("spray_can") or player:GetSharedVar("sh_Tied") ) then
		return true;
	end;
end;

-- Called when a player presses F3.
function SCHEMA:ShowSpare1(player)
	nexus.player.RunNexusCommand(player, "InvAction", "zip_tie", "use");
end;

-- Called when a player presses F4.
function SCHEMA:ShowSpare2(player)
	umsg.Start("nx_HotkeyMenu", player);
	umsg.End();
end;

-- Called when a player spawns an object.
function SCHEMA:PlayerSpawnObject(player)
	if ( player:GetSharedVar("sh_Tied") ) then
		nexus.player.Notify(player, "You don't have permission to do this right now!");
		
		return false;
	end;
end;

-- Called when a player attempts to breach an entity.
function SCHEMA:PlayerCanBreachEntity(player, entity)
	if ( nexus.entity.IsDoor(entity) ) then
		if ( !nexus.entity.IsDoorHidden(entity) ) then
			return true;
		end;
	end;
end;

-- Called when a player attempts to use the radio.
function SCHEMA:PlayerCanRadio(player, text, listeners, eavesdroppers)
	if ( player:HasItem("handheld_radio") ) then
		if ( !player:GetCharacterData("frequency") ) then
			nexus.player.Notify(player, "You need to set the radio frequency first!");
			
			return false;
		end;
	else
		nexus.player.Notify(player, "You do not own a radio!");
		
		return false;
	end;
end;

-- Called when a player attempts to use an entity in a vehicle.
function SCHEMA:PlayerCanUseEntityInVehicle(player, entity, vehicle)
	if ( entity:IsPlayer() or nexus.entity.IsPlayerRagdoll(entity) ) then
		return true;
	end;
end;

-- Called when a player attempts to use a door.
function SCHEMA:PlayerCanUseDoor(player, door)
	if ( player:GetSharedVar("sh_Tied") ) then
		return false;
	end;
end;

-- Called when a player's radio info should be adjusted.
function SCHEMA:PlayerAdjustRadioInfo(player, info)
	for k, v in ipairs( g_Player.GetAll() ) do
		if ( v:HasInitialized() and v:HasItem("handheld_radio") ) then
			if ( v:GetCharacterData("frequency") == player:GetCharacterData("frequency") ) then
				if ( !v:GetSharedVar("sh_Tied") ) then
					info.listeners[v] = v;
				end;
			end;
		end;
	end;
end;

-- Called when a player attempts to use a tool.
function SCHEMA:CanTool(player, trace, tool)
	if ( !nexus.player.HasFlags(player, "w") ) then
		if (string.sub(tool, 1, 5) == "wire_" or string.sub(tool, 1, 6) == "wire2_") then
			player:RunCommand("gmod_toolmode \"\"");
			
			return false;
		end;
	end;
end;

-- Called when a player's character data should be restored.
function SCHEMA:PlayerRestoreCharacterData(player, data)
	if ( !data["victories"] ) then data["victories"] = {}; end;
	if ( !data["augments"] ) then data["augments"] = {}; end;
	if ( !data["notepad"] ) then data["notepad"] = ""; end;
	if ( !data["bounty"] ) then data["bounty"] = 0; end;
	if ( !data["honor"] ) then data["honor"] = 50; end;
end;

-- Called when a player has been healed.
function SCHEMA:PlayerHealed(player, healer, itemTable)
	local action = nexus.player.GetAction(player);
	
	if ( player:IsGood() ) then
		healer:HandleHonor(5);
	else
		healer:HandleHonor(-5);
	end;
	
	if (itemTable.uniqueID == "health_vial") then
		healer:ProgressAttribute(ATB_DEXTERITY, 15, true);
	elseif (itemTable.uniqueID == "health_kit") then
		healer:ProgressAttribute(ATB_DEXTERITY, 25, true);
	elseif (itemTable.uniqueID == "bandage") then
		healer:ProgressAttribute(ATB_DEXTERITY, 5, true);
	end;
end;

-- Called when a player's shared variables should be set.
function SCHEMA:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "sh_Alliance", player:GetCharacterData("alliance", "") );
	player:SetSharedVar( "sh_Clothes", player:GetCharacterData("clothes", 0) );
	player:SetSharedVar( "sh_Implant", player:GetCharacterData("implant", false) );
	player:SetSharedVar( "sh_Bounty", player:GetCharacterData("bounty") );
	player:SetSharedVar( "sh_Honor", player:GetCharacterData("honor") );
	player:SetSharedVar( "sh_Rank", player:GetCharacterData("rank") );
	
	if ( nexus.augments.Has(player, AUG_GHOSTHEART) ) then
		player:SetSharedVar("sh_Ghostheart", true);
	else
		player:SetSharedVar("sh_Ghostheart", false);
	end;
	
	if (player.cancelDisguise) then
		if ( curTime >= player.cancelDisguise or !IsValid( player:GetSharedVar("sh_Disguise") ) ) then
			nexus.player.Notify(player, "Your disguise has begun to fade away, your true identity is revealed.");
			
			player.cancelDisguise = nil;
			player:SetSharedVar("sh_Disguise", NULL);
		end;
	end;
	
	if (player:Alive() and !player:IsRagdolled() and player:GetVelocity():Length() > 0) then
		local inventoryWeight = nexus.inventory.GetWeight(player);
		
		if (inventoryWeight >= nexus.inventory.GetMaximumWeight(player) / 4) then
			player:ProgressAttribute(ATB_STRENGTH, inventoryWeight / 400, true);
		end;
	end;
	
	if (nexus.player.GetCash(player) > 200) then
		nexus.victories.Progress(player, VIC_CODEKGUY);
	end;
end;

-- Called when a player has been unragdolled.
function SCHEMA:PlayerUnragdolled(player, state, ragdoll)
	nexus.player.SetAction(player, "die", false);
end;

-- Called when a player has been ragdolled.
function SCHEMA:PlayerRagdolled(player, state, ragdoll)
	nexus.player.SetAction(player, "die", false);
end;

-- Called at an interval while a player is connected.
function SCHEMA:PlayerThink(player, curTime, infoTable)
	local ragdolled = player:IsRagdolled();
	local alive = player:Alive();
	
	if (alive and !ragdolled) then
		if (!player:InVehicle() and player:GetMoveType() == MOVETYPE_WALK) then
			if ( player:IsInWorld() ) then
				if ( !player:IsOnGround() and player:GetGroundEntity() != GetWorldEntity() ) then
					player:ProgressAttribute(ATB_ACROBATICS, 0.25, true);
				elseif (infoTable.running) then
					player:ProgressAttribute(ATB_AGILITY, 0.125, true);
				elseif (infoTable.jogging) then
					player:ProgressAttribute(ATB_AGILITY, 0.0625, true);
				end;
			end;
		end;
	end;
	
	local acrobatics = nexus.attributes.Fraction(player, ATB_ACROBATICS, 175, 50);
	local strength = nexus.attributes.Fraction(player, ATB_STRENGTH, 8, 4);
	local agility = nexus.attributes.Fraction(player, ATB_AGILITY, 50, 25);
	
	if (clothes != "") then
		local itemTable = nexus.item.Get(clothes);
		
		if (itemTable and itemTable.pocketSpace) then
			infoTable.inventoryWeight = infoTable.inventoryWeight + itemTable.pocketSpace;
		end;
	end;
	
	infoTable.inventoryWeight = infoTable.inventoryWeight + strength;
	infoTable.jumpPower = infoTable.jumpPower + acrobatics;
	infoTable.runSpeed = infoTable.runSpeed + agility;
	
	if ( nexus.augments.Has(player, AUG_GODSPEED) ) then
		infoTable.runSpeed = infoTable.runSpeed * 1.1;
	end;
end;

-- Called when a player orders an item shipment.
function SCHEMA:PlayerOrderShipment(player, itemTable, entity)
	if (itemTable.batch == 5) then
		nexus.victories.Progress(player, VIC_BULKBUYER);
	end;
	
	if (itemTable.uniqueID == "nx_metalcrowbar") then
		nexus.victories.Progress(player, AUG_FREEMAN);
	end;
end;

-- Called when attempts to use a command.
function SCHEMA:PlayerCanUseCommand(player, commandTable, arguments)
	if ( player:GetSharedVar("sh_Tied") ) then
		local blacklisted = {
			"OrderShipment",
			"Radio"
		};
		
		if ( table.HasValue(blacklisted, commandTable.name) ) then
			nexus.player.Notify(player, "You cannot use this command when you are tied!");
			
			return false;
		end;
	end;
end;

-- Called when a player attempts to use an entity.
function SCHEMA:PlayerUse(player, entity)
	local curTime = CurTime();
	
	if (entity.bustedDown) then
		return false;
	end;
	
	if ( player:GetSharedVar("sh_Tied") ) then
		if ( entity:IsVehicle() ) then
			if ( nexus.entity.IsChairEntity(entity) or nexus.entity.IsPodEntity(entity) ) then
				return;
			end;
		end;
		
		if ( !player.nextTieNotify or player.nextTieNotify < CurTime() ) then
			nexus.player.Notify(player, "You cannot use that when you are tied!");
			
			player.nextTieNotify = CurTime() + 2;
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to destroy an item.
function SCHEMA:PlayerCanDestroyItem(player, itemTable, noMessage)
	if ( player:GetSharedVar("sh_Tied") ) then
		if (!noMessage) then
			nexus.player.Notify(player, "You cannot destroy items when you are tied!");
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to drop an item.
function SCHEMA:PlayerCanDropItem(player, itemTable, noMessage)
	if ( player:GetSharedVar("sh_Tied") ) then
		if (!noMessage) then
			nexus.player.Notify(player, "You cannot drop items when you are tied!");
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to use an item.
function SCHEMA:PlayerCanUseItem(player, itemTable, noMessage)
	if ( player:GetSharedVar("sh_Tied") ) then
		if (!noMessage) then
			nexus.player.Notify(player, "You cannot use items when you are tied!");
		end;
		
		return false;
	end;
	
	if (nexus.item.IsWeapon(itemTable) and !itemTable.fakeWeapon) then
		local throwableWeapon = nil;
		local secondaryWeapon = nil;
		local primaryWeapon = nil;
		local meleeWeapon = nil;
		local fault = nil;
		
		for k, v in ipairs( player:GetWeapons() ) do
			local weaponTable = nexus.item.GetWeapon(v);
			
			if (weaponTable and !weaponTable.fakeWeapon) then
				if ( !weaponTable:IsMeleeWeapon() and !weaponTable:IsThrowableWeapon() ) then
					if (weaponTable.weight <= 2) then
						secondaryWeapon = true;
					else
						primaryWeapon = true;
					end;
				elseif ( weaponTable:IsThrowableWeapon() ) then
					throwableWeapon = true;
				else
					meleeWeapon = true;
				end;
			end;
		end;
		
		if ( !itemTable:IsMeleeWeapon() and !itemTable:IsThrowableWeapon() ) then
			if (itemTable.weight <= 2) then
				if (secondaryWeapon) then
					fault = "You cannot use another secondary weapon!";
				end;
			elseif (primaryWeapon) then
				fault = "You cannot use another secondary weapon!";
			end;
		elseif ( itemTable:IsThrowableWeapon() ) then
			if (throwableWeapon) then
				fault = "You cannot use another throwable weapon!";
			end;
		elseif (meleeWeapon) then
			fault = "You cannot use another melee weapon!";
		end;
		
		if (fault) then
			if (!noMessage) then
				nexus.player.Notify(player, fault);
			end;
			
			return false;
		end;
	end;
end;

-- Called when a player attempts to say something out-of-character.
function SCHEMA:PlayerCanSayOOC(player, text)
	if ( !nexus.player.IsAdmin(player) ) then
		nexus.player.Notify(player, "Out-of-character discussion is disabled in this experiment.");
		
		return false;
	end;
end;

-- Called when a player attempts to say something locally out-of-character.
function SCHEMA:PlayerCanSayLOOC(player, text)
	if ( !player:Alive() ) then
		nexus.player.Notify(player, "You don't have permission to do this right now!");
	end;
end;

-- Called when chat box info should be adjusted.
function SCHEMA:ChatBoxAdjustInfo(info)
	if ( IsValid(info.speaker) and info.speaker:HasInitialized() ) then
		if (info.class != "ooc" and info.class != "looc") then
			if ( IsValid(info.speaker) and info.speaker:HasInitialized() ) then
				if (string.sub(info.text, 1, 1) == "?") then
					info.text = string.sub(info.text, 2);
					info.data.anon = true;
				end;
			end;
		end;
	end;
end;

-- Called when a player destroys generator.
function SCHEMA:PlayerDestroyGenerator(player, entity, generator)
	local owner = entity:GetPlayer();
	
	if ( IsValid(owner) and owner:IsGood() ) then
		if ( nexus.augments.Has(player, AUG_PAYBACK) ) then
			nexus.player.GiveCash( player, generator.cash * 2, "destroying a "..string.lower(generator.name) );
			
			return;
		end;
	end;
	
	nexus.player.GiveCash( player, generator.cash, "destroying a "..string.lower(generator.name) );
end;

-- Called when a player dies.
function SCHEMA:PlayerDeath(player, inflictor, attacker, damageInfo)
	nexus.victories.Progress(player, VIC_BULLYVICTIM);
	
	if ( attacker:IsPlayer() ) then
		local weapon = attacker:GetActiveWeapon();
		
		if ( IsValid(weapon) ) then
			umsg.Start("nx_Death", player);
				umsg.Entity(weapon);
			umsg.End();
		else
			umsg.Start("nx_Death", player);
			umsg.End();
		end;
		
		if ( player:IsBad() ) then
			nexus.victories.Progress(attacker, VIC_DEVILHUNTER);
			attacker:HandleHonor(5);
		else
			nexus.victories.Progress(attacker, VIC_SAINTHUNTER);
			attacker:HandleHonor(-5);
		end;
		
		if ( player:IsWanted() ) then
			nexus.victories.Progress(attacker, VIC_BOUNTYHUNTER);
			nexus.player.GiveCash(attacker, player:GetBounty(), "bounty hunting");
			player:RemoveBounty();
		end;
	else
		umsg.Start("nx_Death", player);
		umsg.End();
	end;
	
	if (damageInfo) then
		local miscellaneousDamage = damageInfo:IsBulletDamage() or damageInfo:IsFallDamage() or damageInfo:IsExplosionDamage();
		local meleeDamage = damageInfo:IsDamageType(DMG_CLUB) or damageInfo:IsDamageType(DMG_SLASH);
		
		if (miscellaneousDamage or meleeDamage) then
			self:PlayerDropRandomItems( player, player:GetRagdollEntity() );
		end;
	end;
end;

-- Called just before a player dies.
function SCHEMA:DoPlayerDeath(player, attacker, damageInfo)
	self:TiePlayer(player, false, true);
	
	player.beingSearched = nil;
	player.searching = nil;
end;

-- Called when a player's order item should be adjusted.
function SCHEMA:PlayerAdjustOrderItemTable(player, itemTable)
	if ( nexus.augments.Has(player, AUG_MERCANTILE) ) then
		itemTable.cost = itemTable.cost * 0.9;
	end;
end;

-- Called when a player's storage should close.
function SCHEMA:PlayerStorageShouldClose(player, storage)
	local entity = player:GetStorageEntity();
	
	if (player.searching and entity:IsPlayer() and !entity:GetSharedVar("sh_Tied") ) then
		return true;
	end;
end;

-- Called when a player's attribute has been updated.
function SCHEMA:PlayerAttributeUpdated(player, attributeTable, amount)
	local attributeID = attributeTable.uniqueID;
	local currentPoints = nexus.attributes.Get(player, attributeID, true);
	
	if (!currentPoints) then return; end;
	
	if (currentPoints == attributeTable.maximum) then
		if (attributeTable.uniqueID == ATB_ENDURANCE) then
			nexus.victories.Progress(player, VIC_SNAKESKIN);
		elseif (attributeTable.uniqueID == ATB_DEXTERITY) then
			nexus.victories.Progress(player, VIC_QUICKHANDS);
		elseif (attributeTable.uniqueID == ATB_AGILITY) then
			nexus.victories.Progress(player, VIC_GONZALES);
		elseif (attributeTable.uniqueID == ATB_STRENGTH) then
			nexus.victories.Progress(player, VIC_MIKETYSON);
		end;
	elseif (currentPoints >= 50) then
		if (attributeTable.uniqueID == ATB_ACROBATICS) then
			nexus.victories.Progress(player, VIC_FIDDYACRO);
		end;
	end;
end;

-- Called just after a player spawns.
function SCHEMA:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local kevlarVest = nexus.item.Get("kevlar_vest");
	local skullMask = player:GetCharacterData("skullmask");
	local clothes = player:GetCharacterData("clothes");
	local team = player:Team();
	
	if (!lightSpawn) then
		umsg.Start("nx_ClearEffects", player);
		umsg.End();
		
		player:SetSharedVar("sh_Disguise", NULL);
		player.cancelDisguise = nil;
		player.beingSearched = nil;
		player.searching = nil;
	end;
	
	if ( player:GetSharedVar("sh_Tied") ) then
		self:TiePlayer(player, true);
	end;
	
	if (kevlarVest) then
		SCHEMA:CreatePlayerGear(player, "KevlarVest", kevlarVest);
	end;
	
	if (skullMask) then
		local itemTable = nexus.item.Get("skull_mask");
		
		if ( itemTable and player:HasItem(itemTable.uniqueID) ) then
			SCHEMA:CreatePlayerGear(player, "SkullMask", itemTable);
			
			player:SetSharedVar("sh_SkullMask", true);
			player:UpdateInventory(itemTable.uniqueID);
		else
			player:SetCharacterData("skullmask", nil);
		end;
	end;
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		local team = player:Team();
		
		if ( itemTable and player:HasItem(itemTable.uniqueID) ) then
			self:PlayerWearClothes(player, itemTable);
		else
			player:SetCharacterData("clothes", nil);
		end;
	end;
end;

-- Called when a player's footstep sound should be played.
function SCHEMA:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		
		if (itemTable) then
			if ( player:IsRunning() or player:IsJogging() ) then
				if (itemTable.runSound) then
					if (type(itemTable.runSound) == "table") then
						sound = itemTable.runSound[ math.random(1, #itemTable.runSound) ];
					else
						sound = itemTable.runSound;
					end;
				end;
			elseif (itemTable.walkSound) then
				if (type(itemTable.walkSound) == "table") then
					sound = itemTable.walkSound[ math.random(1, #itemTable.walkSound) ];
				else
					sound = itemTable.walkSound;
				end;
			end;
		end;
	end;
	
	player:EmitSound(sound);
	
	return true;
end;

-- Called when a player throws a punch.
function SCHEMA:PlayerPunchThrown(player)
	player:ProgressAttribute(ATB_STRENGTH, 0.25, true);
end;

-- Called when a player punches an entity.
function SCHEMA:PlayerPunchEntity(player, entity)
	if ( entity:IsPlayer() or entity:IsNPC() ) then
		player:ProgressAttribute(ATB_STRENGTH, 1, true);
	else
		player:ProgressAttribute(ATB_STRENGTH, 0.5, true);
	end;
end;

-- Called when an entity has been breached.
function SCHEMA:EntityBreached(entity, activator)
	if ( nexus.entity.IsDoor(entity) ) then
		nexus.entity.OpenDoor(entity, 0, true, true);
		
		if ( IsValid(activator) ) then
			nexus.victories.Progress(activator, VIC_BLOCKBUSTER);
		end;
	end;
end;

-- Called when a player takes damage.
function SCHEMA:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	local curTime = CurTime();
	
	if ( damageInfo:IsBulletDamage() ) then
		player:SetDSP(math.random(35, 37), false);
	
		if (player:Armor() > 0) then
			umsg.Start("nx_ShotEffect", player);
				umsg.Float(0.25);
			umsg.End();
		else
			umsg.Start("nx_ShotEffect", player);
				umsg.Float(0.5);
			umsg.End();
		end;
	end;
	
	if (player:Health() <= 10 and math.random() <= 0.75) then
		if (nexus.player.GetAction(player) != "die") then
			nexus.player.SetRagdollState( player, RAGDOLL_FALLENOVER, nil, nil, NEXUS:ConvertForce(damageInfo:GetDamageForce() * 32) );
			
			if ( nexus.augments.Has(player, AUG_ADRENALINE) ) then
				local duration = 60;
				
				if ( nexus.augments.Has(player, AUG_LONGLASTER) ) then
					duration = duration / 2;
				end;
				
				nexus.player.SetAction(player, "die", duration, 1, function()
					if ( IsValid(player) and player:Alive() ) then
						player:SetHealth(10); nexus.player.SetRagdollState(player, RAGDOLL_NONE);
					end;
				end);
			else
				local duration = 60;
				
				if ( nexus.augments.Has(player, AUG_LONGLASTER) ) then
					duration = duration * 2;
				end;
				
				nexus.player.SetAction(player, "die", duration, 1, function()
					if ( IsValid(player) and player:Alive() ) then
						player:TakeDamage(player:Health() * 2, attacker, inflictor);
					end;
				end);
			end;
		end;
	end;
	
	if ( attacker:IsPlayer() ) then
		umsg.Start("nx_TakeDmg", player);
			umsg.Entity(attacker);
			umsg.Short( damageInfo:GetDamage() );
		umsg.End();
		
		umsg.Start("nx_DealDmg", attacker);
			umsg.Entity(player);
			umsg.Short( damageInfo:GetDamage() );
		umsg.End();
		
		if ( attacker:IsGood() and player:IsBad() ) then
			if ( nexus.augments.Has(attacker, AUG_BLOODDONOR) ) then
				local health = math.Round(damageInfo:GetDamage() * 0.1);
				
				if (health > 0) then
					attacker:SetHealth( math.Clamp( attacker:Health() + health, 0, attacker:GetMaxHealth() ) );
				end;
			end;
		end;
		
		if ( damageInfo:IsBulletDamage() ) then
			if ( nexus.augments.Has(attacker, AUG_INCENDIARY) ) then
				if ( math.random() >= 0.95 and player:IsBad() ) then
					player:Ignite(5, 0);
				end;
			elseif ( nexus.augments.Has(attacker, AUG_FROZENROUNDS) ) then
				if ( math.random() >= 0.95 and player:IsGood() ) then
					nexus.player.SetRagdollState(player, RAGDOLL_FALLENOVER, 3);
					
					local ragdollEntity = player:GetRagdollEntity();
					
					if ( IsValid(ragdollEntity) ) then
						nexus.entity.StatueRagdoll(ragdollEntity, 128);
					end;
				end;
			end;
		end;
	end;
	
	if (damageInfo:IsBulletDamage() and hitGroup != nil) then
		local curTime = CurTime();
		
		if (!player.nextAttributeLoss or curTime >= player.nextAttributeLoss) then
			player.nextAttributeLoss = curTime + 5;
			
			if (hitGroup == HITGROUP_HEAD) then
				player:BoostAttribute("Body Damage", ATB_DEXTERITY, -10, 600, true);
				player:BoostAttribute("Body Damage", ATB_AGILITY, -10, 600, true);
			elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_GENERIC) then
				player:BoostAttribute("Body Damage", ATB_ENDURANCE, -10, 600, true);
			elseif (hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG) then
				player:BoostAttribute("Body Damage", ATB_ACROBATICS, -10, 600, true);
				player:BoostAttribute("Body Damage", ATB_STAMINA, -10, 600, true);
				player:BoostAttribute("Body Damage", ATB_AGILITY, -10, 600, true);
			elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM) then
				player:BoostAttribute("Body Damage", ATB_DEXTERITY, -10, 600, true);
				player:BoostAttribute("Body Damage", ATB_STRENGTH, -10, 600, true);
			end;
		end;
	end;
end;

-- A function to scale damage by hit group.
function SCHEMA:PlayerScaleDamageByHitGroup(player, attacker, hitGroup, damageInfo, baseDamage)
	local endurance = nexus.attributes.Fraction(player, ATB_ENDURANCE, 0.4, 0.5);
	local clothes = player:GetCharacterData("clothes");
	local curTime = CurTime();
	
	if ( hitGroup == HITGROUP_HEAD and nexus.augments.Has(player, AUG_HEADPLATE) ) then
		if (math.random() <= 0.5) then
			damageInfo:SetDamage(0);
		end;
	end;
	
	if (damageInfo:GetDamage() > 0 and hitGroup == HITGROUP_HEAD) then
		if ( attacker:IsPlayer() and nexus.augments.Has(attacker, AUG_RECYCLER) ) then
			if (math.random() <= 0.5) then
				attacker:SetHealth( math.Clamp( attacker:Health() + (damageInfo:GetDamage() / 2), 0, attacker:GetMaxHealth() ) );
			end;
		end;
	end;
	
	if ( damageInfo:IsDamageType(DMG_CLUB) or damageInfo:IsDamageType(DMG_SLASH) ) then
		if ( nexus.augments.Has(player, AUG_BLUNTDEFENSE) ) then
			damageInfo:ScaleDamage(0.75);
		end;
	end;
	
	if (attacker:GetClass() == "entityflame") then
		if (!player.nextTakeBurnDamage or curTime >= player.nextTakeBurnDamage) then
			player.nextTakeBurnDamage = curTime + 0.1;
			
			damageInfo:SetDamage(1);
		else
			damageInfo:SetDamage(0);
		end;
	end;
	
	if ( damageInfo:IsFallDamage() ) then
		if ( nexus.augments.Has(player, AUG_LEGBRACES) ) then
			damageInfo:ScaleDamage(0.5);
		end;
	else
		damageInfo:ScaleDamage(1.25 - endurance);
	end;
	
	if (clothes) then
		local itemTable = nexus.item.Get(clothes);
		
		if (itemTable and itemTable.armor) then
			if ( damageInfo:IsBulletDamage() or (damageInfo:IsFallDamage() and itemTable.armor >= 0.4) ) then
				damageInfo:ScaleDamage( 1 - (itemTable.armor * 0.8) );
			end;
		end;
	end;
	
	if ( attacker:IsPlayer() and attacker:IsBad() and player:IsGood() ) then
		if ( nexus.augments.Has(attacker, AUG_HOLLOWPOINT) ) then
			damageInfo:ScaleDamage(1.1);
		end;
	end;
	
	if (nexus.player.GetAction(player) == "die") then
		if ( nexus.augments.Has(player, AUG_BORNSURVIVOR) ) then
			damageInfo:ScaleDamage(0);
		end;
	end;
end;

-- Called when an entity takes damage.
function SCHEMA:EntityTakeDamage(entity, inflictor, attacker, amount, damageInfo)
	local curTime = CurTime();
	local player = nexus.entity.GetPlayer(entity);
	
	if (player) then
		if (!player.nextEnduranceTime or CurTime() > player.nextEnduranceTime) then
			player:ProgressAttribute(ATB_ENDURANCE, math.Clamp(damageInfo:GetDamage(), 0, 75) / 10, true);
			player.nextEnduranceTime = CurTime() + 2;
		end;
	end;
	
	if ( attacker:IsPlayer() ) then
		local strength = nexus.attributes.Fraction(attacker, ATB_STRENGTH, 1, 0.5);
		local weapon = nexus.player.GetWeaponClass(attacker);
		
		if ( damageInfo:IsDamageType(DMG_CLUB) or damageInfo:IsDamageType(DMG_SLASH) ) then
			damageInfo:ScaleDamage(1 + strength);
		end;
		
		if (weapon == "weapon_crowbar") then
			if ( entity:IsPlayer() ) then
				damageInfo:ScaleDamage(0.1);
			else
				damageInfo:ScaleDamage(0.8);
			end;
		end;
		
		if (entity:GetClass() == "prop_physics") then
			if ( damageInfo:IsBulletDamage() ) then
				damageInfo:ScaleDamage(0.25);
			end;
			
			local boundingRadius = entity:BoundingRadius() * 5;
			entity.health = entity.health or boundingRadius;
			entity.health = math.max(entity.health - damageInfo:GetDamage(), 0);
			
			local blackness = (255 / boundingRadius) * entity.health;
			entity:SetColor(blackness, blackness, blackness, 255);
			
			if (entity.health == 0 and !entity.isDead) then
				if ( entity:GetOwnerKey() != attacker:QueryCharacter("key") ) then
					nexus.victories.Progress(attacker, AUG_HOOLIGAN);
				end;
				
				nexus.entity.Decay(entity, 5);
				
				entity:SetCollisionGroup(COLLISION_GROUP_WEAPON);
				entity:Ignite(5, 0);
				entity.isDead = true;
			end;
		end;
		
		for k, v in ipairs( ents.FindByClass("nx_doorguarder") ) do
			if (entity:GetPos():Distance( v:GetPos() ) < 256) then
				local owner = v:GetPlayer();
				
				if ( IsValid(owner) and nexus.augments.Has(owner, AUG_REVERSEMAN) ) then
					attacker:TakeDamageInfo(damageInfo);
				end;
				
				return;
			end;
		end;
		
		if ( damageInfo:IsBulletDamage() and !IsValid(entity.breach) ) then
			if (string.lower( entity:GetClass() ) == "prop_door_rotating") then
				if ( !nexus.entity.IsDoorFalse(entity) ) then
					local damagePosition = damageInfo:GetDamagePosition();
					
					if (entity:WorldToLocal(damagePosition):Distance( Vector(-1.0313, 41.8047, -8.1611) ) <= 8) then
						local effectData = EffectData();
						
						effectData:SetStart(damagePosition);
						effectData:SetOrigin(damagePosition);
						effectData:SetScale(8);
						
						util.Effect("GlassImpact", effectData, true, true);
						
						nexus.entity.OpenDoor( entity, 0, true, true, attacker:GetPos() );
					end;
				end;
			end;
		end;
	end;
end;