--[[
Name: "cl_changelog.lua".
Product: "eXperim3nt".
--]]
	
nexus.directory.AddCategoryPage( "Changelog", nil, [[
	<p>
		<font size="4">
			<b><i>Changes made on the 09th June 2010.</i></b><br>
		</font>
		<b>+</b> Biological suits and suits with gasmasks prevent you from being affected by tear gas.<br>
		<b>+</b> Added smoke grenades, flare grenades, tear gas grenades and flash grenades.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 08th June 2010.</i></b><br>
		</font>
		<b>+</b> Added a fuckton of new uniforms, some re-skinned by me.<br>
		<b>+</b> Disabled the flashlight now that the colormod is off.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 07th June 2010.</i></b><br>
		</font>
		<b>+</b> Pressing 'use' on a player will now bring up a list of options, like inviting to your alliance.<br>
		<b>+</b> Added a permanent augment which puts codeks earned from generators straight into your inventory.<br>
		<b>+</b> Added a load of new augments, more victories and augments coming this week.<br>
		<b>+</b> Added the Explomine, Firemine and Freezemine landmine items.<br>
		<b>+</b> Added loads of victories, adding more augments later this week.<br>
		<b>+</b> Administrators are godmoded when in observer.<br>
		<b>+</b> Untying a player is now done through their 'use' menu.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 05th June 2010.</i></b><br>
		</font>
		<b>+</b> Instead of those augments allowing you to create another generator it just gives more codeks.<br>
		<b>+</b> Removed the Gears of War clothing, they didn't work properly but I'll add new ones tomorow.<br>
		<b>+</b> Removed the Codek Multiplier and now Codek Producers give more.<br>
		<b>+</b> Reduced the radius of the Door Guarder.<br>
		<b>+</b> Added outlines to the shipment and cash entities.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 04th June 2010.</i></b><br>
		</font>
		<b>+</b> One layer of prop blocking is now allowed, but a thin layer.<br>
		<b>+</b> Made props a bit more expensive and made them destroyable.<br>
		<b>+</b> Added the Leg Braces, Frozen Rounds, Incendiary, Armored and Adrenaline augments.<br>
		<b>+</b> Added the Notepad item under the Reusables category.<br>
		<b>+</b> Added the Headplate, Recycler, Favored and Cursed augments.<br>
		<b>+</b> Added the Intervention, Reverseman, Metalship and Thieving augments.<br>
		<b>+</b> Added the Door Guarder and Codek Guarder entities.<br>
		<b>+</b> Made it possible to shoot doors open that do not have a Door Guard.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 03rd June 2010.</i></b><br>
		</font>
		<b>+</b> Upped the possible amount of earned money in an hour from $600 to $800.<br>
		<b>+</b> Altered the prices of Augments just slightly.<br>
		<b>+</b> Added the Mercantile augment and fixed some alliance menu bugs.<br>
		<b>+</b> Added eleven victories to achieve with rewards.<br>
		<b>+</b> Added a Sinner's Tome and a Saint's Tome.<br>
		<b>+</b> Added the Payback and Steel Sheets augments.<br>
		<b>+</b> Added the Godspeed and Obsessive augments.<br>
		<b>+</b> Added the Blood Donor and Hollow Point augments.<br>
		<b>+</b> Added the Lifebringer augment for good characters.<br>
		<b>+</b> Added the compact knife weapon available in the Equipment menu.<br>
		<b>+</b> The live beta testing phase of eXperim3nt has begun.<br>
		<b>+</b> More features will be added over the coming weeks.<br>
		<b>+</b> Tons of victories and augments will be added in a few days.
	</p>
]] );