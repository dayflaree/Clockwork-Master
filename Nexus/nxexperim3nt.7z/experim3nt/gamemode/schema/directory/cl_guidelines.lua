--[[
Name: "cl_guidelines.lua".
Product: "eXperim3nt".
--]]

nexus.directory.AddCategoryPage( "Guidelines", nil, [[
	<p>
		<i>
			These are just guidelines, there is not a full rules list because there would be too many to list.
			Use these guidelines and your <b>common sense</b> and you should be able to play the game without
			suffering from a very long ban.
		</i>
	</p>
	<p>
		<p>
			<b>1.</b> If somebody breaks a rule it does not take seven of you to tell them, if one person
			tells them to go and read the guidelines, you do not need to back them up.
		</p>
		<p>
			<b>2.</b> It is not your duty to become a vigilante, if somebody tries to prop-kill you or
			something similiar, you should disconnect and report it to an administrator. Trying to kill
			them yourself will only result in you being banned.
		</p>
		<p>
			<b>3.</b> Do not kill another character without a good reason, and you must be able to prove
			to an administrator that you had a valid reason.
		</p>
		<p>
			<b>4.</b> Never take revenge on somebody that killed you, or randomly killed you, report them
			instead.
		</p>
		<p>
			<b>5.</b> Do not attempt to kill another character by using props, we have sufficient protection to prevent you from
			doing so, but if you do manage it we do have logs and it will result in a permanent ban.
		</p>
		<p>
			<b>6.</b> Have respect for the staff, they are here to make sure your playing experience is fun and enjoyable. We understand
			that sometimes our staff's judgement can be wrong, and if you believe that is so then please report it on the forums. If you do
			report an action made by our staff, be sure not to disrespect them in doing so.
		</p>
		<p>
			<b>7.</b> If you are going to block something with a prop, the block is only allowed to be one layer thick; so that the block
			can be destroyed by other players. You are not allowed to instantly replace a destroyed prop.
		</p>
		<p>
			<b>8.</b> Do not disconnect from the server to avoid roleplay, or to avoid being mugged or dying. This is very severe, and a
			severe punishment will be given for anyone that does so.
		</p>
		<p>
			<b>9.</b> Do not spawn-kill, camp at spawn, or tie or kill anyone that is away from their keyboard. Doing so will result in a very
			severe punishment, with no warnings.
		</p>
		<p>
			<b>9.</b> Be careful who you pick a fight with, they may have a lot of backup, or may put a bounty on your head. Think about this
			before you decide to go to war with somebody.
		</p>
		<p>
			<b>10.</b> Go away from keyboard at your own risk, although people who kill or tie players that are away from keyboard will be banned, it
			is still better for you to disconnect instead.
		</p>
		<p>
			<b>11.</b> Be careful who you trust and be careful who you share your name with. Nobody can be fully trusted in the experiment, so do not
			cry if you get scammed.
		</p>
		<p>
			<b>12.</b> If you're new, don't draw attention to yourself. Stay back, build up your generators and save up for some protection. The best way
			to get protection, or any shipment of items, is to save up with in a group of five people.
		</p>
		<p>
			<b>13.</b> If someone is in trouble, it is best to mind your own business, otherwise you could end up making potentially dangerous and powerful
			enemies. Do not cry if you make enemies with somebody more powerful than you.
		</p>
		<p>
			<i>Please check back here regularly, as more guidelines will be added over time.</i>
		</p>
	</p>
]] );