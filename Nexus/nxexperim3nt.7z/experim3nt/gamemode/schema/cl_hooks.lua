--[[
Name: "cl_hooks.lua".
Product: "eXperim3nt".
--]]

local OUTLINE_MATERIAL = Material("white_outline");

-- Called when the bars are needed.
function SCHEMA:GetBars(bars)
	local honor = g_LocalPlayer:GetSharedVar("sh_Honor");
	
	if (!self.honor) then
		self.honor = honor;
	else
		self.honor = math.Approach(self.honor, honor, 1);
	end;
	
	if (honor >= 50) then
		bars:Add("HONOR", Color(175, 255, 75, 255), "Honor", self.honor, 100, self.honor < 55);
	else
		bars:Add("HONOR", Color(255, 75, 175, 255), "Honor", self.honor, 100, self.honor > 45);
	end;
end;

-- Called when the local player's item functions should be adjusted.
function SCHEMA:PlayerAdjustItemFunctions(itemTable, itemFunctions)
	if ( nexus.augments.Has(AUG_CASHBACK) or nexus.augments.Has(AUG_BLACKMARKET) ) then
		if (itemTable.cost) then
			itemFunctions[#itemFunctions + 1] = "Cash";
		end;
	end;
end;

-- Called when the character loading background should be drawn.
function SCHEMA:ShouldDrawCharacterLoadingBackground(alpha)
	return false;
end;

-- Called just before a bar is drawn.
function SCHEMA:PreDrawBar(barInfo)
	surface.SetDrawColor(255, 255, 255, 150);
	surface.SetTexture(self.scratchTexture);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.width, barInfo.height);
	
	barInfo.drawBackground = false;
	barInfo.drawProgress = false;
	
	if (barInfo.text) then
		barInfo.text = string.upper(barInfo.text);
	end;
end;

-- Called just after a bar is drawn.
function SCHEMA:PostDrawBar(barInfo)
	surface.SetDrawColor(barInfo.color.r, barInfo.color.g, barInfo.color.b, barInfo.color.a);
	surface.SetTexture(self.scratchTexture);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.progressWidth, barInfo.height);
end;

-- Called just before the weapon selection info is drawn.
function SCHEMA:PreDrawWeaponSelectionInfo(info)
	surface.SetDrawColor( 255, 255, 255, math.min(200, info.alpha) );
	surface.SetTexture(self.dirtyTexture);
	surface.DrawTexturedRect(info.x, info.y, info.width, info.height);
	
	info.drawBackground = false;
end;

-- Called just before the local player's information is drawn.
function SCHEMA:PreDrawPlayerInfo(boxInfo, information, subInformation)
	surface.SetDrawColor(255, 255, 255, 100);
	surface.SetTexture(self.dirtyTexture);
	surface.DrawTexturedRect(boxInfo.x, boxInfo.y, boxInfo.width, boxInfo.height);
	
	boxInfo.drawBackground = false;
	boxInfo.drawGradient = false;
end;

-- Called when the local player's business item should be adjusted.
function SCHEMA:PlayerAdjustBusinessItemTable(itemTable)
	if ( nexus.augments.Has(AUG_MERCANTILE) ) then
		itemTable.cost = itemTable.cost * 0.9;
	end;
end;

-- Called when the HUD should be painted.
function SCHEMA:HUDPaint()
	local info = {
		alpha = 255 - NEXUS:GetBlackFadeAlpha(),
		x = ScrW() - 208,
		y = 8
	};
	
	if (nexus.inventory.HasItem("heartbeat_implant") and info.alpha > 0) then
		if ( g_LocalPlayer:GetSharedVar("sh_Implant") ) then
			local aimVector = g_LocalPlayer:GetAimVector();
			local position = g_LocalPlayer:GetPos();
			local curTime = UnPredictedCurTime();

			self.heartbeatOverlay:SetMaterialFloat( "$alpha", math.min(0.5, (info.alpha / 255) * 0.5) );
			
			surface.SetDrawColor( 255, 255, 255, math.min(150, info.alpha / 2) );
				surface.SetMaterial(self.heartbeatOverlay);
			surface.DrawTexturedRect(info.x, info.y, 200, 200);
			
			surface.SetDrawColor( 255, 255, 255, math.min(150, info.alpha / 2) );
			surface.SetTexture(self.dirtyTexture);
			surface.DrawTexturedRect(info.x, info.y, 200, 200);
			
			surface.SetDrawColor(0, 200, 0, info.alpha);
				surface.SetMaterial(self.heartbeatPoint);
			surface.DrawTexturedRect(info.x + 84, info.y + 84, 32, 32);
			
			if (self.heartbeatScan) then
				local scanAlpha = math.min( 255 * math.max(self.heartbeatScan.fadeOutTime - curTime, 0), info.alpha );
				local y = self.heartbeatScan.y + ( (184 / 255) * (255 - scanAlpha) );
				
				if (scanAlpha > 0) then
					surface.SetDrawColor(100, 0, 0, scanAlpha * 0.5);
						surface.SetMaterial(self.heartbeatGradient);
					surface.DrawTexturedRect(self.heartbeatScan.x, y, self.heartbeatScan.width, self.heartbeatScan.height);
				else
					self.heartbeatScan = nil;
				end;
			end;
			
			if (curTime >= self.nextHeartbeatCheck) then
				self.nextHeartbeatCheck = curTime + 1;
				self.oldHeartbeatPoints = self.heartbeatPoints;
				self.heartbeatPoints = {};
				self.heartbeatScan = {
					fadeOutTime = curTime + 1,
					height = 16,
					width = 200,
					y = info.y,
					x = info.x
				};
				
				local centerY = info.y + 100;
				local centerX = info.x + 100;
				
				for k, v in ipairs( ents.FindInSphere(position, 768) ) do
					if ( v:IsPlayer() and v:Alive() and v:HasInitialized() ) then
						if ( g_LocalPlayer != v and !nexus.player.IsNoClipping(v) ) then
							if ( v:Health() >= (v:GetMaxHealth() / 3) ) then
								if ( !v:GetSharedVar("sh_Ghostheart") ) then
									local playerPosition = v:GetPos();
									local difference = playerPosition - position;
									local pointX = (difference.x / 768);
									local pointY = (difference.y / 768);
									local pointZ = math.sqrt(pointX * pointX + pointY * pointY);
									local phi = math.Deg2Rad(math.Rad2Deg( math.atan2(pointX, pointY) ) - math.Rad2Deg( math.atan2(aimVector.x, aimVector.y) ) - 90);
									
									pointX = math.cos(phi) * pointZ;
									pointY = math.sin(phi) * pointZ;
									
									self.heartbeatPoints[#self.heartbeatPoints + 1] = {
										fadeInTime = curTime + 1,
										height = 32,
										width = 32,
										x = centerX + (pointX * 100) - 16,
										y = centerY + (pointY * 100) - 16
									};
								end;
							end;
						end;
					end;
				end;
				
				if (self.lastHeartbeatAmount > #self.heartbeatPoints) then
					g_LocalPlayer:EmitSound("items/flashlight1.wav", 25);
				end;
				
				for k, v in ipairs(self.oldHeartbeatPoints) do
					v.fadeOutTime = curTime + 1;
					v.fadeInTime = nil;
				end;
				
				self.lastHeartbeatAmount = #self.heartbeatPoints;
			end;
			
			for k, v in ipairs(self.oldHeartbeatPoints) do
				local pointAlpha = 255 * math.max(v.fadeOutTime - curTime, 0);
				local pointX = math.Clamp(v.x, info.x, (info.x + 200) - 32);
				local pointY = math.Clamp(v.y, info.y, (info.y + 200) - 32);
				
				surface.SetDrawColor( 200, 0, 0, math.min(pointAlpha, info.alpha) );
					surface.SetMaterial(self.heartbeatPoint);
				surface.DrawTexturedRect(pointX, pointY, v.width, v.height);
			end;
			
			for k, v in ipairs(self.heartbeatPoints) do
				local pointAlpha = 255 - ( 255 * math.max(v.fadeInTime - curTime, 0) );
				local pointX = math.Clamp(v.x, info.x, (info.x + 200) - 32);
				local pointY = math.Clamp(v.y, info.y, (info.y + 200) - 32);
				
				surface.SetDrawColor( 200, 0, 0, math.min(pointAlpha, info.alpha) );
					surface.SetMaterial(self.heartbeatPoint);
				surface.DrawTexturedRect(pointX, pointY, v.width, v.height);
			end;
			
			info.y = info.y + 212;
		end;
	end;
end;

-- Called when a cash entity is drawn.
function SCHEMA:NexusCashEntityDraw(entity)
	self:NexusGeneratorEntityDraw( entity, Color(0, 255, 255, 255) );
end;

-- Called when a shipment entity is drawn.
function SCHEMA:NexusShipmentEntityDraw(entity)
	self:NexusGeneratorEntityDraw( entity, Color(125, 100, 75, 255) );
end;

-- Called when a generator entity is drawn.
function SCHEMA:NexusGeneratorEntityDraw(entity, forceColor)
	local curTime = CurTime();
	local sineWave = math.max(math.abs(math.sin(curTime) * 32), 16);
	local r, g, b, a = entity:GetColor();
	local outlineColor = forceColor or Color(255, 0, 255, 255);
	
	if (entity:GetClass() == "nx_codekproducer") then
		outlineColor = Color(0, 255, 255, 255);
	end;
	
	cam.Start3D( EyePos(), EyeAngles() );
		render.SuppressEngineLighting(true);
			render.SetColorModulation(outlineColor.r / 255, outlineColor.g / 255, outlineColor.b / 255);
				render.SetAmbientLight(1, 1, 1);
					render.SetBlend(outlineColor.a / 255);
						entity:SetModelScale( Vector() * ( 1.025 + (sineWave / 320) ) );
							SetMaterialOverride(OUTLINE_MATERIAL);
						entity:DrawModel();
						
						entity:SetModelScale( Vector() );
					render.SetBlend(1);
				SetMaterialOverride(nil);
			render.SetColorModulation(r / 255, g / 255, b / 255);
		render.SuppressEngineLighting(false);
	cam.End3D();
end;

-- Called when an item entity is drawn.
function SCHEMA:NexusItemEntityDraw(itemTable, entity)
	local curTime = CurTime();
	local sineWave = math.max(math.abs(math.sin(curTime) * 32), 16);
	local r, g, b, a = entity:GetColor();
	local outlineColor = Color(255, 0, 0, 255);
	
	if (itemTable.category == "Consumables" or itemTable.category == "Alcohol") then
		outlineColor = Color(50, 50, 255, 255);
	elseif (itemTable.category == "Ammunition") then
		outlineColor = Color(255, 50, 100, 255);
	elseif (itemTable.category == "Clothing") then
		outlineColor = Color(255, 255, 175, 255);
	elseif (itemTable.category == "Implants") then
		outlineColor = Color(50, 255, 50, 255);
	elseif (itemTable.category == "Stimpacks") then
		outlineColor = Color(255, 255, 50, 255);
	elseif (itemTable.category == "Reusables") then
		outlineColor = Color(50, 255, 255, 255);
	elseif (itemTable.category == "Storage") then
		outlineColor = Color(175, 50, 100, 255);
	elseif (itemTable.category == "Tomes") then
		outlineColor = Color(125, 175, 25, 255);
	elseif (itemTable.category == "Other") then
		outlineColor = Color(255, 150, 150, 255);
	end;
	
	cam.Start3D( EyePos(), EyeAngles() );
		render.SuppressEngineLighting(true);
			render.SetColorModulation(outlineColor.r / 255, outlineColor.g / 255, outlineColor.b / 255);
				render.SetAmbientLight(1, 1, 1);
					entity:SetModelScale( Vector() * ( 1.025 + (sineWave / 320) ) );
						SetMaterialOverride(OUTLINE_MATERIAL);
					entity:DrawModel();
					
					entity:SetModelScale( Vector() );
				SetMaterialOverride(nil);
			render.SetColorModulation(r / 255, g / 255, b / 255);
		render.SuppressEngineLighting(false);
	cam.End3D();
end;

-- Called each tick.
function SCHEMA:Tick()
	local frameTime = FrameTime();
	local curTime = CurTime();
	
	if ( IsValid(g_LocalPlayer) ) then
		if ( NEXUS:IsCharacterScreenOpen(true) ) then
			if (!self.musicSound) then
				self.musicSound = CreateSound(g_LocalPlayer, "music/hl2_song12_long.mp3");
				self.musicSound:PlayEx(0.4, 75);
			end;
		elseif (self.musicSound) then
			self.musicSound:FadeOut(8);
			
			timer.Simple(8, function()
				self.musicSound = nil;
			end);
		end;
	end;
end;

-- Called just after the opaque renderables have been drawn.
function SCHEMA:PostDrawOpaqueRenderables(drawingDepth, drawingSkybox)
	if (!drawingSkybox) then
		local colorWhite = nexus.schema.GetColor("white");
		local colorBlack = Color(0, 0, 0, 255);
		local eyeAngles = EyeAngles();
		local curTime = UnPredictedCurTime();
		local eyePos = EyePos();
		
		if (curTime >= self.nextGetSnipers) then
			self.nextGetSnipers = curTime + 1;
			self.sniperPlayers = {};
			
			for k, v in ipairs( g_Player.GetAll() ) do
				if ( nexus.player.GetWeaponRaised(v) ) then
					local weapon = v:GetActiveWeapon();
					
					if ( v:HasInitialized() and IsValid(weapon) ) then
						local weaponClass = string.lower( weapon:GetClass() );
						
						if (weaponClass == "rcs_g3sg1" and weapon:GetNetworkedInt("Zoom") != 0) then
							self.sniperPlayers[#self.sniperPlayers + 1] = v;
						end;
					end;
				end;
			end;
			
			if (#self.sniperPlayers == 0) then
				self.sniperPlayers = nil;
			end;
		end;
		
		if (self.sniperPlayers) then
			cam.Start3D(eyePos, eyeAngles);
				for k, v in ipairs(self.sniperPlayers) do
					if ( IsValid(v) and v:Alive() ) then
						local trace = nexus.player.GetRealTrace(v, true);
						local position = trace.HitPos + (trace.HitNormal * 1.25);
						
						render.SetMaterial(self.laserSprite);
						render.DrawSprite( position, 4, 4, Color(255, 0, 0, 255) );
					end;
				end;
			cam.End3D();
		end;
	end;
end;

-- Called when the menu's items should be adjusted.
function SCHEMA:MenuItemsAdd(menuItems)
	menuItems:Add("Bounties", "nx_Bounties", "Place a bounty on someone, or view active bounties.");
	menuItems:Add("Alliance", "nx_Alliance", "Manage the alliance that you are a member of.");
	menuItems:Add("Augments", "nx_Augments", "Purchase new or view already purchased augments.");
	menuItems:Add("Victories", "nx_Victories", "View a list of possible victories to achieve.");
end;

-- Called when an entity's menu options are needed.
function SCHEMA:GetEntityMenuOptions(entity, options)
	local mineTypes = {"nx_firemine", "nx_freezemine", "nx_explomine"};
	
	if ( table.HasValue( mineTypes, entity:GetClass() ) ) then
		options["Defuse"] = "nx_mineDefuse";
	elseif (entity:GetClass() == "prop_ragdoll") then
		local player = nexus.entity.GetPlayer(entity);
		
		if ( !player or !player:Alive() ) then
			if ( nexus.augments.Has(AUG_MUTILATOR) ) then
				options["Mutilate"] = "nx_corpseMutilate";
			end;
			
			if ( nexus.augments.Has(AUG_LIFEBRINGER) ) then
				options["Revive"] = "nx_corpseRevive";
			end;
			
			options["Loot"] = "nx_corpseLoot";
		end;
	elseif (entity:GetClass() == "nx_belongings") then
		options["Open"] = "nx_belongingsOpen";
	elseif (entity:GetClass() == "nx_breach") then
		options["Charge"] = "nx_breachCharge";
	elseif ( entity:IsPlayer() ) then
		local cashEnabled = nexus.config.Get("cash_enabled"):Get();
		local myAlliance = g_LocalPlayer:GetAlliance();
		local cashName = nexus.schema.GetOption("name_cash");
		
		if (myAlliance and g_LocalPlayer:GetRank() == RANK_MAJ) then
			options["Invite"] = {
				Callback = function(entity) NEXUS:RunCommand("AllyInvite"); end,
				arguments = true,
				toolTip = "Invite this character to your alliance."
			};
		end;
		
		if ( entity:GetSharedVar("sh_Tied") ) then
			options["Untie"] = {
				Callback = function(entity) NEXUS:RunCommand("PlyUntie"); end,
				arguments = true
			};
		end;
		
		if (cashEnabled) then
			options["Give"] = {
				Callback = function(entity)
					Derma_StringRequest("Amount", "How much do you want to give them?", "0", function(text)
						NEXUS:RunCommand(string.gsub(cashName, "%s", "").."Give", entity:Name(), text);
					end);
				end,
				arguments = true,
				toolTip = "Give this character some "..string.lower(cashName).."."
			};
		end;
	end;
end;

-- Called when a player's footstep sound should be played.
function SCHEMA:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	return true;
end;

-- Called when a text entry has gotten focus.
function SCHEMA:OnTextEntryGetFocus(panel)
	self.textEntryFocused = panel;
end;

-- Called when a text entry has lost focus.
function SCHEMA:OnTextEntryLoseFocus(panel)
	self.textEntryFocused = nil;
end;

-- Called when the cinematic intro info is needed.
function SCHEMA:GetCinematicIntroInfo()
	return {
		credits = "A roleplaying game designed by "..self.author..".",
		title = nexus.config.Get("intro_text_big"):Get(),
		text = nexus.config.Get("intro_text_small"):Get()
	};
end;

-- Called when a player's name should be shown as unrecognised.
function SCHEMA:PlayerCanShowUnrecognised(player, x, y, color, alpha, flashAlpha)
	if ( player:GetSharedVar("sh_SkullMask") and !nexus.augments.Has(AUG_ROUSELESS) ) then
		return "This character is wearing a Skull Mask.";
	end;
end;

-- Called when a player's phys desc override is needed.
function SCHEMA:GetPlayerPhysDescOverride(player, physDesc)
	local physDescOverride = nil;
	
	if (!self.oneDisguise) then
		self.oneDisguise = true;
			local disguise = player:GetSharedVar("sh_Disguise");
			
			if ( IsValid(disguise) ) then
				physDescOverride = nexus.player.GetPhysDesc(disguise);
			end;
		self.oneDisguise = nil;
	end;
	
	if (physDescOverride) then
		return physDescOverride;
	end;
end;

-- Called when the scoreboard's class players should be sorted.
function SCHEMA:ScoreboardSortClassPlayers(class, a, b)
	return a:GetRank() > b:GetRank();
end;

-- Called when a player's scoreboard class is needed.
function SCHEMA:GetPlayerScoreboardClass(player)
	local alliance = player:GetAlliance();
	
	if (alliance) then
		return alliance;
	end;
end;

-- Called when the target player's name is needed.
function SCHEMA:GetTargetPlayerName(player)
	local targetPlayerName = nil;
	local playerAlliance = player:GetAlliance();
	local myAlliance = g_LocalPlayer:GetAlliance();
	
	if (!self.oneDisguise) then
		self.oneDisguise = true;
			local disguise = player:GetSharedVar("sh_Disguise");
			
			if ( IsValid(disguise) and nexus.player.DoesRecognise(disguise) ) then
				targetPlayerName = disguise:Name();
			end;
		self.oneDisguise = nil;
	end;
	
	if (targetPlayerName) then
		return targetPlayerName;
	end;
	
	if (myAlliance and playerAlliance) then
		if (myAlliance == playerAlliance) then
			return player:GetRank(true)..". "..player:Name();
		end;
	end;
end;

-- Called when the scoreboard's player info should be adjusted.
function SCHEMA:ScoreboardAdjustPlayerInfo(info)
	local playerAlliance = info.player:GetAlliance();
	local myAlliance = g_LocalPlayer:GetAlliance();
	
	if (myAlliance and playerAlliance) then
		if (myAlliance == playerAlliance) then
			info.name = info.player:GetRank(true)..". "..info.player:Name();
		end;
	end;
end;

-- Called when an entity is created.
function SCHEMA:OnEntityCreated(entity)
	if ( entity:IsPlayer() ) then
		entity:SetNetworkedVarProxy("sh_Alliance", function(entity, name, oldValue, newValue)
			timer.Simple(FrameTime(), function()
				if ( nexus.menu.GetOpen() ) then
					if (nexus.menu.GetActivePanel() == self.alliancePanel) then
						self.alliancePanel:Rebuild();
					end;
				end;
			end);
		end);
		
		entity:SetNetworkedVarProxy("sh_Bounty", function(entity, name, oldValue, newValue)
			timer.Simple(FrameTime(), function()
				if ( nexus.menu.GetOpen() ) then
					if (nexus.menu.GetActivePanel() == self.bountyPanel) then
						self.bountyPanel:Rebuild();
					end;
				end;
			end);
		end);
	end;
end

-- Called when the local player is created.
function SCHEMA:LocalPlayerCreated()
	g_LocalPlayer:SetNetworkedVarProxy("sh_SkullMask", function(entity, name, oldValue, newValue)
		if (oldValue != newValue) then
			nexus.inventory.Rebuild();
		end;
	end);
	
	g_LocalPlayer:SetNetworkedVarProxy("sh_Implant", function(entity, name, oldValue, newValue)
		if (oldValue != newValue) then
			nexus.inventory.Rebuild();
		end;
	end);
	
	g_LocalPlayer:SetNetworkedVarProxy("sh_Clothes", function(entity, name, oldValue, newValue)
		if (oldValue != newValue) then
			nexus.inventory.Rebuild();
		end;
	end);
	
	self:OnEntityCreated(g_LocalPlayer);
end;

-- Called when the target's status should be drawn.
function SCHEMA:DrawTargetPlayerStatus(target, alpha, x, y)
	local colorInformation = nexus.schema.GetColor("information");
	local thirdPerson = "him";
	local mainStatus = nil;
	local untieText = nil;
	local gender = "He";
	local action = nexus.player.GetAction(target);
	
	if (nexus.player.GetGender(target) == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if ( target:Alive() ) then
		if (action == "die") then
			mainStatus = gender.." is in critical condition.";
		end;
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." is clearly unconscious.";
		end;
		
		if ( target:GetSharedVar("sh_Tied") ) then
			if (nexus.player.GetAction(g_LocalPlayer) == "untie") then
				mainStatus = gender.. " is being untied.";
			else
				mainStatus = gender.." has been tied up.";
			end;
		elseif (nexus.player.GetAction(g_LocalPlayer) == "chloro") then
			mainStatus = gender.." is having chloroform used on "..thirdPerson..".";
		elseif (nexus.player.GetAction(g_LocalPlayer) == "tie") then
			mainStatus = gender.." is being tied up.";
		end;
		
		if (mainStatus) then
			y = NEXUS:DrawInfo(mainStatus, x, y, colorInformation, alpha);
		end;
		
		return y;
	end;
end;

-- Called to check if a player does recognise another player.
function SCHEMA:PlayerDoesRecognisePlayer(player, status, simple, default)
	local doesRecognise = nil;
	
	if ( player:GetSharedVar("sh_SkullMask") and !nexus.augments.Has(AUG_ROUSELESS) ) then
		return false;
	end;
	
	if (!self.oneDisguise and !SCOREBOARD_PANEL) then
		self.oneDisguise = true;
			local disguise = player:GetSharedVar("sh_Disguise");
			
			if ( IsValid(disguise) and nexus.player.DoesRecognise(disguise) ) then
				doesRecognise = true;
			end;
		self.oneDisguise = nil;
	end;
	
	return doesRecognise;
end;

-- Called when the target player's text is needed.
function SCHEMA:GetTargetPlayerText(player, targetPlayerText)
	if ( !player:GetSharedVar("sh_SkullMask") or nexus.augments.Has(AUG_ROUSELESS) ) then
		local disguise = player:GetSharedVar("sh_Disguise");
		
		if ( IsValid(disguise) ) then
			player = disguise;
		end;
		
		local alliance = player:GetAlliance();
		local honor = player:GetSharedVar("sh_Honor");
		
		if ( alliance and player:Alive() ) then
			if ( player:IsLeader() ) then
				targetPlayerText:Add( "ALLIANCE", "A leader of \""..alliance.."\".", Color(50, 50, 150, 255) );
			else
				targetPlayerText:Add( "ALLIANCE", "A member of \""..alliance.."\".", Color(50, 150, 50, 255) );
			end;
		end;
		
		if (honor >= 50) then
			targetPlayerText:Add( "HONOR", self:PlayerGetHonorText(player, honor), Color(175, 255, 75, 255) );
		else
			targetPlayerText:Add( "HONOR", self:PlayerGetHonorText(player, honor), Color(255, 75, 175, 255) );
		end;
	end;
end;

-- Called when screen space effects should be rendered.
function SCHEMA:RenderScreenspaceEffects()
	local modify = {};
	
	if ( !NEXUS:IsScreenFadedBlack() ) then
		local curTime = CurTime();
		
		if (self.flashEffect) then
			local timeLeft = math.Clamp( self.flashEffect[1] - curTime, 0, self.flashEffect[2] );
			local incrementer = 1 / self.flashEffect[2];
			
			if (timeLeft > 0) then
				modify = {};
				
				modify["$pp_colour_brightness"] = 0;
				modify["$pp_colour_contrast"] = 1 + (timeLeft * incrementer);
				modify["$pp_colour_colour"] = 1 - (incrementer * timeLeft);
				modify["$pp_colour_addr"] = incrementer * timeLeft;
				modify["$pp_colour_addg"] = 0;
				modify["$pp_colour_addb"] = 0;
				modify["$pp_colour_mulr"] = 1;
				modify["$pp_colour_mulg"] = 0;
				modify["$pp_colour_mulb"] = 0;
				
				DrawColorModify(modify);
				DrawMotionBlur(1 - (incrementer * timeLeft), 1, 0);
			else
				self.flashEffect = nil;
			end;
		end;
		
		if (self.tearGassed) then
			local timeLeft = self.tearGassed - curTime;
			
			if (timeLeft > 0) then
				if (timeLeft >= 15) then
					DrawMotionBlur(0.1 + ( 0.9 / (20 - timeLeft) ), 1, 0);
				else
					DrawMotionBlur(0.1, 1, 0);
				end;
			else
				self.tearGassed = nil;
			end;
		end;
	end;
end;

-- Called when the foreground HUD should be painted.
function SCHEMA:HUDPaintForeground()
	local dateTimeFont = nexus.schema.GetFont("date_time_text");
	local colorWhite = nexus.schema.GetColor("white");
	local y = (ScrH() / 2) - 128;
	local x = ScrW() / 2;
	
	if ( g_LocalPlayer:Alive() ) then
		local curTime = CurTime();
		
		if (self.stunEffects) then
			for k, v in pairs(self.stunEffects) do
				local alpha = math.Clamp( ( 255 / v[2] ) * (v[1] - curTime), 0, 255 );
				
				if (alpha != 0) then
					draw.RoundedBox( 0, 0, 0, ScrW(), ScrH(), Color(255, 255, 255, alpha) );
				else
					table.remove(self.stunEffects, k);
				end;
			end;
		end;
		
		if (self.shotEffect) then
			local alpha = math.Clamp( ( 255 / self.shotEffect[2] ) * (self.shotEffect[1] - curTime), 0, 255 );
			local scrH = ScrH();
			local scrW = ScrW();
			
			if (alpha != 0) then
				draw.RoundedBox( 0, 0, 0, scrW, scrH, Color(255, 50, 50, alpha) );
			else
				self.shotEffect = nil;
			end;
		end;
		
		if (#self.damageNotify > 0) then
			NEXUS:OverrideMainFont(dateTimeFont);
				for k, v in ipairs(self.damageNotify) do
					local alpha = math.Clamp( (255 / v.duration) * (v.endTime - curTime), 0, 255 );
					
					if (alpha != 0) then
						local position = v.position:ToScreen();
						local canSee = nexus.player.CanSeePosition(g_LocalPlayer, v.position);
						
						if (canSee) then
							NEXUS:DrawInfo(v.text, position.x, position.y - ( (255 - alpha) / 2 ), v.color, alpha);
						end;
					else
						table.remove(self.damageNotify, k);
					end;
				end;
			NEXUS:OverrideMainFont(false);
		end;
	end;
	
	if ( IsValid(self.hotkeyMenu) ) then
		NEXUS:OverrideMainFont( nexus.schema.GetFont("menu_text_tiny") );
			NEXUS:DrawInfo("Select which item to use...", self.hotkeyMenu.x, self.hotkeyMenu.y, colorWhite, 255, true, function(x, y, width, height)
				return x, y - height - 8;
			end);
		NEXUS:OverrideMainFont(false);
	end;
end;

-- Called when the local player's item menu should be adjusted.
function SCHEMA:PlayerAdjustItemMenu(itemTable, menuPanel, itemFunctions)
	if (itemTable.OnUse) then
		local subMenu = menuPanel:AddSubMenu("Hotkey");
		
		subMenu:AddOption("Slot #1", function()
			self.hotkeyItems[1] = itemTable.uniqueID;
			NEXUS:SaveSchemaData("hotkeys", self.hotkeyItems);
		end);
		
		subMenu:AddOption("Slot #2", function()
			self.hotkeyItems[2] = itemTable.uniqueID;
			NEXUS:SaveSchemaData("hotkeys", self.hotkeyItems);
		end);
		
		subMenu:AddOption("Slot #3", function()
			self.hotkeyItems[3] = itemTable.uniqueID;
			NEXUS:SaveSchemaData("hotkeys", self.hotkeyItems);
		end);
	end;
end;
-- Called to get the screen text info.
function SCHEMA:GetScreenTextInfo()
	local blackFadeAlpha = NEXUS:GetBlackFadeAlpha();
	
	if (!g_LocalPlayer:Alive() and self.deathType) then
		return {
			alpha = blackFadeAlpha,
			title = "YOU WERE KILLED BY "..self.deathType,
			text = "It probably isn't random, you just don't know the reason."
		};
	elseif ( g_LocalPlayer:GetSharedVar("sh_BeingChloro") ) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "SOMEBODY IS USING CHLOROFORM ON YOU"
		};
	elseif ( g_LocalPlayer:GetSharedVar("sh_BeingTied") ) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "YOU ARE BEING TIED UP"
		};
	elseif ( g_LocalPlayer:GetSharedVar("sh_Tied") ) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "YOU HAVE BEEN TIED UP"
		};
	end;
end;

-- Called when the chat box info should be adjusted.
function SCHEMA:ChatBoxAdjustInfo(info)
	if ( IsValid(info.speaker) ) then
		if (info.data.anon) then
			info.name = "Somebody";
		end;
	end;
end;

-- Called when the post progress bar info is needed.
function SCHEMA:GetPostProgressBarInfo()
	if ( g_LocalPlayer:Alive() ) then
		local action, percentage = nexus.player.GetAction(g_LocalPlayer, true);
		
		if (action == "die") then
			if ( nexus.augments.Has(AUG_ADRENALINE) ) then
				return {text = "You are slowly healing yourself.", percentage = percentage, flash = percentage > 75};
			else
				return {text = "You are slowly dying.", percentage = percentage, flash = percentage > 75};
			end;
		elseif (action == "chloroform") then
			return {text = "You are using chloroform on somebody.", percentage = percentage, flash = percentage > 75};
		elseif (action == "defuse") then
			return {text = "You are defusing a landmine.", percentage = percentage, flash = percentage > 75};
		end;
	end;
end;