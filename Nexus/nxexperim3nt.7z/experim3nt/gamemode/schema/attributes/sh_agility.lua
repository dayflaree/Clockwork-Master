--[[
Name: "sh_agility.lua".
Product: "eXperim3nt".
--]]

local ATTRIBUTE = {};

ATTRIBUTE.name = "Agility";
ATTRIBUTE.maximum = 100;
ATTRIBUTE.uniqueID = "agt";
ATTRIBUTE.description = "Affects your overall speed, e.g: how fast you run.";
ATTRIBUTE.characterScreen = true;

ATB_AGILITY = nexus.attribute.Register(ATTRIBUTE);