--[[
Name: "sh_dexterity.lua".
Product: "eXperim3nt".
--]]

local ATTRIBUTE = {};

ATTRIBUTE.name = "Dexterity";
ATTRIBUTE.maximum = 100;
ATTRIBUTE.uniqueID = "dex";
ATTRIBUTE.description = "Affects your overall dexterity, e.g: how fast you can tie/untie.";
ATTRIBUTE.characterScreen = true;

ATB_DEXTERITY = nexus.attribute.Register(ATTRIBUTE);