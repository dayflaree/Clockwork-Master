--[[
Name: "sh_codek_producer.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "generator_base";
ITEM.name = "Codek Producer";
ITEM.cost = 120;
ITEM.model = "models/props_lab/reciever01a.mdl";
ITEM.business = true;
ITEM.description = "Produces a medium rate of codeks over time.\nThis is not permanent and can be destroyed by others.";

ITEM.generator = {
	powerPlural = "Batteries",
	powerName = "Battery",
	uniqueID = "nx_codekproducer",
	maximum = 1,
	health = 150,
	power = 4,
	cash = 60,
	name = "Codek Producer",
};

nexus.item.Register(ITEM);