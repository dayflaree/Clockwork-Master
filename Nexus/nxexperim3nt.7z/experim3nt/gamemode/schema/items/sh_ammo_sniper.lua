--[[
Name: "sh_ammo_sniper.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "7.65x59mm Rounds";
ITEM.cost = 400;
ITEM.model = "models/items/redammo.mdl";
ITEM.weight = 2;
ITEM.uniqueID = "ammo_sniper";
ITEM.business = true;
ITEM.ammoClass = "ar2";
ITEM.ammoAmount = 16;
ITEM.description = "A red container with 7.65x59mm on the side.";

nexus.item.Register(ITEM);