--[[
Name: "sh_bandit_cloak.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 500;
ITEM.name = "Bandit Cloak";
ITEM.armor = 0.05;
ITEM.weight = 1;
ITEM.business = true;
ITEM.replacement = "models/srp/stalker_bandit_veteran2.mdl";
ITEM.description = "A bandit cloak, usually used for comitting bad deeds.\nProvides you with 5% bullet resistance.";

nexus.item.Register(ITEM);