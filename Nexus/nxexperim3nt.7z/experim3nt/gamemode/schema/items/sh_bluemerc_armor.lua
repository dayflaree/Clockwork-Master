--[[
Name: "sh_bluemerc_armor.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 3500;
ITEM.name = "Bluemerc Armor";
ITEM.armor = 0.275;
ITEM.weight = 2;
ITEM.business = true;
ITEM.replacement = "models/salem/blue.mdl";
ITEM.description = "Some Bluemerc branded armor with a stylised mask.\nProvides you with 27.5% bullet resistance.";

nexus.item.Register(ITEM);