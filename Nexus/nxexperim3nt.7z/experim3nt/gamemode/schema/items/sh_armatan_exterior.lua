--[[
Name: "sh_armatan_exterior.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 4750;
ITEM.name = "Armatan Exterior";
ITEM.armor = 0.35;
ITEM.weight = 3;
ITEM.business = true;
ITEM.replacement = "models/spx2.mdl";
ITEM.description = "Some Armatan branded exterior armor.\nProvides you with 35% bullet resistance.";

nexus.item.Register(ITEM);