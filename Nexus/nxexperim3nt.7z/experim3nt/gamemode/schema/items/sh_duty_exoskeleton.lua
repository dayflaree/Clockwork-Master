--[[
Name: "sh_duty_exoskeleton.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 9000;
ITEM.name = "Duty Exoskeleton";
ITEM.armor = 0.55;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/srp/masterduty.mdl";
ITEM.description = "A Duty branded exoskeleton.\nProvides you with 55% bullet resistance.";

nexus.item.Register(ITEM);