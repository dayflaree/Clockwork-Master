--[[
Name: "sh_spray_can.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.name = "Spray Can";
ITEM.cost = 100;
ITEM.model = "models/sprayca2.mdl";
ITEM.weight = 1;
ITEM.category = "Reusables"
ITEM.business = true;
ITEM.description = "A standard spray can filled with paint.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

nexus.item.Register(ITEM);