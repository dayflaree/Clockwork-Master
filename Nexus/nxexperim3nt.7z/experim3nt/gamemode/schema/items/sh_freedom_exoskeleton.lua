--[[
Name: "sh_freedom_exoskeleton.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 7000;
ITEM.name = "Freedom Exoskeleton";
ITEM.armor = 0.45;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/srp/masterfreedom.mdl";
ITEM.description = "A Freedom branded exoskeleton.\nProvides you with 45% bullet resistance.";

nexus.item.Register(ITEM);