--[[
Name: "sh_medic_uniform.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 1000;
ITEM.name = "Medic Uniform";
ITEM.armor = 0.1;
ITEM.group = "group03m";
ITEM.weight = 1;
ITEM.business = true;
ITEM.description = "A medic uniform with a yellow insignia.\nProvides you with 10% bullet resistance.";

nexus.item.Register(ITEM);