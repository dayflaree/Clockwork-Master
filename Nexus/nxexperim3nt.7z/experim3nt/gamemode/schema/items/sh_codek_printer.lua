--[[
Name: "sh_codek_printer.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "generator_base";
ITEM.name = "Codek Printer";
ITEM.cost = 60;
ITEM.model = "models/props_lab/reciever01b.mdl";
ITEM.business = true;
ITEM.description = "Prints a minor rate of codeks over time.\nThis is not permanent and can be destroyed by others.";

ITEM.generator = {
	powerPlural = "Batteries",
	powerName = "Battery",
	uniqueID = "nx_codekprinter",
	maximum = 1,
	health = 100,
	power = 3,
	cash = 50,
	name = "Codek Printer",
};

nexus.item.Register(ITEM);