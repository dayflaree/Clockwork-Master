--[[
Name: "sh_bluemoon_biosuit.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 2750;
ITEM.name = "Bluemoon Biosuit";
ITEM.armor = 0.225;
ITEM.weight = 2;
ITEM.business = true;
ITEM.replacement = "models/bio_suit/slow_bio_suit.mdl";
ITEM.description = "A Bluemoon branded biological protection suit.\nProvides you with 22.5% bullet resistance.";

nexus.item.Register(ITEM);