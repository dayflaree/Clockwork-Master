--[[
Name: "sh_mercenary_exoskeleton.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 8500;
ITEM.name = "Mercenary Exoskeleton";
ITEM.armor = 0.525;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/srp/mastermercenary.mdl";
ITEM.description = "A Mercenary branded exoskeleton.\nProvides you with 52.5% bullet resistance.";

nexus.item.Register(ITEM);