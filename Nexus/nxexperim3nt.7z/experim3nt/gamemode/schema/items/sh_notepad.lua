--[[
Name: "sh_notepad.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.name = "Notepad";
ITEM.cost = 80;
ITEM.model = "models/props_lab/clipboard.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Edit";
ITEM.business = true;
ITEM.category = "Reusables";
ITEM.description = "A clean and professional notepad with a cardboard backing.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	NEXUS:StartDataStream(player, "Notepad", player:GetCharacterData("notepad") or "");
	
	nexus.player.SetMenuOpen(player, false);
	
	return false;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

nexus.item.Register(ITEM);