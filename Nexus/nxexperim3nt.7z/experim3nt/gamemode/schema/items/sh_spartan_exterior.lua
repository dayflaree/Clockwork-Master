--[[
Name: "sh_spartan_exterior.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 4500;
ITEM.name = "Spartan Exterior";
ITEM.armor = 0.325;
ITEM.weight = 3;
ITEM.business = true;
ITEM.replacement = "models/spex.mdl";
ITEM.description = "Some Spartan branded exterior armor.\nProvides you with 32.5% bullet resistance.";

nexus.item.Register(ITEM);