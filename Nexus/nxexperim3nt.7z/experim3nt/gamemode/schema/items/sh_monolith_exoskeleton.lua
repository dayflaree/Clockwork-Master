--[[
Name: "sh_monolith_exoskeleton.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 8000;
ITEM.name = "Monolith Exoskeleton";
ITEM.armor = 0.5;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/srp/mastermonolith.mdl";
ITEM.description = "A Monolith branded exoskeleton.\nProvides you with 50% bullet resistance.";

nexus.item.Register(ITEM);