
--[[
Name: "sh_hellmerc_gasmask.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 6500;
ITEM.name = "Hellmerc Gasmask";
ITEM.armor = 0.425;
ITEM.weight = 3;
ITEM.business = true;
ITEM.replacement = "models/napalm_atc/slow.mdl";
ITEM.description = "Some Hellmerc branded armor with a mandatory gasmask.\nProvides you with 42.5% bullet resistance.";

nexus.item.Register(ITEM);