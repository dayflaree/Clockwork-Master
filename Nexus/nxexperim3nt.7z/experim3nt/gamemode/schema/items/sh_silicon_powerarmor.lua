--[[
Name: "sh_silicon_powerarmor.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 10000;
ITEM.name = "Silicon Powerarmor";
ITEM.armor = 0.6;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/nailgunner/silc.mdl";
ITEM.description = "Some Silicon branded powerarmor with extreme resistance.\nProvides you with 60% bullet resistance.";

nexus.item.Register(ITEM);