
--[[
Name: "sh_duplexan_exterior.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 5000;
ITEM.name = "Duplexan Exterior";
ITEM.armor = 0.375;
ITEM.weight = 3;
ITEM.business = true;
ITEM.replacement = "models/spx7.mdl";
ITEM.description = "Some Duplexan branded exterior armor.\nProvides you with 37.5% bullet resistance.";

nexus.item.Register(ITEM);