--[[
Name: "sh_stalker_exoskeleton.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 7500;
ITEM.name = "Stalker Exoskeleton";
ITEM.armor = 0.475;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/srp/masterstalker.mdl";
ITEM.description = "A Stalker branded exoskeleton.\nProvides you with 47.5% bullet resistance.";

nexus.item.Register(ITEM);