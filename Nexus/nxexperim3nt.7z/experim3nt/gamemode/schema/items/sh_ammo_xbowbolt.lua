--[[
Name: "sh_ammo_xbowbolt.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "ammo_base";
ITEM.name = "5.7x28mm Rounds";
ITEM.cost = 250;
ITEM.model = "models/items/boxzrounds.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_xbowbolt";
ITEM.business = true;
ITEM.ammoClass = "xbowbolt";
ITEM.ammoAmount = 48;
ITEM.description = "An average sized blue container with 5.7x28mm on the side.";

nexus.item.Register(ITEM);