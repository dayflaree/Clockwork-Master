--[[
Name: "sh_vintage_powerarmor.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 9500;
ITEM.name = "Vintage Powerarmor";
ITEM.armor = 0.575;
ITEM.weight = 4;
ITEM.business = true;
ITEM.replacement = "models/nailgunner/slow.mdl";
ITEM.description = "Some Vintage branded powerarmor with extreme resistance.\nProvides you with 57.5% bullet resistance.";

nexus.item.Register(ITEM);