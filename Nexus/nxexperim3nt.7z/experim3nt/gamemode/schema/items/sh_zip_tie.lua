--[[
Name: "sh_zip_tie.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.name = "Zip Tie";
ITEM.cost = 150;
ITEM.model = "models/items/crossbowrounds.mdl";
ITEM.weight = 0.1;
ITEM.useText = "Tie";
ITEM.business = true;
ITEM.description = "An orange zip tie with Thomas and Betts printed on the side.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (player.isTying) then
		nexus.player.Notify(player, "You are already tying a character!");
		
		return false;
	else
		local trace = player:GetEyeTraceNoCursor();
		local target = nexus.entity.GetPlayer(trace.Entity);
		
		if ( target and target:Alive() ) then
			if ( !target:GetSharedVar("sh_Tied") ) then
				if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
					local canTie = (target:GetAimVector():DotProduct( player:GetAimVector() ) > 0);
					local tieTime = SCHEMA:GetDexterityTime(player);
					
					if ( nexus.augments.Has(player, AUG_QUICKHANDS) ) then
						tieTime = tieTime * 0.5;
					end;
					
					if ( canTie or target:IsRagdolled() ) then
						nexus.player.SetAction(player, "tie", tieTime);
						
						target:SetSharedVar("sh_BeingTied", true);
						
						nexus.player.EntityConditionTimer(player, target, trace.Entity, tieTime, 192, function()
							local canTie = (target:GetAimVector():DotProduct( player:GetAimVector() ) > 0);
							
							if ( ( canTie or target:IsRagdolled() ) and player:Alive() and !player:IsRagdolled()
							and !target:GetSharedVar("sh_Tied") ) then
								return true;
							end;
						end, function(success)
							if (success) then
								player.isTying = nil;
								
								SCHEMA:TiePlayer(target, true);
								
								player:UpdateInventory("zip_tie", -1);
								player:ProgressAttribute(ATB_DEXTERITY, 15, true);
								
								nexus.victories.Progress(player, VIC_ZIPNINJA);
							else
								player.isTying = nil;
							end;
							
							nexus.player.SetAction(player, "tie", false);
							
							if ( IsValid(target) ) then
								target:SetSharedVar("sh_BeingTied", false);
							end;
						end);
					else
						nexus.player.Notify(player, "You cannot tie characters that are facing you!");
						
						return false;
					end;
					
					nexus.player.SetMenuOpen(player, false);
					
					player.isTying = true;
					
					return false;
				else
					nexus.player.Notify(player, "This character is too far away!");
					
					return false;
				end;
			else
				nexus.player.RunNexusCommand(player, "CharSearch");
				
				return false;
			end;
		else
			nexus.player.Notify(player, "That is not a valid character!");
			
			return false;
		end;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player.isTying) then
		nexus.player.Notify(player, "You are currently tying a character!");
		
		return false;
	end;
end;

nexus.item.Register(ITEM);