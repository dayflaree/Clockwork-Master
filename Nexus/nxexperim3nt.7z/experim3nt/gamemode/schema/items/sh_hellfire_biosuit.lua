--[[
Name: "sh_hellfire_biosuit.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 2750;
ITEM.name = "Hellfire Biosuit";
ITEM.armor = 0.225;
ITEM.weight = 2;
ITEM.business = true;
ITEM.replacement = "models/bio_suit/hell_bio_suit.mdl";
ITEM.description = "A Hellfire branded biological protection suit.\nProvides you with 22.5% bullet resistance.";

nexus.item.Register(ITEM);