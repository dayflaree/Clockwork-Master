--[[
Name: "sh_freezemine.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.name = "Freezemine";
ITEM.cost = 120;
ITEM.batch = 1;
ITEM.model = "models/props_combine/combine_mine01.mdl";
ITEM.weight = 2;
ITEM.business = true;
ITEM.category = "Landmines";
ITEM.description = "When another character touches it, it will deal explosion damage and freeze them.\nThis is not permanent and can be destroyed by others.";

-- Called when the item's shipment entity should be created.
function ITEM:OnCreateShipmentEntity(player, batch, position)
	local entity = ents.Create("nx_freezemine");
	
	nexus.player.GiveProperty(player, entity, true);
	
	entity:SetAngles( Angle(0, 0, 0 ) );
	entity:SetPos(position);
	entity:Spawn();
	
	return entity;
end;

-- Called when the item's drop entity should be created.
function ITEM:OnCreateDropEntity(player, position)
	return self:OnCreateShipmentEntity(player, 1, position);
end;

-- Called when a player attempts to order the item.
function ITEM:CanOrder(player)
	local totalMines = 0;
	
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_freezemine");
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_explomine");
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_firemine");
	
	if (totalMines >= 3) then
		nexus.player.Notify(player, "You have reached the maximum amount of landmines!");
		
		return false;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	local totalMines = 0;
	
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_freezemine");
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_explomine");
	totalMines = totalMines + nexus.player.GetPropertyCount(player, "nx_firemine");
	
	if (totalMines >= 3) then
		nexus.player.Notify(player, "You have reached the maximum amount of landmines!");
		
		return false;
	end;
end;

nexus.item.Register(ITEM);