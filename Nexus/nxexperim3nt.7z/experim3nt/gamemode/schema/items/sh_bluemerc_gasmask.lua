
--[[
Name: "sh_bluemerc_gasmask.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 6500;
ITEM.name = "Bluemerc Gasmask";
ITEM.armor = 0.425;
ITEM.weight = 3;
ITEM.business = true;
ITEM.replacement = "models/napalm_atc/blue.mdl";
ITEM.description = "Some Bluemerc branded armor with a mandatory gasmask.\nProvides you with 42.5% bullet resistance.";

nexus.item.Register(ITEM);