--[[
Name: "sh_exterior_riotgear.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 4000;
ITEM.name = "Exterior Riotgear";
ITEM.armor = 0.3;
ITEM.weight = 2.5;
ITEM.business = true;
ITEM.replacement = "models/riot_ex2.mdl";
ITEM.description = "A dark gray outfit with a mandatory skull mask.\nProvides you with 30% bullet resistance.";

nexus.item.Register(ITEM);