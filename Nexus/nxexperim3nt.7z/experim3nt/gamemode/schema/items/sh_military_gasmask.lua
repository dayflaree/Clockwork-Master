--[[
Name: "sh_military_gasmask.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 2500;
ITEM.name = "Military Gasmask";
ITEM.armor = 0.2;
ITEM.weight = 2;
ITEM.business = true;
ITEM.replacement = "models/pmc/pmc_4/pmc__07.mdl";
ITEM.description = "A military suit with a mandatory gasmask.\nProvides you with 20% bullet resistance.";

nexus.item.Register(ITEM);