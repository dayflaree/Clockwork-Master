--[[
Name: "sh_hellmerc_armor.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "clothes_base";
ITEM.cost = 3500;
ITEM.name = "Hellmerc Armor";
ITEM.armor = 0.275;
ITEM.weight = 2;
ITEM.business = true;
ITEM.replacement = "models/salem/slow.mdl";
ITEM.description = "Some Hellmerc branded armor with a stylised mask.\nProvides you with 27.5% bullet resistance.";

nexus.item.Register(ITEM);