--[[
Name: "sh_victories.lua".
Product: "eXperim3nt".
--]]

nexus.victories = {};

if (SERVER) then
	function nexus.victories.Progress(player, victory, progress)
		local victoryTable = nexus.victory.Get(victory);
		local victories = player:GetCharacterData("victories");
		
		if (!progress) then
			progress = 1;
		end;
		
		if (victoryTable) then
			if ( !victories[victoryTable.uniqueID] ) then
				victories[victoryTable.uniqueID] = 0;
			end;
			
			local currentVictory = victories[victoryTable.uniqueID];
			
			if (currentVictory < victoryTable.maximum) then
				victories[victoryTable.uniqueID] = math.Clamp(currentVictory + progress, 0, victoryTable.maximum);
				
				if (victories[victoryTable.uniqueID] == victoryTable.maximum) then
					nexus.chatBox.Add(nil, player, "victory", victoryTable.name);
					
					if (victoryTable.reward) then
						nexus.player.GiveCash(player, victoryTable.reward, victoryTable.name);
					end;
					
					if (victoryTable.OnAchieved) then
						victoryTable:OnAchieved(player);
					end;
				end;
			end;
			
			umsg.Start("nx_VictoriesProgress", player);
				umsg.Long(victoryTable.index);
				umsg.Short( victories[victoryTable.uniqueID] );
			umsg.End();
		else
			return false, "That is not a valid victory!";
		end;
	end;
	
	-- A function to get whether a player has a victory.
	function nexus.victories.Has(player, victory)
		local victoryTable = nexus.victory.Get(victory);
		
		if (victoryTable) then
			if (nexus.victories.Get(player, victory) == victoryTable.maximum) then
				return true;
			end;
		end;
		
		return false;
	end;
	
	-- A function to get a player's victory.
	function nexus.victories.Get(player, victory)
		local victoryTable = nexus.victory.Get(victory);
		local victories = player:GetCharacterData("victories");
		
		if (victoryTable) then
			return victories[victoryTable.uniqueID] or 0;
		else
			return 0;
		end;
	end;
else
	nexus.victories.stored = {};
	
	-- A function to get the victories panel.
	function nexus.victories.GetPanel()
		return nexus.victories.panel;
	end;
	
	-- A function to get the local player's victory.
	function nexus.victories.Get(victory)
		local victoryTable = nexus.victory.Get(victory);
		
		if (victoryTable) then
			return nexus.victories.stored[victoryTable.uniqueID] or 0;
		else
			return 0;
		end;
	end;
	
	-- A function to get whether the local player has a victory.
	function nexus.victories.Has(victory)
		local victoryTable = nexus.victory.Get(victory);
		
		if (victoryTable) then
			if (nexus.victories.Get(victory) == victoryTable.maximum) then
				return true;
			end;
		end;
		
		return false;
	end;
	
	usermessage.Hook("nx_VictoriesProgress", function(msg)
		local victory = msg:ReadLong();
		local progress = msg:ReadShort();
		local victoryTable = nexus.victory.Get(victory);
		
		if (victoryTable) then
			nexus.victories.stored[victoryTable.uniqueID] = progress;
			
			if ( nexus.menu.GetOpen() ) then
				local panel = nexus.victories.GetPanel();
				
				if (panel and nexus.menu.GetActivePanel() == panel) then
					panel:Rebuild();
				end;
			end;
		end;
	end);
	
	usermessage.Hook("nx_VictoriesClear", function(msg)
		nexus.victories.stored = {};
		
		if ( nexus.menu.GetOpen() ) then
			local panel = nexus.victories.GetPanel();
			
			if (panel and nexus.menu.GetActivePanel() == panel) then
				panel:Rebuild();
			end;
		end;
	end);
end;