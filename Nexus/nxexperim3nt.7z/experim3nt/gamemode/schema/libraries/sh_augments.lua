--[[
Name: "sh_augments.lua".
Product: "eXperim3nt".
--]]

nexus.augments = {};

if (SERVER) then
	function nexus.augments.Give(player, augment)
		local augmentTable = nexus.augment.Get(augment);
		local augments = player:GetCharacterData("augments");
		
		if (augmentTable) then
			augments[augmentTable.uniqueID] = true;
			
			umsg.Start("nx_AugmentsGive", player);
				umsg.Long(augmentTable.index);
			umsg.End();
			
			if (augmentTable.OnGiven) then
				augmentTable:OnGiven(player);
			end;
			
			if (table.Count(augments) >= 5) then
				nexus.victories.Progress(player, VIC_TESTSUBJECT);
			end;
		else
			return false, "That is not a valid augment!";
		end;
	end;
	
	-- A function to get whether a player has an augment.
	function nexus.augments.Has(player, augment)
		local augmentTable = nexus.augment.Get(augment);
		local augments = player:GetCharacterData("augments");
		
		if (augmentTable) then
			if ( augments[augmentTable.uniqueID] ) then
				if (augmentTable.honor == "perma") then
					return true;
				elseif (augmentTable.honor == "good") then
					return player:IsGood();
				else
					return player:IsBad();
				end;
			else
				return false;
			end;
		else
			return false;
		end;
	end;
else
	nexus.augments.stored = {};
	
	-- A function to get the augments panel.
	function nexus.augments.GetPanel()
		return nexus.augments.panel;
	end;
	
	-- A function to get whether the local player has an augment.
	function nexus.augments.Has(augment)
		local augmentTable = nexus.augment.Get(augment);
		
		if (augmentTable) then
			if ( nexus.augments.stored[augmentTable.uniqueID] ) then
				if (augmentTable.honor == "perma") then
					return true;
				elseif (augmentTable.honor == "good") then
					return g_LocalPlayer:IsGood();
				else
					return g_LocalPlayer:IsBad();
				end;
			else
				return false;
			end;
		else
			return false;
		end;
	end;
	
	usermessage.Hook("nx_AugmentsGive", function(msg)
		local augment = msg:ReadLong();
		local augmentTable = nexus.augment.Get(augment);
		
		if (augmentTable) then
			nexus.augments.stored[augmentTable.uniqueID] = true;
			
			if ( nexus.menu.GetOpen() ) then
				local panel = nexus.augments.GetPanel();
				
				if (panel and nexus.menu.GetActivePanel() == panel) then
					panel:Rebuild();
				end;
			end;
		end;
	end);
	
	usermessage.Hook("nx_AugmentsClear", function(msg)
		nexus.augments.stored = {};
		
		if ( nexus.menu.GetOpen() ) then
			local panel = nexus.augments.GetPanel();
			
			if (panel and nexus.menu.GetActivePanel() == panel) then
				panel:Rebuild();
			end;
		end;
	end);
end;