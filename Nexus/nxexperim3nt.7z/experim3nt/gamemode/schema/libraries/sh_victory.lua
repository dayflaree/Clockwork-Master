--[[
Name: "sh_victory.lua".
Product: "eXperim3nt".
--]]

nexus.victory = {};
nexus.victory.stored = {};
nexus.victory.buffer = {};

-- A function to get the victory buffer.
function nexus.victory.GetBuffer()
	return nexus.victory.buffer;
end;

-- A function to get all victorys.
function nexus.victory.GetAll()
	return nexus.victory.stored;
end;

-- A function to register a new victory.
function nexus.victory.Register(victory)
	victory.uniqueID = victory.uniqueID or string.lower( string.gsub(victory.name, "%s", "_") );
	victory.index = NEXUS:GetShortCRC(victory.name);
	
	nexus.victory.stored[victory.uniqueID] = victory;
	nexus.victory.buffer[victory.index] = victory;
	
	resource.AddFile("materials/"..victory.image..".vtf");
	resource.AddFile("materials/"..victory.image..".vmt");
	
	return victory.uniqueID;
end;

-- A function to get an victory by its name.
function nexus.victory.Get(name)
	if (name) then
		if ( nexus.victory.buffer[name] ) then
			return nexus.victory.buffer[name];
		elseif ( nexus.victory.stored[name] ) then
			return nexus.victory.stored[name];
		else
			local victory;
			
			for k, v in pairs(nexus.victory.stored) do
				if ( string.find( string.lower(v.name), string.lower(name) ) ) then
					if (victory) then
						if ( string.len(v.name) < string.len(victory.name) ) then
							victory = v;
						end;
					else
						victory = v;
					end;
				end;
			end;
			
			return victory;
		end;
	end;
end;