--[[
Name: "sh_augment.lua".
Product: "eXperim3nt".
--]]

nexus.augment = {};
nexus.augment.stored = {};
nexus.augment.buffer = {};

-- A function to get the augment buffer.
function nexus.augment.GetBuffer()
	return nexus.augment.buffer;
end;

-- A function to get all augments.
function nexus.augment.GetAll()
	return nexus.augment.stored;
end;

-- A function to register a new augment.
function nexus.augment.Register(augment)
	augment.uniqueID = augment.uniqueID or string.lower( string.gsub(augment.name, "%s", "_") );
	augment.index = NEXUS:GetShortCRC(augment.name);
	
	nexus.augment.stored[augment.uniqueID] = augment;
	nexus.augment.buffer[augment.index] = augment;
	
	resource.AddFile("materials/"..augment.image..".vtf");
	resource.AddFile("materials/"..augment.image..".vmt");
	
	return augment.uniqueID;
end;

-- A function to get an augment by its name.
function nexus.augment.Get(name)
	if (name) then
		if ( nexus.augment.buffer[name] ) then
			return nexus.augment.buffer[name];
		elseif ( nexus.augment.stored[name] ) then
			return nexus.augment.stored[name];
		else
			local augment = nil;
			
			for k, v in pairs(nexus.augment.stored) do
				if ( string.find( string.lower(v.name), string.lower(name) ) ) then
					if (augment) then
						if ( string.len(v.name) < string.len(augment.name) ) then
							augment = v;
						end;
					else
						augment = v;
					end;
				end;
			end;
			
			return augment;
		end;
	end;
end;