--[[
Name: "sh_reckoner.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Reckoner";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/reckoner";
AUGMENT.honor = "evil";
AUGMENT.description = "Your generators will put codeks earned into your inventory.";

AUG_RECKONER = nexus.augment.Register(AUGMENT);