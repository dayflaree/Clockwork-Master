--[[
Name: "sh_obsessive.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Obsessive";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/obsessive";
AUGMENT.honor = "perma";
AUGMENT.description = "Your safebox can hold double the amount with this augment.";

AUG_OBSESSIVE = nexus.augment.Register(AUGMENT);