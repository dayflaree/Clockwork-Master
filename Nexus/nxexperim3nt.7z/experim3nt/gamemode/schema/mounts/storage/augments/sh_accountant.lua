--[[
Name: "sh_accountant.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Accountant";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/accountant";
AUGMENT.honor = "good";
AUGMENT.description = "Your generators will put codeks earned into your safebox.";

AUG_ACCOUNTANT = nexus.augment.Register(AUGMENT);