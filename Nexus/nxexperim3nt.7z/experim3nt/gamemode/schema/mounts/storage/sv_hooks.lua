--[[
Name: "sv_hooks.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

-- Called when a player attempts to earn generator cash.
function MOUNT:PlayerCanEarnGeneratorCash(player, info, cash)
	local positiveHintColor = nexus.schema.GetColor("positive_hint");
	
	if ( nexus.augments.Has(player, AUG_RECKONER) ) then
		nexus.player.GiveCash(player, info.cash, info.name);
		nexus.mount.Call("PlayerEarnGeneratorCash", player, info, info.cash);
		
		return false;
	elseif ( nexus.augments.Has(player, AUG_ACCOUNTANT) ) then
		nexus.hint.Send(player, "Your character's safebox gained "..FORMAT_CASH(info.cash)..".", 4, positiveHintColor);
		nexus.mount.Call("PlayerEarnGeneratorCash", player, info, info.cash);
		
		player:SetCharacterData("safeboxcash", player:GetCharacterData("safeboxcash") + info.cash);
		
		return false;
	end;
end;

-- Called when Nexus has loaded all of the entities.
function MOUNT:NexusInitPostEntity()
	self:LoadPersonalStorage();
	self:LoadStorage();
	self.highestCost = 0;
	self.randomItems = {};
	
	for k, v in pairs(nexus.item.stored) do
		if (v.business and !v.isRareItem and !v.isBaseItem) then
			if (v.cost and v.cost > self.highestCost) then
				self.highestCost = v.cost;
			end;
			
			self.randomItems[#self.randomItems + 1] = {
				v.uniqueID,
				v.weight,
				v.cost
			};
		end;
	end;
end;

-- Called when data should be saved.
function MOUNT:SaveData() self:SaveStorage(); end;

-- Called when a player attempts to breach an entity.
function MOUNT:PlayerCanBreachEntity(player, entity)
	if (entity.inventory and entity.password) then
		return true;
	end;
end;

-- Called when an entity attempts to be auto-removed.
function MOUNT:EntityCanAutoRemove(entity)
	if (self.storage[entity] or entity:GetNetworkedString("nx_StorageName") != "") then
		return false;
	end;
end;

-- Called when an entity's menu option should be handled.
function MOUNT:EntityHandleMenuOption(player, entity, option, arguments)
	local class = entity:GetClass();
	
	if (class == "nx_safebox" and arguments == "nx_containerOpen") then
		self:OpenContainer(player, entity);
	elseif (arguments == "nx_containerOpen") then
		if ( nexus.entity.IsPhysicsEntity(entity) ) then
			local model = string.lower( entity:GetModel() );
			
			if ( self.containers[model] ) then
				local containerWeight = self.containers[model][1];
				
				if (!entity.password or entity.breached) then
					self:OpenContainer(player, entity, containerWeight);
				else
					umsg.Start("nx_ContainerPassword", player);
						umsg.Entity(entity);
					umsg.End();
				end;
			end;
		end;
	end;
end;

-- Called when an entity has been breached.
function MOUNT:EntityBreached(entity, activator)
	if (entity.inventory and entity.password) then
		entity.breached = true;
		
		NEXUS:CreateTimer("Reset Breached: "..entity:EntIndex(), 120, 1, function()
			if ( IsValid(entity) ) then entity.breached = nil; end;
		end);
	end;
end;

-- Called when an entity is removed.
function MOUNT:EntityRemoved(entity)
	if (IsValid(entity) and !entity.areBelongings) then
		if (entity.inventory and table.Count(entity.inventory) > 0) then
			for k, v in pairs(entity.inventory) do
				if (v > 0) then
					for i = 1, v do
						local item = nexus.entity.CreateItem( nil, k, entity:GetPos() + Vector( 0, 0, math.random(1, 48) ), entity:GetAngles() );
						
						nexus.entity.CopyOwner(entity, item);
					end;
				end;
			end;
		end;
			
		if (entity.cash and entity.cash > 0) then
			nexus.entity.CreateCash( nil, entity.cash, entity:GetPos() + Vector( 0, 0, math.random(1, 48) ) );
		end;
			
		entity.inventory = nil;
		entity.cash = nil;
	end;
end;

-- Called when a player's prop cost info should be adjusted.
function MOUNT:PlayerAdjustPropCostInfo(player, entity, info)
	local model = string.lower( entity:GetModel() );
	
	if ( self.containers[model] ) then
		info.name = self.containers[model][2];
	end;
end;

-- Called to check if a player does have an item.
function MOUNT:PlayerDoesHaveItem(player, itemTable)
	local safebox = player:GetCharacterData("safeboxitems");
	
	if ( safebox and safebox[itemTable.uniqueID] ) then
		return safebox[itemTable.uniqueID];
	end;
end;

-- Called when a player's character data should be restored.
function MOUNT:PlayerRestoreCharacterData(player, data)
	data["safeboxitems"] = data["safeboxitems"] or {};
	data["safeboxcash"] = data["safeboxcash"] or 0;
	
	for k, v in pairs( data["safeboxitems"] ) do
		local itemTable = nexus.item.Get(k);
		
		if (!itemTable) then
			hook.Call("PlayerHasUnknownInventoryItem", NEXUS, player, data["safeboxitems"], k, v);
			
			data["safeboxitems"][k] = nil;
		end;
	end;
end;