--[[
Name: "sh_info.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Storage";
MOUNT.author = "kuropixel";
MOUNT.description = "Allows players to store money and items.";