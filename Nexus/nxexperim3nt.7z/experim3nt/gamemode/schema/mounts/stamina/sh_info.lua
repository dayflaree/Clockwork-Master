--[[
Name: "sh_info.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Stamina";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds stamina to limit player movement.";