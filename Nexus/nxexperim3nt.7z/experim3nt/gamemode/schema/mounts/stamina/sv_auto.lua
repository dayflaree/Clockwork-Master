--[[
Name: "sv_auto.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

local playerMeta = FindMetaTable("Player");

-- A function to handle a player's implants.
function playerMeta:HandleImplants()
	local thermalVision = self:GetWeapon("nx_thermalvision");
	local stealthCamo = self:GetWeapon("nx_stealthcamo");
	local isRagdolled = self:IsRagdolled();
	local isAlive = self:Alive();
	
	if (ValidEntity(thermalVision) and thermalVision:IsActivated() and isAlive and !isRagdolled) then
		if (self:GetCharacterData("stamina") > 5) then
			self:SetSharedVar("sh_Thermal", true);
		else
			self:EmitSound("items/nvg_off.wav");
			thermalVision:SetActivated(false);
		end;
	else
		self:SetSharedVar("sh_Thermal", false);
	end;
	
	if (ValidEntity(stealthCamo) and stealthCamo:IsActivated() and isAlive and !isRagdolled) then
		if (self:GetCharacterData("stamina") > 5) then
			if (!self.lastMaterial) then
				self.lastMaterial = self:GetMaterial();
			end;
			
			if (!self.lastColor) then
				self.lastColor = { self:GetColor() };
			end;
			
			self:SetMaterial("sprites/heatwave");
			self:SetColor(255, 255, 255, 0);
		else
			self:EmitSound("items/nvg_off.wav");
			stealthCamo:SetActivated(false);
		end;
	elseif (self.lastMaterial and self.lastColor) then
		self:SetMaterial(self.lastMaterial);
		self:SetColor( unpack(self.lastColor) );
		
		self.lastMaterial = nil;
		self.lastColor = nil;
	end;
end;