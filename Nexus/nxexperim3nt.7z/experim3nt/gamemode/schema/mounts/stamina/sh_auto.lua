--[[
Name: "sh_auto.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

NEXUS:IncludeDirectory(NEXUS:GetMountDirectory().."/victories/");

nexus.player.RegisterSharedVar("sh_Stamina", NWTYPE_NUMBER, true);
nexus.player.RegisterSharedVar("sh_Thermal", NWTYPE_BOOL, true);

NEXUS:IncludePrefixed("sv_hooks.lua");
NEXUS:IncludePrefixed("cl_hooks.lua");