--[[
Name: "sh_thermal_implant.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "weapon_base";
ITEM.name = "Thermal Implant";
ITEM.cost = 4000;
ITEM.model = "models/gibs/shield_scanner_gib1.mdl";
ITEM.weight = 1.5;
ITEM.category = "Implants";
ITEM.uniqueID = "nx_thermalvision";
ITEM.business = true;
ITEM.fakeWeapon = true;
ITEM.meleeWeapon = true;
ITEM.description = "An implant which allows you to see stealthed humans.\nUsing this implant will drain your stamina.";

nexus.item.Register(ITEM);