--[[
Name: "sh_stealth_implant.lua".
Product: "eXperim3nt".
--]]

local ITEM = {};

ITEM.base = "weapon_base";
ITEM.name = "Stealth Implant";
ITEM.cost = 5000;
ITEM.model = "models/gibs/shield_scanner_gib1.mdl";
ITEM.weight = 1.5;
ITEM.category = "Implants";
ITEM.uniqueID = "nx_stealthcamo";
ITEM.business = true;
ITEM.fakeWeapon = true;
ITEM.meleeWeapon = true;
ITEM.description = "An implant to allow you to become temporarily invisible.\nUsing this implant will drain your stamina.";

nexus.item.Register(ITEM);