--[[
Name: "cl_auto.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");

MOUNT.heatwaveMaterial = Material("sprites/heatwave");
MOUNT.heatwaveMaterial:SetMaterialFloat("$refractamount", 0);
MOUNT.shinyMaterial = Material("models/shiny");