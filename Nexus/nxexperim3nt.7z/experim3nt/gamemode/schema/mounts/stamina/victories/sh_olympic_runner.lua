--[[
Name: "sh_olympic_runner.lua".
Product: "eXperim3nt".
--]]

local VICTORY = {};

VICTORY.name = "Olympic Runner";
VICTORY.image = "victories/olympicrunner";
VICTORY.reward = 960;
VICTORY.maximum = 1;
VICTORY.description = "Get 100% stamina without using boosts.\nReceive a reward of 960 codeks.";

VIC_OLYMPICRUNNER = nexus.victory.Register(VICTORY);