--[[
Name: "sh_blood_donor.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Blood Donor";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/blooddonor";
AUGMENT.honor = "good";
AUGMENT.description = "You will receive 10% health back from damage you do with weapons.\nThis augment only applies when attacking evil characters.";

AUG_BLOODDONOR = nexus.augment.Register(AUGMENT);