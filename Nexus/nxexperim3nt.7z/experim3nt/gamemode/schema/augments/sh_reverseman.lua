--[[
Name: "sh_reverseman.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Reverseman";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/reverseman";
AUGMENT.honor = "evil";
AUGMENT.description = "Your Door Guarders will damage characters that try to shoot your doors open.";

AUG_REVERSEMAN = nexus.augment.Register(AUGMENT);