--[[
Name: "sh_reincarnation.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Reincarnation";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/reincarnation";
AUGMENT.honor = "perma";
AUGMENT.description = "With this augment you will spawn 75% quicker.";

AUG_REINCARNATION = nexus.augment.Register(AUGMENT);