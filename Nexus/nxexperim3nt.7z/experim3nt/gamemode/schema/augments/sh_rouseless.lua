--[[
Name: "sh_rouseless.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Rouseless";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/rouseless";
AUGMENT.honor = "evil";
AUGMENT.description = "You can see through other character's skull masks.";

AUG_ROUSELESS = nexus.augment.Register(AUGMENT);