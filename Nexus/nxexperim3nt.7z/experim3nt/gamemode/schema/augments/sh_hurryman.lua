--[[
Name: "sh_hurryman.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Hurryman";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/hurryman";
AUGMENT.honor = "good";
AUGMENT.description = "You will untie characters 50% faster.";

AUG_HURRYMAN = nexus.augment.Register(AUGMENT);