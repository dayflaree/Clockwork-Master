--[[
Name: "sh_metalship.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Metalship";
AUGMENT.cost = 2000;
AUGMENT.image = "augments/metalship";
AUGMENT.honor = "good";
AUGMENT.description = "Your Codek Producer will produce double the amount";

AUG_METALSHIP = nexus.augment.Register(AUGMENT);