--[[
Name: "sh_incendiary.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Incendiary";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/incendiary";
AUGMENT.honor = "good";
AUGMENT.description = "Your firearms have a 5% chance to set the victim on fire.\nThis augment only applies when attacking evil characters.";

AUG_INCENDIARY = nexus.augment.Register(AUGMENT);