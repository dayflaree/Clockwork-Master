--[[
Name: "sh_cashback.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Cashback";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/cashback";
AUGMENT.honor = "good";
AUGMENT.description = "You can cash in items in your inventory for 25% of their original price.";

AUG_CASHBACK = nexus.augment.Register(AUGMENT);