--[[
Name: "sh_thieving.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Thieving";
AUGMENT.cost = 2000;
AUGMENT.image = "augments/thieving";
AUGMENT.honor = "evil";
AUGMENT.description = "Your Codek Printer will produce double the amount.";

AUG_THIEVING = nexus.augment.Register(AUGMENT);