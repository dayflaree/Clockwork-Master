--[[
Name: "sh_steel_sheets.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Steel Sheets";
AUGMENT.cost = 1600;
AUGMENT.image = "augments/steelsheets";
AUGMENT.honor = "good";
AUGMENT.description = "With this augment your generators will be harder to destroy.";

AUG_STEELSHEETS = nexus.augment.Register(AUGMENT);