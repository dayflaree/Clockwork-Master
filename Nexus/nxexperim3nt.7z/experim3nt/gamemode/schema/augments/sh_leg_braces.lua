--[[
Name: "sh_leg_braces.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Leg Braces";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/legbraces";
AUGMENT.honor = "perma";
AUGMENT.description = "This augment will reduce your falling damage by 50%.";

AUG_LEGBRACES = nexus.augment.Register(AUGMENT);