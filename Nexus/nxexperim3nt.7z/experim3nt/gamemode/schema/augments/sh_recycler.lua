--[[
Name: "sh_recycler.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Recycler";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/recycler";
AUGMENT.honor = "evil";
AUGMENT.description = "You have a 50% chance of getting health back when you headshot a character.";

AUG_RECYCLER = nexus.augment.Register(AUGMENT);