--[[
Name: "sh_mutilator.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Mutilator";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/mutilator";
AUGMENT.honor = "evil";
AUGMENT.description = "Grants you the ability to mutilate corpses for health.";

AUG_MUTILATOR = nexus.augment.Register(AUGMENT);