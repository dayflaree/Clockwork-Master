--[[
Name: "sh_mercantile.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Mercantile";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/mercantile";
AUGMENT.honor = "perma";
AUGMENT.description = "All shipments will cost you 10% less to purchase.";

AUG_MERCANTILE = nexus.augment.Register(AUGMENT);