--[[
Name: "sh_lifebringer.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Lifebringer";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/lifebringer";
AUGMENT.honor = "good";
AUGMENT.description = "Grants you the ability to bring corpses back to life.\nWhen used, you donate half of your health to the target.";

AUG_LIFEBRINGER = nexus.augment.Register(AUGMENT);