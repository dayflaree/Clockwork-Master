--[[
Name: "sh_adrenaline.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Adrenaline";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/adrenaline";
AUGMENT.honor = "perma";
AUGMENT.description = "With this augment you will slowly revive yourself in critical condition.";

AUG_ADRENALINE = nexus.augment.Register(AUGMENT);