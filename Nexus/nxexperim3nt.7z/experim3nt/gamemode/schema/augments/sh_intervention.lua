--[[
Name: "sh_intervention.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Intervention";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/intervention";
AUGMENT.honor = "good";
AUGMENT.description = "Your Codek Guarders give your generators double protection.";

AUG_INTERVENTION = nexus.augment.Register(AUGMENT);