--[[
Name: "sh_hollow_point.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Hollow Point";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/hollowpoint";
AUGMENT.honor = "evil";
AUGMENT.description = "You will deal 10% more damage with weapons.\nThis augment only applies when attacking good characters.";

AUG_HOLLOWPOINT = nexus.augment.Register(AUGMENT);