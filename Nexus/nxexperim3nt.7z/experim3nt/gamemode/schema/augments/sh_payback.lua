--[[
Name: "sh_payback.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Payback";
AUGMENT.cost = 2000;
AUGMENT.image = "augments/payback";
AUGMENT.honor = "evil";
AUGMENT.description = "With this augment you receive more for destroying generators.\nThis only applies to generators belonging to good characters.";

AUG_PAYBACK = nexus.augment.Register(AUGMENT);