--[[
Name: "sh_ghostheart.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Ghostheart";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/ghostheart";
AUGMENT.honor = "good";
AUGMENT.description = "You will not show on other character's heartbeat sensors.";

AUG_GHOSTHEART = nexus.augment.Register(AUGMENT);