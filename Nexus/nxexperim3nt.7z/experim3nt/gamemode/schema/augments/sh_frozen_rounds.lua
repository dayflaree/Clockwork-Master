--[[
Name: "sh_frozen_rounds.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Frozen Rounds";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/frozenrounds";
AUGMENT.honor = "evil";
AUGMENT.description = "Your firearms have a 5% chance to freeze the victim temporarily.\nThis augment only applies when attacking good characters.";

AUG_FROZENROUNDS = nexus.augment.Register(AUGMENT);