--[[
Name: "sh_quickhands.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Quickhands";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/quickhands";
AUGMENT.honor = "evil";
AUGMENT.description = "You will tie characters 50% faster.";

AUG_QUICKHANDS = nexus.augment.Register(AUGMENT);