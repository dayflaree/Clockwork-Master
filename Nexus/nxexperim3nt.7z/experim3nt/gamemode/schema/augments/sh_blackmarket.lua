--[[
Name: "sh_blackmarket.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Blackmarket";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/blackmarket";
AUGMENT.honor = "evil";
AUGMENT.description = "You can cash in items in your inventory for 20% of their original price.";

AUG_BLACKMARKET = nexus.augment.Register(AUGMENT);