--[[
Name: "sh_armored.lua".
Product: "eXperim3nt".
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Armored";
AUGMENT.cost = 2000;
AUGMENT.image = "augments/armored";
AUGMENT.honor = "perma";
AUGMENT.description = "You will get 50% more armor when kevlar is used.";

AUG_ARMORED = nexus.augment.Register(AUGMENT);