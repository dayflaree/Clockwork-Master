--[[
Name: "sh_coms.lua".
Product: "eXperim3nt".
--]]

local COMMAND = {};

COMMAND = {};
COMMAND.tip = "Add a static prop at your target position.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if ( nexus.entity.IsPhysicsEntity(target) ) then
			for k, v in pairs(SCHEMA.staticProps) do
				if (target == v) then
					nexus.player.Notify(player, "This prop is already static!");
					
					return;
				end;
			end;
			
			SCHEMA.staticProps[#SCHEMA.staticProps + 1] = target;
			SCHEMA:SaveStaticProps();
			
			nexus.player.Notify(player, "You have added a static prop.");
		else
			nexus.player.Notify(player, "This entity is not a physics entity!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "StaticPropAdd");

COMMAND = {};
COMMAND.tip = "Remove static props at your target position.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if ( nexus.entity.IsPhysicsEntity(target) ) then
			for k, v in pairs(SCHEMA.staticProps) do
				if (target == v) then
					SCHEMA.staticProps[k] = nil;
					SCHEMA:SaveStaticProps();
					
					nexus.player.Notify(player, "You have removed a static prop.");
					
					return;
				end;
			end;
		else
			nexus.player.Notify(player, "This entity is not a physics entity!");
		end;
	else
		nexus.player.Notify(player, "You must look at a valid entity!");
	end;
end;

nexus.command.Register(COMMAND, "StaticPropRemove");

COMMAND = {};
COMMAND.tip = "Search a character if they are tied.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.entity.GetPlayer(player:GetEyeTraceNoCursor().Entity);
	
	if (target) then
		if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
			if ( !player:GetSharedVar("sh_Tied") ) then
				if ( target:GetSharedVar("sh_Tied") ) then
					if (target:GetVelocity():Length() == 0) then
						if (!player.searching) then
							target.beingSearched = true;
							player.searching = target;
							
							nexus.player.OpenStorage( player, {
								name = nexus.player.FormatRecognisedText(player, "%s", target),
								weight = nexus.inventory.GetMaximumWeight(target),
								entity = target,
								distance = 192,
								cash = nexus.player.GetCash(target),
								inventory = nexus.player.GetInventory(target),
								OnClose = function(player, storageTable, entity)
									player.searching = nil;
									
									if ( IsValid(entity) ) then
										entity.beingSearched = nil;
									end;
								end,
								OnTake = function(player, storageTable, itemTable)
									local target = nexus.entity.GetPlayer(storageTable.entity);
									
									if (target) then
										if (target:GetCharacterData("clothes") == itemTable.index) then
											if ( !target:HasItem(itemTable.index) ) then
												target:SetCharacterData("clothes", nil);
												
												itemTable:OnChangeClothes(target, false);
											end;
										elseif ( target:GetSharedVar("sh_SkullMask") ) then
											if ( !target:HasItem(itemTable.index) ) then
												itemTable:OnPlayerUnequipped(target);
											end;
										end;
									end;
								end,
								OnGive = function(player, storageTable, itemTable)
									if (player:GetCharacterData("clothes") == itemTable.index) then
										if ( !player:HasItem(itemTable.index) ) then
											player:SetCharacterData("clothes", nil);
											
											itemTable:OnChangeClothes(player, false);
										end;
									elseif ( player:GetSharedVar("sh_SkullMask") ) then
										if ( !player:HasItem(itemTable.index) ) then
											itemTable:OnPlayerUnequipped(player);
										end;
									end;
								end
							} );
						else
							nexus.player.Notify(player, "You are already searching a character!");
						end;
					else
						nexus.player.Notify(player, "You cannot search a moving character!");
					end;
				else
					nexus.player.Notify(player, "This character is not tied!");
				end;
			else
				nexus.player.Notify(player, "You don't have permission to do this right now!");
			end;
		else
			nexus.player.Notify(player, "This character is too far away!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "CharSearch");

COMMAND = {};
COMMAND.tip = "Heal a character if you own a medical item.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( !player:GetSharedVar("sh_Tied") ) then
		local itemTable = nexus.item.Get( arguments[1] );
		local entity = player:GetEyeTraceNoCursor().Entity;
		local healed = nil;
		local target = nexus.entity.GetPlayer(entity);
		
		if (target) then
			if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
				if (itemTable and arguments[1] == "health_vial") then
					if ( player:HasItem("health_vial") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 1.5), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_vial", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a health vial!");
					end;
				elseif (itemTable and arguments[1] == "health_kit") then
					if ( player:HasItem("health_kit") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player, 2), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_kit", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a health kit!");
					end;
				elseif (itemTable and arguments[1] == "bandage") then
					if ( player:HasItem("bandage") ) then
						target:SetHealth( math.Clamp( target:Health() + SCHEMA:GetHealAmount(player), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("bandage", -1, true);
						
						healed = true;
					else
						nexus.player.Notify(player, "You do not own a bandage!");
					end;
				else
					nexus.player.Notify(player, "This is not a valid item!");
				end;
				
				if (healed) then
					nexus.mount.Call("PlayerHealed", target, player, itemTable);
					
					if (nexus.player.GetAction(target) == "die") then
						nexus.player.SetRagdollState(target, RAGDOLL_NONE);
						nexus.victories.Progress(player, VIC_PARAMEDIC);
					end;
					
					player:FakePickup(target);
				end;
			else
				nexus.player.Notify(player, "This character is too far away!");
			end;
		else
			nexus.player.Notify(player, "You must look at a character!");
		end;
	else
		nexus.player.Notify(player, "You don't have permission to do this right now!");
	end;
end;

nexus.command.Register(COMMAND, "CharHeal");

COMMAND = {};
COMMAND.tip = "Set your radio frequency.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local frequency = arguments[1];
	
	if ( string.find(frequency, "^%d%d%d%.%d$") ) then
		local start, finish, decimal = string.match(frequency, "(%d)%d(%d)%.(%d)");
		
		start = tonumber(start);
		finish = tonumber(finish);
		decimal = tonumber(decimal);
		
		if (start == 1 and finish > 0 and finish < 10 and decimal > 0 and decimal < 10) then
			player:SetCharacterData("frequency", frequency);
			
			nexus.player.Notify(player, "You have set your radio frequency to "..frequency..".");
		else
			nexus.player.Notify(player, "The radio frequency must be between 101.1 and 199.9!");
		end;
	else
		nexus.player.Notify(player, "The radio frequency must look like xxx.x!");
	end;
end;

nexus.command.Register(COMMAND, "SetFreq");

COMMAND = {};
COMMAND.tip = "Create a new alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	umsg.Start("nx_CreateAlliance", player);
	umsg.End();
end;

nexus.command.Register(COMMAND, "AllyCreate");

COMMAND = {};
COMMAND.tip = "Invite a character to your alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetAlliance();
	local target = nexus.entity.GetPlayer(player:GetEyeTraceNoCursor().Entity);
	
	if (target) then
		if (alliance) then
			if ( player:IsLeader() ) then
				if (target:GetVelocity():Length() == 0) then
					target.allianceAuthenticate = alliance;
					target.allianceInviter = player;
					
					NEXUS:StartDataStream( {target}, "InviteAlliance", alliance );
					
					nexus.player.Notify(player, "You have invited this character to your alliance.");
					nexus.player.Notify(target, "A character has invited you to their alliance.");
				else
					nexus.player.Notify(target, "You cannot invite a character while they are moving!");
				end;
			else
				nexus.player.Notify(target, "You are not a leader of this alliance!");
			end;
		else
			nexus.player.Notify(target, "You are not in an alliance!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "AllyInvite");

COMMAND = {};
COMMAND.tip = "Make a character a leader of your alliance.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetAlliance();
	local target = nexus.player.Get( table.concat(arguments, " ") );
	
	if (alliance) then
		if ( player:IsLeader() ) then
			if (target) then
				local targetAlliance = target:GetAlliance();
				
				if (targetAlliance == alliance) then
					player:SetRank(RANK_MAJ);
					
					nexus.player.Notify(player, "You have made "..target:Name().." a leader of the '"..alliance.."' alliance.");
					nexus.player.Notify(target, player:Name().." has made you a leader of the '"..alliance.."' alliance.");
				else
					nexus.player.Notify(player, target:Name().." is not in your alliance!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You are not a leader of this alliance!");
		end;
	else
		nexus.player.Notify(target, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyMakeLeader");

COMMAND = {};
COMMAND.tip = "Kick a character out of your alliance.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetAlliance();
	local target = nexus.player.Get( table.concat(arguments, " ") );
	
	if (alliance) then
		if ( player:IsLeader() ) then
			if (target) then
				local targetAlliance = target:GetAlliance();
				
				if (targetAlliance == alliance) then
					if ( !target:IsLeader() ) then
						target:SetRank(RANK_RCT);
						target:SetAlliance("");
						
						nexus.player.Notify(player, "You have kicked "..target:Name().." from the '"..alliance.."' alliance.");
						nexus.player.Notify(target, player:Name().." has kicked you from the '"..alliance.."' alliance.");
					else
						nexus.player.Notify(player, "You cannot kick another leader out of the alliance!");
					end;
				else
					nexus.player.Notify(player, target:Name().." is not in your alliance!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You are not a leader of this alliance!");
		end;
	else
		nexus.player.Notify(player, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyKick");

COMMAND = {};
COMMAND.tip = "Leave your alliance.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local alliance = player:GetAlliance();
	
	if (alliance) then
		player:SetAlliance("");
		player:SetRank(RANK_RCT);
		
		nexus.player.Notify(player, "You have left the '"..alliance.."' alliance.");
	else
		nexus.player.Notify(target, "You are not in an alliance!");
	end;
end;

nexus.command.Register(COMMAND, "AllyLeave");

COMMAND = {};
COMMAND.tip = "Untie the character that you're looking at.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local untieTime = SCHEMA:GetDexterityTime(player);
	local eyeTrace = player:GetEyeTraceNoCursor();
	local target = eyeTrace.Entity;
	local entity = target;
	
	if ( nexus.augments.Has(player, AUG_HURRYMAN) ) then
		untieTime = untieTime * 0.5;
	end;
	
	if ( IsValid(target) ) then
		target = nexus.entity.GetPlayer(target);
		
		if ( target and !player:GetSharedVar("sh_Tied") ) then
			if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
				if ( target:GetSharedVar("sh_Tied") and target:Alive() ) then
					nexus.player.SetAction(player, "untie", untieTime);
					
					target:SetSharedVar("sh_BeingUntied", true);
					
					nexus.player.EntityConditionTimer(player, target, entity, untieTime, 192, function()
						return player:Alive() and target:Alive() and !player:IsRagdolled() and !player:GetSharedVar("sh_Tied");
					end, function(success)
						if (success) then
							self:TiePlayer(target, false);
							
							player:ProgressAttribute(ATB_DEXTERITY, 15, true);
						end;
						
						if ( IsValid(target) ) then
							target:SetSharedVar("sh_BeingUntied", false);
						end;
						
						nexus.player.SetAction(player, "untie", false);
					end);
				else
					nexus.player.Notify(player, "This character is either not tied, or not alive!");
				end;
			else
				nexus.player.Notify(player, "This character is too far away!");
			end;
		else
			nexus.player.Notify(player, "You don't have permission to do this right now!");
		end;
	else
		nexus.player.Notify(player, "You must look at a character!");
	end;
end;

nexus.command.Register(COMMAND, "PlyUntie");

COMMAND = {};
COMMAND.tip = "Disguise yourself as another character.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( player:HasItem("disguise_kit") ) then
		local curTime = CurTime();
		
		if (!player.nextUseDisguise or curTime >= player.nextUseDisguise) then
			local target = nexus.player.Get( arguments[1] );
			
			if (target) then
				if (player != target) then
					local success, fault = player:UpdateInventory("disguise_kit", -1);
					
					if (success) then
						nexus.player.Notify(player, "You are now disguised as "..target:Name().." for two minutes!");
						
						player.nextUseDisguise = curTime + 600;
						player:SetSharedVar("sh_Disguise", target);
						player.cancelDisguise = curTime + 120;
					end;
				else
					nexus.player.Notify(player, "You cannot disguise yourself as yourself!");
				end;
			else
				nexus.player.Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			nexus.player.Notify(player, "You cannot use another disguise kit for "..math.Round( math.ceil(player.nextUseDisguise - curTime) ).." second(s)!");
		end;
	else
		nexus.player.Notify(player, "You do not own a disguise kit!");
	end;
end;

nexus.command.Register(COMMAND, "DisguiseSet");

COMMAND = {};
COMMAND.tip = "Remove your character's active disguise.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( IsValid( player:GetSharedVar("sh_Disguise") ) ) then
		nexus.player.Notify(player, "You have taken off your disguise, your true identity is revealed!");
		
		player:SetSharedVar("sh_Disguise", NULL);
		player.cancelDisguise = nil;
	end;
end;

nexus.command.Register(COMMAND, "DisguiseRemove");

COMMAND = {};
COMMAND.tip = "Use a zip tie from your inventory.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	nexus.player.RunNexusCommand(player, "InvAction", "zip_tie", "use");
end;

nexus.command.Register(COMMAND, "InvZipTie");

COMMAND = {};
COMMAND.tip = "Add a bounty to a character.";
COMMAND.text = "<string Name> <number Bounty>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = nexus.player.Get( arguments[1] );
	local bounty = tonumber( arguments[2] );
	
	if (!bounty) then
		nexus.player.Notify(player, "This is not a valid bounty!");
		
		return;
	end;
	
	if (target) then
		local minimumBounty = 100;
		
		if ( target:IsGood() ) then
			minimumBounty = 200;
		end;
		
		if (bounty < minimumBounty) then
			if ( target:IsGood() ) then
				nexus.player.Notify(player, target:Name().." is good, and has a minimum bounty of "..FORMAT_CASH(minimumBounty, nil, true).."!");
			else
				nexus.player.Notify(player, target:Name().." is bad, and has a minimum bounty of "..FORMAT_CASH(minimumBounty, nil, true).."!");
			end;
			
			return;
		end;
		
		if ( nexus.player.CanAfford(player, minimumBounty) ) then
			nexus.player.Notify(player, "You have placed a bounty of "..FORMAT_CASH(bounty, nil, true).." on "..target:Name()..".");
			nexus.player.GiveCash(player, -bounty, "placing a bounty");
			
			target:AddBounty(bounty);
		else
			nexus.player.Notify(player, "You need another "..FORMAT_CASH(bounty - nexus.player.GetCash(player), nil, true).."!");
		end;
	end;
end;

nexus.command.Register(COMMAND, "Bounty");