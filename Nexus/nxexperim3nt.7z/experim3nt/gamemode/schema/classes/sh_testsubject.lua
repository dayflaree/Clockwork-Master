--[[
Name: "sh_testsubject.lua".
Product: "eXperim3nt".
--]]

local CLASS = {};

CLASS.wages = 20;
CLASS.color = Color(150, 125, 100, 255);
CLASS.factions = {FACTION_CIVILIAN};
CLASS.isDefault = true;
CLASS.wagesName = "Supplies";
CLASS.description = "The test subject of an Aperture Science experiment.";
CLASS.defaultPhysDesc = "Wearing tattered clothing";

CLASS_TESTSUBJECT = nexus.class.Register(CLASS, "Test Subject");