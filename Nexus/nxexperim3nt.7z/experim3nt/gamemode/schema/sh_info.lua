--[[
Name: "sh_info.lua".
Product: "eXperim3nt".
--]]

SCHEMA.name = "Novus Two";
SCHEMA.author = "Dickbanger McGee";
SCHEMA.description = "Derpscript v1337";