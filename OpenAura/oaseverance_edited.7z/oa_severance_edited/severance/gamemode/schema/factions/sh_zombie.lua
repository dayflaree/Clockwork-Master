--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = {};

FACTION.attributePointsScale = 2;
FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "severance/factions/civilian";
FACTION.maximum = 3;
FACTION.models = {
	female = {
		"models/zed/malezed_06.mdl",
		"models/zed/malezed_04.mdl",
		"models/zed/malezed_08.mdl"
	},
	male = {
		"models/zed/malezed_06.mdl",
		"models/zed/malezed_04.mdl",
		"models/zed/malezed_08.mdl"
	};
};

FACTION_ZOMBIE = openAura.faction:Register(FACTION, "Zombie");
