--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = {};

FACTION.attributePointsScale = 4;
FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "severance/factions/civilian";
FACTION.maximum = 3;
FACTION.models = {
	female = {
			"models/player/slow/fleshpound/slow.mdl"
	},
	male = {
			"models/player/slow/fleshpound/slow.mdl"
	};
};

FACTION_KARVIN = openAura.faction:Register(FACTION, "Karvin");
