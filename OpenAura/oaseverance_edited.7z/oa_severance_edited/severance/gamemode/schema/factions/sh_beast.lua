--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = {};

FACTION.attributePointsScale = 3;
FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "severance/factions/civilian";
FACTION.maximum = 3;
FACTION.models = {
	female = {
		"models/regenerator.mdl"
	},
	male = {
		"models/regenerator.mdl"
	};
};

FACTION_BEAST = openAura.faction:Register(FACTION, "Beast");
