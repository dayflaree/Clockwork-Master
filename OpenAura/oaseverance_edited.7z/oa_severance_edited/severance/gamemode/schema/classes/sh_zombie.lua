--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(150, 112, 97, 244);
CLASS.factions = {FACTION_ZOMBIE};
CLASS.isDefault = true;
CLASS.description = "Part of the undead masses...";
CLASS.defaultPhysDesc = "Undead";

CLASS_ZOMBIE = openAura.class:Register(CLASS, "Zombie");
