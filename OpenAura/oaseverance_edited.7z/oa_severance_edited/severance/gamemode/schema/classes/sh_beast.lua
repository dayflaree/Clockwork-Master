--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(150, 114, 97, 266);
CLASS.factions = {FACTION_BEAST};
CLASS.isDefault = true;
CLASS.description = "Part of the undead masses...";
CLASS.defaultPhysDesc = "Undead";

CLASS_BEAST = openAura.class:Register(CLASS, "Beast");
