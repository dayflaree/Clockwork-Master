--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(150, 112, 97, 244);
CLASS.factions = {FACTION_EXPSURVIVOR};
CLASS.isDefault = true;
CLASS.description = "A survivor who is more experience than the average survivor.";
CLASS.defaultPhysDesc = "Wearing decent clothing wearing a decent sized backpack.";

CLASS_EXPSURVIVOR = openAura.class:Register(CLASS, "Experienced Survivor");
