--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(126, 124, 99, 221);
CLASS.factions = {FACTION_KARVIN};
CLASS.isDefault = true;
CLASS.description = "A very mutated and intellegent form of the virus...";
CLASS.defaultPhysDesc = "Undead";

CLASS_KARVIN = openAura.class:Register(CLASS, "Karvin");
