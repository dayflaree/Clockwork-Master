--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	161,4,172
--]]

local CLASS = {};

CLASS.color = Color(161, 4, 172, 255);
CLASS.factions = {FACTION_ECO};
CLASS.isDefault = true;
CLASS.description = "A hell bent cult.";
CLASS.defaultPhysDesc = "Wearing white gas masks.";

CLASS_ECO = openAura.class:Register(CLASS, "Scientists");

