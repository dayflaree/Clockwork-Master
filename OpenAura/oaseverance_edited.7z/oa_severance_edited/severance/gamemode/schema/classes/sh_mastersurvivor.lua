--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(150, 112, 97, 244);
CLASS.factions = {FACTION_MASTERSURVIVOR};
CLASS.isDefault = true;
CLASS.description = "A survivor who has had previous.";
CLASS.defaultPhysDesc = "Wearing decent clothing with a gun on their side.";

CLASS_MASTERSURVIVOR = openAura.class:Register(CLASS, "Master Survivor");
