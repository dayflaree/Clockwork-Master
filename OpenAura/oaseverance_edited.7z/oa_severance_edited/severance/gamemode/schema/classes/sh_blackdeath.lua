--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = {};

CLASS.color = Color(25, 25, 112, 255);
CLASS.factions = {FACTION_BLACK};
CLASS.isDefault = true;
CLASS.description = " It is/was a mercenary or private military contracting group. Some of the best soldier or veterans are part of this group, and have the intent of clearing every city they come upon, and earn cash from the inhabitants...If alive.";
CLASS.defaultPhysDesc = "A badge across uniform showing ";

CLASS_BLACK = openAura.class:Register(CLASS, "Black Decay");