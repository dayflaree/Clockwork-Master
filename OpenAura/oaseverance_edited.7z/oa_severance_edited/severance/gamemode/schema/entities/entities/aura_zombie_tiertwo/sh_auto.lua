--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ENT.Base = "aura_basezombie_tiertwo";
ENT.Type = "ai";
ENT.Author = "kurozae/Zombiedance";
ENT.Spawnable = false;
ENT.PrintName = "Grasper";
ENT.Information = "Tier 2 running zombie!";
ENT.AdminSpawnable = true;
ENT.AutomaticFrameAdvance = true;