--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	models/player/sovietquarantine.mdl
	models/player/slow/fleshpound/slow.mdl
--]]

for k, v in pairs( _file.Find("models/player/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/player/"..v);
end;
for k, v in pairs( _file.Find("models/player/slow/fleshpound/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/player/slow/fleshpound/"..v);
end;
for k, v in pairs( _file.Find("models/pmc/pmc_4/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/pmc/pmc_4/"..v);
end;
for k, v in pairs( _file.Find("models/napalm_atc/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/napalm_atc/"..v);
end;

for k, v in pairs( _file.Find("models/nailgunner/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/nailgunner/"..v);
end;

for k, v in pairs( _file.Find("models/salem/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/salem/"..v);
end;

for k, v in pairs( _file.Find("models/bio_suit/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/bio_suit/"..v);
end;

for k, v in pairs( _file.Find("models/srp/*.mdl", true) ) do
	openAura.animation:AddMaleHumanModel("models/srp/"..v);
end;

openAura.animation:AddMaleHumanModel("models/humans/group03/male_experim.mdl");
openAura.animation:AddMaleHumanModel("models/pmc/pmc_4/pmc__07.mdl");
openAura.animation:AddMaleHumanModel("models/tactical_rebel.mdl");
openAura.animation:AddMaleHumanModel("models/riot_ex2.mdl");

local MODEL_SPX7 = openAura.animation:AddMaleHumanModel("models/spx7.mdl");
local MODEL_SPX2 = openAura.animation:AddMaleHumanModel("models/spx2.mdl");
local MODEL_SPEX = openAura.animation:AddMaleHumanModel("models/spex.mdl");
local SPEX_MODELS = {MODEL_SPEX, MODEL_SPX2, MODEL_SPX7};

for k, v in ipairs(SPEX_MODELS) do
	openAura.animation:AddOverride(v, "stand_grenade_idle", "LineIdle03");
	openAura.animation:AddOverride(v, "stand_pistol_idle", "LineIdle03");
	openAura.animation:AddOverride(v, "stand_blunt_idle", "LineIdle03");
	openAura.animation:AddOverride(v, "stand_slam_idle", "LineIdle03");
	openAura.animation:AddOverride(v, "stand_fist_idle", "LineIdle03");
end;

local groups = {34, 35, 36, 37, 38, 39, 40, 41};

for k, v in pairs(groups) do
	local groupName = "group"..v;

	for k2, v2 in pairs( _file.Find("models/humans/"..groupName.."/*.*", true) ) do
		local fileName = string.lower(v2);

		if ( string.find(fileName, "female") ) then
			openAura.animation:AddFemaleHumanModel("models/humans/"..groupName.."/"..fileName);
		else
			openAura.animation:AddMaleHumanModel("models/humans/"..groupName.."/"..fileName);
		end;
	end;
end;

openAura.option:SetKey( "default_date", {month = 1, year = 2011, day = 1} );
openAura.option:SetKey( "default_time", {minute = 0, hour = 0, day = 1} );
openAura.option:SetKey("description_attributes", "Check on your character's stats.");
openAura.option:SetKey("description_inventory", "Manage the items in your satchel.");
openAura.option:SetKey("description_business", "Distribute a variety of items.");
openAura.option:SetKey("model_shipment", "models/props_junk/cardboard_box003b.mdl");
openAura.option:SetKey("intro_image", "severance/severance");
openAura.option:SetKey("name_attributes", "Stats");
openAura.option:SetKey("name_attribute", "Stat");
openAura.option:SetKey("name_inventory", "Satchel");
openAura.option:SetKey("menu_music", "music/hl1_song21.mp3");
openAura.option:SetKey("name_business", "Distribution");
openAura.option:SetKey("gradient", "severance/bg_gradient");

openAura.config:ShareKey("intro_text_small");
openAura.config:ShareKey("intro_text_big");

openAura.player:RegisterSharedVar("permaKilled", NWTYPE_BOOL, true);
openAura.player:RegisterSharedVar("clothes", NWTYPE_NUMBER, true);
openAura.player:RegisterSharedVar("tied", NWTYPE_NUMBER);

openAura:IncludePrefixed("sh_coms.lua");
openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("cl_hooks.lua");
openAura:IncludePrefixed("cl_theme.lua");

openAura.config:ShareKey("intro_text_small");
openAura.config:ShareKey("intro_text_big");

openAura.quiz:SetEnabled(true);
openAura.quiz:AddQuestion("Do you understand that roleplaying is slow paced and relaxed?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("Can you type properly, using capital letters and full-stops?", 2, "yes i can", "Yes, I can.");
openAura.quiz:AddQuestion("You do not need weapons to roleplay, do you understand?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("You do not need items to roleplay, do you understand?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("What do you think serious roleplaying is about?", 2, "Collecting items and upgrades.", "Developing your character.");
openAura.quiz:AddQuestion("What universe is this roleplaying game set in?", 2, "Real Life.", "Apocalypse.");

openAura.flag:Add("y", "Distribution", "Access to distribute items around the map.");
