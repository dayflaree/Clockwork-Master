--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	Changing the name of this schema under any
	circumstances will result in dewhitelisting.
--]]

openAura.schema.name = "Severance";
openAura.schema.author = "kurozael";
openAura.schema.version = 1.0;
openAura.schema.description = "Out In The Open Roleplay";
