--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.name = "Hellfire Biosuit";
ITEM.weight = 2;
ITEM.cost = 18500;
ITEM.armorScale = 0.225;
ITEM.replacement = "models/bio_suit/hell_bio_suit.mdl";


openAura.item:Register(ITEM);
