--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.name = "Russian Trench Coat";
ITEM.weight = 2;
ITEM.cost = 12000;
ITEM.iconModel = "models/player/sovietquarantine.mdl";
ITEM.protection = 0.2;
ITEM.description = "A russian trench coat... Provides 20% protection";
ITEM.replacement = "models/player/sovietquarantine.mdl";
ITEM.pocketSpace = 4;

openAura.item:Register(ITEM);
