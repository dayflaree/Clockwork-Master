--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.name = "Armatan Exterior";
ITEM.weight = 3;
ITEM.armorScale = 0.35;
ITEM.cost = 45000;
ITEM.replacement = "models/spx2.mdl";
ITEM.description = "Some Armatan branded exterior armor.\nProvides you with 35% bullet resistance.";

openAura.item:Register(ITEM);
