--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.name = "Documents: Lab 32";
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.weight = 0.2;
ITEM.cost = 19000;
ITEM.useText = "Read";
ITEM.category = "Artifacts"
ITEM.description = "An peculiar artifact...";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
		openAura.player:Notify(player, "You begin to read the books but you don't understand much...<Take to scientists>");
		return false;
	end
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

openAura.item:Register(ITEM);