--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.name = "Riot Soldier Uniform";
ITEM.weight = 5;
ITEM.armorScale = 0.3;
ITEM.cost = 36000;
ITEM.replacement = "models/fallout_nv/nikout/LonesomeRoad/player/riotsoldier.mdl";
ITEM.description = "Built of mostly titanium making it /n quite durable against gun fire. 30% Protection";

openAura.item:Register(ITEM);
