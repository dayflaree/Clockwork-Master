--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.name = "Strange Container";
ITEM.model = "models/props_lab/jar01a.mdl";
ITEM.weight = 0.5;
ITEM.cost = 17000;
ITEM.useText = "Examine";
ITEM.category = "Artifacts"
ITEM.description = "An peculiar artifact...";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
		if (openAura.player:character.faction == FACTION_ECO) then
			openAura.player:Notify(player, "Inside the container is a strange liquid. The color you are unable to make out it is like nothing you have ever seen.");
			openAura.player:Notify(player, "It appears to be moving and beginning to glow. You slam on the cap before anything happens...");
		else
			openAura.player:Notify(player, "A container labeled 'Unknown Element'...<Take to scientists>");
	end
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

openAura.item:Register(ITEM);