--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	openAura.player:Notify(player, "You ");
	--]]

ITEM = openAura.item:New();
ITEM.name = "Peculiar Artifact";
ITEM.model = "models/props_lab/crematorcase.mdl";
ITEM.weight = 6.0;
ITEM.business = true;
ITEM.cost = 19000;
ITEM.customFunctions = {"Examine"};
ITEM.category = "Artifacts"
ITEM.description = "An peculiar artifact...";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (openAura.player:character.faction == FACTION_ECO) then
			openAura.player:Notify(player, "It is filled with an odd goo that shakes vigorously about...");
		else
			openAura.player:Notify(player, "You need special equipment to view this....");
		end;
	end;
end;
openAura.item:Register(ITEM);