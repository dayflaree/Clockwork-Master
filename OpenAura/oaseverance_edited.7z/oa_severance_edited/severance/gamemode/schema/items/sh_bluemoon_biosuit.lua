--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.name = "Bluemoon Biosuit";
ITEM.weight = 2;
ITEM.cost = 17000;
ITEM.armorScale = 0.225;
ITEM.replacement = "models/bio_suit/slow_bio_suit.mdl";
ITEM.description = "A Bluemoon branded biological protection suit.\nProvides you with 22.5% bullet resistance.\nProvides you with tear gas protection.";

openAura.item:Register(ITEM);
