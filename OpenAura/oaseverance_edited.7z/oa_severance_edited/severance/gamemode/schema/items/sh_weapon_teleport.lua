--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "weapon_base";
ITEM.name = "Teleport";
ITEM.model = "models/Weapons/W_pistol.mdl";
ITEM.weight = 0;
ITEM.cost = 99999;
ITEM.uniqueID = "weapon_teleporter";
ITEM.category = "Monster";
ITEM.description = "Lunge long distances at insane speeds!";
ITEM.meleeWeapon = true;
ITEM.isAttachment = false;
ITEM.loweredOrigin = Vector(-12, 2, 0);
ITEM.loweredAngles = Angle(-25, 15, -80);
ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 255, -90);
ITEM.attachmentOffsetVector = Vector(5, 5, -8);

openAura.item:Register(ITEM);
