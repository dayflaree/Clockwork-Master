--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.cost = 10000000;
ITEM.name = "Karvin Skin";
ITEM.weight = 1;
ITEM.business = true;
ITEM.armorScale = 0.80;
ITEM.replacement = "models/player/slow/fleshpound/slow.mdl";
ITEM.description = "The skin of a Karvin.\nProvides you with 80% bullet resistance.";

openAura.item:Register(ITEM);
