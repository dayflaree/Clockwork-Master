--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Display Typing";
PLUGIN.author = "kurozael";
PLUGIN.description = "This plugin will display whether a character is typing above their head.";