--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Cleaned Maps";
PLUGIN.author = "kurozael";
PLUGIN.description = "A static plugin which removes a lot of commonly unwanted entities from maps.";