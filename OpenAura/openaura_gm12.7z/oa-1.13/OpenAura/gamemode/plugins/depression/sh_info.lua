--[[
	Name: sh_info.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Depression";
PLUGIN.author = "Kipper";
PLUGIN.description = "BAWWW I WANT ATTENTION I CUT SELF";