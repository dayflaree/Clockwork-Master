--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Area Displays";
PLUGIN.author = "kurozael";
PLUGIN.description = "Allows nice three dimensional text to be displayed to players.";