--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Cross Server Chat";
PLUGIN.author = "kurozael";
PLUGIN.description = "Allows players to chat across servers using channels.";