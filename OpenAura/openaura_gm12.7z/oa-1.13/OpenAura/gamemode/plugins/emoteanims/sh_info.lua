--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Emote Anims";
PLUGIN.author = "kurozael";
PLUGIN.description = "With this plugin characters can perform a variety of different animations.";