--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Static Props";
PLUGIN.author = "kurozael";
PLUGIN.description = "Allows you to place props that will stay on the map permanently.";