--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Christmas";
PLUGIN.author = "kurozael";
PLUGIN.description = "A plugin to add a little bit of festiveness to your roleplay.";