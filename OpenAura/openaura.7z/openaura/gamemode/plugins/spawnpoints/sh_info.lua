--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Spawn Points";
PLUGIN.author = "kurozael";
PLUGIN.description = "Spawnpoints can be set for each class, faction or by default.";