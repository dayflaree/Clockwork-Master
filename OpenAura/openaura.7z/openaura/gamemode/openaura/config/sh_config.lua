--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]


openAura.config:ShareKey("use_opens_entity_menus");
openAura.config:ShareKey("additional_characters");
openAura.config:ShareKey("raised_weapon_system");
openAura.config:ShareKey("use_own_group_system");
openAura.config:ShareKey("default_inv_weight");
openAura.config:ShareKey("limb_damage_system");
openAura.config:ShareKey("unrecognised_name");
openAura.config:ShareKey("enable_crosshair");
openAura.config:ShareKey("recognise_system");
openAura.config:ShareKey("use_free_aiming");
openAura.config:ShareKey("enable_heartbeat");
openAura.config:ShareKey("cash_enabled");
openAura.config:ShareKey("default_physdesc");
openAura.config:ShareKey("enable_vignette");
openAura.config:ShareKey("cash_weight");
openAura.config:ShareKey("block_inv_binds");
openAura.config:ShareKey("fade_dead_npcs");
openAura.config:ShareKey("enable_headbob");
openAura.config:ShareKey("command_prefix");
openAura.config:ShareKey("default_flags");
openAura.config:ShareKey("minute_time");
openAura.config:ShareKey("local_voice");
openAura.config:ShareKey("talk_radius");
openAura.config:ShareKey("wages_name");
openAura.config:ShareKey("door_cost");