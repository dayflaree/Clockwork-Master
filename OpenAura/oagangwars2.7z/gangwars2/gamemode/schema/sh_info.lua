--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	Changing the name of this schema under any
	circumstances will result in dewhitelisting.
--]]

openAura.schema.name = "Gang Wars 2";
openAura.schema.author = "kurozael";
openAura.schema.version = 2.0;
openAura.schema.description = "Powerful gang warfare overthrows government control.";