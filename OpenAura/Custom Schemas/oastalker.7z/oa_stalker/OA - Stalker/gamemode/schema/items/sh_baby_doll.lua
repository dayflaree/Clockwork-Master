--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "junk_base";
ITEM.name = "Baby Doll";
ITEM.worth = 25;
ITEM.model = "models/props_c17/doll01.mdl";
ITEM.weight = 0.1
ITEM.description = "An old baby doll, it's missing an eye.";

openAura.item:Register(ITEM);