--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = openAura.item:New();
ITEM.base = "junk_base";
ITEM.name = "Vegetable Oil";
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl";
ITEM.worth = 20;
ITEM.weight = 0.1;
ITEM.description = "A bottle of vegetable oil, it isn't very tasty.";

openAura.item:Register(ITEM);