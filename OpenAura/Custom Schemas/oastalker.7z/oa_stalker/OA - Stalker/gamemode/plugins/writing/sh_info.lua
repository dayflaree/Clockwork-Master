--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Writing";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds paper to the schema which players can write on.";