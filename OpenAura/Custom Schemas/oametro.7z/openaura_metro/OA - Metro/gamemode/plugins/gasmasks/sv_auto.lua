--[[
	Name: sh_info.lua.
	Author: LauScript
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");
