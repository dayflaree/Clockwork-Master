--[[
	Name: sh_info.lua.
	Author: LauScript
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Gas Masks";
PLUGIN.author = "LauScript";
PLUGIN.description = "Adds gasmask and filter system for the players to wear.";