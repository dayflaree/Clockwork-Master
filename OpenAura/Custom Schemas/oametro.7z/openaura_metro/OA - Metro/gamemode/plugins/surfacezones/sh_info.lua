--[[
	Name: sh_info.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Surface Zones";
PLUGIN.author = "LauScript";
PLUGIN.description = "Add what is considered the surface.";