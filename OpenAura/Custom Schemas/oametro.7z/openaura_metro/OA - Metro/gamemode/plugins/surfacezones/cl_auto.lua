--[[
	Name: cl_auto.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");

-- Called when screen space effects should be rendered.
function PLUGIN:RenderScreenspaceEffects()
end;
