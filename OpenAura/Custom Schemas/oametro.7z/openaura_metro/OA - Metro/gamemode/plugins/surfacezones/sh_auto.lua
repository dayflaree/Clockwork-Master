--[[
	Name: sh_auto.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;

PLUGIN.surfaceZones = {};

openAura:IncludePrefixed("sh_coms.lua");
openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("cl_hooks.lua");