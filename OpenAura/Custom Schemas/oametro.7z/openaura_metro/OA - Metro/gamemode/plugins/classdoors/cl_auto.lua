--[[
	Name: cl_auto.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");