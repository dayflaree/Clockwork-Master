--[[
	Name: sh_info.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Class Doors";
PLUGIN.author = "TJjokerR";
PLUGIN.description = "Allows you to easily add doors that can only be opened by specific classes.";