--[[
	Name: sh_info.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Battery";
PLUGIN.author = "TJjokerR";
PLUGIN.description = "Adds battery to limit player movement.";