--[[
Name: "sh_info.lua".
Product: "Cider Two".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Storage";
PLUGIN.author = "kurozael";
PLUGIN.description = "Allows players to store money and items.";