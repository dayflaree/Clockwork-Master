--[[
Name: "sh_info.lua".
Product: "HL2 RP".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Books";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds books to the schema which players can read.";