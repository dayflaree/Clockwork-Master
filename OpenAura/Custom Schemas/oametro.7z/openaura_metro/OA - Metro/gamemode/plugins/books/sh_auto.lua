--[[
Name: "sh_auto.lua".
Product: "HL2 RP".
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("cl_hooks.lua");
openAura:IncludePrefixed("sv_hooks.lua");