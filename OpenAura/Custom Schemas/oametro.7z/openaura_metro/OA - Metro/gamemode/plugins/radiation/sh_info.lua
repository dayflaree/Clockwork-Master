--[[
	Name: sh_info.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Radiation";
PLUGIN.author = "TJjokerR";
PLUGIN.description = "Allows to mark areas that contain certain levels of radiation.";