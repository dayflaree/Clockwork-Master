--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	Changing the name of this schema under any
	circumstances will result in dewhitelisting.
--]]

openAura.schema.name = "Metro 2033";
openAura.schema.author = "Tokiz, OA by Kuro";
openAura.schema.version = 1.0;
openAura.schema.description = "A roleplaying game based on Metro 2033.";