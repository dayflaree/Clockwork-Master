--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ENT.Base = "aura_basezombie";
ENT.Type = "ai";
ENT.Author = "kurozael";
ENT.Spawnable = false;
ENT.PrintName = "Running Zombie";
ENT.Information = "A running zombie, watch out!";
ENT.AdminSpawnable = true;
ENT.AutomaticFrameAdvance = true;