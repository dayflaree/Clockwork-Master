--[[
	� 2012 Slidefuse LLC
	This plugin is released under the MIT license. Do whatever!
--]]

local PLUGIN = PLUGIN

openAura:IncludePrefixed("sh_auto.lua")