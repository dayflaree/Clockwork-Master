--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Render Fix";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This simple plugin fixes the rendering issues brought up by Garry's Mod updates 134 thru 136";