--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Flashlight";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds flashlights to allow players to see in the dark.";