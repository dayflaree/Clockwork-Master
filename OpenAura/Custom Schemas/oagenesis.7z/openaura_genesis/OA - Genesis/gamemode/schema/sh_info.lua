--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	Changing the name of this schema under any
	circumstances will result in dewhitelisting.
--]]

openAura.schema.name = "Genesis Roleplay";
openAura.schema.author = "Kelse with credit to Kurozael";
openAura.schema.version = 0.1;
openAura.schema.description = "A roleplaying gamemode based on Chernobyl and the terrible incidents that occured..";