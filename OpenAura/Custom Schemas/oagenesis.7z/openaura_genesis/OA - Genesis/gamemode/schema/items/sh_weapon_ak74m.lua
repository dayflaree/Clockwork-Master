--[[
Name: "sh_weapon_ak47.lua".
Product: "Severance".
--]]

ITEM = openAura.item:New();
ITEM.batch = 1;
ITEM.base = "weapon_base";
ITEM.name = "AK-74M";
ITEM.model = "models/weapons/w_ops_ak74.mdl";
ITEM.weight = 3;
ITEM.cost = 2000;
ITEM.access = "H59";
ITEM.business = true;
ITEM.uniqueID = "weapon_ak74m";
ITEM.weaponClass = "rcs_ak74";
ITEM.description = "A grey and brown weapon with rust on the side.";
ITEM.isAttachment = true;
ITEM.hasFlashlight = true;
ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);

openAura.item:Register(ITEM);