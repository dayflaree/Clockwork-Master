--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

require("openaura_core");
MsgN ("If you're not 92INF and you are using this YOU ARE BREAKING THE LAW.");
MsgN ("This gamemode is legally copyrighted.")
MsgN ("However, if you are 92INF Hi -Kelse")