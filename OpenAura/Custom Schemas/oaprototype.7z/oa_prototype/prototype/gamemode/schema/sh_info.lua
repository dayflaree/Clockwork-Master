--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	Changing the name of this schema under any
	circumstances will result in dewhitelisting.
--]]

openAura.schema.name = "Prototype: Green Zone";
openAura.schema.author = "Euphe";
openAura.schema.version = 1.0;
openAura.schema.description = "A roleplaying script based on the game Prototype.";