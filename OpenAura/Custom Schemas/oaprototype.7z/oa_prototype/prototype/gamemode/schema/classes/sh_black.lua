--[[
Name: "sh_black.lua".
Product: "Prototype".
--]]

local CLASS = {};

CLASS.wages = 25;
CLASS.color = Color(50, 50, 50, 255);

CLASS.factions = {FACTION_BLACK};
CLASS.description = "A member of Black Watch.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a scary black uniform";

CLASS_BLACK = openAura.class:Register(CLASS, "Black Watch");