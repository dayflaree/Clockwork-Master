--[[
Name: "sh_mil.lua".
Product: "Prototype".
--]]

local CLASS = {};

CLASS.wages = 25;
CLASS.color = Color(50, 150, 50, 255);
CLASS.factions = {FACTION_MIL};
CLASS.description = "A member of military forces dispatched to establish quarantine and guarantee safety to civilians.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a nice, clean military uniform";

CLASS_MIL = openAura.class:Register(CLASS, "Military");