--[[
Name: "sh_civilian.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 20;
CLASS.color = Color(100, 175, 100, 255);
CLASS.factions = {FACTION_GENTEC};
CLASS.description = "A Gen Tec scientist.";
CLASS.defaultPhysDesc = "Wearing nice and clean clothes";
CLASS.headsetGroup = 1;

CLASS_CIVILIAN = openAura.class:Register(CLASS, "Gen Tec");