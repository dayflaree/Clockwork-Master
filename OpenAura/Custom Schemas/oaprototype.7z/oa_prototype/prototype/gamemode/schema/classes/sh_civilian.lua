--[[
Name: "sh_civilian.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 5;
CLASS.color = Color(150, 125, 100, 255);
CLASS.factions = {FACTION_CIVILIAN};
CLASS.isDefault = true;
CLASS.description = "A regular inhabitant of the city.";
CLASS.defaultPhysDesc = "Wearing nice and clean clothes";

CLASS_CIVILIAN = openAura.class:Register(CLASS, "Civilian");