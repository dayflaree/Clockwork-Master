--[[
Name: "sh_hustler.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 10;
CLASS.limit = 16;
CLASS.color = Color(150, 125, 100, 255);
CLASS.classes = {"Civilian"};
CLASS.description = "A city drug dealer who manufactures illegal highs.\nThey have low wages compared to legal classes.";
CLASS.defaultPhysDesc = "Wearing nice and clean clothes";

CLASS_HUSTLER = openAura.class:Register(CLASS, "Hustler");