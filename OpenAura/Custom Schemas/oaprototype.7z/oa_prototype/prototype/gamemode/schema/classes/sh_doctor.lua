--[[
Name: "sh_doctor.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 15;
CLASS.limit = 32;
CLASS.color = Color(0, 125, 125, 255);
CLASS.classes = {"Debug"};
CLASS.description = "A doctor that works in the nearby hospital.\nThey earn money from the goverment.";
CLASS.defaultPhysDesc = "Wearing nice and clean clothes";

function CLASS:GetModel(player, defaultModel)
	local model = string.gsub ( defaultModel, "group%d%d", "Group01" )
	model = string.gsub ( model, "female", "scrubfe2" )
	model = string.gsub ( model, "male", "scrub1" )
	model = string.gsub ( model, "_01", "a" )
	model = string.gsub ( model, "_02", "b" )
	model = string.gsub ( model, "_03", "c" )
	model = string.gsub ( model, "_04", "d" )
	model = string.gsub ( model, "_05", "e" )
	model = string.gsub ( model, "_06", "f" )
	model = string.gsub ( model, "_07", "g" )
	model = string.gsub ( model, "_08", "h" )
	model = string.gsub ( model, "_09", "i" )
	return model
end

CLASS_DOCTOR = openAura.class:Register(CLASS, "Doctor");