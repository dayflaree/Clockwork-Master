--[[
Name: "sh_secretary.lua".
Product: "Cider Two".
--]]

local CLASS = {};

CLASS.wages = 25;
CLASS.color = Color(150, 125, 100, 255);
CLASS.limit = 8;
CLASS.factions = {FACTION_GOVERMENT};
CLASS.description = "A secretary working for the president.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a clean, black suit with no tie";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group10");
end;

CLASS_SECRETARY = openAura.class:Register(CLASS, "Secretary");