--[[
Name: "sh_mil.lua".
Product: "Prototype".
--]]

local FACTION = {};

FACTION.attributePointsScale = 2;
FACTION.useFullName = true;
FACTION.whitelist = true;

FACTION.limit = 32;
FACTION.models = {
	female = {
	},
	male = {
		"models/Rusty/NatGuard/male_01.mdl",
		"models/Rusty/NatGuard/male_02.mdl",
		"models/Rusty/NatGuard/male_03.mdl",
		"models/Rusty/NatGuard/male_04.mdl",
		"models/Rusty/NatGuard/male_05.mdl",
		"models/Rusty/NatGuard/male_06.mdl",
		"models/Rusty/NatGuard/male_07.mdl",
		"models/Rusty/NatGuard/male_08.mdl",
		"models/Rusty/NatGuard/male_09.mdl",
		"models/Rusty/NatGuard/male_01.mdl",
		"models/Rusty/NatGuard/male_02.mdl",
		"models/Rusty/NatGuard/male_03.mdl",
		"models/Rusty/NatGuard/male_04.mdl",
		"models/Rusty/NatGuard/male_05.mdl",
		"models/Rusty/NatGuard/male_06.mdl",
		"models/Rusty/NatGuard/male_07.mdl",
		"models/Rusty/NatGuard/male_08.mdl",
		"models/Rusty/NatGuard/male_09.mdl",
		"models/Rusty/NatGuard/male_01.mdl",
		"models/Rusty/NatGuard/male_02.mdl",
		"models/Rusty/NatGuard/male_03.mdl",
		"models/Rusty/NatGuard/male_04.mdl",
		"models/Rusty/NatGuard/male_05.mdl",
		"models/Rusty/NatGuard/male_06.mdl",
		"models/Rusty/NatGuard/male_07.mdl",
		"models/Rusty/NatGuard/male_08.mdl",
		"models/Rusty/NatGuard/male_09.mdl"
	};
};

FACTION_MIL = openAura.faction:Register(FACTION, "Military Forces");