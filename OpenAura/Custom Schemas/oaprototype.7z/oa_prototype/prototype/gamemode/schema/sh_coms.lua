--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]


-- Let's you ignite an object.
COMMAND = openAura.command:New();
COMMAND.tip = "Attempt to ignite a object"
COMMAND.text = ""
 
-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
 
	local ent = player:GetEyeTrace().Entity
	if ent:IsValid() and not ent:IsWorld() and not ent:IsPlayer() and not ent:IsNPC() and openAura.player:GetInventory(player)["ammo_smg1"]  then
	if player:GetPos():Distance(player:GetEyeTrace().HitPos) < 70 and ent:GetPhysicsObject():IsValid() and string.find(ent:GetPhysicsObject():GetMaterial(),"wood") then
 player:EmitSound("physics/metal/weapon_impact_soft1.wav")
 local t =  math.Max(100 - (openAura.schema:GetDexterityTime(player) * 3)  ,0)
 if math.random(1,5) == 2 then
 timer.Simple(2, function()
 ent:Ignite(t ,40)
 ent:EmitSound("ambient/fire/mtov_flame2.wav",70,100)
 end)
 end
 else
 	openAura.player:Notify(player, "The object you are trying to ignite is too far away");
 end
else
		openAura.player:Notify(player, "The object you are trying to ignite is not valid, or you do not have a lighter!");
			
end
 end;

openAura.command:Register(COMMAND, "Ignite");


-- Let's an Admin set a players health.
COMMAND = openAura.command:New();
COMMAND.tip = "Set a players health.";
COMMAND.text = "<string Name> <number Amount>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.player:Get( arguments[1] );
	local amount = arguments[2];
	
	if (!amount) then
		amount = 100;
	end;
	
	if (target) then
		openAura.player:NotifyAll(player:Name().." has set "..target:Name().."'s health to "..amount..".");
		
		target:SetHealth(amount);
	else
		openAura.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

openAura.command:Register(COMMAND, "PlySetHealth");

-- Let's you report a player.
COMMAND = openAura.command:New();
COMMAND.tip = "Report a player you don't like.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.optionalArguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	if (target and target:IsPlayer()) then
		if (player != target) then
			local listeners = {};
			for _, v in pairs(_player.GetAll()) do
				if (openAura.player:IsAdmin(v) or v:IsSuperAdmin() or v:IsAdmin()) then
					table.insert(listeners, v);
				end;
			end;
			if (table.Count(listeners) > 0) then
				openAura.chatBox:Add(listeners, player, "report", target:Name());
			else
				openAura.player:Notify(player, "We're sorry - No admins are online to hear your cries!");
			end;
		else
			openAura.player:Notify(player, "You cannot report yourself!");
		end;
	else
		openAura.player:Notify(player, "You must be looking at a character!");
	end;
end;

openAura.command:Register(COMMAND, "PlyReport");

-- Let's an Admin reward a player cash for good roleplay or other.
COMMAND = openAura.command:New();
COMMAND.tip = "Reward a player with money.";
COMMAND.text = "<string Name> <amount>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.player:Get( arguments[1] )
	local cashName = openAura.option:GetKey("name_cash");
	local reward = arguments[2]

	if (target) then
		openAura.player:GiveCash(target, reward, "Money from an admin");
		openAura.player:Notify(target, "You have been given "..reward.." "..cashName.." by an admin!");
	else
		openAura.player:Notify(target, "Invalid player!");
	end;
end;

openAura.command:Register(COMMAND, "PlyReward");


COMMAND = openAura.command:New();
COMMAND.tip = "Send out an advert to all players.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( openAura.player:CanAfford(player, 10) ) then
		openAura.chatBox:Add( nil, player, "advert", arguments[1] );
		openAura.player:GiveCash(player, -10, "making an advert");
	else
		openAura.player:Notify(player, "You need another "..FORMAT_CASH(10 - openAura.player:GetCash(player), nil, true).."!");
	end;
end;

openAura.command:Register(COMMAND, "Advert");

COMMAND = openAura.command:New();
COMMAND.tip = "Broadcast a message as the president.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:Team() == CLASS_PRESIDENT) then
		openAura.chatBox:Add( nil, player, "president", arguments[1] );
	else
		openAura.player:Notify(player, "You are not the president!");
	end;
end;

openAura.command:Register(COMMAND, "Broadcast");



COMMAND = openAura.command:New();
COMMAND.tip = "Set the name of a broadcaster.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if (target:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if (target:GetClass() == "aura_broadcaster") then
				target:SetNetworkedString( "name", arguments[1] );
			else
				openAura.player:Notify(player, "This entity is not a broadcaster!");
			end;
		else
			openAura.player:Notify(player, "This entity is too far away!");
		end;
	else
		openAura.player:Notify(player, "You must look at a valid entity!");
	end;
end;

openAura.command:Register(COMMAND, "SetBroadcasterName");

COMMAND = openAura.command:New();
COMMAND.tip = "Set the active government agenda.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local team = player:Team();
	
	if (team == CLASS_PRESIDENT) then
		openAura:SetSharedVar( "agenda", arguments[1] ); 
	else
		openAura.player:Notify(player, "You are not the president!");
	end;
end;

openAura.command:Register(COMMAND, "SetAgenda");

COMMAND.tip = "Disguise yourself as another character.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( player:HasItem("disguise_kit") ) then
		local curTime = CurTime();
		
		if (!player.nextUseDisguise or curTime >= player.nextUseDisguise) then
			local target = openAura.player:Get( arguments[1] );
			
			if (target) then
				if (player != target) then
					local success, fault = player:UpdateInventory("disguise_kit", -1);
					
					if (success) then
						openAura.player:Notify(player, "You are now disguised as "..target:Name().." for two minutes!");
						
						player.nextUseDisguise = curTime + 600;
						player:SetSharedVar("disguise", target);
						player.cancelDisguise = curTime + 120;
					end;
				else
					openAura.player:Notify(player, "You cannot disguise yourself as yourself!");
				end;
			else
				openAura.player:Notify(player, arguments[1].." is not a valid character!");
			end;
		else
			openAura.player:Notify(player, "You cannot use another disguise kit for "..math.Round( math.ceil(player.nextUseDisguise - curTime) ).." second(s)!");
		end;
	else
		openAura.player:Notify(player, "You do not own a disguise kit!");
	end;
end;

openAura.command:Register(COMMAND, "DisguiseSet");

COMMAND = openAura.command:New();
COMMAND.tip = "Remove your character's active disguise.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( IsValid( player:GetSharedVar("disguise") ) ) then
		openAura.player:Notify(player, "You have taken off your disguise, your true identity is revealed!");
		
		player:SetSharedVar("disguise", NULL);
		player.cancelDisguise = nil;
	end;
end;

openAura.command:Register(COMMAND, "DisguiseRemove");

COMMAND = openAura.command:New();
COMMAND.tip = "Demote a character from their position.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local isAdmin = ( player:IsUserGroup("operator") or player:IsAdmin() );
	
	if (player:Team() == CLASS_PRESIDENT or isAdmin) then
		local target = openAura.player:Get( arguments[1] );
		
		if (target) then
			local team = target:Team();
			
			if (team == CLASS_POLICE or team == CLASS_DISPENSER or team == CLASS_RESPONSE
			or team == CLASS_SECRETARY or isAdmin) then
				local name = _team.GetName(team);
				
				openAura.player:Notify(player, "You have demoted "..target:Name().." from "..name..".");
				openAura.player:Notify(target, player:Name().." has demoted you from "..name..".");
				
				openAura.class:Set(target, CLASS_CIVILIAN, true, true);
			else
				openAura.player:Notify(player, target:Name().." cannot be demoted from this position!");
			end;
		else
			openAura.player:Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		openAura.player:Notify(player, "You are not the president, or an administrator!");
	end;
end;

openAura.command:Register(COMMAND, "CharDemote");

COMMAND = openAura.command:New();
COMMAND.tip = "Blacklist a player from a class.";
COMMAND.text = "<string Name> <string Class>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.player:Get( arguments[1] )
	local class = openAura.class:Get( arguments[2] )
	
	if (target) then
		local blacklist = target:GetData("blacklist");
		
		if (class) then
			if ( table.HasValue(blacklist, class.index) ) then
				openAura.player:Notify(player, target:Name().." is already on the "..class.." blacklist!");
			else
				openAura.player:NotifyAll(player:Name().." has added "..target:Name().." to the "..class.name.." blacklist.");
				
				openAura:StartDataStream( {target}, "SetBlacklisted", {class.index, true} );
				
				table.insert(blacklist, class.index);
			end;
		else
			openAura.player:Notify(player, "This is not a valid class!");
		end;
	else
		openAura.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

openAura.command:Register(COMMAND, "PlyBlacklist");

COMMAND = openAura.command:New();
COMMAND.tip = "Unblacklist a player from a class.";
COMMAND.text = "<string Name> <string Class>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.player:Get( arguments[1] )
	local class = openAura.class:Get( arguments[2] )
	
	if (target) then
		local blacklist = target:GetData("blacklist");
		
		if (class) then
			if ( !table.HasValue(blacklist, class.index) ) then
				openAura.player:Notify(player, target:Name().." is not on the "..class.." blacklist!");
			else
				openAura.player:NotifyAll(player:Name().." has removed "..target:Name().." from the "..class.name.." blacklist.");
				
				openAura:StartDataStream( {target}, "SetBlacklisted", {class.index, false} );
				
				for k, v in ipairs(blacklist) do
					if (v == class.index) then
						table.remove(blacklist, k);
						
						break;
					end;
				end;
			end;
		else
			openAura.player:Notify(player, "This is not a valid class!");
		end;
	else
		openAura.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

openAura.command:Register(COMMAND, "PlyUnblacklist");

COMMAND = openAura.command:New();
COMMAND.tip = "Set the physical description of an object.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if ( IsValid(target) ) then
		if (target:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if ( openAura.entity:IsPhysicsEntity(target) ) then
				if ( player:QueryCharacter("key") == target:GetOwnerKey() ) then
					player.objectPhysDesc = target;
					
					umsg.Start("aura_ObjectPhysDesc", player);
						umsg.Entity(target);
					umsg.End();
				else
					openAura.player:Notify(player, "You are not the owner of this entity!");
				end;
			else
				openAura.player:Notify(player, "This entity is not a physics entity!");
			end;
		else
			openAura.player:Notify(player, "This entity is too far away!");
		end;
	else
		openAura.player:Notify(player, "You must look at a valid entity!");
	end;
end;

openAura.command:Register(COMMAND, "ObjectPhysDesc");

COMMAND = openAura.command:New();
COMMAND.tip = "Set your radio frequency, or a stationary radio's frequency.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local radio;
	
	if (IsValid(trace.Entity) and trace.Entity:GetClass() == "aura_radio") then
		if (trace.HitPos:Distance( player:GetShootPos() ) <= 192) then
			radio = trace.Entity;
		else
			openAura.player:Notify(player, "This stationary radio is too far away!");
			
			return;
		end;
	end;
	
	local frequency = arguments[1];
	
	if ( string.find(frequency, "^%d%d%d%.%d$") ) then
		local start, finish, decimal = string.match(frequency, "(%d)%d(%d)%.(%d)");
		
		start = tonumber(start);
		finish = tonumber(finish);
		decimal = tonumber(decimal);
		
		if (start == 1 and finish > 0 and finish < 10 and decimal > 0 and decimal < 10) then
			if (radio) then
				trace.Entity:SetFrequency(frequency);
				
				openAura.player:Notify(player, "You have set this stationary radio's frequency to "..frequency..".");
			else
				player:SetCharacterData("frequency", frequency);
				
				openAura.player:Notify(player, "You have set your radio frequency to "..frequency..".");
			end;
		else
			openAura.player:Notify(player, "The radio frequency must be between 101.1 and 199.9!");
		end;
	else
		openAura.player:Notify(player, "The radio frequency must look like xxx.x!");
	end;
end;

openAura.command:Register(COMMAND, "SetFreq");

COMMAND = openAura.command:New();
COMMAND.tip = "Permanently kill a character.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.player:Get( arguments[1] );
	
	if (target) then
		if ( !target:GetCharacterData("permakilled") ) then
			openAura.schema:PermaKillPlayer( target, target:GetRagdollEntity() );
		else
			openAura.player:Notify(player, "This character is already permanently killed!");
			
			return;
		end;
		
		openAura.player:NotifyAll(player:Name().." permanently killed the character '"..target:Name().."'.");
	else
		openAura.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

openAura.command:Register(COMMAND, "CharPermaKill");

COMMAND = openAura.command:New();
COMMAND.tip = "Heal a character if you own a medical item.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:GetSharedVar("tied") == 0) then
		local itemTable = openAura.item:Get( arguments[1] );
		local entity = player:GetEyeTraceNoCursor().Entity;
		local healed;
		
		local target = openAura.entity:GetPlayer(entity);
		
		if (target) then
			if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
				if (itemTable and arguments[1] == "health_vial") then
					if ( player:HasItem("health_vial") ) then
						target:SetHealth( math.Clamp( target:Health() + openAura.schema:GetHealAmount(player, 1.5), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_vial", -1, true);
						
						healed = true;
					else
						openAura.player:Notify(player, "You do not own a health vial!");
					end;
				elseif (itemTable and arguments[1] == "health_kit") then
					if ( player:HasItem("health_kit") ) then
						target:SetHealth( math.Clamp( target:Health() + openAura.schema:GetHealAmount(player, 2), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("health_kit", -1, true);
						
						healed = true;
					else
						openAura.player:Notify(player, "You do not own a health kit!");
					end;
				elseif (itemTable and arguments[1] == "bandage") then
					if ( player:HasItem("bandage") ) then
						target:SetHealth( math.Clamp( target:Health() + openAura.schema:GetHealAmount(player), 0, target:GetMaxHealth() ) );
						target:EmitSound("items/medshot4.wav");
						
						player:UpdateInventory("bandage", -1, true);
						
						healed = true;
					else
						openAura.player:Notify(player, "You do not own a bandage!");
					end;
				else
					openAura.player:Notify(player, "This is not a valid item!");
				end;
				
				if (healed) then
					openAura.plugin:Call("PlayerHealed", target, player, itemTable);
					
					if (openAura.player:GetAction(target) == "die") then
						openAura.player:SetRagdollState(target, RAGDOLL_NONE);
					end;
					
					player:FakePickup(target);
				end;
			else
				openAura.player:Notify(player, "This character is too far away!");
			end;
		else
			openAura.player:Notify(player, "You must look at a character!");
		end;
	else
		openAura.player:Notify(player, "You don't have permission to do this right now!");
	end;
end;

openAura.command:Register(COMMAND, "CharHeal");

-- Called when the command has been run.
COMMAND = openAura.command:New();
COMMAND.tip = "Search a character if they are tied.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = openAura.entity:GetPlayer(player:GetEyeTraceNoCursor().Entity);
	
	if (target) then
		if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
			if (player:GetSharedVar("tied") == 0) then
				if (target:GetSharedVar("tied") != 0) then
					if (target:GetVelocity():Length() == 0) then
						if (!player.searching) then
							target.beingSearched = true;
							player.searching = target;
							
							openAura.player:OpenStorage( player, {
								name = openAura.player:FormatRecognisedText(player, "%s", target),
								weight = openAura.inventory:GetMaximumWeight(target),
								entity = target,
								distance = 192,
								cash = openAura.player:GetCash(target),
								inventory = openAura.player:GetInventory(target),
								OnClose = function(player, storageTable, entity)
									player.searching = nil;
									
									if ( IsValid(entity) ) then
										entity.beingSearched = nil;
									end;
								end,
								OnTake = function(player, storageTable, itemTable)
									local target = openAura.entity:GetPlayer(storageTable.entity);
									
									if (target) then
										if (target:GetCharacterData("clothes") == itemTable.index) then
											if ( !target:HasItem(itemTable.index) ) then
												target:SetCharacterData("clothes", nil);
												
												itemTable:OnChangeClothes(target, false);
											end;
										end;
									end;
								end,
								OnGive = function(player, storageTable, itemTable)
									if (player:GetCharacterData("clothes") == itemTable.index) then
										if ( !player:HasItem(itemTable.index) ) then
											player:SetCharacterData("clothes", nil);
											
											itemTable:OnChangeClothes(player, false);
										end;
									end;
								end
							} );
						else
							openAura.player:Notify(player, "You are already searching a character!");
						end;
					else
						openAura.player:Notify(player, "You cannot search a moving character!");
					end;
				else
					openAura.player:Notify(player, "This character is not tied!");
				end;
			else
				openAura.player:Notify(player, "You don't have permission to do this right now!");
			end;
		else
			openAura.player:Notify(player, "This character is too far away!");
		end;
	else
		openAura.player:Notify(player, "You must look at a character!");
	end;
end;

openAura.command:Register(COMMAND, "CharSearch");

COMMAND = openAura.command:New();
COMMAND.tip = "Use a zip tie from your inventory.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	openAura.player:RunOpenAuraCommand(player, "InvAction", "zip_tie", "use");
end;

openAura.command:Register(COMMAND, "InvZipTie");