--[[
Name: "sh_cocaine.lua".
Product: "Cider Two".
--]]

ITEM = openAura.item:New();
ITEM.base = "drug_base";
ITEM.name = "Cocaine";
ITEM.model = "models/cocn.mdl";
ITEM.attributes = {Agility = 75};
ITEM.description = "A wrapped up white powder, it's good for your agility.";

openAura.item:Register(ITEM);