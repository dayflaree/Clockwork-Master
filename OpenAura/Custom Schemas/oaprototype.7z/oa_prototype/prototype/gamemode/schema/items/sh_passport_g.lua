
ITEM = openAura.item:New();
ITEM.name = "Greenzone Passport";
ITEM.model = "models/props_lab/clipboard.mdl";
ITEM.weight = 0.05;
ITEM.useText = "Show";
ITEM.business = false;
ITEM.description = "A card that allows passage into the Greenzone.";
function ITEM:OnUse(player, itemEntity)

	local talkRadius = openAura.config:Get("talk_radius"):Get();
	local listeners = {};
	local position = player:GetShootPos();
	
			for k, v in pairs(_player.GetAll()) do
				if (v:GetShootPos():Distance(position) <= talkRadius) then
				listeners[#listeners + 1] = v;
				end
			end
		
			openAura.player:Notify(player, "You show your passport.") ;
			openAura.player:Notify(listeners, player.." shows a valid Greenzone passport.") ;

end;