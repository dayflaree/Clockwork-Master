--[[
Name: "sh_police_uniform.lua".
Product: "Cider Two".
--]]

ITEM = openAura.item:New();
ITEM.base = "clothes_base";
ITEM.cost = 200;
ITEM.name = "Black watch uniform";
ITEM.replacement = "models/Combine_Soldier.mdl";
ITEM.iconModel = "models/Combine_Soldier.mdl";
ITEM.weight = 0.5;
ITEM.protection = 0.4;
ITEM.classes = {CLASS_BLACKMARKET};
ITEM.business = true;
ITEM.description = "A stolen black watch uniform.";

openAura.item:Register(ITEM);