--[[
Name: "sh_ecstacy.lua".
Product: "Cider Two".
--]]

ITEM = openAura.item:New();
ITEM.base = "drug_base";
ITEM.name = "Ecstacy";
ITEM.model = "models/jaanus/ecstac.mdl";
ITEM.attributes = {Acrobatics = 75};
ITEM.description = "Some bottled white pills, they're good for your acrobatics.";

openAura.item:Register(ITEM);