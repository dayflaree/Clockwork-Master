--[[
Name: "sh_ammo_xbowbolt.lua".
Product: "Cider Two".
--]]

ITEM = openAura.item:New();
ITEM.base = "ammo_base";
ITEM.name = "5.7x28mm Rounds";
ITEM.cost = 75;
ITEM.model = "models/items/boxzrounds.mdl";
ITEM.weight = 1;
ITEM.classes = {CLASS_BLACKMARKET, CLASS_DISPENSER};
ITEM.uniqueID = "ammo_xbowbolt";
ITEM.business = true;
ITEM.ammoClass = "xbowbolt";
ITEM.ammoAmount = 20;
ITEM.description = "An average sized blue container with 5.7x28mm on the side.";

openAura.item:Register(ITEM);