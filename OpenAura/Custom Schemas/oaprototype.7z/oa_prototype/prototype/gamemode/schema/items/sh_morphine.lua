--[[
Name: "sh_morphine.lua".
Product: "Cider Two".
--]]

ITEM = openAura.item:New();
ITEM.base = "drug_base";
ITEM.name = "Morphine";
ITEM.model = "models/jaanus/morphi.mdl";
ITEM.attributes = {Endurance = 75};
ITEM.description = "Some bottled blue pills, they're good for your endurance.";

openAura.item:Register(ITEM);