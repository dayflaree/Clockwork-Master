
openAura.directory:AddCategoryPage( "Black watch", "Prototype",[[
<p>
"When we hunt, we kill!
No one is safe!
Nothing is sacred!
We are Blackwatch!
We are the last line of defense!
We will burn our own to hold the red line; it is the last line to ever hold!"
<i>The Blackwatch creed.</i>
</p>
<p><b>Blackwatch Special Forces</b>, officially designated under 1st Biological Warfare Command is the black ops military force, responsible for the containment of biohazard/viral outbreaks. 
They were previously deployed at Hope, Idaho to contain the viral outbreak caused by the Redlight virus, and later to New York City in order to combat the Blacklight virus. 
</p>
<p>Furthermore, they have full authority over American military forces and local police when it comes to biological warfare 
- they can request any information and any amount of military forces to serve under their command, as exemplified by their use of Marines on Manhattan Island.
Each member of the organization is single mindedly dedicated to its goal and fully believes that it justifies the means, no matter how distasteful they are. </p>
<p>
As such, Blackwatch soldiers will execute infected humans without hesitation, 
use area of effect weapons in urban areas and deploy heavy armor and gunships in crowded areas just to destroy a single Runner.
</p>
<p>They will also not hesitate to firebomb city blocks just to suppress the infection, regardless of other military and civilian presence. 
Some members have even been noted as possessing a cruel and sadistic glee while doing so. 
This approach earns them the ire of any jointly deployed military forces, who usually consider them gung-ho, bloodthirsty psychopaths, and Nazis.
</p>
]]);