
--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

for k, v in pairs( _file.Find("../models/humans/group17/*.mdl") ) do
	openAura.animation:AddMaleHumanModel("models/humans/group17/"..v);
end;

for k, v in pairs( _file.Find("../models/humans/group99/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group99/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group99/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/humans/group09/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group09/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group09/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/humans/group10/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group10/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group10/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/humans/group08/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group08/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group08/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/humans/group07/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group07/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group07/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/humans/group04/*.mdl") ) do
	if ( string.find(string.lower(v), "female") ) then
		openAura.animation:AddFemaleHumanModel("models/humans/group04/"..v);
	else
		openAura.animation:AddMaleHumanModel("models/humans/group04/"..v);
	end;
end;

for k, v in pairs( _file.Find("../models/pmc/pmc_4/*.mdl") ) do
	openAura.animation:AddMaleHumanModel("models/pmc/pmc_4/"..v);
end;

local groups = {34, 35, 36, 37, 38, 39, 40, 41};

for k, v in pairs(groups) do
	local groupName = "group"..v;
	
	for k2, v2 in pairs( _file.Find("../models/humans/"..groupName.."/*.*") ) do
		local fileName = string.lower(v2);
		
		if ( string.find(fileName, "female") ) then
			openAura.animation:AddFemaleHumanModel("models/humans/"..groupName.."/"..fileName);
		else
			openAura.animation:AddMaleHumanModel("models/humans/"..groupName.."/"..fileName);
		end;
	end;
end;



openAura.option:SetKey( "default_date", {month = 1, year = 2013, day = 1} );
openAura.option:SetKey( "default_time", {minute = 0, hour = 0, day = 1} );
openAura.option:SetKey("description_attributes", "Check on your character's stats.");
openAura.option:SetKey("description_inventory", "Manage the items in your invertory.");
openAura.option:SetKey("description_business", "Access the business menu.");
openAura.option:SetKey("model_shipment", "models/props_junk/cardboard_box003b.mdl");
openAura.option:SetKey("intro_image", "cidertwo/prototype");
--openAura.option:SetKey("menu_music", "sound/prototype_song.mp3");
openAura.option:SetKey("name_attributes", "Attributes");
openAura.option:SetKey("name_attribute", "Attribute");
openAura.option:SetKey("name_inventory", "Invertory");
openAura.option:SetKey("name_business", "Business");
openAura.option:SetKey("gradient", "cidertwo/gradient2");

openAura.config:ShareKey("intro_text_small");
openAura.config:ShareKey("intro_text_big");

openAura.player:RegisterSharedVar("permaKilled", NWTYPE_BOOL, true);
openAura.player:RegisterSharedVar("tied", NWTYPE_NUMBER);

openAura:RegisterGlobalSharedVar("noWagesTime", NWTYPE_NUMBER);
openAura:RegisterGlobalSharedVar("lottery", NWTYPE_NUMBER);
openAura:RegisterGlobalSharedVar("agenda", NWTYPE_STRING);

openAura.player:RegisterSharedVar("beingChloro", NWTYPE_BOOL, true);
openAura.player:RegisterSharedVar("skullMask", NWTYPE_BOOL);
openAura.player:RegisterSharedVar("beingTied", NWTYPE_BOOL, true);
openAura.player:RegisterSharedVar("disguise", NWTYPE_ENTITY);
openAura.player:RegisterSharedVar("clothes", NWTYPE_NUMBER, true);
openAura.player:RegisterSharedVar("lottery", NWTYPE_BOOL, true);
openAura.player:RegisterSharedVar("hunger", NWTYPE_NUMBER, true);
openAura.player:RegisterSharedVar("thirst", NWTYPE_NUMBER, true);


openAura:IncludePrefixed("sh_coms.lua");
openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("cl_hooks.lua");
openAura:IncludePrefixed("cl_theme.lua");

openAura.config:ShareKey("intro_text_small");
openAura.config:ShareKey("intro_text_big");

openAura.quiz:SetEnabled(true);
openAura.quiz:AddQuestion("Do you understand that roleplaying is slow paced and relaxed?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("Can you type properly, using capital letters and full-stops?", 2, "yes i can", "Yes, I can.");
openAura.quiz:AddQuestion("You do not need weapons to roleplay, do you understand?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("You do not need items to roleplay, do you understand?", 1, "Yes.", "No.");
openAura.quiz:AddQuestion("What do you think serious roleplaying is about?", 2, "Collecting items and upgrades.", "Developing your character.");
openAura.quiz:AddQuestion("What universe is this roleplaying game set in?", 2, "Real Life.", "Prototype.");

openAura.flag:Add("q", "Special", "Access to the special items.");
