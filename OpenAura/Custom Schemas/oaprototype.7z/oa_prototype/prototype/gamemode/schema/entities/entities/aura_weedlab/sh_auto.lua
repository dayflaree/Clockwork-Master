--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

ENT.Type = "anim";
ENT.Base = "aura_generator";
ENT.Model = "models/props_lab/reciever01a.mdl";
ENT.PrintName = "Weed Lab";