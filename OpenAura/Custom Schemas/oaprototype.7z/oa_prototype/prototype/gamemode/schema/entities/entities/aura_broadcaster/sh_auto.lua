--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "kurozael";
ENT.PrintName = "Broadcaster";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;

-- Called when the datatables are setup.
function ENT:SetupDataTables()
	self:DTVar("Bool", 0, "off");
end;

-- A function to get whether the entity is off.
function ENT:IsOff()
	return self:GetDTBool("off");
end;