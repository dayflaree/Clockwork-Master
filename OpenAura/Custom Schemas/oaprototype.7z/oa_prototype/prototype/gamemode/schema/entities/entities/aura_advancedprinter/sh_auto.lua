--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

ENT.Type = "anim";
ENT.Base = "aura_generator";
ENT.Model = "models/props_c17/cashregister01a.mdl";
ENT.PrintName = "Advanced Printer";