--[[
Name: "sh_auto.lua".
Product: "Cider Two".
--]]

ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "kurozael";
ENT.PrintName = "Belongings";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.UsableInVehicle = true;

-- Called when the entity initializes.
function ENT:SharedInitialize()
	openAura.entity:RegisterSharedVars( self, {
		{"name", NWTYPE_STRING}
	} );
end;