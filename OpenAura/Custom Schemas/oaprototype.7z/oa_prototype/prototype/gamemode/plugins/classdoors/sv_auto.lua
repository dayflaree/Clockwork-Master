--[[
	Name: sv_auto.lua.
	Author: Snazzy.
--]]

local PLUGIN = PLUGIN;
PLUGIN.classDoors = {};

openAura:IncludePrefixed("sh_auto.lua");

-- A function to get whether a player has a flashlight.
function PLUGIN:AddClassDoor(class, doorName)
	if(!self.classDoors[doorName])then
		self.classDoors[doorName] = {};
	end;
	
	table.insert(self.classDoors[doorName], class);
end;

--[[
	You can easily add a door, that can only be accessed by a certain class by doing:		
		PLUGIN:AddClassDoor(Class Enumeration, Door Name);
	As shown in the examples below
--]]
PLUGIN:AddClassDoor(CLASS_BLACK, "BLACK WATCH");
PLUGIN:AddClassDoor(CLASS_MIL, "MILITARY");
