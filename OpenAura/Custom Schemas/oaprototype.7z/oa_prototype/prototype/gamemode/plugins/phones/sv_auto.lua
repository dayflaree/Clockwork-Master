--[[
	Name: sv_auto.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");

