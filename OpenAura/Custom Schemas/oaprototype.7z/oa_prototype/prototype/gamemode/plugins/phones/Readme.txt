Allows calling other characters.
Sets a random number when the character first spawns. The numbers are attached to characters and never change.

With a really low chance there can appear equal numbers. In that case you can cry or deal with it.