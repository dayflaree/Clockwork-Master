--[[
	Name: sh_info.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Phones";
PLUGIN.author = "Euphe";
PLUGIN.description = "Allows you to call other players.";