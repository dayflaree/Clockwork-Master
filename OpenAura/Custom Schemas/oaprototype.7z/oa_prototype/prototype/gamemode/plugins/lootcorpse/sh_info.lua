--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Corpse Loot";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "Removes everything from players inventories when they die, and allows players to loot corpses.";