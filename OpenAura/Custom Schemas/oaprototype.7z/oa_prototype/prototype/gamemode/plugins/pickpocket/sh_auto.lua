--[[
	Name: sh_auto.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("sh_coms.lua");