--[[
	Name: sh_coms.lua.
	Author: Euphe.
--]]
local PLUGIN = PLUGIN;

-- A command to steal.

COMMAND = openAura.command:New();
COMMAND.tip = "Pickpocket stuff.";
COMMAND.text = "<string itemname> or <r>(for random)";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	local validItems = {  -- Add any items that can be pickpocketed here. That's done so you can customize it easier. 
	"melon",
	"handheld_radio"
	};
	
	if ( target and target:IsPlayer() ) then
		if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
		local luck = math.random(1,100)
		local dex = openAura.attributes:Fraction(player, ATB_DEXTERITY, 12, 6);
		local chance = luck + dex;
		local inventory = openAura.player:GetInventory(target);
		local itemname = arugments[1];
		
		
		-- local function for a fulyl successful theft
		local function Success(itemname)
	if (itemname == "r") then
			local random = math.random(1,100);
				if random > 50 then
					local cash = math.floor(math.random(0, 15) + (dex*0.5))
					if openAura.player:CanAfford(target, cash) then
						openAura.player:GiveCash(player, cash, "Stealing");
						openAura.player:GiveCash(target, -cash, "Unknown cases");
						player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
						openAura.player:Notify(player, "You succesfully stole "..cash.."$!");
					else
						allcash = openAura.player:GetCash(target);
						openAura.player:GiveCash(player, allcash, "Stealing");
						openAura.player:GiveCash(target, -allcash, "Unknown cases");
						player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
						openAura.player:Notify(player, "You succesfully stole "..allcash.."$!");
					end
				else
				local sitem = table.Random(inventory)
					for k, v in pairs(validItems) do
						if string.find(sitem, validItems) and random <= 50 then
							player:UpdateInventory(sitem, 1, true, true)
							target:UpdateInventory(sitem, -1, true, true)
							player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
							openAura.player:Notify(player, "You succesfully stole an item!");
						end
					end		
				end
			elseif !(itemname == "r") then
				local sitem = openAura.item:Get( itemname );
					if (sitem) then
					for k, v in pairs(validItems) do
						if string.find(sitem, validItems) then
							player:UpdateInventory(sitem, 1, true, true)
							target:UpdateInventory(sitem, -1, true, true)
							player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
							openAura.player:Notify(player, "You succesfully stole a specific item!");
						end
					end
					end
				
			end
		
	
	end	
			-- local function for a not so succesful theft
			local function Failure1(itemname)
			if (itemname == "r") then
				local random = math.random(1,100);
				if random > 50 then
					local cash = math.floor(math.random(0, 15) + (dex*0.5))
					if openAura.player:CanAfford(target, cash) then
						openAura.player:GiveCash(player, cash, "Stealing");
						openAura.player:GiveCash(target, -cash, "Unknown cases");
						player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
						openAura.player:Notify(player, "You succesfully stole "..cash.."$, but got spotted!");
						openAura.player:Notify(target, "Somebody stole something from you!");
					else
						allcash = openAura.player:GetCash(target);
						openAura.player:GiveCash(player, allcash, "Stealing");
						openAura.player:GiveCash(target, -allcash, "Unknown cases");
						player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
						openAura.player:Notify(player, "You succesfully stole "..allcash.."$, but got spotted!");
						openAura.player:Notify(target, "Somebody stole something from you!");
					end	
				else
				local sitem = table.Random(inventory)
					for k, v in pairs(validItems) do
						if string.find(sitem, validItems) and random <= 50 then
							player:UpdateInventory(sitem, 1, true, true)
							target:UpdateInventory(sitem, -1, true, true)
							player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
							openAura.player:Notify(player, "You succesfully stole an item, but got spotted!");
							openAura.player:Notify(target, "Somebody stole something from you!");
						end
					end
				end
				elseif !(itemname == "r") then
				local sitem = openAura.item:Get( itemname );
					if (sitem) then
					for k, v in pairs(validItems) do
						if string.find(sitem, validItems) then
							player:UpdateInventory(sitem, 1, true, true)
							target:UpdateInventory(sitem, -1, true, true)
							player:ProgressAttribute(ATB_DEXTERITY, 0.25, true);
							openAura.player:Notify(player, "You succesfully stole a specific item, but got spotted");
							openAura.player:Notify(target, "Somebody stole something from you!");
						end
					end	
					end
				end
			end
			if chance > 75 then
			Success(itemname);
			elseif (chance >= 50 and chance <= 75) then
			Failure1(itemname)	
				
			elseif chance < 50 then
			-- Don't think we need a local function for 2 lines.
					openAura.player:Notify(player, "You failed to steal an item and got spotted!");
					openAura.player:Notify(target, "Somebody failed at stealing something from you!");
				
			end
		
		else openAura.player:Notify(player, "The target is too far away!"); end
	else openAura.player:Notify(player, "This is not a valid target!"); end	
end
openAura.command:Register(COMMAND, "Steal");
