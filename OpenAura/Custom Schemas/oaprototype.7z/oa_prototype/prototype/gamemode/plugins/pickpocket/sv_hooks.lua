--[[
	Name: cl_auto.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

