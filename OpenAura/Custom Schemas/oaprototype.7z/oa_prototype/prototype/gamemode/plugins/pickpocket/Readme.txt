Allows stealing. Use /steal

If you want to steal a specific item use /steal <itemname>
/steal r will attempt to steal random items or cash

/steal handheld will attempt to steal a handheld radio

**Don't forget to add items that can be pickpocketed to the validItems table in sh_coms.lua**