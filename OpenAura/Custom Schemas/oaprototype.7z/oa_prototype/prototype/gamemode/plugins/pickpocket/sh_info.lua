--[[
	Name: sh_info.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Pickpocket";
PLUGIN.author = "Euphe";
PLUGIN.description = "Allows you to steal from other players.";