--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Door Commands";
PLUGIN.author = "kurozael";
PLUGIN.description = "Provides a bunch of useful commands for interacting with doors.";