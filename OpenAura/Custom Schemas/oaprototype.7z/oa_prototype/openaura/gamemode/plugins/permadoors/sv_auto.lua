--[[
	Name: sv_auto.lua.
	Author: Euphe and thejjokerr.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");

-- A function to load the door data.
function PLUGIN:LoadDoorData()
	self.doorData = {};
	
	local positions = {};
	local doorData = openAura:RestoreSchemaData( "plugins/doors/"..game.GetMap() );
	
	for k, v in ipairs( ents.GetAll() ) do
		if ( IsValid(v) ) then
			local position = v:GetPos();
			
			if (position) then
				positions[ tostring(position) ] = v;
			end;
		end;
	end

	for k, v in pairs(doorData) do
		local entity = positions[ tostring(v.position) ];
		
		if ( IsValid(entity) and !self.doorData[entity] ) then
			if ( openAura.entity:IsDoor(entity) ) then
				local data = {
					customName = v.customName,
					position = v.position,
					entity = entity,
					name = v.name,
					text = v.text,
					owner = v.owner,
					perma = v.perma
				};
				
				if  (data.perma) then
					openAura.entity:SetDoorUnownable(data.entity, true);
					openAura.entity:SetDoorName(data.entity, data.name);
				end;
				
				self.doorData[data.entity] = data;
			end;
		end;
end
end
-- A function to save the door data.
function PLUGIN:SaveDoorData()
	local doorData = {};
	
	for k, v in pairs(self.doorData) do
		local data = {
			customName = v.customName,
			position = v.position,
			name = v.name,
			owner = v.owner,
			text = v.text,
			perma = v.perma
		};
		
		doorData[#doorData + 1] = data;
	end;
	
	openAura:SaveSchemaData("plugins/doors/"..game.GetMap(), doorData);
end;