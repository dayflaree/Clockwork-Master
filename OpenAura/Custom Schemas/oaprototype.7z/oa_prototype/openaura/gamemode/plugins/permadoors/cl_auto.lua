--[[
	Name: cl_auto.lua.
	Author: Euphe and thejjokerr.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");
