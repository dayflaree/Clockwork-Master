--[[
Name: sh_coms.lua.
	Author: Euphe and thejjokerr.
--]]

local PLUGIN = PLUGIN;

COMMAND = openAura.command:New();
COMMAND.tip = "Set a permamently owned door.";
COMMAND.text = "<string owner name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local door = player:GetEyeTraceNoCursor().Entity;
	local char = openAura.player:Get(arguments[1]);
	if ( IsValid(door) and openAura.entity:IsDoor(door) ) then
		local data = {
            perma = true,
            customName = true,
            position = door:GetPos(),
            entity = door,
            owner = char:UniqueID(),
            name = char:Name(),
            text = "It is permamently owned"
        }
		openAura.entity:SetDoorUnownable(data.entity, false);
		openAura.entity:SetDoorText(data.entity, false);
		openAura.entity:SetDoorName(data.entity, data.name);
		
		PLUGIN.doorData[data.entity] = data;
		PLUGIN:SaveDoorData();
		
		openAura.player:Notify(player, "You have set a door permamently owned by ".. char:Name().."!");
		openAura.player:GiveDoor(char, door );
	else
		openAura.player:Notify(player, "This is not a valid door!");
	end;
end
openAura.command:Register(COMMAND, "DoorSetPerma");
