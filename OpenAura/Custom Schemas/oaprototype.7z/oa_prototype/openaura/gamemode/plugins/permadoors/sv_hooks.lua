--[[
Name: sv_hooks.lua.
	Author: Euphe and thejjokerr.
--]]

local PLUGIN = PLUGIN;

-- Called when OpenAura has loaded all of the entities.
function PLUGIN:OpenAuraInitPostEntity()
	self:LoadDoorData();
end;
-- Called when a character spawns.
function PLUGIN:PostPlayerSpawn(player)
	self.doorData = {};
	

	local doorData = openAura:RestoreSchemaData( "plugins/doors/"..game.GetMap() );
	for k, v in ipairs( doorData ) do
		if IsValid(v) and ( openAura.entity:IsDoor(v) ) then
			local data = {
					customName = v.customName,
					position = v.position,
					entity = entity,
					name = v.name,
					text = v.text,
					owner = v.owner,
					perma = v.perma
				};
				
				if  (data.perma) and (data.owner == player:UniqueID()) then
				 openAura.player:GiveDoor( player, v );
				end
		end
	end
end
