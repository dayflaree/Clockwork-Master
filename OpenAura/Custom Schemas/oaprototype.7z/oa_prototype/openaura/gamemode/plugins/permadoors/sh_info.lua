--[[
	Name: sh_info.lua.
	Author: Euphe and thejjokerr.
--]]
local PLUGIN = PLUGIN;

PLUGIN.name = "Permamently owned doors";
PLUGIN.author = "Euphe";
PLUGIN.description = "Allows creating permamently owned doors.";