--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

--[[
	This code is open source, free for use, and was
	written by BlackOps.
--]]

PLUGIN.name = "Animated Legs";
PLUGIN.author = "BlackOps";
PLUGIN.description = "Gives characters animated legs that they can physically see.";