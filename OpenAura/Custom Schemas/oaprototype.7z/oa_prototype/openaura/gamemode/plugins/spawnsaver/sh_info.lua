--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Spawn Saver";
PLUGIN.author = "kurozael";
PLUGIN.description = "Players spawn where they disconnected if desired in the config.";