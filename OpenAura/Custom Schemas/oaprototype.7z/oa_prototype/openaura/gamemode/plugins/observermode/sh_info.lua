--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Observer Mode";
PLUGIN.author = "kurozael";
PLUGIN.description = "Staff can enter observer mode, similiar to noclipping but they\nare teleported back to where they entered it.";