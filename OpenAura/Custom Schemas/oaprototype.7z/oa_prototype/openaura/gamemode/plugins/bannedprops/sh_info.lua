--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Banned Props";
PLUGIN.author = "kurozael";
PLUGIN.description = "A basic plugin which allows props to be banned.";