--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Weapon Select";
PLUGIN.author = "kurozael";
PLUGIN.description = "A new weapon selection interface for players.";