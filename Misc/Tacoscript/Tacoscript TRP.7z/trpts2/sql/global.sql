-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 24, 2013 at 10:49 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tacoscript2`
--

-- --------------------------------------------------------

--
-- Table structure for table `ts2_bans`
--

CREATE TABLE IF NOT EXISTS `ts2_bans` (
  `banID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `serverGroup` tinyint(3) unsigned DEFAULT NULL,
  `userSteam` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `adminSteam` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `banStart` int(11) unsigned NOT NULL DEFAULT '0',
  `banLength` int(11) unsigned NOT NULL DEFAULT '0',
  `banReason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `banLifted` int(11) unsigned NOT NULL DEFAULT '0',
  `lifterSteam` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`banID`),
  KEY `serverGroup` (`serverGroup`,`userSteam`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
