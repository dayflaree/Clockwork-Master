SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `trp_users`
-- ----------------------------
DROP TABLE IF EXISTS `trp_users`;
CREATE TABLE `trp_users` (
  `userID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `steamID` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `userName` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `userTooltrust` tinyint(1) NOT NULL DEFAULT '0',
  `dateRegistered` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userID`),
  KEY `steamID` (`steamID`)
) ENGINE=MyISAM AUTO_INCREMENT=5669 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of trp_users
-- ----------------------------
INSERT INTO `trp_users` VALUES ('1', 'STEAM_0:1:14751471', 'Horsey', '1', '0');


-- ----------------------------
-- Table structure for `trp_donations`
-- ----------------------------
DROP TABLE IF EXISTS `trp_donations`;
CREATE TABLE `trp_donations` (
  `steamID` varchar(64) COLLATE utf8_bin NOT NULL,
  `maxRagdolls` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `maxProps` smallint(6) unsigned NOT NULL DEFAULT '0',
  `customModel` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `customModelName` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `customAvatar` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `remarks` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`steamID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of trp_donations
-- ----------------------------
INSERT INTO `trp_donations` VALUES ('STEAM_0:1:14751471', '3', '70', '', ' ', '', 'Horsey');

-- ----------------------------
-- Table structure for `trp_characters`
-- ----------------------------
DROP TABLE IF EXISTS `trp_characters`;
CREATE TABLE `trp_characters` (
  `userID` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `charName` varchar(32) COLLATE utf8_bin NOT NULL,
  `charModel` varchar(75) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charDesc` varchar(300) COLLATE utf8_bin NOT NULL DEFAULT '',
  `playerFlags` varchar(52) COLLATE utf8_bin NOT NULL DEFAULT '',
  `factionFlags` varchar(52) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charAge` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `charScale` float(5,2) NOT NULL,
  `charLastOn` int(11) unsigned NOT NULL DEFAULT '0',
  `charInventories` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charItems` varchar(1024) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charPrimary` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charSecondary` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charStrength` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charSpeed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charEndurance` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charAim` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charStrengthProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charSpeedProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charEnduranceProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charAimProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charID`),
  KEY `userID` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=10211 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of trp_characters
-- ----------------------------
INSERT INTO `trp_characters` VALUES ('1', '1', 'Jake Holling', 'models/Humans/Group01/Male_04.mdl', '', '', '', '35', '1.00', '0', 'Pockets;Backpack;;;;', '', '', '', '11', '30', '30', '19', '0', '0', '0', '0');