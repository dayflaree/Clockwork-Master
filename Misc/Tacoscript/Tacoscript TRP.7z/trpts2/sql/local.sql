-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 08, 2013 at 04:45 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `terminator`
--

-- --------------------------------------------------------

--
-- Table structure for table `ts2_characters`
--

CREATE TABLE IF NOT EXISTS `ts2_characters` (
  `userID` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `charName` varchar(32) COLLATE utf8_bin NOT NULL,
  `charModel` varchar(75) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charDesc` varchar(300) COLLATE utf8_bin NOT NULL DEFAULT '',
  `playerFlags` varchar(52) COLLATE utf8_bin NOT NULL DEFAULT '',
  `factionFlags` varchar(52) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charAge` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `charScale` float(5,2) NOT NULL,
  `charLastOn` int(11) unsigned NOT NULL DEFAULT '0',
  `charInventories` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charItems` varchar(1024) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charPrimary` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charSecondary` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `charStrength` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charSpeed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charEndurance` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charAim` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charStrengthProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charSpeedProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charEnduranceProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `charAimProgress` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charID`),
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ts2_donations`
--

CREATE TABLE IF NOT EXISTS `ts2_donations` (
  `steamID` varchar(64) COLLATE utf8_bin NOT NULL,
  `maxRagdolls` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `maxProps` smallint(6) unsigned NOT NULL DEFAULT '0',
  `customModel` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `customModelName` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `customAvatar` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `remarks` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`steamID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `ts2_users`
--

CREATE TABLE IF NOT EXISTS `ts2_users` (
  `userID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `steamID` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `userName` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `userTooltrust` tinyint(1) NOT NULL DEFAULT '0',
  `dateRegistered` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userID`),
  KEY `steamID` (`steamID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;
