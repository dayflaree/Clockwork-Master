TS.MapSnapshot = {}

local Snapshot = TS.MapSnapshot

local ITEM_REGULAR = 1
local ITEM_CONTAINER = 2
local ITEM_NOTITEM = 3

function Snapshot:CreateNew(filename)
	local Entities = ents.GetAll()

	local data = {
		props = {},
		items = {}
	}

	for i = 1, #Entities do
		local ent = Entities[i]

		if (ent:GetClass() == "prop_physics" && ent.CreatorSteamID) || (ent:GetClass() == "ts2_item") then
			local item = self:PackageEntity(ent)

			if item[2] == ITEM_REGULAR || item[2] == ITEM_CONTAINER then
				data.items[#data.items + 1] = item
			elseif item[2] == ITEM_NOTITEM then
				data.props[#data.props + 1] = item
			end
		end
	end

	data = util.TableToJSON(data)

	file.Write("TS2/data/" .. filename .. ".txt", data)
end

function Snapshot:LoadSnapshot(filename)
	local data = file.Read("TS2/data/" .. filename .. ".txt")

	if not (data) then return end
	data = util.JSONToTable(data)

	for i = 1, #data.items do
		local dat = data.items[i]

		local itemData, t, pData = dat[1], dat[2], dat[3]

		if itemData.Name == "Note" then //Wow this is fucking ghetto lol.
			function itemData:Use()
				net.Start("RecieveLetter")
					net.WriteString(self.LetterContent)
				net.Send(self.Owner)
			end
		end

		local ent = TS.CreateItemProp(itemData, pData.pos, pData.ang, nil)

		-- make sure it's all good
		if not IsValid(ent) or not IsValid(ent:GetPhysicsObject()) then
			ent:Remove()
			continue
		end

		if t == ITEM_CONTAINER then

			local Container = ent.ItemData
			local Grid = Container.InventoryGrid
			for x = 0, Container.Width do
				for y = 0, Container.Height do
					if Grid[x] && Grid[x][y] && Grid[x][y].ItemData then
						local item = Grid[x][y].ItemData
						local itemData = TS.ItemsData[item.ID]

						if itemData then
							for k, v in pairs (itemData) do
								if type (v) == "function" then
									item[k] = itemData[k]
								end
							end
						end
					end
				end
			end
		end

		if ent.InventoryGrid then
			PrintTable(ent.InventoryGrid)
		end

		if IsValid(ent) then
			ent:SetMaterial(pData.mat)
			ent:SetColor(pData.col)
			ent:GetPhysicsObject():EnableMotion(false)
		end
	end

	for i = 1, #data.props do
		local dat = data.props[i]
		local propData, t, pData = dat[1], dat[2], dat[3]

		local ent = ents.Create("prop_physics")
			ent:SetPos(pData.pos)
			ent:SetAngles(pData.ang)
			ent:SetModel(pData.mdl)
			ent:SetMaterial(pData.mat)
			ent:SetColor(pData.col)
		ent:Spawn()

		-- make sure it's all good
		if not IsValid(ent) or not IsValid(ent:GetPhysicsObject()) then
			MsgC(Color(255,255,0), "bad entity, removing\n")
			ent:Remove()
			continue
		end

		-- set the prop info
		table.merge(ent:GetTable(), propData)

		ent:GetPhysicsObject():EnableMotion(false)
	end
end

Snapshot.PropSaveKeys = {
	"CreatorIsRick",
	"CreatorIsSuperAdmin",
	"CreatorHasTT",
	"CS",
	"CreatorSteamID",
	"Desc"
}

function Snapshot:PackageEntity(item)
	local data, typ

	if item:GetClass() == "ts2_item" then
		data, typ = self:SnapshotItem(item)
	else
		data, typ = {}, ITEM_NOTITEM

		for k, v in pairs(self.PropSaveKeys) do
			data[v] = item[v]
		end
	end

	local pData = {
		pos = item:GetPos(),
		ang = item:GetAngles(),
		mdl = item:GetModel(),
		mat = item:GetMaterial(),
		col = item:GetColor()
	}

	return { data, typ, pData }
end

function Snapshot:SnapshotItem(item)
	local data, typ = table.Copy(item.ItemData) or {}, ITEM_REGULAR

	for k, v in pairs (data) do
		if type(v) == "function" then
			data[k] = nil
		end
	end

	if data.InventoryGrid then
		typ = ITEM_CONTAINER
	end

	return data, typ
end

function Snapshot:Autosave()
	local map = game.GetMap()

	local mapData = self:CreateNew(map .. "_Autosave")
end

function Snapshot:Load()
	self:LoadSnapshot(game.GetMap() .. "_Autosave")
end

local function Autosave()
	Snapshot:Autosave()
end

timer.Create("Map_Autosave", 180, 0, Autosave)