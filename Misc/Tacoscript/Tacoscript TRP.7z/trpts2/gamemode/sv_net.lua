TS.LastTitleUpdate = 0

function SetClientTitle(len, client)
	if CurTime() - TS.LastTitleUpdate < 2 then return end

	local title = net.ReadString()

	if not title or not string.find(title, "%S") then
		return
	end

	-- Trim whitespace, get rid of newline chars and clip it if it's too long.
	-- AND DO IT ALL AT ONCE
	local text = string.sub(string.gsub(string.Trim(title), "[\t\n\r]", ""), 1, 300)
	client:SetPlayerTitle(text)

	net.Start("CharDesc")
		net.WriteTable({client, text})
	net.Broadcast()

	TS.LastTitleUpdate = CurTime()
end
net.Receive("STTS", SetClientTitle)

function GenerateLetter(len, client)

	local Paper, Inventory = client.SelectedPaper, client.InventoryGrid

	local inv, x, y = Paper.Inv, Paper.x, Paper.y

	if not (inv or x or y) then return end

	if not (Inventory[inv] or Inventory[inv][x] or Inventory[inv][x][y] or Inventory[inv][x][y].ItemData.ID ~= "paper") then
		return
	end

	local LetterContent = net.ReadString()

	local ITEM = {}

	ITEM.ID = "letter" .. TS.LetterCount
	ITEM.Flags = "l!"
	ITEM.UseDelay = .1
	ITEM.PickupDelay = .1

	ITEM.Name = "Note"
	ITEM.Description = string.sub(string.gsub(LetterContent, "@n", ""), 1, 30) .. "..."
	ITEM.Model = TS.ItemsData["paper"].Model
	ITEM.CamPos = TS.ItemsData["paper"].CamPos
	ITEM.LookAt = TS.ItemsData["paper"].LookAt
	ITEM.FOV = TS.ItemsData["paper"].FOV
	ITEM.Width = 1
	ITEM.Height = 1
	ITEM.LetterContent = LetterContent

	ITEM.Pickup = function(self) end

	ITEM.Drop = function(self) end

	ITEM.Use = function(self)
		net.Start("RecieveLetter")
			net.WriteString(self.LetterContent)
		net.Send(self.Owner)
	end

	TS.ItemsData[ITEM.ID] = ITEM

	client:DropItemProp("letter" .. TS.LetterCount)
	client:TakeItemAt(inv, x, y)

	TS.LetterCount = TS.LetterCount + 1

end
net.Receive("LetterToServer", GenerateLetter)
