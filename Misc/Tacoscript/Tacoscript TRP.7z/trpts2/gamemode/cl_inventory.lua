
if InventoryMenu then

	InventoryMenu.PrimarySlot:Remove()
	InventoryMenu.SecondarySlot:Remove()
	InventoryMenu:RemoveTitleBar()
	InventoryMenu:Remove()
	InventoryMenu = nil

end

ActiveInventory = 1
ChosenItem = { id = "", x = -1, y = -1 }
HoverItem = { id  = "", x = -1, y = -1 }
DragSlot = 0

GRIDWIDTH = 50
GRIDHEIGHT = 50

function ResetItemData()

	ChosenItem.id = ""
	ChosenItem.x = -1
	ChosenItem.y = -1

	if InventoryMenu.DescriptionPanel.Icon then

		InventoryMenu.DescriptionPanel.Icon:Remove()
		InventoryMenu.DescriptionPanel.Icon = nil

	end

	InventoryMenu.DescriptionPanel.PaintHook = nil

end

local cellx = 0
local celly = 0

IsDragging = false
local candrop = false

function CreateInventoryMenu()

	local menx = ScrW() / 2 - (470 / 2)
	local meny = ScrH() / 2 - (670 / 2)

	InventoryMenu = CreateBPanel("Inventory", menx, meny, 470, 670)

	InventoryMenu.Paint = function()

		local w, h = InventoryMenu:GetWide(), InventoryMenu:GetTall()

		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 160))

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w , h)


	end

	InventoryMenu.OnCursorEntered = function()

		if ChosenItem.id ~= "" then

			ResetItemData()
			RemoveItemButtons()

		end

	end

	InventoryMenu.PrimarySlot = CreateBPanel(nil, 10, 540, 285, 100)
	InventoryMenu.PrimarySlot:SetParent(InventoryMenu)

	menx, meny = InventoryMenu.PrimarySlot:GetPos()

	InventoryMenu.PrimarySlot.Model = vgui.Create("DModelPanel", InventoryMenu.PrimarySlot)
	InventoryMenu.PrimarySlot.Model:SetSize(285, 100)
	InventoryMenu.PrimarySlot.Model:SetPos(0, 0)
	InventoryMenu.PrimarySlot.Model.LayoutEntity = function(self) end
	InventoryMenu.PrimarySlot.Model:MoveToFront()

	/* For our drag and drop operation. */
 	InventoryMenu.PrimarySlot.Model.OnMousePressed = function()

		if input.IsMouseDown(MOUSE_LEFT) && not IsDragging && ClientVars["PrimaryWeapon"] ~= "" then

			IsDragging = true
			CreateSlotWeaponDragging(ClientVars["PrimaryWeapon"], 1)
			return

		end

 	end

 	function InventoryMenu.PrimarySlot:Paint()

		local w, h = self:GetWide(), self:GetTall()

		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 90))

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w , h)

	end

 	InventoryMenu.SecondarySlot = CreateBPanel(nil, 320, 540, 143, 100)
	InventoryMenu.SecondarySlot:SetParent(InventoryMenu)

 	menx, meny = InventoryMenu.SecondarySlot:GetPos()

	InventoryMenu.SecondarySlot.Model = vgui.Create("DModelPanel", InventoryMenu.SecondarySlot)
	InventoryMenu.SecondarySlot.Model:SetSize(140, 100)
	InventoryMenu.SecondarySlot.Model:SetPos(0, 0)
	InventoryMenu.SecondarySlot.Model.LayoutEntity = function(self) end
	InventoryMenu.SecondarySlot.Model:MoveToFront()

	/* For our drag and Drop operation. */
 	InventoryMenu.SecondarySlot.Model.OnMousePressed = function()

		if input.IsMouseDown(MOUSE_LEFT) && not IsDragging && ClientVars["SecondaryWeapon"] ~= "" then

			IsDragging = true
			CreateSlotWeaponDragging(ClientVars["SecondaryWeapon"], 2)
			return

		end


 	end

	function InventoryMenu.SecondarySlot:Paint()

		local w, h = self:GetWide(), self:GetTall()

		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 90))

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w , h)

	end

	InventoryMenu:CanClose(false)

	InventoryMenu.Think = function()

		if InventoryMenu.StorageButton then

			if not StorageMenu or not StorageMenu:IsVisible() then

				InventoryMenu.StorageButton:Remove()
				InventoryMenu.StorageButton = nil

			end

		end

	end

	InventoryMenu:SetBodyColor(Color(20, 20, 20, 100))

	InventoryMenu.InventoryPanel = CreateBPanel(nil, 10, 0, 450, 55)
	InventoryMenu.InventoryPanel:SetParent(InventoryMenu)
	InventoryMenu.InventoryPanel:SetBodyColor(Color(30, 30, 30, 0))
	InventoryMenu.InventoryPanel:EnableScrolling(true)

	InventoryMenu.DescriptionPanel = CreateBPanel(nil, 10, 80, 450, 128)
	InventoryMenu.DescriptionPanel:SetParent(InventoryMenu)
	InventoryMenu.DescriptionPanel:SetBodyColor(Color(0, 0, 0, 0))

	InventoryMenu.ContentPanel = CreateBPanel(nil, 10, 235, 453, 303)
	InventoryMenu.ContentPanel:SetParent(InventoryMenu)
	InventoryMenu.ContentPanel:SetBodyColor(Color(30, 30, 30, 170))
	InventoryMenu.ContentPanel.Paint = function()

		local w, h = InventoryMenu.ContentPanel:GetWide(), InventoryMenu.ContentPanel:GetTall()

		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 0))

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w , h)

		local row = InventoryList[ActiveInventory].Height - 1
		local col = InventoryList[ActiveInventory].Width - 1

		local black = false
		local newblack = true
		local coloroverride = nil

		local mx, my = gui.MousePos()

		local xxx, yyy = InventoryMenu:GetPos()
		local iw, ih = InventoryMenu:GetSize()
		local xx, yy = InventoryMenu.ContentPanel:GetPos()

		xx = xx + xxx
		yy = yyy + yy

		for y = 0, row do

			for x = 0, col do

				if (MouseXIn((xx + x * GRIDWIDTH), (xx + x * GRIDWIDTH) + GRIDWIDTH) &&
					 MouseYIn((yy + y * GRIDHEIGHT), (yy + y * GRIDHEIGHT) + GRIDHEIGHT)) then

					--PrintTable(InventoryIconGrid[ActiveInventory][x][y])

					if not (InventoryGrid[ActiveInventory][x][y].Filled) then

						cellx = x
						celly = y

						coloroverride = Color(58, 95, 205, 80)

					else

						cellx = x
						celly = y

						coloroverride = nil

					end

				else

					coloroverride = nil

					if not (MouseXIn (xxx, xxx + iw) && MouseYIn (yyy, yyy + ih)) then

						cellx = -1
						celly = -1

					end

				end

				if black then

					DrawFilledOutlinedSquare(x * GRIDWIDTH, y * GRIDHEIGHT, GRIDWIDTH, GRIDHEIGHT, coloroverride or Color(0, 0, 0, 200), Color(0, 0, 0, 255))

				else

					DrawFilledOutlinedSquare(x * GRIDWIDTH, y * GRIDHEIGHT, GRIDWIDTH, GRIDHEIGHT, coloroverride or Color(30, 30, 30, 0), Color(0, 0, 0, 255))

				end

				black = !black

			end

			black = newblack
			newblack = !newblack

		end

		local ww, hh = InventoryMenu.ContentPanel:GetWide(), InventoryMenu.ContentPanel:GetTall()




		if InventoryGrid[ActiveInventory][cellx] && InventoryGrid[ActiveInventory][cellx][celly] && InventoryGrid[ActiveInventory][cellx][celly].Filled then

			if MouseXIn(xx, xx + (GRIDWIDTH * (col + 1))) && MouseYIn(yy, yy + (GRIDHEIGHT * (row + 1))) then

				local data = InventoryGrid[ActiveInventory][cellx][celly]
				draw.RoundedBox(0, data.X * GRIDWIDTH + 2, data.Y * GRIDHEIGHT + 2, data.W * GRIDWIDTH - 1, data.H * GRIDHEIGHT - 1, Color(0, 200, 0, 40))

				--[[
				//Mouse positons.
				local mx = gui.MouseX()
				local my = gui.MouseY()

				mx = mx - xxx
				my = my - yyy

				draw.RoundedBox(0, mx, my, 100, 50, Color(0 , 0, 0, 100))
				]]--

			end

		end

	end

	InventoryMenu.ContentPanel.OnMousePressed = function()

		if ChosenItem.id ~= "" then

			ResetItemData()
			RemoveItemButtons()

		end

	end

	InventoryMenu.ContentPanel.OnCursorEntered = function()

		if ChosenItem.id ~= "" then

			ResetItemData()
			RemoveItemButtons()

		end

	end

	InventoryMenu.ContentPanel.PaintHook = function()


	end

end

function event.ResetInventory()

	CreateInventoryMenu()
	InventoryMenu:SetVisible(false)
	InventoryMenu.TitleBar:SetVisible(false)
	InventoryMenu.PrimarySlot:SetVisible(false)
	InventoryMenu.PrimarySlot.Model:SetVisible(false)

	InventoryMenu.SecondarySlot:SetVisible(false)
	InventoryMenu.SecondarySlot.Model:SetVisible(false)

	ActiveInventory = 1

	InventoryList = { }
	InventoryIconGrid = { }
	InventoryGrid = { }
	PrimarySlot = {}
	SecondarySlot = {}

	IsDragging = false

	for n = 1, TS.MaxInventories do

		InventoryList[n] = { }
		InventoryList[n].Name = ""
		InventoryList[n].Width = 9
		InventoryList[n].Height = 6

		InventoryIconGrid[n] = { }
		InventoryGrid[n] = { }

		for x = 0, 8 do

			InventoryIconGrid[n][x] = { }
			InventoryGrid[n][x] = { }

			for y = 0, 5 do

				InventoryIconGrid[n][x][y] = { }
				InventoryGrid[n][x][y] = { }
				InventoryGrid[n][x][y].Filled = false

			end

		end

	end

end

event.ResetInventory()

function RemoveItemButtons()

	if InventoryMenu.UseButton then
		InventoryMenu.UseButton:Remove()
		InventoryMenu.UseButton = nil
	end

	if InventoryMenu.TuneButton then
		InventoryMenu.TuneButton:Remove()
		InventoryMenu.TuneButton = nil
	end

	if InventoryMenu.DropButton then
		InventoryMenu.DropButton:Remove()
		InventoryMenu.DropButton = nil
	end

	if InventoryMenu.StorageButton then
		InventoryMenu.StorageButton:Remove()
		InventoryMenu.StorageButton = nil
	end

	if InventoryMenu.LookInsideButton then
		InventoryMenu.LookInsideButton:Remove()
		InventoryMenu.LookInsideButton = nil
	end

end

function SetAllInventoryIconsVisibility(id, bool)

	for y = 0, InventoryList[id].Height - 1 do

		for x = 0, InventoryList[id].Width - 1 do

			if InventoryIconGrid[id][x][y] and InventoryIconGrid[id][x][y].IsValid and InventoryIconGrid[id][x][y]:IsValid() then
				InventoryIconGrid[id][x][y]:SetVisible(bool)
			end

		end

	end

end

local VestOnID = ""
local VestOn = false
local LastAction = 0

function ToggleVest()

	if VestOnID == "" then return end

	VestOn = false

	if InventoryMenu.TakeOffInventoryButton then
		InventoryMenu.TakeOffInventoryButton:Remove()
	end

	MakePutOn(VestOnID)
	VestOnID = ""

end
usermessage.Hook("TV", ToggleVest)

function MakePutOn(id)

	InventoryMenu.PutOnInventoryButton = InventoryMenu:AddButton("Wear", 105, 77, function()

		if CurTime() - LastAction < 2.3 then return end

		LastAction = CurTime()

		RunConsoleCommand("eng_putonstorage", InventoryList[id].Name)

		if InventoryMenu.PutOnInventoryButton then
			InventoryMenu.PutOnInventoryButton:Remove()
		end

		MakeTakeOff(id)
		VestOn = true
		VestOnID = id

	end)

end

function MakeTakeOff(id)

	InventoryMenu.TakeOffInventoryButton = InventoryMenu:AddButton("Take off", 105, 77, function()

		if CurTime() - LastAction < 2.3 then return end

		LastAction = CurTime()

		RunConsoleCommand("eng_takeoffstorage", InventoryList[id].Name)

		if InventoryMenu.TakeOffInventoryButton then
			InventoryMenu.TakeOffInventoryButton:Remove()
		end

		MakePutOn(id)
		VestOn = false
		VestOnID = ""

	end)

end

function SetActiveInventory(id)

	if id == ActiveInventory then return end

	if InventoryMenu.RemoveInventoryButton then
		InventoryMenu.RemoveInventoryButton:Remove()
		InventoryMenu.RemoveInventoryButton = nil
	end

	if InventoryMenu.PutOnInventoryButton then
		InventoryMenu.PutOnInventoryButton:Remove()
		InventoryMenu.PutOnInventoryButton = nil
	end

	if InventoryMenu.TakeOffInventoryButton then
		InventoryMenu.TakeOffInventoryButton:Remove()
		InventoryMenu.TakeOffInventoryButton = nil
	end

	SetAllInventoryIconsVisibility(ActiveInventory, false)
	SetAllInventoryIconsVisibility(id, true)

	ActiveInventory = id

	if InventoryMenu.DescriptionPanel.Icon then
		InventoryMenu.DescriptionPanel.Icon:Remove()
		InventoryMenu.DescriptionPanel.Icon = nil
	end

	InventoryMenu.DescriptionPanel.PaintHook = nil

	RemoveItemButtons()

	if not InventoryList[id].Permanent then

		InventoryMenu.RemoveInventoryButton = InventoryMenu:AddButton("Drop storage", 10, 77, function()

			RunConsoleCommand("eng_invdropstorage", InventoryList[id].Name)

			if 	StorageActiveInventory == ActiveInventory and StorageMenu and StorageMenu:IsValid() then

				StorageMenu:Remove()

			end

		end)

		--You cannot wear or take off backpacks
		if 	InventoryList[id].Name ~= "Backpack" || InventoryList[id].Name ~= "Ammo Pouch" then

			if VestOn then

				MakeTakeOff(id)

			else

				MakePutOn(id)

			end

		end

	end

	ChosenItem.id = ""
	ChosenItem.x = -1
	ChosenItem.y = -1

	for k, v in pairs(InventoryMenu.InventoryPanel.ScrollingObjects) do

		if v.IsLink then

			if InventoryMenu.InventoryPanel.ScrollingObjects[k].Text == InventoryList[id].Name then
				InventoryMenu.InventoryPanel.ScrollingObjects[k].NormalColor = Color(0, 75, 200, 200)
			else
				InventoryMenu.InventoryPanel.ScrollingObjects[k].NormalColor = Color(255, 255, 255, 255)
			end

		end

	end

end

function RefreshInventoryList()

	for k, v in pairs(InventoryMenu.InventoryPanel.ScrollingObjects) do

		if v.IsLink then
			InventoryMenu.InventoryPanel.ScrollingObjects[k]:Remove()
			InventoryMenu.InventoryPanel.ScrollingObjects[k] = nil
		end

	end

	local count = 0

	for n = 1, TS.MaxInventories do

		if InventoryList[n].Name ~= "" then

			local link = InventoryMenu.InventoryPanel:AddLink(InventoryList[n].Name, "NewChatFont", 5, 5 + 16 * count, Color(0, 75, 200, 200), function() SetActiveInventory(n); end)

			if n == ActiveInventory then

				link.NormalColor = Color(0, 75, 200, 200)

			end

			count = count + 1

		end

	end

end

function GetTotalAmmoCount(id)

	local amount = 0

	if not InventoryIconGrid then return end

	for i, v in pairs(InventoryIconGrid) do

		for x, c in pairs(v) do

			for y, u in pairs(c) do

				if InventoryIconGrid[i][x][y].mData then

					if InventoryIconGrid[i][x][y].mData.AmmoType == id && string.find(InventoryIconGrid[i][x][y].mData.Flags, "a") then

						local amt = InventoryGrid[i][x][y].Amount

						amount = amount + amt

					end

				end

			end

		end

	end

	return amount

end

local function DropCurrentItem()

	if (StorageItemID == ChosenItem.id and
		StorageActiveInventory == ActiveInventory and
		StorageItemX == ChosenItem.x and
		StorageItemY == ChosenItem.y and StorageMenu and StorageMenu:IsValid()) then

		StorageMenu:Remove()

	end

	RemoveItemButtons()

	RunConsoleCommand("eng_invdropitem", ChosenItem.id, ActiveInventory, ChosenItem.x, ChosenItem.y)

end


function ShowItemButtons(item)

	RemoveItemButtons()

	local item = table.Copy(TS.ItemsData[item])
	local SelectedItem = table.Copy(ChosenItem) --Snapshot lol
	local amt = InventoryGrid[ActiveInventory][SelectedItem.x][SelectedItem.y].Amount

	local UseItem = function()

		RemoveItemButtons()
		RunConsoleCommand("eng_invuseitem", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y)

	end

	local UseItemPortion = function()

		RunConsoleCommand("eng_invuseitemportion", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y)

	end

	local AddStorage = function()

		RemoveItemButtons()
		RunConsoleCommand("eng_invaddstorage", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y)

	end

	local TuneRadio = function()

		PromptRadioMenu()

	end

	local xoffset = 10

	local MenuButtonOptions = DermaMenu()

	local AddButton = function(cmd, func)

		--[[
		local button = InventoryMenu:AddButton(cmd, xoffset, 230, func)
		xoffset = button:GetSize() + xoffset + 5

		return button
		]]--

		MenuButtonOptions:AddOption(cmd, func)

		return nil

	end

	if string.find(item.Flags, "t") then
		InventoryMenu.TuneButton = AddButton("Tune in", TuneRadio)
	end

	if string.find(item.Flags, "e") then
		InventoryMenu.UseButton = AddButton("Eat", UseItem)
	end

	if string.find(item.Flags, "d") then
		if string.find(item.Flags, "@") then
			InventoryMenu.UseButton = AddButton("Drink some", UseItemPortion)
		else
			InventoryMenu.UseButton = AddButton("Drink", UseItem)
		end
	end

	if string.find(item.Flags, "u") then
		InventoryMenu.UseButton = AddButton("Use", UseItem)
	end

	if string.find(item.Flags, "p") then
		InventoryMenu.UseButton = AddButton("Write", function() RemoveItemButtons(); RunConsoleCommand("eng_invwriteitem", ActiveInventory, SelectedItem.x, SelectedItem.y); end)
	end

	if string.find(item.Flags, "l") then
		InventoryMenu.UseButton = AddButton("Read", function() RunConsoleCommand("eng_invuseitem", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y, 1); end)
	end

	if string.find(item.Flags, "W") then
		InventoryMenu.UseButton = AddButton("Read", function() RunConsoleCommand("eng_invuseitem", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y, 1); end)
	end

	InventoryMenu.DropButton = AddButton("Drop", DropCurrentItem)

	if string.find(item.Flags, "w") then

		if (amt > 0) && not (string.find(item.Flags, "P")) then

			AddButton("Unload", function() RunConsoleCommand("eng_unloadweapon", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y, amt) end)

		end

		if TS.ItemsData[item.AmmoType] then

			if not (string.find(TS.ItemsData[item.AmmoType].Flags, "P")) then

				if (amt ~= TS.ItemsData[SelectedItem.id].Maximum && amt >= 0)  then

					AddButton("Load Ammo", function() RunConsoleCommand("eng_loadweapon", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y, amt) end)

				end

			else

				if (amt == 0)  then

					AddButton("Load Plasma Cell", function() RunConsoleCommand("eng_loadweapon", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y, amt) end)

				end

			end

		end

	else

		if (amt > 1) && not (string.find(item.Flags, "P")) then
			AddButton("Split", function()
				StackSplitMenu({ ActiveInventory, SelectedItem.x, SelectedItem.y })
			end)
		end

	end

	if not string.find(item.Flags, "c") and StorageMenu and StorageMenu:IsVisible() and StorageMenu.CanPutInto then
		InventoryMenu.StorageButton = AddButton("Put into storage", AddStorage)
	end

	if string.find(item.Flags, "C") or string.find(item.Flags, "W") then

		InventoryMenu.LookInsideButton = AddButton("Look inside", function()

			StorageItemID = SelectedItem.id
			StorageActiveInventory = ActiveInventory
			StorageItemX = SelectedItem.x
			StorageItemY = SelectedItem.y

			RunConsoleCommand("eng_invlookinsidecontainer", SelectedItem.id, ActiveInventory, SelectedItem.x, SelectedItem.y)

			if InventoryMenu.StorageButton and InventoryMenu.StorageButton:IsValid() then
				InventoryMenu.StorageButton:Remove()
			end

		end)

	end

	MenuButtonOptions:Open()

end

function ShowItemDescription(item)

	if InventoryMenu.DescriptionPanel.Icon then
		InventoryMenu.DescriptionPanel.Icon:Remove()
		InventoryMenu.DescriptionPanel.Icon = nil
	end

	local data = TS.ItemsData[item]

	InventoryMenu.DescriptionPanel.Icon = vgui.Create("DModelPanel", InventoryMenu.DescriptionPanel)
	InventoryMenu.DescriptionPanel.Icon:SetModel(data.Model)
	if data.Material then
		InventoryMenu.DescriptionPanel.Icon.Entity:SetMaterial(data.Material)
	end
	InventoryMenu.DescriptionPanel.Icon:SetPos(2, 2)
	InventoryMenu.DescriptionPanel.Icon:SetSize(math.Clamp(data.Width * GRIDWIDTH * 2, 0, InventoryMenu.DescriptionPanel:GetWide()), math.Clamp(data.Height * GRIDHEIGHT * 2, 0, InventoryMenu.DescriptionPanel:GetTall()))
	InventoryMenu.DescriptionPanel.Icon:SetCamPos(data.CamPos)
	InventoryMenu.DescriptionPanel.Icon:SetLookAt(data.LookAt)
	InventoryMenu.DescriptionPanel.Icon:SetFOV(data.FOV)
	InventoryMenu.DescriptionPanel.Text = FormatLine(data.Desc, "NewChatFont", InventoryMenu.DescriptionPanel:GetWide() - math.Clamp(data.Width * GRIDWIDTH * 2, 0, InventoryMenu.DescriptionPanel:GetWide()))

	InventoryMenu.DescriptionPanel.PaintHook = function()

		draw.DrawText(data.Name, "NewChatFont", InventoryMenu.DescriptionPanel:GetWide() - 5, 2, Color(255, 255, 255, 255), 2)
		draw.DrawText(InventoryMenu.DescriptionPanel.Text, "NewChatFont", InventoryMenu.DescriptionPanel:GetWide() - 2, 18, Color(255, 255, 255, 255), 2)

	end

	InventoryMenu.DescriptionPanel.Icon.LayoutEntity = function(self)

	end

end

/* Function CreateItemDragging

	Arguments: item

	"item" is a string containing the name of the item.

*/

function ReturnProperDragLocation(x, y, w, h)

	local dx = x
	local dy = y

	/* Can we fit the item at this location? */
	if not (CanFitAt(ActiveInventory, cellx, celly, w, h)) then

		/* Start from the right, for the sake of a snug fit */
		for nx = w - 1, 0, -1 do

			for ny = h - 1, 0, -1 do

				/* After the decrements, is this position appropriate? */
				if CanFitAt(ActiveInventory, cellx - nx, celly - ny, w, h) then

					/* It is, so let's use these! */
					dx = cellx - nx
					dy = celly - ny

				end

			end

		end

	end

	return dx, dy

end

function CreateItemDragging(item)

	local data = TS.ItemsData[item]

	local mx, my = gui.MousePos()

	dragicon = vgui.Create("DModelPanel", InventoryMenu.ContentPanel)
	dragicon:SetModel(data.Model)
	if data.Material then
		dragicon.Entity:SetMaterial(data.Material)
	end
	dragicon:SetPos(mx, my)
	dragicon:SetSize(data.Width * GRIDWIDTH, data.Height * GRIDHEIGHT)
	dragicon:SetCamPos(data.CamPos)
	dragicon:SetLookAt(data.LookAt)
	dragicon:SetFOV(data.FOV)
	dragicon:SetAmbientLight(Color(255, 255, 255, 255))
	dragicon:MakePopup()
	dragicon.ItemClass = item

	dragicon.Dragging = true

	dragicon.LayoutEntity = function(self)

	end

	dragicon.OnMousePressed = function()

 		if input.IsMouseDown(MOUSE_LEFT) then

			IsDragging = false

		end

 	end

	local x, y = InventoryMenu:GetPos()
	local ww, hh = InventoryMenu:GetWide(), InventoryMenu:GetTall()

	dragicon.Think = function()

		if dragicon then

			local mx, my = gui.MousePos()

			dragicon:SetPos(mx - (dragicon:GetWide() * 0.5), my - (dragicon:GetTall() * 0.5))

			if not IsDragging then

				/* Divide our icon width by the grid size to get our sizes. */
				local w, h = dragicon:GetSize()

				w = w / GRIDWIDTH
				h = h / GRIDHEIGHT

				local dx = cellx
				local dy = celly

				if w > 1 && h > 1 then
					dx, dy = ReturnProperDragLocation(dx, dy, w, h)
				end

				local wpsx, wpsy = InventoryMenu.PrimarySlot:GetPos()
				local wssx, wssy = InventoryMenu.SecondarySlot:GetPos()

				//This is dumb.
				wpsx, wpsy, wssx, wssy = wpsx + x, wpsy + y, wssx + x, wssy + y

				hh = hh - 105

				if MouseXIn(x, x + ww) && MouseYIn(y, y + hh) then

					RunConsoleCommand("eng_dragdropitem", HoverItem.id, ActiveInventory, HoverItem.x, HoverItem.y, dx, dy)

				elseif MouseXIn(wpsx, wpsx + 205) && MouseYIn(wpsy, wpsy + 100) then

					RunConsoleCommand("eng_rseo", HoverItem.id, ActiveInventory, HoverItem.x, HoverItem.y)

				elseif MouseXIn(wssx, wssx + 205) && MouseYIn(wssy, wssy + 100) then

					RunConsoleCommand("eng_rseo", HoverItem.id, ActiveInventory, HoverItem.x, HoverItem.y)

				end

				/* Do some cleanup. */
				ResetItemData()
				RemoveItemButtons()


				dragicon.Dragging = false

				dragicon:Remove()
				dragicon = nil

			end

		end

	end

end

//ToDo: Fix this ugly shit.
function CreateSlotWeaponDragging(item, slot)

	local data = TS.ItemsData[item]

	if data then

		local mx, my = gui.MousePos()

		dragicon = vgui.Create("DModelPanel", InventoryMenu.ContentPanel)
		dragicon:SetModel(data.Model)
		dragicon:SetPos(mx, my)
		dragicon:SetSize(data.Width * GRIDWIDTH, data.Height * GRIDHEIGHT)
		dragicon:SetCamPos(data.CamPos)
		dragicon:SetLookAt(data.LookAt)
		dragicon:SetFOV(data.FOV)
		dragicon:SetAmbientLight(Color(255, 255, 255, 255))
		dragicon:MakePopup()
		dragicon.Slot = slot
		dragicon.ItemClass = item

		dragicon.Dragging = true

		dragicon.LayoutEntity = function(self)

		end

		dragicon.OnMousePressed = function()

			if input.IsMouseDown(MOUSE_LEFT) then

				IsDragging = false

			end

		end

		dragicon.Think = function()

			if dragicon then

				local mx, my = gui.MousePos()

				dragicon:SetPos(mx - (dragicon:GetWide() * 0.5), my - (dragicon:GetTall() * 0.5))

				if not IsDragging then

					/* Divide our icon width by the grid size to get our sizes. */
					local w, h = dragicon:GetSize()

					w = w / GRIDWIDTH
					h = h / GRIDHEIGHT

					local dx = cellx
					local dy = celly

					if cellx ~= -1 && celly ~= -1 then

						dx, dy = ReturnProperDragLocation(dx, dy, w, h)

						RunConsoleCommand("eng_ddps", dragicon.ItemClass, ActiveInventory, dx, dy, dragicon.Slot)
						/* Call DragDrop operation. Checks to see if it can fit on the server inventory grid, and if so, changes it. */

					else


					end

					/* Do some cleanup. */
					ResetItemData()
					RemoveItemButtons()


					dragicon.Dragging = false

					dragicon:Remove()
					dragicon = nil

				end

			end

		end

	end

end

/* Function AddToInventory

	Arguments: id, item, x, y

	"id" is an integer for the current inventory.
	"item" is a string containing the name of the item.
	"x, y" are the grid position in the inventory

*/
function AddToInventory(id, item, x, y)

	local data = TS.ItemsData[item]

	local icon = vgui.Create("DModelPanel", InventoryMenu.ContentPanel)
	icon:SetModel(data.Model)

	if data.Material then
		icon.Entity:SetMaterial(data.Material)
	end

	icon:SetPos((x * GRIDWIDTH) + 3, (y * GRIDHEIGHT) + 3)
	icon:SetSize((data.Width * GRIDWIDTH)  - 3, (data.Height * GRIDHEIGHT) - 3)
	icon:SetCamPos(data.CamPos)
	icon:SetLookAt(data.LookAt)
	icon:SetFOV(data.FOV)
	icon.IsDragging = false
	icon.mData = data

	local oPaint = icon.Paint

	icon.Paint = function()
		oPaint(icon)

		if InventoryGrid[id][x][y].Amount > 1 then

			local w, h = icon:GetSize()
			/* Draws the amount that item has next to it. */
			draw.DrawText(InventoryGrid[id][x][y].Amount, "NewChatFont", w - 6, h - 20, Color(255, 255, 255, 220), 2)

		end

	end

	icon.LayoutEntity = function(self) end

	icon.OnCursorEntered = function()

		ChosenItem = { id = item, x = x, y = y }
		ShowItemDescription(item)

	end

	/* For our drag and drop operation. */
 	icon.OnMousePressed = function()

 		ChosenItem = { id = item, x = x, y = y }

 		if input.IsMouseDown(MOUSE_RIGHT) then

 			ShowItemButtons(item)

 		else

			if input.IsMouseDown(MOUSE_LEFT) && not IsDragging then

				IsDragging = true
				HoverItem = { id = item, x = x, y = y }
				CreateItemDragging(item)
				return

			end

		end

 	end

 	InventoryIconGrid[id][x][y] = icon

	if ActiveInventory == id then
		InventoryIconGrid[id][x][y]:SetVisible(true)
	else
		InventoryIconGrid[id][x][y]:SetVisible(false)
	end

 	InventoryIconGrid[id][x][y] = icon

	if ActiveInventory == id then
		InventoryIconGrid[id][x][y]:SetVisible(true)
	else
		InventoryIconGrid[id][x][y]:SetVisible(false)
	end

end

/* Function CanFitAt

	Arguments: id, x, y, w, h

	"id" is an integer for the current inventory.
	"x, y" are the grid position in the inventory
	"w, h" is the width and height of the simulated item.

	Basically, this function takes the dimensions and tests them.

*/
function CanFitAt(id, x, y, w, h)

	for k = 0, h - 1 do

		for j = 0, w - 1 do

			/* Is this position and width within the inventory bounds? */
			if (x + j >= InventoryList[id].Width or
				y + k >= InventoryList[id].Height) then

				return false

			end

			/* Is this even a valid operation? Do our x and y values check out? */
			if not InventoryGrid[id][x + j] or not InventoryGrid[id][x + j][y + k] then

				return false

			end

			/* Is this position already holding an item? */
			if InventoryGrid[id][x + j][y + k].Filled then

				return false

			end

		end

	end

	return true

end

function FindFreeSpace(id, w, h)

	for y = 0, InventoryList[id].Height - 1 do

		for x = 0, InventoryList[id].Width - 1 do

			if InventoryGrid[id][x] and InventoryGrid[id][x][y] and (not InventoryGrid[id][x][y].Filled and CanFitAt(id, x, y, w, h)) then

				return x, y

			end

		end

	end

	return false

end

/* Function InsertIntoInventory

	Arguments: id, x, y, w, h, amount

	"id" identifies our current item (string).
	"x, y" are the grid position in the inventory
	"w, h" is the width and height of the received item.
	"amount" is the amount of the item (for stacking)

	In simple, the item is received from the server and inserted into our
	inventory for clientside prediction.

*/
function InsertIntoInventory(id, x, y, w, h, amount)

	for j = 0, w - 1 do

		for k = 0, h - 1 do

			InventoryGrid[id][x + j][y + k].Filled = true
			InventoryGrid[id][x + j][y + k].X = x
			InventoryGrid[id][x + j][y + k].Y = y
			InventoryGrid[id][x + j][y + k].W = w
			InventoryGrid[id][x + j][y + k].H = h


		end

	end

	InventoryGrid[id][x][y].Amount = amount or 0

end

local function ReceiveNewItem(msg)

	local inv = msg:ReadShort()
	local id = msg:ReadString()
	local amt = msg:ReadShort()
	local x = msg:ReadShort()
	local y = msg:ReadShort()

	if not TS.ItemsData[id] then return end

	local w = TS.ItemsData[id].Width
	local h = TS.ItemsData[id].Height

	if x and y then

		InsertIntoInventory(inv, x, y, w, h, amt)

		AddToInventory(inv, id, x, y)

	end

end
usermessage.Hook("RNI", ReceiveNewItem)

local function ReceiveNewSavedItem(msg)

	local inv = msg:ReadShort()
	local id = msg:ReadString()
	local x = msg:ReadShort()
	local y = msg:ReadShort()
	local amt = msg:ReadShort()

	if not TS.ItemsData[id] then return end

	local w = TS.ItemsData[id].Width
	local h = TS.ItemsData[id].Height

	InsertIntoInventory(inv, x, y, w, h, amt)

	AddToInventory(inv, id, x, y)

end
usermessage.Hook("RNSI", ReceiveNewSavedItem)

function OnUpdatePlayerPrimaryWeapon(oldval, newval)

	if not TS.ItemsData[newval] or newval == "" then
		InventoryMenu.PrimarySlot.Model:SetModel("")
		return

	end

	PrimarySlot = TS.ItemsData[newval]
	InventoryMenu.PrimarySlot.Model:SetModel(PrimarySlot.Model)
	InventoryMenu.PrimarySlot.Model:SetCamPos(PrimarySlot.CamPos)
	InventoryMenu.PrimarySlot.Model:SetLookAt(PrimarySlot.LookAt)
	InventoryMenu.PrimarySlot.Model:SetFOV(PrimarySlot.FOV + 5.5)

end

function OnUpdatePlayerSecondaryWeapon(oldval, newval)

	if not TS.ItemsData[newval] or newval == "" then
		InventoryMenu.SecondarySlot.Model:SetModel("")
		return

	end

	SecondarySlot = TS.ItemsData[newval]
	InventoryMenu.SecondarySlot.Model:SetModel(SecondarySlot.Model)
	InventoryMenu.SecondarySlot.Model:SetCamPos(SecondarySlot.CamPos)
	InventoryMenu.SecondarySlot.Model:SetLookAt(SecondarySlot.LookAt)
	InventoryMenu.SecondarySlot.Model:SetFOV(SecondarySlot.FOV + 12)

end

local function UpdateItemAmount(msg)

	local inv = msg:ReadShort()
	local x = msg:ReadShort()
	local y = msg:ReadShort()
	local amt = msg:ReadShort()

	InventoryGrid[inv][x][y].Amount = amt

end
usermessage.Hook("UIA", UpdateItemAmount)

local function RemoveItemInventory(msg)

	local iid = msg:ReadShort()
	local x = msg:ReadShort()
	local y = msg:ReadShort()

	for k, v in pairs(InventoryGrid[iid]) do

		for n, m in pairs(v) do

			if m.X == x and m.Y == y then

				InventoryGrid[iid][k][n].Filled = false
				InventoryGrid[iid][k][n].X = -1
				InventoryGrid[iid][k][n].Y = -1

			end

		end

	end

	if InventoryIconGrid[iid][x][y] and InventoryIconGrid[iid][x][y].Remove then
		InventoryIconGrid[iid][x][y]:Remove()
		InventoryIconGrid[iid][x][y] = nil
	end

	if (ChosenItem.x == x and
		ChosenItem.y == y and
		ActiveInventory == iid) then

		RemoveItemButtons()
		ChosenItem.id = ""
		ChosenItem.x = -1
		ChosenItem.y = -1

		if InventoryMenu.DescriptionPanel.Icon then
			InventoryMenu.DescriptionPanel.Icon:Remove()
			InventoryMenu.DescriptionPanel.Icon = nil
		end

		InventoryMenu.DescriptionPanel.PaintHook = nil

	end


end
usermessage.Hook("RII", RemoveItemInventory)

local FirstInventory = false

local function RemoveInventory(msg)

	local name = msg:ReadString()

	for n = 1, TS.MaxInventories do

		if InventoryList[n].Name == name then

			InventoryList[n].Name = ""

			for k, v in pairs(InventoryGrid[n]) do

				for i, m in pairs(v) do

					InventoryGrid[n][k][i].Filled = false
					InventoryGrid[n][k][i].X = -1
					InventoryGrid[n][k][i].Y = -1

					if InventoryIconGrid[n][k][i] and InventoryIconGrid[n][k][i].Remove then
						InventoryIconGrid[n][k][i]:Remove()
						InventoryIconGrid[n][k][i] = nil
					end

				end

			end

			if n == ActiveInventory then
				SetActiveInventory(1)
			end

			RefreshInventoryList()

		end

	end

end
usermessage.Hook("RINV", RemoveInventory)

local function AddNewInventory(msg)

	local name = msg:ReadString()
	local w = msg:ReadShort()
	local h = msg:ReadShort()
	local p = msg:ReadBool()

	for n = 1, TS.MaxInventories do

		if InventoryList[n].Name == "" then

			InventoryList[n].Name = name
			InventoryList[n].Width = w
			InventoryList[n].Height = h
			InventoryList[n].Permanent = p

			RefreshInventoryList()

			if not FirstInventory then --Do this to set the initial inventory color to blue (usually Pockets)

				FirstInventory = true

				if n == ActiveInventory then
					SetActiveInventory(n)
				end

			end

			return

		end

	end


end
usermessage.Hook("ANI", AddNewInventory)

function StackSplitMenu(args)

	if SplitMenu then

		if SplitMenu.Entry then
			SplitMenu.Entry:Remove()
		end

		if SplitMenu.TitleBar then
			SplitMenu.TitleBar:Remove()
		end

		SplitMenu:Remove()

	end

	SplitMenu = CreateBPanel("How Much?", 350, 300, 140, 50)
	SplitMenu:SetBodyColor(Color(30, 30, 30, 170))
	SplitMenu:CanClose(true)
	SplitMenu:CanDrag(false)
	SplitMenu:MakePopup()

	local x, y = SplitMenu:GetPos()

	SplitMenu.Entry = vgui.Create("DTextEntry", SplitMenu)
	SplitMenu.Entry:SetSize(80, 20)
	SplitMenu.Entry:SetPos(x + 10, y + 10)
	SplitMenu.Entry:SetEditable(true)
	SplitMenu.Entry:MakePopup()

	SplitMenu.Entry.OnEnter = function()

		if not tonumber(SplitMenu.Entry:GetValue()) then
			return
		end

		if (tonumber(SplitMenu.Entry:GetValue()) < 0 or
			tonumber(SplitMenu.Entry:GetValue()) > 50000) then

			CreateOkPanel("Really?", "What the hell are you trying to split?")
			return

		end

		if args && args[1] && args[2] && args[3] then
			RunConsoleCommand("eng_splititem", SplitMenu.Entry:GetValue(), args[1], args[2], args[3])
		end

		if SplitMenu then

			if SplitMenu.Entry then
				SplitMenu.Entry:Remove()
			end

			if SplitMenu.TitleBar then
				SplitMenu.TitleBar:Remove()
			end

			SplitMenu:Remove()

		end

	end

	function SplitMenu:OnClose()

		if SplitMenu.Entry then
			SplitMenu.Entry:Remove()
		end

		if SplitMenu.TitleBar then
			SplitMenu.TitleBar:Remove()
		end

	end

end