function FillRGBA(x, y, w, h, col)

    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawRect(x, y, w, h)

end

function OutlineRGBA(x, y, w, h, col)

    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawOutlinedRect(x, y, w, h)

end

function DrawFilledOutlinedSquare(x, y, w, h, col1, col2)

	FillRGBA(x + 2, y + 2, w - 1, h - 1, col1)
	OutlineRGBA(x + 2, y + 2, w - 1, h - 1, col2)

end

function MouseXIn(min, max)

	if (gui.MouseX() > min) && (gui.MouseX() < max) then
		return true
	end

	return false

end

function MouseYIn(min, max)

	if (gui.MouseY() > min) && (gui.MouseY() < max) then
		return true
	end

	return false

end

function MouseInPoints(xmin, xmax, ymin, ymax)
	return (MouseXIn(xmin, xmax) && MouseYIn(ymin, ymax))
end

-- Write to a file, making sure that the directories exist and the file path contains
-- no invalid characters. Basically, the file is gonna get created no matter what.
function file.WriteSafe(filename, contents)
	-- No Unicode filenames on Waterworld, apparently.
	filename = file.GetSafeFilename(filename)

	-- Make sure the directory exists.
	local dir = string.GetPathFromFilename(filename)
	if not file.Exists(dir, "DATA") then
		file.CreateDir(dir)
	end

	-- Open, write, close.
	local logfile = file.Open(filename, "w", "DATA")
	assert(logfile, 'Couldn\'t open file for writing: "' .. filename .. '"')
	logfile:Write(contents)
	logfile:Close()
end
