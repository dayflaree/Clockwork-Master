--[[
	sh_includes.lua
	Manage auto-included modules and extensions
]]

function resource.GetFileRealm(filename)
	local pre = string.sub(filename, 1, 3)
	local sh = pre == "sh_"
	local cl = pre == "cl_"
	local sv = pre == "sv_" or (not sh and not cl)
	return cl or sh, sv or sh
end

function resource.IncludeFolder(path)
	local files, folders = file.Find(path and (path .. "/*") or "*", "LUA")

	-- Make sure we include files as we find them
	for k, filename in pairs(files) do
		local cl, sv = resource.GetFileRealm(filename)
		if SERVER then
			if cl then
				AddCSLuaFile(path .. "/" .. filename)
			end
			if sv then
				include(path .. "/" .. filename)
			end
		elseif CLIENT and cl then
			include(path .. "/" .. filename)
		end
	end

	-- Call ourselves on all the folders
	for k, folder in pairs(folders) do
		resource.IncludeFolder(path .. "/" .. folder)
	end
end

-- Start the chain here
resource.IncludeFolder((GM and GM.FolderName or GAMEMODE.FolderName) .. "/gamemode/includes")
