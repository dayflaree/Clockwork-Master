local meta = FindMetaTable("Player")

--We have stat tables, so instead of calculating new strength or speed in real time,
--we have a pre-calculated table.  Saves some CPU cycles.
TS.WalkSpeedTable = { }
TS.RunSpeedTable = { }
TS.DuckSpeedTable = { }
TS.SprintDegradeTable = { }
TS.SprintFillTable = { }
TS.JumpDegradeTable = { }

for n = 0, 100 do

	if n <= 5 then

		TS.WalkSpeedTable[n] = 85
		TS.RunSpeedTable[n] = 180
		TS.DuckSpeedTable[n] = 180

		TS.JumpDegradeTable[n] = 30
		TS.SprintDegradeTable[n] = 9
		TS.SprintFillTable[n] = 3

	elseif n <= 15 then

		TS.WalkSpeedTable[n] = 90
		TS.RunSpeedTable[n] = 195
		TS.DuckSpeedTable[n] = 180

		TS.JumpDegradeTable[n] = 20
		TS.SprintDegradeTable[n] = 11
		TS.SprintFillTable[n] = 4

	elseif n <= 25 then

		TS.WalkSpeedTable[n] = 96
		TS.RunSpeedTable[n] = 210
		TS.DuckSpeedTable[n] = 180

		TS.JumpDegradeTable[n] = 15
		TS.SprintDegradeTable[n] = 8
		TS.SprintFillTable[n] = 5

	elseif n <= 35 then

		TS.WalkSpeedTable[n] = 100
		TS.RunSpeedTable[n] = 240
		TS.DuckSpeedTable[n] = 190

		TS.JumpDegradeTable[n] = 8
		TS.SprintDegradeTable[n] = 6
		TS.SprintFillTable[n] = 5

	elseif n <= 45 then

		TS.WalkSpeedTable[n] = 105
		TS.RunSpeedTable[n] = 260
		TS.DuckSpeedTable[n] = 190

		TS.JumpDegradeTable[n] = 6
		TS.SprintDegradeTable[n] = 4
		TS.SprintFillTable[n] = 6

	elseif n <= 55 then

		TS.WalkSpeedTable[n] = 115
		TS.RunSpeedTable[n] = 280
		TS.DuckSpeedTable[n] = 190

		TS.JumpDegradeTable[n] = 5
		TS.SprintDegradeTable[n] = 3
		TS.SprintFillTable[n] = 6

	elseif n <= 65 then

		TS.WalkSpeedTable[n] = 117
		TS.RunSpeedTable[n] = 305
		TS.DuckSpeedTable[n] = 195

		TS.JumpDegradeTable[n] = 4
		TS.SprintDegradeTable[n] = 2
		TS.SprintFillTable[n] = 7

	else

		TS.WalkSpeedTable[n] = 120
		TS.RunSpeedTable[n] = 320
		TS.DuckSpeedTable[n] = 195

		TS.JumpDegradeTable[n] = 4
		TS.SprintDegradeTable[n] = 2
		TS.SprintFillTable[n] = 8

	end

end

--Brings up character menu
function meta:PromptCharacterMenu()

	umsg.Start("PCM", self)
	umsg.End()

	local result = TS.SQL:Query("SELECT charName, charModel FROM {CHARACTERS} WHERE userID = ?", self.UID)
	local data = {}

	-- FIXME
	for k, row in pairs(result) do
		data[row["charName"]] = row["charModel"]
	end

	net.Start("SMC")
		net.WriteTable(data)
	net.Send(self)

	self.CharacterMenu = true

end

function meta:RemoveCharacterMenu()

	umsg.Start("RCM", self)
	umsg.End()

end

--Prompt MOTD
function meta:PromptMOTD()

	umsg.Start("MOTD", self)
	umsg.End()

	self.HasSeenMOTD = true

end

function meta:CallEvent(name)
	umsg.Start("_" .. name, self)
	umsg.End()
end

--Will set player's movement speeds based off the player stats/situation
function meta:ComputePlayerSpeeds()

	local spd = self:GetPlayerSpeed()
	local mul = 1

	local max = 9999

	if self.SlowDownForHit then

		mul = .50
		max = 60

	end

	if self.StatusIsInjured then

		max = 82

	end

	self:SetWalkSpeed(math.Clamp(TS.WalkSpeedTable[spd] * mul, 0, max))
	self:SetCrouchedWalkSpeed(math.Clamp(TS.DuckSpeedTable[spd] * mul, 0, max))

	if not self.StatusIsInjured then

		if self:GetPlayerSprint() <= 0 then
			self:SetRunSpeed(math.Clamp(TS.RunSpeedTable[spd] * .5 * mul, TS.WalkSpeedTable[spd], 9999))
		else
			self:SetRunSpeed(math.Clamp(TS.RunSpeedTable[spd] * mul, 0, max))
		end

	else

		self:SetWalkSpeed(math.Clamp(TS.WalkSpeedTable[spd] * mul, 0, max))
		self:SetRunSpeed(math.Clamp(TS.RunSpeedTable[spd] * mul, 0, max))

	end


end

function meta:ResetBodyDamage()

	self.HelmetHealth = 0
	self.BodyArmorHealth = 0
	self:SetPlayerMaxArmor(0)
	self.StatusIsInjured = false
	self.StatusIsCrippled = false

	self:SetPlayerCanSprint(true)

end

function meta:ResetBleeding()

	self:SetPlayerBleeding(false)
	self.IsBleeding = false
	self.LastBleedDecal = 0
	self.LastBleedDmg = 0
	self.BleedingDmgPerSec = 0
	self.BleedingIncDmgPerSec = 0
	self.BleedingHealthCatcher = 0

end

function meta:GetBasicTrace()
	local trace = { }
		trace.start = self:EyePos()
		trace.endpos = trace.start + self:GetAimVector() * 180
		trace.filter = self

	return util.TraceLine(trace)
end

function GetUMSGTableSize(tab)

	local size = 0

	for	k, v in pairs (tab) do

		if type(v) == "string" then
			size = size + #v
		elseif type(v) == "Vector" then
			size = size + 12
		elseif type(v) == "number" then
			size = size + 2 //lets assume short for now.
		end

	end

	return size

end

function meta:SendItemData( id )
	if self.ItemsDownloaded[id] then return end

	local t_data = TS.ItemsData[id]
	if not ( id || t_data ) then return end

	TS.ItemNetworking:SendItem( self, t_data, "RID" )

	self.ItemsDownloaded[id] = true
end


function meta:GiveHealth(amt)

	self:SetHealth(math.Clamp(self:Health() + amt, 0, self.MaxHealth))

end

function meta:TakeHealth(amt)

	self:SetHealth(math.Clamp(self:Health() - amt, 0, self.MaxHealth))

	if self:Health() <= 0 then

		self:Die()

	end

end

function meta:Die()

	TS.PrintMessageAll(2, self:GetRPName() .. " died")
	self.ForceDeath = true
	self.BypassUnconscious = true
	self:Kill()

end

function meta:IsRick()
	return TS.Config.RickList[self:SteamID()]
end

function meta:IsSuperAdmin()
	return self:IsRick() or self:IsUserGroup("superadmin")
end

function meta:IsAdmin()
	return self:IsRick() or self:IsSuperAdmin() or self:IsUserGroup("admin")
end

function meta:SnapOutOfStance()

	self:SetPlayerFreezeHead(false)
	self.InStanceAction = false
	self.StanceLean = false
	self.StanceGroundSit = false
	self.StanceSit = false
	self.StanceATW = false
	self.ForcedAnimationMode = false
	self.StanceSnapToPlayerPos = nil

	umsg.Start("SOOS", self:EntIndex())
		umsg.Entity(self)
	umsg.End()

end

function meta:RemoveHandPickUp()

	self.HandPickUpSent:Remove()
	self.HandPickUpSent = nil

end

function meta:HandPickUp(ent, bone)

	if self.HandPickUpSent and self.HandPickUpSent:IsValid() then
		self:RemoveHandPickUp()
	end

	self.HandPickUpSent = ents.Create("ts2_pickup")
	self.HandPickUpSent:SetPos(ent:GetPos())
	self.HandPickUpSent:SetModel("models/props_junk/popcan01a.mdl")
	self.HandPickUpSent:SetPlayer(self)
	self.HandPickUpSent:SetTarget(ent)
	self.HandPickUpSent:Spawn()
	self.HandPickUpTarget = ent
	constraint.Weld(self.HandPickUpSent, ent, 0, bone, 9999)

end

function meta:Observe(bool)

	self.ObserveMode = bool
	self:SetNoDraw(bool)

	if self:GetActiveWeapon() and self:GetActiveWeapon():IsValid() then
		self:GetActiveWeapon():SetNoDraw(bool)
	end

	self:SetNotSolid(bool)

	if bool then
		self:SetMoveType(8)
		self:GodEnable()
	else
		self:SetMoveType(2)
		self:GodDisable()
	end

end

function meta:HandleTeamSpawn()

	self:SetModel("")
	self:SetMaterial("")
	self:SetColor(Color(255, 255, 255, 255))
	self:SetBloodColor(BLOOD_COLOR_RED)

	self:MakeNormal()
	self:SetJumpPower(200)

	if self:Team() == 1 then

		self:SetModel(self.CitizenModel or "")

		if self:HasInventory("Storage") then self:RemoveInventory("Storage"); end
		if not self:HasInventory("Pockets") then self:WearItem("clothes_citizen"); end

		if self.PlayerScale ~= "1.0" and self.PlayerScale ~= "1" then
			self:ScalePlayer(self.PlayerScale)
		end

		--Child flag
		if self:HasPlayerFlag("S") then self:MakeShort(); end

		--Tall flag
		if self:HasPlayerFlag("T") then self:MakeTall(); end

		self:SetBloodColor(BLOOD_COLOR_RED)

	elseif self:IsCP() then

		self:TakeAllInventoryWeapons()

		local CannotWear = { "Pockets", "Rebel vest", "Rebel medic vest", "Backpack" }

		for k, v in pairs(CannotWear) do

			if self:HasInventory(v) then

				self:RemoveInventory(v)

			end

		end

		if not self:HasInventory("Storage") then

			self:WearItem("clothes_storage")

		end

		self:SetPlayerStrength(100)
		self:SetPlayerSpeed(30)
		self:SetPlayerEndurance(100)
		self:SetPlayerAim(100)
		self:SetBloodColor(BLOOD_COLOR_MECH)
	end

	local delay = 0

	for k, v in pairs(TS.Flags) do

		if self:HasTerminatorFlag(v.ID) then

			if not (v.Model == "") then

				self:SetModel(v.Model)

			end

			self:SetMaterial(v.Material)
			self:SetColor(v.Color)
			self:ScalePlayer(v.Scale)
			self.BodyArmorHealth = v.Armor
			self.Footsteps = v.Footsteps
			self.CanEvent = v.Event
			self.MaxArmor = v.Armor
			self.DR = v.DR
			self.IgnoreAmmo = v.IgnoreAmmo
			self.NoRecoil = v.NoRecoil

			self:SetPlayerMaxArmor(v.Armor)

			self:SetBloodColor(BLOOD_COLOR_MECH)
 			if v.IsSkynet then

				for n, m in pairs(v.Loadout) do

					if (not (self:HasItem(m) || self:GetPlayerPrimaryWeapon() == m ||
							 self:GetPlayerSecondaryWeapon() == m) ) then

						timer.Simple(delay, function() self:GiveInventoryItem("Storage", m) end)
						delay = delay + .5

					end

				end

			end

			if v.OnSpawn then

				v.OnSpawn(self)

			end

		end

	end

	self:SetPlayerCurrentArmor(self.BodyArmorHealth)

	local map = game.GetMap()
	local str = string.lower(team.GetName(self:Team()))

	if not (TS.SpawnLocations[map] == nil) then

		local tab = TS.SpawnLocations[map][str]

		for k, v in pairs(tab) do

			local blocking = ents.FindInBox(v.pos + Vector(-16, -16, 0), v.pos + Vector(16, 16, 64))

			if #blocking == 0 then

				self:SetPos(v.pos)
				self:SetEyeAngles(v.ang)
				break

			end

		end

	end

	/* ------------------------------------- */

end

function meta:OpenStorageMenu(ent)

	if type(ent) == "table" then

		local itemdata = { }

		for k, v in pairs(ent) do
			itemdata[k] = v
		end

		ent = { }
		ent.tbl = { }
		ent.tbl.ItemData = itemdata

		ent.GetTable = function(self)
			return self.tbl
		end

	end

	if not ent.ItemData.RecPlayers then

		ent.ItemData.RecPlayers = { }

	end

	if not table.HasValue(ent.ItemData.RecPlayers, self) then

		table.insert(ent.ItemData.RecPlayers, self)

	end

	self.StorageEntity = ent

	local w = ent.ItemData.Width
	local h = ent.ItemData.Height

	if ent.ItemData.InvWidth and ent.ItemData.InvHeight then

		w = ent.ItemData.InvWidth
		h = ent.ItemData.InvHeight

	end

	--Create the storage menu
	umsg.Start("CSM", self)
		umsg.String(ent.ItemData.Name)
		umsg.Short(w)
		umsg.Short(h)
		umsg.String(ent.ItemData.Flags or "")
	umsg.End()

	local delay = .5

	--Send all of the item data for each item in the storage
	for x, v in pairs(ent.ItemData.InventoryGrid) do

		for y, k in pairs(v) do

			if k.ItemData then

				local id = k.ItemData.ID

				if not self.ItemsDownloaded[id] then
						self:SendItemData(id)
					end

				local give = function()

					if (ent.ItemData.InventoryGrid[x][y].ItemData and
						ent.ItemData.InventoryGrid[x][y].ItemData.ID == id) then

							umsg.Start("ISI", self)
								umsg.String(id)
								umsg.Short(x)
								umsg.Short(y)
								umsg.Short(ent.ItemData.InventoryGrid[x][y].Amount)
							umsg.End()

					end

				end

				timer.Simple(delay, give)

				delay = delay + .2

			end

		end

	end

end

function meta:DropCurrentWeapon()

	local weap = self:GetActiveWeapon()

	if weap and weap:IsValid() then

		local class = weap:GetClass()

		if (string.find(class, "ts2_") and
			class ~= "ts2_hands" and
			class ~= "ts2_kanyewest") then

			self:DropItemProp(class)
			self:StripWeapon(class)

		end

		if class == self.TempWeaponClass then
			self.HasTempWeapon = false
		end

	end

end

function meta:DropTempWeapon()

	if self.HasTempWeapon then

		if self:HasWeapon(self.TempWeaponClass) then

			local weap = self:GetActiveWeapon()

			if weap and weap:IsValid() then

				self:DropItemProp(self.TempWeaponClass)

			end

			self:StripWeapon(self.TempWeaponClass)
			self.HasTempWeapon = false

		end

	end

end

function meta:GiveTempWeapon(class)

	if self:HasWeapon(class) then
		return
	end

	self:DropTempWeapon()

	self.HasTempWeapon = true
	self.TempWeaponClass = class
	self:Give(class)
	self:SelectWeapon(class)

end

function meta:HandleWeaponChangeTo(class)

	if self:GetActiveWeapon():IsValid() and self.ObserveMode then
		self:GetActiveWeapon():SetNoDraw(true)
	end

	if (class ~= "weapon_physgun" and
		class ~= "weapon_physcannon" and
		class ~= "gmod_tool") then

		self:SetPlayerHolstered(true)

		umsg.Start("HPOS", self); umsg.End()

		self:CrosshairDisable()

	else

		self:DrawViewModel(true)
		self:SetPlayerHolstered(false)
		self:CrosshairEnable()

	end

	self.LastWeapon = class

end

function meta:OpenPlayerMenu(hitpos, ent, tr)

	CreateActionMenu("Action Menu", self, hitpos - Vector(0, 0, 10))

	SetActionMenuEntity(ent)

	local Hit = tr.HitNormal
	local Distance =  hitpos:Distance(self:GetPos())

	if ent:IsPlayer() then
		AddActionOption("Give Weapon", "rp_giveweap")
	elseif not (ent:IsPlayer() && not ent:IsNPC()) then
		if Distance > 60 && Distance < 90 then
			if (math.abs(Hit.x) == 1) || (math.abs(Hit.y) == 1) then
				AddActionOption("Mount Weapon", "rp_placeweapon")
			else
				AddActionOption("Place Weapon", "rp_placeweapon")
			end
		else
			AddActionOption("Drop Weapon", "rp_dropweapon")
		end
	end

	if not self:GetActiveWeapon().IsPrimary == nil then
		AddActionOption("Drop Weapon", "rp_dropweapon")
	end

	EndActionMenu()

end

function meta:ClearWeapon(weapon)

	local Weapons = {
		self:GetPlayerPrimaryWeapon(),
		self:GetPlayerSecondaryWeapon()
	}

	local Ident = {
		"Primary",
		"Secondary"
	}

	for i = 1, 2 do

		if Weapons[i] == weapon then
			self["SetPlayer" .. Ident[i] .. "Weapon"](self, "")
		end

	end

	self:StripWeapon(weapon)

end

function meta:OpenPropMenu(hitpos, prop)

	CreateActionMenu("Action Menu", self, hitpos - Vector(0, 0, 10))

	SetActionMenuEntity(prop)

		if prop.Creator == self then
			AddActionOption("Set description", "rp_promptpropdesc")
		end

	EndActionMenu()

end

function meta:ScaleDamageFromAttack(attacker, weapon, hitgroup, dmginfo)

	armor = self.BodyArmorHealth
	dmg = dmginfo:GetDamage()

	-- Terminators

	--[[
	if armor > 0 and (not self:IsCitizen() or self:HasTerminatorFlag("E")) then

		armor = armor - (dmg/2)
		self.BodyArmorHealth = armor

		return false

	end


	if armor > 0 then

		armor = armor - (dmg/2)
		self.BodyArmorHealth = armor

		return false

	end
	]]--

	if attacker:IsPlayer() then




		if hitgroup == HITGROUP_HEAD then

			dmg = dmg * 2

		elseif hitgroup == HITGROUP_CHEST then

			dmg = dmg * 1

		elseif hitgroup == HITGROUP_RIGHTLEG or hitgroup == HITGROUP_LEFTLEG then

			dmg = dmg * 0.05

			if self:Team() ~= 2 then

				self.SlowDownForHit = true
				self:ComputePlayerSpeeds()

				timer.Create("SlowDownHit" .. self:UserID() .. self:UserID(), 3, 0, function()

					if self and self:IsValid() then

						self.SlowDownForHit = false
						self:ComputePlayerSpeeds()

					end

				end)

			end

		else

			dmg = dmg * 0.6

		end

	end

	if self:GetPlayerConscious() then

		if self:IsCitizen() and math.random(1, 4) == 3 then

			local num = math.random(1, 9)

			if not string.find(string.lower(self:GetModel()), "female") then
				self:EmitSound(Sound("vo/npc/male01/pain0" .. num .. ".wav"))
			else
				self:EmitSound(Sound("vo/npc/female01/pain0" .. num .. ".wav"))
			end

		end

	end

	if CurTime() - self.LastEnduranceProgress > .5 then

		local exp = (dmg / 2) * (1 - (self:GetPlayerEndurance() / 100))

		self:RaiseEnduranceProgress(exp)

		self.LastEnduranceProgress = CurTime()

	end

	dmginfo:SetDamage(dmg)

	if armor > 0 then
	return false
	else
	return dmginfo
	end

end

function meta:BleedOutADecal()

	local trace = { }
	trace.start = self:EyePos()
	trace.endpos = trace.start - Vector(0, 0, 80)

	local front = false
	local back = false
	local mid = false

	if math.random(1, 3) == 2 then
		back = true
	elseif math.random(3, 6) == 4 then
		mid = true
	else
		front = true
	end

	if front then
		trace.endpos = trace.endpos + self:GetForward() * 30
	elseif back then
		trace.endpos = trace.endpos + self:GetForward() * -30
	end

	local left = false
	local right = false
	local center = false

	if mid then
		if math.random(1, 3) == 2 then
			left = true
		else
			right = true
		end
	else
		if math.random(1, 3) == 2 then
			left = true
		elseif math.random(4, 7) == 5 then
			right = true
		else
			center = true
		end
	end

	if left then
		trace.endpos = trace.endpos + self:GetRight() * -30
	elseif right then
		trace.endpos = trace.endpos + self:GetRight() * 30
	end

	trace.filter = self

	local tr = util.TraceLine(trace)

	local pos = tr.HitPos
	local norm = tr.HitNormal

	util.Decal("Blood", pos + norm, pos - norm)

end

function meta:DropClothes()

	local itemdata = TS.ItemsData[self.CurrentClothes]

	if itemdata.InvCanDrop == false then
		return
	end

	if itemdata.ID == "backpack" then

		if self.BackEntity and self.BackEntity:IsValid() then
			self.BackEntity:Remove()
		end

	end

	local item = self:DropItemProp(self.CurrentClothes)
	local invname = itemdata.InvName

	item:ConvertToStorage()

	item.ItemData.HelmetHealth = self.HelmetHealth
	item.ItemData.BodyArmorHealth = self.BodyArmorHealth

	if itemdata.InvStayWithClothes then
		item.ItemData:CopyFromPlayerInventory(self, invname)
		self:RemoveInventory(invname)
	end

end

function meta:WearItem(item)

	local invgrid = nil

	if type(item) == "string" then


		if not TS.ItemsData[item] then
			return
		end

		self.CurrentClothes = item

		item = TS.ItemsData[item]

	else


		invgrid = item.InventoryGrid
		self.CurrentClothes = item.ID

	end

	if item.InvName then

		if not self:HasInventory(item.InvName) then

			local b = false

			if item.InvStayWithClothes == nil then
				b = true
			else
				b = item.InvStayWithClothes
			end

			print (item.CanRevertToCitizensCloth)

			self:AddInventory(item.InvName, item.InvWidth, item.InvHeight, !b, item.CanRevertToCitizensCloth or false, true)

			if invgrid then

				self:CopyFromInventoryTable(item.InvName, invgrid)

			end

		end

	end

end

local BonesToSet = {

	"ValveBiped.Bip01_Pelvis",
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Spine1",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_UpperArm",
	"ValveBiped.Bip01_R_ForeArm",
	"ValveBiped.Bip01_L_UpperArm",
	"ValveBiped.Bip01_L_ForeArm",
	"ValveBiped.Bip01_R_Thigh",
	"ValveBiped.Bip01_R_Calf",
	"ValveBiped.Bip01_L_Thigh",
	"ValveBiped.Bip01_L_Calf",

}

function meta:RagdollPlayer()

	if self.IsRagdolled then
		return
	end

	local ragdoll = ents.Create("prop_ragdoll")

	ragdoll:SetPos(self:GetPos())
	ragdoll:SetAngles(self:GetAngles())
	ragdoll:SetModel(self.RealModelEnt:GetModel())
	ragdoll:SetOwner(self)

	ragdoll:Spawn()

	local c = ragdoll:GetPhysicsObjectCount()

	local vel = self:GetVelocity()

	for n = 1, c do

		local bone = ragdoll:GetPhysicsObjectNum(n)

		if bone and bone:IsValid() then

			local bonepos, boneang = self:GetBonePosition(ragdoll:TranslatePhysBoneToBone(n))

			if bonepos then
				bone:SetPos(bonepos)
			end
			if boneang then
				bone:SetAngles(boneang)
			end

		end

	end

	self:SnapOutOfStance()

	self:MakeInvisible()

	self:Freeze(true)

	self.IsRagdolled = true
	self.RagdollEntity = ragdoll
	ragdoll.IsPlayerRagdoll = true
	ragdoll.Player = self

	umsg.Start("SPM")
		umsg.Entity(self)
		umsg.Entity(ragdoll)
	umsg.End()

	table.insert(TS.PlayerRagdolls, ragdoll)

	return ragdoll

end

function meta:UnragdollPlayer()

	self.IsRagdolled = false

	self:MakeNotInvisible()
	self:Freeze(false)
	self:CrosshairDisable()

	local spawnpos

	if self.RagdollEntity and self.RagdollEntity:IsValid() then

		if self:Health() > 0 then
			spawnpos = self.RagdollEntity:GetPos()
			self:RemoveRagdoll()
		end

	end

	if self:Health() > 0 then

		self:Spawn()

		if spawnpos then

			self:SetPos(spawnpos)

		end

	end

end

function meta:RemoveRagdoll()

	if self.RagdollEntity and self.RagdollEntity:IsValid() then

		self.RagdollEntity:Remove()
		self.RagdollEntity = nil

	end

end

function meta:MakeInvisible(b)

	if b == nil then
		b = true
	end

	self:SetNotSolid(b)
	self:SetNoDraw(b)
	self:DrawViewModel(!b)

	if self:GetActiveWeapon():IsValid() then
		self:GetActiveWeapon():SetNoDraw(b)
	end

end

function meta:MakeNotInvisible()

	self:MakeInvisible(false)

end

function meta:DropAndRemoveCurrentWeapon()

	local weap = self:GetActiveWeapon()

	if weap and weap:IsValid() then

		local class = weap:GetClass()
		local Ammo = weap:Clip1()

		local GroundItem = self:DropItemProp(class, Ammo)

		local WeaponData = TS.ItemsData[class]
		local Slot = false

		if not (WeaponData) then return end

		local SlotString = {
			[true] = "Primary",
			[false] = "Secondary"
		}

		if WeaponData.IsPrimary then Slot = true end

		self["SetPlayer" .. SlotString[Slot] .. "Weapon"](self, "")

	end

end

function meta:Unconscious()

	if self:IsCP() then return end

	TS.PrintMessageAll(2, self:GetRPName() .. "(" .. self:Name() .. ")" .. " was knocked unconscious.")

	self:SelectWeapon("ts2_hands")

	local ent = self:RagdollPlayer()

	self.RagdollHealth = self:Health()

	self:Spectate(OBS_MODE_CHASE)
	self:SpectateEntity(ent)

	self:SetPlayerConscious(false)

end

function meta:Conscious()

	self:UnragdollPlayer()

	self:SetHealth(self.RagdollHealth or 100)

	self:UnSpectate()

	self:SetPlayerConscious(true)

end

function meta:TiedUpBy(ply)

	if self.HandPickUpSent and self.HandPickUpSent:IsValid() then
		self:RemoveHandPickUp()
	end

	if self.RightHandEntity and self.RightHandEntity:IsValid() then

		self.RightHandEntity:Remove()
		self.RightHandEntity = nil

	end

	self:DrawViewModel(false)

	self.IsTied = true

	self:PrintMessage(3, "Tied up by " .. ply:GetRPName())
	ply:PrintMessage(3, "You've tied up " .. self:GetRPName())

	self:SelectWeapon("ts2_hands")
	self:SetPlayerHolstered(true)

end

function meta:SetAimAnim(bool)

	self.Unholstered = bool

	umsg.Start("UNS")
		umsg.Bool(bool)
		umsg.Entity(self:GetActiveWeapon())
	umsg.End()

end

function meta:RemoveAccountMenu()

	umsg.Start("RAM", self)
	umsg.End()

end

function meta:CanBeSkyNet()

	for k, v in pairs(TS.Flags) do

		if self:HasTerminatorFlag(v.ID) && v.IsSkynet == true then

			return true

		end

	end

	return false

end

function meta:IsDrone()

	for k, v in pairs(TS.Flags) do

		if self:HasTerminatorFlag(v.ID) && v.Drone == true then

			return true

		end

	end

	return false

end


function meta:CanUseSkynetRadio()

	for k, v in pairs(TS.Flags) do

		if self:HasTerminatorFlag(v.ID) && v.CanUseRadio then

			return true

		end

	end

	return false

end

function meta:CanUseDroneItem()

	for k, v in pairs(TS.Flags) do

		if self:HasTerminatorFlag(v.ID) && v.Drone == true then

			return true

		end

	end

	return false

end

/* Some meta functions for my world radio. */

/* ToDo: Get rid of ents.FindByClass! */

function meta:IsNearWorldRadio()

	for k, v in pairs (TS.WorldRadios) do

		if v && IsValid(v) then

			if v.ItemData.Frequency ~= nil then /* Is our radio on? Is it even a radio? */

				if v:GetPos():Distance(self:GetPos()) < 180 then

					return true

				end

			end

		else

			table.remove(TS.WorldRadios, k)

		end

	end

	return false

end

/* Deprecated? */
function meta:GetNearestWorldRadioFrequency()

	local tbl = { 0, 0 } /* [1] = distance, [2] = frequency. */

	local pos = self:GetPos()

	for k, v in pairs (TS.WorldRadios) do

		if v && IsValid(v) then

			if v.ItemData.Frequency ~= nil then /* Is our radio on? Is it even a radio? */

				pos = pos:Distance(v:GetPos())

				if tbl[1] == 0 || tbl[1] > pos then

					tbl = {pos, v.ItemData.Frequency}

				end

			end

		else

			table.remove(TS.WorldRadios, k)

		end

	end

	return tbl[2]

end

/* Get the current entity we're viewing. Return it if it's a world radio. */
function meta:GetViewedRadioEnt()

	local trace = { }
	trace.start = self:EyePos()
	trace.endpos = trace.start + self:GetAimVector() * 90
	trace.filter = self

	local tr = util.TraceLine(trace)

	if tr.Entity && IsValid(tr.Entity) then

		if tr.Entity.ItemData then

			if tr.Entity.ItemData.Frequency then

				return tr.Entity

			end

		end

	end

	return false

end

/* If we don't have a radio item, perhaps we can use the world entity as our radio? */
function meta:CanUseRadio()

	if self:HasItem("radio") || self:GetViewedRadioEnt() then

		return true

	end

	return false

end

/* ========================================= */

function meta:PromptAccountCreationMenu()

	umsg.Start("HandleAccountCreation", self)
	umsg.End()

end

function meta:PromptQuizMenu()

	umsg.Start("CQ", self)
	umsg.End()

end

function meta:IsPhysBanned()

	if table.HasValue(TS.PhysgunBans, self:SteamID()) then

		return true

	end

	return false

end

function meta:UnTiedUpBy(ply)

	self:DrawViewModel(true)

	self.IsTied = false

	self:PrintMessage(3, "Untied up by " .. ply:GetRPName())
	ply:PrintMessage(3, "You've untied " .. self:GetRPName())

	self:SelectWeapon("ts2_hands")
	self:SetPlayerHolstered(true)

end

function meta:CheckLimit(name)

	local limit = self.Limits[name] or 0
	local default = GetConVarNumber("sbox_max" .. name)

	if default > limit then
		limit = default
	elseif limit < 0 then
		return true
	end

 	if self:GetCount(name) >= limit then
		self:LimitHit(name)
		return false
	end
 	return true

end

function meta:ScalePlayer(scale)
	self:SetModelScale(scale, 0)
	self:SetHull(Vector(-16 * scale, -16 * scale, 0), Vector(16 * scale, 16 * scale, 72 * scale))
	self:SetHullDuck(Vector(-16 * scale, -16 * scale, 0), Vector(16 * scale, 16 * scale, 36 * scale))
	self:SetViewOffset(Vector(0, 0, 64 * scale))
	self:SetViewOffsetDucked(Vector(0, 0, 28 * scale))
end

function meta:MakeTall()
	self:ScalePlayer(1.1)
end

function meta:MakeNormal()
	self:ScalePlayer(1)
end

function meta:MakeShort()
	self:ScalePlayer(0.9)
end

function meta:AttachProp(model, attachment)

	local ent = ents.Create("ts2_attachment")
	ent:SetModel(model)
	ent:SetPlayer(self, attachment)
	ent:Spawn()

	table.insert(self.AttachedProps, { Model = model, Attachment = attachment, Entity = ent })

	return ent

end

function meta:RemoveAttachmentFrom(attachment)

	for k, v in pairs(self.AttachedProps) do

		if v.Attachment == attachment then

			v.Entity:Remove()
			self.AttachedProps[k] = nil

		end

	end

end

--rp_getinfo related shit.
function meta:GetInfoWeapons()

	for k, v in pairs(weapons.GetList()) do

		if self:HasItem(v.ClassName) then

			return v.ClassName

		end

	end

	return ""

end

function meta:GetInfoItems()

	local items, I = {}, 1
	for i, inv in pairs(self.InventoryGrid) do
		for x, col in pairs(inv) do
			for y, cell in pairs(col) do
				if cell.ItemData then
					items[I], I = cell.ItemData.ID, I + 1
				end
			end
		end
	end
	return items

end

function meta:HandleSitGround()

	self:SetPlayerFreezeHead(true)
	self.ForcedAnimationMode = true
	self.ForcedAnimation = 373
	self.InStanceAction = true
	self.StanceGroundSit = true
	self.StanceGroundSitPos = self:GetPos()

	umsg.Start("HSG", self:EntIndex())
		umsg.Entity(self)
	umsg.End()

end

function meta:HandleSit(ent)

	self:SetPlayerFreezeHead(true)
	self.ForcedAnimationMode = true
	self.ForcedAnimation = anim
	self.InStanceAction = true
	self.StanceSit = true
	self.StanceSitPlayerPos = self:GetPos()
	self.StanceSitEntPos = ent:GetPos()
	self.StanceSitEnt = ent

	umsg.Start("HS", self:EntIndex())
		umsg.Entity(self)
	umsg.End()

end

function meta:HandleLean()

	self:SetPlayerFreezeHead(true)
	self.ForcedAnimationMode = true
	self.ForcedAnimation = 370
	self.InStanceAction = true
	self.StanceLean = true
	self.StanceLeanPos = self:GetPos()
	self:Freeze(true)

	umsg.Start("HL", self:EntIndex())
		umsg.Entity(self)
	umsg.End()

end

function meta:HasTerminatorFlag(flag)

	if string.find(self.TerminatorFlags, flag) then

		return true

	end

	return false

end

function meta:HasPlayerFlag(flag)

	if string.find(self.PlayerFlags, flag) then

		return true

	end

	return false

end