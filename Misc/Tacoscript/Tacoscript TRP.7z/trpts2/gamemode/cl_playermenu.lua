PlayerMenuVisible = false

PlayerMenuIntro = 0

function event.PlayerMenuOff()

	if PlayerMenuVisible then

		TogglePlayerMenu()

	end

end

function TogglePlayerMenu()

	PlayerMenuVisible = !PlayerMenuVisible

	StorageItemID = nil

	for k, v in pairs(PlayerMenuLinks) do

		v:SetVisible(PlayerMenuVisible)

		local x, y = v:GetPos()

		v:SetPos(-1000, y)

	end

	if PlayerInfoPanel and PlayerInfoPanel:IsValid() then

		if PlayerInfoPanel.TitleBar and PlayerInfoPanel.TitleBar:IsValid() then
			PlayerInfoPanel.TitleBar:SetVisible(PlayerMenuVisible)
		end

		PlayerInfoPanel:SetVisible(PlayerMenuVisible)

	end

	if PlayerMenuVisible then

		gui.EnableScreenClicker(true)

		InventoryMenu:SetVisible(true)
		InventoryMenu.TitleBar:SetVisible(true)
		InventoryMenu.PrimarySlot:SetVisible(true)
		InventoryMenu.PrimarySlot.Model:SetVisible(true)

		InventoryMenu.SecondarySlot:SetVisible(true)
		InventoryMenu.SecondarySlot.Model:SetVisible(true)

		PlayerMenuIntro = 0

		RemoveItemButtons()

	else

		if StorageMenu then
			StorageMenu:Remove()
			StorageMenu = nil
		end

		if RadioFrame then
			RadioFrame:Remove()
		end

		InventoryMenu:SetVisible(false)
		InventoryMenu.TitleBar:SetVisible(false)

		InventoryMenu.PrimarySlot:SetVisible(false)
		InventoryMenu.PrimarySlot.Model:SetVisible(false)

		InventoryMenu.SecondarySlot:SetVisible(false)
		InventoryMenu.SecondarySlot.Model:SetVisible(false)

		ResetItemData()

		HideMouse()

	end

end
usermessage.Hook("TPM", TogglePlayerMenu)

surface.CreateFont("IDHeader", {
	size = 22,
	weight = 800,
	font = "TargetID",
	antialias = true,
	additive = false
})

surface.CreateFont("IDHeader2", {
	size = 18,
	weight = 800,
	font = "TargetID",
	antialias = true,
	additive = false
})

surface.CreateFont("IDInfo", {
	size = 16,
	weight = 200,
	font = "BudgetLabel",
	antialias = true,
	additive = false
})

surface.CreateFont("IDInfo2", {
	size = 16,
	weight = 800,
	font = "BudgetLabel",
	antialias = true,
	additive = false
})

surface.CreateFont("IDInfo3", {
	size = 9,
	weight = 100,
	font = "BudgetLabel",
	antialias = true,
	additive = false
})

function DrawPlayerMenu()

	for k, v in pairs(PlayerMenuLinks) do

		local x, y = v:GetPos()

		v:SetPos((ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)), y)

	end

	local sw = 125

	HealthAlpha = 255
	SprintAlpha = 255

	--[[ draw.DrawText(ClientVars["Title"] .. "\n" .. ClientVars["Title2"], "NewChatFont", (ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)) + 2, ScrH() - sw - 10, Color(255, 255, 255, 255)); ]]--

	for n = 1, #TS.PlayerStats do

		local perc = ClientVars[TS.PlayerStats[n]] / 100

		draw.RoundedBox(2, (ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)), ScrH() - sw + (20 * n), (ScrW() * .15 - 2), 14, Color(0, 0, 0, 255))
		local w = (ScrW() * .15 - 2)

		if perc > 0 then
			draw.RoundedBox(2, (ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)) + 2, ScrH() - sw + (20 * n) + 2, (ScrW() * .15 - 6) * perc, 10, Color(39, 64, 139, 255))
			draw.RoundedBox(2, (ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)) + 2, ScrH() - sw + (20 * n) + 2, (ScrW() * .15 - 6) * perc, 4, Color(58, 95, 205, 255))
		end

		draw.DrawText(TS.PlayerStats[n] .. " - " .. ClientVars[TS.PlayerStats[n]], "SmallChatFont", (ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)) + 2, ScrH() - sw + (20 * n) + 2, Color(255, 255, 255, 255))

	end

end

function PlayerMenuThink()

	if PlayerMenuIntro < 100 then

		PlayerMenuIntro = math.Clamp(PlayerMenuIntro + 500 * FrameTime(), 0, 100)

	end

end

if PlayerMenuLinks then

	for k, v in pairs(PlayerMenuLinks) do
		v:Remove()
	end

end

/* When I see the point of putting this somewhere else, I will. */


function CreatePanel()

	local w = 500
	local h = 250

	if !GSM then

		GSM = CreateBPanel("Set Description", ScrW() / 2 - (w / 2), ScrH() / 2 - (h / 2), w, h)


	else
		GSM:Remove()
		GSM = nil
		GSM = CreateBPanel("Set Description", ScrW() / 2 - (w / 2), ScrH() / 2 - (h / 2), w, h)

	end

	local x, y = GSM:GetPos()

	GSM.Button = GSM:AddButton("Ok", 5, h - 30)

	GSM.Text = vgui.Create("DTextEntry", GSM)
	GSM.Text:SetPos(x + 5, y + 5)
	GSM.Text:SetSize(w - 10, h - 40)
	GSM.Text:MakePopup()
	GSM.Text:SetMultiline(true)
	GSM.Text:SetValue(LocalPlayer():GetTitle())

	GSM.PaintHook = function()

		local str = tostring(300 - string.len(GSM.Text:GetValue())  .. " character's left.")

		/* Banana VGUI, why u so bad? */
		draw.DrawText(str, "NewChatFont", w - 60, h - 28, Color(255, 255, 255, 255), 1)

		local x, y = GSM:GetPos()
		GSM.Text:SetPos(x + 5, y + 5)

	end

	GSM.Button.Action = function()

		if string.len(GSM.Text:GetValue()) > 300 then

			CreateOkPanel("Invalid Description!", "Your character description is too long!")
			return

		end

		local buff = GSM.Text:GetValue()

		net.Start("STTS")
			net.WriteString(buff)
		net.SendToServer()

		GSM:Remove()

	end

end


PlayerMenuLinks = { }

function CreatePlayerMenu()

	local function AddLink(name, y, func)

		local link = vgui.Create("BLink")
		link:SetPos((ScrW() * -.15 - 2) + ((ScrW() * .15 + 8) * (PlayerMenuIntro / 100)), y)
		link:SetFont("NewChatFont")
		link:SetText(name)
		link:SizeToContents()
		link.HighlightColor = Color(0, 65, 160, 255)
		link.Action = func

		table.insert(PlayerMenuLinks, link)

	end

	AddLink("Character Create/Select", ScrH() - 250, function() RunConsoleCommand("eng_charmenu", ""); end)
 	AddLink("Open MOTD", ScrH() - 230, function() RunConsoleCommand("rp_motd", ""); end)
	AddLink("Item Spawning", ScrH() - 210, function() RunConsoleCommand("rp_spawning"); end)
	AddLink("Help", ScrH() - 190, function() RunConsoleCommand("gm_showhelp", ""); end)
	AddLink("Set Description", ScrH() - 170, function()

		CreatePanel()
		event.PlayerMenuOff()

	end)
	AddLink("Settings", ScrH() - 150, function()

		TS.SettingsMenu:Open()
		event.PlayerMenuOff()

	end)

end

CreatePlayerMenu()