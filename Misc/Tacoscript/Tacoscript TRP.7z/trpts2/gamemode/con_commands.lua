local function ccAdminSay(ply, cmd, text)

	if ply:EntIndex() == 0 then

		for k, v in ipairs(player.GetAll()) do
			if v:IsAdmin() then
				SendOverlongMessage(0, TS.MessageTypes.ADMIN.id, "[ADMINS] " .. text, v)
			end
		end

		TS.WriteToChatLog("Console: [ADMINS] " .. text)

		print("Console: [ADMINS] " .. text)

	end

end
concommand.Add("asay", ccAdminSay)

function ccUnlockDoor(ply, cmd, args)

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 70
	trace.filter = ply

	local tr = util.TraceLine(trace)

	if tr.Entity and tr.Entity:IsDoor() then

		ply:EmitSound(Sound("doors/door_latch3.wav"))

		tr.Entity:Fire("unlock", "", 0)
		ply:PrintMessage(3, "Door unlocked.")

	else

		ply:PrintMessage(3, "Not a door!")

	end

end
concommand.Add("rp_unlock", ccUnlockDoor)

function ccLockDoor(ply, cmd, args)

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 70
	trace.filter = ply

	local tr = util.TraceLine(trace)

	if tr.Entity and tr.Entity:IsDoor() then

		ply:EmitSound(Sound("doors/door_latch3.wav"))

		tr.Entity:Fire("lock", "", 0)
		ply:PrintMessage(3, "Door locked.")

	else

		ply:PrintMessage(3, "Not a door!")

	end

end
concommand.Add("rp_lock", ccLockDoor)

function ccChangeName(ply, cmd, args)

	if ply.IsTied then return end

	local name = string.gsub(table.concat(args, " "), "[\r\n\t]", "")
	if #name < 3 or #name > 30 or not string.match(name, "%S") then
		return
	end

	if ply:CharExists(name) then

		ply:PrintMessage(2, "You already have a character with that name!")
		return

	end

	ply:CharSaveData("charName", name)
	ply:SetNWString("RPName", name)

end
concommand.Add("rp_changename", ccChangeName)

function ccYoutubeStop(ply, cmd, arg)
	umsg.Start("KYT", ply)
	umsg.End()
	Console(ply, "Stopped Youtube Song!")
end
concommand.Add("rp_stopyoutube", ccYoutubeStop)


function ccDevRestart(ply, cmd, arg)

	if not ply:IsRick() then return end

	timer.Simple(1, function() game.ConsoleCommand("changelevel " .. game.GetMap() .. "\n") end)

end
concommand.Add("dr", ccDevRestart)

function ccPrintUserList(ply, cmd, arg)
	local players = player.GetAll()

	for n = 1, #players do
		local pl = players[n]
		if pl:IsValid() then

			if not pl:IsCP() then

				Console(ply, n .. " - " .. pl:GetRPName() .. " [" .. pl:Name() .. "][" .. pl:SteamID() .. "]")

			end

		end

	end

end
concommand.Add("rp_printuserlist", ccPrintUserList)
concommand.Add("rp_userlist", ccPrintUserList)

local hguns = { "weapon_physgun", "weapon_physcannon", "gmod_tool" }

function ccSelectWeapon(ply, cmd, arg)

	if not arg[1] then
		return
	end

	if ply.IsTied then return end

	if ply:HasWeapon(arg[1]) then

		ply:SelectWeapon(arg[1])

		if table.HasValue(hguns, arg[1]) then

			ply:SetAimAnim(true)
			return

		end

		if ply.Unholstered then

			ply:SetAimAnim(false)

		end

	end

end
concommand.Add("rp_selectweapon", ccSelectWeapon)

function ccICSit(ply, cmd, arg)

	if CurTime() - ply.LastStanceAction < 2 then
		return
	end

	ply.LastStanceAction = CurTime()

	if not ply.InStanceAction then

		if ply:Crouching() then return end

		local trace = { }
		trace.start = (ply:EyePos() - Vector(0, 0, 30))
		trace.endpos = trace.start - ply:GetAngles():Forward() * 22
		trace.filter = ply

		local tr = util.TraceLine(trace)

		if not tr.Hit then

			local trace = { }
			trace.start = (ply:EyePos() - Vector(0, 0, 25)) - ply:GetAngles():Forward() * 22
			trace.endpos = trace.start - Vector(0, 0, 25)
			trace.filter = ply

			local tr = util.TraceLine(trace)

			if tr.Hit then

				ply.StanceSnapToPlayerPos = ply:GetPos()
				ply:SetPos(ply:GetPos() + ply:GetAngles():Forward() * -10)

				ply:HandleSit(tr.Entity)

				ply:PrintMessage(3, "Sitting down")

			else

				ply:PrintMessage(3, "Can't sit here")

			end

		else

			ply:PrintMessage(3, "Can't sit here")

		end

	elseif ply.StanceSit then

		if ply.StanceSnapToPlayerPos then

			ply:SetPos(ply.StanceSnapToPlayerPos)

		end

		ply:SnapOutOfStance()

	end

end
concommand.Add("rp_ic_sit", ccICSit)

function ccICSitGround(ply, cmd, arg)

	if CurTime() - ply.LastStanceAction < 2 then
		return
	end

	ply.LastStanceAction = CurTime()

	if not ply.InStanceAction then

		ply:HandleSitGround()

		ply:PrintMessage(3, "Sitting down")

	elseif ply.StanceGroundSit then

		ply:SnapOutOfStance()

	end

end
concommand.Add("rp_ic_sitground", ccICSitGround)

function ccICLean(ply, cmd, arg)

	if CurTime() - ply.LastStanceAction < 2 then
		return
	end

	ply.LastStanceAction = CurTime()

	local TurnOffLean = function()

		ply:SnapOutOfStance()
		ply:Freeze(false)

	end

	if not ply.InStanceAction then

		local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = (trace.start - Vector(0, 0, 25)) - ply:GetAngles():Forward() * 20
		trace.filter = ply

		local tr = util.TraceLine(trace)

		if tr.Hit then

			ply:HandleLean()
			ply:PrintMessage(3, "Leaning")

		end

		local function leanthink()

			if ply.StanceLean then

				local trace = { }
				trace.start = ply:EyePos()
				trace.endpos = (trace.start - Vector(0, 0, 25)) - ply:GetAngles():Forward() * 20
				trace.filter = ply

				local tr = util.TraceLine(trace)

				if not tr.Hit then

					TurnOffLean()

				else

					timer.Simple(1, leanthink)

				end

			end

		end

		timer.Simple(1, leanthink)

	elseif ply.StanceLean then

		TurnOffLean()
		ply:Freeze(false)

	end

end
concommand.Add("rp_ic_lean", ccICLean)

function ccMOTD(ply)

	if CurTime() - ply.LastMOTDPrompt < 2 then
		return
	end

	if not ply.CanInitialize then
		return
	end

	ply.LastMOTDPrompt = CurTime()

	ply:PromptMOTD()

end
concommand.Add("rp_motd", ccMOTD)

function CCSpawnSWEP(ply, cmd, arg)

	if not ply:IsSuperAdmin() then

		return

	end

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 60
	trace.filter = ply

	local tr = util.TraceLine(trace)

	local weap = arg[1]

	if TS.ItemsData[weap] then

		local weapon = TS.CreateItemProp(arg[1], tr.HitPos)

		local min = weapon:OBBMins()
		local pos = tr.HitPos - tr.HitNormal * min.z
		weapon:SetPos(pos)

	else

		ply:PrintMessage(3, "Cannot spawn none TS2 supported weapons!")

	end

end
concommand.Add("gm_spawnswep", CCSpawnSWEP)
concommand.Add("gm_giveswep", CCSpawnSWEP)

function ccFreqChange(ply, cmd, args)

	if ply:IsCP() then return end

	local freq = tonumber(args[1])

	if freq then

		freq = math.floor(freq)

	else

		return

	end

	if freq < 0 then

		return

	end

	if freq > 999 then

		return

	end

	/* This modification is for the tuning of my world radio entities. */
	if args[2] then

		local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 90
		trace.filter = ply

		local tr = util.TraceLine(trace)

		/* pretty much self explanatory? */
		if tr.Entity.ItemData.Frequency then

			tr.Entity.ItemData.Frequency = freq
			ply:PrintMessage(3, "Radio frequency set to " .. tostring(freq) .. ".")

		end

	elseif ply:HasItem("radio") then

		ply.Frequency = freq

	end

end
concommand.Add("rp_changefreq", ccFreqChange)

function ccToggleRadio(ply, cmd, arg)

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 90
	trace.filter = ply

	local tr = util.TraceLine(trace)

	if tr.Entity && IsValid(tr.Entity) then

		if tr.Entity.ItemData.IsOn ~= nil then

			local tab = {[true] = "On.", [false] = "Off."}

			tr.Entity.ItemData.IsOn = !tr.Entity.ItemData.IsOn
			tr.Entity.ItemData.Description = "This radio is " .. tab[tr.Entity.ItemData.IsOn]
			tr.Entity:EmitSound("UI/buttonclick.wav", 100, 100)

		end

	else

		ply:PrintMessage(3, "Not close enough to radio!")

	end

end
concommand.Add("rp_toggleradio", ccToggleRadio)

function ccSpawnList(ply, cmd, arg)
	if not ply.Initialized then
		return
	end

	if not (ply:HasPlayerFlag("Y") || ply:HasPlayerFlag("X") || ply:HasPlayerFlag("Z")) && not (ply:IsAdmin() || ply:IsSuperAdmin()) then
		ply:PrintMessage(3, "You need the X, Y, or Z flag to access this!")
		return
	end

	local function OpenSpawnMenu()
		local x = false

		if ply:HasPlayerFlag("X") || ply:HasPlayerFlag("Z") then
			x = true
		end

		umsg.Start("PSM", ply)
			umsg.Bool(x)
		umsg.End()
	end

	if ply.SpawnMenuLoaded then
		OpenSpawnMenu()
	else
		if ply.SpawnMenuLoading then
			return
		end

		ply.SpawnMenuLoading = true

		TS.ItemNetworking:SendProcessedItems(ply)
		OpenSpawnMenu()

		ply:PrintMessage(3, "Spawn menu initialize complete!")
		ply.SpawnMenuLoaded = true
	end
end
concommand.Add("rp_spawning", ccSpawnList)

function ccDeleteCharacter(ply, cmd, arg)

	if not arg[1] then
		ply:PrintMessage(2, "rp_deletesave - Delete a character permanently")
		return
	end

	local name = arg[1]

	for n = 2, #arg do

		name = name .. " " .. arg[n]

	end

	if not ply:CharExists(name) then

		ply:PrintMessage(2, "Save does not exist!")
		return

	end

	TS.SQL:Query("DELETE FROM {CHARACTERS} WHERE userID = ? AND charName = ?", ply.UID, name)

	--If they're playing on the save..
	if ply:GetRPName() == name then

		ply:PrintMessage(2, "Save removed: " .. name)

		ply:RefreshChar()

		if not ply.CharacterMenu then

			ply:PromptCharacterMenu()
			ply:CallEvent("HorseyMapViewOn")

		end

	else

		ply:PrintMessage(2, "Save removed: " .. name)

	end

end
concommand.Add("rp_deletesave", ccDeleteCharacter)

--Player item spawning
function ccSpawnItem(ply, cmd, arg)

	if not arg[1] or not TS.ItemsData[arg[1]] then return end

	if string.find(arg[1], "donator_") then return end
	if string.find(arg[1], "weapon_") then return end
	if !ply:IsAddingGoodWep(arg[1]) then return end

	if TS.ItemsData[ arg[1] ].AdminOnly && not (ply:IsAdmin() || ply:IsSuperAdmin()) then

		ply:PrintMessage(3, "This item can only be spawned by admins!")
		return

	end

	if not ply:HasPlayerFlag(TS.ItemsData[ arg[1] ].Spawnflag) && not (ply:IsAdmin() || ply:IsSuperAdmin()) then

		ply:PrintMessage(3, "You require " .. TS.ItemsData[ arg[1] ].Spawnflag .. " flag to do this!")
		return

	end

	TS.WriteLog("spawnmenu", ply:GetRPName() .. "(" .. ply:SteamID() .. ")" .. " has spawned: " .. arg[1] .. " " .. "(" .. tostring(os.date()) .. ")")

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 150
	trace.filter = ply

	local tr = util.TraceLine(trace)

	local item = TS.CreateItemProp(arg[1], tr.HitPos, nil, nil, tr)

end
concommand.Add("rp_spawnitem", ccSpawnItem)

function ccGiveWeap( ply, cmd, arg )
	local activeweap = ply:GetActiveWeapon()

	if not activeweap or not activeweap:IsValid() then
		ply:PrintMessage(3, "Take out a weapon to give!")
		return
	end

	if (activeweap:GetClass() == "gmod_tool" or
		activeweap:GetClass() == "weapon_physcannon" or
		activeweap:GetClass() == "weapon_physgun" or
		activeweap:GetClass() == "ts2_hands" or
		activeweap:GetClass() == "ts2_tgun") then

		ply:PrintMessage(3, "You cannot give this!")
		return
	end

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 200
		trace.filter = ply
	local tr = util.TraceLine(trace)

	local Receiver = tr.Entity

	if Receiver and Receiver:IsValid() and Receiver:IsPlayer() then
		if Receiver:EyePos():Distance( ply:EyePos() ) <= 50 then

			local s_activeclass = activeweap:GetClass()

			//This is what should be called.
			local Item = TS.ItemsData[s_activeclass]
			local ammo = ply:GetWeapon(s_activeclass):Clip1()

			local function SetWeapon( ply, id )
				local func = ( Item.IsPrimary && "Primary" || !Item.IsPrimary && "Secondary" )
				ply["SetPlayer"..func.."Weapon"]( ply, id or Item.ID)
			end

			local function HasWeapon( ply )
				local func = ( Item.IsPrimary && "Primary" || !Item.IsPrimary && "Secondary" )
				return ( ply["GetPlayer"..func.."Weapon"]( ply ) == "" )
			end

			//Does our subject have a primary weapon himself?
			if !HasWeapon( Receiver ) then
				if !Receiver.ItemsDownloaded[Item.ID] then
					Receiver:SendItemData(Item.ID)
				end

				//Give it to him then.
				SetWeapon(Receiver)
				local pWeapon = Receiver:Give(s_activeclass)
				Receiver:SelectWeapon (s_activeclass)

				//Now that you have the gun, we can't forget the ammo loaded in it.
				pWeapon:SetClip1(ammo)

				//We gave him the gun, it only makes sense we would have our hands out.
				ply:SelectWeapon ("ts2_hands")

				//Take our gun away.
				ply:StripWeapon(s_activeclass)
				SetWeapon( ply, "" )

				return
			end

			if !Receiver:CanItemFitInAnyInventory(s_activeclass) then
				ply:PrintMessage(3, "Player cannot fit weapon in inventory!")
				return
			end

			local bool, iid, x, y = Receiver:GiveAnyInventoryItem( s_activeclass )
			Receiver:ModifyItemAmount( iid, x, y, ammo )
			SetWeapon( ply, "" )

			ply:StripWeapon( s_activeclass )

			SetWeapon = nil
			HasWeapon = nil
		else
			ply:PrintMessage(3, "Not close enough to player!")
		end
	end
end
concommand.Add("rp_giveweap", ccGiveWeap)

function ccPlaceWeapon(ply, cmd, arg)

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 200
		trace.filter = ply

	local tr = util.TraceLine(trace)

	local Weapon = ply:GetActiveWeapon():GetClass()
	local Amount = ply:GetActiveWeapon():Clip1()

	if (Weapon == "gmod_tool" or
		Weapon == "weapon_physcannon" or
		Weapon == "weapon_physgun" or
		Weapon == "ts2_hands" or
		Weapon == "ts2_tgun") then

		Weapon:PrintMessage(3, "No.")
		return

	end

	local Distance =  tr.HitPos:Distance(ply:GetPos())

	if Distance > 60 && Distance < 90 then

		if (math.abs(tr.HitNormal.x) == 1) || (math.abs(tr.HitNormal.y) == 1) then

			ply:ClearWeapon(Weapon)

			local ent = TS.CreateItemProp(Weapon, tr.HitPos, nil, Amount, tr)
			ent:GetPhysicsObject():EnableMotion(false)

		else

			ply:ClearWeapon(Weapon)

			local ent = TS.CreateItemProp(Weapon, tr.HitPos, nil, Amount, tr)

		end

	end

end
concommand.Add("rp_placeweapon", ccPlaceWeapon)

function ccDropWeapon(ply, cmd, arg)

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 200
		trace.filter = ply

	local tr = util.TraceLine(trace)

	local Weapon = ply:GetActiveWeapon():GetClass()
	local Amount = ply:GetActiveWeapon():Clip1()

	if (Weapon == "gmod_tool" or
		Weapon == "weapon_physcannon" or
		Weapon == "weapon_physgun" or
		Weapon == "ts2_hands" or
		Weapon == "ts2_tgun") then

		ply:PrintMessage(3, "No.")
		return

	end

	ply:ClearWeapon(Weapon)

	local ent = ply:DropItemProp(Weapon, Amount)

end
concommand.Add("rp_dropweapon", ccDropWeapon)

function ccBlorp(ply, cmd, arg)

	ply:PrintMessage(3, ".....BLORP!")

end
concommand.Add("rp_blorp", ccBlorp)

--[[
65 A
66 B
67 C
68 D
69 E
70 F
71 G
72 H
73 I
74 J
75 K
76 L
77 M
78 N
79 O
80 P
81 Q
82 R
83 S
84 T
85 U
86 V
87 W
88 X
89 Y
90 Z
--]]

function ccToggleTHUD(ply, cmd, args)

	--if they're not on the terminator team then they can't use this command.
	if not ply:IsCP() and not ply:HasTerminatorFlag("E") then
		ply:PrintMessage(3, "You can\'t use this!")
		return
	end

	umsg.Start("tthud", ply)
	umsg.End()

end
concommand.Add("rp_thud", ccToggleTHUD)
