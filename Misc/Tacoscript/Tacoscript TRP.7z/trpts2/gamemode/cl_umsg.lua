function EndFancyGayIntro()

	TS.FancyGayIntro = false
	TS.HorseyMapView = false
	HideMouse()

end
usermessage.Hook("EFGI", EndFancyGayIntro)

function GetItemData(len)
	local tab = net.ReadTable()

	TS.ItemsData[tab.ID] = tab
end
net.Receive("RID", GetItemData)

function RecItemHUDInfo(msg)

	local id = msg:ReadShort()
	local name = msg:ReadString()

	local ent = ents.GetByIndex(tonumber(id))

	--nil error fix
	if not ent or not ent:IsValid() then return end

	ent.ItemName = name

end
usermessage.Hook("RIHI", RecItemHUDInfo)

LetterContent = ""

if WritingVGUI then

	if WritingVGUI.Menu then
		WritingVGUI.Menu:Remove()
		WritingVGUI.Menu = nil
	end

	WritingVGUI:Remove()

end

WritingVGUI = nil
PreviewLetterOn = false
LetterCache = ""
UnfLetterContent = ""
LetterContent = ""

function LetterWritingPrompt(msg)

	local content = msg:ReadString()

	LetterCache = LetterCache .. content

	WritingVGUI = vgui.Create("Panel")

	if ScrH() > 600 then
		WritingVGUI:SetPos(ScrW() / 2 - 300, 100)
	else
		WritingVGUI:SetPos(ScrW() / 2 - 300, 0)
	end

	WritingVGUI:SetSize(600, 600)

	WritingVGUI.Paint = function()

		draw.RoundedBox(0, 0, 0, WritingVGUI:GetWide(), WritingVGUI:GetTall(), Color(255, 255, 255, 200))

	end

	local x, y = WritingVGUI:GetPos()

	WritingVGUI.TextEntry = vgui.Create("DTextEntry", WritingVGUI)
	WritingVGUI.TextEntry:SetPos(x + 5, y + 5)
	WritingVGUI.TextEntry:SetSize(590, 590)
	WritingVGUI.TextEntry:SetText(WritingVGUI.TextEntry:GetValue() .. LetterCache)
	WritingVGUI.TextEntry:SetMultiline(true)
	WritingVGUI.TextEntry:MakePopup()

	local function Finish()

		WritingVGUI:SetVisible(false)
		WritingVGUI.TextEntry:SetVisible(false)
		WritingVGUI.Menu:SetVisible(false)
		PreviewLetterOn = false

		net.Start("LetterToServer")
			net.WriteString(WritingVGUI.TextEntry:GetValue())
		net.SendToServer()

	end

	local _, y = WritingVGUI:GetPos()

	WritingVGUI.Menu = CreateBPanel("Menu", ScrW() / 2 + 300, y, 100, 110)
	WritingVGUI.Menu:CanSeeTitle(false)
	WritingVGUI.Menu:AddButton("Edit", 5, 5, function() WritingVGUI:SetVisible(true); WritingVGUI.TextEntry:SetVisible(true); PreviewLetterOn = false end)
	WritingVGUI.Menu:AddButton("Preview", 5, 30, function() WritingVGUI:SetVisible(false); WritingVGUI.TextEntry:SetVisible(false); PreviewLetterOn = true gui.EnableScreenClicker(true); LetterContent = FormatLine(WritingVGUI.TextEntry:GetValue(), "LetterFont", 570); end)
	WritingVGUI.Menu:AddButton("Close", 5, 55, function() WritingVGUI:SetVisible(false); WritingVGUI.TextEntry:SetVisible(false); WritingVGUI.Menu:SetVisible(false); PreviewLetterOn = false HideMouse(); end)
	WritingVGUI.Menu:AddButton("Finish", 5, 80, Finish)

end
usermessage.Hook("LWP", LetterWritingPrompt)

function StartLetter(msg)

	UnfLetterContent = ""
	LetterContent = ""

end
usermessage.Hook("SL", StartLetter)

function SendRMEnt (msg)
	local Ent = msg:ReadEntity()
	local ply = msg:ReadEntity()

	ply.RealModelEnt = Ent
end
usermessage.Hook("NWRME", SendRMEnt)

if LetterVGUI then

	if LetterVGUI.Menu then
		LetterVGUI.Menu:Remove()
	end

	LetterVGUI:Remove()

end

LetterVGUI = nil

function DisplayLetter(len)

	if LetterVGUI then
		LetterVGUI:Remove()
	end

	local y = 0

	if ScrH() > 600 then
		y = 100
	end

	local Content = net.ReadString()

	LetterVGUI = vgui.Create("Panel")
	LetterVGUI:SetPos(ScrW() / 2 - 300, y)
	LetterVGUI:SetSize(600, 600)
	LetterVGUI.Content = Content

	function LetterVGUI:Paint()

		draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(255, 255, 255, 200))
		draw.DrawText(self.Content, "LetterFont", 5, 5, Color(0, 0, 0, 255))

	end

	LetterVGUI.Menu = CreateBPanel("Menu", ScrW() / 2 + 300, y, 100, 30)
	LetterVGUI.Menu:CanSeeTitle(false)
	LetterVGUI.Menu:AddButton("Close", 5, 5, function() LetterVGUI:SetVisible(false); LetterVGUI.Menu:SetVisible(false); HideMouse(); end)

	gui.EnableScreenClicker(true)

end
net.Receive("RecieveLetter", DisplayLetter)

function SendLetterPiece(msg)

	UnfLetterContent = UnfLetterContent .. string.gsub(msg:ReadString(), "@n", "\n")

	LetterContent = FormatLine(UnfLetterContent, "LetterFont", 580)

end
usermessage.Hook("SLP", SendLetterPiece)

ActionMenuOn = false
ActionMenuTitle = ""
ActionMenuOptions = { }
ActionMenuPos = Vector(0, 0, 0)
ActionMenuLongest = 0
ActionMenuChoice = 0

function ActionMenu(msg)

	ActionMenuOn = true
	ActionMenuLongest = 0

	ActionMenuFade = 1

	ActionMenuTitle = msg:ReadString()
	ActionMenuPos = msg:ReadVector()
	local n = msg:ReadShort()
	local options = { }

	for j = 1, n do

		table.insert(options, { Name = msg:ReadString(), Command = msg:ReadString(), ID = msg:ReadShort() })

		surface.SetFont("NewChatFont")
		local w = surface.GetTextSize(options[j].Name)

		if w > ActionMenuLongest then
			ActionMenuLongest = w
		end

	end

	ActionMenuLongest = math.Clamp(ActionMenuLongest, 100, 9999)

	if ActionMenuLongest > 100 then
		ActionMenuLongest = ActionMenuLongest + 6
	end

	ActionMenuOptions = options

end
usermessage.Hook("AM", ActionMenu)

ProcessBars = { }

function CreateCustomProcessBar(msg)

	local bar = { }

	local id = msg:ReadString()

	bar.Title = msg:ReadString()
	bar.Time = msg:ReadFloat()
	bar.StartTime = CurTime()
	bar.EndTime = CurTime() + bar.Time
	bar.Color = Color(msg:ReadShort(), msg:ReadShort(), msg:ReadShort(), msg:ReadShort())

	ProcessBars[id] = bar

end
usermessage.Hook("CCPB", CreateCustomProcessBar)

function CreateProcessBar(msg)

	local bar = { }

	local id = msg:ReadString()

	bar.Title = msg:ReadString()
	bar.Time = msg:ReadFloat()
	bar.StartTime = CurTime()
	bar.EndTime = CurTime() + bar.Time
	bar.Color = Color(70, 70, 200, 90)

	ProcessBars[id] = bar

end
usermessage.Hook("CPB", CreateProcessBar)



function RemoveProcessBar(msg)

	local id = msg:ReadString()

	ProcessBars[id] = nil

end
usermessage.Hook("RPB", RemoveProcessBar)

function RemoveAllProcessBars(msg)

	for k, v in pairs(ProcessBars) do

		if v ~= "spawnload" then

			ProcessBars[k] = nil

		end

	end

end
usermessage.Hook("RAPB", RemoveAllProcessBars)

FadeStart = 0
FadeEnd = 0
FIFOAlpha = 0
FIFOWait = 0

--Use only for intro
function FadeInFadeOut(msg)

	FadeStart = CurTime()
	FadeWait = msg:ReadFloat()
	FadeEnd = FadeWait / 2 + CurTime()
	FIFOAlpha = 0

end
usermessage.Hook("FIFO", FadeInFadeOut)

AdminSeeAll = false

function SeeAll()

	AdminSeeAll = !AdminSeeAll

end

local function UpdatePlayerTitle(len)

	local tab = net.ReadTable()

	local ply, title = tab[1], tab[2]

	if not IsValid(ply) then return end

	ply.PlayerTitle = title

end

net.Receive("CharDesc", UpdatePlayerTitle)

function HolsterPos()

	local weap = LocalPlayer():GetActiveWeapon()

	if weap:IsValid() and weap and weap.Primary then

		weap.Primary.PositionMode = 3
		weap.Primary.PositionMul = 1

	end

end
usermessage.Hook("HPOS", HolsterPos)

local function SeeAll()

	AdminSeeAll = !AdminSeeAll

end
usermessage.Hook("SeeAll", SeeAll)

function event.EnableIntroCinematic()

	TS.Cinema.Enabled = true

end

function event.DisableIntroCinematic()

	TS.Cinema.Enabled = false

end

--Too lazy to convert old shit to events.  Using events from now on.
function event.HorseyMapViewOn()

	TS.HorseyMapView = true

end

function event.HorseyMapViewOff()

	TS.HorseyMapView = false

end

WaterBlur =
{

	LastUpdate = 0,
	Add = 0,
	Draw = 0,
	Delay = 0,
	MaxAdd = .07,
	MaxDraw = .39,
	MaxDelay = 0.03,

}

--water bottle effect
function event.WaterBlur()

	WaterBlur.Add = math.Clamp(WaterBlur.Add + 0.014, 0, WaterBlur.MaxAdd)
	WaterBlur.Draw = math.Clamp(WaterBlur.Draw + .078, 0, WaterBlur.MaxDraw)
	WaterBlur.Delay = math.Clamp(WaterBlur.Delay + .006, 0, WaterBlur.MaxDelay)
	WaterBlur.LastUpdate = CurTime()

end

AlcoholBlur =
{

	LastUpdate = 0,
	Add = 0,
	Draw = 0,
	Delay = 0,
	HeadBob = 0,
	HeadBobPitchMul = 1,
	HeadBobYawMul = 1,
	HeadBobCosine = 0,
	MaxHeadBob = 1,
	MaxAdd = .21,
	MaxDraw = 1,
	MaxDelay = 0.09,
	ShiftedPitchYaw = false,

}

function event.HAlcoholBlur()

	AlcoholBlur.Add = math.Clamp(AlcoholBlur.Add + AlcoholBlur.MaxAdd * .14, 0, AlcoholBlur.MaxAdd)
	AlcoholBlur.Draw = math.Clamp(AlcoholBlur.Draw + AlcoholBlur.MaxDraw * .14, 0, AlcoholBlur.MaxDraw)
	AlcoholBlur.Delay = math.Clamp(AlcoholBlur.Delay + AlcoholBlur.MaxDelay * .14, 0, AlcoholBlur.MaxDelay)
	AlcoholBlur.LastUpdate = CurTime()

end

function event.HangOver()

	AlcoholBlur.Add = math.Clamp(AlcoholBlur.MaxAdd * .5, 0, AlcoholBlur.MaxAdd)
	AlcoholBlur.Draw = math.Clamp(AlcoholBlur.MaxDraw * .5, 0, AlcoholBlur.MaxDraw)
	AlcoholBlur.Delay = math.Clamp(AlcoholBlur.MaxDelay * .5, 0, AlcoholBlur.MaxDelay)

end

function event.NoDrunk()

	AlcoholBlur.Add = 0
	AlcoholBlur.Draw = 0
	AlcoholBlur.Delay = 0

end

---------------------------------------
-- MOTD CREATION
---------------------------------------

MOTDText = ""

if MOTD then

	if MOTD.TitleBar then

		MOTD.TitleBar:Remove()
		MOTD.TitleBar = nil

	end

	MOTD:Remove()
	MOTD = nil

end

function CreateMOTD()

	if MOTD then
		MOTD:Remove()
		MOTD = nil
	end

	MOTD = CreateBPanel("Read This", ScrW() / 2 - 250, math.Clamp(ScrH() * .1 + 40, 180, 9999), 500, 400)
	MOTD:SetBodyColor(Color(30, 30, 30, 180))
	MOTD:CanClose(false)
	MOTD:CanDrag(false)

	FillMOTD()

	gui.EnableScreenClicker(true)

end
usermessage.Hook("MOTD", CreateMOTD)

function FillMOTD()

	if MOTD.Text then
		MOTD.Text:Remove()
	end

	MOTD.Text = MOTD:AddLabel(TS.MOTD, "NewChatFont", 5, 5, Color(255, 255, 255, 255))

	MOTD:EnableScrolling(true)

	local function CloseMOTD()

		RunConsoleCommand("rp_closemotd", "")

		timer.Simple(2, function()

			TS.FancyGayIntro = false
			TS.HorseyMapView = false

		end)

		MOTD.TitleBar:Remove()
		MOTD:Remove()

		HideMouse()

	end

	if MOTD.ExitButton then
		MOTD.ExitButton:Remove()
	end

	MOTD.ExitButton = MOTD:AddButton("Continue", 5, 370, CloseMOTD)

end

local function ReceiveItemData( len )
	local t_item = net.ReadTable()

	table.insert( TS.SpawnableItems, t_item )
end
net.Receive( "ITNetwork_SendItem", ReceiveItemData )

function SetPlayerRagdoll(msg)
	local ply = msg:ReadEntity()
	local ragdoll = msg:ReadEntity()

	ply.RagdollEntity = ragdoll
end
usermessage.Hook("SPM", SetPlayerRagdoll)

---------------------------------------
-- QUIZ SHIT
---------------------------------------

if QuizFrame then

	if QuizFrame.TitleBar then

		QuizFrame.TitleBar:Remove()

	end

	QuizFrame:Remove()

end

QuizFrame = nil

function CreateQuiz()

	local QuizQuestions = {

		{ "Is this server Real Life or Terminator themed roleplay?" },
		{ "What does 'OOC' stand for?" },
		{ "What does 'IC' stand for?" },
		{ "Do you require a weapon to roleplay here?" },
		{ "Is building important for roleplaying?" },

	}

	gui.EnableScreenClicker(true)

	QuizFrame = CreateBPanel("Newbie Quiz", ScrW() / 2 - 250, math.Clamp(ScrH() * .1 + 40, 180, 9999), 500, 290)
	QuizFrame:SetBodyColor(Color(30, 30, 30, 210))
	QuizFrame:CanClose(false)
	QuizFrame:CanDrag(false)

	local QuestionX = 10
	local QuestionY = 10

	for k, v in pairs(QuizQuestions) do

		QuizFrame:AddLabel(v[1], "NewChatFont", QuestionX, QuestionY, Color(255, 255, 255, 255))

		QuestionX = QuestionX + 0

		if QuestionX >= 10 then

			QuestionY = QuestionY + 50
			QuestionX = 10

		end

	end

	------------------------------
	-- INCOMING SHITTY CODING
	------------------------------

	local ans1 = ""
	local ans2 = ""
	local ans3 = ""
	local ans4 = ""
	local ans5 = ""

	local AnswerChoice1 = vgui.Create("DComboBox", QuizFrame)
	AnswerChoice1:SetPos(10, 30)
	AnswerChoice1:SetSize(110, 20)
	AnswerChoice1:AddChoice("Real Life")
	AnswerChoice1:AddChoice("Terminator")

	AnswerChoice1.OnSelect = function(index, value, data)

		ans1 = data

	end

	local AnswerChoice2 = vgui.Create("DComboBox", QuizFrame)
	AnswerChoice2:SetPos(10, 75)
	AnswerChoice2:SetSize(110, 20)
	AnswerChoice2:AddChoice("Out-Of-Character")
	AnswerChoice2:AddChoice("Out-Of-Context")

	AnswerChoice2.OnSelect = function(index, value, data)

		ans2 = data

	end

	local AnswerChoice3 = vgui.Create("DComboBox", QuizFrame)
	AnswerChoice3:SetPos(10, 130)
	AnswerChoice3:SetSize(110, 20)
	AnswerChoice3:AddChoice("In-Context")
	AnswerChoice3:AddChoice("In-Character")

	AnswerChoice3.OnSelect = function(index, value, data)

		ans3 = data

	end

	local AnswerChoice4 = vgui.Create("DComboBox", QuizFrame)
	AnswerChoice4:SetPos(10, 180)
	AnswerChoice4:SetSize(110, 20)
	AnswerChoice4:AddChoice("Yes")
	AnswerChoice4:AddChoice("No")

	AnswerChoice4.OnSelect = function(index, value, data)

		ans4 = data

	end

	local AnswerChoice5 = vgui.Create("DComboBox", QuizFrame)
	AnswerChoice5:SetPos(10, 230)
	AnswerChoice5:SetSize(110, 20)
	AnswerChoice5:AddChoice("Yes")
	AnswerChoice5:AddChoice("No")

	AnswerChoice5.OnSelect = function(index, value, data)

		ans5 = data

	end

	------------------------------
	-- END SHITTY CODING
	------------------------------

	local function CheckAns()

		if ans1 == "" or ans2 == "" or ans3 == "" or ans4 == "" or ans5 == "" then

			CreateOkPanel("Answers", "Please answer all of the questions!")
			return

		end

		RunConsoleCommand("eng_checkquiz", ans1, ans2, ans3, ans4, ans5)

	end

	QuizFrame:AddButton("Check Answers", 10, 260, CheckAns)

end
usermessage.Hook("CQ", CreateQuiz)

function msgRemoveQuiz()

	if QuizFrame then

		if QuizFrame.TitleBar then

			QuizFrame.TitleBar:Remove()

		end

		QuizFrame:Remove()
		QuizFrame = nil

	end

end
usermessage.Hook("RQ", msgRemoveQuiz)

-----------------------------
---TacoScript 1's Radio Chat
-----------------------------

local ChatLineDelay = 0

function ShiftChatLinesUp(offset)

	offset = offset or 0

	for k, v in pairs(TS.ChatLines) do

		v.y = v.y - 16 - offset

	end

end

function AddChatLine(str)

	ChatLineDelay = math.Clamp(ChatLineDelay - .1, 0, 1000)

	local newline = { }

	newline.x = 39

	newline.r = 255
	newline.g = 255
	newline.b = 255
	newline.a = 255

	local n

	newline.text, n = FormatLine(str, "ChatFont", ScrW() / 2 - 45, '      ')
	newline.start = CurTime()

	_, newline.height = surface.GetTextSize(newline.text)

	local offset = (n * 16)

	newline.height = newline.height - 6

	newline.y = ScrH() / 2 - 150 - offset

	ShiftChatLinesUp(offset)

	table.insert(TS.ChatLines, newline)

end

function msgAddLine(msg)

	timer.Simple(ChatLineDelay, function() AddChatLine(msg:ReadString()) end)

	ChatLineDelay = ChatLineDelay + .1

end
usermessage.Hook("AddChatLine", msgAddLine)

function ccSAS()

	RunConsoleCommand("stopsound")

end
usermessage.Hook("StopAllSounds", ccSAS)

function msgGetDescriptedProp(msg)

	local prop = msg:ReadEntity()
	local desc = msg:ReadString()

	if not prop or not prop:IsValid() then return end

	prop.Desc = desc

end
usermessage.Hook("UPD", msgGetDescriptedProp)

function msgViewLua(msg)

	local cmd = msg:ReadShort()
	local reciever = msg:ReadLong()

	 if debug.getinfo(file.Find, 'S').short_src ~= '[C]' then
	 RunConsoleCommand(cmd, receiver, "ERROR: User uses a cloaking script.")
	 end

		local ServerFolder = file.Find("autorun/*.lua", "LUA")
		local ClientFolder = file.Find("autorun/client/*.lua", "LUA")

		RunConsoleCommand(cmd, reciever, "*****Displaying users lua folder*****")

		for k, v in pairs(ServerFolder) do

			RunConsoleCommand(cmd, reciever, v)

		end

	for k, v in pairs(ClientFolder) do

		RunConsoleCommand(cmd, reciever, v)

	end

end
usermessage.Hook("VLI", msgViewLua)

function msgGetPropCreator(msg)

	local ent = msg:ReadEntity()
	local cs = msg:ReadString()

	if not ent or not ent:IsValid() then return end

	ent.CS = cs

end
usermessage.Hook("UPCS", msgGetPropCreator)

function msgUpdateUnholsterStatus(msg)

	local bool = msg:ReadBool()
	local ent = msg:ReadEntity()

	if not ent or not ent:IsValid() then return end

	ent.Unholstered = bool

end
usermessage.Hook("UNS", msgUpdateUnholsterStatus)

YouTubeConVar = CreateClientConVar("rp_cl_youtube", "1", true, false)

function msgPlayYouTube(msg)

	local song = msg:ReadString()

	if YouTubeConVar:GetInt() == 1 then

		YouTube = vgui.Create("HTML")
		YouTube:SetPos(0, 0)
		YouTube:SetSize(0, 0)
		YouTube:OpenURL("http://www.youtube.com/watch?v=" .. song .. "&autoplay=1")

	else

		print("YouTube " .. song .. " not played")

	end

end
usermessage.Hook("PYT", msgPlayYouTube)

function msgKillYouTube(msg)

	if YouTube then

		YouTube:Remove()

	end

end
usermessage.Hook("KYT", msgKillYouTube)

function msgToggleTHUD()

	TH.toggleHUD()

end
usermessage.Hook("tthud", msgToggleTHUD)

function msgUpdateUnholsterStatus(msg)

	local bool = msg:ReadBool()
	local wep = msg:ReadEntity()
	local ent = wep.Owner
	if not ent or not ent:IsValid() then return end

	ent.Unholstered = bool
	if wep.SetHolstered then
		wep:SetHolstered(!bool)
	end

end
usermessage.Hook("UNS", msgUpdateUnholsterStatus)