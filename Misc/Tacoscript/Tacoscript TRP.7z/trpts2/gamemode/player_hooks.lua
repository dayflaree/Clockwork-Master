
function GM:PlayerInitialSpawn(ply)


	-- Check for local or global bans
	local row = TS.GlobalSQL:Query("SELECT serverGroup, banStart, banLength, banReason FROM {BANS} WHERE banLifted = 0 AND (banLength = 0 OR banStart + banLength > ?) AND (serverGroup = ? OR serverGroup IS NULL) AND userSteam = ?", os.time(), TS.Config.ServerGroup, ply:SteamID())[1]
	if row then
		ply:Kick(TS.GetKickMessage(tonumber(row.serverGroup), tonumber(row.banStart), tonumber(row.banLength), row.banReason))
		return
	end

	ply.Vars = {}
	for k, v in pairs(PlayerVars) do
		ply.Vars[k] = v
	end

	ply.Limits = {
		balloons	= 0,
		dynamite	= 0,
		effects		= 0,
		hoverballs	= 0,
		lamps		= 0,
		npcs		= 0,
		props		= 10,
		ragdolls	= 0,
		thrusters	= 0,
		vehicles	= 0,
		wheels		= 0,
		turrets		= 0,
		sents		= 0,
		spawners	= 0
	}

	ply:Initialize()

end

local meta = FindMetaTable("Player")

function meta:Initialize()

	self:SetTeam(1)

	--Setup variables
	for k, v in pairs(TS.ServerVariables) do

		if type(TS.ServerVariables[k]) == "table" then

			self[k] = { }

		else

			self[k] = v

		end

	end

	self:Observe(false)
	self:SetupStatProgress()

	self:SetPlayerBleeding(false)
	self:SetPlayerCanSprint(true)
	self:SetPlayerConscious(true)

	self:Lock()
	self:CallEvent("HorseyMapViewOn")

	timer.Simple(.2, function() self:MakeInvisible(true) end)
	timer.Simple(.3, function() self:CrosshairDisable() end)
	timer.Simple(.4, function() self:DrawViewModel(false) end)

	--Delay so that it doesn't fuck up
	timer.Simple(.6, function() self:HandlePlayer() end)

	TS.WriteLog("connects", self:Name() .. " [" .. self:SteamID() .. "][" .. self:IPAddress() .. "] joined the game at " .. tostring(os.date()))

end

function meta:RefreshChar()

	--Inventories
	self.Inventories = { }

	--Just a list of the items in our inventory
	self.InventoryList = { }

	--Serverside inventory grid.  CPU lag?  We'll see.
	self.InventoryGrid = { }

	for n = 1, TS.MaxInventories do

		self.Inventories[n] = { }
		self.Inventories[n].Name = ""
		self.Inventories[n].Width = 9
		self.Inventories[n].Height = 6

		self.InventoryGrid[n] = { }

		for x = 0, 8 do

			self.InventoryGrid[n][x] = { }

			for y = 0, 5 do

				self.InventoryGrid[n][x][y] = { }
				self.InventoryGrid[n][x][y].Filled = false

			end

		end

	end

	for k, v in pairs (self:GetWeapons()) do

		self:StripWeapon(v:GetClass())

	end

	self:CallEvent("ResetInventory")

	self:MakeInvisible(true)

	self:SetTeam(1)
	self:Lock()

	self.Frequency = 0
	self.TerminatorFlags = ""
	self.PlayerFlags = ""

	--Reset stats
	self:SetPlayerStrength(10)
	self:SetPlayerSpeed(10)
	self:SetPlayerEndurance(10)
	self:SetPlayerAim(10)

	self:SetPlayerPrimaryWeapon("")
	self:SetPlayerSecondaryWeapon("")

	self:SetupStatProgress()

	if self.BackEntity and self.BackEntity:IsValid() then
		self.BackEntity:Remove()
	end

end

function meta:CharacterInitialize()

	TS.LightWell:SendAllLights(self)

	if self.ObserveMode then
		self:Observe(false)
	end

	--Inventories
	self.Inventories = { }

	--Just a list of the items in our inventory
	self.InventoryList = { }

	--Serverside inventory grid.  CPU lag?  We'll see.
	self.InventoryGrid = { }

	for n = 1, TS.MaxInventories do

		self.Inventories[n] = { }
		self.Inventories[n].Name = ""
		self.Inventories[n].Width = 9
		self.Inventories[n].Height = 6

		self.InventoryGrid[n] = { }

		for x = 0, 8 do

			self.InventoryGrid[n][x] = { }

			for y = 0, 5 do

				self.InventoryGrid[n][x][y] = { }
				self.InventoryGrid[n][x][y].Filled = false

			end

		end

	end

	self:CallEvent("ResetInventory")

	self:SetHealth(100)
	self.MaxHealth = 100

	self.StatusIsInjured = false
	self.StatusIsCrippled = false
	self.IsTied = false

	self.LastDrunkMulUpdate = 0
	self.LastDrunkWalkUpdate = 0
	self.LastDrunkWalkMul = 0

	self.Frequency = 0
	self.TerminatorFlags = ""
	self.PlayerFlags = ""
	self.PlayerScale = "1.0"

	self:Conscious()

	--Compute player speeds on new character
	self:ComputePlayerSpeeds()

	--Set model
	self:SetModel(self.CitizenModel or "")
	self:SetPlayerSprint(100)
	self:SetPlayerConsciousness(100)
	self:SetPlayerTitle("")
	self:SetPlayerBleeding(false)
	self:SetPlayerCanSprint(true)
	self:SetPlayerConscious(true)

	self:ResetBleeding()
	self:SetupStatProgress()

	self:SetPlayerPrimaryWeapon("")
	self:SetPlayerSecondaryWeapon("")

	self:SetTeam(1)

	--We're initialized and allow the player to move around again
	self.Initialized = true
	self:UnLock()

	self:DrawViewModel(true)

	if self:CharExists(self:GetRPName()) then

		self:CharLoad(self:GetRPName())

	else

		self:CharSave()

	end
	self:KillSilent()
	self:Spawn()

end

function GM:PlayerSpawn(ply)

	if not ply.Initialized then
		ply:SetModel("models/odessa.mdl")
		return
	end

	if ply.PlayerRagdoll then
		ply.PlayerRagdoll:Remove()
		ply.PlayerRagdoll = nil
	end

	if ply.RagdollEntity and ply.RagdollEntity:IsValid() then
		if ply.BypassUnconscious then
			ply:RemoveRagdoll()
			ply.BypassUnconscious = false
		else
			ply:MakeInvisible()
			ply:CrosshairDisable()
			ply:SetPos(ply.RagdollEntity:GetPos())
			ply:Freeze(true)
			return
		end
	end

	if ply:HasInventory("Backpack") then

		ply.BackEntity = ply:AttachProp("models/fallout 3/backpack_2.mdl", "chest")

	end

	if ply:CanBeSkyNet() then
		ply.IsSkynet = true
		ply:SetTeam(2)
	end

	ply:SetPlayerDrunkMul(0)
	ply:CallEvent("NoDrunk")
	ply:MakeNormal()

	ply.IsTied = false
	ply.SlowDownForHit = false
	ply.Footsteps = false
	ply.CanEvent = false
	ply.MaxArmor = 0

	ply:Flashlight(false)

	ply:CrosshairDisable()

	ply.LastWeapon = nil

	ply:ResetBodyDamage()
	ply:ResetBleeding()

	--ply:SetNoCollideWithTeammates(true)

	ply:HandleTeamSpawn()

	ply:SetPlayerSprint(100)
	ply:SetPlayerConsciousness(100)

	if ply:HasTT() then
		ply:Give("gmod_tool")
	end

	ply:Give("weapon_physcannon")

	if not ply:IsPhysBanned() then
		ply:Give("weapon_physgun")
	end

	ply:Give("ts2_hands")

	ply:SelectWeapon("ts2_hands")

	ply:ComputePlayerSpeeds()

end

function GM:PlayerDeathSound()

	return true

end

function GM:CanPlayerSuicide(ply)

	if ply.IsTied or not ply:GetPlayerConscious() then

		return false

	end

	return true

end

function GM:DoPlayerDeath(ply, attacker, dmginfo)

	local makeragdoll = true

	ply.ForceDeath = false

	if not ply.BypassUnconscious then

		if not ply:GetPlayerConscious() then
			ply:TakeAllInventoryWeapons()
			ply:Freeze(false)
			return
		end

	elseif not ply:GetPlayerConscious() then

		ply:Conscious()
		makeragdoll = false

	end

	for k, v in pairs(ply.ProcessBars) do

		if v ~= "spawnload" then

			ply.ProcessBars[k] = nil

		end

	end

	umsg.Start("RAPB", ply); umsg.End()
	umsg.Start("TV", ply); umsg.End()

	if ply:GetActiveWeapon():IsValid() and not ply:IsCP() then

		local Weapon = ply:GetActiveWeapon()

		if (string.find(Weapon:GetClass(), "ts2_") and
			Weapon:GetClass() ~= "ts2_base" and
			Weapon:GetClass() ~= "ts2_hands" and
			Weapon:GetClass() ~= "ts2_kanyewest") then

			local WeaponData = TS.ItemsData[ Weapon:GetClass() ]

			if WeaponData.OnUnequip then
				WeaponData:OnUnequip(ply)
			end

			TS.CreateItemProp(Weapon:GetClass(), ply:GetActiveWeapon():GetPos(), ply:GetActiveWeapon():GetAngles(), Weapon:Clip1())

		end

	end

	if ply.BackEntity and ply.BackEntity:IsValid() then
		ply.BackEntity:Remove()
	end

	if ply.HeadEntity and ply.HeadEntity:IsValid() then
		ply.HeadEntity:Remove()
	end

	ply:TakeAllInventoryWeapons()
	ply:SetPlayerPrimaryWeapon("")
	ply:SetPlayerSecondaryWeapon("")

	ply:SnapOutOfStance()

	ply.HelmetHealth = 0
	ply.BodyArmorHealth = 0
	ply:SetPlayerCurrentArmor(0)

	ply:SetAimAnim(false)

	if makeragdoll then

		ply.PlayerRagdoll = ents.Create("prop_ragdoll")

		local ragdoll = ply.PlayerRagdoll

		ragdoll:SetPos(ply:GetPos())
		ragdoll:SetAngles(ply:GetAngles())
		ragdoll:SetModel(ply.RealModelEnt:GetModel())

		ragdoll:Spawn()

		local c = ragdoll:GetPhysicsObjectCount()

		local vel = ply:GetVelocity() * 2

		for n = 1, c do

			local bone = ragdoll:GetPhysicsObjectNum(n)

			if bone and bone:IsValid() then

				local bonepos, boneang = ply:GetBonePosition(ragdoll:TranslatePhysBoneToBone(n))

				if bonepos && boneang then
					bone:SetPos(bonepos)
					bone:SetAngles(boneang)
				end
				--bone:AddVelocity(vel)

			end

		end
	end

end

 --had to redo this because zybermuffin or w.e his name is fucked it up. GOOD ONE.
function GM:PlayerDeath(victim, weapon, killer)

	--If someones killed someone
	if victim and killer && IsValid(killer) then

		local prefix, suffix

		if victim == killer then

			TS.PrintMessageAll(2, victim:GetRPName() .. " has suicided!")
			return

		end

		if not (IsValid(killer)) then return end

		local weapon = nil

		prefix = victim:GetRPName() .. "(" .. victim:Nick() .. ") was killed by " .. killer:GetClass() .. "."

		if killer:IsPlayer() then
			weapon = killer:GetActiveWeapon()
			prefix = killer:GetRPName() .. "(" .. killer:Nick() .. ")" .. " killed " .. victim:GetRPName() .. "(" .. victim:Nick() .. ") "
		end

		local suffix

		if weapon and weapon:IsValid() then

			suffix = "with " .. weapon.PrintName

		else

			suffix = ""

		end

		TS.PrintMessageAll(2, prefix .. suffix)

	end

end

function GM:PlayerConnect(name, address)

	TS.PrintMessageAll(2, name .. " has connected to the server")

end

function GM:PlayerDisconnected(ply)

	if ply:IsCP() then

		ply:TakeAllInventoryWeapons()

	end

	if ply.RagdollEntity and ply.RagdollEntity:IsValid() then
		ply.RagdollEntity:Remove()
	end

	if ply.Initialized and not ply.CharacterMenu then
		--ply:CharSave(); //error/data loss risk since timers are used in charsaving, can't force people to wait on disconnects
	end

	TS.PrintMessageAll(2, ply:GetRPName() .. " [" .. ply:Nick() .. "][" .. ply:SteamID() .. "] has left the server")

end

function GM:PlayerTraceAttack()

	return false

end

function GM:ScaleNPCDamage(npc, hitgroup, dmginfo)

	if hitgroup == HITGROUP_HEAD then

		dmginfo:SetDamage(-1000)
		return dmginfo

	end

	if dmginfo:GetAttacker():IsValid() and dmginfo:GetAttacker():IsPlayer() and dmginfo:GetAttacker():GetActiveWeapon():IsValid() then

		if CurTime() - dmginfo:GetAttacker().LastAimProgress > .5 then

			dmginfo:GetAttacker():RaiseAimProgress(1)
			dmginfo:GetAttacker().LastAimProgress = CurTime()

		end

	end

	return dmginfo

end

function GM:EntityTakeDamage(ent, dmginfo)

	--[12/15/11] This should've been here.

	if ent:IsPlayer() && dmginfo:IsExplosionDamage() then
		self:ScalePlayerDamage(ent, HITGROUP_GENERIC, dmginfo)
	end

	local attacker = dmginfo:GetAttacker()
	local amount = dmginfo:GetDamage()

	if attacker:IsProp() then

		dmginfo:ScaleDamage(0)

	end

	if (attacker:GetClass() == "worldspawn" ||
		 attacker:GetClass() == "prop_ragdoll" ||
		 attacker:GetClass() == "ts2_item") then

		if dmginfo:GetDamage() > 10 then

			dmginfo:ScaleDamage(0)

		end

	end

end

local function IsPlasmaWeapon(weapon)

	if weapon.Primary then

		if weapon.IsBluePlasma || weapon.IsRedPlasma then

			return true

		end

	end

	return false

end

function GM:ScalePlayerDamage(ply, hitgroup, dmginfo)
	if not ply.Initialized then return end

	if dmginfo:IsFallDamage() and ply:Team() == 3 then return end

	local attacker = dmginfo:GetAttacker()

	if ply.ObserveMode then
		dmginfo:SetDamage(-1000)
		return dmginfo
	end
	--[[
	if ply:HasTerminatorFlag("E") then
		dmginfo:SetDamage(-1000)
		return dmginfo
	end
	]]--
	dmg = dmginfo:GetDamage()
	armor = ply.BodyArmorHealth

	local weapon = dmginfo:GetInflictor()

	if weapon:IsPlayer() or weapon:IsNPC() then
		weapon = weapon:GetActiveWeapon()
	end

	if armor > 0 then

		local dr = ply.DR or 100

		--[[ Get the percentage of DR ]]--
		dr = (dr / 100)

		--[[ Subtract that from 1 to get our true percent. ]]--
		dr = 1 - dr

		if IsPlasmaWeapon(weapon) && ply:Team() == 2 then
			dr = dr / 2
		end

		armor = armor - (dmg - (dmg * dr))

		ply.BodyArmorHealth = armor

		ply:SetPlayerCurrentArmor(armor)

		dmginfo:SetDamage(-1000)

		return dmginfo

	end

	ply:SnapOutOfStance()

	if weapon:IsValid() and weapon:IsWeapon() then

		return ply:ScaleDamageFromAttack(dmginfo:GetInflictor(), weapon, hitgroup, dmginfo)

	end
	if attacker:IsProp() then

		dmginfo:ScaleDamage(0)

	end

	if (attacker:GetClass() == "worldspawn" ||
		 attacker:GetClass() == "prop_ragdoll" ||
		 attacker:GetClass() == "ts2_item") then

		if dmginfo:GetDamage() > 10 then

			dmginfo:ScaleDamage(0)

		end

	end


	return dmginfo

end

function GM:PlayerSwitchFlashlight(ply)

	if CurTime() - ply.LastFlashSwitch < 1 then
		return false
	end

	ply.LastFlashSwitch = CurTime()

	if ply:IsCP() then

		return true

	end

	return ply:HasItem("flashlight")

end

function GM:Move(ply, mv)

	if ply.InStanceAction then

		ply:SetCollisionGroup(COLLISION_GROUP_WORLD)

		return true

	end

	if ply:GetCollisionGroup() ~= COLLISION_GROUP_PLAYER_MOVEMENT then

		ply:SetCollisionGroup(COLLISION_GROUP_PLAYER_MOVEMENT)

	end

end

function GM:PlayerSpray(ply)

	return true

end

function GM:PlayerShouldTakeDamage(victim, attacker)

	if attacker:IsProp() then

		return false

	end

	return true

end

function GM:PlayerFootstep(ply, pos, foot, sound, volume, rf)

	if ply.Footsteps then

		if not ply.InCloak then
			local num = math.random(1, 4)

			ply:EmitSound("npc/dog/dog_footstep" .. num .. ".wav")
			return true

		end

	end

end

function GM:PlayerCanPickupWeapon(ply, ent)

	if ent:IsValid() then

		local class = ent:GetClass()

		if (TS.ItemsData[class] or
			class == "weapon_physgun" or
			class == "gmod_tool" or
			class == "weapon_physcannon") then

			return true

		end

		return false

	end

end

function GM:PlayerShouldTaunt(ply, actid)
	return false
end
