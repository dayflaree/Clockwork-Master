TS.ThirdPerson = {
	Enabled = CreateClientConVar("rp_cl_thirdperson_enabled", "0", true, false),
	Crosshair = CreateClientConVar("rp_cl_thirdperson_crosshair_enabled", "0", true, false),
	OffsetUp = CreateClientConVar("rp_cl_thirdperson_offsetUp", "-4", true, false),
	OffsetRight = CreateClientConVar("rp_cl_thirdperson_offsetRight", "20", true, false),
	OffsetForward = CreateClientConVar("rp_cl_thirdperson_offsetForward", "-40", true, false),
	Color_R = CreateClientConVar("rp_cl_thirdperson_crosshair_r", "255", true, false),
	Color_G = CreateClientConVar("rp_cl_thirdperson_crosshair_g", "255", true, false),
	Color_B = CreateClientConVar("rp_cl_thirdperson_crosshair_b", "255", true, false),
	CrosshairThickness = CreateClientConVar("rp_cl_thirdperson_crosshair_thickness", "2", true, false),
	CrosshairSpread = CreateClientConVar("rp_cl_thirdperson_crosshair_spread", "9", true, false),
	ScaleByDistance = CreateClientConVar("rp_cl_thirdperson_crosshair_spread_scaledistance", "0", true, false),
	ScreenCrosshair = CreateClientConVar("rp_cl_thirdperson_crosshair_2d", "1", true, false),
	CamPos = Vector(),
	DrawSprite = Material("sprites/gmdm_pickups/light")
}

local ThirdPerson = TS.ThirdPerson

function ThirdPerson:GetViewData(ply, raw)
	ply = ply or LocalPlayer()

	local trace = util.QuickTrace(ply:GetShootPos(), ply:GetAimVector() * 2500, ply)

	if not raw then
		return trace.HitPos:ToScreen()
	else
		return trace.HitPos
	end
end

function ThirdPerson:CalcView(view)
	local ply = LocalPlayer()

	if self.Enabled:GetBool() && GetViewEntity() == ply && not SeeSniperScope && not ply:GetNetworkedBool("isDriveJumper", false) then
		view.angles = ply:GetAimVector():Angle()

		local traceData = {
			start = ply:EyePos(),
			filter = ply
		}

		traceData.endpos = traceData.start + view.angles:Forward() * math.Clamp(self.OffsetForward:GetInt(), -100, 100)
		traceData.endpos = traceData.endpos + view.angles:Right() * math.Clamp(self.OffsetRight:GetInt(), -100, 100)
		traceData.endpos = traceData.endpos + view.angles:Up() * math.Clamp(self.OffsetUp:GetInt(), -100, 100)

		local tr = util.TraceLine (traceData)
		view.origin = tr.HitPos

		if tr.Fraction < 1.0 then
			view.origin = view.origin + tr.HitNormal * 5
			--[[
			local alpha = (ply:EyePos():Distance(view.origin) / 25) * 255
			local pColor = Color(255, 255, 255, alpha)

			if ply.RealModelEnt then
				ply.RealModelEnt:SetRenderMode(RENDERMODE_TRANSALPHA)
				ply.RealModelEnt:SetColor(pColor)
			end
			]]--
		end

	end
end

function ThirdPerson:HUDPaint()
	local ply = LocalPlayer()

	if self.Enabled:GetBool() && self.Crosshair:GetBool() && GetViewEntity() == ply && not SeeSniperScope && not ply:GetNetworkedBool("isDriveJumper", false) then

		local Pos = self:GetViewData(ply, true)
		local pos_screen = Pos:ToScreen()
		local scale = self.CrosshairThickness:GetInt()

		surface.SetDrawColor(self.Color_R:GetInt(), self.Color_G:GetInt(), self.Color_B:GetInt(), 255)

		if self.ScreenCrosshair:GetBool() then

			local spread = self.CrosshairSpread:GetInt()

			if self.ScaleByDistance:GetBool() then
				local Distance = LocalPlayer():GetShootPos():Distance(Pos)
				local Dist_Perc = math.Clamp(Distance / 2000, 0, 1)

				spread = spread * (1 - Dist_Perc)
			end

			surface.DrawRect(pos_screen.x - ((scale / 2) - 1), pos_screen.y - ((scale / 2) - 1), scale, scale)

			surface.DrawRect(pos_screen.x - ((scale / 2) - 1), (pos_screen.y + spread) - ((scale / 2) - 1), scale, scale)
			surface.DrawRect(pos_screen.x - ((scale / 2) - 1), (pos_screen.y - spread) - ((scale / 2) - 1), scale, scale)

			surface.DrawRect((pos_screen.x + spread) - ((scale / 2) - 1), pos_screen.y - ((scale / 2) - 1), scale, scale)
			surface.DrawRect((pos_screen.x - spread) - ((scale / 2) - 1), pos_screen.y - ((scale / 2) - 1), scale, scale)
		else
			cam.Start3D(EyePos(), EyeAngles())
				render.SetMaterial(self.DrawSprite)
				render.DrawSprite(Pos, scale * 5, scale * 5, Color(self.Color_R:GetInt(), self.Color_G:GetInt(), self.Color_B:GetInt(), 200))
			cam.End3D()
		end
	end
end

function GM:ShouldDrawLocalPlayer()
	if TS.ThirdPerson.Enabled:GetBool() && not SeeSniperScope then
		return true
	end
end