local function CalcAngles()

	local function f(val)
		return tostring(math.Round(val))
	end

	local pos = LocalPlayer():GetPos()
	local ang = LocalPlayer():GetAngles()

	Msg("TS.MapViews[\"" .. game.GetMap() .. "\"] =\n")
	Msg("{\n")
	Msg("\tpos = Vector(" .. f(pos.x) .. ", " .. f(pos.y) .. ", " .. f(pos.z) .. ");\n")
	Msg("\tang = Angle(" .. f(ang.p) .. ", " .. f(ang.y) .. ", " .. f(ang.r) .. ");\n")
	Msg("}\n")

end
concommand.Add("ca", CalcAngles)

itemviewerrows = 32
itemviewercols = 32

if itemviewer then

	if itemviewer.RemoveTitleBar then
		itemviewer:RemoveTitleBar()
	end

	itemviewer:Remove()

end

itemviewer = nil

function createItemViewer()

	local catas = {}
	local itable = {}

	local name = { }
	name[1] = "x"
	name[2] = "y"
	name[3] = "z"

	local currentclass = ""

	itemviewer = CreateBPanel("Icon Creator", 100, 100, 700, 600)
	itemviewer.mode = 1

	itemviewercols = 1
	itemviewerrows = 1

	itemviewer.fov = 90

	itemviewer.PaintHook = function()

		local x, y = itemviewer:GetPos()

		if itemviewer.mode == 1 then
			draw.RoundedBox(2, 10, 30, itemviewercols, itemviewerrows, Color(0, 0, 200, 100))
		elseif itemviewer.mode == 2 then
			draw.RoundedBox(2, 10, 30, 350, 190, Color(0, 0, 200, 100))
		else
			draw.RoundedBox(2, 10, 30, 200, 200, Color(0, 0, 200, 100))
		end

		itemviewer.modelpath:SetPos(x + 10, y + 150)

	end

	itemviewer.modelpath = vgui.Create("DTree", itemviewer)
	itemviewer.modelpath:SetPos(105, 240)
	itemviewer.modelpath:SetSize(300, 400)
	--itemviewer.modelpath:SetEnterAllowed(true)
	itemviewer.modelpath:MakePopup()



	for k, v in pairs (weapons.GetList()) do

		itable[v.ClassName] = v

		if not catas[v.Category or ""] then

			if not (v.Category == "Counter-Strike" or v.Category == "Half-Life 1") then

			catas[v.Category or ""] = v.Category


			end

		end

	end

	for k, v in pairs (catas) do

		catas[k] = itemviewer.modelpath:AddNode(k)

	end

	for k, v in pairs (weapons.GetList()) do

		if catas[v.Category] then
		local node = catas[v.Category]:AddNode(v.ClassName)
		node.DoClick = function()

				currentclass = v.ClassName

				if string.gsub(v.WorldModel, " ", "") == "" then return end

				if itemviewer.model then
					itemviewer.model:Remove()
				end

				local x, y = itemviewer:GetPos()

				v.IconCamPos = v.IconCamPos or Vector(0, 0, 0)
				v.IconLookAt = v.IconLookAt or Vector(0, 0, 0)

				itemviewer.model = vgui.Create("DModelPanel", itemviewer)
				itemviewer.model:SetPos(x + 10, y + 30)

				itemviewer.model:SetSize(v.ItemWidth * 50, v.ItemHeight * 50)

				itemviewer.model:SetModel(v.WorldModel)
				itemviewer.model:SetAnimated(false)
				itemviewer.model:SetAmbientLight(Color(255, 255, 255))
				itemviewer.model:SetCamPos(v.IconCamPos or Vector(0, 0, 0))
				itemviewer.model:SetLookAt(v.IconLookAt or Vector(0, 0, 0))
				itemviewer.model:SetFOV(v.IconFOV or 90)
				itemviewer.model:SetMouseInputEnabled(false)
				itemviewer.model:MakePopup()

				itemviewercols = v.ItemWidth * 50
				itemviewerrows = v.ItemHeight * 50

				itemviewer.ItemSize[1]:SetValue(v.ItemWidth)
				itemviewer.ItemSize[2]:SetValue(v.ItemHeight)

				for j = 1, 3 do

					itemviewer.ObjectPos[j]:SetValue(v.IconCamPos[name[j]])
					itemviewer.CamPos[j]:SetValue(v.IconLookAt[name[j]])

				end

				itemviewer.Fov:SetValue(v.IconFOV)


				itemviewer.model.LayoutEntity = function(self, ent)

					ent:SetAngles(Angle(0, 0, 0))

				end

			end
		end

	end

	itemviewer.modelpath.OnEnter = function(self)



	end

	itemviewer.ObjectPos = { }

	for j = 1, 3 do

		itemviewer.ObjectPos[j] = vgui.Create("DNumSlider", itemviewer)
		itemviewer.ObjectPos[j]:SetPos(480, 300 + 16 * j)
		itemviewer.ObjectPos[j]:SetSize(200, 16)
		itemviewer.ObjectPos[j]:SetText("Camera Position - " .. name[j])
		itemviewer.ObjectPos[j]:SetMin(-200)
		itemviewer.ObjectPos[j]:SetMax(200)
		itemviewer.ObjectPos[j]:SetDecimals(2)
		itemviewer.ObjectPos[j]:SetValue(50)

		itemviewer.ObjectPos[j].ValueChanged = function(self)

			itemviewer.model:SetCamPos(Vector(itemviewer.ObjectPos[1]:GetValue(),
											 	itemviewer.ObjectPos[2]:GetValue(),
											 	itemviewer.ObjectPos[3]:GetValue()))

			itemviewer.model:MakePopup()

		end

		itemviewer.ObjectPos[j].id = j

	end

	itemviewer.CamPos = { }

	for j = 1, 3 do

		itemviewer.CamPos[j] = vgui.Create("DNumSlider", itemviewer)
		itemviewer.CamPos[j]:SetPos(480, 370 + 16 * j)
		itemviewer.CamPos[j]:SetSize(200, 16)
		itemviewer.CamPos[j]:SetText("Look at Position - " .. name[j])
		itemviewer.CamPos[j]:SetMin(-200)
		itemviewer.CamPos[j]:SetMax(200)
		itemviewer.CamPos[j]:SetDecimals(2)
		itemviewer.CamPos[j]:SetValue(0)

		if j == 3 then
			itemviewer.CamPos[j]:SetValue(40)
		end

		itemviewer.CamPos[j].ValueChanged = function(self)

			itemviewer.model:SetLookAt(Vector(itemviewer.CamPos[1]:GetValue(),
											 	itemviewer.CamPos[2]:GetValue(),
											 	itemviewer.CamPos[3]:GetValue()))

			itemviewer.model:MakePopup()

		end

		itemviewer.CamPos[j].id = j

	end

	itemviewer.ItemSize = { }

	local namez = {
		"Item Width",
		"Item Height"
	}

	for j = 1, 2 do

		itemviewer.ItemSize[j] = vgui.Create("DNumSlider", itemviewer)
		itemviewer.ItemSize[j]:SetPos(480, 440 + 16 * j)
		itemviewer.ItemSize[j]:SetSize(200, 16)
		itemviewer.ItemSize[j]:SetText(namez[j])
		itemviewer.ItemSize[j]:SetMin(1)
		itemviewer.ItemSize[j]:SetMax(9)
		itemviewer.ItemSize[j]:SetDecimals(0)
		itemviewer.ItemSize[j]:SetValue(1)

		itemviewer.ItemSize[j].ValueChanged = function(self)

			itemviewer.model:SetSize(itemviewer.ItemSize[1]:GetValue() * 50, itemviewer.ItemSize[2]:GetValue() * 50)

			itemviewercols = itemviewer.ItemSize[1]:GetValue() * 50
			itemviewerrows = itemviewer.ItemSize[2]:GetValue() * 50

			itemviewer.model:MakePopup()

		end

		itemviewer.CamPos[j].id = j

	end

	itemviewer.Fov = vgui.Create("DNumSlider", itemviewer)
	itemviewer.Fov:SetPos(480, 530)
	itemviewer.Fov:SetSize(200, 16)
	itemviewer.Fov:SetText("FOV")
	itemviewer.Fov:SetMin(1)
	itemviewer.Fov:SetMax(200)
	itemviewer.Fov:SetDecimals(2)
	itemviewer.Fov:SetValue(90)

	itemviewer.Fov.ValueChanged = function(self)
		itemviewer.fov = self:GetValue()
		itemviewer.model:SetFOV(itemviewer.fov)
		itemviewer.model:MakePopup()
	end

	local function output()

		MsgN("**" .. currentclass .. "**")
		Msg("SWEP.IconCamPos = Vector(" ..  itemviewer.ObjectPos[1]:GetValue() .. ", " .. itemviewer.ObjectPos[2]:GetValue() .. ", " .. itemviewer.ObjectPos[3]:GetValue() .. ") \n")
		Msg("SWEP.IconLookAt = Vector(" ..  itemviewer.CamPos[1]:GetValue() .. ", " .. itemviewer.CamPos[2]:GetValue() .. ", " .. itemviewer.CamPos[3]:GetValue() .. ") \n")
		Msg	("SWEP.IconFOV = " .. itemviewer.Fov:GetValue() .. "\n")
		MsgN("********************")

	end

	itemviewer:AddButton("Output Icon Info", 480, 560, output)

end
concommand.Add("itemviewer", createItemViewer)

if animviewer then

	if animviewer.RemoveTitleBar then
		animviewer:RemoveTitleBar()
	end

	animviewer:Remove()
	animviewer = nil

end

function createAnimationViewer()

	LocalPlayer().ForcedAnimationMode = true

	LocalPlayer().ForcedAnimation = 1

	gui.EnableScreenClicker(true)

	animviewer = CreateBPanel("Animation Viewer", 100, 100, 300, 400)
	animviewer.ModelPanel = vgui.Create("DModelPanel", animviewer)

	animviewer.CurrentAnimation = 1

	local doitonce = false

	local animlist = { }

	animviewer.ModelPanel:SetModel("models/Humans/Group01/Male_01.mdl")
	animviewer.ModelPanel:SetCamPos(Vector(50, -31, 44))
	animviewer.ModelPanel:SetLookAt(Vector(0, 4, 37))
	animviewer.ModelPanel:SetFOV(90)
	animviewer.ModelPanel:SetPos(50, 5)
	animviewer.ModelPanel:SetSize(200, 200)
	animviewer.ModelPanel.LayoutEntity = function(self, ent)

		ent:SetAngles(Angle(0, 0, 0))

		ent:ResetSequence(ent:SelectWeightedSequence(animviewer.CurrentAnimation))

		self:SetAnimSpeed(1.0)
		self:RunAnimation()

		if not doitonce and ent and ent:IsValid() then

			animlist = { }

			for n = 1, 3000 do

				if ent:SelectWeightedSequence(n) ~= -1 then

					table.insert(animlist, n)

				end

			end

			doitonce = true

		end

	end

	local animviewermodels =
	{

		"models/Humans/Group01/Male_01.mdl",
		"models/Humans/Group01/Female_01.mdl",
		"models/police.mdl",
		"models/Combine_Super_Soldier.mdl"

	}

	animviewer.ModelSelect = vgui.Create("DComboBox", animviewer)
	animviewer.ModelSelect:SetPos(20, 210)
	animviewer.ModelSelect:SetSize(250, 16)

	for n = 1, #animviewermodels do

		animviewer.ModelSelect:AddChoice(animviewermodels[n])

	end

	animviewer.ModelSelect:ChooseOptionID(1)

	animviewer.ModelSelect.OnSelect = function(self, index, value, data)

		animviewer.ModelPanel:SetModel(value)

		doitonce = false

	end

	animviewer.CurrentAnim = vgui.Create("DTextEntry", animviewer)
	animviewer.CurrentAnim:MakePopup()
	animviewer.CurrentAnim:SetPos(220, 350)
	animviewer.CurrentAnim:SetSize(30, 16)
	animviewer.CurrentAnim:SetText(animviewer.CurrentAnimation)
	animviewer.CurrentAnim:SetKeyboardInputEnabled(true)
	animviewer.CurrentAnim:SetText(animviewer.CurrentAnimation)

	animviewer.CurrentAnim.Think = function()
		local x, y = animviewer:GetPos()
		animviewer.CurrentAnim:SetPos(120 + x, 230 + y)
	end

	animviewer.CurrentAnim.OnEnter = function(self)

		local newanim = tonumber(animviewer.CurrentAnim:GetValue()) or 1

		if newanim < 0 then
			newanim = 1
		end

		animviewer.CurrentAnimation = newanim

		LocalPlayer().ForcedAnimation = newanim

	end

	local function GoRight()

		animviewer.CurrentAnimation = animviewer.CurrentAnimation + 1

		while(not table.HasValue(animlist, animviewer.CurrentAnimation)) do

			animviewer.CurrentAnimation = animviewer.CurrentAnimation + 1

			if animviewer.CurrentAnimation > 3000 then

				animviewer.CurrentAnimation = 1

			end

		end

		LocalPlayer().ForcedAnimation = animviewer.CurrentAnimation

		animviewer.CurrentAnim:SetText(animviewer.CurrentAnimation)

	end

	local function GoLeft()

		animviewer.CurrentAnimation = animviewer.CurrentAnimation - 1

		while(not table.HasValue(animlist, animviewer.CurrentAnimation)) do

			animviewer.CurrentAnimation = animviewer.CurrentAnimation - 1

			if animviewer.CurrentAnimation < 1 then

				animviewer.CurrentAnimation = animlist[#animlist]

			end

		end

		LocalPlayer().ForcedAnimation = animviewer.CurrentAnimation

		animviewer.CurrentAnim:SetText(animviewer.CurrentAnimation)

	end

	animviewer.Left = animviewer:AddButton("<", 95, 227, GoLeft)
	animviewer.Right = animviewer:AddButton(">", 155, 227, GoRight)

end
concommand.Add("animviewer", createAnimationViewer)
