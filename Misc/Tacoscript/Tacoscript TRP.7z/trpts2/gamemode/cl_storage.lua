
if StorageMenu then
	StorageMenu:Remove()
end
StorageMenu = nil

StorageIconGrid = { }
StorageW = 0
StorageH = 0

ChosenStorageItem = { id = "", x = -1, y = -1 }
ClickedItem = { id = "", x = -1, y = -1 }

storage_cell_x = 0
storage_cell_y = 0

function RemoveAllStorageIcons()

	for k, v in pairs(StorageIconGrid) do

		for n, m in pairs(v) do

			if StorageIconGrid[k] && StorageIconGrid[k][n] && StorageIconGrid[k][n]:IsValid() then
				StorageIconGrid[k][n]:Remove()
				StorageIconGrid[k][n] = nil
			end

		end

	end

	StorageIconGrid = nil
	StorageIconGrid = { }

	ChosenStorageItem = { id = "", x = -1, y = -1 }

end

function RemoveStorageButtons()

	if not StorageMenu then return end

	if StorageMenu.TakeButton then
		StorageMenu.TakeButton:Remove()
		StorageMenu.TakeButton = nil
	end

end

function ShowStorageButtons()

	StorageMenu.MenuButtonOptions = DermaMenu()

	ClickedItem.id = ChosenStorageItem.id
	ClickedItem.x = ChosenStorageItem.x
	ClickedItem.y = ChosenStorageItem.y

	local AddButton = function(cmd, func)

		--[[
		local button = InventoryMenu:AddButton(cmd, xoffset, 230, func)
		xoffset = button:GetSize() + xoffset + 5

		return button
		]]--

		StorageMenu.MenuButtonOptions:AddOption(cmd, function()
			func()
			StorageMenu.MenuButtonOptions = nil
		end)

		return nil

	end

	local function take()

		local room = false

		for n = 1, TS.MaxInventories do

			if InventoryList[n].Name ~= "" then

				if FindFreeSpace(n, TS.ItemsData[ClickedItem.id].Width, TS.ItemsData[ClickedItem.id].Height) then

					if string.find(StorageMenu.Flags, "C") then
						RunConsoleCommand("eng_invtakeinvstoritem", StorageItemID, StorageActiveInventory, StorageItemX, StorageItemY, ClickedItem.id, ClickedItem.x, ClickedItem.y)
					else
						RunConsoleCommand("eng_invtakestorageitem", ClickedItem.id, ClickedItem.x, ClickedItem.y)
					end

					room = true
					break

				end

			end

		end

		if not room then

			CreateOkPanel("No room", "No room for item")

		end

	end

	AddButton("Take", take)

	StorageMenu.MenuButtonOptions:Open()

end


function CreateStorageMenu(msg)

	if StorageMenu then
		StorageMenu:Remove()
		StorageMenu = nil
	end

	RemoveAllStorageIcons()
	RemoveStorageButtons()

	if not PlayerMenuVisible then
		TogglePlayerMenu()
	end

	local title = msg:ReadString()
	StorageW = msg:ReadShort()
	StorageH = msg:ReadShort()
	local flags = msg:ReadString()

	StorageMenu = CreateBPanel(title, 10, 10, (StorageW * GRIDWIDTH) + 12, (StorageH * GRIDHEIGHT) + 22)
	StorageMenu:SetBodyColor(Color(20, 20, 20, 100))

	StorageMenu.Flags = flags
	StorageMenu.CanPutInto = true

	StorageMenu.TitleBar:SetPos(ScrW() / 2 - (StorageMenu:GetWide() + 20), ScrH() / 2 - (InventoryMenu:GetTall() / 2))
	StorageMenu:SetPos(ScrW() / 2 - (StorageMenu:GetWide() + 20), ScrH() / 2 - (InventoryMenu:GetTall() / 2) + StorageMenu.TitleBar:GetTall())

	InventoryMenu.TitleBar:SetPos(ScrW() / 2 + 20, ScrH() / 2 - (InventoryMenu:GetTall() / 2))
	InventoryMenu:SetPos(ScrW() / 2 + 20, ScrH() / 2 - (InventoryMenu:GetTall() / 2) + InventoryMenu.TitleBar:GetTall())

	local flagtable = string.ToTable(flags)

	for i = 1, #flagtable do
		local flag = flagtable[i]

		if flag == "C" || flag == "^" then
			StorageMenu.CanPutInto = false
		end
	end

	StorageMenu.OnCursorEntered = function()

		if ChosenStorageItem.id ~= "" then

			ChosenStorageItem = { id = "", x = -1, y = -1 }

		end

	end

	StorageMenu.ContentPanel = CreateBPanel(nil, 5, -5, (StorageW * GRIDWIDTH) + 2, (StorageH * GRIDHEIGHT) + 2)
	StorageMenu.ContentPanel:SetParent(StorageMenu)
	StorageMenu.ContentPanel:SetBodyColor(Color(30, 30, 30, 170))

	StorageMenu.ContentPanel.OnCursorEntered = function()

		if ChosenStorageItem.id ~= "" then

			ChosenStorageItem = { id = "", x = -1, y = -1 }

		end

	end

	function StorageMenu.ContentPanel:Paint()
		local row, col = StorageH - 1, StorageW - 1
		local black, newblack = false, true
		local gridColor = nil

		local mx, my = gui.MousePos()

		local inv_x, inv_y = StorageMenu:GetPos()
		local inv_w, inv_h = StorageMenu:GetSize()

		local con_x, con_y = StorageMenu.ContentPanel:GetPos()

		con_x = con_x + inv_x
		con_y = con_y + inv_y

		for y = 0, row do
			for x = 0, col do
				local point_x, point_y = con_x + x * GRIDWIDTH, con_y + y * GRIDHEIGHT

				local draw_x = x
				local draw_y = y
				local draw_width = GRIDWIDTH
				local draw_height = GRIDHEIGHT

				if MouseInPoints(point_x, point_x + GRIDWIDTH, point_y, point_y + GRIDHEIGHT) then
					storage_cell_x, storage_cell_y = x, y

					if not (ChosenStorageItem.x > -1) then
						gridColor = Color(58, 95, 205, 80)
					end
				else
					if not (MouseXIn (inv_x, inv_x + inv_w) && MouseYIn (inv_y, inv_y + inv_h)) then
						storage_cell_x, storage_cell_y = -1, -1
					end
				end

				if black then
					DrawFilledOutlinedSquare(draw_x * draw_width, draw_y * draw_height, draw_width, draw_height, gridColor or Color(0, 0, 0, 200), Color(0, 0, 0, 255))
				else
					DrawFilledOutlinedSquare(draw_x * draw_width, draw_y * draw_height, draw_width, draw_height, gridColor or Color(30, 30, 30, 0), Color(0, 0, 0, 255))
				end

				gridColor = nil

				black = !black
			end
			black = newblack
			newblack = !newblack
		end

		if ChosenStorageItem.x > -1 then

			local x, y = ChosenStorageItem.x, ChosenStorageItem.y
			local idata = TS.ItemsData[ChosenStorageItem.id]
			local px, py = con_x + x * GRIDWIDTH, con_y + y * GRIDHEIGHT

			draw.RoundedBox(0, x * GRIDWIDTH + 2, y * GRIDHEIGHT + 2, GRIDWIDTH * TS.ItemsData[ChosenStorageItem.id].Width - 1, GRIDHEIGHT * TS.ItemsData[ChosenStorageItem.id].Height - 1, Color(0, 200, 0, 40))

			if not (StorageMenu.MenuButtonOptions && StorageMenu.MenuButtonOptions:IsVisible()) then
				if not (MouseInPoints(px, px + (GRIDWIDTH * idata.Width), py, py + (GRIDHEIGHT * idata.Height))) then
					if ChosenStorageItem.id ~= "" then
						ChosenStorageItem = { id = "", x = -1, y = -1 }
					end
				end
			end
		end

	end

	function StorageMenu:OnClose()
		if StorageMenu then

			StorageMenu:Remove()
			RemoveAllStorageIcons()

		end
		StorageMenu = nil
	end

end
usermessage.Hook("CSM", CreateStorageMenu)

function InsertStorageItem(msg)

	if not StorageMenu then return end

	local item = msg:ReadString()
	local x = msg:ReadShort()
	local y = msg:ReadShort()
	local Amount = msg:ReadShort()

	local data = TS.ItemsData[item]

	if not data then timer.Simple(1, function() InsertStorageItem(msg) end); return end

	local icon = vgui.Create("DModelPanel", StorageMenu.ContentPanel)
	icon:SetModel(data.Model)
	icon:SetPos(x * GRIDWIDTH + 3, y * GRIDHEIGHT + 3)
	icon:SetSize(data.Width * GRIDWIDTH - 3, data.Height * GRIDHEIGHT - 3)
	icon:SetCamPos(data.CamPos)
	icon:SetLookAt(data.LookAt)
	icon:SetFOV(data.Fov)
	icon:SetVisible(true)

	icon.Entity:SetMaterial(data.Material or "")

	icon.LayoutEntity = function(self)


 	end

	local oPaint = icon.Paint

	icon.Paint = function()

		oPaint(icon)

		if StorageIconGrid[x][y].Amount > 1 then

			local w, h = icon:GetSize()
			/* Draws the amount that item has next to it. */
			draw.DrawText(StorageIconGrid[x][y].Amount, "NewChatFont", w - 6, h - 20, Color(255, 255, 255, 220), 2)

		end

	end

	function icon:OnCursorEntered()
		if not (StorageMenu.MenuButtonOptions && StorageMenu.MenuButtonOptions:IsVisible()) then
			ChosenStorageItem = { id = item, x = x, y = y }
		end
	end


	/* For our drag and drop operation. */
 	function icon:OnMousePressed()
		if input.IsMouseDown(MOUSE_RIGHT) then
 			ShowStorageButtons(item)
		end
	end

 	if StorageIconGrid[x] and StorageIconGrid[x][y] then

 		if StorageIconGrid[x][y].IsValid && StorageIconGrid[x][y]:IsValid() then
 			StorageIconGrid[x][y]:Remove()
 		end

 		StorageIconGrid[x][y] = nil

 	end

 	if not StorageIconGrid[x] then
 		StorageIconGrid[x] = { }
 	end

 	StorageIconGrid[x][y] = icon
	StorageIconGrid[x][y].Amount = Amount

	StorageIconGrid[x][y]:SetVisible(true)

	StorageIconGrid[x][y] = icon

end
usermessage.Hook("ISI", InsertStorageItem)

function RemoveStorageItem(msg)
	local x = msg:ReadShort()
	local y = msg:ReadShort()

	if (ChosenStorageItem and
		ChosenStorageItem.x == x and
		ChosenStorageItem.y == y) then

		ChosenStorageItem = { id = "", x = -1, y = -1 }
	end

	if StorageIconGrid[x] and StorageIconGrid[x][y] then

		StorageIconGrid[x][y]:Remove()
		StorageIconGrid[x][y] = nil

	end
end
usermessage.Hook("RSI", RemoveStorageItem)

function NoRoomInStorage()

	CreateOkPanel("No room", "No room for item")

end
usermessage.Hook("NRIS", NoRoomInStorage)