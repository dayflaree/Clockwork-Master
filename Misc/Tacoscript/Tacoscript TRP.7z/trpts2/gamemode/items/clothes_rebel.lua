ITEM.Name = "Rebel Vest"

ITEM.Model = "models/items/item_item_crate.mdl"

ITEM.Flags = "Ws"

ITEM.Width = 4
ITEM.Height = 4

ITEM.Description = ""

ITEM.CamPos = Vector(2, 0, 200)
ITEM.LookAt = Vector(0, 0, 10)
ITEM.FOV = 16

ITEM.Spawnflag = "X"

ITEM.InvName = "Rebel vest"
ITEM.InvWidth = 5
ITEM.InvHeight = 4
ITEM.InvStayWithClothes = true

ITEM.CanRevertToCitizensCloth = true