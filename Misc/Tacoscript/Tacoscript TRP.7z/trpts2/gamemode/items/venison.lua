
ITEM.Name = "Venison"

ITEM.Description = "The meat of a game animal."
ITEM.Model = "models/Gibs/Shield_Scanner_Gib2.mdl"
ITEM.Material = "models/flesh"
ITEM.CamPos = Vector(48, 57, 50)
ITEM.LookAt = Vector(-1, 0, 0)
ITEM.FOV = 13
ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "e"

function ITEM:Use()

	self.Owner:GiveHealth(10)
	self.Owner:SetPlayerSprint(math.Clamp(self.Owner:GetPlayerSprint() + 10, 0, 100))

end