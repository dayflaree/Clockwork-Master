
ITEM.Name = "Smith & Wesson .357 Magnum"

ITEM.Description = "Powerful pistol round for several Light Rifles and Handguns."
ITEM.Model = "models/STALKER/ammo/357.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 7

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120
