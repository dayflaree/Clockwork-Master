ITEM.Name = "HAM Radio"

ITEM.Model = "models/props/terror/hamradio.mdl"

ITEM.Flags = "ra!"

ITEM.Width = 3
ITEM.Height = 3

ITEM.Description = "This radio is On."

ITEM.Frequency = 500
ITEM.IsOn = true
ITEM.IsTransmitting = false
