ITEM.Name = "Storage Container"

ITEM.Model = "models/items/item_item_crate.mdl"

ITEM.Flags = "c!"

ITEM.Width = 4
ITEM.Height = 4

ITEM.Description = "A storage container"

function ITEM:FillContainer()

end
