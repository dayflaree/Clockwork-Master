
ITEM.Name = "Bottled Water"

ITEM.Description = "An old dirty bottle of water.."

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "d@"

ITEM.Amount = 5

function ITEM:Use()

	self.Owner:GiveHealth(5)

end

ITEM.Model = "models/props_junk/garbage_glassbottle003a.mdl"
ITEM.CamPos = Vector(200, -135, 50)
ITEM.LookAt = Vector(0, 0, 0)
ITEM.FOV = 6
