ITEM.Name = "Flashlight"

ITEM.Description = "Light up dark alleyways and fend yourself from rapists with this."

ITEM.Model = "models/raviool/flashlight.mdl"
ITEM.CamPos = Vector(0, -49, 0)
ITEM.LookAt = Vector(-1.2425677063176, 8, 1.1232641002086)
ITEM.FOV = 11.837259938591

ITEM.Width = 2
ITEM.Height = 1


function ITEM:Drop()

	self.Owner:Flashlight(false)

end