
ITEM.Name = "Medkit"

ITEM.Description = "Contains bandages, disinfectant spray, tweezers, plasters and water! This also stops bleeding."
ITEM.Model = "models/STALKER/Item/Medical/medkit1.mdl"

ITEM.CamPos = Vector(65, 19, 44)
ITEM.LookAt = Vector(1, 0, 2)
ITEM.FOV = 11

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "u"

function ITEM:Use()

	self.Owner:GiveHealth(25)
	self.Owner:SetPlayerSprint(math.Clamp(self.Owner:GetPlayerSprint() + 10, 0, 100))

	if 	self.Owner:GetTable().IsBleeding then
		self.Owner:ResetBleeding()
	end

	self.Owner:GetTable().StatusIsInjured = false
	self.Owner:GetTable().StatusIsCrippled = false
	self.Owner:SetPlayerCanSprint(true)

end