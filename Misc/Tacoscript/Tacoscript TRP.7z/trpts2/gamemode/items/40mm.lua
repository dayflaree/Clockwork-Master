ITEM.Name = "40mm Grenade"

ITEM.Description = "Grenade for use in 40mm grenade tubes."

ITEM.Model = "models/items/ar2_grenade.mdl"
ITEM.CamPos = Vector(-89, 80, 62)
ITEM.LookAt = Vector(5, -5, -3)
ITEM.FOV = 5

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"

ITEM.Maximum = 5

ITEM.Spawnflag = "Z"
ITEM.AdminOnly = true

function ITEM:Drop()

end