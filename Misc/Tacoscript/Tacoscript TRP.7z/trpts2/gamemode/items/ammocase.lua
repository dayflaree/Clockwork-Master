ITEM.Name = "Ammo Case"
ITEM.Description = "Oh boy! I wonder what's inside!"

ITEM.Flags = "!c^"
ITEM.Spawnflag = "Z"

ITEM.Model = "models/Items/BoxMRounds.mdl"

ITEM.Width = 2
ITEM.Height = 2

ITEM.InvWidth = 4
ITEM.InvHeight = 4

ITEM.CamPos = Vector (50, 50, 50)
ITEM.LookAt = Vector(-1, 0, 6)
ITEM.FOV = 22

ITEM.GeneratedTypes = {
	[".50BMG"] = 10,
	[".600OK"] = 10,
	["5.45mm"] = 60,
	["5.56mm"] = 60,
	[".30-06"] = 20,
	["7.62mm"] = 40,
	["8gauge"] = 50,
	["9x39mm"] = 30,
	["12gauge"] = 25
}

function ITEM:FillContainer()
	local stack = 0

	if not (self.type) then
		math.randomseed(os.time())

		local hit = math.random(1, table.Count(self.GeneratedTypes))
		local iterator = 0

		self.type = ""

		for k, v in pairs (self.GeneratedTypes) do
			iterator = iterator + 1

			if iterator == hit then
				self.type = k
				stack = v
				break
			end
		end
	else
		stack = self.GeneratedTypes[self.type] or 0
	end

	local iData = TS.ItemsData[self.type]

	for i = 1, (self.InvWidth * self.InvHeight) do
		self:GiveInventoryItem(self.type, stack)
	end
end

function ITEM:RequestDescription()
	local Name = TS.ItemsData[self.type].Name or self.type
	return "A case of ammunition containing " .. self:GetCount() .. " rounds of " .. Name .. "."
end