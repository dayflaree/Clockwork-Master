
ITEM.Name = "Morphine"

ITEM.Description = "This should take away the pain.."
ITEM.Model = "models/STALKER/Item/Medical/medkit2.mdl"

ITEM.CamPos = Vector(65, 19, 44)
ITEM.LookAt = Vector(1, 0, 2)
ITEM.FOV = 11
ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "u"

function ITEM:Use()

	self.Owner:GiveHealth(10)
	self.Owner:SetPlayerSprint(math.Clamp(self.Owner:GetPlayerSprint() + 10, 0, 100))

end