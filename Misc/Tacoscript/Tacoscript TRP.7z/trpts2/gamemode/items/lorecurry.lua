ITEM.Name = "Curry"

ITEM.Description = "A somewhat spicy and delicious curry made when only fresh ingredients are available."

ITEM.Model = "models/dav0r/thruster.mdl"
ITEM.Material = "models/props_c17/metalladder003"

ITEM.CamPos = Vector (50, 50, 50)
ITEM.LookAt = Vector(0, 0, 3.77)
ITEM.FOV = 8.88

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "e@"

ITEM.Amount = 5
ITEM.Maximum = 5

function ITEM:Use()

	self.Owner:GiveHealth(10)

end