ITEM.Name = "Backpack"

ITEM.Model = "models/fallout 3/backpack_2.mdl"

ITEM.Flags = "Ws"

ITEM.Width = 4
ITEM.Height = 4

ITEM.Description = ""

ITEM.InvName = "Backpack"
ITEM.InvWidth = 5
ITEM.InvHeight = 4
ITEM.InvStayWithClothes = true
ITEM.CanRevertToCitizensCloth = true
ITEM.InvCanDrop = true

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, -2, -3)
ITEM.FOV = 16
