ITEM.Name = "Moonshine"
ITEM.Description = "A bottle of homemade spirits. Guaranteed to knock you on your ass."

ITEM.Model = "models/stalker/item/food/vokda.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 5)
ITEM.FOV = 9

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "d@"

ITEM.Amount = 5

function ITEM:Use()

	self.Owner:GiveHealth(20)
	self.Owner:CallEvent("HAlcoholBlur")
	self.Owner:SetPlayerDrunkMul(math.Clamp(self.Owner:GetPlayerDrunkMul() + .25, 0, 1.6))
	self.Owner:GetTable().LastDrunkMulUpdate = CurTime()

end