ITEM.Name = "Cardboard Box"

ITEM.Model = "models/props_junk/cardboard_box002a.mdl"

ITEM.Flags = "c!"

ITEM.Width = 3
ITEM.Height = 3

ITEM.Description = "A cardboard box that can store items."

function ITEM:FillContainer()

end
