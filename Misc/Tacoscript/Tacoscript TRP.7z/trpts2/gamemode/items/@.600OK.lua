
ITEM.Name = ".600 caliber Overkill"

ITEM.Description = "Fucking huge ammo"
ITEM.Model = "models/STALKER/ammo/12x70.mdl"

ITEM.CamPos = Vector(-45, -55, 49)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 6

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 8

ITEM.Spawnflag = "Z"

ITEM.Maximum = 8