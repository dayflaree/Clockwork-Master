
ITEM.Name = "5.56x45mm NATO"

ITEM.Description = "Rifle round originally chambered in the M16 rifle."
ITEM.Model = "models/stalker/ammo/556x45.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 2)
ITEM.FOV = 8


ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120