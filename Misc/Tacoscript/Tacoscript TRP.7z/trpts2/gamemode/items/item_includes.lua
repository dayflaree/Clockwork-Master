
--ITEM FLAGS--
--Quick ref!--
-- e - edible
-- d - drinkable
-- p - paper item / can write on
-- l - letter item / can read
-- u - can use
-- c - Is a container
-- ! - can not put in inventory
-- s - Item can only be placed in storage like briefcases or backpacks
-- C - Is a container, but not storage (you cannot put things into it, only take out). Can put in inventory.
-- W - Wearable.  Can contain its own inventory.
-- w - Weapon.  Don't use this.
-- @ - Can use some of this item.
-- t - Tuneable (RADIO ONLY).
-- a - Ammunition
-- P - Plasma Ammunition
-- ^ - Items can't be put into this container, only taken.
-- < - Useable only in the world.
-- > - Equiptable

/* 1/2/12 */
-- ra - Tuneable Radio Entity

function TS.HandleItemSpawning(DATA)

	if not type(DATA) == "table" then

		return

	end

	if not TS.ProcessedItems then

		TS.ProcessedItems = { }

	end

	local bi = {

		"clothes_storage",
		"clothes_citizen",
		"clothes_rebel",
		"clothes_rebelmedic",
		"skynetdevice",
		"clothes_developer"

	}

	if not table.HasValue(bi, DATA.ID) then

		table.insert(TS.ProcessedItems, DATA)

	end

	DATA = nil

end

function TS.IncludeItem(dir)

	ITEM = nil
	ITEM = { }

	include(dir)

	local id = string.gsub(dir, ".lua", "")

	id = string.gsub(id, "@", "")

	print(id)

	ITEM.ID 			= id
	ITEM.Flags 			= ITEM.Flags or ""
	ITEM.UseDelay 		= ITEM.UseDelay or 1
	ITEM.PickupDelay 	= ITEM.PickupDelay or .7
	ITEM.Amount			= ITEM.Amount or 1
	ITEM.Maximum 		= ITEM.Maximum or 1
	ITEM.SkynetOnly 	= ITEM.SkynetOnly or false
	ITEM.Spawnflag 		= ITEM.Spawnflag or "Y"
	ITEM.AdminOnly		= ITEM.AdminOnly or false
	ITEM.Material 		= ITEM.Material or ""

	ITEM.Drop 			= ITEM.Drop or function() end
	ITEM.Use 			= ITEM.Use or function() end

	--PrintTable(ITEM)

	if string.find(ITEM.Flags, "P") || string.find(ITEM.Flags, "a") then
		ITEM.AmmoType = ITEM.ID
	end

	/* Because I need this added for my entity. */
	ITEM.Draw = ITEM.Draw or function() end

	ITEM.IsContainer = function(self)

		if (string.find(self.Flags, "c") or
			string.find(self.Flags, "C") or
			string.find(self.Flags, "W")) then

			return true

		end

		return false

	end

	ITEM.CanDrop = function(self)

		return true

	end

	TS.ItemsData[id] = ITEM

	TS.HandleItemSpawning(ITEM)

end

local items = file.Find("Tacoscript2TRP/gamemode/items/*.lua", "LUA")

for files, directories in pairs(items) do

	local directories = string.Explode("\n", directories)

	for i = 1, #directories do

		local file = directories[i]

		if (file ~= "item_includes.lua" and
			file ~= "item_interaction.lua") then

			TS.IncludeItem(file)

		end
	end

end

TS.FormatedWeaponsToItems = false
TS.WeaponGivingDelay = true