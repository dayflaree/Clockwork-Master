ITEM.Name = "Firehawks Vest"

ITEM.Model = "models/items/item_item_crate.mdl"

ITEM.Flags = "Ws"

ITEM.Width = 4
ITEM.Height = 4

ITEM.Description = "I'm special"

ITEM.CamPos = Vector(2, 0, 200)
ITEM.LookAt = Vector(0, 0, 10)
ITEM.FOV = 16

ITEM.Spawnflag = "X"

ITEM.AdminOnly = true

ITEM.InvName = "Firehawks Vest"
ITEM.InvWidth = 9
ITEM.InvHeight = 6
ITEM.InvStayWithClothes = true

ITEM.CanRevertToCitizensCloth = true

function ITEM:OnWearItem(ply)

	if not table.HasValue(CoolPeople, ply:SteamID()) then


		ply:SetPlayerDrunkMul(math.Clamp(1.59, 0, 1.6))
		ply:GetTable().LastDrunkMulUpdate = CurTime()
		ply:ConCommand("say", "Woah...I'm not feeling so good...")

	end

end

function ITEM:OnDrop(ply)

	if not table.HasValue(CoolPeople, ply:SteamID()) then

		ply:CallEvent("NoDrunk")
		ply:SetPlayerDrunkMul(0)
		ply:GetTable().LastDrunkMulUpdate = CurTime()
		ply:ConCommand("say", "Okay, I'm feeling better now...")

	end

end