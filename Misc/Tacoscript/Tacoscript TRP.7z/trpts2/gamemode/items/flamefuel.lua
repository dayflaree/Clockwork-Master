ITEM.Name = "Flamethrower Fuel"

ITEM.Description = "Gasoline for the flamethrower."
ITEM.Model = "models/props_junk/PropaneCanister001a.mdl"

ITEM.CamPos = Vector(7, 18, 2)
ITEM.LookAt = Vector(-11, -25, -3)
ITEM.FOV = 92


ITEM.Weight = 0.5
ITEM.Amount = 10000

ITEM.Width = 2
ITEM.Height = 2

ITEM.Flags = "a"

ITEM.Spawnflag = "Z"

ITEM.Maximum = 10000