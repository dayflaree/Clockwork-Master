
ITEM.Name = "Laptop"

ITEM.Model = "models/nt/props_tech/monitor_ghostcase.mdl"
ITEM.Description = "Valuable Tech Equipment"

ITEM.Width = 2
ITEM.Height = 2

ITEM.CamPos = Vector(50, 38, 20)
ITEM.LookAt = Vector(0, 0, 0)
ITEM.FOV = 28
