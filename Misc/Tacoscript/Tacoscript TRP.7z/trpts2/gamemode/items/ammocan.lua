ITEM.Name = "Ammo Can"
ITEM.Description = "Oh boy! I wonder what's inside!"

ITEM.Model = "models/Items/BoxSRounds.mdl"

ITEM.Flags = "!c^"
ITEM.Spawnflag = "Z"

ITEM.Width = 2
ITEM.Height = 1

ITEM.InvWidth = 4
ITEM.InvHeight = 2

ITEM.CamPos = Vector (191, -10, -11)
ITEM.LookAt = Vector(-2, 0, 6)
ITEM.FOV = 5

ITEM.GeneratedTypes = {
	[".44"] = 20,
	[".45ACP"] = 30,
	[".50AE"] = 15,
	[".357"] = 20,
	["4.6x30mm"] = 30,
	["5.7x28mm"] = 30,
	["9x19mm"] = 60
}

function ITEM:FillContainer()
	local stack = 0

	if not (self.type) then
		math.randomseed(os.time())

		local hit = math.random(1, table.Count(self.GeneratedTypes))
		local iterator = 0

		self.type = ""

		for k, v in pairs (self.GeneratedTypes) do
			iterator = iterator + 1

			if iterator == hit then
				self.type = k
				stack = v
				break
			end
		end
	else
		stack = self.GeneratedTypes[self.type] or 0
	end

	local iData = TS.ItemsData[self.type]

	for i = 1, (self.InvWidth * self.InvHeight) do
		self:GiveInventoryItem(self.type, stack)
	end
end

function ITEM:RequestDescription()
	local Name = TS.ItemsData[self.type].Name or self.type
	return "A case of ammunition containing " .. self:GetCount() .. " rounds of " .. Name .. "."
end