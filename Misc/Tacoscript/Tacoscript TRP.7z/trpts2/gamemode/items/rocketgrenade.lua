ITEM.Name = "Rocket Grenade"

ITEM.Description = ""

ITEM.Model = "models/weapons/w_missile_closed.mdl"
ITEM.CamPos = Vector(0, -49, 0)
ITEM.LookAt = Vector(0, 8, -0.30209094121359)
ITEM.FOV = 37.258109196605

ITEM.Width = 2
ITEM.Height = 1

ITEM.Flags = "a"

ITEM.Maximum = 3

ITEM.Spawnflag = "Z"
ITEM.AdminOnly = true

function ITEM:Drop()

end