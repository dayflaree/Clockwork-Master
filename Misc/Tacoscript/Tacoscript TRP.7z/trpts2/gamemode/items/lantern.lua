
ITEM.Name = "Electric Lantern"

ITEM.Description = ""
ITEM.Model = "models/maxofs2d/light_tubular.mdl"

ITEM.CamPos = Vector(51.39, 50, 50)
ITEM.LookAt = Vector(-0.08, 0, 9.74)

ITEM.FOV = 19.2

ITEM.Width = 2
ITEM.Height = 2

ITEM.Flags = "<>"
ITEM.Amount = 1

ITEM.Spawnflag = "Y"
ITEM.AdminOnly = false

ITEM.Enabled = true
ITEM.UseString = "Turn On"
ITEM.ProgressName = "Turning on light..."

ITEM.NonConsumable = true

ITEM.UseStrings = {
	[false] = {"Turn On", "Turning on light..."},
	[true] = {"Turn Off", "Turning off light..."}
}

ITEM.UseDelay = 0.5
ITEM.ThinkDelay = 0.1

ITEM.Maximum = 1

function ITEM:PostProcess( )
	self:DoUpdate()
end

function ITEM:Use( )
	self.Enabled = !self.Enabled

	self:DoUpdate( )
end

function ITEM:DoUpdate()
	self.UseString = self.UseStrings[self.Enabled][1]
	self.ProgressName = self.UseStrings[self.Enabled][2]

	if self.Enabled then
		TS.LightWell:BindLight( self.Entity, 1, Color(96, 61, 35), 0, 512, 1)
		self.Entity:EmitSound("buttons/lightswitch2.wav", 50, 100)
	else
		TS.LightWell:RemoveLight( self.Entity )
		self.Entity:EmitSound("buttons/lightswitch2.wav", 50, 100)
	end
end

function ITEM:OnEquip( owner )
	TS.LightWell:BindLight( owner, 1, Color(96, 61, 35), 0, 1024, 1 )
end

function ITEM:OnUnequip( owner )
	TS.LightWell:RemoveLight( owner )
end