
ITEM.Name = ".45 Automatic Colt Pistol"

ITEM.Description = "A low velocity pistol round combining both Accuracy and Stopping Power against human targets."
ITEM.Model = "models/STALKER/ammo/45cal.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 5

ITEM.FOV = 12

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120