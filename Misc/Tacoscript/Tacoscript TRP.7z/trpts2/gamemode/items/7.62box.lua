
ITEM.Name = "7.62mm Box Magazine"

ITEM.Description = " 7.62x54mm belts for use in heavy machine guns."
ITEM.Model = "models/STALKER/ammo/pkm.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 7

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 100

ITEM.Spawnflag = "Z"

ITEM.Maximum = 400