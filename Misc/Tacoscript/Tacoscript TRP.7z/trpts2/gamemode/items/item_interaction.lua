/* This is a better idea. */

TS.WorldRadios = {}

function TS.IsContainer(ent)
	if not (IsValid(ent) && ent.ItemData) then return false end

	local Flags = ent.ItemData.Flags

	if Flags && (string.find(Flags, "c") or string.find(Flags, "C") or string.find(Flags, "W")) then
		return true
	end

	return false
end

function TS.CreateItemProp(item, pos, ang, amount, tr)
	if not item || not pos then
		return
	end

	if type(item) == "string" then
		item = TS.ItemsData[item]

		if amount then
			amount = math.Clamp(amount, 0, item.Maximum)
		end
	else
		local itemdata = table.Copy(TS.ItemsData[item.ID])

		if itemdata then
			for k, v in pairs (item) do
				itemdata[k] = item[k]
			end

			item = itemdata
		end
		amount = nil
	end

	local ent = ents.Create("ts2_item")
	ent:AttachItem(item)

	if tr then
		pos = tr.HitPos - tr.HitNormal * ent:OBBMins().z
	end

	ent:SetPos(pos)
	ent:SetAngles(ang or Angle(0, 0, 0))
	ent:Spawn()

	if item.Material then
		ent:SetMaterial(item.Material)
	end

	if TS.IsContainer(ent) then

		TS.ItemToContainer(ent.ItemData)

		if ent.ItemData.FillContainer then
			ent.ItemData:FillContainer()
		end

	end

	if item.Flags and (string.find(item.Flags, "ra")) then

		table.insert(TS.WorldRadios, ent)

	end

	if ent.ItemData.PostProcess then
		ent.ItemData:PostProcess()
	end

	if amount then
		ent.ItemData.Amount = amount or item.Amount or 0
	end

	return ent

end
function TS.GenerateItemCrate(itemid, min_stack, max_stack, count, tr)

	local item = TS.ItemsData[itemid]

	if not (item or tr) then
		return
	end

	local pos, ang, Container = Vector(), Angle(), nil

	local ent = Entity()

	--Are we using a new crate or modifying an old one?
	if tr.Entity:GetClass() == "ts2_item" && TS.IsContainer(tr.Entity) then
		ent = tr.Entity
		Container = ent:GetTable().ItemData
	else
		ent = ents.Create("ts2_item")
		ent:AttachItem("storagebox")

		Container = ent:GetTable().ItemData

		pos = tr.HitPos - tr.HitNormal * ent:OBBMins().z

		ent:SetPos(pos)
		ent:SetAngles(ang)
		ent:Spawn()

		TS.ItemToContainer(Container)
	end

	for i = 1, count do
		math.randomseed(os.time())
		local Amount = math.Clamp(math.floor(math.random(min_stack, max_stack)), 1, itemid.Maximum)

		Container:GiveInventoryItem(itemid, Amount)
	end

end
