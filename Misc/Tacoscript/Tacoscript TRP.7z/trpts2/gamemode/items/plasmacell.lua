
ITEM.Name = "Plasma Cell"

ITEM.Description = ""
ITEM.Model = "models/Items/battery.mdl"

ITEM.CamPos = Vector(50, 78, 90)
ITEM.LookAt = Vector(0, 0, 0)

ITEM.FOV = 12

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "P"
ITEM.Amount = 30000

ITEM.Spawnflag = "Z"
ITEM.AdminOnly = true

ITEM.Maximum = 120000