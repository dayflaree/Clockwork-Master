



ITEM.Name = "Sheet of paper"

ITEM.Description = "A sheet of paper!"
ITEM.Model = "models/props_c17/paper01.mdl"


ITEM.CamPos = Vector(50, -5, 70)
ITEM.LookAt = Vector(3, -1, 5)
ITEM.FOV = 23


ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "p"

function ITEM:Use()



end