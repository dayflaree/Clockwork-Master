
ITEM.Name = "FN 5.7x28mm"

ITEM.Description = "Modern AP round developed for the new generation of PDWs."
ITEM.Model = "models/STALKER/ammo/762x39.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 7

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120