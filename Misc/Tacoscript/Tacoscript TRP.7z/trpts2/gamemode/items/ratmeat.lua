
ITEM.Name = "Rat Meat"

ITEM.Description = "Looks raw so I'll need to cook this first, I wounder if it'll taste like beef."
ITEM.Model = "models/STALKER/Item/food/sausage.mdl"
ITEM.CamPos = Vector(50, 16, 27)
ITEM.LookAt = Vector(-25, -9, -13)
ITEM.FOV = 11
ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "e"

function ITEM:Use()

	self.Owner:GiveHealth(14)
	self.Owner:SetPlayerSprint(math.Clamp(self.Owner:GetPlayerSprint() + 12, 0, 100))

end