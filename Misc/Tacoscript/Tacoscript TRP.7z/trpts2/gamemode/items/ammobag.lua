ITEM.Name = "Ammo Pouch"
ITEM.Description = "A small pouch fitted to carry various ammuniton types."

ITEM.Model = "models/props_junk/garbage_bag001a.mdl"
ITEM.Material = "models/gibs/woodgibs/woodgibs02"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, -2, -3)
ITEM.FOV = 16

ITEM.Flags = "Ws"

ITEM.Width = 4
ITEM.Height	= 4

ITEM.InvName = "Ammo Pouch"

ITEM.InvWidth = 4
ITEM.InvHeight = 4

ITEM.CanRevertToCitizensCloth = true
ITEM.InvStayWithClothes = true
ITEM.NotClothing = true

ITEM.InvTypeFlags = "aP"

ITEM.AdminOnly	= true

