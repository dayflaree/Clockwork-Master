
ITEM.Name = "9x39mm SPP"

ITEM.Description = "Russian subsonic assault rifle cartridge."
ITEM.Model = "models/stalker/ammo/9x39.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 2)
ITEM.FOV = 8

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120