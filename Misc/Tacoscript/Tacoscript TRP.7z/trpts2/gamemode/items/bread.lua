ITEM.Name = "Bread"
ITEM.Description = "A small roll of bread."

ITEM.Model = "models/stalker/item/food/bread.mdl"

ITEM.CamPos = Vector(62, 66, 50)
ITEM.LookAt = Vector(-1, 0, -1)
ITEM.FOV = 6

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "e"

function ITEM:Use()

	self.Owner:GiveHealth(20)

end