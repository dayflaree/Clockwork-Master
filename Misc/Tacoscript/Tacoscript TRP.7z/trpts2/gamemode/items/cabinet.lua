ITEM.Name = "Cabinet"

ITEM.Model = "models/props_wasteland/controlroom_storagecloset001b.mdl"

ITEM.Flags = "c!"

ITEM.Width = 7
ITEM.Height = 6

ITEM.Description = "A cabinet for storing things"

function ITEM:FillContainer()

end
