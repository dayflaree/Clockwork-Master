
ITEM.Name = "SkyNet Communication Device"

ITEM.Model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.Description = "Communicate with SkyNet through this"

ITEM.Width = 1
ITEM.Height = 1

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, -1)
ITEM.FOV = 10

