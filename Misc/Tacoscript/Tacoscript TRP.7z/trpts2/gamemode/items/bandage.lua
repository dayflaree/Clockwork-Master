
ITEM.Name = "Bandage Roll"

ITEM.Description = "A bandage roll, this can help stop bleeding"

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "u"

function ITEM:Use()

	self.Owner:SetPlayerSprint(self.Owner:GetPlayerEndurance())

	if 	self.Owner:GetTable().IsBleeding then
		self.Owner:ResetBleeding()
	end

	self.Owner:GetTable().StatusIsInjured = false
	self.Owner:GetTable().StatusIsCrippled = false
	self.Owner:SetPlayerCanSprint(true)

end

ITEM.Model = "models/STALKER/Item/Medical/bandage.mdl"

ITEM.CamPos = Vector(28, 47, 26)
ITEM.LookAt = Vector(-1, 0, 1)
ITEM.FOV = 9
