ITEM.Name = "8 Gauge Buckshot"

ITEM.Description = "Heavy shotgun gauge."
ITEM.Model = "models/STALKER/ammo/12x70.mdl"

ITEM.CamPos = Vector(-45, -55, 49)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 6

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120