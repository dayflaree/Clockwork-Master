
ITEM.Name = "9x19mm Parabellum"

ITEM.Description = "Standard pistol round."
ITEM.Model = "models/STALKER/ammo/9x19.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 5

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120