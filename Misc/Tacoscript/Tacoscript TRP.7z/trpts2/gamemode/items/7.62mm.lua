
ITEM.Name = "7.62mm"

ITEM.Description = "Russian Civilian/Military issue round."
ITEM.Model = "models/STALKER/ammo/762x39.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 7

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120
