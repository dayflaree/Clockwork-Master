
ITEM.Name = "Glowstick (Green)"

ITEM.Description = ""
ITEM.Model = "models/props_c17/TrapPropeller_Lever.mdl"
ITEM.Material = "models/props_c17/frostedglass_01a"

ITEM.CamPos = Vector(67, 50, 50)
ITEM.LookAt = Vector(-1, 0, -1)
ITEM.FOV = 9

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = ">"
ITEM.Amount = 1

ITEM.Spawnflag = "Y"
ITEM.AdminOnly = false

ITEM.Maximum = 5

function ITEM:PostProcess()
	TS.LightWell:BindLight(self.Entity, 1, Color(67, 255, 0), 0, 128, 1, 1)
end

function ITEM:OnEquip(owner)
	TS.LightWell:BindLight(owner, 1, Color(67, 255, 0), 0, 128, 1, 1)
end

function ITEM:OnUnequip(owner)
	TS.LightWell:RemoveLight(owner)
end