
ITEM.Name = ".50 Browning Machine Gun"

ITEM.Description = "High caliber round designed for use in the Browning Machine Gun."
ITEM.Model = "models/STALKER/ammo/50cal.mdl"

ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAt = Vector(0, 0, 1)
ITEM.FOV = 7

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "a"
ITEM.Amount = 30

ITEM.Spawnflag = "Z"

ITEM.Maximum = 120