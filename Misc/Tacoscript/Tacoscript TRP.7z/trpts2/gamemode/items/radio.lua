
ITEM.Name = "Radio"


ITEM.Description = "Send transmissions back and forth or listen in with this"

ITEM.Width = 1
ITEM.Height = 1

ITEM.Flags = "t["

ITEM.Spawnflag = "X"

ITEM.Model = "models/stalker/item/handhelds/radio.mdl"
ITEM.CamPos = Vector(-1, 57, 83)
ITEM.LookAt = Vector(0, -3, 2)
ITEM.FOV = 6

ITEM.Maximum = 1
ITEM.Amount = 1

ITEM.AdminOnly = true

function ITEM:OnReciveRadioMessage(msg)

end

function ITEM:OnSendRadioMessage(msg)

end