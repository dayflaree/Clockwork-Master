ITEM.Name = "Citizen Clothing"

ITEM.Model = "models/items/item_item_crate.mdl"

ITEM.Flags = "Ws"

ITEM.Width = 4
ITEM.Height = 4

ITEM.Description = ""

ITEM.InvName = "Pockets"
ITEM.InvWidth = 2
ITEM.InvHeight = 3
ITEM.InvStayWithClothes = false
ITEM.InvCanDrop = false

ITEM.Spawnflag = "X"

ITEM.CamPos = Vector(2, 0, 200)
ITEM.LookAt = Vector(0, 0, 10)
ITEM.FOV = 16