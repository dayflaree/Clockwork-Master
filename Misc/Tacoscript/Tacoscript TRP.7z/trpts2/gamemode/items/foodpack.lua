
ITEM.Name = "Food Package"

ITEM.Model = "models/weapons/w_package.mdl"

ITEM.Flags = "C"

ITEM.Width = 2
ITEM.Height = 2

ITEM.Description = "A Tech-Comm issued food package containing all of your daily nutritious needs."

ITEM.InvWidth = 2
ITEM.InvHeight = 2

ITEM.CamPos = Vector(84, 7, 150)
ITEM.LookAt = Vector(-99, -23, -200)
ITEM.FOV = 8

function ITEM:FillContainer()

	self:GiveInventoryItem("water")
	self:GiveInventoryItem("ratmeat")
	self:GiveInventoryItem("cannedbeans")

end
