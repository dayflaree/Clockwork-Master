TS.LightWell = {}

local LightWell = TS.LightWell

LightWell.Lights = {}

function LightWell:BindLight(ent, lifetime, c, t, size, perma, brightness)
	if SERVER then
		timer.Simple(0.2, function()
			umsg.Start("_bl")
				umsg.Short(lifetime)
				umsg.Vector(Vector(c.r, c.g, c.b))
				umsg.Short(t)
				umsg.Short(size)
				umsg.Entity(ent)
				umsg.Short(perma or 0)
				umsg.Short(brightness)
			umsg.End()
		end)
		self.Lights[ent] = { lifetime + CurTime(), c, t, size, perma, brightness }
		return true
	else
		local Light = EffectData()
			Light:SetMagnitude(lifetime)
			Light:SetOrigin(Vector(c.r, c.g, c.b))
			Light:SetScale(size)
			Light:SetRadius(t)
			Light:SetNormal(Vector(perma, brightness, 0))
			Light:SetEntity(ent)
		util.Effect("lw_light", Light)
		return true
	end
end

if SERVER then
	//Eww.
	function LightWell:ReturnCleanLightTable()
		local tab = {}
		for k, v in pairs (self.Lights) do
			local index = k:EntIndex()
			tab[index] = {}
			tab[index][1] = v[1] - CurTime()
			tab[index][2] = v[2]
			tab[index][3] = v[3]
			tab[index][4] = v[4]
			tab[index][5] = v[5] or 0
			tab[index][6] = v[6]
		end
		return tab
	end

	function LightWell:SendAllLights(ply)
		//datastream.StreamToClients(ply, "LightWell::ApplyLights", self:ReturnCleanLightTable())

		net.Start("LightWell::ApplyLights")
			net.WriteTable(self:ReturnCleanLightTable())
		net.Send(ply)
	end

	function LightWell:EntRemoved(ent)
		if self.Lights[ent] then
			umsg.Start("_rfq")
				umsg.Short(ent:EntIndex())
			umsg.End()

			umsg.Start("_rfl")
				umsg.Short(ent:EntIndex())
			umsg.End()
		end
	end

	function LightWell:RemoveLight(ent)
		umsg.Start("_rfl")
			umsg.Short(ent:EntIndex())
		umsg.End()
	end

else
	LightWell.QueuedLights = {}

	function LightWell:ApplyLights(data)
		for k, v in pairs (data) do
			local ent = Entity(k)
			if IsValid(ent) then
				self:BindLight(ent, v[1], v[2], v[3], v[4], v[5])
			else
				--Lets think wishfully for a second. If it arrives and it's not there, let's wait until it shows up.
				self.QueuedLights[k] = table.Copy(data[k])
			end
		end
		return true
	end

	function LightWell:LightQueue(ent)
		local LightData = self.QueuedLights[ent:EntIndex()]

		if LightData then
			self:BindLight(ent, LightData[1], LightData[2], LightData[3], LightData[4], LightData[5])
			self.QueuedLights[ent:EntIndex()] = nil
		end
	end

	function LightWell:RemoveFromQueue(id)
		self.QueuedLights[id] = nil
	end

	function LightWell:RemoveFromLights(ent)
		for k, v in pairs (self.Lights) do
			if v[4] == ent then

			v[2]:Remove()
			self.Lights[k] = nil
			end
		end
	end

	function GM:OnEntityCreated(ent)
		LightWell:LightQueue(ent)
	end

	function LightWell:Think()
		for k, v in pairs (self.Lights) do
			if v[1] - CurTime() <= 0 && not v[3] then
				v[2]:Remove()
				self.Lights[k] = nil
			end
		end
	end

	net.Receive("LightWell::ApplyLights", function(len)
		LightWell:ApplyLights(net.ReadTable())
	end)

	usermessage.Hook("_bl", function(data)
		local lifetime = data:ReadShort()
		local c = data:ReadVector()
		local t = data:ReadShort()
		local size = data:ReadShort()
		local ent = data:ReadEntity()
		local perma = data:ReadShort()
		local brightness = data:ReadShort()

		LightWell:BindLight(ent, lifetime, c, t, size, perma, brightness)
	end)

	usermessage.Hook("_rfq", function(data)
		local LightEntity = data:ReadShort()

		LightWell:RemoveFromQueue(LightEntity)
	end)

	usermessage.Hook("_rfl", function(data)
		local LightEntity = data:ReadShort()

		LightWell:RemoveFromLights(LightEntity)
	end)

end