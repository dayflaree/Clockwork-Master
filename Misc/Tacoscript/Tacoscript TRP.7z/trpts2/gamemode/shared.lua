TS = { }

team.SetUp(1, "Survivors", Color(0, 120, 0, 255))
team.SetUp(2, "SkyNet", Color(102, 127, 255, 255))

TS.MapViews = { }
TS.SpawnLocations = {}

TS.MapViews["rp_salvation"] =
{
	pos = Vector(-718, -1402, 274),
	ang = Angle(-18, 143, 0)
}

TS.MapViews["rp_cscdesert_v2-1_propfix"] =
{
	pos = Vector(4482, -8698, 343),
	ang = Angle(-15, -8, 0)
}

TS.MapViews["rp_salvation_night"] =
{
	pos = Vector(67, 4529, 135),
	ang = Angle(-13, 90, 0)
}

TS.MapViews["rp_salvation_2"] =
{
	pos = Vector(2154, 442, 648),
	ang = Angle(-21, 24, 0)
}

TS.MapViews["rp_salvation_2_night"] =
{
	pos = Vector(2154, 442, 648),
	ang = Angle(-21, 24, 0)
}

TS.MapViews["rp_destroyedcity_final"] =
{
	pos = Vector(1914, -12304, 366),
	ang = Angle(33, 34, 0)
}

TS.MapViews["gm_atomic"] =
{
	pos = Vector(-12090, -4090, -10916),
	ang = Angle(-26, -132, 0)
}

TS.MapViews["rp_city8_canals"] =
{
	pos = Vector(1127, -5069, 161),
	ang = Angle(12, 31, 0)
}

TS.MapViews["md_stalkerredux_b4"] =
{
	pos = Vector(1170, -316, 599),
	ang = Angle(33, -77, 0)
}

TS.MapViews["rp_apocalypse"] =
{
	pos = Vector(-224, 8810, 780),
	ang = Angle(-13, 128, 0)
}

/*, Spawn, Locations, */

/*, =====================================================================, */

TS.SpawnLocations["rp_cscdesert_v2-1_propfix"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(1.651, -1.582, 0.000),
						pos	=	Vector(	1439.4994, -9035.3184, 0.0313)},
				[2] = {
						ang	=	Angle(1.651, -1.582, 0.000),
						pos	=	Vector(	1441.5565, -8960.8311, 0.0313)},
				[3] = {
						ang	=	Angle(1.651, -1.582, 0.000),
						pos	=	Vector(	1443.8259, -8878.6689, 0.0313)},
				[4] = {
						ang	=	Angle(1.651, -1.582, 0.000),
						pos	=	Vector(	1446.9630, -8765.0762, 0.0313)},
				[5] = {
						ang	=	Angle(1.387, -2.770, 0.000),
						pos	=	Vector(	1553.9478, -8754.1602, 0.0313)},
				[6] = {
						ang	=	Angle(1.387, -2.770, 0.000),
						pos	=	Vector(	1551.1210, -8812.6162, 0.0313)},
				[7] = {
						ang	=	Angle(1.387, -2.770, 0.000),
						pos	=	Vector(	1547.4285, -8888.9785, 0.0313)},
				[8] = {
						ang	=	Angle(1.387, -2.770, 0.000),
						pos	=	Vector(	1542.7670, -8985.3809, 0.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	6992.9980, 5850.3979, 0.0313)},
				[2] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7055.1323, 5850.4663, 0.0313)},
				[3] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7128.5703, 5850.5459, 0.0313)},
				[4] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7207.5049, 5850.6309, 0.0313)},
				[5] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7293.0864, 5850.7246, 0.0313)},
				[6] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7372.0718, 5850.8096, 0.0313)},
				[7] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7452.9478, 5850.8975, 0.0313)},
				[8] = {
						ang	=	Angle(1.651, 90.062, 0.000),
						pos	=	Vector(	7535.1851, 5850.9868, 0.0313)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_salvation"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.4858, -12192.4727, 64.0313)},
				[2] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5344, -12116.4854, 64.0313)},
				[3] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5739, -12054.8027, 64.0313)},
				[4] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.6179, -11986.0518, 64.0313)},
				[5] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-824.4539, -11985.9170, 64.0313)},
				[6] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.1353, -12049.7129, 64.0313)},
				[7] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0891, -12121.7871, 64.0313)},
				[8] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0439, -12192.4219, 64.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	194.2403, 4823.0854, -91.9688)},
				[2] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	116.2287, 4819.8286, -91.9688)},
				[3] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	48.3355, 4816.9946, -91.9688)},
				[4] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	-26.8822, 4813.8560, -91.9688)},
				[5] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	190.2165, 4887.7925, -87.9688)},
				[6] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	105.9168, 4887.9727, -87.9688)},
				[7] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	27.5507, 4888.1401, -87.9688)},
				[8] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	-44.6825, 4888.2939, -87.9688)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_salvation_night_redemption"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.4858, -12192.4727, 64.0313)},
				[2] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5344, -12116.4854, 64.0313)},
				[3] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5739, -12054.8027, 64.0313)},
				[4] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.6179, -11986.0518, 64.0313)},
				[5] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-824.4539, -11985.9170, 64.0313)},
				[6] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.1353, -12049.7129, 64.0313)},
				[7] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0891, -12121.7871, 64.0313)},
				[8] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0439, -12192.4219, 64.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	194.2403, 4823.0854, -91.9688)},
				[2] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	116.2287, 4819.8286, -91.9688)},
				[3] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	48.3355, 4816.9946, -91.9688)},
				[4] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	-26.8822, 4813.8560, -91.9688)},
				[5] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	190.2165, 4887.7925, -87.9688)},
				[6] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	105.9168, 4887.9727, -87.9688)},
				[7] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	27.5507, 4888.1401, -87.9688)},
				[8] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	-44.6825, 4888.2939, -87.9688)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_salvation_redemption"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.4858, -12192.4727, 64.0313)},
				[2] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5344, -12116.4854, 64.0313)},
				[3] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.5739, -12054.8027, 64.0313)},
				[4] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-912.6179, -11986.0518, 64.0313)},
				[5] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-824.4539, -11985.9170, 64.0313)},
				[6] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.1353, -12049.7129, 64.0313)},
				[7] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0891, -12121.7871, 64.0313)},
				[8] = {
						ang	=	Angle(1.320, 0.036, 0.000),
						pos	=	Vector(	-822.0439, -12192.4219, 64.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	194.2403, 4823.0854, -91.9688)},
				[2] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	116.2287, 4819.8286, -91.9688)},
				[3] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	48.3355, 4816.9946, -91.9688)},
				[4] = {
						ang	=	Angle(0.528, -87.612, 0.000),
						pos	=	Vector(	-26.8822, 4813.8560, -91.9688)},
				[5] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	190.2165, 4887.7925, -87.9688)},
				[6] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	105.9168, 4887.9727, -87.9688)},
				[7] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	27.5507, 4888.1401, -87.9688)},
				[8] = {
						ang	=	Angle(1.188, -90.120, 0.000),
						pos	=	Vector(	-44.6825, 4888.2939, -87.9688)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_destroyedcity_final"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(-0.628, -20.568, 0.000),
						pos	=	Vector(	-1735.2076, -6227.6304, -383.9688)},
				[2] = {
						ang	=	Angle(-0.892, -24.659, 0.000),
						pos	=	Vector(	-1736.9030, -6288.7358, -383.9688)},
				[3] = {
						ang	=	Angle(-1.816, -24.132, 0.000),
						pos	=	Vector(	-1732.3799, -6356.8765, -383.9688)},
				[4] = {
						ang	=	Angle(-3.796, -18.720, 0.000),
						pos	=	Vector(	-1731.0591, -6450.1875, -383.9688)},
				[5] = {
						ang	=	Angle(-3.532, -18.984, 0.000),
						pos	=	Vector(	-1741.1090, -6524.5786, -383.9688)},
				[6] = {
						ang	=	Angle(-4.456, -6.180, 0.000),
						pos	=	Vector(	-1732.3099, -6588.7100, -383.9688)},
				[7] = {
						ang	=	Angle(-2.212, -1.560, 0.000),
						pos	=	Vector(	-1788.7096, -6484.6069, -383.9688)},
				[8] = {
						ang	=	Angle(-2.608, -1.692, 0.000),
						pos	=	Vector(	-1781.0721, -6394.8716, -383.9688)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(1.748, 89.916, 0.000),
						pos	=	Vector(	-1486.4890, -15079.6240, -367.9688)},
				[2] = {
						ang	=	Angle(1.748, 89.916, 0.000),
						pos	=	Vector(	-1425.6583, -15079.7168, -369.9688)},
				[3] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1372.7452, -15079.7959, -367.9688)},
				[4] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1323.7754, -15079.7529, -369.9688)},
				[5] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1323.6536, -15227.8242, -369.9688)},
				[6] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1384.6273, -15227.8789, -367.9688)},
				[7] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1442.5974, -15227.9316, -369.9688)},
				[8] = {
						ang	=	Angle(1.748, 90.048, 0.000),
						pos	=	Vector(	-1495.5254, -15227.9785, -367.9688)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_salvation_2_night"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(-2.641, 75.636, 0.000),
						pos	=	Vector(	-7085.4678, -8458.3574, 128.0313)},
				[2] = {
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-7000.3140, -8459.1289, 128.0313)},
				[3] = {
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-6897.1826, -8463.6768, 128.0313)},
				[4] = {
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-6793.6396, -8465.7881, 128.0313)},
				[5] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-6825.3452, -8588.2119, 128.0313)},
				[6] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-6936.7954, -8596.4795, 128.0313)},
				[7] =	{
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-7023.6611, -8594.5938, 128.0313)},
				[8] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-7120.9526, -8597.8955, 128.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7791.0190, 7264.8330, 0.0313)},
				[2] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7792.0898, 7325.5879, 0.0313)},
				[3] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7793.2666, 7392.3306, 0.0313)},
				[4] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7794.4536, 7459.6978, 0.0313)},
				[5] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7795.7358, 7532.4663, 0.0313)},
				[6] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7796.8462, 7595.5049, 0.0313)},
				[7] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7797.9570, 7658.5464, 0.0313)},
				[8] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7799.0527, 7720.7300, 0.0313)}}

}

/*, =====================================================================, */

TS.SpawnLocations["rp_salvation_2"] = {

		["survivors"] = {

				[1] = {
						ang	=	Angle(-2.641, 75.636, 0.000),
						pos	=	Vector(	-7085.4678, -8458.3574, 128.0313)},
				[2] =
						{
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-7000.3140, -8459.1289, 128.0313)},
				[3] = {
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-6897.1826, -8463.6768, 128.0313)},
				[4] = {
						ang	=	Angle(1.979, 75.504, 0.000),
						pos	=	Vector(	-6793.6396, -8465.7881, 128.0313)},
				[5] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-6825.3452, -8588.2119, 128.0313)},
				[6] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-6936.7954, -8596.4795, 128.0313)},
				[7] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-7023.6611, -8594.5938, 128.0313)},
				[8] = {
						ang	=	Angle(-1.849, 76.428, 0.000),
						pos	=	Vector(	-7120.9526, -8597.8955, 128.0313)}},

		["skynet"] = {

				[1] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7791.0190, 7264.8330, 0.0313)},
				[2] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7792.0898, 7325.5879, 0.0313)},
				[3] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7793.2666, 7392.3306, 0.0313)},
				[4] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7794.4536, 7459.6978, 0.0313)},
				[5] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7795.7358, 7532.4663, 0.0313)},
				[6] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7796.8462, 7595.5049, 0.0313)},
				[7] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7797.9570, 7658.5464, 0.0313)},
				[8] = {
						ang	=	Angle(-2.377, 178.992, 0.000),
						pos	=	Vector(	7799.0527, 7720.7300, 0.0313)}}

}

/*, =====================================================================, */

TS.SpawnLocations["md_whitehills_b2"] = {

		["survivors"] = {

				[1] = {
						ang = Angle(2.1120026111603, 1.3200106620789, 0),
						pos = Vector(-8264.318359375, -5770.2006835938, 319.03125)
						},

				[2] = {
						ang = Angle(2.1120026111603, 1.3200106620789, 0),
						pos = Vector(-8262.271484375, -5859.0004882813, 319.03125)
						},
				[3] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8261.00390625, -5914.0004882813, 319.03125)
						},

				[4] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8261.59765625, -5996.0595703125, 319.03125)
						},

				[5] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8424.4453125, -5921.1142578125, 319.03125)
						},

				[6] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8424.0458984375, -5866.1098632813, 319.03125)
						},

				[7] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8553.2734375, -5891.0190429688, 319.03125)
						},

				[8] = {
						ang = Angle(0.79200279712677, -0.39598941802979, 0),
						pos = Vector(-8552.6044921875, -5794.376953125, 319.03125)
						}},

		["skynet"] = {

				[1] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9187.2353515625, 2524.09375, 736.03125)
						},

				[2] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9186.7919921875, 2577.728515625, 736.03125)
						},

				[3] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9186.3212890625, 2634.513671875, 736.03125)
						},

				[4] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9185.861328125, 2690.0925292969, 736.03125)
						},

				[5] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9185.431640625, 2742.0461425781, 736.03125)
						},

				[6] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9184.998046875, 2794.1677246094, 736.03125)
						},

				[7] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9184.5390625, 2849.6511230469, 736.03125)
						},

				[8] = {
						ang = Angle(-0.038001641631126, -179.53126525879, 0),
						pos = Vector(9184.130859375, 2898.7456054688, 736.03125)
						}}

}



/* Map not on the test server :P
TS.SpawnLocations["rp_apocalypse"] =
{

	["survivors"] =
	{
		pos = Vector(-1762.4693603516, -6337.9790039063, -383.96875),
		ang = Angle(3.5640006065369, -46.044021606445, 0)
	},

	["skynet"] =
	{
		pos = Vector(-1398.3126220703, -15063.8125, -367.96875),
		ang = Angle(-1.7159972190857, 88.860084533691, 0)
	}

}
*/

TS.ItemsData = { }

TS.MaxInventories = 3
MAX_CHARACTERS = 12

TS.HUDItemInfo = { }

TS.SelectablePlayerModels =
{
	"models/Humans/Group01/Male_01.mdl",
	"models/Humans/Group01/male_02.mdl",
	"models/Humans/Group01/male_03.mdl",
	"models/Humans/Group01/Male_04.mdl",
	"models/Humans/Group01/Male_05.mdl",
	"models/Humans/Group01/male_06.mdl",
	"models/Humans/Group01/male_07.mdl",
	"models/Humans/Group01/male_08.mdl",
	"models/Humans/Group01/male_09.mdl",
	"models/Humans/Group02/Male_01.mdl",
	"models/Humans/Group02/male_02.mdl",
	"models/Humans/Group02/male_03.mdl",
	"models/Humans/Group02/Male_04.mdl",
	"models/Humans/Group02/Male_05.mdl",
	"models/Humans/Group02/male_06.mdl",
	"models/Humans/Group02/male_07.mdl",
	"models/Humans/Group02/male_08.mdl",
	"models/Humans/Group02/male_09.mdl",
	"models/Humans/Group01/male_10.mdl",
	"models/Humans/Group01/male_11.mdl",
	"models/Humans/Group01/male_12.mdl",
	"models/Humans/Group01/male_13.mdl",
	"models/Humans/Group01/male_14.mdl",
	"models/Humans/Group01/male_15.mdl",
	"models/Humans/Group01/male_16.mdl",
	"models/Humans/Group01/male_17.mdl",
	"models/Humans/Group01/male_18.mdl",
	"models/Humans/Group01/male_19.mdl",
	"models/Humans/Group01/male_20.mdl",


	"models/Humans/Group01/Female_01.mdl",
	"models/Humans/Group01/Female_02.mdl",
	"models/Humans/Group01/Female_03.mdl",
	"models/Humans/Group01/Female_04.mdl",
	"models/Humans/Group01/Female_06.mdl",
	"models/Humans/Group01/Female_07.mdl",
	"models/Humans/Group02/Female_01.mdl",
	"models/Humans/Group02/Female_02.mdl",
	"models/Humans/Group02/Female_03.mdl",
	"models/Humans/Group02/Female_04.mdl",
	"models/Humans/Group02/Female_06.mdl",
	"models/Humans/Group02/Female_07.mdl",
	"models/Humans/Group01/Female_08.mdl",
	"models/Humans/Group01/Female_09.mdl",
	"models/Humans/Group01/Female_10.mdl",
	"models/Humans/Group01/Female_11.mdl",
	"models/Humans/Group01/Female_12.mdl",
	"models/Humans/Group01/Female_13.mdl",
	"models/Humans/Group01/Female_14.mdl",
	"models/Humans/Group01/Female_15.mdl",
	"models/Humans/Group01/Female_16.mdl",
	"models/Humans/Group01/Female_17.mdl",
	"models/Humans/Group01/Female_18.mdl"
}



TS.MessageTypes =
{
	GOOC = {id = 0, tabs = {1, 2}, ShowName = true, NameColor = nil, TextColor = Color(200, 200, 200, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- //
	LOOC = {id = 1, tabs = {1, 3}, ShowName = true, NameColor = Color(138, 185, 209, 255), TextColor = Color(138, 185, 209, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- [[
	SAY = {id = 2, tabs = {1, 3}, ShowName = true, NameColor = Color(91, 166, 211, 255), TextColor = Color(91, 166, 221, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, --
	WHISPER = {id = 3, tabs = {1, 3}, ShowName = true, NameColor = Color(91, 166, 211, 255), TextColor = Color(91, 166, 221, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /w
	YELL = {id = 4, tabs = {1, 3}, ShowName = true, NameColor = Color(91, 166, 211, 255), TextColor = Color(91, 166, 221, 255), font = "NewChatFont", hook = nil, ACL = false, AlLog = true, ICLog = true}, -- /y
	ICACTION = {id = 5, tabs = {1, 3}, ShowName = false, NameColor = Color(131, 206, 251, 255), TextColor = Color(131, 196, 251, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /it
	EMOTE = {id = 6, tabs = {1, 3}, ShowName = false, NameColor = Color(131, 206, 251, 255), TextColor = Color(131, 196, 251, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /me
	EMOTE2 = {id = 25, tabs = {1, 3}, ShowName = false, NameColor = Color(131, 206, 251, 255), TextColor = Color(131, 196, 251, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /me's
	PRIVMSG = {id = 7, tabs = {1, 5}, ShowName = false, NameColor = Color(200, 200, 200, 255), TextColor = Color(160, 255, 160, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- /pm
	BLUEMSG = {id = 8, tabs = {1, 2}, ShowName = false, NameColor = Color(200, 200, 200, 255), TextColor = Color(200, 200, 200, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- admin cmds -- why is this called blue?
	RADIO = {id = 9, tabs = {6}, ShowName = true, NameColor = Color(72, 118, 255, 255), TextColor = Color(72, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = true, AllLog = true, ICLog = false}, -- radio. wrgs
	RADIOYELL = {id = 10, tabs = {6}, ShowName = true, NameColor = Color(72, 118, 255, 255), TextColor = Color(72, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = true, AllLog = true, ICLog = true}, -- /ry
	RADIOWHISPER = {id = 11, tabs = {6}, ShowName = true, NameColor = Color(72, 118, 255, 255), TextColor = Color(72, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = true, AllLog = true, ICLog = true}, -- /rw
	ADMIN = {id = 12, tabs = {1, 4}, ShowName = true, NameColor = Color(255, 107, 218, 255), TextColor = Color(255, 156, 230, 255),  font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- !a
	CONSOLE = {id = 13, tabs = {1, 4}, ShowName = false, NameColor = Color(232, 20, 225, 255), TextColor = Color(200, 200, 200, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- csay
	MISC = {id = 14, tabs = {1}, ShowName = false, NameColor = Color(230, 20, 225, 255), TextColor = Color(255, 255, 149, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- umsg
	ADMINYELL = {id = 15, tabs = {1, 2}, ShowName = true, NameColor = Color(255, 255, 255, 255), TextColor = Color(232, 20, 20, 255), font = "GiantChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- rpa_yell
	NORMALMSG = {id = 16, tabs = {1, 3}, ShowName = false, NameColor = Color(111, 186, 241, 275), TextColor = Color(111, 186, 241, 275), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- umsg
	DISPATCH = {id = 17, tabs = {1, 3}, ShowName = false, NameColor = Color(111, 186, 241, 275), TextColor = Color(111, 186, 241, 275), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /dis
	BROADCAST = {id = 18, tabs = {1, 3}, ShowName = false, NameColor = Color(111, 186, 241, 275), TextColor = Color(111, 186, 241, 275), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /br
	ADVERTISMENT = {id = 19, tabs = {1, 3}, ShowName = false, NameColor = Color(111, 186, 241, 275), TextColor = Color(111, 186, 241, 275), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /adv
	EVENT = {id = 20, tabs = {1, 3}, ShowName = false, NameColor = Color(0, 191, 255, 255), TextColor = Color(0, 191, 255, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- /ev
	RADIODISPATCH = {id = 21, tabs = {1, 3, 6}, ShowName = false, NameColor = Color(72, 118, 255, 255), TextColor = Color(72, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = true, AllLog = true, ICLog = true}, -- /rdis
	KICK = {id = 22, tabs = {1}, ShowName = false, NameColor = Color(232, 20, 225, 255), TextColor = Color(255, 255, 149, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = false}, -- !kick
	SKYNET = {id = 23, tabs = {6}, ShowName = true, NameColor = Color(72, 118, 255, 255), TextColor = Color(72, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = true, AllLog = true, ICLog = false}, -- skynet radio
	RADIOWORLD = {id = 24, tabs = {1, 3}, ShowName = true, NameColor = Color(90, 118, 255, 255), TextColor = Color(90, 118, 255, 255), font = "NewChatFont", hook = nil, ACL = false, AllLog = true, ICLog = true}, -- world radio
}

-- lookup after ID
do
	local addtab = {}
	for k, v in pairs(TS.MessageTypes) do
		addtab[v.id] = v
	end

	for k, v in pairs(addtab) do
		TS.MessageTypes[k] = v -- any nicer way to do this?
	end
end

-- IMPORTANT LOL --
TS.PlayerStats =
{

	"Strength",
	"Speed",
	"Endurance",
	"Aim",

}

TS.Inventories = { }
TS.Inventories["Pockets"] = "clothes_citizen"
TS.Inventories["Rebel vest"] = "clothes_rebel"
TS.Inventories["Rebel medic vest"] = "clothes_rebelmedic"
TS.Inventories["Backpack"] = "backpack"
TS.Inventories["Firehawks Vest"] = "clothes_developer"
TS.Inventories["Ammo Pouch"] = "ammobag"

TS.SQLData = { }
TS.SQLData["group_hastt"] = 0
TS.SQLData["group_max_balloons"] = 0
TS.SQLData["group_max_dynamite"] = 0
TS.SQLData["group_max_effects"] = 0
TS.SQLData["group_max_hoverballs"] = 0
TS.SQLData["group_max_lamps"] = 0
TS.SQLData["group_max_npcs"] = 0
TS.SQLData["group_max_props"] = 0
TS.SQLData["group_max_ragdolls"] = 0
TS.SQLData["group_max_thrusters"] = 0
TS.SQLData["group_max_vehicles"] = 0
TS.SQLData["group_max_wheels"] = 0
TS.SQLData["group_max_turrets"] = 0
TS.SQLData["group_max_sents"] = 0
TS.SQLData["group_max_spawners"] = 0

--Get elapsed time in hours, minutes, and seconds
function GetHMS()

	local s = CurTime(); --How many total seconds do we have
	local totalm = math.floor(s / 60); --How many total minutes do we have
	local h = math.floor(totalm / 60); --How many total hours do we have

	local m = totalm - h * 60; --Minutes left
	s = s - totalm * 60; --Seconds left

	return h, m, math.floor(s)

end


function FormatLine(str, font, size, indent)

	if not str then return end

	local start = 1
	local c = 1

	surface.SetFont(font)

	local endstr = ""
	local n = 0
	local lastspace = 0
	local lastspacemade = 0

	while(string.len(str) > c) do

		local sub = string.sub(str, start, c)

		if string.sub(str, c, c) == " " then
			lastspace = c
		end

		if surface.GetTextSize(sub) >= size and lastspace ~= lastspacemade then

			local sub2

			if lastspace == 0 then
				lastspace = c
				lastspacemade = c
			end

			if lastspace > 1 then
				sub2 = string.sub(str, start, lastspace - 1)
				c = lastspace
			else
				sub2 = string.sub(str, start, c)
			end

			endstr = endstr .. sub2 .. "\n"

			if indent then
				endstr = endstr .. indent
			end

			lastspace = c + 1
			lastspacemade = lastspace

			start = c + 1
			n = n + 1

		end

		c = c + 1

	end

	if start < string.len(str) then

		endstr = endstr .. string.sub(str, start)

	end

	return endstr, n

end

function GM:CanDrive(pl, ent)
	return false
end

function GM:UpdateAnimation(ply)
	ply:SetPlaybackRate(1)

	if ply:KeyDown(IN_SPEED) then
		ply:SetPlaybackRate(1)
	end
end

local entity = FindMetaTable("Entity")

if SERVER then

	-- we dont want to get rid of the original setmode, so we rename it
	local oSetModel = entity.SetModel
	-- now we override the old setmodel function
	entity.SetModel = function(self, modelname)
		-- since it's an entity hook, we'll check if it's a player
		if self:IsPlayer() then

			-- check if meta:OnModelChanged exists
			--[[if entity["OnModelChanged"] then

				-- we're going to see if it errors, and is valid, ecetera
				local result, err = pcall(entity["OnModelChanged"](self:GetModel(), modelname))

				if err then

					ErrorNoHalt("Error at \'player.OnModelChanged(new, old)\': " .. err)

				end

				-- if it is valid, change the model name
				if result and result ~= "" and !err then

					modelname = result

				end

			end]]

			-- send down the new model, and alert the clients to the change
			umsg.Start("OMC")
				umsg.Entity(self)
				umsg.String(modelname)
			umsg.End()

			self:TSModelChange(modelname)

			if string.match(string.lower(modelname), "female") then
				modelname = "models/humans/female_skeleton.mdl"
			else
				modelname = "models/humans/male_skeleton.mdl"
			end
		end
		-- regardless of player or not, set the model
		oSetModel(self, modelname or "models/humans/male_skeleton.mdl")
	end
end

if CLIENT then
	local function msgReceiveModelChange(msg)
		local ply = msg:ReadEntity()
		local model = msg:ReadString()

		-- we've recieved a model name, now we check if OnModelChanged exists, and if so, call it
		if IsValid(ply) and ply:IsPlayer() and ply.OnModelChanged then
			ply:OnModelChanged(model)
		end
	end
	usermessage.Hook("OMC", msgReceiveModelChange)
end
