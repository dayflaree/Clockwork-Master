TS.Weaponholsters = TS.Weaponholsters or {}

TS.Weaponholsters.Enabled = CreateClientConVar("rp_cl_weaponholsters", "1", true, false)

local Holsters = TS.Weaponholsters

function Holsters:ModifyPosAngles(data, pos, ang, ply)
	local scale = ply:GetModelScale()

	pos = pos + (ang:Forward() * (data.OffF * scale)) + (ang:Up() * (data.OffU * scale)) + (ang:Right() * (data.OffR * scale))
	if data.OffRotF then ang:RotateAroundAxis(ang:Right(), data.OffRotR) end
	if data.OffRotF then ang:RotateAroundAxis(ang:Forward(), data.OffRotF) end
	if data.OffRotU then ang:RotateAroundAxis(ang:Up(), data.OffRotU) end
	return pos, ang
end

function Holsters:CanDraw(ply, Gun)
	local ActiveWeapon = ""

	if IsValid(ply:GetActiveWeapon()) then
		ActiveWeapon = ply:GetActiveWeapon():GetClass()
	end

	if ActiveWeapon == Gun:GetClass() then
		return false
	end

	if (GetViewEntity() == LocalPlayer() && ply == LocalPlayer()) && LocalPlayer():ShouldDrawLocalPlayer() == false then
		return false
	end

	if ply:GetMoveType() == 8 && not (ply.RagdollEntity && IsValid(ply.RagdollEntity)) then
		return false
	end

	return TS.Weaponholsters.Enabled:GetBool()
end

function Holsters:HandleGuns(ply)
	local Weapons = ply:GetWeapons()

	if not (ply:Alive()) then return end

	for i = 1, #Weapons do
		local Gun = Weapons[i]

		if Gun && IsValid(Gun) && Gun.PositionData then
			local pos, ang = Vector(), Angle()
			local data = Gun.PositionData

			if not data.Bone then return end
			if not (Gun.mdl) then
				Gun.mdl = ClientsideModel(Gun.WorldModel, RENDERGROUP_OPAQUE)
				Gun.mdl:SetNoDraw(true)
			end

			if self:CanDraw(ply, Gun) then

				local bone = ply:LookupBone(data.Bone)
				local matrix = ply:GetBoneMatrix(bone)

				if matrix then
					pos, ang = matrix:GetTranslation(), matrix:GetAngles()

					pos, ang = self:ModifyPosAngles(data, pos, ang, ply)

					Gun.mdl:SetRenderOrigin(pos)
					Gun.mdl:SetRenderAngles(ang)
					Gun.mdl:SetModelScale(ply:GetModelScale(), 0)
					Gun.mdl:SetupBones()
					Gun.mdl:DrawModel()
				end
			end
		end
	end
end

hook.Add("PostDrawOpaqueRenderables", "TS2WeaponHolsters", function(ply)
	local plytab = player.GetAll()
	for i = 1, #plytab do
		Holsters:HandleGuns(plytab[i])
	end
end)