local function roll(ply, cmd, text)

	num = tonumber(string.Trim(text)) or 6

	if num then

		if num < 100 then

			ply:PrintMessage("Argument must be between 1 and 100.")
			return

		end

		ply:Roll(num)

	else

		ply:PrintMessage("Invalid roll argument.")

	end

end
TS.ChatCmd("/roll", roll)

local function cToggClothesss(ply, args, call)


	local model = string.lower(ply.RealModelEnt:GetModel())
	local modelsep = string.Explode("/" , model)

	if table.HasValue(modelsep, "humans") then
	model = string.gsub(model, "humans/group03m", "Barnes/refugee")
	model = string.gsub(model, "humans/group02", "Barnes/refugee")
	model = string.gsub(model, "humans/group01", "Barnes/refugee")
	model = string.gsub(model, "humans/group03", "Barnes/refugee")
	else
	model = string.gsub(model, "barnes/refugee", "humans/group01")
	end


	ply:SetModel(model)


end
TS.ChatCmd("/tc", cToggClothesss)

local function cTogVest(ply, args, call)

	local model = string.lower(ply.RealModelEnt:GetModel())
	local modelsep = string.Explode("/" , model)

	if table.HasValue(modelsep, "group03") then
	model = string.gsub(model, "humans/group03", "humans/group03m")
	elseif table.HasValue(modelsep, "group03m") then
	model = string.gsub(model, "humans/group03m" , "humans/group03")
	else
	ply:PrintMessage(3, "Must be vested to use this!")
	end

	ply:SetModel(model)

end

TS.ChatCmd("/tv", cTogVest)

local function lockdoor(ply, cmd, text)

	ply:ConCommand("rp_lock\n")

end
TS.ChatCmd("/lock", lockdoor)

local function unlockdoor(ply, cmd, text)

	ply:ConCommand("rp_unlock\n")

end
TS.ChatCmd("/unlock", unlockdoor)

local function skynetdevice(ply, cmd, text)

	if not ply:HasItem("skynetdevice") then

		ply:PrintMessage(3, "You need a SkyNet Communication Device to do this!")
		return

	end

	ply:TalkToSkyNetRadio(text)
	ply:SayLocalChat(text)

end
TS.ChatCmd("/sd ", skynetdevice)

local function skynetradio(ply, cmd, text)

	if not (ply:CanUseSkynetRadio()) then

		ply:PrintMessage(3, "You need to be part of SkyNET to do this!")
		return

	end

	ply:TalkToSkyNetRadio(text)

end
TS.ChatCmd("/sr ", skynetradio)

local function propdescription(ply, cmd, text)

	if string.gsub(text, " ", "") == "" then

		ply:PrintMessage(3, "Description cannot be blank!")
		return

	end

	if string.len(text) > 160 then

		ply:PrintMessage(3, "Description cannot be over 160 characters!")
		return

	end

	SetPropDescription(ply, text)

end
TS.ChatCmd("/setdescription ", propdescription)

local function event(ply, cmd, text)

	if ply:CanUseAdminCommand() or ply:HasPlayerFlag("A") or ply.CanEvent then

		ply:SayGlobalEvent(text)

		TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [EVENT]:" .. text)

	end

end
TS.ChatCmd("/ev ", event)

local function AdminSay(ply, cmd, text)

	if not ply:IsAdmin() then
		ply:SendOverlongMessage(TS.MessageTypes.ADMIN.id, "[TO ADMINS] " .. text, ply)
		text = "! " .. text
	end

	for k, v in ipairs(player.GetAll()) do
		if v:IsAdmin() then
			ply:SendOverlongMessage(TS.MessageTypes.ADMIN.id, "[ADMINS] " .. text, v)
		end
	end

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [ADMIN]:" .. text)

	print(ply:GetRPName() .. " (" .. ply:Name() .. "): [ADMINS] " .. text)

end
TS.ChatCmd("!a ", AdminSay)

local function CleanupItems(ply, cmd, text)

	ply:ConCommand("rpa_clearitems\n")

end
TS.ChatCmd("/clearitems", CleanupItems)

local function CleanNPCRagdolls(ply, cmd, text)

	ply:ConCommand("rpa_clearnpcbodies\n")

end
TS.ChatCmd("/clearnpcbodies", CleanNPCRagdolls)

local function CleanNPCWeapons(ply, cmd, text)

	ply:ConCommand("rpa_clearguns\n")

end
TS.ChatCmd("/clearguns", CleanNPCWeapons)

local function YellRadio(ply, cmd, text)

	if not ply:CanUseRadio() then

		ply:PrintMessage(3, "You need a radio to do this!")
		return

	end

	local curradiofreq = 0

	local ent = ply:GetViewedRadioEnt()

	if ent && ply.Frequency == 0 then

		if ent.ItemData.IsOn then

			curradiofreq = tonumber(ent.ItemData.Frequency)
			ply:GetViewedRadioEnt().ItemData.IsTransmitting = true

		else

			curradiofreq = 0

		end

	else

		curradiofreq = tonumber(ply.Frequency)

	end

	if curradiofreq == 0 then

		ply:PrintMessage(3, "You need to tune your radio in!")
		return

	end

	ply:TalkToRadio("[YELL] " .. text, curradiofreq)
	ply:YellLocalChat(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [RADIO-YELL]:" .. text)

end
TS.ChatCmd("/ry ", YellRadio)

local function WhisperRadio(ply, cmd, text)

	if not ply:CanUseRadio() then

		ply:PrintMessage(3, "You need a radio to do this!")
		return

	end

	local curradiofreq = 0

	local ent = ply:GetViewedRadioEnt()

	if ent && ply.Frequency == 0 then

		if ent.ItemData.IsOn then

			curradiofreq = tonumber(ent.ItemData.Frequency)
			ply:GetViewedRadioEnt().ItemData.IsTransmitting = true

		else

			curradiofreq = 0

		end

	else

		curradiofreq = tonumber(ply.Frequency)

	end

	if curradiofreq == 0 then

		ply:PrintMessage(3, "You need to tune your radio in!")
		return

	end

	ply:TalkToRadio("[WHISPER] " .. text, curradiofreq)
	ply:WhisperLocalChat(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [RADIO-WHISPER]:" .. text)

end
TS.ChatCmd("/rw ", WhisperRadio)

local function SayRadio(ply, cmd, text)

	if ply:Team() == 2 then

		ply:TalkToSkyNetRadio(text)
		TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [SKYNET]:" .. text)

	else

		if not ply:CanUseRadio() then

			ply:PrintMessage(3, "You need a radio to do this!")
			return

		end

		local curradiofreq = 0

		local ent = ply:GetViewedRadioEnt()

		if ent && ply.Frequency == 0 then

			if ent.ItemData.IsOn then

				curradiofreq = tonumber(ent.ItemData.Frequency)
				ply:GetViewedRadioEnt().ItemData.IsTransmitting = true

			else

				curradiofreq = 0

			end

		else

			curradiofreq = tonumber(ply.Frequency)

		end

		if curradiofreq == 0 then

			ply:PrintMessage(3, "You need to tune your radio in!")
			return

		end

		ply:TalkToRadio(text, curradiofreq)
		ply:SayLocalChat(text)

		TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [RADIO]:" .. text)
	end
end
TS.ChatCmd("/r ", SayRadio)

local function SetFrequency(ply, cmd, freq)

	freq = tonumber(freq)

	if freq then

		freq = math.floor(freq)

	else

		ply:PrintMessage(3, "Invalid frequency!")
		return

	end

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 90
	trace.filter = ply

	local tr = util.TraceLine(trace)

	/* pretty much self explanatory? */
	if tr.Entity.ItemData.Frequency then

		tr.Entity.ItemData.Frequency = freq
		ply:PrintMessage(3, "Radio frequency set to " .. tostring(freq) .. ".")

	end

end
TS.ChatCmd("/setfreq", SetFrequency)

CoolPeople = {
"STEAM_0:1:12116637",
"STEAM_0:1:8310486"
}

Realizations = {
"You know, I just had the realization that Firehawk is the coolest, and I'm a big fat phony.",
"Fuck. Why the fuck can't I be as awesome as Firehawk?",
"Everyone, you should give Firehawk your money because hedabes.",
"OMG FIREHAWK GIMME UR AUTOGRAPH! I AM UR BIGGEST FAN ER ME GERRD!!!11",
"HAIL FIREHAWK!"
}

local function ooc(ply, cmd, text)

	if CurTime() < ply.NextTimeCanChatOOC then
		return ""
	end

	if (TS.OOCDelay > 0)and(not ply:IsAdmin()) then

		umsg.Start("SNCTOOC", ply)
			umsg.Float(TS.OOCDelay)
		umsg.End()

		ply.NextTimeCanChatOOC = CurTime() + TS.OOCDelay

	end

	if ply:HasContainer("Firehawks Vest") && not table.HasValue(CoolPeople, ply:SteamID()) then
		math.randomseed(CurTime())
		local rand = math.random(1, 2)

		if rand == 2 then
			text = table.Random(Realizations)
		end
	end

	TS.WriteToChatLog(ply:GetRPName() ..  "(" .. ply:SteamID() .. ") [OOC]:" .. text)

	print(ply:GetRPName() .. " (" .. ply:Name() .. "): [OOC] " .. text)

	return text

end
TS.ChatCmd("//", ooc)


local function getup(ply, cmd, text)

	if not ply:GetPlayerConscious() and ply:GetPlayerConsciousness() >= 45 then

		ply:Conscious()

	end

end
TS.ChatCmd("/getup", getup)

/*
local function survivor(ply, cmd, text)

	ply:SetTeam(1)
	ply:Die()

end
TS.ChatCmd("/survivor", survivor)

local function skynet(ply, cmd, text)

	if not ply:CanBeSkyNet() then
		return
	end

	ply:SetTeam(2)
	ply:Die()

end
TS.ChatCmd("/skynet", skynet)
*/

local function yell(ply, cmd, text)

	ply:YellLocalChat(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [YELL]:" .. text)

end
TS.ChatCmd("/y", yell)

local function whisper(ply, cmd, text)

	ply:WhisperLocalChat(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [WHISPER]:" .. text)

end
TS.ChatCmd("/w", whisper)

local function looc(ply, cmd, text)

	ply:SayLocalOOCChat(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [LOCAL-OOC]:" .. text)

end
TS.ChatCmd("[[", looc)
TS.ChatCmd(".//", looc)

local function me(ply, cmd, text)

	ply:DoICAction(text, 256, true)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [ACTION]:" .. text)

end
TS.ChatCmd("/me", me)

local function me2(ply, cmd, text)

	ply:DoICAction(text, 256, false)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [ACTION]:" .. text)

end
TS.ChatCmd("/me's", me2)

local function melong(ply, cmd, text)

	ply:DoICAction(text, 540, true)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [ACTION]:" .. text)

end
TS.ChatCmd("/lme", melong)

local function me2long(ply, cmd, text)

	ply:DoICAction(text, 540, false)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [ACTION]:" .. text)

end
TS.ChatCmd("/lme's", me2long)

local function write(ply, cmd, text)

	local res, i, x, y = ply:HasItem("paper")

	if res then

		ply.SelectedPaper = { Inv = i, x = x, y = y }

		umsg.Start("LWP", ply)
			umsg.String(text)
		umsg.End()

	end

end
TS.ChatCmd("/write", write)

local function cmdSendPM(ply, cmd, text)

	if not string.match(text, "%S") then
		ply:PrintMessage(HUD_PRINTTALK, "You last PMed: " .. (ply.LastPaged or "*no one*"))
		return
	end

	local args = string.split(string.trim(text), " ", 2, true)
	if #args[1] == 0 then
		ply:PrintMessage(HUD_PRINTTALK, "No players found")
		return
	elseif not args[2] then
		ply:PrintMessage(HUD_PRINTTALK, "Message cannot be empty")
		return
	end

	local succ, result = TS.FindPlayerByName(args[1])
	TS.ErrorMessage(ply, true, succ, result)
	if not succ then return end

	-- Add to the target's last pagers list, removing duplicates if necessary
	local pname, rname = ply:GetRPName(), result:GetRPName()
	local pagers = table.push(result.LastPagers or {}, pname, 5)
	for i = 2, #pagers do
		if pagers[i] == pname then
			table.remove(pagers, i)
			break
		end
	end
	result.LastPagers = pagers
	result.LastPager = pname
	ply.LastPaged = rname

	SendOverlongMessage(ply:EntIndex(), TS.MessageTypes.PRIVMSG.id, "[PM to " .. rname .. "] " .. args[2], ply)
	SendOverlongMessage(ply:EntIndex(), TS.MessageTypes.PRIVMSG.id, "[PM from " .. pname .. "] " .. args[2], result)
	TS.WriteToChatLog(pname .. "(" .. ply:SteamID() .. ") [PM to " .. rname .. "]: " .. args[2])

end
TS.ChatCmd("/pm", cmdSendPM)

local function cmdReplyPM(ply, cmd, text)

	if not string.match(text, "%S") then
		ply:PrintMessage(HUD_PRINTTALK, "Last PMed by: " .. (ply.LastPagers and table.concat(ply.LastPagers, ", ") or "*no one*"))
		return
	elseif not ply.LastPagers then
		ply:PrintMessage(HUD_PRINTTALK, "No players found")
		return
	end

	cmdSendPM(ply, "/reply", string.gsub(ply.LastPagers[1], " ", ".") .. " " .. text)

end
TS.ChatCmd("/reply", cmdReplyPM)

local function it(ply, cmd, text)

	ply:SayICAction(text)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [IT]: " .. text)

end
TS.ChatCmd("/it", it)

local function lit(ply, cmd, text)

	ply:SayICAction(text, 540)

	TS.WriteToChatLog(ply:GetRPName() .. "(" .. ply:SteamID() .. ") [IT]: " .. text)

end
TS.ChatCmd("/lit", lit)

local function lean(ply, cmd, text)

	if ply:IsCP() then return end

	ply:ConCommand("rp_ic_lean\n")

end
TS.ChatCmd("/lean", lean)

local function sitground(ply, cmd, text)

	if ply:IsCP() then return end

	ply:ConCommand("rp_ic_sitground\n")

end
TS.ChatCmd("/sitground", sitground)

local function stand(ply, cmd, text)

	if ply.InStanceAction then

		if ply.StanceGroundSit then

			ply:ConCommand("rp_ic_sitground\n")

		elseif ply.StanceSit  then

			ply:ConCommand("rp_ic_sit\n")

		elseif ply.StanceLean then

			ply:ConCommand("rp_ic_lean\n")

		end

	end

end
TS.ChatCmd("/stand", stand)

local function sit(ply, cmd, text)

	if ply:IsCP() then return end

	ply:ConCommand("rp_ic_sit\n")

end
TS.ChatCmd("/sit", sit)

local function atw(ply, cmd, text)

	if ply:IsCP() then return end

	ply:ConCommand("rp_ic_atw\n")

end
TS.ChatCmd("/atw", atw)

local function goto(ply, cmd, text)

	ply:ConCommand("rpa_goto " .. text .. "\n")

end
TS.ChatCmd("!goto", goto)

local function bring(ply, cmd, text)

	ply:ConCommand("rpa_bring " .. text .. "\n")

end
TS.ChatCmd("!bring", bring)

local function slay(ply, cmd, text)

	ply:ConCommand("rpa_slay " .. text .. "\n")

end
TS.ChatCmd("!slay", slay)

local function slap(ply, cmd, text)

	ply:ConCommand("rpa_slap " .. text .. "\n")

end
TS.ChatCmd("!slap", slap)

local function explode(ply, cmd, text)

	ply:ConCommand("rpa_explode " .. text .. "\n")

end
TS.ChatCmd("!explode", explode)

local function kick(ply, cmd, text)

	ply:ConCommand("rpa_kick " .. text .. "\n")

end
TS.ChatCmd("!kick", kick)

local function ban(ply, cmd, text)

	ply:ConCommand("rpa_ban " .. text .. "\n")

end
TS.ChatCmd("!ban", ban)

local function cloak(ply, cmd, text)

	ply:ConCommand("rpa_cloak\n")

end
TS.ChatCmd("!cloak", cloak)