TS.SettingsMenu = TS.SettingsMenu or {}
local Settings = TS.SettingsMenu

--[[ Controls a few extra behaviors for listed controls ]]--
Settings.ControlCallbacks = {
	["DCheckBoxLabel"] = function(obj, vars, name, args)
		obj:SetConVar(vars)
	end,
	["DColorPalette"] = function (obj, vars, name, args)
		local cr, cg, cb = unpack(vars)

		obj.m_ConVarR = cr
		obj.m_ConVarG = cg
		obj.m_ConVarB = cb
	end,
	["DNumSlider"] = function (obj, vars, name, args)
		obj:SetConVar(vars)

		obj:SetMin(args[1] or -100)
		obj:SetMax(args[2] or 100)
		if args[3] then
			obj:SetDecimals(0)
		end
		obj:SetValue(GetConVarNumber(vars))
	end
}

function Settings:Open()
	if not (self.Panel) then
		self.Panel = vgui.Create("DFrame")

		self.Panel:SetSize(300, 500)
		self.Panel:SetTitle("TRP :: Settings")
		self.Panel:ShowCloseButton(true)
		self.Panel:SetDeleteOnClose(false)
		self.Panel:SetScreenLock(true)
		self.Panel:Center()

		local w, h = self.Panel:GetSize()
		local mx, my = self.Panel:GetPos()

		self.Panel:SetPos((ScrW() - 25) - w, my)

		function self.Panel:Paint()
			surface.SetDrawColor(50, 50, 60, 255)
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(0, 150, 255, 255)
			surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
		end

		self.Settings = vgui.Create("DPanelList", self.Panel)
		self.Settings:SetSpacing(2)
		self.Settings:SetPos(5, 25)
		self.Settings:EnableVerticalScrollbar(true)

		local x, y = self.Settings:GetPos()

		self.Settings:SetSize(w - (x * 2), h - (y * 2) + (y - 2))
		self.Settings:EnableHorizontal(false)
		self.Settings:EnableVerticalScrollbar(true)

		--[[ Third Person ]]--
		self.ThirdPerson = self:CreateCategory("ThirdPerson", self.Settings, function(o)
			self:AddSetting("Enabled", "rp_cl_thirdperson_enabled", "DCheckBoxLabel", o)
			self:AddSetting("x", "rp_cl_thirdperson_offsetForward", "DNumSlider", o, -100, 0)
			self:AddSetting("y", "rp_cl_thirdperson_offsetRight", "DNumSlider", o)
			self:AddSetting("z", "rp_cl_thirdperson_offsetUp", "DNumSlider", o)

			self:AddSetting("Show Crosshair", "rp_cl_thirdperson_crosshair_enabled", "DCheckBoxLabel", o)
			self:AddSetting("Crosshair Thickness", "rp_cl_thirdperson_crosshair_thickness", "DNumSlider", o, 1, 8, true)
			self:AddSetting("Crosshair Spread", "rp_cl_thirdperson_crosshair_spread", "DNumSlider", o, 1, 18, true)
			self:AddSetting("Scale Crosshair by Distance", "rp_cl_thirdperson_crosshair_spread_scaledistance", "DCheckBoxLabel", o)
			self:AddSetting("Draw 2D Crosshair", "rp_cl_thirdperson_crosshair_2d", "DCheckBoxLabel", o)

			local prx = "rp_cl_thirdperson_crosshair_"
			self:AddSetting("Color", {prx .. "r", prx .. "g", prx .. "b"}, "DColorPalette", o)
		end)

		--[[ Headbob ]]--
		self.Headbob = self:CreateCategory("Headbob", self.Settings, function(o)
			self:AddSetting("Enabled", "rp_cl_headbob", "DCheckBoxLabel", o)
			self:AddSetting("Forward Sway Percentage", "rp_cl_headbob_forwardpercent", "DNumSlider", o, 0, 1)
			self:AddSetting("Strafe Sway Percentage", "rp_cl_headbob_strafepercent", "DNumSlider", o, 0, 1)
			self:AddSetting("FOV Running Offset", "rp_cl_headbob_fovoffset", "DNumSlider", o, 0, 40, true)
			self:AddSetting("Work with ironsights", "rp_cl_headbob_ironsights", "DCheckBoxLabel", o)
			self:AddSetting("Sway while idle", "rp_cl_headbob_idlesway", "DCheckBoxLabel", o)
		end)

		--[[ Misc/Cinematic ]]--
		self.Misc = self:CreateCategory("Misc/Cinematic", self.Settings, function(o)
			self:AddSetting("Letterbox :: Enabled", "rp_cl_letterbox", "DCheckBoxLabel", o)
			self:AddSetting("Letterbox :: Static", "rp_cl_letterbox_static", "DCheckBoxLabel", o)
			self:AddSetting("Misc :: Sad Colors", "rp_cl_sadcolors", "DCheckBoxLabel", o)
		end)

		--[[ Weapon Holsters ]]--
		self.WeaponHolsters = self:CreateCategory("Weapon Holsters", self.Settings, function(o)
			self:AddSetting("Enabled", "rp_cl_weaponholsters", "DCheckBoxLabel", o)
		end)

		--[[ Logging ]]--
		self.Logging = self:CreateCategory("Logging", self.Settings, function(o)
			self:AddSetting("Enabled", "rp_cl_logging", "DCheckBoxLabel", o)
			self:AddSetting("Log per Character", "rp_cl_logging_per_char", "DCheckBoxLabel", o)
			self:AddSetting("Log per Date", "rp_cl_logging_per_date", "DCheckBoxLabel", o)
		end)

		--[[ HUD ]]--
		self.HUD = self:CreateCategory("HUD", self.Settings, function(o)
			self:AddSetting("TS1 HUD", "rp_cl_ts1hud", "DCheckBoxLabel", o)
			self:AddSetting("Fade out Health", "rp_cl_fadehealth", "DCheckBoxLabel", o)
			self:AddSetting("Fade out Armor", "rp_cl_fadearmor", "DCheckBoxLabel", o)
			self:AddSetting("Fade out Stamina", "rp_cl_fadestamina", "DCheckBoxLabel", o)
			self:AddSetting("Fade out Ammo", "rp_cl_fadeammo", "DCheckBoxLabel", o)
		end)
	end
	self.Panel:MakePopup()
	self.Panel:SetVisible(true)
end

function Settings:CreateCategory(name, parent, contents)
	local obj = vgui.Create("DCollapsibleCategory", parent)
	obj:SetLabel(name)
	obj:SetExpanded(0)

	obj.Contents = vgui.Create("DPanelList", obj)
	obj.Contents:SetSpacing(5)
	obj.Contents:EnableHorizontal(false)
	obj.Contents:EnableVerticalScrollbar(true)
	obj.Contents:SetAutoSize(true)

	obj:SetContents(obj.Contents)
	parent:AddItem(obj)

	--[[ Call the function. ]]--
	contents(obj)

	return obj
end

function Settings:AddSetting(name, command, ctype, parent, ...)
	local obj = vgui.Create(ctype, parent)
		obj:SetText(name)
	if self.ControlCallbacks[ctype] then
		local args = {...}
		self.ControlCallbacks[ctype](obj, command, name, args)
	end

	parent.Contents:AddItem(obj)
	parent:SizeToContents()
end