util.AddNetworkString("ITNetwork_SendItem")

TS.ItemNetworking = {
	Skip = {
		["CanRevertToCitizensCloth"] = true,
		["InvStayWithClothes"] = true,
		["NotClothing"] = true,
		["GeneratedTypes"] = true
	},
	Replace = {
		["Description"] = "Desc"
	},
	SkipType = {
		[TYPE_FUNCTION] = true,
		[TYPE_THREAD] = true
	}
}

local ItemNetworking = TS.ItemNetworking

function ItemNetworking:SendItem( ply, t_item, stream )
	local t_buffer = {}

	for key, data in pairs ( t_item ) do
		if not ( self.Skip[key] || self.SkipType[TypeID( data )] ) then
			t_buffer[self.Replace[key] or key] = data
		end
	end

	net.Start(stream or "ITNetwork_SendItem")
		net.WriteTable( t_buffer )
	net.Send( ply )
end

function ItemNetworking:SendProcessedItems( ply )
	for key, t_item in pairs(TS.ProcessedItems) do
		if ply:HasPlayerFlag( t_item.Spawnflag ) && ( t_item.AdminOnly && (ply:IsAdmin() || ply:IsSuperAdmin()) || not t_item.AdminOnly ) then
			self:SendItem( ply, t_item )
		end
	end
end
