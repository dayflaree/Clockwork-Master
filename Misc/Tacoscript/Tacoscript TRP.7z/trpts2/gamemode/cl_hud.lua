surface.CreateFont("DescFont", {
	size = 14,
	weight = 200,
	font = "Myriad Pro",
	antialias = true,
	additive = false
})

surface.CreateFont("font_esp_status", {
	size = 8,
	weight = 400,
	font = "Courier New",
	antialias = true,
	additive = false
})

surface.CreateFont("font_esp", {
	size = 10,
	weight = 400,
	font = "Verdana",
	antialias = true,
	additive = false
})

surface.CreateFont("GiantDanceTargetID", {
	size = 48,
	weight = 200,
	font = "TargetID",
	antialias = true,
	additive = false
})

surface.CreateFont("LetterFont", {
	size = 20,
	weight = 200,
	font = "akbar",
	antialias = true,
	additive = false
})

surface.CreateFont("PlInfoFont", {
	size = 18,
	weight = 500,
	font = "coolvetica",
	antialias = true,
	additive = false
})

surface.CreateFont("GiantTargetID", {
	size = 48,
	weight = 800,
	font = "TargetID",
	antialias = true,
	additive = false
})

surface.CreateFont("BigTargetID", {
	size = 26,
	weight = 800,
	font = "TargetID",
	antialias = true,
	additive = false
})


LastHealthUpdate = 0
LastSprintUpdate = 0
LastWeaponUpdate = 0

LastHealth = 0
LastFiremode = 0
LastSprint = 0
LastWeapon = 0
LastWClass = ""
LastArmor = 0

HealthAlpha = 255
SprintAlpha = 255
WeaponAlpha = 255
ArmorAlpha = 255

SprintWidth = ScrW() * .3 - 2

local hudtype = CreateClientConVar("rp_cl_ts1hud", "0", true, false)
local colortype = CreateClientConVar("rp_cl_sadcolors", "0", true, false)

TS.FadeOutHealth = CreateClientConVar("rp_cl_fadehealth", "1", true, false)
TS.FadeOutArmor = CreateClientConVar("rp_cl_fadearmor", "1", true, false)
TS.FadeOutStamina = CreateClientConVar("rp_cl_fadestamina", "1", true, false)
TS.FadeOutAmmo = CreateClientConVar("rp_cl_fadeammo", "1", true, false)

TS.StaticLetterbox = CreateClientConVar("rp_cl_letterbox_static", "0", true, false)
local bMarkUp = markup

LastArmorUpdate = 0
LastBleedHUD = 0
BleedHUDAlpha = 0

LastCantSprintHUD = 0
CantSprintHUDAlpha = 0

/* Experimental TRP HUD */

/* The ancient chinesse art of...localizing things! */

--The validity of these claims is unknown..
local surface 		= surface
local string 		= string
local draw			= draw
local player 		= player
local table 		= table
local timer 		= timer
local util 			= util
local hook 			= hook
local math 			= math
local util 			= util

/* local local 		= local */

local LocalPlayer 	= LocalPlayer
local pcall 		= pcall
local IsValid 	= IsValid
local Angle 		= Angle
local CurTime 		= CurTime
local Color 		= Color
local FrameTime 	= FrameTime

/* Good job. */

local vlag 			= {}
vlag.mul 			= 2
vlag.la 			= Angle(0, 0, 0)
vlag.x 				= 0
vlag.y 				= 0

/* The positions for our "objects". xpos = ammo, xpos2 = health. */
local xpos, ypos = ScrW() - 160, ScrH() - 60
local xpos2, ypos2 = 30, ScrH() - 60

/* Smoothers, approachers, whatever you want to call them...and stuff.. */
local smooth1, smooth2, smooth3, smooth4, smooth5, smooth6, smooth7, hammo = 0, 0, 0, 0, 0, 0, 0, 0

/* Let's make shit easier. */
function FillRGBA(x, y, w, h, col)

    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawRect(x, y, w, h)

end

/* Yeah, what he said! */
function OutlineRGBA(x, y, w, h, col)

    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawOutlinedRect(x, y, w, h)

end

local blocked = {
["gmod_tool"] = 1,
["ts2_kanyewest"] = 1,
["weapon_physcannon"] = 1,
["weapon_physgun"] = 1
}

local FiremodeStr = {
[1] = "Semi-Auto",
[2] = "Full Auto",
[3] = "M203",
[5] = "Burst",
[6] = "Plasma"
}

local FiremodeAmmo = {
[3] = "40mm"
}

local Amount = 0.04

local Approach_Max = 0.08
local Approach_Min = 0.04

local Letterbox = CreateClientConVar("rp_cl_letterbox", 0, true, false)

/* Original...I know. */
function myHUD()

	local ply = LocalPlayer()

	local wep = ply:GetActiveWeapon()
	local class = ""

	if wep && IsValid(wep) then
		class = wep:GetClass()
	end

	if Letterbox:GetBool() then
		if ply:KeyDown(IN_ATTACK2) && (not blocked[class] or ply:KeyDown(IN_SPEED)) && not TS.StaticLetterbox:GetBool() then
			Amount = math.Approach(Amount, Approach_Max, (Approach_Max - Amount) * (FrameTime() * 10))
		else
			Amount = math.Approach(Amount, Approach_Min, (Approach_Min - Amount) * (FrameTime() * 10))
		end

		draw.RoundedBox(2, 0, 0, ScrW(), ScrH() * Amount, Color(0, 0, 0, 255))
		draw.RoundedBox(2, 0, ScrH() - (ScrH() * Amount), ScrW(), ScrH() * Amount, Color(0, 0, 0, 255))
	end

	/* Here in my car, wait..no... */
	pcall(function()

		local blocked = {
			["ts2_hands"] = 1,
			["gmod_tool"] = 1,
			["ts2_kanyewest"] = 1
		}

		if ply && IsValid(ply) then

			local ammo1, ammo2, ammo1_ = 0, 0, 0

			if not blocked[wep:GetClass()] then

				vlag.ca = EyeAngles()

				local tX = math.AngleDifference(vlag.ca.y , vlag.la.y) * .5
				local tY = -math.AngleDifference(vlag.ca.p , vlag.la.p) * .5

				vlag.x = vlag.x + (tX - vlag.x) * math.Clamp(0.2 * 0.5 * FrameTime() * 50 , 0 , 1)
				vlag.y = vlag.y + (tY - vlag.y) * math.Clamp(0.2 * 0.5 * FrameTime() * 50 , 0 , 1)

				vlag.la = EyeAngles()

				if wep.UseHeatsink then

					local heat = wep.heatsinkHeat or 0

					heat = heat / 10

					smooth7 = math.Approach(smooth7, heat, ((5) * (heat - smooth7)) * FrameTime())

					OutlineRGBA((xpos - 1) + vlag.x, (ypos + 11) + vlag.y, 102 , 6, Color(0, 0, 0))
					FillRGBA(xpos + vlag.x, (ypos + 12) + vlag.y, 100 * smooth7, 4, Color(255, 0, 0))

				end

				local Firemode = wep:GetData()

				if wep.Primary && IsValid(wep) && not wep.IgnoreAmmoSystem then

					local printammo = TS.ItemsData[wep:GetClass()].AmmoType

					if FiremodeAmmo[ Firemode ] then
						printammo = FiremodeAmmo[ Firemode ]
					end

					if Firemode == FIREMODE_CUSTOM then
						printammo = wep.CustomAmmo
					end

					/* Ammunition */
					ammo1 = wep:Clip1()

					if FiremodeAmmo[ Firemode ] || wep.CustomAmmo && not (Firemode == FIREMODE_CUSTOM) then ammo1 = GetTotalAmmoCount(printammo) end

					ammo1_ = ammo1
					ammo1 = ammo1 / wep.Primary.ClipSize

					if TS.ItemsData[wep:GetClass()] then
						ammo2 = GetTotalAmmoCount(printammo) or 0
					else
						ammo2 = 0
					end

					/* Retreive our maximum ammunition */
					if ammo2 > hammo then hammo = ammo2 end

					if LastWeapon ~= ammo1_ then

						LastWeapon = ammo1_
						LastWeaponUpdate = CurTime()
						WeaponAlpha = 255

					end

					/* Approach our values to make the shit look smooth and nice. */
					smooth1 = math.Approach(smooth1, ammo1, ((5) * (ammo1 - smooth1)) * FrameTime())

					if not (wep.UseHeatsink) then

						local str = ""

						if printammo then str = (" - " .. printammo) end

						/* Draw the text, borders, and bars for our Ammo. */
						draw.DrawText("Ammo" .. str, "DescFont", xpos + vlag.x, (ypos - 15) + vlag.y, Color(255, 255, 255, WeaponAlpha), nil)

						if not (FiremodeAmmo[ Firemode ] || wep.CustomAmmo) then

							FillRGBA((xpos - 1) + vlag.x, (ypos - 1) + vlag.y, 102 , 10, Color(0, 0, 0, WeaponAlpha))
							OutlineRGBA((xpos - 1) + vlag.x, (ypos - 2) + vlag.y, 102 , 12, Color(0, 0, 0, WeaponAlpha))
							FillRGBA(xpos + vlag.x, ypos - 1 + vlag.y, 100 * smooth1, 10, Color(0, 150, 220, WeaponAlpha))

						end


						if not (FiremodeAmmo[ Firemode ])  || wep.CustomAmmo then
							draw.DrawText("[" .. tostring(ammo1_) .. "/" .. tostring(ammo2) .. "]", "DescFont", xpos + vlag.x, (ypos + 15) + vlag.y, Color(255, 255, 255, WeaponAlpha), nil)
						else
							draw.DrawText(tostring(ammo1_), "DescFont", xpos + vlag.x, (ypos + 15) + vlag.y, Color(255, 255, 255, WeaponAlpha), nil)
						end

						if Firemode then

							draw.DrawText((wep.FiremodeName or FiremodeStr[ Firemode ]), "DescFont", xpos + vlag.x, (ypos + 30) + vlag.y, Color(255, 255, 255, WeaponAlpha), nil)

							if LastFiremode ~= Firemode then

								LastFiremode = Firemode
								LastWeaponUpdate = CurTime()
								WeaponAlpha = 255

							end

						end

					end


				end

			end

		end

		if not LocalPlayer():Alive() then return end
	if DontDrawDisplay then return end

	local healthperc = 1

	if TS.HighestHealth ~= 0 then
		healthperc = LocalPlayer():Health() / TS.HighestHealth
	end

	local sprintperc = ClientVars["Sprint"] / 100

	local yoffset = 0

	if hudtype:GetInt() == 1 then

		yoffset = -ScrH() + 20
		HealthAlpha = 255
		SprintAlpha = 255

	end

	draw.RoundedBox(2, 5, ScrH() - 15 + yoffset, ScrW() * .3, 8, Color(0, 0, 0, HealthAlpha))

	if LocalPlayer():Health() > 0 then

		if ClientVars["Bleeding"] then

			if CurTime() - LastBleedHUD > 2 then

				LastBleedHUD = CurTime()
				BleedHUDAlpha = 0

			else

				if CurTime() - LastBleedHUD < 1 then

					BleedHUDAlpha = math.Clamp(BleedHUDAlpha + 255 * FrameTime(), 0, 150)

				else

					BleedHUDAlpha = math.Clamp(BleedHUDAlpha - 255 * FrameTime(), 0, 150)

				end

			end

			draw.RoundedBox(2, 6, ScrH() - 14 + yoffset, (ScrW() * .3 - 2) * healthperc, 6, Color(210, 80, 80, HealthAlpha))
			draw.RoundedBox(2, 6, ScrH() - 14 + yoffset, (ScrW() * .3 - 2) * healthperc, 3, Color(255, 110, 110, HealthAlpha))
			draw.RoundedBox(2, 6, ScrH() - 14 + yoffset, (ScrW() * .3 - 2) * healthperc, 6, Color(255, 255, 255, BleedHUDAlpha))

		else

			draw.RoundedBox(2, 6, ScrH() - 14 + yoffset, (ScrW() * .3 - 2) * healthperc, 6, Color(34, 139, 34, HealthAlpha))
			draw.RoundedBox(2, 6, ScrH() - 14 + yoffset, (ScrW() * .3 - 2) * healthperc, 3, Color(50, 205, 50, HealthAlpha))

		end

	end

	if hudtype:GetInt() == 1 then

		yoffset = yoffset + 20

	end

	draw.RoundedBox(2, 5, ScrH() - 25 + yoffset, ScrW() * .3, 8, Color(0, 0, 0, SprintAlpha))

	if sprintperc > 0 then

		if ClientVars["CanSprint"] then

			draw.RoundedBox(2, 6, ScrH() - 24 + yoffset, SprintWidth, 6, Color(39, 64, 139, SprintAlpha))
			draw.RoundedBox(2, 6, ScrH() - 24 + yoffset, SprintWidth, 3, Color(58, 95, 205, SprintAlpha))

		else

			if CurTime() - LastCantSprintHUD > 2 then

				LastCantSprintHUD = CurTime()
				CantSprintHUDAlpha = 0

			else

				if CurTime() - LastCantSprintHUD < 1 then

					CantSprintHUDAlpha = math.Clamp(CantSprintHUDAlpha + 255 * FrameTime(), 0, 150)

				else

					CantSprintHUDAlpha = math.Clamp(CantSprintHUDAlpha - 255 * FrameTime(), 0, 150)

				end

			end

			draw.RoundedBox(2, 6, ScrH() - 24 + yoffset, SprintWidth, 6, Color(39, 64, 139, SprintAlpha))
			draw.RoundedBox(2, 6, ScrH() - 24 + yoffset, SprintWidth, 3, Color(58, 95, 205, SprintAlpha))
			draw.RoundedBox(2, 6, ScrH() - 24 + yoffset, SprintWidth, 6, Color(255, 255, 255, CantSprintHUDAlpha))

		end

	end

	draw.RoundedBox(2, 5, ScrH() - 35 + yoffset, ScrW() * .3, 8, Color(0, 0, 0, ArmorAlpha))

	if ClientVars["CurrentArmor"] && ClientVars["CurrentArmor"] > 0 then

		local Perc = ClientVars["CurrentArmor"] / ClientVars["MaxArmor"]

		draw.RoundedBox(2, 6, ScrH() - 34 + yoffset, (ScrW() * .3 - 2) * Perc, 6, Color(251, 125, 0, ArmorAlpha))
		draw.RoundedBox(2, 6, ScrH() - 34 + yoffset, (ScrW() * .3 - 2) * Perc, 3, Color(255, 154, 0, ArmorAlpha))

	end

	local newsprintwidth = (ScrW() * .3 - 2) * sprintperc

	if SprintWidth > newsprintwidth then

		SprintWidth = SprintWidth - (ScrW() * .3 - 2) * FrameTime() * .4

		if SprintWidth < newsprintwidth then
			SprintWidth = newsprintwidth
		end

	elseif SprintWidth < newsprintwidth then

		SprintWidth = SprintWidth + (ScrW() * .3 - 2) * FrameTime() * .4

		if SprintWidth > newsprintwidth then
			SprintWidth = newsprintwidth
		end

	end

	if LastHealth ~= LocalPlayer():Health() then

		LastHealth = LocalPlayer():Health()
		LastHealthUpdate = CurTime()
		HealthAlpha = 255

	end

	if LastSprint ~= ClientVars["Sprint"] then

		LastSprint = ClientVars["Sprint"]
		LastSprintUpdate = CurTime()
		SprintAlpha = 255

	end

	if LastArmor ~= ClientVars["CurrentArmor"] then

		LastArmor = ClientVars["CurrentArmor"]
		LastArmorUpdate = CurTime()
		ArmorAlpha = 255

	end

	if TS.FadeOutHealth:GetBool() then
		if CurTime() - LastHealthUpdate > 3 then
			HealthAlpha = math.Clamp(HealthAlpha - 180 * FrameTime(), 0, 255)
		end
	else
		HealthAlpha = 255
	end

	if TS.FadeOutStamina:GetBool() then
		if CurTime() - LastSprintUpdate > 3 then
			SprintAlpha = math.Clamp(SprintAlpha - 180 * FrameTime(), 0, 255)
		end
	else
		SprintAlpha = 255
	end

	if TS.FadeOutAmmo:GetBool() then
		if CurTime() - LastWeaponUpdate > 3 then
			WeaponAlpha = math.Clamp(WeaponAlpha - 180 * FrameTime(), 0, 255)
		end
	else
		WeaponAlpha = 255
	end

	if TS.FadeOutArmor:GetBool() then
		if CurTime() - LastArmorUpdate > 3 then
			ArmorAlpha = math.Clamp(ArmorAlpha - 180 * FrameTime(), 0, 255)
		end
	else
		ArmorAlpha = 255
	end

	end)

end

IntroFade = 255
IntroBlackFade = 255

function DrawFancyGayIntro()

	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, IntroBlackFade))

	draw.DrawTextGlowing("Terminator Roleplay", "GiantTargetID", ScrW() / 2, ScrH() * .1, Color(255, 255, 255, 255 - IntroFade), 1, nil, 6, Color(255, 255, 255, 255 - IntroFade))
	draw.DrawText("Terminator Roleplay", "GiantTargetID", ScrW() / 2, ScrH() * .1, Color(0, 0, 0, 255 - IntroFade), 1)

	if CurTime() - TS.StartTime > 1 then
		IntroFade = math.Clamp(IntroFade - 80 * FrameTime(), 0, 255)
	end

	if CurTime() - TS.StartTime > 2.5 then
		IntroBlackFade = math.Clamp(IntroBlackFade - 80 * FrameTime(), 0, 255)
	end

end

local TargetInfo = { } /* Local is faster, niggers. */

LastTargetIDUpdate = 0; /* I never asked for this. */

function UpdateTargetID(ent)

	if CurTime() - LastTargetIDUpdate < 2 then
		return
	end

	if ent:IsPlayer() then

		RunConsoleCommand("eng_uti", ent:EntIndex(), (ent.PlayerTitle or ""))

	elseif ent:IsProp() then

		RunConsoleCommand("eng_uti", ent:EntIndex(), (ent.Desc or ""))

	end

	LastTargetIDUpdate = CurTime()

end

/* 1/7/12 - Did extended titles. If this function causes any of the previously seen issues,
I'm replacing it with markup. -Firehawk. */

/* Because I really wanted to extend the titles. */

function GetTextSize(font, str)

	surface.SetFont(font)
	return surface.GetTextSize(str)

end

function DoWrapText(text, max, font, bTable)

	if text == nil or text == "" then return end

	local tab = {} --This will be holding our text.
	local str  = ""
	local i, size, sep

	if string.find(text, " ") then

		tab = string.Explode(" ", text) --Explode it into a nice little table.
		sep = " "

	else

		tab = string.ToTable(text) --If there's no spaces, don't even bother.
		sep = ""

	end

	size = table.Count(tab) --Self Explanatory

	for i = 1, size do --Loop through our table.

		str = str .. sep .. tab[i] --Start forming our string together.
		len = GetTextSize(font, str) --This is how big our string is so far.

		if len > max or i == table.Count(tab) then --Is it too big? Are the little bits left too small?

			table.insert(bTable, str) --Store that line in our table.
			text = string.sub(text, string.len(str), string.len(text)) --We're done with you, now die!
			table.Empty(tab)
			str = ""
			DoWrapText(text, max, font, bTable) --And repeat...
			break --I'm not sure I need this. Probably not.

		end

	end

end

--Use this function, not the other one.
function WrapText(text, max, font)

	local tab = {}
	local str = ""
	DoWrapText(text, max, font, tab) --Fill tab with our wordwrapped string as a table

	for k, v in pairs(tab) do --Time to fix it up.

		str = str .. v .. "\n" --Append a newline to the end of each wordwrapped line.

	end

	return str --Return it! Use it.

end

--Use this function to append dots to the end of a long string.
function ChokeString(text, max)

	if text == nil or text == "" then return end

	local len = string.len(text)

	if len > max then

		text = string.sub(text, 1, max) .. "..."

	end

	return text

end

--Thank you, Zaubermuffin.
function CleanString(str)

	return string.gsub(string.gsub(str, '>', '&gt;'), '<', '&lt;')

end

--Got our custom markup drawing shit!
function DoMarkupDraw(text, font, max, x, y, align, alpha)

	text = CleanString(text) --No niggers, you can't put color in your description!

	--Parse our text with our font and color.
	local obj = markup.Parse("<color=white><font=" .. font .. ">" .. text .. "</color></font>" , max)

	--I didn't like how markup was drawing, so I overwrote it!
	function obj:Draw(xOffset, yOffset, halign, valign, alphaoverride)

		for i,blk in pairs(self.blocks) do

			local c = Color(blk.colour.r, blk.colour.g, blk.colour.b, alpha)
			local y = yOffset + (blk.height - blk.thisY) + blk.offset.y
			local x = xOffset


			if halign == TEXT_ALIGN_CENTER then        x = x - (self.totalWidth / 2)
			elseif halign == TEXT_ALIGN_RIGHT then     x = x - (self.totalWidth)
			end

			x = x + blk.offset.x

			if valign == TEXT_ALIGN_CENTER then        y = y - (self.totalHeight / 2)
			elseif valign == TEXT_ALIGN_BOTTOM then    y = y - (self.totalHeight)
			end

			local alpha = blk.colour.a

			if alphaoverride then alpha = alphaoverride end

			draw.DrawTextOutlined(blk.text, blk.font, x, y, c, TEXT_ALIGN_CENTER, nil, 1, Color(0, 0, 0, alpha))

		end

	end

	--Get our text size.
	local w, h = GetTextSize(font, " ")

	--Calculate our height.
	local s = h * #obj.blocks

	--Draw our stuff.
	obj:Draw(x, y - s, align, 0, alpha)

	--Return our size.
	return s

end

function DrawPlayerInfo()

	local trace = { }
	trace.start = LocalPlayer():EyePos()
	trace.endpos = trace.start + LocalPlayer():GetAimVector() * 300
	trace.filter = LocalPlayer()

	local tr = util.TraceLine(trace)

	if tr.Entity and tr.Entity:IsValid() and LocalPlayer():KeyDown(IN_USE) then

		if !tr.Entity:IsPlayer() then

			if not tr.Entity.CS then

				RunConsoleCommand("eng_ucs", tr.Entity:EntIndex())
				return

			end

			local pos = tr.HitPos:ToScreen()
			local auth = tr.Entity.CS or ""

			draw.DrawText(auth, "NewChatFont", pos.x, pos.y, Color(255, 255, 255, 200))

		else

			if TargetInfo[tr.Entity] then

				TargetInfo[tr.Entity].FullTitle = true /* Yes! */

			end

		end

	end

	if tr.Entity and tr.Entity:IsValid() and (tr.Entity:IsPlayer() or tr.Entity.ItemName or tr.Entity:IsProp()) then

		UpdateTargetID(tr.Entity)

		if not TargetInfo[tr.Entity] then

			TargetInfo[tr.Entity] = { }

			TargetInfo[tr.Entity].StartTime = CurTime()
			TargetInfo[tr.Entity].Fade = 0

			if tr.Entity:IsPlayer() then

				TargetInfo[tr.Entity].Text = tr.Entity:GetRPName()
				TargetInfo[tr.Entity].TextColor = Color(200, 200, 200, 255)
				TargetInfo[tr.Entity].FullTitle = false

			elseif tr.Entity.ItemName then

				TargetInfo[tr.Entity].Text = tr.Entity.ItemName
				TargetInfo[tr.Entity].TextColor = Color(200, 200, 200, 255)

			elseif tr.Entity:IsProp() then

				TargetInfo[tr.Entity].Text = tr.Entity.Desc
				TargetInfo[tr.Entity].TextColor = Color(200, 200, 200, 255)

			end

		else

			TargetInfo[tr.Entity].Fade = math.Clamp(TargetInfo[tr.Entity].Fade + 300 * FrameTime(), 0, 255)

		end

	end

	for k, v in pairs(TargetInfo) do

		local TextColor = Color(v.TextColor.r, v.TextColor.g, v.TextColor.b, v.Fade)

		if k:IsValid() and k:IsPlayer() then

			local pos = k:EyePos() + Vector(0, 0, 8)
			local scrpos = pos:ToScreen()

			if v.Text ~= k:GetRPName() then

				TargetInfo[k].Text = k:GetRPName()

			end

			local typing = ""

			if k:GetNWBool("IsTyping") then

				typing = "\n(Typing)"

			end

			local title = k.PlayerTitle or ""

			local font = "DescFont"

			if v.FullTitle == false then

				title = ChokeString(title, 130)

			end

			local tcolor = { }
			tcolor = team.GetColor(k:Team())
			tcolor = Color(tcolor.r, tcolor.g, tcolor.b, v.Fade)

			local SizeH = DoMarkupDraw((title or "") .. typing, font, 450, scrpos.x, scrpos.y + 15, 5, v.Fade)

			draw.DrawTextOutlined(v.Text, "NewChatFont", scrpos.x, scrpos.y - SizeH, tcolor, 1, nil, 1, Color(0, 0, 0, v.Fade))

		end

		if k:IsValid() and k.ItemName then

			local pos = k:EyePos() + Vector(0, 0, 5)
			local scrpos = pos:ToScreen()

			if v.Text ~= k.ItemName then

				TargetInfo[k].Text = k.ItemName

			end

			draw.DrawTextOutlined(v.Text, "NewChatFont", scrpos.x, scrpos.y, TextColor, 1, nil, 1, Color(0, 0, 0, v.Fade))

		end

		if k:IsValid() and k.Desc then

			local pos = k:EyePos() + Vector(0, 0, 5)
			local scrpos = pos:ToScreen()

			if v.Text ~= k.Desc then

				TargetInfo[k].Text = k.Desc

			end

			draw.DrawTextOutlined(v.Text, "NewChatFont", scrpos.x, scrpos.y, TextColor, 1, nil, 1, Color(0, 0, 0, v.Fade))

		end

		if k:IsValid() and k ~= tr.Entity then

			TargetInfo[k].Fade = math.Clamp(TargetInfo[k].Fade - 300 * FrameTime(), 0, 255)

			if TargetInfo[k].Fade == 0 then

				TargetInfo[k] = nil

			end

		end

		if not k:IsValid() then

			TargetInfo[k] = nil

		end

	end

end
ActionMenuFade = 1

function DrawActionMenu()

	local pos = (ActionMenuPos + Vector(0, 0, 10))
	pos = pos:ToScreen()

	local selected = false

	draw.DrawTextOutlined(ActionMenuTitle, "NewChatFont", pos.x + ActionMenuLongest / 2, pos.y, Color(255, 255, 255, math.Clamp(255 * ActionMenuFade, 0, 255)), 1, nil, 1, Color(0, 0, 0, math.Clamp(255 * ActionMenuFade, 0, 255)))

	local y = pos.y + 18

	for n = 1, #ActionMenuOptions do

		local w = ActionMenuLongest

		local color = Color(60, 60, 60, math.Clamp(ActionMenuFade * 140, 0, 255))

		if ActionMenuCursorIsOn(pos.x, y - 10, w, 20) then
			color = Color(60, 60, 180, math.Clamp(ActionMenuFade * 140, 0, 255))
			ActionMenuChoice = n
			selected = true

			if input.IsMouseDown(MOUSE_LEFT) then

				RunConsoleCommand(ActionMenuOptions[n].Command, ActionMenuOptions[n].ID)
				ActionMenuOn = false

			end

		end

		draw.RoundedBox(2, pos.x, y, w, 20, Color(0, 0, 0, math.Clamp(ActionMenuFade * 220, 0, 255)))
		draw.RoundedBox(2, pos.x + 1, y + 1, w - 2, 18, color)
		draw.RoundedBox(4, pos.x + 1, y + 1, w - 2, 9, Color(200, 200, 200, math.Clamp(ActionMenuFade * 90, 0, 255)))
		draw.DrawText(ActionMenuOptions[n].Name, "NewChatFont", pos.x + w / 2, y + 2, Color(255, 255, 255, math.Clamp(ActionMenuFade * 255, 0, 255)), 1)

		y = y + 21

	end

	local curx, cury = ScrW() / 2, ScrH() / 2

	if TS.ThirdPerson.Enabled:GetBool() then
		local pos = TS.ThirdPerson:GetViewData()
		curx, cury = pos.x, pos.y
	end

	local cursor_color_main = Color(255, 255, 255, math.Clamp(255 * ActionMenuFade, 0, 255))
	local curson_color_border = Color(0, 0, 0, math.Clamp(ActionMenuFade * 255, 0, 255))

	draw.DrawTextOutlined("o", "NewChatFont", curx, cury, cursor_color, 1, 1, 0, cursor_color_main)

	if (math.abs((curx) - pos.x) > 100 or
		math.abs((cury) - pos.y) > 100) then

		ActionMenuFade = math.Clamp(ActionMenuFade - .7 * FrameTime(), 0, 1)

		if ActionMenuFade == 0 then

			ActionMenuOn = false

		end

	else

		ActionMenuFade = 1

	end

	if not selected and input.IsMouseDown(MOUSE_LEFT) then

		ActionMenuOn = false

	end

end

function DrawProcessBars()

	local yoffset = 0

	for k, v in pairs(ProcessBars) do

		local perc = (math.Clamp((CurTime() - v.StartTime) / v.Time, 0, 1))

		draw.RoundedBox(4, ScrW() / 2 - 160, ScrH() * .2 - 20 + yoffset, 320, 40, Color(0, 0, 0, 220))
		draw.DrawText(v.Title, "NewChatFont", ScrW() / 2, ScrH() * .2 - 17 + yoffset, Color(255, 255, 255, 255), 1)
		draw.RoundedBox(2, ScrW() / 2 - 150, ScrH() * .2 + yoffset, 300, 12, Color(0, 0, 0, 255))

		if perc > 0 then

			draw.RoundedBox(2, ScrW() / 2 - 149, ScrH() * .2 + 1 + yoffset, 298 * perc, 10, v.Color)
			draw.RoundedBox(2, ScrW() / 2 - 149, ScrH() * .2 + 1 + yoffset, 298 * perc, 4, Color(200, 200, 200, 50))

		end

		yoffset = yoffset + 42

	end

end

function DrawWeaponSelect()

	local perc = WeaponsMenuFadeAlpha / 255

	local color = {
		Color(100, 100, 100, 120 * perc),
		Color(100, 100, 100, 120 * perc),
		Color(100, 100, 100, 120 * perc )
	}

	color[SelectedTab] = Color(255, 255, 255, 200 * perc )

	draw.RoundedBox(4, ScrW() / 2 - 290, 10, 160, 30, Color(0, 0, 0, 220 * perc ))
	draw.RoundedBox(4, ScrW() / 2 - 289, 11, 158, 28, Color(100, 100, 100, 80 * perc ))
	draw.DrawTextOutlined("Hands", "NewChatFont", ScrW() / 2 - 175, 18, color[1], nil, nil, 1, Color(0, 0, 0, 255 * perc ))

	draw.RoundedBox(4, ScrW() / 2 - 125, 10, 160, 30, Color(0, 0, 0, 220 * perc ))
	draw.RoundedBox(4, ScrW() / 2 - 124, 11, 158, 28, Color(100, 100, 100, 80 * perc ))
	draw.DrawTextOutlined("Weapons", "NewChatFont", ScrW() / 2 - 32, 18, color[2], nil, nil, 1, Color(0, 0, 0, 255 * perc ))

	draw.RoundedBox(4, ScrW() / 2 + 40, 10, 160, 30, Color(0, 0, 0, 220 * perc ))
	draw.RoundedBox(4, ScrW() / 2 + 41, 11, 158, 28, Color(100, 100, 100, 80 * perc ))
	draw.DrawTextOutlined("Misc", "NewChatFont", ScrW() / 2 + 164, 18, color[3], nil, nil, 1, Color(0, 0, 0, 255 * perc ))

	local x = ScrW() / 2 - 290

	if SelectedTab == 2 then

		x = ScrW() / 2 - 125

	elseif SelectedTab == 3 then

		x = ScrW() / 2 + 40

	end

	surface.SetFont("NewChatFont")

	local yoffset = 0

	local count = 1

	for k, v in pairs(WeaponsTabs[SelectedTab]) do

		local xoffset = 0

		local w = surface.GetTextSize(WeaponsTabs[SelectedTab][k].PrintName)

		if w > 160 then

			xoffset = w - 150

		end

		local dh = 0

		local color = Color(100, 100, 100, 120 * perc )

		if k == SelectedSlot then

			color = Color(100, 100, 255, 120 * perc )

			if WeaponsTabs[SelectedTab][k].Desc then

				local dw

				dw, dh = surface.GetTextSize(WeaponsTabs[SelectedTab][k].Desc)

				if dw > w then

					xoffset = dw - 150

				end

			end

		end

		draw.RoundedBox(4, x - xoffset, 22 + count * 21 + yoffset, 160 + xoffset, 20 + dh, Color(0, 0, 0, 220 * perc ))
		draw.RoundedBox(4, x + 1 - xoffset, 23 + count * 21 + yoffset, 158 + xoffset, 18 + dh, color)
		draw.DrawTextOutlined(WeaponsTabs[SelectedTab][k].PrintName, "NewChatFont", x + 155, 25 + count * 21 + yoffset, Color(255, 255, 255, 200 * perc ), 2, nil, 1, Color(0, 0, 0, 255 * perc ))

		if k == SelectedSlot and WeaponsTabs[SelectedTab][k].Desc then

			draw.DrawText(WeaponsTabs[SelectedTab][k].Desc, "NewChatFont", x + 155, 40 + count * 21 + yoffset, Color(255, 255, 255, 200 * perc ), 2)

		end

		yoffset = yoffset + dh

		count = count + 1

	end

	if CurTime() >= WeaponsMenuFadeTime then

		WeaponsMenuFadeAlpha = WeaponsMenuFadeAlpha - 128 * FrameTime()

		if WeaponsMenuFadeAlpha <= 0 then

			WeaponsMenuVisible = false

		end

	end

end

function DrawPreviewLetter()

	if WritingVGUI and WritingVGUI.TextEntry then

		local y = 0

		if ScrH() > 600 then
			y = 100
		end

		draw.RoundedBox(0, ScrW() / 2 - 300, y, 600, 600, Color(255, 255, 255, 200))
		draw.DrawText(LetterContent, "LetterFont", ScrW() / 2 - 295, y + 5, Color(0, 0, 0, 255))

	end

end

function DrawChatBoxTimeNotice()

	if ChatBoxVisible then

		if CurTime() < NextTimeCanChat or CurTime() < NextTimeCanChatOOC then

			local amt = math.floor((NextTimeCanChatOOC - CurTime()))

			if NextTimeCanChatOOC < NextTimeCanChat then
				amt = math.floor((NextTimeCanChat - CurTime()))
			end

			local str = "Wait " .. amt .. " second"

			if amt ~= 1 then

				str = str .. "s"

			end

			str = str .. " to chat"

			if NextTimeCanChatOOC > NextTimeCanChat then
				str = str .. " in OOC"
			end

			surface.SetFont("NewChatFont")
			local w = surface.GetTextSize(str)

			draw.RoundedBox(0, 5, ScrH() - 370, w + 10, 19, Color(0, 0, 0, 255))
			draw.RoundedBox(0, 7, ScrH() - 368, w + 6, 15, Color(60, 60, 60, 220))
			draw.DrawText(str, "NewChatFont", 12, ScrH() - 368, Color(200, 200, 200, 255))

		end

	end

end


function DrawFIFO()

	if CurTime() > FadeStart and CurTime() < FadeEnd then
		FIFOAlpha = math.Clamp(FIFOAlpha + (600 * FrameTime()), 0, 255)
	end

	if CurTime() > FadeStart and CurTime() > FadeEnd and FadeStart > 0 then
		FIFOAlpha = math.Clamp(FIFOAlpha - (150 * FrameTime()), 0, 255)
	end

	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, FIFOAlpha))

	draw.DrawText("The Future; 2030", "GiantTargetID", ScrW() / 2, ScrH() / 2, Color(255, 255, 255, FIFOAlpha), 1, 1)
	--draw.DrawText("WHAT. THE. FUCK?!?", "BigTargetID", ScrW() / 2, ScrH() / 2 + 40, Color(255, 255, 255, FIFOAlpha), 1, 1)

end

--copy pasta
function DrawColorMod()

	if not LocalPlayer():Alive() then return end

 	local tab = {}

 	tab[ "$pp_colour_addr" ] 		= 0
 	tab[ "$pp_colour_addg" ] 		= 0
 	tab[ "$pp_colour_addb" ] 		= 0
 	tab[ "$pp_colour_brightness" ] 	= -.04
 	tab[ "$pp_colour_contrast" ] 	= 1.68
 	tab[ "$pp_colour_colour" ] 		= .35
 	tab[ "$pp_colour_mulr" ] 		= 0
 	tab[ "$pp_colour_mulg" ] 		= 0
 	tab[ "$pp_colour_mulb" ] 		= 0

 	DrawColorModify(tab)

end

function DrawConsciousEffects()

	if not LocalPlayer():Alive() then return end

	if CurTime() < 10 then return end

	local c = ClientVars["Consciousness"]

	if c <= 50 then

		local alpha = 5 * (ClientVars["Consciousness"] / 50)
		draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, alpha))

	end

	if c <= 30 then
		DrawMotionBlur(.17, .99, 0.05)
	elseif c <= 35 then
		DrawMotionBlur(.33, .99, 0.02)
	elseif c <= 40 then
		DrawMotionBlur(.41, .99, 0)
	elseif c <= 45 then
		DrawMotionBlur(.61, .99, 0)
	elseif c <= 50 then
		DrawMotionBlur(.71, .99, 0)
	end

end

function DrawSeeAll()

	 if AdminSeeAll and LocalPlayer():IsAdmin() then

		for k, v in pairs(player.GetAll()) do

			if v ~= LocalPlayer() then

				local pos = v:EyePos() + Vector(0, 0, 11)
				local scrpos = pos:ToScreen()

				draw.DrawTextOutlined(v:GetRPName() .. " (" .. v:Name() .. ")", "NewChatFont", scrpos.x, scrpos.y, Color(200, 0, 0, 255), 1, nil, 1, Color(0, 0, 0, 255))

			end

		end

	end

end

UnconsciousTextAlpha = 0

function DrawUnconscious()

	if not ClientVars["Conscious"] and LocalPlayer():Alive() then

		UnconsciousTextAlpha = math.Clamp(UnconsciousTextAlpha + 100 * FrameTime(), 0, 255)

	else

		if UnconsciousTextAlpha > 0 then

			UnconsciousTextAlpha = math.Clamp(UnconsciousTextAlpha - 100 * FrameTime(), 0, 255)

		end

	end

	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, math.Clamp(UnconsciousTextAlpha, 0, 210)))
	draw.DrawText("You are unconscious", "BigTargetID", ScrW() / 2, 50, Color(255, 255, 255, UnconsciousTextAlpha), 1, 0)

	draw.RoundedBox(2, ScrW() / 2 - 100, ScrH() / 2 - 16, 200, 20, Color(0, 0, 0, UnconsciousTextAlpha))

	if ClientVars["Consciousness"] > 0 then

		draw.RoundedBox(2, ScrW() / 2 - 98, ScrH() / 2 - 14, 196 * math.Clamp(ClientVars["Consciousness"] / 45, 0, 1), 16, Color(40, 40, 40, UnconsciousTextAlpha))
		draw.RoundedBox(4, ScrW() / 2 - 98, ScrH() / 2 - 14, 196 * math.Clamp(ClientVars["Consciousness"] / 45, 0, 1), 5, Color(50, 50, 50, UnconsciousTextAlpha))

	end

	if ClientVars["Consciousness"] >= 45 then

		draw.DrawText("You can now get back up with /getup", "BigTargetID", ScrW() / 2, ScrH() - 80, Color(255, 255, 255, UnconsciousTextAlpha), 1, 0)

	end

	local healthperc = 1

	if TS.HighestHealth ~= 0 then
		healthperc = LocalPlayer():Health() / TS.HighestHealth
	end

	draw.RoundedBox(0, ScrW() / 2 - 100, ScrH() / 2 + 14, 200, 12, Color(0, 0, 0, UnconsciousTextAlpha))

	if healthperc > 0 then
		draw.RoundedBox(0, ScrW() / 2 - 98, ScrH() / 2 + 16, 196 * healthperc, 8, Color(140, 0, 0, UnconsciousTextAlpha))
		draw.RoundedBox(2, ScrW() / 2 - 98, ScrH() / 2 + 16, 196 * healthperc, 4, Color(140, 50, 50, UnconsciousTextAlpha))
	end

end

function DrawWaterBlur()

	if WaterBlur.Draw > 0 then

		DrawMotionBlur(WaterBlur.Add, WaterBlur.Draw, WaterBlur.Delay)

		if CurTime() - WaterBlur.LastUpdate > 45 then

			WaterBlur.Add = math.Clamp(WaterBlur.Add - WaterBlur.MaxAdd * .14, 0, WaterBlur.MaxAdd)
			WaterBlur.Draw = math.Clamp(WaterBlur.Draw - WaterBlur.MaxDraw * .14, 0, WaterBlur.MaxDraw)
			WaterBlur.Delay = math.Clamp(WaterBlur.Delay - WaterBlur.MaxDelay * .14, 0, WaterBlur.MaxDelay)
			WaterBlur.LastUpdate = CurTime()

		end

	end

end

function DrawAlcoholBlur()

	if AlcoholBlur.Draw > 0 then

		DrawMotionBlur(AlcoholBlur.Add, AlcoholBlur.Draw, AlcoholBlur.Delay)

		if CurTime() - AlcoholBlur.LastUpdate > 100 then

			AlcoholBlur.Add = math.Clamp(AlcoholBlur.Add - AlcoholBlur.MaxAdd * .11, 0, AlcoholBlur.MaxAdd)
			AlcoholBlur.Draw = math.Clamp(AlcoholBlur.Draw - AlcoholBlur.MaxDraw * .11, 0, AlcoholBlur.MaxDraw)
			AlcoholBlur.Delay = math.Clamp(AlcoholBlur.Delay - AlcoholBlur.MaxDelay * .11, 0, AlcoholBlur.MaxDelay)
			AlcoholBlur.LastUpdate = CurTime()

		end

	end

end

function DrawDeadEffects()

	if CharacterMenu then return end
	if LocalPlayer():Alive() then return end

	local tab = { }

	tab[ "$pp_colour_addr" ] 		= 0
	tab[ "$pp_colour_addg" ] 		= 0
	tab[ "$pp_colour_addb" ] 		= 0
	tab[ "$pp_colour_brightness" ] 	= -.02
	tab[ "$pp_colour_contrast" ] 	= 3.46
	tab[ "$pp_colour_colour" ] 		= 0
	tab[ "$pp_colour_mulr" ] 		= 0
	tab[ "$pp_colour_mulg" ] 		= 0
	tab[ "$pp_colour_mulb" ] 		= 0

	DrawColorModify(tab)

end

function DrawChatLines()

	if not LocalPlayer():Alive() or not ClientVars["Conscious"] then return end

	for k, v in pairs(TS.ChatLines) do

		draw.DrawText(v.text, "ChatFont", v.x, v.y, Color(v.r, v.g, v.b, v.a))

	end

end

function DrawBleedingBlur()

	if not ClientVars["Bleeding"] then return end
	if not LocalPlayer():Alive() then return end

	local h = LocalPlayer():Health()

	if h <= 30 then
		DrawMotionBlur(.80, .99, 0.05)
	elseif h <= 35 then
		DrawMotionBlur(.70, .99, 0.02)
	elseif h <= 40 then
		DrawMotionBlur(.60, .99, 0)
	elseif h <= 45 then
		DrawMotionBlur(.55, .99, 0)
	elseif h <= 50 then
		DrawMotionBlur(.45, .99, 0)
	end

end

function DrawCloakNotice()

	draw.DrawText("You are cloaked", "BigTargetID", ScrW() / 2, 10, Color(255, 255, 255, 255), 1, 0)

end

function GM:HUDPaint()

	DrawConsciousEffects()

	DrawWaterBlur()
	DrawAlcoholBlur()

	if colortype:GetInt() == 1 then
		DrawColorMod()
	end

	if TS.FancyGayIntro then

		DrawFancyGayIntro()
		DrawFIFO()
		return

	end

	DrawPlayerInfo()

	DrawSeeAll()

	myHUD()

	if ActionMenuOn then
		DrawActionMenu()
	end

	if PlayerMenuVisible then

		DrawPlayerMenu()

	end

	DrawProcessBars()

	if WeaponsMenuVisible then
		DrawWeaponSelect()
	end

	if PreviewLetterOn then
		DrawPreviewLetter()
	end

	DrawChatBoxTimeNotice()

	DrawFIFO()

	DrawUnconscious()

	DrawDeadEffects()

	DrawChatLines()

	DrawBleedingBlur()

	if ClientVars["Cloaked"] then

		DrawCloakNotice()

	end

	TS.ThirdPerson:HUDPaint()

end

function GM:HUDShouldDraw(id)
	local nodraw = {

		"CHudHealth",
		"CHudAmmo",
		"CHudSecondaryAmmo",
		"CHudBattery",
		"CHudChat",
		"CHudWeaponSelection"

	}

	for k, v in pairs(nodraw) do
		if id == v then
			return false
		end
	end

	if id == "CHudCrosshair" && (TS.ThirdPerson.Enabled:GetBool() && TS.ThirdPerson.Crosshair:GetBool()) then
		return false
	end

	return true
end

function GM:PostRenderVGUI()
	if StorageMenu && ChosenStorageItem && not (StorageMenu.MenuButtonOptions && StorageMenu.MenuButtonOptions:IsVisible()) then
		local sx, sy = ChosenStorageItem.x, ChosenStorageItem.y
		local data = TS.ItemsData[ChosenStorageItem.id]

		if data then
			surface.SetFont("DefaultSmall")
			local w, h = surface.GetTextSize(data.Name)

			local x, y = gui.MouseX(), gui.MouseY()

			DrawFilledOutlinedSquare(x + 10, y, w + 10, h, Color(0, 0, 0, 180), Color(100, 100, 100, 180))
			draw.DrawText(data.Name, "DefaultSmall", x + 15, y + 1, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
end

--Copy pasta modification
function draw.DrawTextOutlined(text, font, x, y, colour, xalign, yalign, outlinewidth, outlinecolour)

 	for _x=-1, 1 do
 		for _y=-1, 1 do
 			draw.DrawText(text, font, x + (_x*outlinewidth), y + (_y*outlinewidth), outlinecolour, xalign, yalign)
 		end
 	end

 	draw.DrawText(text, font, x, y, colour, xalign, yalign)

end

function draw.DrawTextGlowing(text, font, x, y, colour, xalign, yalign, passes, outlinecolour)

 	for _x=-1, 1 do
 		for _y=-1, 1 do
 			for n = 1, passes do
 				draw.DrawText(text, font, x + (_x*(n/2)), y + (_y*(n/2)), Color(outlinecolour.r, outlinecolour.g, outlinecolour.b, math.Clamp(((1 / n) * 255), 0, outlinecolour.a)), xalign, yalign)
 			end
 		end
 	end

 	draw.DrawText(text, font, x, y, colour, xalign, yalign)

end

function DrawStunHit()

	local eyeang = Angle(2 * math.Rand(-1, .3), 2 * math.Rand(-.7, .7), 0)
	LocalPlayer():ViewPunch(eyeang)

	local drawalpha = 200

	timer.Create("stunalpha", 0.05, 100, function()

		drawalpha = drawalpha - 2

	end)

	draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(255, 255, 255, drawalpha))

end