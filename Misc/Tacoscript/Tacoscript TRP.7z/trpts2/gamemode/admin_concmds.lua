function ccYouTube(ply, cmd, arg)

	if not ply:CanUseSuperAdminCommand() then return end

	local song = arg[1]

	if not song then
		Console(ply, "rpa_youtube <YouTube ID> - Play a YouTube song")
		return
	end

	for k, v in pairs(player.GetAll()) do

		umsg.Start("PYT", v)
			umsg.String(song)
		umsg.End()

	end

	TS.PrintMessageAll(2, ply:GetRPName() .. " played YouTube " .. song)
	TS.WriteLog("youtube", ply:GetRPName() .. " (" .. ply:SteamID() .. ")" .. " played " .. song)

end
concommand.Add("rpa_youtube", ccYouTube)

--function TS.GenerateItemCrate(itemid, min_stack, max_stack, count, tr)

function ccGenerateItemCrate(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1] && arg[2] && arg[3] && arg[4]) then return end

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 180
		trace.filter = ply

	local tr = util.TraceLine(trace)

	TS.GenerateItemCrate(arg[1], arg[2], arg[3], arg[4], tr)

end

concommand.Add("rpa_generateitemcrate", ccGenerateItemCrate)

function ccConvertToContainer(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1] && arg[2] && arg[3] && arg[4]) then return end

	local Name = arg[1]
	local Description = arg[2]
	local w = math.Clamp(tonumber(arg[3]), 1, 10)
	local h = math.Clamp(tonumber(arg[4]), 1, 15)

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 180
		trace.filter = ply

	local tr = util.TraceLine(trace)

	if tr.Entity && tr.Entity:GetClass() == "prop_physics" then
		local model = tr.Entity:GetModel()

		local iData = {
			Name = Name,
			Description = Description,
			Model = model,
			Flags = "c!",
			Width = w,
			Height = h
		}

		local ent = ents.Create("ts2_item")
			ent:SetModel(model)
			ent:SetPos(tr.Entity:GetPos())
			ent:SetAngles(tr.Entity:GetAngles())
		ent:Spawn()

		ent:GetPhysicsObject():EnableMotion(false)

		iData.Entity = ent

		tr.Entity:Remove()

		ent.ItemData = TS.ItemToContainer(iData)
	end
end
concommand.Add("rpa_convertcontainer", ccConvertToContainer)

function ccPlayerBindContainer(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1]) then return end

	local succ, result = TS.FindPlayerByName(arg[1])
	TS.ErrorMessage(ply, true, succ, result)

	if succ then
		local tr = ply:GetBasicTrace()

		if TS.IsContainer(tr.Entity) then
			local Container = tr.Entity.ItemData

			if Container:AddToWhitelist(result) then
				ply:PrintMessage(3, "Successfully added player to container bind.")
			end
		end
	else
		ply:PrintMessage(3, "Cannot locate player!")
	end
end

concommand.Add("rpa_addtocontainerbind", ccPlayerBindContainer)


function ccBindContainerFlag(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1]) then return end

	local tr = ply:GetBasicTrace()

	local succ, result = TS.FindPlayerByName(arg[1])
	TS.ErrorMessage(ply, true, succ, result)

	if TS.IsContainer(tr.Entity) then
		local Container = tr.Entity.ItemData

		if Container:AddFactionFlag(arg[1]) then
			ply:PrintMessage(3, "Successfully applied flag to container.")
		else
			ply:PrintMessage(3, "This container already has that flag!")
		end
	end
end

concommand.Add("rpa_applycontainerflag", ccBindContainerFlag)

function ccRemoveContainerFlag(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1]) then return end

	local tr = ply:GetBasicTrace()

	if TS.IsContainer(tr.Entity) then
		local Container = tr.Entity.ItemData

		if Container:RemoveFactionFlag(arg[1]) then
			ply:PrintMessage(3, "Successfully removed flag from container.")
		else
			ply:PrintMessage(3, "That flag doesn't exist on this container!")
		end
	end
end

concommand.Add("rpa_removecontainerflag", ccRemoveContainerFlag)

function ccRemovePlayerFromContainer(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	if not (arg[1]) then return end

	local succ, result = TS.FindPlayerByName(arg[1])
	TS.ErrorMessage(ply, true, succ, result)

	local tr = ply:GetBasicTrace()

	if TS.IsContainer(tr.Entity) then
		local Container = tr.Entity.ItemData

		Container:RemoveFromWhitelist(arg[1], result)
	end
end

concommand.Add("rpa_removecontainerbind", ccRemovePlayerFromContainer)

function ccPrintAllContainerBinds(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 180
		trace.filter = ply

	local tr = util.TraceLine(trace)

	if TS.IsContainer(tr.Entity) then
		local Container = tr.Entity.ItemData

		if Container.PlayerLock then
			ply:PrintMessage(3, "Listing all binds for (" .. Container.Name .. ").")
			for k, v in pairs (Container.PlayerLock) do
				ply:PrintMessage(3, v[2] .. " - " .. v[3] .. " - " .. v[1])
			end
		else
			ply:PrintMessage(3, "There is no player lock on this container.")
		end
	end
end

concommand.Add("rpa_printboundplayers", ccPrintAllContainerBinds)

function ccClearContainerLock(ply, cmd, arg)
	if not ply:CanUseAdminCommand() then return end

	local trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 180
		trace.filter = ply

	local tr = util.TraceLine(trace)

	if TS.IsContainer(tr.Entity) then
		local Container = tr.Entity.ItemData

		if Container.PlayerLock then
			Container.PlayerLock = nil

			ply:PrintMessage(3, "Container has been unlocked!")
		end
	end
end

concommand.Add("rpa_clearcontainerlock", ccClearContainerLock)

function ccHug(ply, cmd, arg)

	if not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_hug <Name> - Hug a player")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:SetHealth(100)
		TS.PrintMessageAll(3, ply:GetRPName() .. " gave " .. result:GetRPName() .. " a big hug!")

	end

end
concommand.Add("rpa_hug", ccHug)

function ccKillYouTube(ply, cmd, arg)

	if not ply:CanUseSuperAdminCommand() then return end

	for k, v in pairs(player.GetAll()) do

		umsg.Start("KYT", v)
		umsg.End()

	end

	TS.PrintMessageAll(2, ply:GetRPName() .. " stopped YouTube")
	TS.WriteLog("youtube", ply:GetRPName() .. " (" .. ply:SteamID() .. ")" .. " killed YouTube panel")

end
concommand.Add("rpa_killyoutube", ccKillYouTube)

local function ccBanPlayer(ply, cmd, args)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then
		Console(ply, "Permission denied.")
		return
	end

	-- we need a server ID, or else we have to ban globally and that's never supposed to happen
	if not TS.Config.ServerGroup then
		Console(ply, "Server group ID has not been set. Cannot continue.")
		return
	end

	if not args[1] then
		if cmd == "rpa_ban" then
			Console(ply, "Usage: rpa_ban <name> [<length> [<reason>]]\n   Kicks and bans <name> for <length> minutes, with optional message <reason>.\n   <length> defaults to 1 hour if not specified. A 0-minute ban is permanent.")
		else
			Console(ply, "Usage: rpa_banid <steamid> [<length> [<reason>]]\n   Bans <steamid> for <length> minutes, with optional message <reason>.\n   <length> defaults to 1 hour if not specified. A 0-minute ban is permanent.")
		end
		return
	end

	local name = table.remove(args, 1)
	local steamid
	local length = tonumber(table.remove(args, 1) or 60)
	local reason = table.concat(args, " ")

	-- check length
	if not length then
		Console(ply, "Invalid ban length.")
		return
	elseif ply:EntIndex() ~= 0 and not ply:IsSuperAdmin() and (length < 1 or length * 60 > 10080) then
		Console(ply, "Permission denied: cannot ban for longer than 1 week.")
		return
	end

	if cmd == "rpa_ban" then
		local succ, result = TS.FindPlayerByName(name)
		TS.ErrorMessage(ply, true, succ, result)
		if not result then return end

		name = result:GetRPName()
		steamid = result:SteamID()
	else
		-- Make sure it's valid. Also trim whitespace, because it won't apply
		-- if it's not exact
		name = string.match(name, "^%s*STEAM_%d+:%d+:%d+%s*$")
		if not name then
			Console(ply, "Invalid SteamID format.")
			return
		end
		steamid = name
	end

	-- Check if he's already banned
	local row = TS.GlobalSQL:Query("SELECT * FROM {BANS} WHERE banLifted = 0 AND (banLength = 0 OR banStart + banLength > ?) AND (serverGroup = ? OR serverGroup IS NULL) AND userSteam = ?", os.time(), TS.Config.ServerGroup, steamid)[1]
	if row then
		Console(ply, "That player is already banned (globally, or on this server group).")
		return
	end

	local data = {
		serverGroup		= TS.Config.ServerGroup,
		userSteam		= steamid,
		adminSteam		= GetSteamID(ply),
		banStart		= os.time(),
		banLength		= length * 60,
		banReason		= reason and string.sub(reason, 1, 255)
	}
	TS.GlobalSQL:UnsafeQuery(TS.GlobalSQL:BuildQuery("insert", "{BANS}", data, true))

	-- we don't bother with banid; we check bans on connection instead
	-- we still have to kick by ID tho'
	if length == 0 then
		TS.PrintMessageAll(HUD_PRINTTALK, string.format(reason and '%s permanently banned %s: "%s"' or '%s permanently banned %s.', GetRPName(ply, true), name, reason))

		game.ConsoleCommand(string.format(reason and 'kickid %s "Permanently banned by %s: \\"%s\\""\n' or 'kickid %s "Permanently banned by %s."\n', steamid, GetRPName(ply), reason))
	else
		TS.PrintMessageAll(HUD_PRINTTALK, string.format(reason and '%s banned %s for %i minutes: "%s"' or '%s banned %s for %i minutes.', GetRPName(ply, true), name, length, reason))

		game.ConsoleCommand(string.format(reason and 'kickid %s "Banned for %i minutes by %s: "%s""\n' or 'kickid %s "Banned for %i minutes by %s."\n', steamid, length, GetRPName(ply), reason))
	end

end
concommand.Add("rpa_ban", ccBanPlayer)
concommand.Add("rpa_banid", ccBanPlayer)

local function ccUnbanID(ply, cmd, args)

	if ply:EntIndex() ~= 0 and not ply:IsAdmin() then
		Console(ply, "Permission denied.")
		return
	end

	-- we need a server ID, or else we have to ban globally and that's never supposed to happen
	if not TS.Config.ServerGroup then
		Console(ply, "Server group ID has not been set. Cannot continue.")
		return
	end

	if not args[1] then
		Console(ply, "Usage: rpa_unbanid <steamid>\n   Lifts all local bans for the given SteamID.\n   Global bans cannot be lifted locally.")
		return
	end

	-- Pull bans that apply to this server and haven't expired or been lifted
	-- We also have to keep track of any bans the player isn't allowed to lift
	local banids, B = {}, 1
	local global, perma = 0, 0

	local bans = TS.GlobalSQL:Query("SELECT * FROM {BANS} WHERE banLifted = 0 AND (banLength = 0 OR banStart + banLength > ?) AND (serverGroup = ? OR serverGroup IS NULL) AND userSteam = ?", os.time(), TS.Config.ServerGroup, args[1])
	for k, row in pairs(bans) do
		local canlift = true

		-- Can't lift local bans 
		if not tonumber(row.serverGroup) then
			global = global + 1
			canlift = false
		end

		-- Basic admins can't lift bans they're not allowed to apply
		if row.banLength == 0 and ply:EntIndex() ~= 0 and not ply:IsSuperAdmin() then
			perma = perma + 1
			canlift = false
		end

		if canlift then
			banids[B], B = tonumber(row.banID), B + 1
		end
	end

	-- since we don't use banid, we only need to update the database
	if #banids > 0 then
		TS.GlobalSQL:Query("UPDATE {BANS} SET banLifted = ?, lifterSteam = ? WHERE banID IN (" .. table.concat(banids, ", ") .. ")", os.time(), GetSteamID(ply))
	end
	Console(ply, string.format("Lifted %i ban%s for '%s'.", #banids, #banids ~= 1 and "s" or "", args[1]))
	if global > 0 then
		Console(ply, global .. " cross-server ban" .. (global ~= 1 and "s" or "") .. " excluded: cannot lift locally.")
	end
	if perma > 0 then
		Console(ply, perma .. " permanent ban" .. (perma ~= 1 and "s" or "") .. " excluded: permission denied.")
	end

end
concommand.Add("rpa_unbanid", ccUnbanID)

local function ccListBans(ply, cmd, args)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then
		Console(ply, "Permission denied.")
		return
	end

	-- yes, we still need a server ID
	if not TS.Config.ServerGroup then
		Console(ply, "Server group ID has not been set. Cannot continue.")
		return
	end
	local start = tonumber(args[1]) or 0
	if start < 0 then
		Console(ply, "Cannot start at a negative number.")
		return
	end

	local bans = TS.GlobalSQL:Query("SELECT * FROM {BANS} WHERE banLifted = 0 AND (banLength = 0 OR banStart + banLength > ?) AND (serverGroup = ? OR serverGroup IS NULL) ORDER BY banID ASC LIMIT ?, 25", os.time(), TS.Config.ServerGroup, start)

	Console(ply, string.format("    %-24s %-18s %s", "User", "Date", "Expires"))
	for i, row in ipairs(bans) do
		row.banStart = tonumber(row.banStart)
		row.banLength = tonumber(row.banLength)
		row.banLifted = tonumber(row.banLifted)
		local endtime = row.banLength > 0 and row.banStart + row.banLength or 0

		Console(ply, string.format("%02i. %-24s %-18s %-18s %s",
			start + i - 1,
			row.userSteam,
			os.date("%X %x", tonumber(row.banStart)),
			endtime > 0 and (os.date("%X %x", endtime)) or "---",
			(not tonumber(row.serverGroup) and "X" or "") .. ((endtime > 0 and endtime < os.time()) and "E" or "") .. (row.banLifted > 0 and "L" or "")
		))
	end
	Console(ply, "Showing results " .. start .. " to " .. start + 24 .. '. Use "rpa_listbans ' .. start + 25 .. '" to view more results.\nLegend: (X) Cross-server   (E) Expired   (L) Lifted')

end
concommand.Add("rpa_banlist", ccListBans)

function ccExplode(ply, cmd, arg)

	if not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_explode <Name> - Explode a player")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		local norm = result:GetAngles():Up()
		result:SetVelocity(norm * 500 + result:GetAngles():Forward() * math.random(-40, 40))

		result:Kill()

		local explode = ents.Create("env_explosion")
		explode:SetPos(result:GetPos())
		explode:Spawn()
		explode:Fire("Explode", "", 0)

		TS.PrintMessageAll(3, ply:GetRPName() .. " exploded " .. result:GetRPName())

	end

end
concommand.Add("rpa_explode", ccExplode)

function ccCreateNPC(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_createnpc <Class> - Create a TS2 NPC")
		return
	end

	CreateTS2NPC(ply, arg[1])

end
--concommand.Add("rpa_createnpc", ccCreateNPC)

function ccCleanupItems(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then
		ply:PrintMessage(3, "Sorry. This is an admin only command.")
		return
	end

	for _, item in pairs (ents.FindByClass("ts2_item")) do
		if IsValid(item)  then
			item:Remove()
		end
	end

	ply:PrintMessage(3, "Cleared all ts2_item entities from the map.")
	return

end
concommand.Add("rpa_clearitems", ccCleanupItems)

function ccCleanNPCRagdolls(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then
		ply:PrintMessage(3, "Sorry. This is an admin only command.")
		return
	end

	for k, v in pairs (player.GetAll()) do
		if IsValid(v) && v:IsPlayer() then
			v:SendLua([[
			for _, Ragdoll in pairs(ents.FindByClass("class C_ClientRagdoll")) do
				if IsValid(Ragdoll) then
					Ragdoll:Remove()
				end
			end]])
		end
	end
	ply:PrintMessage(3, "Cleared all NPC ragdolls from the map.")
	return

end
concommand.Add("rpa_clearnpcbodies", ccCleanNPCRagdolls)

function ccCleanNPCWeapons(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then
		ply:PrintMessage(3, "Sorry. This is an admin only command.")
		return
	end

	//Lets assume since the gun on the floor isn't parented, it's probably not legit.
	for _, Weapon in pairs(ents.FindByClass("weapon_*")) do
        if IsValid(Weapon) && not IsValid(Weapon:GetParent()) then
            Weapon:Remove()
        end
    end

	ply:PrintMessage(3, "Cleared all non-ts2 weapons from the map.")
	return

end
concommand.Add("rpa_clearguns", ccCleanNPCWeapons)

function ccSetGlobalProps(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not tonumber(arg[1]) then
		Console(ply, "rpa_setglobalprops <Number> - Sets how many overall props there can be on the server")
		return
	end

	local limit = tonumber(arg[1])

	TS.GlobalPropLimit = limit

	TS.PrintMessageAll(3, ply:GetRPName() .. " updated the global prop limit to " .. limit)

end
concommand.Add("rpa_setglobalprops", ccSetGlobalProps)

function ccMutePlayer(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_mute <Name> - Makes the player unable to speak in ooc until unmuted.")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		if result:IsRick() or result:IsSuperAdmin() then return end

		if result.Muted then

			ply:PrintMessage(3, "Player is already muted!")
			return

		end

		result.Muted = true

		ply:PrintMessage(3, "Successfully muted " .. result:GetRPName() .. "!")
		result:PrintMessage(3, "You been muted by " .. ply:GetRPName() .. "!")

	end

end
concommand.Add("rpa_mute", ccMutePlayer)

function ccUnMutePlayer(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_unmute <Name> - Makes the player able to speak once again if muted.")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		if !result.Muted then

			ply:PrintMessage(3, "Player isn't muted!")
			return

		end

		result.Muted = false

		ply:PrintMessage(3, "Successfully unmuted " .. result:GetRPName() .. "!")
		result:PrintMessage(3, "You been unmuted by " .. ply:GetRPName() .. ", you are able to speak in OOC once again.")

	end

end
concommand.Add("rpa_unmute", ccUnMutePlayer)

function ccViewLua(ply, cmd, arg)

	if not arg[1] or not arg[2] then
		return
	end

	local reciever = player.GetByID(arg[1])
	local luafile = arg[2]

	if reciever:IsAdmin() or reciever:IsRick() then

		reciever:PrintMessage(2, luafile)

	end

end

function ccGetLua(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_getlua <Name> - Get the lua folders of a player.")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		local uniqueid = math.random(1, 9999)

		concommand.Add(uniqueid, ccViewLua)

		umsg.Start("VLI", result)
			umsg.Short(uniqueid)
			umsg.Long(ply:EntIndex())
		umsg.End()

	end

end
concommand.Add("rpa_getlua", ccGetLua)

function ccGetIP(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_getip <Name> - Get the IP of a player.")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		ply:PrintMessage(2, result:GetRPName() .. "'s IP Address: " .. result:IPAddress())

	end

end
concommand.Add("rpa_getip", ccGetIP)

function ccListWeapons(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	for k, v in pairs(weapons.GetList()) do

		if string.find(v.ClassName, "ts2_") then

			if v.ClassName != "ts2_kanyewest" or "ts2_stormninja" or "ts2_godfist" then

				ply:PrintMessage(2, v.ClassName)

			end

		end

	end

end
concommand.Add("rpa_weaponlist", ccListWeapons)

function ccStopSounds(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	--Most console commands are blocked, including stopsounds so we'll use a usermessage instead.
	umsg.Start("StopAllSounds")
	umsg.End()

	ply:PrintMessage(2, "Stopping all sounds..")

end
concommand.Add("rpa_stopsounds", ccStopSounds)

function ccChangeMap(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_changemap <Map Name> - Change map - without the .bsp")
		return
	end

	local mapname = arg[1]

	if (string.find(mapname, "construct") or
		string.find(mapname, "flatgrass")) then

		ply:PrintMessage(2, "No.")
		return

	end

	if string.find(mapname, ".bsp") then
		mapname = string.gsub(mapname, ".bsp", "")
	end

	TS.PrintMessageAll(3, ply:GetRPName() .. " is changing the map to " .. mapname)

	timer.Simple(2, function()
		game.ConsoleCommand("changelevel " .. mapname .. "\n")
	end)

end
concommand.Add("rpa_changemap", ccChangeMap)

function ccMusicPlayer(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	local MusicToPlay =
	{
		"terminator/desert.mp3",
		"terminator/destiny.mp3",
		"terminator/dysonattack.mp3",
		"terminator/freeze.mp3",
		"terminator/goodbye.mp3",
		"terminator/heavy.mp3",
		"terminator/illbeback.mp3",
		"terminator/impaled.mp3",
		"terminator/lovescene.mp3",
		"terminator/nucleardream.mp3",
		"terminator/revives.mp3",
		"terminator/swat.mp3",
		"terminator/t1title.mp3",
		"terminator/t2maintheme.mp3",
		"terminator/freeside.mp3",
		"terminator/plan.mp3",
		"terminator/salvation.mp3",
		"terminator/serena.mp3",
		"terminator/t4title.mp3",
		"terminator/escape.mp3",
		"terminator/trumpet1.mp3",
		"terminator/trumpet2.mp3",
		"terminator/darkknight.mp3",
		"terminator/dog.mp3",
		"terminator/bennetdysonbeef.mp3",


	}

	if not arg[1] then

		for k, v in pairs(MusicToPlay) do

			ply:PrintMessage(2, v)

		end

		ply:PrintMessage(2, "Enter the sound path to play the sound!")
		return

	end

	--[[
	if not table.HasValue(MusicToPlay, arg[1]) then

		ply:PrintMessage(2, "Invalid sound, choose a sound from the list!")
		return

	end
	--]]

	for k, v in pairs(player.GetAll()) do

		v:EmitSound(arg[1], 50, 100)

	end

end
concommand.Add("rpa_playmusic", ccMusicPlayer)

function ccChangeScale(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] or not arg[2] then
		Console(ply, "rpa_setscale <Name> <Scale> - Set a player's model scale")
		return
	end

	local name = arg[1]

	local scale = arg[2]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:ScalePlayer(scale)
	    result.PlayerScale = scale
		ply:PrintMessage(3, "Set " .. result:GetRPName() .. "'s height scale to " .. scale)
		result:PrintMessage(3, "Your height scale has been set!")

		TS.WriteLog("changescale", ply:GetRPName() .. " (" .. ply:SteamID() .. ")" .. " set " .. result:GetRPName() .. " (" .. ply:SteamID() .. ") to " .. scale)

	end

end
concommand.Add("rpa_changescale", ccChangeScale)

function ccSetScale(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] or not arg[2] then
		Console(ply, "rpa_setscale <Name> <Scale> - Set a player's model scale")
		return
	end

	local name = arg[1]

	local scale = arg[2]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:ScalePlayer(scale)
		ply:PrintMessage(3, "Set " .. result:GetRPName() .. "'s height scale to " .. scale)
		result:PrintMessage(3, "Your height scale has been set!")

		TS.WriteLog("setscale", ply:GetRPName() .. " (" .. ply:SteamID() .. ")" .. " set " .. result:GetRPName() .. " (" .. ply:SteamID() .. ") to " .. scale)

	end

end
concommand.Add("rpa_setscale", ccSetScale)

function ccMakeTall(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_maketall <Name> - Scale player's model larger")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:MakeTall()
		ply:PrintMessage(3, "Made " .. result:GetRPName() .. " tall!")
		result:PrintMessage(3, "You've been made tall!")

	end

end
concommand.Add("rpa_maketall", ccMakeTall)

function ccMakeShort(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_makeshort <Name> - Scale player's model smaller")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:MakeShort()
		ply:PrintMessage(3, "Made " .. result:GetRPName() .. " short!")
		result:PrintMessage(3, "You've been made short!")

	end

end
concommand.Add("rpa_makeshort", ccMakeShort)

function ccMakeNormal(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_makenormal <Name> - Scale player's model back to normal")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:MakeNormal()
		ply:PrintMessage(3, "Made " .. result:GetRPName() .. " normal!")
		result:PrintMessage(3, "You've been made back to normal!")

	end

end
concommand.Add("rpa_makenormal", ccMakeNormal)

function ccSlap(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_slap <Name> - Slap someone")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		local norm = result:GetAngles():Up()
		result:SetVelocity(norm * 500 + result:GetAngles():Forward() * math.random(-1000, 1000))

		TS.PrintMessageAll(3, ply:GetRPName() .. " slapped " .. result:GetRPName())
		TS.PrintMessageAll(2, ply:GetRPName() .. " slapped " .. result:GetRPName())

	end

end
concommand.Add("rpa_slap", ccSlap)

function ccChangeModel(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_changeplayermodel <Name> <Model> - Permanently change player's model")
		return
	end

	local name = arg[1]
	local model = arg[2]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:SetModel(model)
		result.CitizenModel = model

		ply:PrintMessage(3, "Successfully set " .. result:GetRPName() .. "'s player model!")
		result:PrintMessage(3, "Your model has been changed!")

	end

end
concommand.Add("rpa_changeplayermodel", ccChangeModel)

function ccSetModel(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_setplayermodel <Name> <Model> - Temporarily change player's model")
		return
	end

	local name = arg[1]
	local model = arg[2]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:SetModel(model)

		ply:PrintMessage(3, "Successfully set " .. result:GetRPName() .. "'s player model!")
		result:PrintMessage(3, "Your model has been changed!")

	end

end
concommand.Add("rpa_setplayermodel", ccSetModel)

function ccSetSkin(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) then
		Console(ply, "rpa_setskin <player> <skin #> - Set a players skin")
		return
	end

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	local name = arg[1]
	local skin = tonumber(arg[2])

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:SetSkin(skin)

		ply:PrintMessage(3, "Successfully set " .. result:GetRPName() .. "'s skin!")
		result:PrintMessage(3, "Your skin has been changed!")

	end

end
concommand.Add("rpa_setskin", ccSetSkin)

function ccSetBodygroup(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) then
		Console(ply, "rpa_setbodygroup <player> <main> <state> - Set a players bodygroup")
		return
	end

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	local name = arg[1]
	local main = tonumber(arg[2])
	local state = tonumber(arg[3])

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:SetBodygroup(main, state)

		ply:PrintMessage(3, "Successfully set " .. result:GetRPName() .. "'s bodygroup!")
		result:PrintMessage(3, "Your bodygroup has been changed!")

	end

end
concommand.Add("rpa_setbodygroup", ccSetBodygroup)

function ccRMap(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	TS.PrintMessageAll(3, ply:GetRPName() .. " is restarting the map!")

	TS.MapSnapshot:Autosave()

	timer.Simple(2, function()
		game.ConsoleCommand("changelevel " .. game.GetMap() .. "\n")
	end)

end
concommand.Add("rpa_restartmap", ccRMap)

function ccCRestore(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	ply:PrintMessage(3, "Map restore point has been created. (Will be flushed on next load)")

	TS.MapSnapshot:Autosave()

end
concommand.Add("rpa_createrestore", ccCRestore)

function ccCloak(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	--Check if they're cloaked or not
	if ply.InCloak then

		ply.InCloak = false

		ply:MakeNotInvisible()

		ply:PrintMessage(3, "You are now un-cloaked!")

		ply:SetPlayerCloaked(false)

	else

		ply.InCloak = true

		ply:MakeInvisible()

		ply:PrintMessage(3, "You are now cloaked!")

		ply:SetPlayerCloaked(true)

	end

end
concommand.Add("rpa_cloak", ccCloak)

function ccGetInfo(ply, cmd, arg)
	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end
	if not arg[1] then
		Console(ply, "rpa_getinfo <Name> - Get a player's character and OOC information")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		Console(ply, "Displaying data for: " .. result:GetRPName())
		Console(ply, "    OOC Name: " .. result:Name())
		Console(ply, "    SteamID: " .. result:SteamID())
		Console(ply, "    Flags:  ")
		Console(ply, "        SkyNet: " .. result.TerminatorFlags)
		Console(ply, "        Player: " .. result.PlayerFlags)
		Console(ply, "    Stats: ")
		Console(ply, "        Strength: " .. result:GetPlayerStrength())
		Console(ply, "        Endurance: " .. result:GetPlayerEndurance())
		Console(ply, "        Speed: " .. result:GetPlayerSpeed())
		Console(ply, "        Aim: " .. result:GetPlayerAim())
		Console(ply, "    Title: " .. result:GetPlayerTitle())
		Console(ply, "    Title 2: " .. result:GetPlayerTitle2())
		Console(ply, "    Health: " .. result:Health())
		Console(ply, "    Armor: " .. result.BodyArmorHealth)
		Console(ply, "    Model: " .. result:GetModel())
		Console(ply, "    Default Model: " .. result.CitizenModel)
		Console(ply, "    Weapons:")
		for k, v in pairs(result:GetWeapons()) do
			Console(ply, "        " .. v:GetClass())
		end
		Console(ply, "    Inventory: ")
		for k,v in pairs(result:GetInfoItems()) do
			Console(ply, "        " .. v)
		end

	end

end
concommand.Add("rpa_getinfo", ccGetInfo)

function ccSlay(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_slay <Name> - Slay a player")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		TS.PrintMessageAll(2, ply:GetRPName().." slayed "..result:GetRPName())
		result:Die()

	end

end
concommand.Add("rpa_slay", ccSlay)

function ccCreateItem(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_createitem <ID> - Create item with ID")
		return
	end

	local NoSpawn = { "ts2_kanyewest", "ts2_stormninja", "ts2_godfist", "ts2_tgun" }

	if table.HasValue(NoSpawn, arg[1]) and (not ply:IsRick() or ply:Team() == 3) then
		ply:PrintMessage(3, "How about NO")
		return
	end

	if not TS.ItemsData[arg[1]] then return end

	local trace = { }
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 150
	trace.filter = ply

	local tr = util.TraceLine(trace)

	local amt = tonumber(arg[2])

	local item = TS.CreateItemProp(arg[1], tr.HitPos, nil, amt, tr)

end
concommand.Add("rpa_createitem", ccCreateItem)

function ccConsoleChat(ply, cmd, args)

	if ply:EntIndex() ~= 0 then
		Console(ply, "Permission denied.")
		return
	end
	if not args[1] then return end

	local text = table.concat(args, " ")

	if args[2] then
		MsgC(Color(200,200,200), "PROTIP: Try this instead: ")
		MsgC(Color(255,255,0), 'csay "message"\n')
	end
	MsgN("Console: " .. text)

	SendOverlongMessage(0, TS.MessageTypes.CONSOLE.id, text, nil)

end
concommand.Add("csay", ccConsoleChat)

function ccBring(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_bring <Name> - Bring a player")
		return
	end

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		trace = { }
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAngles():Forward() * 50
		trace.filter = ply

		tr = util.TraceLine(trace)


		if tr.Hit then

			trace = { }
			trace.start = ply:EyePos()
			trace.endpos = trace.start + ply:GetAngles():Forward() * -50
			trace.filter = ply

			tr = util.TraceLine(trace)

		end

		if tr.Hit then

			trace = { }
			trace.start = ply:EyePos()
			trace.endpos = trace.start + ply:GetAngles():Right() * -50
			trace.filter = ply

			tr = util.TraceLine(trace)

		end

		if tr.Hit then

			trace = { }
			trace.start = ply:EyePos()
			trace.endpos = trace.start + ply:GetAngles():Right() * 50
			trace.filter = ply

			tr = util.TraceLine(trace)

		end


		result:SetPos(tr.HitPos - Vector(0, 0, 64))

	end

end
concommand.Add("rpa_bring", ccBring)

function ccGoTo(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_goto <Name> - Go to a player")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		local trace = { }
		trace.start = result:EyePos()
		trace.endpos = trace.start + result:GetAngles():Up() * 90
		trace.filter = result

		local tr = util.TraceLine(trace)

		if tr.Hit then

			trace = { }
			trace.start = result:EyePos()
			trace.endpos = trace.start + result:GetAngles():Forward() * 50
			trace.filter = result

			tr = util.TraceLine(trace)

		end

		if tr.Hit then

			trace = { }
			trace.start = result:EyePos()
			trace.endpos = trace.start + result:GetAngles():Forward() * -50
			trace.filter = result

			tr = util.TraceLine(trace)

		end

		if tr.Hit then

			trace = { }
			trace.start = result:EyePos()
			trace.endpos = trace.start + result:GetAngles():Right() * -50
			trace.filter = result

			tr = util.TraceLine(trace)

		end

		if tr.Hit then

			trace = { }
			trace.start = result:EyePos()
			trace.endpos = trace.start + result:GetAngles():Right() * 50
			trace.filter = result

			tr = util.TraceLine(trace)

		end


		ply:SetPos(tr.HitPos - Vector(0, 0, 64))

	end

end
concommand.Add("rpa_goto", ccGoTo)

function ccAdminYell(ply, cmd, args)
	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then
		Console(ply, "Permission denied.")
		return
	end

	if not args[1] then
		Console(ply, "rpa_yell <Text> - Yell at the server angrily")
		return
	end

	local text = table.concat(args, " ")

	if ply:EntIndex() == 0 and args[2] then
		MsgC(Color(200,200,200), "PROTIP: if you use concommands properly, your punctuation won't get fucked up.\nTry this instead: ")
		MsgC(Color(200,200,0), 'rpa_yell "message"\n')
		MsgN(text)
	elseif args[2] then
		Console(ply, "PROTIP: if you use concommands properly, your punctuation won't get fucked up.\nTry this instead: rpa_yell \"text\"")
	end
	SendOverlongMessage(ply:EntIndex(), TS.MessageTypes.ADMINYELL.id, text, nil)
end
concommand.Add("rpa_yell", ccAdminYell)

function ccKick(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_kick <Name> <Reason> - Kick name with reason")
		return
	end

	local msg = ""

	if arg[2] then

		for n = 2, #arg do

			if msg ~= "" then
				msg = msg .. " "
			end

			msg = msg .. arg[n]

		end

	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, true, succ, result)

	if succ then

		result:Kick(msg, ply:GetRPName())

	end

end
concommand.Add("rpa_kick", ccKick)

function ccOOCDelay(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] or not tonumber(arg[1]) then
		Console(ply, "rpa_oocdelay <Delay> - Set an OOC delay; Current delay is: " .. TS.OOCDelay)
		return
	end

	local delay = tonumber(arg[1])

	if delay < 0 or delay > 600 then
		Console(ply, "Must be between 0 and 600.")
		return
	end

	TS.OOCDelay = delay

	umsg.Start("ODC")
		umsg.String(ply:GetRPName())
		umsg.Float(delay)
	umsg.End()

	for k, v in pairs(player.GetAll()) do

		if not v:IsAdmin() then

			v.NextTimeCanChatOOC = CurTime() + delay

		end

	end

	TS.PrintMessageAll(2, "Admin " .. ply:GetRPName() .. " (" .. ply:SteamID() .. ") has set the OOC delay to " .. delay)

end
concommand.Add("rpa_oocdelay", ccOOCDelay)

function ccMaxStats(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseSuperAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_maxstats <Name> - Give player max stats")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		result:SetPlayerStrength(100)
		result:SetPlayerSpeed(100)
		result:SetPlayerEndurance(100)
		result:SetPlayerAim(100)

		Console(result, "Admin " .. ply:GetRPName() .. "(" .. ply:SteamID() .. ") has given you max stats", true)
		Console(ply, "Gave max stats to " .. result:GetRPName(), true)

		TS.WriteLog("maxstats", ply:GetRPName() .. "(" .. ply:SteamID() .. ")" .. " gave " .. result:GetRPName() .. " max stats.")

	end

end
concommand.Add("rpa_givemaxstats", ccMaxStats)

function ccObserve(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() and not ply:HasPlayerFlag("O") then return end

	if ply.ObserveMode then

		ply:Observe(false)

	else

		ply:Observe(true)

	end

end
concommand.Add("rpa_observe", ccObserve)
concommand.Add("rp_noclip", ccObserve); --legacy support, oh I love being a Dev -- Storm_Ninja

function ccSeeAll(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	umsg.Start("SeeAll", ply); umsg.End()

end
concommand.Add("rpa_seeall", ccSeeAll)

function ccForceF1(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_forcef1 <Name> - Force the help menu open on a player")
		return
	end

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		umsg.Start("SH", result)
		umsg.End()

		result:PrintMessage(3, "You have been forced to read F1!")
		ply:PrintMessage(3, "Forced F1 on: " .. result:GetRPName())

	end

end
concommand.Add("rpa_forcef1", ccForceF1)

function ccBanPhysgun(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_banphysgun <Name> - Ban a player's physgun")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		if not result:IsPhysBanned() then

			file.Write("TS2/data/physgunbans.txt", (file.Read("TS2/data/physgunbans.txt") or "") .. ";" .. result:SteamID())

			table.insert(TS.PhysgunBans, result:SteamID())

			if result:HasWeapon("weapon_physgun") then
				result:StripWeapon("weapon_physgun")
			end

			ply:PrintMessage(3, "Sucessfully banned " .. result:GetRPName() .. "'s physgun!")
			result:PrintMessage(3, "Your physgun has been banned!")

		else

			ply:PrintMessage(3, "Player's physgun is already banned!")

		end

	end

end
concommand.Add("rpa_banphysgun", ccBanPhysgun)

function ccUnbanPhysgun(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_unbanphysgun <Name> - Unban a player's physgun")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		if result:IsPhysBanned() then

			file.Write("TS2/data/physgunbans.txt", string.gsub((file.Read("TS2/data/physgunbans.txt") or ""), ";" .. result:SteamID(), ""))

			for k, v in pairs(TS.PhysgunBans) do

				if v == result:SteamID() then
					TS.PhysgunBans[k] = nil
					break
				end

			end

			if not result:HasWeapon("weapon_physgun") then
				result:Give("weapon_physgun")
			end

			ply:PrintMessage(3, "Successfully unbanned " .. result:GetRPName() .. "'s physgun!")
			result:PrintMessage(3, "Your physgun has been unbanned!")

		else

			ply:PrintMessage(3, "Player's physgun isn't banned!")

		end

	end

end
concommand.Add("rpa_unbanphysgun", ccUnbanPhysgun)

function ccItemList(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	for k, v in pairs(TS.ProcessedItems) do

		ply:PrintMessage(2, "Name: " .. v.Name .. "\n" .. "ID: " .. v.ID)

	end

end
concommand.Add("rpa_itemlist", ccItemList)

-----------------------------
--MY SQL COMMANDS------------
-----------------------------

function ccFlagPlayerT(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_setterminatorflag <Name> <Flag> - Set a player's Terminator Flag(s)")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if not arg[2] then
		arg[2] = " "
	end

	if succ then

		result.TerminatorFlags = arg[2]

		TS.SQL:Query("UPDATE {CHARACTERS} SET factionFlags = ? WHERE userID = ? AND charName = ?", arg[2], result.UID, result:GetRPName())

		ply:PrintMessage(3, "Updated Terminator flags for: " .. result:GetRPName() .. " (" .. result.TerminatorFlags .. ")")
		result:PrintMessage(3, "Your Terminator flags have been updated!")

	end

end
concommand.Add("rpa_setterminatorflag", ccFlagPlayerT)

function ccSetPlayerStat(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_setplayerstat <Name> <stat> <amount> - Set a player's Player Flag(s)")
		Console(ply, "Example: rpa_setplayerstat Jimmy Strength 20")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if not arg[2] then
		Console(ply, "ERROR: No Stat Specified!")
		return
	end

	local statExists = false

	for i = 1, #TS.PlayerStats do
		local stat = TS.PlayerStats[i]

		if stat == arg[2] then
			statExists = true
		end
	end

	if not (statExists) then
		Console(ply, "ERROR: Specified Stat doesn't exist!")
		return
	end

	if not (tonumber(arg[3])) then
		Console(ply, "ERROR: No number specified!")
		return
	end

	if succ then
		local value = math.Clamp(tonumber(arg[3]), 0, 100)
		result["SetPlayer" .. arg[2]](result, value)

		ply:PrintMessage(3, "Set " .. arg[2] .. " for " .. result:GetRPName() .. " to " .. value .. ".")
		result:PrintMessage(3, arg[2] .. " has been set to " .. value .. " by " .. ply:GetRPName() .. ".")

		result:CharSave()
	end

end
concommand.Add("rpa_setplayerstat", ccSetPlayerStat)

function ccFlagPlayer(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_setplayerflag <Name> <Flag> - Set a player's Player Flag(s)")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if not arg[2] then
		arg[2] = " "
	end

	if succ then

		result.PlayerFlags = arg[2]

		ply:PrintMessage(3, "Updated Player flags for: " .. result:GetRPName() .. " (" .. result.PlayerFlags .. ")")
		result:PrintMessage(3, "Your Player flags have been updated!")

		TS.ItemNetworking:SendProcessedItems(result)

		TS.SQL:Query("UPDATE {CHARACTERS} SET factionFlags = ? WHERE userID = ? AND charName = ?", arg[2], result.UID, result:GetRPName())

	end

end
concommand.Add("rpa_setplayerflag", ccFlagPlayer)

function ccAddAdvTT(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_addadvtt <Name> - Give a player Tool Trust")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		if result.Tooltrust then

			ply:PrintMessage(3, "Person already has Tool Trust!")
			return

		end

		TS.SQL:Query("UPDATE {USERS} SET userTooltrust = 1 WHERE userID = ?", result.UID)

		ply:PrintMessage(3, "Given Tool Trust to: " .. result:GetRPName() .. " (" .. result:SteamID() .. ") ")
		result:PrintMessage(3, "You have been given Tool Trust!")

		result:LoadSQLData()

		if not result:HasWeapon("gmod_tool") then
			result:Give("gmod_tool")
		end

	end

end
concommand.Add("rpa_addadvtt", ccAddAdvTT)

function ccRemoveAdvTT(ply, cmd, arg)

	if ply:EntIndex() ~= 0 and not ply:CanUseAdminCommand() then return end

	if not arg[1] then
		Console(ply, "rpa_removeadvtt <Name> - Remove a player's Tool Trust")
		return
	end

	local name = arg[1]

	local succ, result = TS.FindPlayerByName(name)
	TS.ErrorMessage(ply, false, succ, result)

	if succ then

		if not result.Tooltrust then

			ply:PrintMessage(3, "Person doesen't have Tool Trust!")
			return

		end

		TS.SQL:Query("UPDATE {USERS} SET userTooltrust = 0 WHERE userID = ?", result.UID)

		ply:PrintMessage(3, "Removed Tool Trust from: " .. result:GetRPName() .. " (" .. result:SteamID() .. ") ")
		result:PrintMessage(3, "Your Tool Trust has been removed")

		result:LoadSQLData()

		if result:HasWeapon("gmod_tool") then
			result:StripWeapon("gmod_tool")
		end

	end

end
concommand.Add("rpa_removeadvtt", ccRemoveAdvTT)

function ccSpectate(ply, cmd, args)
	if ply:EntIndex() == 0 then
		Console(ply, "This command cannot be used from the server console.")
		return
	elseif not ply:IsRick() then
		Console(ply, "Permission denied.")
		return
	end

	if not args[1] then
		Console(ply, "rpa_spectate <Name> - Spectate a player!")
		return
	end

	local succ, result = TS.FindPlayerByName(args[1])
	TS.ErrorMessage(ply, false, succ, result)
	if not succ then return end

	ply:SetViewEntity(result)
end
concommand.Add("rpa_spectate", ccSpectate)

function ccUnspectate(ply, cmd, args)
	if ply:EntIndex() == 0 then
		Console(ply, "This command cannot be used from the server console.")
		return
	elseif not ply:IsRick() then
		Console(ply, "Permission denied.")
		return
	end

	ply:SetViewEntity(ply)
end
concommand.Add("rpa_unspectate", ccUnspectate)
