--[[
	A wrapper for MySQLOO v8
	Was supposed to be part of a standard DBAL API, but let's face it, nobody's
	going to use SQLite :(

	Public functions:
		New(config, aliases)

	DBAL object methods:
		Connect(attempts)
		Disconnect()
		BeginTransaction()
		Commit()
		Rollback()
		Query(query, ..., callback, ...)
		UnsafeQuery(query, callback, ...)

		FormatQuery(query, ...)
		BuildQuery(mode, name, data, escapetokens)
		Escape(str)

		IsConnected()
		TableExists(name)
		GetLastInsertID()
]]

require("mysqloo")

-- Namespace
if not mysql then
	mysql = {}
	mysql.__index = mysql
	mysql.__tostring = function(self) return string.format("[MySQL][User:%s@%s][DB:%s]", self.config.User, self.config.Host, self.config.Name) end
end

-- Creates and returns a new dbal object.
-- Expects the following structure:
--	config = {
--		Host	= "127.0.0.1",
--		Port	= 3306,
--		Name	= "mydatabase",
--		User	= "myusername",
--		Pass	= "mypassword"
--	}
--	aliases = {
--		MYALIAS		= "my_table"
--		MYALIAS2	= "other_table"
--	}
function mysql.New(config, aliases)
	local t = setmetatable({}, mysql)

	t.config = table.Copy(config or {})
	t.aliases = table.Copy(aliases or {})

	for k, v in pairs(config) do
		config[k] = nil
	end

	return t
end

-- Upvalues
local mysqloo = mysqloo
local gsub = string.gsub
local format = string.format
local tblconcat = table.concat
local sqlSetup, sqlConnect, sqlShutdown, sqlBeginTransaction, sqlCommit, sqlRollback, sqlQuery, sqlUnsafeQuery,
	sqlFormatQuery, sqlBuildQuery, sqlEscape, sqlIsConnected, sqlTableExists, sqlLastInsertID

-- Constants
function SQL_NOCALLBACK() end	-- Only actually supported by MySQLOO but included for compatibility
SQL_NULL = {}					-- Use this to pass an sql NULL if necessary

-- Open a connection to the database
sqlConnect = function(self, attempts)
	-- Already connected?
	if sqlIsConnected(self) then
		return
	end

	attempts = attempts or 0
	if attempts > 5 then
		util.Log("Timed out while attempting to connect to database. Aborted.", LOG_SQL_ERROR)
	end

	util.Log("Connecting to MySQL server...", LOG_SQL)

	-- Try to create the database object
	local dbobj = mysqloo.connect(self.config.Host, self.config.User, self.config.Pass, self.config.Name, self.config.Port)
	if not dbobj then
		util.Log("Couldn't create database object.", LOG_SQL_ERROR)
	end

	-- Set the hooks and try to connect
	function dbobj.onConnected(db)
		util.Log("Connected to '" .. self.config.Name .. "' on " .. db:hostInfo() .. " (MySQL v" .. db:serverInfo() .. ")", LOG_SQL)
		self.db = db
		self.ready = true

		-- cache some info about our connection that we know won't change. this is really only useful for servers that use shared databases
		-- and want to track who inserted what row etc
		-- we'd use GetConVar* but it's unreliable
		local row = sqlUnsafeQuery(self, "SELECT @curHost := SUBSTRING_INDEX(`HOST`,':',1) AS host, @curIP := IF(@curHost = 'localhost', '127.0.0.1', @curIP) AS ip, INET_ATON(@curIP) AS ipnum FROM `information_schema`.`PROCESSLIST` WHERE `ID` = CONNECTION_ID()")[1]
		self.host = row.host
		self.ip = row.ip
		self.ipnum = tonumber(row.ipnum)
	end
	function dbobj.onConnectionFailed(db, err)
		util.Log("Failed connecting to database '" .. self.config.Name .. "': " .. tostring(err), LOG_SQL_ERROR)
		db:delete()
	end

	dbobj:connect()
	dbobj:wait()
end
mysql.Connect = sqlConnect

-- Close the connection to the database
sqlDisconnect = function(self)
	self.db:delete()
	self.db = nil
end
mysql.Disconnect = sqlDisconnect

-- Start an SQL transaction. Don't use this unless you know what you're doing.
sqlBeginTransaction = function(self)
	sqlUnsafeQuery(self, "BEGIN")
end
mysql.BeginTransaction = sqlBeginTransaction

-- Commit the last transaction
sqlCommit = function(self)
	sqlUnsafeQuery(self, "COMMIT")
end
mysql.Commit = sqlCommit

-- Revert an uncommitted transaction
sqlRollback = function(self)
	sqlUnsafeQuery(self, "ROLLBACK")
end
mysql.Rollback = sqlRollback

--[[
	Run a query, escaping arguments and substituting them for ?'s in the
	query string. Table aliases may be used by enclosing one of the keys
	in self.aliases in curly braces.

	Good:
		SQL:Query("SELECT * FROM {MYALIAS} WHERE username LIKE ?", "bob's game")
		=> "SELECT * FROM my_table WHERE username LIKE 'bob\'s game'"
	Bad:
		SQL:Query("SELECT * FROM my_table WHERE username LIKE '" .. args[1] .. "'")
		=> "SELECT * FROM my_table WHERE username LIKE ''; DROP TABLE information_schema; --'"

	If you pass a function in the arguments, the query will be run asynchronously,
	mysql.Query will return nil and the function will be called with any returned data
	as its first argument and any further varargs after it, e.g.

		local function myCallback(data, ply)
			if #data > 0 then
				PrintTable(data)
			end
		end
		SQL:Query("SELECT * FROM {MYTABLE} WHERE username = ?", Entity(1):Nick(), myCallback, Entity(1))
]]
sqlQuery = function(self, query, ...)
	local args = {...}
	local cb, cbargs = nil, {}

	-- Check the args list for a callback.
	for i, arg in ipairs(args) do
		if type(arg) == "function" then
			cb = table.remove(args, i)
			if cb == SQL_NOCALLBACK then break end
			for j = i + 1, #args do
				cbargs[j - i] = table.remove(args, i)
			end
		end
	end
	return sqlUnsafeQuery(self, sqlFormatQuery(self, query, unpack(args)), cb, cb and unpack(cbargs) or nil)
end
mysql.Query = sqlQuery

-- Run a query directly without formatting or escaping. Should only
-- ever be used with literal queries. 90% of the time you'll want
-- dbobj:Query() instead.
-- Good:
--	"SELECT * FROM {USERS} WHERE DATEDIFF(CURDATE(), user_laston) > 15"
-- Bad:
--	"SELECT * FROM {USERS} WHERE user_id = " .. arg[1]
sqlUnsafeQuery = function(self, query, callback, ...)
	-- Make sure we're connected
	if not sqlIsConnected(self) then
		sqlConnect(self)
	end

	-- replace table aliases since we're not using sqlFormatQuery
	query = gsub(query, "{([%w_]-)}", self.aliases)

	local q = self.db:query(query)
	function q:onAborted()
		util.Log("Query [" .. query .. "] aborted.", LOG_SQL_ERROR)
	end
	function q:onError(err, sql)
		util.Log("Query [" .. query .. "] hit error: " .. err, LOG_SQL_ERROR)
	end

	-- Asynchronous query
	if callback then
		-- Only set the hook if we want a callback
		if callback ~= SQL_NOCALLBACK then
			function q:OnSuccess(data)
				callback(data)
			end
		end
		-- Run it, keep going
		q:start()

	-- Blocking query
	else
		q:start()
		q:wait()
		return q:getData()
	end
end
mysql.UnsafeQuery = sqlUnsafeQuery

-- Substitutes question marks in the query string for varargs, replaces table aliases
sqlFormatQuery = function(self, query, ...)
	local args = {...}

	-- Make sure the number of arguments agrees with the number of tokens in the query
	-- NOTE: if you pass a nil as the last argument, this WILL throw an error
	local tokens = 0
	for char in string.gmatch(query, ".") do
		if char == "?" then tokens = tokens + 1 end
	end
	if tokens < #args then
		util.Log("Too many arguments to 'FormatQuery': expected " .. tokens .. ", got " .. #args, LOG_SQL_ERROR)
	elseif tokens > #args then
		util.Log("Too few arguments to 'FormatQuery': expected " .. tokens .. ", got " .. #args, LOG_SQL_ERROR)
	end

	-- replace table aliases
	query = gsub(query, "{([%w_]-)}", self.aliases)

	local i = 1
	query = gsub(query, "%?", function()
		local val = sqlEscape(self, args[i])

		-- tick
		i = i + 1

		return val
	end)

	-- we're done replacing question marks, so substitute any that were
	-- escaped by sqlBuildQuery
	return (gsub(query, "\1", "?"))
end
mysql.FormatQuery = sqlFormatQuery

-- Builds an SQL query from a Lua table, using keys as field names
-- Accepted modes are "insert" and "update", use escapetokens = true if you're
-- running it in a query afterward
-- WARNING: Does not automatically concatenate a WHERE clause
sqlBuildQuery = function(self, mode, tablename, data, escapetokens)
	local query, fields, vals, i = nil, {}, {}, 1
	tablename = gsub(tablename, "{([%w_]-)}", self.aliases)

	if mode == "insert" then
		for k, v in pairs(data) do
			fields[i] = '`' .. k .. '`'
			vals[i] = sqlEscape(self, v)

			i = i + 1
		end
		query = format('INSERT INTO `%s` (%s) VALUES (%s)', tablename, tblconcat(fields, ", "), tblconcat(vals, ", "))

	-- I really hope you're planning on adding a WHERE clause
	elseif mode == "update" then
		for k, v in pairs(data) do
			fields[i] = '`' .. k .. '` = ' .. sqlEscape(self, v)
			i = i + 1
		end
		query = format('UPDATE `%s` SET %s', tablename, tblconcat(fields, ", "))
	end

	-- escape question marks if necessary so we can safely pass it through sqlFormatQuery
	return escapetokens and (gsub(query, "?", "\1")) or query
end
mysql.BuildQuery = sqlBuildQuery

-- Escapes database input -- gets called automatically by sqlFormatQuery
sqlEscape = function(self, val)
	if not sqlIsConnected(self) then
		sqlConnect(self)
	end

	if type(val) == "number" then
		return val
	elseif type(val) == "nil" or val == SQL_NULL then
		return "NULL"
	else
		return "'" .. self.db:escape(tostring(val)) .. "'"
	end
end
mysql.Escape = sqlEscape

-- Check if the database is connected and ready for use
sqlIsConnected = function(self)
	return self.db and self.db:status() == mysqloo.DATABASE_CONNECTED
end
mysql.IsConnected = sqlIsConnected

-- Retrieve the last autoincremented ID number
sqlGetLastInsertID = function(self)
	return tonumber(sqlUnsafeQuery(self, "SELECT LAST_INSERT_ID() AS id")[1].id)
end
mysql.GetLastInsertID = sqlGetLastInsertID

-- Check if a table exists
sqlTableExists = function(self, name)
	-- substitute table aliases
	name = gsub(name, "{([%w_]+)}", self.aliases)
	return (#sqlQuery(self, "SELECT 1 FROM information_schema.tables WHERE table_schema = ? AND table_name = ?", self.config.Database, name) > 0)
end
mysql.TableExists = sqlTableExists
