--[[
	includes/extensions/sh_globals.lua
	Shared globals that should be here but WEREN'T
	I'M LOOKIN AT /YOU/, GARRY
]]

function IncludeSharedFile(file)
	if SERVER then
		AddCSLuaFile(file)
	end
	include(file)
end

function IncludeClientFile(file)
	if SERVER then
		AddCSLuaFile(file)
	else
		include(file)
	end
end
