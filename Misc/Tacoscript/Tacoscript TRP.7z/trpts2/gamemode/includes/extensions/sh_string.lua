--[[
	includes/extensions/sh_string.lua
]]

local strsub = string.sub
local strfind = string.find
local strlen = string.len
local strrep = string.rep
local strmatch = string.match
local gsub = string.gsub
local gmatch = string.gmatch

-- Check if a string starts with a given substring
function string.starts(str, start)
	return strsub(str, 1, strlen(str)) == start
end

-- Check if a string ends with a given substring
function string.ends(str, ending)
	return strsub(str, 1, strlen(str)) == ending
end

function string.pad(num, width, char)
	num = tostring(num)
	return strrep(char or "0", width - #num) .. num
end

function string.trim(str)
	return strmatch(str, "^%s*(.-)%s*$")
end

function string.trimleft(str)
	return strmatch(str, "^%s*(.-)$")
end

function string.trimright(str)
	return strmatch(str, "^(.-)%s*$")
end

-- Escape a string for use in patterns
function string.escape(str)
	return gsub(str, "[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%1")
end

-- Explode a string into an array
function string.explode(str)
	local tbl = {}
	for i = 1, #str do
		tbl[i] = strsub(str, i, i)
	end
	return tbl
end

-- Split a string by a given delimiter, limited to a given number of elements
function string.split(str, delim, limit, multi)
	local tbl, i = {}, 1

	-- Run through the matches. We have to concat the delimiter as well, so we can match
	-- at the end of the string.
	for start, match in gmatch(str .. delim, "()(.-)" .. delim .. (multi and "+" or "")) do
		if i == limit then
			-- This is the last argument we're allowed to return, so dump the rest of the string into it.
			tbl[i] = strsub(str, start)
			break
		end
		tbl[i] = string.trim(match)
		i = i + 1
	end

	return tbl
end

-- Explode a string into substrings by length. Does not break on spaces.
function string.splittolen(str, chars)
	local tbl, i = {}, 1
	local start, finish = 1, #str

	while true do
		-- Add the current substring to the table...
		tbl[i] = strsub(str, start, start + chars - 1)

		-- And move on to the next length
		start = start + chars
		i = i + 1

		-- If we've gone past the end of the string, we're done
		if start > finish then
			break
		end
	end

	return tbl
end

-- Taken from the Lua users wiki ( http://lua-users.org/wiki/StringRecipes )
-- TODO: Needs documentation
local function wrap(str, limit, indent, indent1)
	indent = indent or ""
	indent1 = indent1 or indent
	limit = limit or 72
	local here = 1-#indent1

	return indent1..gsub(str, "(%s+)()(%S+)()", function(sp, st, word, fi)
		if fi-here > limit then
			here = st - #indent
			return "\n"..indent..word
		end
	end)
end

-- Taken from the Lua users wiki ( http://lua-users.org/wiki/StringRecipes ) and modified slightly.
-- TODO: Needs documentation
function string.reflow(str, limit, indent, indent1)
	-- return (str:gsub("%s*\n%s+", "\n")	-- Don't left-trim
	-- return (str:gsub("%s*\n", "\n")
		-- :gsub("%s%s+", " ")		-- Don't collapse whitespace
		return gsub(str, "[^\n]+",
		function(line)
			return wrap(line, limit, indent, indent1)
		end)
	-- )
end
