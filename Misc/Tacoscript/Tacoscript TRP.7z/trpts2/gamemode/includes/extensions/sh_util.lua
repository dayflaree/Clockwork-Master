--[[
	includes/extensions/sh_util.lua
]]

-- Constants
LOG_INFO	= 0		-- Info
LOG_WARN	= 1		-- Warnings
LOG_ERROR	= 2		-- Errors, nonfatal
LOG_FATAL	= 3		-- Errors, fatal

LOG_SQL			= 4		-- SQL queries and notifications
LOG_SQL_ERROR	= 5		-- SQL badnesses

LOG_OOC		= 6		-- OOC chat logs
LOG_IC		= 7		-- Roleplay logs
LOG_ADMIN	= 8		-- Admin actions and notifications

-- Add two colors
function util.AddColors(a, b)
	return Color(
		math.Clamp(a.r + b.r, 0, 255),
		math.Clamp(a.g + b.g, 0, 255),
		math.Clamp(a.b + b.b, 0, 255),
		math.Clamp(a.a + b.a, 0, 255)
	)
end

-- Subtract one color from another
function util.SubtractColors(a, b)
	return Color(
		math.Clamp(a.r - b.r, 0, 255),
		math.Clamp(a.g - b.g, 0, 255),
		math.Clamp(a.b - b.b, 0, 255),
		math.Clamp(a.a - b.a, 0, 255)
	)
end

-- Clamp a color to valid values
function util.ClampColor(color)
	color.r = math.Clamp(color.r or 0, 0, 255)
	color.g = math.Clamp(color.g or 0, 0, 255)
	color.b = math.Clamp(color.b or 0, 0, 255)
	color.a = math.Clamp(color.a or 0, 0, 255)

	return color
end

-- Log text to the specified filenames
function util.WriteLog(text, ...)
	if not text then return end
	local filenames = {...}
	if #filenames == 0 then
		util.Log('Tried to call util.WriteLog() with message "' .. text .. '" but no filenames.', LOG_ERROR)
	else
		local path = util.GetFolderName(true) .. os.date("logs/%Y-%m-%d/")
		local timestamp = os.date("%H:%M:%S ")
		for _, name in pairs(filenames) do
			file.AppendSafe(path .. name, timestamp .. text)
		end
	end
end

-- Log gamemode events, warnings and errors. Mode should be one of the LOG_ constants
function util.Log(msg, mode)
	if not msg or msg == "" then
		-- I'm on the fence whether I consider this an error or a warning, but we want a traceback
		util.Log("Called util.Log() with an empty or nil message.", LOG_ERROR)
		return
	end

	-- Fatal errors
	if mode == LOG_FATAL then
		-- Gets a traceback in errors.txt
		util.WriteLog("[ERROR] " .. msg, "errors.txt", util.GetFolderName() .. ".txt")
		util.WriteLog("[ERROR]" .. string.gsub(debug.traceback(), "\n", "\n" .. os.date("%H:%M:%S ") .. " [ERROR] "), "errors.txt")
		error("[ERROR] " .. msg)

	-- Annoying errors
	elseif mode == LOG_ERROR then
		-- Gets a traceback in errors.txt
		util.WriteLog("[ERROR] " .. msg, "errors.txt", util.GetFolderName() .. ".txt")
		util.WriteLog("[ERROR] " .. string.gsub(debug.traceback(), "\n", "\n" .. os.date("%H:%M:%S ") .. " [ERROR] "), "errors.txt")
		ErrorNoHalt("[ERROR] " .. msg .. "\n")

	-- Warnings
	elseif mode == LOG_WARN then
		util.WriteLog("[WARNING] " .. msg, "warnings.txt", util.GetFolderName() .. ".txt")
		MsgC(Color(255,255,0), "[WARNING] " .. msg .. "\n")

	-- SQL queries and notices
	elseif mode == LOG_SQL then
		util.WriteLog("[SQL] " .. msg, "sql.txt", util.GetFolderName() .. ".txt")
		MsgN("[SQL] " .. msg)
	elseif mode == LOG_SQL_ERROR then
		util.WriteLog("[SQL ERROR] " .. msg, "sql.txt", util.GetFolderName() .. ".txt")
		util.WriteLog("[SQL ERROR] " .. string.gsub(debug.traceback(), "\n", "\n" .. os.date("%H:%M:%S ") .. " [SQL ERROR] "), "sql.txt")
		error("[SQL ERROR] " .. msg)

	elseif mode == LOG_OOC then
		util.WriteLog("[OOC] " .. msg, "chat_ooc.txt", util.GetFolderName() .. ".txt")
	elseif mode == LOG_IC then
		util.WriteLog("[IC] " .. msg, "chat_ic.txt", util.GetFolderName() .. ".txt")
	elseif mode == LOG_ADMIN then
		util.WriteLog("[ADMIN] " .. msg, "admin_actions.txt", util.GetFolderName() .. ".txt")

	-- Everything else. Alternatively, nil
	else
		util.WriteLog("[INFO] " .. msg, "info.txt", util.GetFolderName() .. ".txt")
		MsgN("[INFO] " .. msg)
	end
end

-- Get the gamemode foldername, if possible. Use slash=true if you're using it in a file path
-- instead of adding a slash yourself
function util.GetFolderName(slash)
	if GAMEMODE then
		return GAMEMODE.FolderName .. (slash and "/" or "")
	elseif GM then
		return GM.FolderName .. (slash and "/" or "")
	else
		return ""
	end
end
