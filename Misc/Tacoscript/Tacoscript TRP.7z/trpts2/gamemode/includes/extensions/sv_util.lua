--[[
	includes/extensions/sv_util.lua
]]

-- Convenience function to add clientside Lua files and resources
function resource.AddFileX(path)
	if string.lower(string.sub(path, -4)) == ".lua" then
		AddCSLuaFile(path)
	else
		resource.AddFile(path)
	end
end

-- Recursively add a folder and everything in it
-- exclude should be a string list of file extensions to exclude separated
-- by a consistent delimiter, i.e. "exe dll jpg"
function resource.AddFolder(path, recursive, exclude)
	local files, folders = file.Find(path .. "/*", "GAME")

	-- Add files
	for _, filename in pairs(files) do
		if not exclude or not string.match(exclude, string.GetExtensionFromFilename(filename)) then
			resource.AddFile(path .. "/" .. filename)
		end
	end

	-- Add folders if we're allowed to go deeper
	if recursive then
		for _, folder in pairs(folders) do
			resource.AddFolder(path .. "/" .. folder, recursive, exclude)
		end
	end
end
