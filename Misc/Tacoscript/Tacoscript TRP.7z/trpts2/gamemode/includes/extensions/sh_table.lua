--[[
	includes/extensions/sh_table.lua
]]

-- pushes a value onto the start of the table
-- if limit is specified, any elements beyond the limit will pop off the end:
-- table.push({"bonnie", "carlos", "dianne"}, "andrew", 3) => {"andrew", "bonnie", "carlos"}
function table.push(t, val, limit)

	if val == nil then
		return t
	end

	for i = #t, 1, -1 do
		if limit and i >= limit then
			t[i] = nil
		else
			t[i + 1] = t[i]
		end
	end
	t[1] = val

	return t

end

-- pops the first value from the top of the table
-- table.pop({"andrew, "bonnie", "carlos"}) => {"bonnie", "carlos"}
function table.pop(t)

	for i = 1, #t do
		t[i] = t[i+1]
	end
	return t

end

-- rotates the top num items on the table
-- table.rotate({"andrew", "bonnie", "carlos", "dianne"}, 3)  =>  {"carlos", "andrew", "bonnie", "dianne"}
-- a negative number will rotate backwards:
-- table.rotate({"andrew", "bonnie", "carlos", "dianne"}, 3)  =>  {"bonnie", "carlos", "andrew", "dianne"}
function table.rotate(t, num)

	local last = #t

	if num > 0 then
		-- make sure we don't go off the end of the table
		if num > last then
			num = last
		end
		-- pull values down
		local top = t[num]
		for i = num, 2, -1 do
			t[i] = t[i - 1]
		end
		t[1] = top
	elseif num < 0 then
		num = -num
		if num > last then
			num = last
		end
		-- pull values up
		local bottom = t[1]
		for i = 1, num - 1 do
			t[i] = t[i + 1]
		end
		t[num] = bottom
	end

	return t

end

-- reverses every element in the table
function table.reverse(t)

	local num = #t
	local ret, R = {}, 1

	for i = num, 1, -1 do
		ret[R], R = t[i], R + 1
	end

	for i = 1, num do
		t[i] = ret[i]
	end

	return t

end

function table.merge(to, from, metatable)
	if metatable then
		to = setmetatable(to, getmetatable(from))
	end

	for k, v in pairs(from) do
		to[k] = v
	end

	return to
end

function table.inherit(child, parent, nobase)
	for k, v in pairs(parent) do
		if child[k] == nil then
			child[k] = v
		end
	end

	-- Store the parent if we're allowed to and it's not already set.
	-- I don't know why it would ever be set, but better safe than sorry.
	if not nobase then
		child.__base = parent
	end

	return child
end

-- Returns a deep copy of the given table.
-- Written by PeterPrade ( http://lua-users.org/wiki/PitLibTablestuff ), updated for Lua 5.1+
function table.copy(t, metatable, lookup_table)
	local copy = {}

	if metatable then
		setmetatable(copy, getmetatable(t))
	end

	for k, v in pairs(t) do
		if type(v) ~= "table" then
			copy[k] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[t] = copy
			if lookup_table[v] then
				copy[k] = lookup_table[v] -- we already copied this table. reuse the copy.
			else
				copy[k] = table.copy(v, metatable, lookup_table) -- not yet copied. copy it.
			end
		end
	end
	return copy
end

-- Lua implementation of the Fisher-Yates algorithm by Ludicrous Software
-- http://developer.coronalabs.com/code/shufflerandomize-tables
function table.shuffle(t)
	math.randomseed(os.time());
	local iterations = #t;
	local j;
	for i = iterations, 2, -1 do
		j = math.random(i);
		t[i], t[j] = t[j], t[i];
	end
end

-- Table iterator, ordered by table keys
-- Taken from GMod Lua includes and updated to remove table.insert
local function fnSortedPairs(tbl, index)
	if index == nil then
		index = 1
	else
		for k, v in pairs(tbl.__sortedindex) do
			if v == index then
				index = k + 1
				break
			end
		end
	end

	local key = tbl.__sortedindex[index]
	if not key then
		tbl.__sortedindex = nil
		return
	end

	index = index + 1
	return key, tbl[key]
end

local sortdesc = function(a, b) return a > b end
function sortedpairs(tbl, desc)
	tbl = table.Copy( tbl )

	local sorted, S = {}, 1
	for key, _ in pairs(tbl) do
		sorted[S], S = key, S + 1
	end

	if desc then
		table.sort(sorted, sortdesc)
	else
		table.sort(sorted)
	end
	tbl.__sortedindex = sorted

	return fnSortedPairs, tbl, nil
end
