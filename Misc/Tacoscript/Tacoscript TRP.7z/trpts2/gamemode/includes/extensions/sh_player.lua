--[[
	includes/extensions/sh_player.lua
]]

function player.GetAdmins()
	local tbl, i = {}, 1
	for _, ply in pairs(player.GetAll()) do
		if ply:IsAdmin() then
			tbl[i] = ply
			i = i + 1
		end
	end
	return tbl
end

function player.GetSuperAdmins()
	local tbl, i = {}, 1
	for _, ply in pairs(player.GetAll()) do
		if ply:IsSuperAdmin() then
			tbl[i] = ply
			i = i + 1
		end
	end
	return tbl
end
