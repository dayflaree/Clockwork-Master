--[[
	config.lua
	Server-specific configuration
]]

TS.Config = {}

--------------------
-- ADMIN SETTINGS --
--------------------
TS.Config.RickList = {
	-- Garry
	["STEAM_0:1:7099"] = true
}

-----------------------------
-- LOCAL DATABASE SETTINGS --
-----------------------------
-- Server information
TS.Config.SQLConfig = {
	Host	= "localhost",
	Port	= 3306,
	Name	= "terminator",

	-- User credentials
	User	= "terminator",
	Pass	= ""
}

-- Table aliases, used in SQL queries as "{USERS}" => "trp_users"
TS.Config.SQLAliases = {
	DONATIONS	= "trp_donations",
	CHARACTERS	= "trp_characters",
	USERS		= "trp_users"
}

------------------------------
-- GLOBAL DATABASE SETTINGS --
------------------------------
TS.Config.ServerGroup = 1

-- Server information
TS.Config.GlobalSQLConfig = {
	Host	= "localhost",
	Port	= 3306,
	Name	= "tacoscript2",

	-- User credentials
	User	= "tacoscript2",
	Pass	= ""
}

-- Table aliases, used in SQL queries as "{SERVERS}" => "ts2_servers"
TS.Config.GlobalSQLAliases = {
	SERVERS		= "ts2_servers",
	BANS		= "ts2_bans",
}
