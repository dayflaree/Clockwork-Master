local meta = FindMetaTable("Player")

function meta:SayLocalOOCChat(text)

	local tbl = ents.FindInSphere(self:GetPos(), 256)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v

		end

	end

	self:SendOverlongMessage(TS.MessageTypes.LOOC.id, text, rec)
end

function meta:SayICAction(text, range)

	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	text = string.Trim(text)

	if string.len(text) < 1 then return end

	local tbl = ents.FindInSphere(self:GetPos(), 256 or range)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v

		end

	end

	self:SendOverlongMessage(TS.MessageTypes.ICACTION.id, text, rec)
end

/* Bool - (True) == "/me", (False) == "/me's" */
function meta:DoICAction(text, radius, bool)

	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	if string.len(text) < 1 then return end
	if string.gsub(text, " ", "") == "" then return end

	local tbl = ents.FindInSphere(self:GetPos(), radius)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v
			--v:PrintMessage(2, self:GetRPName() .. text)

		end

	end

	-- Why isn't this logged?
	if bool == true then
		self:SendOverlongMessage(TS.MessageTypes.EMOTE.id, text, rec)
	else
		self:SendOverlongMessage(TS.MessageTypes.EMOTE2.id, text, rec)
	end

end

function meta:WhisperLocalChat(text)

	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	local tbl = ents.FindInSphere(self:GetPos(), 90)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v

		end

	end

	self:SendOverlongMessage(TS.MessageTypes.WHISPER.id, text, rec)
end

function meta:YellLocalChat(text)

	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	local tbl = ents.FindInSphere(self:GetPos(), 600)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v
		end

	end

	self:SendOverlongMessage(TS.MessageTypes.YELL.id, text, rec)
end

function meta:SayLocalChat(text)

	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	local tbl = ents.FindInSphere(self:GetPos(), 256)

	local rec = {}

	for k, v in pairs(tbl) do

		if v:IsPlayer() then

			rec[ #rec + 1 ] = v
			--v:PrintMessage(2, self:GetRPName() .. ": " .. text)

		end

	end

	TS.WriteToChatLog(self:GetRPName() .. "(" .. self:SteamID() .. ") [IC]: " .. text)
	self:SendOverlongMessage(TS.MessageTypes.SAY.id, text, rec)
end

function meta:SayGlobalChat(text)

	if self.Muted then

		self:PrintMessage(3, "You are muted!")
		return ""

	end

	self:SendOverlongMessage(TS.MessageTypes.GOOC.id, text, nil)
end

function meta:TalkToSkyNetRadio(text)

	-- Can't talk when ded
	if not self:Alive() or not self:GetPlayerConscious() then
		return
	end

	-- I assume UDP can use broadcast stuff
	-- anyway, use recipient filters
	local rp = {}

	for k, v in pairs(player.GetAll()) do
		if v.Initialized and (v:CanUseSkynetRadio())  then
			rp[ #rp + 1 ] = v
		end
	end

	self:SendOverlongMessage(TS.MessageTypes.SKYNET.id, text, rp)

end

function meta:SendToEnts(id, text, freq)

	local rf = {}

	for k, v in pairs (TS.WorldRadios) do

		if IsValid(v) then

		local Radio = v.ItemData

			if Radio.IsOn then

				if freq == Radio.Frequency && !Radio.IsTransmitting then
					/* If this radio is recieving a message on the frequency, rather than sending a message...*/

					v:EmitSound("npc/overwatch/radiovoice/off2.wav", 40, 100)

					local tbl = ents.FindInSphere(v:GetPos(), 180)

					for _, pl in pairs (tbl) do

						if pl:IsPlayer() then

							if pl.Initialized then

								rf[ #rf + 1 ] = pl

							end
						/* Add the player to the filter if it is a player. */

						end

					end

				elseif Radio.IsTransmitting then

					v:EmitSound("npc/overwatch/radiovoice/on1.wav", 40, 100) /* Daw :3 */

				end

			end

			Radio.IsTransmitting = false /* We're done here. */

			v.ItemData = Radio

		else

			table.remove(TS.WorldRadios, k) /* You mean nothing to me now! */

		end



	end

	self:SendOverlongMessage(id, text, rf)

end

function meta:SendToRadio(id, text, freq)

	-- didn't I do this already?
	if not self.Initialized or not self:GetPlayerConscious() then
		return
	end

	local rp = {}

	for k, v in pairs(player.GetAll()) do
		if v.Initialized and v.Frequency == freq then
			rp[ #rp + 1 ] = v
			--ErrorNoHalt("\nAdded player: " .. v:Nick() .. " to the main Recipient Filter.\n")
		end
	end

	self:SendOverlongMessage(id, text, rp)

	self:SendToEnts(TS.MessageTypes.RADIOWORLD.id, text, freq)

end

function meta:TalkToRadio(text, freq)
	self:SendToRadio(TS.MessageTypes.RADIO.id, text, freq)
end

function meta:YellToRadio(text)
	self:SendToRadio(TS.MessageTypes.RADIOYELL.id, text)
end

function meta:WhisperToRadio(text)
	self:SendToRadio(TS.MessageTypes.RADIOWHISPER.id, text)
end

function meta:SayGlobalEvent(text)
	self:SendOverlongMessage(TS.MessageTypes.EVENT.id, text, nil)
end

function meta:SayPM(text, rec)
	self:SendOverlongMessage(TS.MessageTypes.PRIVMSG.id, text, rec)
end

if not meta.OrigPrintMessage then
	meta.OrigPrintMessage = meta.PrintMessage
end

function meta:PrintMessage(type, msg)

	if type == 2 then

		meta.OrigPrintMessage(self, type, msg)

	else
		self:SendOverlongMessage(TS.MessageTypes.BLUEMSG.id, msg, self)
	end

end



-- OLM Handling
-- OLM has three part messages:
-- START: tsb; declares the BEGINNING of a message. Contains player id and message id (server)
-- DATA: as many data parts as necessary. Contain the index and the string.
-- END: contain the index and a string.
-- There is ABSOLUTELY NO GUARANTEE that every packet is filled completely
-- or that the first packet is full, etc.
--
-- The protocol was improved. Let's call it OLM 2.0

-- Keep this synced with cl_chat.lua!
-- DO NOT UN-GLOBAL THIS
OLM_MAXLENGTH = 1000

-- Redirect the olm
function meta:ProcessOLM(Message)
	OLM_PlayerSay(self, Message)
end

function RecieveClientMessage(len, ply)
	local Message = net.ReadString()

	if #Message > OLM_MAXLENGTH then
		Message:Sub(1, OLM_MAXLENGTH)
	end

	ply:ProcessOLM(Message)
end

net.Receive("ChatRelay", RecieveClientMessage)

function meta:SendOverlongMessage(id, text, rec)
	SendOverlongMessage(self:EntIndex(), id, text, rec)
end

function SendOverlongMessage(entIndex, id, text, rec)
	net.Start("ChatRelay")
		net.WriteInt(entIndex, 16)
		net.WriteInt(id, 8)
		net.WriteString(text)
	if rec then
		net.Send(rec)
	else
		net.Broadcast()
	end
end


