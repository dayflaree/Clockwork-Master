TS.Flags = {}

/* Args:
name: 		The identifyer for the flag.
loadout: 	A table containing the drone's loadout.
model: 		The model the person is to be set to.
material:	The material the person is to be set to.
scle: 		The scale the person is to be set to.
color: 		The color the person is to be set to.
func: 		(Optional) function called when the player spawns.
skynet:		Is this flag under SkyNET?
footsteps:	Will this flag have metallic footsteps?
density:	How dense is this drone's endo? (Percentage absorb)
event:		Is this drone flag able to use /ev?
drone:		Does this drone flag benefit from the use of SkyNET only plamsa?
*/

function TS.AddDroneFlag (properties)

	if not (properties.ID) then return end

	local obj = {
		ID 			= "",
		Loadout 	= {},
		Model 		= "",
		Material 	= "",
		Scale 		= 1,
		Armor 		= 0,
		Color 		= Color(255, 255, 255, 255),
		IsSkynet	= false,
		Footsteps	= false,
		DR 			= 80,
		Event		= true,
		Drone		= false,
		CanUseRadio = true,
		NoRecoil 	= true,
		IgnoreAmmo = true
	}

	for k, v in pairs (properties) do
		obj[k] = v
	end

	TS.Flags[ obj.ID ] = obj

end

//T-600
TS.AddDroneFlag(
{
	ID = "A",
	Loadout = { "ts2_gatlin", "ts2_f2000" },
	Model = "models/t600/r_t600.mdl",
	-- Scale = 1.225,
	Armor = 800,
	Footsteps = true,
	IsSkynet = true,
	DR = 20, //Reduces 20% ballistic damage, 10% plasma
	Drone = true,
	CanUseRadio = true
})

//T-600 Skinjob
TS.AddDroneFlag(
{
	ID = "B",
	Loadout = { "ts2_gatlin", "ts2_f2000" },
	Model = "models/player/terminator_fatty.mdl",
	-- Scale = 1.2,
	Armor = 800,
	Footsteps = true,
	IsSkynet = true,
	DR = 20, //Reduces 20% ballistic damage, 10% plasma
	Drone = true,
	CanUseRadio = true
})

//T-800
TS.AddDroneFlag(
{
	ID = "C",
	Loadout = { "ts2_40wattm95" },
	Model = "models/player/joazzz/T-800/t800.mdl",
	-- Scale = 1.08,
	Armor = 1000,
	Footsteps = true,
	IsSkynet = true,
	DR = 35, //Reduces 35% ballistic damage, 17.5% plasma
	Drone = true,
	CanUseRadio = true
})

//T-850
TS.AddDroneFlag(
{
	ID = "D",
	Loadout = { "ts2_40wattm95", "ts2_emp" },
	Model = "models/player/joazzz/T-888/t888.mdl",
	-- Scale = 1.03,
	Armor = 1600,
	Footsteps = true,
	IsSkynet = true,
	DR = 50, //Reduces 50% ballistic damage, 25% plasma
	Drone = true,
	CanUseRadio = true
})

//T-882
TS.AddDroneFlag(
{
	ID = "E",
	Loadout = { "ts2_40wattm95", "ts2_70watt", "ts2_emp" },
	Model = "models/player/joazzz/T-882/t882.mdl",
	Scale = 1,
	Armor = 2000,
	Footsteps = true,
	IsSkynet = true,
	DR = 65, //Reduces 65% ballistic damage, 32.5% plasma
	Drone = true,
	CanUseRadio = true
})

//Reprogrammed Drone
TS.AddDroneFlag(
{
	ID = "F",
	Model = "models/player/joazzz/T-800/t800.mdl",
	-- Scale = 1.1,
	Armor = 1950,
	Footsteps = true,
	IsSkynet = false,
	DR = 65, //Reduces 65% ballistic damage, 32.5% plasma
	Drone = true,
	CanUseRadio = false,
	IgnoreAmmo = false,
	OnSpawn = function(ent)

		ent:SetPlayerEndurance(100)
		ent:SetPlayerStrength(100)
		ent:SetPlayerSpeed(100)
		ent:SetPlayerAim(100)

	end,
})

//Reprogrammed Drone (Skinjob)
TS.AddDroneFlag(
{
	ID = "G",
	Scale = 1,
	Armor = 1950,
	IsSkynet = false,
	DR = 65, //Reduces 65% ballistic damage, 32.5% plasma
	Drone = true,
	CanUseRadio = false,
	IgnoreAmmo = false,
	OnSpawn = function(ent)

		ent:SetPlayerEndurance(100)
		ent:SetPlayerStrength(100)
		ent:SetPlayerSpeed(100)
		ent:SetPlayerAim(100)

	end,
})

//Reaver
TS.AddDroneFlag(
{
	ID = "I",
	Model = "models/player/T500R/reaver.mdl",
	-- Scale = 1.1,
	Armor = 500,
	IsSkynet = true,
	DR = 15, //Reduces 15% ballistic damage, 7.5% plasma
	Drone = true,
	CanUseRadio = true,
	OnSpawn = function(ent)

		ent:SetPlayerSpeed(100)

	end,
})

//Widow
TS.AddDroneFlag(
{
	ID = "K",
	Model = "models/player/joazzz/HK-Widow/widow.mdl",
	Armor = 100,
	IsSkynet = true,
	DR = 10, //Reduces 10% ballistic damage, 5% plasma
	Drone = true,
	Color = Color(0, 0, 0, 150),
	CanUseRadio = true,
	OnSpawn = function(ent)

		ent:Give("ts2_widowplasma")

		ent:ScalePlayer(0.5)
		ent:SetHull(Vector(.5 * -14, .5 * -14, 0), Vector(.5 * 14, .5 * 14, 10))
		ent:SetHullDuck(Vector(.5 * -14, .5 * -14, 0), Vector(.5 * 14, .5 * 14, 10))
		ent:SetPlayerSpeed(100)

	end,
})

//T-804
TS.AddDroneFlag(
{
	ID = "L",
	Model = "models/player/joazzz/t-800/t800.mdl",
	Loadout = { "ts2_40wattsniper", "ts2_donator_hk416", "ts2_donator_m14" },
	Armor = 950,
	Scale = 1,
	IsSkynet = true,
	DR = 40, //Reduces 40% ballistic damage, 20% plasma
	Drone = true,
	Color = Color(160, 160, 160, 255),
	CanUseRadio = true
})

//Infiltrator
TS.AddDroneFlag(
{
	ID = "M",
	Armor = 1950,
	Scale = 1,
	IsSkynet = false,
	DR = 75, //Reduces 75% ballistic damage, 37.5% plasma
	Drone = true,
	Color = Color(160, 160, 160, 255),
	CanUseRadio = true,
	OnSpawn = function(ent)

		ent:SetPlayerStrength(100)
		ent:SetPlayerSpeed(100)
		ent:SetPlayerEndurance(100)
		ent:SetPlayerAim(100)

	end
})

//T-800 Skinjob
TS.AddDroneFlag(
{
	ID = "N",
	Loadout = { "ts2_40wattm95" },
	-- Scale = 1.08,
	Armor = 1000,
	Footsteps = true,
	IsSkynet = true,
	DR = 35, //Reduces 35% ballistic damage, 17.5% plasma
	Drone = true,
	CanUseRadio = true
})