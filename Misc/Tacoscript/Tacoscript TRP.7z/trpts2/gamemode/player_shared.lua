local meta = FindMetaTable("Player")

function meta:IsAddingGoodWep(name)

	local BadWeapons =
	{
		"donator",
		"kanyewest",
		"stormninja",
		"hands",
		"base",
		"gatlin",
		"tgun",
		"30gauge",
		"40watt",
		"50watt",
		"styer",
		"60watt",
		"70watt",
		"75watt",
		"god",
		"80watt",
		"85watt",
		"emp",
		"90watt",
		"godfist",
		"rpg7",
		"sniper",
		"styerscout",
		"mapeditor",
		"ziptie",
		"40mm",

	}

	for k, v in pairs(BadWeapons) do

		if string.find(name, v) && not (self:IsSuperAdmin()) then

			return false

		end

	end

	return true

end

-- Safely get a name for a player, even if you don't know if he'll be valid,
-- invalid or worldspawn
-- Use caps=true if you're starting a sentence with the name
function GetRPName(ply, caps)
	if not ply then
		return "<invalid player>"
	elseif ply:EntIndex() == 0 then
		return caps and "Server console" or "server console"
	end
	return ply:GetNWString("RPName")
end

-- Ditto, but for SteamIDs
function GetSteamID(ply)
	return IsValid(ply) and ply:SteamID() or "STEAM_0:0:0"
end

function meta:GetRPName()

	return self:GetNWString("RPName")

end


--Title 1 and title 2 should already be synced as it is sent to the client when
--a person loads or sets their title. If not, get the title via command.
function meta:GetTitle()

	if SERVER then

		return self:GetPlayerTitle()

	else

		if self.PlayerTitle then

			return self.PlayerTitle

		end

		RunConsoleCommand("eng_us", 1, self:EntIndex())
		return ""

	end

end

function meta:IsCitizen()

	if self:Team() == 1 then
		return true
	end

	return false

end

function meta:IsCP()

	if self:Team() == 2 then
		return true
	end

	return false

end

local DoorTypes =
{

	"func_door",
	"func_door_rotating",
	"prop_door_rotating",

}

function meta:IsDoor()

	for k, v in pairs(DoorTypes) do

		if self:GetClass() == v then
			return true
		end

	end

	return false

end

function meta:TSModelChange(modelname)

	if !self.RealModelEnt then
		if SERVER then
		self.RealModelEnt = ents.Create("ts2_model")
		self.RealModelEnt:SetPlayer(self, modelname)
		self.RealModelEnt:Spawn()

		umsg.Start("NWRME")
			umsg.Entity(self.RealModelEnt)
			umsg.Entity(self)
		umsg.End()
		end
	else
		self.RealModelEnt:SetModel(modelname)
	end

end

