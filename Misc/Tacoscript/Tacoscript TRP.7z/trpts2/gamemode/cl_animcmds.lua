function msgSnapOutOfStance(msg)

	local ent = msg:ReadEntity()

	if not ent or not ent:IsValid() then return end

	ent.ForcedAnimationMode = false
	ent.ForcedAnimation = nil

end
usermessage.Hook("SOOS", msgSnapOutOfStance)

function msgHandleSitGround(msg)

	local ent = msg:ReadEntity()

	ent.ForcedAnimationMode = true
	ent.ForcedAnimation = 393

end
usermessage.Hook("HSG", msgHandleSitGround)

function msgHandleSit(msg)

	local ent = msg:ReadEntity()

	ent.ForcedAnimationMode = true
	ent.ForcedAnimation = 395

end
usermessage.Hook("HS", msgHandleSit)

function msgHandleLean(msg)

	local ent = msg:ReadEntity()

	ent.ForcedAnimationMode = true
	ent.ForcedAnimation = 390

end
usermessage.Hook("HL", msgHandleLean)
