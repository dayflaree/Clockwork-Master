TS.HeadBob				= {}

TS.HeadBob.Roll			= 0
TS.HeadBob.Pitch		= 0
TS.HeadBob.Z			= 0
TS.HeadBob.Y			= 0
TS.HeadBob.ForwardPerc	= CreateClientConVar("rp_cl_headbob_forwardpercent", 0.20, true, false)
TS.HeadBob.SidePerc		= CreateClientConVar("rp_cl_headbob_strafepercent", 0.12, true, false)
TS.HeadBob.ZAmt			= 0.3
TS.HeadBob.YAmt			= 0.6
TS.HeadBob.FOVOffset	= 0

TS.HeadBob.FOVAPR		= CreateClientConVar("rp_cl_headbob_fovoffset", 8, true, false)

TS.HeadBob.VelocityCompPitch = CreateClientConVar("rp_cl_headbob_velcomp_pitch", 15, true, false)
TS.HeadBob.VelocityCompYaw = CreateClientConVar("rp_cl_headbob_velcomp_yaw", 30, true, false)

TS.HeadBob.IronsightSway = CreateClientConVar("rp_cl_headbob_ironsights", 0, true, false)
TS.HeadBob.IdleSway = CreateClientConVar("rp_cl_headbob_idlesway", 0, true, false)

TS.HeadBob.Enabled = CreateClientConVar("rp_cl_headbob", "0", true, false)

local Ply = FindMetaTable("Player")

function Ply:GetMovement()
	return (self:KeyDown(IN_FORWARD) || self:KeyDown(IN_BACK) || self:KeyDown(IN_MOVELEFT) || self:KeyDown(IN_MOVERIGHT))
end

function Ply:GetMovementOffset(Direction)
	if Direction then

		if self:KeyDown(IN_MOVELEFT) then
			return -1
		elseif self:KeyDown(IN_MOVERIGHT) then
			return 1
		end
	else
		if self:KeyDown(IN_BACK) then
			return -1
		elseif self:KeyDown(IN_FORWARD) then
			return 1
		end
	end

	return 0
end

function Ply:_GetMovementOffset(Direction)
	local val = self:GetMovementOffset(Direction)

	return (val == (-1) || val == (1))
end

function TS.HeadBob:Call(view)
	self.Velocity = LocalPlayer():GetVelocity():Length()

	local AprVal = ((self.Velocity / 320) * self.FOVAPR:GetInt())

	if LocalPlayer():GetMovement() then
		self.Z = self.Z + (self.Velocity / self.VelocityCompPitch:GetFloat()) * FrameTime()
		self.Y = self.Y + (self.Velocity / self.VelocityCompYaw:GetFloat()) * FrameTime()
		self.ZAmt, self.YAmt = 0.2, 0.4

		if LocalPlayer():KeyDown(IN_SPEED) then
			self.FOVOffset = math.Approach(self.FOVOffset, AprVal, ((AprVal - self.FOVOffset) * FrameTime()) * 6.5)
			self.FOVOffset = math.Clamp (self.FOVOffset, 0, self.FOVAPR:GetInt())
		end
	else
		if self.IdleSway:GetBool() then
			if (self.IronsightSway:GetBool() == false && not (LocalPlayer():KeyDown(IN_ATTACK2))) or self.IronsightSway:GetBool() then
				self.Z = self.Z + 0.5 * FrameTime()
				self.Y = self.Y + 0.9 * FrameTime()
				self.ZAmt, self.YAmt = 0.2, 0.4 //I think you've had one too many beers..
			else
				self.ZAmt, self.YAmt = 0, 0
				self.Z = 0
			end
		else
			self.ZAmt, self.YAmt = 0, 0
			self.Z = 0
		end
	end

	if not (LocalPlayer():KeyDown(IN_SPEED)) then
		self.FOVOffset = math.Approach(self.FOVOffset, 0, ((0 - self.FOVOffset) * FrameTime()) * 6.5)
	end

	if LocalPlayer():_GetMovementOffset(false) then
		self.Pitch = self.Pitch + (LocalPlayer():GetMovementOffset(false) * (self.ForwardPerc:GetFloat() * 1))
		self.Pitch = math.Clamp(self.Pitch, -1.5, 1.5) //Wouldn't want you getting out of control, would we?
	else
		self.Pitch = math.Approach(self.Pitch, 0, 10 * FrameTime()) //Approach zero so the view doesn't jerk about.
	end

	if LocalPlayer():_GetMovementOffset(true) then
		self.Roll = self.Roll + (LocalPlayer():GetMovementOffset(true) * (self.SidePerc:GetFloat() * 1))
		self.Roll = math.Clamp(self.Roll, -1.5, 1.5)
	else
		self.Roll = math.Approach(self.Roll, 0, 10 * FrameTime())
	end

	if LocalPlayer():IsOnGround() then
		view.angles.p = view.angles.p + (math.cos(self.Z) * self.ZAmt)
		view.angles.y = view.angles.y + (math.sin(self.Y) * self.YAmt)
		view.angles.r = view.angles.r + self.Roll * (self.Velocity / 200) //This should be variable!
		view.origin.z = view.origin.z - (math.cos(self.Z) * 0.8) //Why so static?
	end

	view.fov = view.fov + self.FOVOffset
end