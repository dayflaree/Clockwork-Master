local meta = FindMetaTable("Player")

require("mysqloo")

-- mysql = {}

function mysql.connect(host, user, pass, database, port)
    local db = mysqloo.connect(host, user, pass, database, port)
    local succ = nil
    local err = nil

    db.onConnected = function () succ = true end
    db.onConnectionFailed = function (db, errmsg) succ = false err = errmsg; end
    db:connect()
    db:wait()

    return db, succ, err
end

function mysql.disconnect(db)
    db:delete()
    return true
end

function mysql.query(db, sqltext)
	local query = db:query(sqltext)

	query:setOption(mysqloo.OPTION_NUMERIC_FIELDS, true)

	local tab, succ, err
	query.onSuccess = function() succ = true end
	query.onFailure = function(_, msg)
		succ = false
		err = tostring(msg)
		TS.WriteLog("devlogs", 'Query "' .. tostring(sqltext) .. '" failed: ' .. err)
	end
	query.onAborted = function()
		succ = false
		err = "Query aborted"
		TS.WriteLog("devlogs", 'Query "' .. tostring(sqltext) .. '" was aborted.')
	end
	query.onError = function(_, msg)
		succ = false
		err = tostring(msg)
		TS.WriteLog("devlogs", 'Query "' .. tostring(sqltext) .. '" hit error: ' .. err)
	end

	query:start()
	query:wait()
	tab = query:getData()

	return tab, succ, err
end

function mysql.escape(db, txt)
    return db:escape(tostring(txt))
end


function mysql.IsConnected(db)
	local status = db:status()

	if status == mysqloo.DATABASE_NOT_CONNECTED || status == mysqloo.DATABASE_INTERNAL_ERROR then
		return false
	end

	return true
end

function TS.ConnectToSQL()	-- Apparently, this isn't actually used. gg. Check out config.lua instead.

	local host = "76.72.171.19"
	local name = "Scriptsyz"
	local pass = "0110110111010110110101101"
	local database = "testserver"
	local port = 3306
	local succ, err = "", ""

	TS.SQL, succ, err = mysql.connect(host, name, pass, database, port)

	if !mysql.IsConnected(TS.SQL) then

		ErrorNoHalt("Failed connection to SQL: " .. database .. "\n")

	else

		ErrorNoHalt("Successfully connected to SQL: " .. database .. "\n")

	end

end

function TS.PeriodicSave()
	local delay = 0
	for k, v in pairs(player.GetAll()) do
		if v.Initialized and not v.CharacterMenu then
			local function save()
				if IsValid(v) and v.Initialized and not v.CharacterMenu then
					v:CharSave()
				end
			end
			timer.Simple(delay, save)
			delay = delay + 0.1
		end
	end
end
timer.Create("PeriodicSave", 300, 0, TS.PeriodicSave)
-- Change 300 to the number of seconds between saves (300 seconds = 5 min)

function TS.DisconnectFromSQL()

	TS.PeriodicSave()

	mysql.disconnect(TS.SQL)

end

function meta:SetSQLData(name, val)

	if name ~= nil and val ~= nil then

		if self and self:IsValid() then

			self[name] = val

		end

	end

end

function meta:GetSQLData(name)

	if name ~= nil then

		if self and self:IsValid() then

			return self[name]

		end

	end

end

function meta:GetGroupID()

	return tonumber(self:GetSQLData("group_id"))

end