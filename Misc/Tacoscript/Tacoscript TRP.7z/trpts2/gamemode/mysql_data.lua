local meta = FindMetaTable("Player")

function meta:CharExists(name)
	return #TS.SQL:Query("SELECT 1 FROM {CHARACTERS} WHERE userID = ? AND charName = ?", self.UID, name) > 0
end

function meta:CharSaveData(field, value)
	if not field or not value then return end
	TS.SQL:Query("UPDATE {CHARACTERS} SET `" .. field .. "` = ? WHERE userID = ? AND charName = ?", value, self.UID, self:GetRPName())
end

function meta:CharSave()
	-- Get basic character data
	local data = {
		userID			= self.UID,
		charName		= self:GetRPName(),
		charModel		= self.CitizenModel,
		charAge			= self:GetPlayerAge(),
		charDesc		= self:GetPlayerTitle(),
		factionflags	= self.TerminatorFlags,
		playerflags		= self.PlayerFlags,
		charScale		= self.PlayerScale,
		charLastOn		= os.time()
	}

	-- Looping through the stats, because it's easier and we're lazy.
	for k, v in pairs(TS.PlayerStats) do
		data["char" .. v] = self["GetPlayer" .. v](self)
		data["char" .. v .. "Progress"] = self[v .. "Progress"]
	end

	-- Inventories
	local inventories, i = {}, 1
	for k, v in pairs(self.Inventories) do
		inventories[i] = v.Name
		i = i + 1
	end
	data.charInventories = table.concat(inventories, ";")

	-- Items
	local items, i = {}, 1
	for k, inv in pairs(self.Inventories) do
		local name = inv.Name

		-- Grab the current grid and start looping through it
		local grid = self.InventoryGrid[k]
		for x, col in pairs(grid) do
			for y, cell in pairs(col) do
				-- Do we have an item?
				if cell.ItemData then
					-- EXCELLENT. Insert it.
					local item = cell.ItemData
					items[i] = name .. ";" .. item.ID .. ";" .. x .. ";" .. y .. ";" .. (item.Amount or 0)
					i = i + 1
				end
			end
		end
	end
	data.charItems = table.concat(items, ";")

	-- Equipped primary weapon (if possible)
	local pclass = self:GetPlayerPrimaryWeapon()
	local pswep = self:GetWeapon(pclass)
	data.charPrimary = IsValid(pswep) and (pclass .. ";" .. pswep:Clip1()) or ""

	-- Equipped secondary weapon (if possible)
	local sclass = self:GetPlayerSecondaryWeapon()
	local sswep = self:GetWeapon(sclass)
	data.charSecondary = IsValid(sswep) and (sclass .. ";" .. sswep:Clip1()) or ""

	if self:CharExists(self:GetRPName()) then
		TS.SQL:Query(TS.SQL:BuildQuery("update", "{CHARACTERS}", data, true) .. " WHERE charID = ?", self.CharID)
	else
		TS.SQL:Query(TS.SQL:BuildQuery("insert", "{CHARACTERS}", data, true))
		self.CharID = TS.SQL:GetLastInsertID()
	end
end

function meta:CharLoad(name)
	local row = TS.SQL:Query("SELECT * FROM {CHARACTERS} WHERE userID = ? AND charName = ?", self.UID, name)[1]
	if not row then
		util.Log(string.format("OH GOD! Failed loading '%s' for %s (%s) (query returned no rows)!", name, self:Nick(), self:SteamID()), LOG_SQL_ERROR)
	end

	self.CharID = tonumber(row.charID)
	self.CitizenModel = row.charModel

	self:SetPlayerTitle(row.charDesc)

	self.PlayerFlags = row.playerFlags
	self.TerminatorFlags = row.factionFlags

	self:SetPlayerAge(tonumber(row.charAge))
	self.PlayerScale = tonumber(row.charScale)

	for k, v in pairs(TS.PlayerStats) do
		self["SetPlayer" .. v](self, tonumber(row["char" .. v]))
		self[v .. "Progress"] = tonumber(row["char" .. v .. "Progress"])
	end

	-- FIXME
	net.Start("CharDesc")
		net.WriteTable({ self, row.charDesc })
	net.Broadcast()

	-- Load inventories/containers
	local inventories = string.Explode(";", row.charInventories)
	for i = 1, #inventories do
		local inv = inventories[i]

		if string.match(inv, "%S") and TS.Inventories[inv] then
			self:WearItem(TS.Inventories[inv])
		end
	end

	-- Load items
	local items, i, delay = string.Explode(";", row.charItems), 1, 1
	while i < #items do
		if not items[i+4] then return end

		local inv = items[i]
		local item = items[i + 1]
		local x = tonumber(items[i + 2])
		local y = tonumber(items[i + 3])
		local amt = tonumber(items[i + 4])

		if TS.ItemsData[item] and TS.Inventories[inv] then
			if IsValid(self) then
				self:GiveSavedItem(inv, item, x, y, amt)
			end
		end

		i = i + 5
	end

	-- Handle primary/secondary weapon slots
	if #row.charPrimary > 0 then
		local primary = string.Explode(";", row.charPrimary)
		if #primary > 1 and primary[1] ~= "NULL" then
			local class, ammo = primary[1], tonumber(primary[2]) or 0
			self:GiveSavedPrimaryWeapon(class, ammo)

			-- call the hook
			-- FIXME: this should be an on-load hook not an on-equip hook
			local itemdata = TS.ItemsData[ class ]
			if itemdata.OnEquip then
				itemdata:OnEquip(self)
			end
		end
	end
	if #row.charSecondary > 0 then
		local secondary = string.Explode(";", row.charSecondary)
		if #secondary > 1 and secondary[1] ~= "NULL" then
			local class, ammo = secondary[1], tonumber(secondary[2]) or 0
			self:GiveSavedSecondaryWeapon(class, ammo)

			-- call the hook
			-- FIXME: this should be an on-load hook not an on-equip hook
			local itemdata = TS.ItemsData[ class ]
			if itemdata.OnEquip then
				itemdata:OnEquip(self)
			end
		end
	end

	self:MakeNotInvisible()
	self:CallEvent("HorseyMapViewOff")

	--We're initialized and allow the player to move around again
	self.Initialized = true
	self:UnLock()
end

function meta:LoadSQLData()
	-- if he's an admin, we don't bother checking anything
	if self:IsSuperAdmin() then
		for k, v in pairs(self.Limits) do
			self.Limits[k] = 100
		end
		self.Tooltrust = true
		return
	elseif self:IsAdmin() then
		for k, v in pairs(self.Limits) do
			self.Limits[k] = 50
		end
		self.Tooltrust = true
		return
	end

	local row = TS.SQL:Query("SELECT u.userTooltrust, d.maxRagdolls, d.maxProps FROM {USERS} u LEFT JOIN {DONATIONS} d ON d.steamID = u.steamID WHERE u.steamID = ? LIMIT 1", self:SteamID())[1]
	self.Tooltrust = tonumber(row.userTooltrust) == 1

	if self.Tooltrust then
		self.Limits.props = 15
	end

	if row.maxRagdolls then
		self.Limits.ragdolls = tonumber(row.maxRagdolls)
		self.Limits.props = tonumber(row.maxProps)
	end
end

function meta:HandlePlayer()
	local row = TS.SQL:Query("SELECT userID FROM {USERS} WHERE STEAMID = ?", self:SteamID())[1]
	if row then
		self.UID = tonumber(row.userID)
		self:LoadSQLData()

		local function func() self:PromptCharacterMenu() end
		timer.Simple(0.5, func)
	else
		self.Unregistered = true
		local function func() self:PromptQuizMenu() end
		timer.Simple(0.5, func)
	end
end
