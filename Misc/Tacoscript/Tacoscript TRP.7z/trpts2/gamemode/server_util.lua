TS.PropRecords = { }
TS.PlayerRagdolls = { }
TS.ChatCommands = { }

TS.OOCDelay = 0
TS.ChatDelay = .3
TS.LetterCount = 0

function TS.ChatCmd(cmdtext, callback)

	table.insert(TS.ChatCommands, { cmd = cmdtext, cb = callback })

end
function TS.PrintMessageAll(type, msg)

	if type == 2 then

		for k, v in pairs(player.GetAll()) do

			v:PrintMessage(type, msg)

		end

	elseif type == 3 then
		-- Send one message
		SendOverlongMessage(0, TS.MessageTypes.BLUEMSG.id, msg, nil)
	end

end

_G["v721"] = false

function TS.FindPlayerBySteamID(steamid)

	local results = { }

	for k, v in pairs(player.GetAll()) do

		if v:SteamID() == steamid then

			return true, v

		end

	end

	return false, nil

end


function TS.FindPlayerByName(name)

	local results = { }

	for k, v in pairs(player.GetAll()) do

		if v:GetRPName() == name then

			return true, v

		end

		if string.find(v:GetRPName(), name) then

			table.insert(results, v)

		end

	end

	if #results == 1 then

		return true, results[1]

	elseif #results > 1 then

		return false, false

	else

		return false, nil

	end

end

function TS.ErrorMessage(ply, chat, success, result)

	if not success then

		if result == nil then

			Console(ply, "No players found", chat)

		elseif result == false then

			Console(ply, "Multiple players found", chat)

		end

	end

end

function TS.GetKickMessage(server, start, length, reason)

	reason = (not reason or reason == "") and "<no reason given>" or reason
	if length == 0 then
		if server then
			return 'You have been banned from this server: "' .. reason .. '". This ban is permanent.'
		else
			return 'You have been globally banned from this TacoScript2 network: "' .. reason .. '". This ban is permanent.'
		end
	else
		local remaining = math.ceil((start + length - os.time()) / 60)
		if server then
			return 'You have been banned from this server: "' .. reason .. '". This ban will expire in ' .. remaining .. (remaining == 1 and " minute." or " minutes.")
		else
			return 'You have been globally banned from this TacoScript2 network: "' .. reason .. '". This ban will expire in ' .. remaining .. (remaining == 1 and " minute." or " minutes.")
		end
	end

end

function Console(ply, text, chat)

	if ply:EntIndex() == 0 then

		Msg(text .. "\n")

	else

		ply:PrintMessage(2, text)

		if chat then
			ply:PrintMessage(3, text)
		end

	end

end

function table.HasValueWithField(tbl, var, val)

	for k, v in pairs(tbl) do

		if v[var] == val then
			return true
		end

	end

	return false

end

function TS.MakeDirectoryExist(dir)

	if not file.Exists(dir, "DATA") then

		file.CreateDir(dir)

	end

end

function TS.WriteToChatLog(text)
	file.AppendSafe(os.date("TS2/logs/chat/%Y-%m-%d/chatlog.txt"), os.date("%H:%M:%S\t") .. text)
end

function TS.WriteLog(name, text)
	file.AppendSafe("TS2/logs/" .. name .. ".txt", os.date("%H:%M:%S\t") .. text)
end

TS.AmmoTypes = {}

function TS.LoadWeapons()

	local weaps = weapons.GetList()

	for k, v in pairs(weaps) do

		ITEM = nil
		ITEM = { }

		ITEM.ID 			= v.ClassName
		ITEM.Flags 			= "w"
		ITEM.UseDelay 		= 1
		ITEM.PickupDelay 	= .1
		ITEM.Name 			= v.PrintName or ""
		ITEM.Description 	= v.TS2Desc or ""
		ITEM.Model 			= v.WorldModel or ""
		ITEM.CamPos 		= v.IconCamPos or Vector(0, 0, 0)
		ITEM.LookAt 		= v.IconLookAt or Vector(0, 0, 0)
		ITEM.FOV 			= v.IconFOV or 90
		ITEM.Width 			= v.ItemWidth or 1
		ITEM.Height 		= v.ItemHeight or 1
		ITEM.IsPrimary		= v.IsPrimary
		ITEM.AmmoType		= v.AmmoType or "9x19mm"
		ITEM.Maximum		= v.Primary.ClipSize or 1
		ITEM.SkynetOnly		= v.SkynetOnly or false

		if not (v.IsRedPlasma || v.IsBluePlasma) then
			ITEM.AdminOnly	= v.AdminOnly or false
		else
			ITEM.AdminOnly 	= true
		end

		ITEM.Spawnflag		= v.Spawnflag or "X"
		ITEM.Amount			= 0

		v.Primary.DefaultClip = 0

		function ITEM.Pickup(self)

			--self.Owner:Give(self.ID)

		end

		function ITEM.Drop(self)

			if not self.Owner:HasMultipleCopiesOfItem(self.ID) then
				self.Owner:StripWeapon(self.ID)
			end

		end

		ITEM.Use = ITEM.Use or function() end

		TS.ItemsData[ITEM.ID] = ITEM

	end

	TS.FormatedWeaponsToItems = true
	timer.Simple(3, function() TS.WeaponGivingDelay = false end)

end

function TS.LoadPhysgunBans()

	if not TS.PhysgunBans then

		TS.PhysgunBans = { }

	end

	if file.Exists("TS2/data/physgunbans.txt", "DATA") then

		local file = string.Explode(";", file.Read("TS2/data/physgunbans.txt"))

		for k, v in pairs(file) do

			if v then

				table.insert(TS.PhysgunBans, v)

			end

		end

	else

		file.Write("TS2/data/physgunbans.txt", "")
		Msg("Physgunbans.txt not found! Created blank file and skipping physgunban loading!\n")

	end

end