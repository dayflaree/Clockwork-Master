--[[
	config.lua
	Server-specific configuration
]]

TS.Config = {}

--------------------
-- ADMIN SETTINGS --
--------------------
TS.Config.RickList = {
	-- Adv
	["STEAM_0:1:18717157"] = true,
	-- Firehawk
	["STEAM_0:1:12116637"] = true,
	-- Davebrown
	["STEAM_0:0:9103466"] = true,
	-- Hoplite
	["STEAM_0:1:14489810"] = true,
	-- Gangleider
	["STEAM_0:0:13679397"] = true,
	-- Dr. Mr. The Steve Jr., Ph.D
	["STEAM_0:1:19676663"] = true,
}

-----------------------------
-- LOCAL DATABASE SETTINGS --
-----------------------------
-- Server information
TS.Config.SQLConfig = {
	Host	= "127.0.0.1",
	Port	= 3306,
	Name	= "ts2_local_dev",

	-- User credentials
	User	= "root",
	Pass	= ""
}

-- Table aliases, used in SQL queries as "{USERS}" => "trp_users"
TS.Config.SQLAliases = {
	DONATIONS	= "trp_donations",
	CHARACTERS	= "trp_characters",
	USERS		= "trp_users"
}

------------------------------
-- GLOBAL DATABASE SETTINGS --
------------------------------
TS.Config.ServerGroup = 2

-- Server information
TS.Config.GlobalSQLConfig = {
	Host	= "127.0.0.1",
	Port	= 3306,
	Name	= "ts2_global_dev",

	-- User credentials
	User	= "root",
	Pass	= ""
}

-- Table aliases, used in SQL queries as "{SERVERS}" => "ts2_servers"
TS.Config.GlobalSQLAliases = {
	SERVERS		= "ts2_servers",
	BANS		= "ts2_bans",
}
