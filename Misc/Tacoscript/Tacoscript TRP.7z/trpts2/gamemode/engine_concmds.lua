function ShowSpare1Fix(ply)

	ply:ConCommand("gm_showspare1\n")

end
concommand.Add("gm_spare1", ShowSpare1Fix)

function ShowSpare2Fix(ply)

	ply:ConCommand("gm_showspare2\n")

end
concommand.Add("gm_spare2", ShowSpare2Fix)

function CCSetName(ply, cmd, args)

	if not ply.CharacterMenu then
		return
	end

	local name = string.gsub(table.concat(args, " "), "[\r\n\t]", "")
	if #name < 3 or #name > 30 or not string.match(name, "%S") then
		return
	end

	ply.CCName = name

end
concommand.Add("eng_ccsetname", CCSetName)

function CCSetAge(ply, cmd, args)

	if not ply.CharacterMenu then
		return
	end

	if (#args < 1 or not tonumber(args[1])
		or tonumber(args[1]) < 18
		or tonumber(args[1]) > 80) then

		return

	end

	ply.CCAge = tonumber(args[1])


end
concommand.Add("eng_ccsetage", CCSetAge)

function CCSetModel(ply, cmd, args)

	if not ply.CharacterMenu then
		return
	end

	if (#args < 1 or args[1] == ""
		or not table.HasValue(TS.SelectablePlayerModels, args[1])) then

		return

	end

	ply.CCModel = args[1]

end
concommand.Add("eng_ccsetmodel", CCSetModel)

function CCSetStats(ply, cmd, args)

	if not ply.CharacterMenu then
		return
	end

	if (tonumber(args[1]) >= 61 or
		tonumber(args[2]) >= 61 or
		tonumber(args[3]) >= 61 or
		tonumber(args[4]) >= 61) then

		return

	end

	ply.CCStrength = tonumber(args[1])
	ply.CCEndurance = tonumber(args[2])
	ply.CCSpeed = tonumber(args[3])
	ply.CCAim = tonumber(args[4])

end
concommand.Add("eng_ccsetstats", CCSetStats)

function ccCreateCharacter(ply, cmd, args)

	if CurTime() - ply.LastCharCreation < 3 then
		return
	end

	if (not ply.CCName or
		not ply.CCModel or
		not ply.CCAge) then

		return

	end

	local data = TS.SQL:Query("SELECT charName FROM {CHARACTERS} WHERE userID = ?", ply.UID)

	-- Reached his char limit?
	if #data >= MAX_CHARACTERS then
		umsg.Start("MC", ply)
		umsg.End()
		return
	end

	-- Duplicate character?
	for k, row in pairs(data) do
		if string.lower(row.charName) == string.lower(ply.CCName) then
			umsg.Start("DC", ply)
			umsg.End()
			return
		end
	end

	ply:SetNWString("RPName", ply.CCName)
	ply.CitizenModel = ply.CCModel
	ply:SetPlayerAge(ply.CCAge)

	if (ply.CCStrength and
		ply.CCEndurance and
		ply.CCSpeed and
		ply.CCAim) then

		ply:SetPlayerStrength(ply.CCStrength)
		ply:SetPlayerSpeed(ply.CCSpeed)
		ply:SetPlayerEndurance(ply.CCEndurance)
		ply:SetPlayerAim(ply.CCAim)
		ply:SetPlayerTitle("")
	end

	net.Start("CharDesc")
		net.WriteTable({ply, ""})
	net.Broadcast()

	ply.TerminatorFlags = ""
	ply.PlayerFlags = ""
	ply.Frequency = 0

	if not ply.HasSeenMOTD then

		ply.CanInitialize = true
		ply:PromptMOTD()

	else

		ply:CharacterInitialize()

	end

	ply:RemoveCharacterMenu()

	ply.CharacterMenu = false
	ply.LastCharCreation = CurTime()

end
concommand.Add("eng_createcharacter", ccCreateCharacter)

function CCSelectCharacter(ply, cmd, args)

	if #args < 1 then return end

	if CurTime() - ply.LastCharSelection < 2 then
		return
	end

	if ply:CharExists(args[1]) then

		ply.CCModel = "models/odessa.mdl"
		ply:SetNWString("RPName", args[1])
		ply.CitizenModel = ply.CCModel

		if not ply.HasSeenMOTD then

			ply.CanInitialize = true
			ply:PromptMOTD()

		else

			ply:CharacterInitialize()

		end

		ply:RemoveCharacterMenu()
		ply.CharacterMenu = false

	end

	ply.LastCharSelection = CurTime()

end
concommand.Add("eng_selectchar", CCSelectCharacter)

function CloseMOTD(ply, cmd, arg)

	if (not ply.Initialized and
		ply.CanInitialize) then

		umsg.Start("FIFO", ply)
			umsg.Float(4)
		umsg.End()

		timer.Simple(1, function() ply:CharacterInitialize() end)

	end

end
concommand.Add("rp_closemotd", CloseMOTD)

function ccIsTyping(ply, cmd, arg)

	ply:SetNWBool("IsTyping", true)

end
concommand.Add("eng_istyping", ccIsTyping)

function ccIsNotTyping(ply, cmd, arg)

	ply:SetNWBool("IsTyping", false)

end
concommand.Add("eng_isnottyping", ccIsNotTyping)

function ccReceiveItemInfo(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		ply:Disconnect()
		return
	end

	local ent = ents.GetByIndex(tonumber(arg[1]))

	if not ent or not ent:IsValid() then return end

	if not ent.ItemID then return end

	if ply.SendItemNames[ent:EntIndex()] then

		if (ply.SendItemNames[ent:EntIndex()].id == ent.ItemID and
			ply.SendItemNames[ent:EntIndex()].fid == ent.IFID) then
			return
		end

	end

	ply.SendItemNames[ent:EntIndex()] = { id = ent.ItemID, fid = ent.IFID }

	umsg.Start("RIHI", ply)
		umsg.Short(tonumber(arg[1]))
		umsg.String(ent.ItemData.Name or "")
	umsg.End()

end
concommand.Add("eng_reciteminfo",  ccReceiveItemInfo)

function ccInventoryDropItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) or not tonumber(arg[4]) then
		return
	end

	if ply.IsTied then return end

	local id = arg[1]
	local iid = tonumber(arg[2])
	local x = tonumber(arg[3])
	local y = tonumber(arg[4])

	if id == "radio" then ply.Frequency = 0; end

	local inv = ply.InventoryGrid

	if inv && inv[iid] && inv[iid][x] && inv[iid][y][y] then
		inv = ply.InventoryGrid[iid][x][y]

		if inv && not inv.Filled then return end

		local dropitemthink = function(ply, done)

			if done then

				if not ply.InventoryGrid[iid][x][y].Filled then return end
				if not ply.InventoryGrid[iid][x][y].ItemData then return end

				ply.InventoryGrid[iid][x][y].ItemData.Owner = ply

				if ply.InventoryGrid[iid][x][y].ItemData.Drop then
					ply.InventoryGrid[iid][x][y].ItemData:Drop()
				end
				local data = { }

				for k, v in pairs(ply.InventoryGrid[iid][x][y].ItemData) do

					data[k] = v

				end

				DestroyProcessBar("dropitem", ply)
				ply:TakeItemAt(iid, x, y)

				local ent = ply:DropItemProp(id)
				ent.ItemData = data

				ply:CharSave()
				return

			end

		end
		CreateProcessBar("dropitem", "Dropping item", ply)
			SetEstimatedTime(.5, ply)
			SetThinkDelay(.25, ply)
			SetThink(dropitemthink, ply)
		EndProcessBar(ply)
	end

end
concommand.Add("eng_invdropitem", ccInventoryDropItem)

function ccInventoryTakeInventoryStorageItem(ply, cmd, arg)

	if #arg ~= 7 then
		return
	end

	if ply.IsTied then return end

	local id = arg[1]
	local iid = tonumber(arg[2])
	local x = tonumber(arg[3])
	local y = tonumber(arg[4])
	local i_id = arg[5]
	local i_x = tonumber(arg[6])
	local i_y = tonumber(arg[7])

	if not ply.InventoryGrid[iid][x][y].Filled then return end
	if ply.InventoryGrid[iid][x][y].ItemData.ID ~= id then return end
	if not ply.InventoryGrid[iid][x][y].ItemData:IsContainer() then return end

	local Container = ply.InventoryGrid[iid][x][y]

	if ply:CanItemFitInAnyInventory(i_id) then

		local Amount = Container.Amount

		Container.ItemData:RemoveItemAt(i_x, i_y, ply)
		ply:GiveAnyInventoryItem(i_id, Amount)

		ply:CharSave()

	end

end
concommand.Add("eng_invtakeinvstoritem", ccInventoryTakeInventoryStorageItem)

function ccInventoryTakeStorageItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) then
		return
	end

	if ply.IsTied then return end

	local id = arg[1]
	local x = tonumber(arg[2])
	local y = tonumber(arg[3])

	local ent = ply.StorageEntity

	if not ent or not ent:IsValid() then
		return
	end

	if (ent:GetPos() - ply:GetPos()):Length() > 90 then
		ply.StorageEntity = nil
		return
	end

	local takeitemthink = function(ply, done)

		if done then

			if (ply.StorageEntity and
				ply.StorageEntity:IsValid()) then

				local StorageGrid = ent.ItemData.InventoryGrid[x][y]

				local ent = ply.StorageEntity

				if (StorageGrid.ItemData and StorageGrid.ItemData.ID == id  and
					ply:CanItemFitInAnyInventory(id)) then

					ply:GiveAnyInventoryItem(StorageGrid.ItemData, StorageGrid.Amount)

					ent.ItemData:RemoveItemAt(x, y)

					ply:CharSave()

				end

			end

			DestroyProcessBar("takeitem", ply)

			return

		end

	end

	CreateProcessBar("takeitem", "Taking item", ply)
		SetEstimatedTime(.3, ply)
		SetThinkDelay(.3, ply)
		SetThink(takeitemthink, ply)
	EndProcessBar(ply)


end
concommand.Add("eng_invtakestorageitem", ccInventoryTakeStorageItem)

function ccInventoryUseItemPortion(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) or not tonumber(arg[4]) then
		return
	end

	if ply.IsTied then return end

	local id = arg[1]
	local iid = tonumber(arg[2])
	local x = tonumber(arg[3])
	local y = tonumber(arg[4])

	if not ply.InventoryGrid[iid][x][y].Filled then return end

	local useitemthink = function(ply, done)

		if done then

			ply.InventoryGrid[iid][x][y].ItemData.Owner = ply
			ply.InventoryGrid[iid][x][y].ItemData.Use(ply.InventoryGrid[iid][x][y].ItemData)
			ply.InventoryGrid[iid][x][y].ItemData.Amount = ply.InventoryGrid[iid][x][y].ItemData.Amount - 1

			DestroyProcessBar("useitem", ply)

			if ply.InventoryGrid[iid][x][y].ItemData.Amount < 1 then

				if (not arg[5] or tonumber(arg[5]) ~= 1) and ply.InventoryGrid[iid][x][y].ItemData.CanDrop(ply.InventoryGrid[iid][x][y].ItemData) then
					ply:TakeItemAt(iid, x, y)
				end

			else

				umsg.Start("UIA", ply)
					umsg.Short(iid)
					umsg.Short(x)
					umsg.Short(y)
					umsg.Short(ply.InventoryGrid[iid][x][y].ItemData.Amount)
				umsg.End()

			end

			return

		end

	end

	CreateProcessBar("useitem", "Using item", ply)
		SetEstimatedTime(ply.InventoryGrid[iid][x][y].ItemData.UseDelay * .4, ply)
		SetThinkDelay(.05, ply)
		SetThink(useitemthink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_invuseitemportion", ccInventoryUseItemPortion)

--[[ Calls the use hook of an item, and deducts one of the item's stack. ]]--
function ccInventoryUseItem(ply, cmd, arg)
	if not (#arg) == 4 then return end

	--[[ Prepare our data to be used. ]]--
	local id, iid, x, y = unpack(arg)
	iid, x, y = tonumber(iid), tonumber(x), tonumber(y)

	local Inventory = ply.InventoryGrid[iid]

	--[[ Make sure the player can use an item, and that the item even exists. ]]--
	if ply.IsTied || not ply:ValidInventory( iid, x, y) then return end

	local Grid = Inventory[x][y].ItemData

	--[[ Does the Grid exist with the specified item? If not, maybe desync or potential explot? ]]--
	if not (Grid && Grid.ID == id) then return end

	local function UseItem(ply, done)
		if done then
			Grid.Owner = ply
			Grid:Use()

			if Grid.Amount > 0 then
				ply:ModifyItemAmount(iid, x, y, Grid.Amount - 1)
			end
			if Grid.Amount == 0 then
				ply:TakeItemAt(iid, x, y)
			end

			ply:CharSave()

			DestroyProcessBar("useitem", ply)
			return
		end
	end

	CreateProcessBar("useitem", "Using item", ply)
		SetEstimatedTime(Grid.UseDelay, ply)
		SetThinkDelay(.3, ply)
		SetThink(UseItem, ply)
	EndProcessBar(ply)
end
concommand.Add("eng_invuseitem", ccInventoryUseItem)

function ccInventoryAddStorageItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) or not tonumber(arg[4]) then
		return
	end

	local id, iid, x, y = unpack(arg)
	iid, x, y = tonumber(iid), tonumber(x), tonumber(y)

	local Inventory = ply.InventoryGrid[iid]

	--[[ Make sure the player can add an item, or isn't on a cooldown. ]]--
	if ply.IsTied || (CurTime() - ply.LastStorageItemAdd) < 1 then return end
	ply.LastStorageItemAdd = CurTime()

	--[[ Get our Container handle and make sure it's valid. ]]--
	local Container = ply.StorageEntity
	if not Container || not IsValid(Container) then return end

	--[[ Make sure the player is close enough to the container. ]]--
	if (Container:GetPos() - ply:GetPos()):Length() > 90 then
		ply.StorageEntity = nil
		return
	end
	Container = Container.ItemData

	--[[ Alert the client if the container is full. ]]--
	if not Container:CanItemFitInInventory(id) then
		umsg.Start("NRIS", ply)
		umsg.End()
		return
	end

	--[[ String flags are the worst. Jesus. ]]--
	local flagtable = string.ToTable(TS.ItemsData[id].Flags)
	for i = 1, #flagtable do
		local flag = flagtable[i]

		--[[ We can't add containers to other containers ]]--
		if flag == "C" || flag == "^" then
			return
		end
	end

	local Grid = Inventory[x][y].ItemData

	if not (Grid && Grid.ID == id) then return end

	local function AddItem(ply, done)
		if done then
			if Container:CanItemFitInInventory(id) then
				Container:GiveInventoryItem(Grid, Grid.Amount)
				ply:TakeItemAt(iid, x, y)

				ply:CharSave()
			else
				umsg.Start("NRIS", ply)
				umsg.End()
			end

			DestroyProcessBar("additem", ply)
			return
		end
	end

	CreateProcessBar("additem", "Adding item to storage", ply)
		SetEstimatedTime(.3, ply)
		SetThinkDelay(.3, ply)
		SetThink(AddItem, ply)
	EndProcessBar(ply)
end
concommand.Add("eng_invaddstorage", ccInventoryAddStorageItem)


--Removed old one, used TacoScript 1's method for donation models
function ccInventoryPutOnStorage(ply, cmd, arg)

	if not arg[1] then return end

	if ply.IsTied then return end

	local name = arg[1]

	if not ply:HasInventory(name) then return end

	if name == "Backpack" then
		return
	end

	local iid = ply:GetInventoryIndex(name)

	if ply.Inventories[iid].Permanent then
		return
	end

	local putonstoragethink = function(ply, done)

		if done then

			if ply:HasInventory(name) then

				if name == "Rebel vest" then

					ply.HelmetHealth = 10
					if ply:HasTerminatorFlag("E") then
						ply.BodyArmorHealth = 1950
					else
						ply.BodyArmorHealth = 40
					end
					local model = string.lower(ply.RealModelEnt:GetModel())
					model = string.gsub(model, "group03m", "group03")
					model = string.gsub(model, "group02", "group03")
					model = string.gsub(model, "group01", "group03")

					ply:SetModel(model)

				elseif name == "Rebel medic vest" then

					ply.HelmetHealth = 10
					if ply:HasTerminatorFlag("E") then
						ply.BodyArmorHealth = 1950
					else
						ply.BodyArmorHealth = 40
					end

					local model = string.lower(ply.RealModelEnt:GetModel())
					model = string.gsub(model, "group03", "group03m")
					model = string.gsub(model, "group02", "group03m")
					model = string.gsub(model, "group01", "group03m")

					ply:SetModel(model)

				end

			end
			ply:SetPlayerMaxArmor(ply.BodyArmorHealth)
			ply:SetPlayerCurrentArmor(ply.BodyArmorHealth)

			DestroyProcessBar("putonstorage", ply)
			return

		end

	end

	CreateProcessBar("putonstorage", "Putting on", ply)
		SetEstimatedTime(2, ply)
		SetThinkDelay(.25, ply)
		SetThink(putonstoragethink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_putonstorage", ccInventoryPutOnStorage)

function ccInventoryTakeOffStorage(ply, cmd, arg)

	if not arg[1] then
		return
	end

	if ply.IsTied then return end

	local name = arg[1]

	if name == "Backpack" then
		return
	end

	if not ply:HasInventory(name) then return end

	local iid = ply:GetInventoryIndex(name)

	if ply.Inventories[iid].Permanent then
		return
	end

	local takeoffstoragethink = function(ply, done)

		if done then

			if ply:HasInventory(name) then

				ply:SetModel(ply.CitizenModel)
				ply.HelmetHealth = 0
				ply.BodyArmorHealth = 0
				ply:SetPlayerCurrentArmor(0)
				ply:SetPlayerMaxArmor(0)

			end

			DestroyProcessBar("takeoffstorage", ply)
			return

		end

	end

	CreateProcessBar("takeoffstorage", "Undressing", ply)
		SetEstimatedTime(2, ply)
		SetThinkDelay(.25, ply)
		SetThink(takeoffstoragethink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_takeoffstorage", ccInventoryTakeOffStorage)

function ccInventoryDropStorage(ply, cmd, arg)

	if not arg[1] then
		return
	end

	if ply.IsTied then return end

	local name = arg[1]

	if not ply:HasInventory(name) then return end

	local iid = ply:GetInventoryIndex(name)

	if ply.Inventories[iid].Permanent then
		return
	end

	local dropstoragethink = function(ply, done)

		if done then

			if ply.Inventories[iid].IsClothes and ply.Inventories[iid].CanDrop then

				if ply.Inventories[iid].OnDrop then
					ply.Inventories[iid]:OnDrop(ply)
				end

				DestroyProcessBar("dropstorage", ply)
				ply:DropClothes()
				ply:SetModel(ply.CitizenModel)
				ply:WearItem("clothes_citizen")
				ply.HelmetHealth = 0
				ply.BodyArmorHealth = 0
				ply:SetPlayerMaxArmor(0)
				return

			end

			if ply:HasInventory(name) then

				local itemprop = ply:DropItemProp(ply.Inventories[iid].ID)
				itemprop = TS.ItemToContainer(itemprop.ItemData)

				local itemdata = TS.ItemsData[ply.Inventories[iid].ID]
				local inv = 0

				local activeweapx = -1
				local activeweapy = -1

				for k = 0, itemdata.Height - 1 do

					for j = 0, itemdata.Width - 1 do

						local port = true

						if (ply.InventoryGrid[iid][j][k].x == activeweapx and
							ply.InventoryGrid[iid][j][k].y == activeweapy) then

							port = false

						end

						if ply.InventoryGrid[iid][j][k].ItemData and ply:GetActiveWeapon():IsValid() then

							if ply.InventoryGrid[iid][j][k].ItemData.ID == ply:GetActiveWeapon():GetClass() then

								if ply:HasWeaponOnlyFrom(ply.InventoryGrid[iid][j][k].ItemData.ID, iid) then

									port = false

									activeweapx = ply.InventoryGrid[iid][j][k].x
									activeweapy = ply.InventoryGrid[iid][j][k].y

									if not ply:GiveAnyInventoryItemBut(ply.InventoryGrid[iid][j][k].ItemData.ID, iid) then

										ply.HasTempWeapon = true
										ply.TempWeaponClass = ply:GetActiveWeapon():GetClass()


									end

									ply.InventoryGrid[iid][j][k].ItemData = nil

								end

							end

						end

						if port then

							itemprop.InventoryGrid[j][k].Filled = ply.InventoryGrid[iid][j][k].Filled
							itemprop.InventoryGrid[j][k].SX = ply.InventoryGrid[iid][j][k].x
							itemprop.InventoryGrid[j][k].SY = ply.InventoryGrid[iid][j][k].y
							itemprop.InventoryGrid[j][k].ItemData  = ply.InventoryGrid[iid][j][k].ItemData

						else

							itemprop.InventoryGrid[j][k].Filled = false
							itemprop.InventoryGrid[j][k].SX = -1
							itemprop.InventoryGrid[j][k].SY = -1
							itemprop.InventoryGrid[j][k].ItemData = nil

						end

					end

				end

				ply:RemoveInventory(itemdata.Name)

			end

			DestroyProcessBar("dropstorage", ply)

			return

		end

	end

	CreateProcessBar("dropstorage", "Dropping storage item", ply)
		SetEstimatedTime(.7, ply)
		SetThinkDelay(.25, ply)
		SetThink(dropstoragethink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_invdropstorage", ccInventoryDropStorage)

function ccInventoryWriteItem(ply, cmd, arg)

	if not tonumber(arg[1]) or not tonumber(arg[2]) or not tonumber(arg[3]) then
		return
	end

	if ply.IsTied then return end

	local id = "paper"
	local iid = tonumber(arg[1])
	local x = tonumber(arg[2])
	local y = tonumber(arg[3])

	if not ply.InventoryGrid[iid][x][y].Filled then return end
	if ply.InventoryGrid[iid][x][y].ItemData.ID ~= "paper" then return end

	ply.SelectedPaper = { Inv = iid, x = x, y = y }

	umsg.Start("LWP", ply)
		umsg.String("")
	umsg.End()

end
concommand.Add("eng_invwriteitem", ccInventoryWriteItem)

function ccActionMenuPickupContainer(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	if not string.find(ent.ItemData.Flags, "c") then return end

	if ply:HasContainer(ent.ItemData.Name) then

		ply:PrintMessage(3, "You already have one")
		return

	end

	local pickupitemthink = function(ply, done)

		if not ent or not ent:IsValid() then

			DestroyProcessBar("pickupitem", ply)
			return

		end

		if done then

			if not ply:HasContainer(ent.ItemData.Name) then

				if ent.ItemData.ID == "backpack" then
					ply.BackEntity = ply:AttachProp(ent:GetModel(), "chest")
				end

				ply:GiveContainerEntity(ent, false, true)

			end

			DestroyProcessBar("pickupitem", ply)
			ent:Remove()
			return

		end

		local crntdist = (ent:GetPos() - ply:GetPos()):Length()

		if crntdist > 90 then

			DestroyProcessBar("pickupitem", ply)
			return

		end

	end

	CreateProcessBar("pickupitem", "Picking up item", ply)
		SetEstimatedTime(ent.ItemData.PickupDelay, ply)
		SetThinkDelay(.1, ply)
		SetThink(pickupitemthink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_ampickupcontainer", ccActionMenuPickupContainer)

function ccActionMenuLookInsideContainer(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	if not string.find(ent.ItemData.Flags, "c") and not string.find(ent.ItemData.Flags, "W") then return end

	local Container = ent.ItemData

	if not (Container:IsWhitelisted(ply)) then
		ply:PrintMessage(3, "Unable to interact with this item!")
		return
	end

	ply:OpenStorageMenu(ent)

end
concommand.Add("eng_amlookinsidecontainer", ccActionMenuLookInsideContainer)

function ccInventoryLookInsideContainer(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[2]) or not tonumber(arg[3]) or not tonumber(arg[4]) then
		return
	end

	if ply.IsTied then return end

	local id = arg[1]
	local iid = tonumber(arg[2])
	local x = tonumber(arg[3])
	local y = tonumber(arg[4])

	if not ply.InventoryGrid[iid][x][y].Filled then return end
	if ply.InventoryGrid[iid][x][y].ItemData.ID ~= id then return end

	if not string.find(ply.InventoryGrid[iid][x][y].ItemData.Flags, "C") and not string.find(ply.InventoryGrid[iid][x][y].ItemData.Flags, "c") and not string.find(ply.InventoryGrid[iid][x][y].ItemData.Flags, "W") then return end

	local Container = ent.ItemData

	if not (Container:IsWhitelisted(ply)) then
		ply:PrintMessage(3, "Unable to interact with this item!")
		return
	end

	ply:OpenStorageMenu(ply.InventoryGrid[iid][x][y].ItemData)

end
concommand.Add("eng_invlookinsidecontainer", ccInventoryLookInsideContainer)

function ccActionMenuReadItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	if not string.find(ent.ItemData.Flags, "l") then return end

	ent.ItemData.Owner = ply
	ent.ItemData.Use(ent.ItemData)

end
concommand.Add("eng_amreaditem", ccActionMenuReadItem)

function ccActionMenuUseItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	local useitemthink = function(ply, done)

		local ent = ply.ActionMenuTarget

		if not ent or not ent:IsValid() then

			DestroyProcessBar("useitem", ply)
			return

		end

		if done then

			ent.ItemData.Owner = ply
			ent.ItemData.Use(ent.ItemData, ent)

			DestroyProcessBar("useitem", ply)

			if not (ent.ItemData.NonConsumable) then
				ent:Remove()
			end

			return

		end

		local crntdist = (ent:GetPos() - ply:GetPos()):Length()

		if ply.DistanceFromItem < crntdist then

			DestroyProcessBar("useitem", ply)
			return

		end

	end

	CreateProcessBar("useitem", ent.ItemData.ProgressName or "Using item", ply)
		SetEstimatedTime(ent.ItemData.UseDelay, ply)
		SetThinkDelay(ent.ItemData.ProgressThink or .3, ply)
		SetThink(useitemthink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_amuseitem", ccActionMenuUseItem)


function ccActionMenuExamineItem(ply, cmd, arg)

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	ply:PrintMessage(3, ent.ItemData.Name)

	local Description = ent.ItemData.Description

	if ent.ItemData.RequestDescription then
		Description = ent.ItemData:RequestDescription()
	end

	ply:PrintMessage(3, Description)

end
concommand.Add("eng_examineitem", ccActionMenuExamineItem)

function ccActionMenuWearItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	if not ply:IsCitizen() then
		return
	end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	local wearitemthink = function(ply, done)

		local ent = ply.ActionMenuTarget

		if not ent or not ent:IsValid() then

			DestroyProcessBar("wearitem", ply)
			return

		end

		if done then

			DestroyProcessBar("wearitem", ply)

			if ent.ItemData.OnWearItem then
				ent.ItemData:OnWearItem(ply)
			end

			ent.ItemData.Owner = ply
			ent.ItemData.Use(ent.ItemData)

			if not (ent.ItemData.NotClothing) then
				ply:DropClothes()
			end

			ply:WearItem(ent.ItemData)

			if ent.ItemData.ID == "backpack" then
				ply.BackEntity = ply:AttachProp(ent:GetModel(), "chest")
			end

			ent:Remove()
			return

		end

		if not ply:IsCitizen() then
			DestroyProcessBar("wearitem", ply)
			return
		end

		local crntdist = (ent:GetPos() - ply:GetPos()):Length()

		if ply.DistanceFromItem < crntdist then

			DestroyProcessBar("wearitem", ply)
			return

		end

	end

	CreateProcessBar("wearitem", "Wearing item", ply)
		SetEstimatedTime(ent.ItemData.UseDelay, ply)
		SetThinkDelay(.3, ply)
		SetThink(wearitemthink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_amwearitem", ccActionMenuWearItem)

function ccPickupItem(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

	local pickupitemthink = function(ply, done)

		local ent = ply.ActionMenuTarget

		if not ent or not ent:IsValid() then

			DestroyProcessBar("pickupitem", ply)
			return

		end

		if done then

			ply:GiveInventoryItem(id, ent.ItemData)
			DestroyProcessBar("pickupitem", ply)
			ent:Remove()

			ply:CharSave()
			return

		end

		local crntdist = (ent:GetPos() - ply:GetPos()):Length()

		if ply.DistanceFromItem < crntdist then

			DestroyProcessBar("pickupitem", ply)
			return

		end

	end

	local pickupdelay = ent.ItemData.PickupDelay

	if string.find(ent.ItemData.Flags, "w") then

		pickupdelay = .5

	end

	CreateProcessBar("pickupitem", "Picking up item", ply)
		SetEstimatedTime(pickupdelay, ply)
		SetThinkDelay(.1, ply)
		SetThink(pickupitemthink, ply)
	EndProcessBar(ply)

end
concommand.Add("eng_pickupitem", ccPickupItem)

function ccHideViewModel(ply, cmd, arg)

	ply:DrawViewModel(false)

end
concommand.Add("eng_hideviewmodel", ccHideViewModel)

function ccStartLetter(ply, cmd, arg)

	ply.LetterContent = ""

end
concommand.Add("eng_sl", ccStartLetter)

function ccSendLetterPiece(ply, cmd, arg)

	if not arg[1] then return end

	if string.len(ply.LetterContent) >= 1024 then return end

	ply.LetterContent = ply.LetterContent .. arg[1]

end
concommand.Add("eng_slp", ccSendLetterPiece)

function ccEndLetter(ply, cmd, arg)

	if ply.IsTied then return end

	local inv = ply.SelectedPaper.Inv
	local x = ply.SelectedPaper.x
	local y = ply.SelectedPaper.y

	if not inv or not x or not y then return end

	if not ply.InventoryGrid[inv] or not ply.InventoryGrid[inv][x] or not ply.InventoryGrid[inv][x][y] or ply.InventoryGrid[inv][x][y].ItemData.ID ~= "paper" then
		return
	end

	ITEM = nil
	ITEM = { }

	ITEM.ID = "letter" .. TS.LetterCount
	ITEM.Flags = "l"
	ITEM.UseDelay = .1
	ITEM.PickupDelay = .1

	ITEM.Name = "Note"
	ITEM.Description = string.sub(string.gsub(ply.LetterContent, "@n", ""), 1, 30) .. "..."
	ITEM.Model = TS.ItemsData["paper"].Model
	ITEM.CamPos = TS.ItemsData["paper"].CamPos
	ITEM.LookAt = TS.ItemsData["paper"].LookAt
	ITEM.FOV = TS.ItemsData["paper"].FOV
	ITEM.Width = 1
	ITEM.Height = 1
	ITEM.LetterContent = ply.LetterContent

	ITEM.Pickup = function(self) end

	ITEM.Drop = function(self) end

	ITEM.Use = function(self)

		umsg.Start("SL", self.Owner); umsg.End()
		umsg.Start("DL", self.Owner); umsg.End()

		local parts = math.ceil(string.len(self.LetterContent) / 200)

		for n = 1, parts do

			local f = function()

				if not self.Owner or not self.Owner:IsValid() then return end

				umsg.Start("SLP", self.Owner)
					umsg.String(string.sub(self.LetterContent, (n - 1) * 200 + 1, n * 200))
				umsg.End()

			end
			timer.Simple(n * .2, f)

		end


	end

	TS.ItemsData[ITEM.ID] = ITEM

	ply:DropItemProp("letter" .. TS.LetterCount)
	ply:TakeItemAt(inv, x, y)

	TS.LetterCount = TS.LetterCount + 1

end
concommand.Add("eng_el", ccEndLetter)

function ccUpdateTargetID(ply, cmd, arg)

	if CurTime() - ply.LastTargetIDUpdate < 2 then

		return

	end

	ply.LastTargetIDUpdate = CurTime()

	if not tonumber(arg[1]) then

		return

	end

	local ent = ents.GetByIndex((tonumber(arg[1])))

	if ent:IsPlayer() then

		if not arg[2] then

			return

		end

	elseif ent:IsProp() then

		if not arg[2] then

			return

		end

	else

		return

	end

	if ent and ent:IsValid() then

		if ent:IsPlayer() then

			local title = ent:GetPlayerTitle() or ""

			if ent.IsTied then

				title2 = title2 .. "\n(Tied)"

			end

			if arg[2] ~= title then

				net.Start("CharDesc")
					net.WriteTable({ent, title})
				net.Send(ply)

			end

		elseif ent:IsProp() then

			if ent.Desc then

				if ent.Desc ~= arg[2] then

					umsg.Start("UPD", ply)
						umsg.Entity(ent)
						umsg.String(ent.Desc)
					umsg.End()

				end

			end

		end

	end

end
concommand.Add("eng_uti", ccUpdateTargetID)

function ccLookInsideMapStorage(ply, cmd, arg)

	if not arg[1] or not tonumber(arg[1]) then
		return
	end

	if ply.IsTied then return end

	local id = tonumber(arg[1])

	local ent = ply.ActionMenuTarget

	if not ent or not ent:IsValid() then return end

	ply.DistanceFromItem = (ent:GetPos() - ply:GetPos()):Length()

	if ply.DistanceFromItem > 90 then

		return

	end

end
concommand.Add("eng_lookinsidemapstorage", ccLookInsideMapStorage)

function CreateNewAccount(ply, cmd, args)

	if not ply.Unregistered then return end

	local row = TS.SQL:Query("SELECT 1 FROM {USERS} WHERE steamID = ?", ply:SteamID())[1]

	if not row then

		TS.SQL:Query("INSERT INTO {USERS} (steamID, userName, userTooltrust) VALUES (?, ?, 0)", ply:SteamID(), args[1])
		ply.UID = TS.SQL:GetLastInsertID()

		ply:RemoveAccountMenu()

		timer.Simple(0.5, function() ply:PromptCharacterMenu() end)

	else

		ply:RemoveAccountMenu()
		ply:HandleUID()

	end

end
concommand.Add("eng_createaccount", CreateNewAccount)

function ccCharMenu(ply, cmd, arg)

	if CurTime() - ply.LastCharMenu < 1 then
		return
	end

	if ply.CharacterMenu then return end

	ply:CallEvent("PlayerMenuOff")
	ply:CallEvent("HorseyMapViewOn")
	ply:Lock()
	ply:MakeInvisible(true)

	if ply.Initialized then

		ply:CharSave()

	end

	ply:RefreshChar()

	ply:PromptCharacterMenu()

	ply.LastCharMenu = CurTime()

end
concommand.Add("eng_charmenu", ccCharMenu)

function ccCheckForRadio(ply, cmd, arg)

	if not ply:HasItem("radio") then

		ply:PrintMessage(3, "You need a radio!")
		return

	end

	umsg.Start("PRM", ply)
	umsg.End()

end
concommand.Add("eng_checkforradio", ccCheckForRadio)

function ccScopeNoDraw(ply, cmd, arg)

	if not ply:GetActiveWeapon():IsValid() then return end

	ply:DrawViewModel(false)

end
concommand.Add("eng_scopenodraw", ccScopeNoDraw)

function ccSeeScope(ply, cmd, arg)

	if not tonumber(arg[1]) then return end

	local val = tonumber(arg[1])

	local curweap = ply:GetActiveWeapon()

	if val == 1 then

		if curweap and curweap:IsValid() then

			if curweap.UseScope then

				ply:DrawViewModel(false)
				ply:SetFOV(curweap.ScopeFOV, curweap.ScopeSpeed)

			end

		end

	else

		ply:DrawViewModel(true)
		ply:SetFOV(0, curweap.ScopeSpeed)

	end

end
concommand.Add("eng_seescope", ccSeeScope)

function ccCheckQuiz(ply, cmd, arg)

	if CurTime() - ply.LastQuizCheck < 2 then
		return
	end

	if (not arg[1] and
		not arg[2] and
		not arg[3] and
		not arg[4] and
		not arg[5]) then

		return

	end

	if (arg[1] == "Terminator" and
		arg[2] == "Out-Of-Character" and
		arg[3] == "In-Character" and
		arg[4] == "No" and
		arg[5] == "No") then

		umsg.Start("RQ", ply)
		umsg.End()

		timer.Simple(.5, function() ply:PromptAccountCreationMenu() end)

	else

		game.ConsoleCommand("banid 5 " .. ply:SteamID() .. "\n")
		game.ConsoleCommand("writeid\n")

		game.ConsoleCommand("kickid \"" .. ply:UserID() .. "\" \"Failed quiz - banned for five minutes.\"\n")

	end

	ply.LastQuizCheck = CurTime()

end
concommand.Add("eng_checkquiz", ccCheckQuiz)

function CCToggleHolster(ply, cmd, arg)

	if CurTime() - ply.LastHolster < 1 then
		return
	end

	local weap = ply:GetActiveWeapon()

	if weap:IsValid() then

		local class = weap:GetClass()

		if (class == "weapon_physcannon" or
			class == "weapon_physgun" or
			class == "gmod_tool" or
			class == "ts2_zipties" or
			class == "ts2_ziptiecutters") then

			return

		end

		if weap.HolsterToggle then
			weap.HolsterToggle(weap)
		end

	end

	ply:SetPlayerHolstered(!ply:GetPlayerHolstered())

	if ply:GetPlayerHolstered() == true then

		ply:SetAimAnim(false)

	else

		ply:SetAimAnim(true)

	end

	LastHolster = CurTime()

end
concommand.Add("eng_toggleholster", CCToggleHolster)

function ccUpdateScoreboard(ply, cmd, arg)

	if (not tonumber(arg[1]) or
		not tonumber(arg[2])) then

		return

	end

	local code = tonumber(arg[1])
	local ent = ents.GetByIndex((tonumber(arg[2])))

	if ent and ent:IsValid() then

		if code == 1 then

			net.Start("CharDesc")
				net.WriteTable({ent, ent:GetPlayerTitle()})
			net.Send(ply)

		end

	end

end
concommand.Add("eng_us", ccUpdateScoreboard)

function ccUpdateCreatorSteamID(ply, cmd, arg)

	if not tonumber(arg[1]) then

		return

	end

	local ent = ents.GetByIndex((tonumber(arg[1])))

	if ent and ent:IsValid() then

		if ent.CS then

			umsg.Start("UPCS", ply)
				umsg.Entity(ent)
				umsg.String(ent.CS)
			umsg.End()

		end

	end

end
concommand.Add("eng_ucs", ccUpdateCreatorSteamID)

function ccDragDropItem(ply, cmd, arg)

	if CurTime() - ply.LastDrag < .6 then
		return
	end

	local id, iid, x, y, dx, dy = arg[1],
								  tonumber(arg[2]),
								  tonumber(arg[3]),
								  tonumber(arg[4]),
								  tonumber(arg[5]),
								  tonumber(arg[6])

	if not id or not iid or not x or not y or not dx or not dy then

		return

	end

	local item = ply.InventoryGrid[iid][x][y].ItemData

	if not (item) then return end
	if item && item.ID ~= id then return end

	local amt = ply.InventoryGrid[iid][x][y].ItemData.Amount or 0

	//Can we drag to this location?
	if ply:CanDragAt(iid, id, x, y, dx, dy) then

		//Take our old item, add our item at the location.
		ply:TakeItemAt(iid, x, y)
		ply:GiveDraggedItem(iid, id, dx, dy, amt)

	else

		//Get our shit.
		local block = ply.InventoryGrid[iid][dx][dy].ItemData
		local item = ply.InventoryGrid[iid][x][y].ItemData

		//Better be the same shit. Better not be the same item.
		if (block && (block.ID == item.ID)) && not ((dx == x) && (dy == y)) then

			//Better be the same kind of item, and the SAME item.
			if string.find("a", item.Flags) && string.find("a", block.Flags) then

				local needed = (block.Maximum - block.Amount)

				if needed > 0 then

					if amt >= needed then

						ply:ModifyItemAmount(iid, dx, dy, block.Amount + needed)

						amt = amt - needed
						ply:ModifyItemAmount(iid, x, y, amt)

						if amt == 0 then

							ply:TakeItemAt(iid, x, y)

						end

						return

					else

						ply:ModifyItemAmount(iid, dx, dy, block.Amount + amt)
						ply:TakeItemAt(iid, x, y)

						return

					end

				end

			end

		elseif ply:CanSwapItem(iid, dx, dy, item.ID) && not (dx == x && dy == y) then

			local bid, bamt = block.ID, block.Amount
			local mid, mamt = item.ID, item.Amount

			ply:TakeItemAt(iid, x, y)
			ply:TakeItemAt(iid, dx, dy)

			ply:GiveDraggedItem(iid, bid, x, y, bamt)
			ply:GiveDraggedItem(iid, mid, dx, dy, mamt)

		end

	end

	ply.LastDrag = CurTime()

end
concommand.Add("eng_dragdropitem", ccDragDropItem)

//Warning: Dumb.
local function SetPrimarySecondary(ply, id, pslot)

    if pslot == true then

        ply:SetPlayerPrimaryWeapon(id)

    else

       ply:SetPlayerSecondaryWeapon(id)

    end

end

local function DeniedMessage(ply)

	Console(ply, "Please wait before attempting this action.", true)

end

//Unload our shit.
local function UnloadWeapon(ply, id)

	//Is this motherfucker really trying to do this shit like that..?
	if not (ply.InventoryGrid) then return end

	//Get our currently equipted weapon.
	local wep = ply:GetWeapon(id)

	//Try and find a ammo box that fits our ammo type.
	local succ, i, x, y, amt = ply:HasItem(wep.AmmoType)

	//So we can find out what we're dealing with.
	local flags = TS.ItemsData[wep.AmmoType].Flags

	if not (string.find(flags, "P")) then

		//Did we find one?
		if succ then

			//Take the amount stored in the box, and add our magazine onto it.
			local newamount = amt + wep:Clip1()

			//Modify the ammo box with our new ammo count.
			ply:ModifyItemAmount(i, x, y, newamount)
			wep:SetClip1(0)

		else

			//Here, take this ammo box! It has x amount of bullets in it!
			ply:GiveAnyInventoryItem(wep.AmmoType, wep:Clip1())
			wep:SetClip1(0)

		end

	else

		Console(ply, "You cannot unload plasma!", true)

	end

end


//This is for equipting an item from our inventory into one of our slots.
function ccEquipWeaponSlot(ply, cmd, arg)

	//dont spam drag
	if CurTime() - ply.LastDrag < .6 then
			DeniedMessage(ply)
			return
	end

	//Item ID (String), Inventory ID
	local id, iid = arg[1], tonumber(arg[2])

	//Item X and Y coordinates.
	local x, y = tonumber(arg[3]), tonumber(arg[4])

	//Is someone just fucking with us?
	if not id or not iid or not x or not y then return end

	local flags = TS.ItemsData[id].Flags
	local idat

	if ply:ValidGridSpace(iid, x, y) then
		idat = ply.InventoryGrid[iid][x][y].ItemData

		if (idat && idat.ID != id) || not idat then return end

	else
		return
	end

	//For our slot selection.
	local pslot, item = false, ""

	local flagtable = string.ToTable(flags)
	local ValidItem = false
	local ValidWeapon = false

	for i = 1, #flagtable do
		local flag = flagtable[i]

		if flag == "w" || flag == ">" then
			ValidItem = true
		end

		if flag == "w" then
			ValidWeapon = true
		end
	end

	if not (ValidItem) then return end

	//Is our weapon a primary weapon?
	if TS.ItemsData[id].IsPrimary then

		//Get our correct gun, and set our indicator
		pslot = true
		item = ply:GetPlayerPrimaryWeapon()

	else //If not...

		//Do the same shit, just opposite.
		pslot = false
		item = ply:GetPlayerSecondaryWeapon()

	end

	//Is our slot empty?
	if item and item ~= "NULL" && TS.ItemsData[item] then

		//Can we fit our item in our inventory?
		if ply:CanItemFitInAnyInventory(item) || ply:CanSwapItem(iid, x, y, item) then

			//Get our ammo from our gun.
			local ammo = ply.InventoryGrid[iid][x][y].ItemData.Amount

			if idat.OnEquip then
				idat:OnEquip(ply)
			end

			//Take the item from our inventory.
			ply:TakeItemAt(iid, x, y)

			local EquiptedItem, Amount, Weapon = item, 1
			local Amount = 1
			if IsValid(ply:GetWeapon(item)) then
				EquiptedItem = ply:GetWeapon(item):GetClass()
				Amount = ply:GetWeapon(item):Clip1()
			end

			if EquiptedItem then
				local wpnData = TS.ItemsData[EquiptedItem]

				if wpnData.OnUnequip then
					wpnData:OnUnequip(ply)
				end

				//Give us our previously equipted weapon with its ammo.
				ply:GiveAnyInventoryItem(EquiptedItem, Amount)
			end

			//Select our hands, and strip our previously equipted weapon.
			ply:SelectWeapon("ts2_hands")
			ply:StripWeapon(item)

			//Give us our gun, and ammo.
			SetPrimarySecondary(ply, id, pslot)

			if ValidWeapon then
				ply:Give(id)
			end

			if IsValid(Weapon) then
				Weapon:SetClip1(ammo)
			end
		end

	else
		local ammo = 0

		if idat then
			ammo = idat.Amount
		end

		if idat.OnEquip then
			idat:OnEquip(ply)
		end

		//Take the item from our inventory
		ply:TakeItemAt(iid, x, y)

		//Give it to our primary slot.
		SetPrimarySecondary(ply, id, pslot)

		if ValidWeapon then
			local Weapon = ply:Give(id)

			if IsValid(Weapon) then
				//Set our weapon's ammo.
				Weapon:SetClip1(ammo)
			end
		end
	end

   	//Cooldown, nigga.
	ply.LastDrag = CurTime()
end
concommand.Add("eng_rseo", ccEquipWeaponSlot)

//This is used to drag an item from our primary/secondary slot, to our inventory.
function ccDragDropPrimarySecondarySlot(ply, cmd, arg)
	if CurTime() - ply.LastDrag < .6 then
		DeniedMessage(ply)
		return
	end

	local id, iid, dx, dy  = arg[1] , tonumber(arg[2]),
							 tonumber(arg[3]), tonumber(arg[4])

	if not id or not iid or not dx or not dy then return end

	local pslot, item = (TS.ItemsData[id].IsPrimary && not TS.ItemsData[id].IsPrimary == false), ""

	if pslot then
		item = ply:GetPlayerPrimaryWeapon()
	else
		item = ply:GetPlayerSecondaryWeapon()
	end

	local item_data = TS.ItemsData[item]

	local Weapon = ply:GetWeapon(id)

	if id && id ~= "NULL" then
		if ply:CanDragAtFromNil(iid, id, dx, dy) && (item == id) then
			local Ammo = 0

			SetPrimarySecondary(ply, "NULL", pslot)
			ply:SelectWeapon("ts2_hands")

			if IsValid(Weapon) then
				Ammo = Weapon:Clip1()
				ply:StripWeapon(id)
			end

			if item_data.OnUnequip then
				item_data:OnUnequip(ply)
			end

			ply:GiveDraggedItem(iid, id, dx, dy, Ammo)
		end
	end
	ply.LastDrag = CurTime()
end

concommand.Add("eng_ddps", ccDragDropPrimarySecondarySlot)

function ccUnloadWeapon(ply, cmd, arg)
	if CurTime() - ply.LastDrag < 1 then
		DeniedMessage(ply)
		return
	end

	local id, iid, x, y, Amount = arg[1], tonumber(arg[2]),
								  tonumber(arg[3]), tonumber(arg[4]),
								  tonumber(arg[5])

	if not id or not iid or not x or not y or not Amount then return end

	local item = TS.ItemsData[id]

	if not (string.find(item.Flags, "w")) then return end

	local Weapon = ply.InventoryGrid[iid][x][y].ItemData
	local Amt = Weapon.Amount

	if not (id == Weapon.ID) then return end

	if Amt == Amount then
		local aflags = TS.ItemsData[Weapon.AmmoType].Flags or ""

		local succ, i, xx, yy, count = ply:HasItem(Weapon.AmmoType)

		if not (string.find(aflags, "P")) then
			if succ then
				local Max = ply.InventoryGrid[i][xx][yy].ItemData

				Max = Max.Maximum

				if (count + Amt) <= Max then
					ply:ModifyItemAmount(i, xx, yy, count + Amt)
					ply:ModifyItemAmount(iid, x, y, 0)
				else
					local needed = Max - count

					ply:ModifyItemAmount(i, xx, yy, count + needed)

					Amt = Amt - needed

					ply:GiveAnyInventoryItem(Weapon.AmmoType, Amt)
					ply:ModifyItemAmount(iid, x, y, 0)
				end
			else
				ply:GiveAnyInventoryItem(Weapon.AmmoType, Amt)
				ply:ModifyItemAmount(iid, x, y, 0)
			end
		else
			Console(ply, "You cannot unload plasma!", true)
		end
	end
	ply.LastDrag = CurTime()
end
concommand.Add("eng_unloadweapon", ccUnloadWeapon)

local function LoadWeapon(id, x, y, Amt, Weapon, ply)
	local succ, i, xx, yy, count = ply:HasItem(Weapon.AmmoType)

	local aflags = TS.ItemsData[Weapon.AmmoType].Flags or ""

	if succ && not (string.find(aflags, "P")) then
		local needed = Weapon.Maximum - Amt

		//Is our needed amount somehow greater than it allows? or less than zero..?
		if (needed > Weapon.Maximum) or (needed < 0) then

			//Here, have one on the house!
			ply:ModifyItemAmount(id, x, y, Weapon.Maximum)
			return

		elseif needed == 0 then

			//You. Get. NOTHING.
			return

		end

		//Do we have enough to supply your gun?
		if count >= needed then

			//Load the gun up.
			ply:ModifyItemAmount(id, x, y, Amt + needed)

			//Take the amount.
			count = count - needed

			//If there's nothing left...
			if count == 0 then
				ply:TakeItemAt(i, xx, yy)
			else
				ply:ModifyItemAmount(i, xx, yy, count)
			end

			return

		//Okay, we have ammo here. Take what I have.
		elseif count > 0 then

			//Load the gun up.
			ply:ModifyItemAmount(id, x, y, Amt + count)

			//Take the box away.
			ply:TakeItemAt(i, xx, yy)

			Amt = Amt + count

			//FIND ME MORE AMMO. I'M NOT SATISFIED.
			LoadWeapon(id, x, y, Amt, Weapon, ply)

		end

	//Great...a plasma cell.
	else
		//Do we already have a plasma cell?
		if Amt == 0 then

			//Take the plasma cell away.
			ply:TakeItemAt(i, xx, yy)

			//Load it.
			ply:ModifyItemAmount(id, x, y, count)

		end

	end

end

function ccLoadWeapon(ply, cmd, arg)

	//Chill the fuck out!
	if CurTime() - ply.LastDrag < 1 then
		DeniedMessage(ply)
		return
	end

	//Sort out our parameters.
	local id, iid, x, y, Amount = arg[1], tonumber(arg[2]),
								  tonumber(arg[3]), tonumber(arg[4]),
								  tonumber(arg[5])

	//Don't fuck with me.
	if not id or not iid or not x or not y or not Amount then return end

	//Gettin' them item like we get them chicks.
	local item = TS.ItemsData[id]

	if not (string.find(item.Flags, "w")) then return end

	//Don't fuck with me, playa.
	local Weapon = ply.InventoryGrid[iid][x][y].ItemData

	//Get our ammo from the gun.
	local Amt = Weapon.Amount

	//Is this...motherfucker trying to EXPLOIT?!?!?
	if not (id == Weapon.ID) then return end

	//STOP EXPLOITING.
	if Amt == Amount then

		//Let's get this shit on the run.
		LoadWeapon(iid, x, y, Amount, Weapon, ply)

	end

	//Cooldown....JUST FUCKING CHILL MAN.
	ply.LastDrag = CurTime()

end
concommand.Add("eng_loadweapon", ccLoadWeapon)

function ccSplitItem(ply, cmd, args)

	local Amount, iid, x, y = tonumber(args[1]), tonumber(args[2]), tonumber(args[3]), tonumber(args[4])

	if not (Amount && iid && x && y) then return end

	local grid = ply.InventoryGrid[iid][x][y].ItemData

	local Flags = TS.ItemsData[grid.ID].Flags

	if string.find(Flags, "[") then return end

	if grid && grid.Amount > 1 && grid.Amount > Amount && not (string.find(Flags, "P") or string.find(Flags, "w")) then

		local NewAmount = grid.Amount - Amount

		if ply:CanItemFitInAnyInventory(grid.ID) then
			ply:ModifyItemAmount(iid, x, y, NewAmount)
			ply:GiveAnyInventoryItem(grid.ID, Amount)
		end

	end

end
concommand.Add("eng_splititem", ccSplitItem)

function ccEquipWeapon(ply, cmd, args)
	local GroundWeapon = ply.ActionMenuTarget
	local CurrentWeapon = nil
	local Slot = nil
	local CurrentAmmo = 0

	local GroundWeaponData = TS.ItemsData[GroundWeapon.ItemData.ID]

	if not (GroundWeaponData) then return end

	local SlotString = {
		[true] = "Primary",
		[false] = "Secondary"
	}

	if GroundWeaponData.IsPrimary then
		Slot = true
		CurrentWeapon = ply:GetPlayerPrimaryWeapon()
	else
		Slot = false
		CurrentWeapon = ply:GetPlayerSecondaryWeapon()
	end

	print(CurrentWeapon)

	local NotAGun = true

	if IsValid(ply:GetWeapon(CurrentWeapon)) then
		CurrentWeapon = ply:GetWeapon(CurrentWeapon)

		NotAGun = false
	end

	if NotAGun == false && IsValid(CurrentWeapon) then
		CurrentAmmo = CurrentWeapon:Clip1()
	end

	CreateProcessBar("equipweapon", "Picking up weapon...", ply)
		SetEstimatedTime(1, ply)
		SetThinkDelay(.1, ply)
		SetThink(function(ply, done)
			if not (IsValid(GroundWeapon)) then
				DestroyProcessBar("equipweapon", ply)
				return
			end

			local Distance = (GroundWeapon:GetPos() - ply:GetPos()):Length()

			if Distance > 90 then
				DestroyProcessBar("equipweapon", ply)
				return
			end

			if not ply.ItemsDownloaded[GroundWeapon.ItemData.ID] then
				ply:SendItemData(GroundWeapon.ItemData.ID)
			end

			if done then
				ply["SetPlayer" .. SlotString[Slot] .. "Weapon"](ply, GroundWeapon.ItemData.ID)

				if GroundWeapon.ItemData.OnEquip then
					GroundWeapon.ItemData:OnEquip(ply)
				end

				if (NotAGun == false && IsValid(CurrentWeapon)) || NotAGun && NotAGun ~= "NULL" then

					if NotAGun == false then
						CurrentAmmo = CurrentWeapon:Clip1()
					end

					local Class = (NotAGun == false && CurrentWeapon:GetClass() || CurrentWeapon)

					if TS.ItemsData[Class] then

						local GroundProp = ply:DropItemProp(Class)
						GroundProp.ItemData.Amount = CurrentAmmo

						local WeaponData = TS.ItemsData[Class]

						if WeaponData.OnUnequip then
							WeaponData:OnUnequip(ply)
						end

						if NotAGun == false then
							ply:StripWeapon(Class)
						end

					end
				end

				local Weapon = ply:Give(GroundWeapon.ItemData.ID)

				if IsValid(Weapon) then
					Weapon:SetClip1(GroundWeapon.ItemData.Amount)
				end

				GroundWeapon:Remove()

				ply:CharSave()
				DestroyProcessBar("equipweapon", ply)
				return
			end
		end, ply)
	EndProcessBar(ply)
end

concommand.Add("eng_equipweapon", ccEquipWeapon)


/*
March 08, 2012

Began work on start menu redux.

*/

function ccRequestCharacterMenu(ply, cmd, arg)

	if not ply.CharacterMenu then

		ply:PromptCharacterMenu()
		ply:CallEvent("EnableIntroCinematic")

	end

end
concommand.Add("eng_rcm", ccRequestCharacterMenu)
