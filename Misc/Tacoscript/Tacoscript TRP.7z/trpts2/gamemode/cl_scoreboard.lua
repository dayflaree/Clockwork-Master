--Scoreboard optimized and cleaned - 26/May/10
--This was supposed to be temporary, but meh.

surface.CreateFont("HorseyFont", {
	size = 28,
	weight = 400,
	font = "coolvetica",
	antialias = true,
	additive = false
})

if ScoreboardFrame then

	ScoreboardFrame:Remove()

end

ScoreboardFrame = nil

local midx = ScrW() / 2
local midy = ScrH() / 2
local Size = 0.70

local blacklist = {
"hands",
"tool gun",
"gravity gun",
"physics gun",
"#hl2_physgun",
"#hl2_gravitygun",
}

local modelfix = {
["models/terminator_p.mdl"] = 				{[1] = Vector(60, 13, 50), [2] = Vector(0, 0, 61), [3] = 30, [4] = 1},
["models/t600/r_t600.mdl"] = 				{[1] = Vector(50, 13, 50), [2] = Vector(0, 0, 61), [3] = 30, [4] = 347},
["models/player/terminator_fatty.mdl"] = 	{[1] = Vector(50, 13, 50), [2] = Vector(0, 0, 66), [3] = 30, [4] = 347},
["models/dogmeat.mdl"] = 					{[1] = Vector(65, 21, 42), [2] = Vector(0, 0, 47), [3] = 90, [4] = 6} --Dogs are retarded anyway.
}

function GetWeapons(e)

		local str = ""

		local wm = e:GetWeapons()

		for k, v in pairs (wm) do

				local name = v:GetPrintName()

				if table.HasValue(blacklist, string.lower(name)) then

						table.remove(wm, k)

				end

		end

		for _, w in pairs (wm) do

				if w.Primary then
						str = str .. w:GetPrintName() .. ", "
				end

		end

		str = string.sub(str, 1, string.len(str) - 2)

		return str

end

function ReturnStatus(e)

	if e:IsSuperAdmin() && e:IsAdmin() then

		return "Administrator"

	elseif e:IsAdmin() then

		return "Trial Admin"

	else

		return ""

	end

end

--Credits to whoever it is put this together.
local PANEL = {}

function PANEL:Paint()

	local x, y = self:LocalToScreen(0, 0)
	local w, h = self:GetSize()

	if self.border then
		w = w - 1
		h = h - 1
	end

	local sl, st, sr, sb = x, y, x + w, y + h

	local p = self

	while p:GetParent() do

		p = p:GetParent()
		local pl, pt = p:LocalToScreen(0, 0)
		local pr, pb = pl + p:GetWide(), pt + p:GetTall()
		sl = sl < pl and pl or sl
		st = st < pt and pt or st
		sr = sr > pr and pr or sr
		sb = sb > pb and pb or sb

	end

	render.SetScissorRect(sl, st, sr, sb, true)

		self.BaseClass.Paint(self)

	render.SetScissorRect(0, 0, 0, 0, false)

	if self.border then
		local col = self.bordercolor or Color(255, 255, 255)
		surface.SetDrawColor(col)
		surface.DrawOutlinedRect(0, 0, w + 1, h + 1)
	end

end

function PANEL:GiveBorder(tf)

	if tf then
		self.border = true
	else
		self.border = false
	end

end

vgui.Register("DModelPanel2", PANEL, "DModelPanel")

--Well..not really, I guess.
local function CreateScoreboard()

	--Main panel
	ScoreboardFrame = CreateBPanel(nil, midx - 280, midy - (ScrH() * Size * 0.5), 560, ScrH() * Size)
	ScoreboardFrame:SetBodyColor(Color(0, 0, 0, 100))
	ScoreboardFrame:NoClipping(false)
	ScoreboardFrame:CanClose(false)
	ScoreboardFrame:CanDrag(false)

	ScoreboardFrame.Paint = function()

	local w, h = ScoreboardFrame:GetWide(), ScoreboardFrame:GetTall()

        draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 150))

        surface.SetDrawColor(255, 255, 255, 255)
        surface.DrawOutlinedRect(0, 0, w , h)
        surface.DrawOutlinedRect(w - 19, 43, 15, h - 48)

        surface.DrawOutlinedRect(5, 43, w - 28, h - 48)

        draw.SimpleTextOutlined("TacoNBanana.com" , "NewChatFont", 8, 15, Color(255, 255, 255, 255), nil, nil, 1, Color(0, 0, 0, 255))
        draw.SimpleTextOutlined(os.date("%I:%M %p"), "NewChatFont", w - 65, 15, Color(255, 255, 255, 255), nil, TEXT_ALIGN_RIGHT, 1, Color(0, 0, 0, 255))

	end

	--Inner panel
	ScoreboardFrame.Inner = CreateBPanel(nil, 5, 25, 531, ScrH() * Size - 50)
	ScoreboardFrame.Inner:SetBodyColor(Color(30, 30, 30, 240))
	ScoreboardFrame.Inner:SetParent(ScoreboardFrame)
	ScoreboardFrame.Inner:EnableScrolling(true)
	ScoreboardFrame.Inner:CanClose(false)
	ScoreboardFrame.Inner:CanDrag(false)

	ScoreboardFrame.Inner.Paint = function()

	local w, h = ScoreboardFrame:GetWide(), ScoreboardFrame:GetTall()

        draw.RoundedBox(0, 0, 0, w - 25, h, Color(0, 0, 0, 150))

	end

	ScoreboardFrame.Inner.PlayerRow = { }
	ScoreboardFrame.Inner.PlayerIcons = { }

	local sy = 0
	local name

	for t, n in pairs(team.GetAllTeams()) do

	    if team.NumPlayers(t) > 0 then

            if team.GetName(t) ~= "SkyNet" or LocalPlayer():IsAdmin() or LocalPlayer():IsCP() then

                if team.GetName(t) ~= "SkyNet Stealth" or LocalPlayer():Team() == 3 then

                    ScoreboardFrame.Inner:AddLabel(team.GetName(t), "HorseyFont", 5, sy + 3, Color(255, 255, 255, 255))

                    sy = sy + 30

                    for k, v in pairs(player.GetAll()) do

                        if team.GetName(v:Team()) == team.GetName(t)  then

                            ScoreboardFrame.Inner.PlayerRow[v] = CreateBPanel(nil, 0, sy - 21, ScoreboardFrame.Inner:GetWide(), 97)
                            ScoreboardFrame.Inner.PlayerRow[v]:SetBodyColor(Color(250, 250, 250, 255))
                            ScoreboardFrame.Inner.PlayerRow[v]:SetParent(ScoreboardFrame.Inner)
                            ScoreboardFrame.Inner.PlayerRow[v]:NoClipping(false)

                            ScoreboardFrame.Inner.PlayerRow[v].Paint = function()

                                if v:IsValid() then

                                    if not v:GetRPName() or v:GetRPName() == "" then

                                        name = v:Name() .. " - Connecting"

                                    else

                                        name = v:GetRPName()

                                    end

                                    local tcol = team.GetColor(v:Team())

                                    surface.SetDrawColor(tcol.r, tcol.g, tcol.b, 2) -- What color do You want to paint the button (R, B, G, A)
                                    surface.DrawRect(0, 0, ScoreboardFrame.Inner:GetWide(), ScoreboardFrame.Inner:GetTall()) -- Paint what coords

                                    draw.RoundedBox(0, 6, 10, 90, 86, Color(0, 0, 0, 255))

                                    surface.SetDrawColor(255, 255, 255, 255)
                                    surface.DrawOutlinedRect(5, 9, 91 , 86)

                                   	local Desc = v:GetTitle() or ""
                                   	Desc, num = FormatLine(Desc, "DescFont", 390)

                                  	draw.DrawTextOutlined(name or "", "NewChatFont", 100, 6, Color(255, 255, 255, 255), nil, nil, 1, Color(0, 0, 0, 255))
                                    draw.DrawTextOutlined(v:Ping(), "NewChatFont", ScoreboardFrame.Inner:GetWide() - 5, 10, Color(255, 255, 255, 255), TEXT_ALIGN_RIGHT, nil, 1, Color(0, 0, 0, 255))
                                    draw.DrawTextOutlined(Desc, "DescFont", 100, 24, Color(255, 255, 255, 255), nil, nil, 1, Color(0, 0, 0, 255))
                                    draw.DrawTextOutlined(ReturnStatus(v), "DescFont", 100, 38 + (num * 14), Color(255, 0, 0, 255), nil, nil, .1, Color(0, 0, 0, 255))

                                end

                            end


							local model = v.RealModel or "models/maxofs2d/logo_gmod_b.mdl"

                            ScoreboardFrame.Inner.PlayerIcons[v] = vgui.Create("DModelPanel2", ScoreboardFrame.Inner)
                            ScoreboardFrame.Inner.PlayerIcons[v]:SetPos(6, sy + 8)
                            ScoreboardFrame.Inner.PlayerIcons[v]:SetSize(89, 84)
                            ScoreboardFrame.Inner.PlayerIcons[v]:SetParent(ScoreboardFrame.Inner)
                            ScoreboardFrame.Inner.PlayerIcons[v]:SetModel(model)

                            if table.HasValue(modelfix, model) then

                                ScoreboardFrame.Inner.PlayerIcons[v]:SetCamPos(modelfix[model][1])
                                ScoreboardFrame.Inner.PlayerIcons[v]:SetLookAt(modelfix[model][2])
                                ScoreboardFrame.Inner.PlayerIcons[v]:SetFOV(modelfix[model][3])

                            else

                                ScoreboardFrame.Inner.PlayerIcons[v]:SetCamPos(Vector(60, 13, 50))
                                ScoreboardFrame.Inner.PlayerIcons[v]:SetLookAt(Vector(0, 0, 65))
                                ScoreboardFrame.Inner.PlayerIcons[v]:SetFOV(15)

                            end

                            ScoreboardFrame.Inner.PlayerIcons[v].Entity:SetEyeTarget(Vector(-60, 0, 36))

                            ScoreboardFrame.Inner.PlayerIcons[v]:SetMouseInputEnabled(false)
                            ScoreboardFrame.Inner.PlayerIcons[v]:NoClipping(false)
                            ScoreboardFrame.Inner.PlayerIcons[v].LayoutEntity = function(self)

                            local ent = ScoreboardFrame.Inner.PlayerIcons[v]:GetEntity()
                            ent:ClearPoseParameters()

                                if v:IsValid() then

                                    if type(modelfix[model]) == "table" then

                                        ent:ResetSequence(ent:SelectWeightedSequence(modelfix[model][4]))
                                        self:RunAnimation()

                                    else

                                        ent:ResetSequence(ent:SelectWeightedSequence(1))
                                        self:RunAnimation()

                                    end

                                end

                            end


                            sy = sy + 100

                            ScoreboardFrame.Inner:AddObject(ScoreboardFrame.Inner.PlayerIcons[v])
                            ScoreboardFrame.Inner:AddObject(ScoreboardFrame.Inner.PlayerRow[v])

                        end

                    end

                end

            end

	    end

	end

end

function GM:ScoreboardShow()

	CreateScoreboard()

	gui.EnableScreenClicker(true)

end

function GM:ScoreboardHide()

	if ScoreboardFrame then

		ScoreboardFrame:Remove()

	end

	HideMouse()

end