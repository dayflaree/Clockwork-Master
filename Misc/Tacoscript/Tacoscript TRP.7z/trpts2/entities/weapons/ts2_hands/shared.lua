if SERVER then

 	AddCSLuaFile("shared.lua")

 end

 SWEP.HoldType = "pistol"


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = false
 SWEP.AdminSpawnable		= false

SWEP.Primary.Sound = Sound("Weapon_SMG1.Single")

SWEP.ViewModel = Model("models/weapons/v_fists.mdl")
SWEP.WorldModel = Model("models/weapons/w_fists.mdl")


SWEP.PrintName = "Hands"
SWEP.TS2Desc = "Pick up things or punch someone\n(HOLSTERED) Left click - Knock  on door/Throw\n(HOLSTERED) Right click - Pick up/drop\n(UNHOLSTERED) Left click - Punch\n"


 SWEP.Primary.ViewPunchMul = .5
 SWEP.Primary.Damage			= 5
 SWEP.Primary.NumShots		= 1

 SWEP.HoldType = "fist"
 SWEP.TS2HoldType = "FIST"

SWEP.Slot = 1

SWEP.Primary.ClipSize = 0
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Delay = .07
SWEP.Primary.Automatic = true

 SWEP.Primary.IronSightPos = Vector(0, 5.5, -5.0)
 SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(-2.4, -4, -12.0)

SWEP.LastPickUp = 0

SWEP.ItemWidth = 0
SWEP.ItemHeight = 0
SWEP.IsGun = false

SWEP.LastReload = 0

SWEP.CoolSights = false

function SWEP:Initialize()

	if !self.HolsterType then
		self.HolsterType = "normal"
	end

	self:SetWeaponHoldType(self.HolsterType)

	self.HitSounds = {

		Sound("npc/vort/foot_hit.wav"),
		Sound("weapons/crossbow/hitbod1.wav"),
		Sound("weapons/crossbow/hitbod2.wav")
	}

	self.SwingSounds = {

		Sound("npc/vort/claw_swing1.wav"),
		Sound("npc/vort/claw_swing2.wav")

	}

end

function SWEP:Reload()

	return

end

SWEP.NextPrimaryAttack = 0

function SWEP:PrimaryAttack()

	if CLIENT then return end

	if SERVER and self.Owner.IsTied then return end

	if CurTime() < self.NextPrimaryAttack then return end

	if SERVER && not (self.Owner:IsDrone()) then return end

	if (SERVER and self.Owner:GetPlayerHolstered()) then

		if SERVER then

			if self.Owner:GetTable().HandPickUpSent and self.Owner:GetTable().HandPickUpSent:IsValid() and self.Owner:GetTable().HandPickUpTarget and self.Owner:GetTable().HandPickUpTarget:IsValid() then

				local ent = self.Owner:GetTable().HandPickUpTarget
				self.Owner:RemoveHandPickUp()
				self.Owner:GetTable().HandPickUpTarget:GetPhysicsObject():ApplyForceCenter(self.Owner:GetAimVector() * 1000)

				return

			end

		end


		local trace = { }
		trace.start = self.Owner:EyePos()
		trace.endpos = trace.start + self.Owner:GetAimVector() * 30
		trace.filter = self.Owner

		local tr = util.TraceLine(trace)

		if tr.Entity:IsValid() and tr.Entity:IsDoor() then

			self.Weapon:EmitSound(Sound("physics/wood/wood_crate_impact_hard2.wav"))
			self.NextPrimaryAttack = CurTime() + 1

		end

	else

		local trace = { }
		trace.start = self.Owner:EyePos()
		trace.endpos = trace.start + self.Owner:GetAimVector() * 60
		trace.filter = self.Owner

		local tr = util.TraceLine(trace)

		self.Owner:EmitSound(self.SwingSounds[math.random(1, #self.SwingSounds)])
		if SERVER then
			self.Owner:SetPlayerSprint(self.Owner:GetPlayerSprint() - math.random(2, 5))
		end

		self:SendWeaponAnim(ACT_VM_HITCENTER)
		self.Owner:SetAnimation(PLAYER_ATTACK1)
		self.NextPrimaryAttack = CurTime() + .5

		if tr.Hit or tr.Entity:IsValid() then

			self:EmitSound(self.HitSounds[math.random(1, #self.HitSounds)])

			self.NextPrimaryAttack = CurTime() + .5

			if tr.Entity:IsPlayer() then

				local eyeang = Angle(3 * math.Rand(-8, 8), 3 * math.Rand(-8, 8), 0)
				tr.Entity:ViewPunch(eyeang)

				tr.Entity:SetPlayerConsciousness(tr.Entity:GetPlayerConsciousness() - math.random(30, 35))
				tr.Entity:SetHealth(tr.Entity:Health() - math.random(10, 15))

			end

		end

		if SERVER then

			if self.Owner:CanBeSkyNet() || self.Owner:HasTerminatorFlag("F") || self.Owner:HasTerminatorFlag("G")  || self.Owner:HasTerminatorFlag("M") then

				local trace = { }
				trace.start = self.Owner:EyePos()
				trace.endpos = trace.start + self.Owner:GetAimVector() * 90
				trace.filter = self.Owner

				local tr = util.TraceLine(trace)

				if tr.Entity:IsValid() and (tr.Entity:GetClass() == "func_door" or tr.Entity:GetClass() == "prop_door_rotating" or tr.Entity:GetClass() == "func_door_rotating") then

					tr.Entity:Fire("unlock", "", 0)
					tr.Entity:Fire("toggle", "", 0)

				end

				if tr.Entity:IsValid() and tr.Entity:GetClass() == "prop_door_rotating" then

					tr.Entity:EmitSound(Sound("physics/wood/wood_box_impact_hard3.wav"))

					local pos = tr.Entity:GetPos()
					local ang = tr.Entity:GetAngles()
					local model = tr.Entity:GetModel()
					local skin = tr.Entity:GetSkin()

					tr.Entity:SetNotSolid(true)
					tr.Entity:SetNoDraw(true)

					local function ResetDoor(door, fakedoor)

						door:SetNotSolid(false)
						door:SetNoDraw(false)
						fakedoor:Remove()

					end

					local norm = (pos - self.Owner:GetPos())
					norm:Normalize()
					local push = 33000 * norm

					local ent = ents.Create("prop_physics")
					ent:SetPos(pos)
					ent:SetAngles(ang)
					ent:SetModel(model)
					if skin then
						ent:SetSkin(skin)
					end
					ent:Spawn()

					timer.Simple(.05, function()
						ent:SetVelocity(push)
						ent:GetPhysicsObject().ApplyForceCenter(ent:GetPhysicsObject(), push)
					end)

					timer.Simple(300, ResetDoor, tr.Entity, ent)


				end

			end

		end

	end



end

function SWEP:SecondaryAttack()

	if CLIENT then return end

	if self.Owner.IsTied then return end

	if self.Owner:GetPlayerHolstered() then

		if self.Owner:GetTable().HandPickUpSent and self.Owner:GetTable().HandPickUpSent:IsValid() then
			self.Owner:RemoveHandPickUp()
		elseif CurTime() - self.LastPickUp > 1 then

			local trace = { }
			trace.start = self.Owner:EyePos()
			trace.endpos = trace.start + self.Owner:GetAimVector() * 60
			trace.filter = self.Owner

			local tr = util.TraceLine(trace)

			if tr.Entity and tr.Entity:IsValid() then

				self.Owner:HandPickUp(tr.Entity, tr.PhysicsBone)

			end

			self.LastPickUp = CurTime()

		end

	else

	end

	if self.Owner:CanBeSkyNet() || self.Owner:HasTerminatorFlag("F") || self.Owner:HasTerminatorFlag("G")  || self.Owner:HasTerminatorFlag("M") then

		local trace = {}
		trace.start = self.Owner:EyePos()
		trace.endpos = trace.start + self.Owner:GetAimVector() * 80
		trace.filter = self.Owner

		local tr = util.TraceLine(trace)

		if tr.Entity and tr.Entity:IsValid() then

			tr.Entity:GetPhysicsObject():EnableMotion(true)
	 		tr.Entity:GetPhysicsObject():Wake()

			constraint.RemoveAll(tr.Entity)

			local norm = (tr.Entity:GetPos() - self.Owner:GetPos())
			norm:Normalize()
			local push = 400 * norm

			tr.Entity:GetPhysicsObject():SetVelocity(push)

		end

	end

end

function SWEP:HolsterToggle()

	if self.Owner:GetTable().HandPickUpSent and self.Owner:GetTable().HandPickUpSent:IsValid() then
		self.Owner:RemoveHandPickUp()
	end

	if self.Owner:GetTable().RightHandEntity and self.Owner:GetTable().RightHandEntity:IsValid() then

		self.Owner:GetTable().RightHandEntity:Remove()
		self.Owner:GetTable().RightHandEntity = nil

	end

end

