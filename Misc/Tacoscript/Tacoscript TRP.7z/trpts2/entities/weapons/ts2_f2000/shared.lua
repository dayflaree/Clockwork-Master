
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/galil/galil-1.wav")

SWEP.WorldModel = "models/weapons/w_fnf2000.mdl"
SWEP.ViewModel = "models/weapons/v_fnf2000.mdl"

SWEP.PrintName = "F2000"
SWEP.TS2Desc = "Belgian Assault Rifle - 5.56"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 5
 SWEP.Primary.Damage			= 9
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 32
SWEP.Primary.DefaultClip = 160
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
 SWEP.Primary.ReloadDelay = 2.3

 SWEP.Primary.IronSightPos = Vector(3.3626 , 0.989 , -14.5748)
 SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(130, -8.14, -11)
SWEP.IconLookAt = Vector(-12.76, -6.18, -1)
SWEP.IconFOV = 18.5

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	8,
		OffR	=	2.58,
		OffU	=	0.52,
		OffRotR	=	202,
		OffRotF	=	-2162,
		OffRotU	=	-628.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
