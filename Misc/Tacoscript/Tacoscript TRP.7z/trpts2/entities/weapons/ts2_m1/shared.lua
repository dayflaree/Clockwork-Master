if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/garand_shoot.wav")

SWEP.WorldModel 			= "models/weapons/w_m1garand.mdl"
SWEP.ViewModel 				= "models/weapons/v_m1garand.mdl"

SWEP.PrintName 				= "M1 Garand"
SWEP.TS2Desc 				= "WWII-Era Battle Rifle."

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .4
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul	= 10
SWEP.Primary.Damage			= 40
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 8
SWEP.Primary.DefaultClip 	= 150
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .18
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 1

SWEP.Primary.IronSightPos = Vector(-4.9779977798462, 2.6412003040314, -4.5974998474121)
SWEP.Primary.IronSightAng = Vector(-4.4703482582342e-010, -0.0069999978877604, -4.4703482582342e-010)

SWEP.Primary.HolsteredPos = Vector(12.695999145508, -5, -8)
SWEP.Primary.HolsteredAng = Vector(4, 64, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-200, -22, 8)
SWEP.IconLookAt = Vector(45, 7, 0)
SWEP.IconFOV = 13.429178304961

SWEP.IronsightAddEffectiveness = 95

SWEP.ReloadSound 			= "weapons/garand_reload_clipin.wav"
SWEP.LastShotSound			= "weapons/garand_clipding.wav"

SWEP.IsPrimary 				= true
SWEP.AltFire 				= false
SWEP.AmmoType 				= ".30-06"

if CLIENT then
SWEP.PositionData = {
		OffF	=	4,
		OffR	=	4.08,
		OffU	=	3.12,
		OffRotR	=	208.4,
		OffRotF	=	-2527.9,
		OffRotU	=	-809.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
