if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "revolver"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.ViewModel				= "models/weapons/v_plasma.mdl"
SWEP.WorldModel				= "models/weapons/w_plasma.mdl"

SWEP.PrintName 				= "M18A1 'Blowtorch'"
SWEP.TS2Desc 				= "A heavy and slow firing plasma pistol"

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 8
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType			= "revolver"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos 	= Vector(-2.9952, 1.5068, -8.4835)
SWEP.Primary.IronSightAng 	= Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos 	= Vector(-0.2273, -13.4934, -7.5877)
SWEP.Primary.HolsteredAng 	= Vector(53.7318, -5.4051, 0)

SWEP.ItemWidth 				= 1
SWEP.ItemHeight 			= 1

SWEP.IconCamPos 			= Vector(-35, 170, -13)
SWEP.IconLookAt 			= Vector(-2, 4, -2)
SWEP.IconFOV 				= 5

if CLIENT then
SWEP.PositionData = {
		OffF	=	8.3,
		OffR	=	1.08,
		OffU	=	-2.98,
		OffRotR	=	433.8,
		OffRotF	=	-2434.8,
		OffRotU	=	-615.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end


/*
This is for the weapon slots. No need to include this in guns all the time, only when setting it
to true, as this defaults to false.
*/
SWEP.IsPrimary = false

//This is the ammo the gun uses.
SWEP.AmmoType 				= "plasmacell"

//Enabling this allows for heatsinks.
SWEP.UseHeatsink 			= true

/*
The heatsink rate controlls how quickly the weapon cools off one heat.
Lets look at our weapon's delay.

SWEP.Primary.Delay = .1

So, we maintain the speed of the gun, .1, but if someone wanted to fire the gun in quick succession, they would
probably just overheat it. Due to the lower rate of regeneration, three shots in quick succession will probably overheat
the gun.
*/

SWEP.heatsinkRate 			= .1
SWEP.heatsinkPower 			= 2.5