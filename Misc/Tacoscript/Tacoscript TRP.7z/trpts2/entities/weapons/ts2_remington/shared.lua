if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.ViewModelFlip				= true
SWEP.Base 						= "ts2_base"
SWEP.HoldType 					= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable				= true

SWEP.ViewModel					= "models/weapons/v_mega_m3super90.mdl"
SWEP.WorldModel					= "models/weapons/w_remmy_fix.mdl"
SWEP.Primary.Sound				= Sound("Weapons/shotgun.wav")

SWEP.PrintName 					= "Remington 12 Gauge"
SWEP.TS2Desc 					= "Old fashioned pump shotgun"

SWEP.ShotgunReload 				= true

SWEP.Primary.Recoil				= .3
SWEP.Primary.RecoilAdd			= .2
SWEP.Primary.RecoilMin 			= .3
SWEP.Primary.RecoilMax 			= 1

SWEP.Primary.ViewPunchMul 		= 30
SWEP.Primary.Damage				= 10
SWEP.Primary.NumShots			= 9

SWEP.TS2HoldType 				= "SHOTGUN"
SWEP.Category 					= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 		= true
SWEP.Primary.HighPowered 		= true
SWEP.Primary.ClipSize 			= 6
SWEP.Primary.DefaultClip 		= 30
SWEP.Primary.Ammo 				= "smg1"
SWEP.Primary.Delay 				= 1
SWEP.Primary.Automatic 			= false
SWEP.Primary.SpreadCone 		= Vector(.05, .05, .05)
SWEP.Primary.Spread 			= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 		= Vector(4.3888, 2.331, -5.9595)
SWEP.Primary.IronSightAng 		= Vector(0.5892, 0, -0.1397)

SWEP.Primary.HolsteredPos 		= Vector(-10, -1, -5)
SWEP.Primary.HolsteredAng 		= Vector(5, -50, -15)

SWEP.ItemWidth 					= 4
SWEP.ItemHeight					= 1

SWEP.IconCamPos = Vector(4, 41, -8)
SWEP.IconLookAt = Vector(2, 0, 0)
SWEP.IconFOV = 58.092796885634

SWEP.IsPrimary 					= true

SWEP.AmmoType = "12gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	2,
		OffR	=	3.18,
		OffU	=	0.72,
		OffRotR	=	212.6,
		OffRotF	=	-2154.9,
		OffRotU	=	-358.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
