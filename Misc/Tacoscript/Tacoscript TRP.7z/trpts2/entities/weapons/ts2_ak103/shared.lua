
if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound = Sound("Weapons/mp5.wav")

SWEP.WorldModel = "models/weapons/w_ak103.mdl"
SWEP.ViewModel = "models/weapons/v_ak103.mdl"

SWEP.PrintName 				= "AK103"
SWEP.TS2Desc 				= "Russian Carbine Assault Rifle - 7.62mm"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .6

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 9
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 60
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(-3.8719007968903, 2.3343999385834, -9.8522996902466)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(3.442699432373, -0.19999408721924, -8.4948015213013)
SWEP.Primary.HolsteredAng = Vector(0.36000823974609, 53.400001525879, 2.9799995422363)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-23, -148.55, -6)
SWEP.IconLookAt = Vector(9.64, 56, -2.31)
SWEP.IconFOV = 12.9

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "7.62mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.20000000000001,
		OffR	=	2.38,
		OffU	=	-0.18,
		OffRotR	=	1110.5,
		OffRotF	=	-890.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end