if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

 SWEP.Base = "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable		= true
SWEP.ViewModelFlip		= false

SWEP.Primary.Sound			= Sound("Weapons/silenced.wav")

SWEP.WorldModel = "models/weapons/w_an94.mdl"
SWEP.ViewModel = "models/weapons/v_an94.mdl"

SWEP.PrintName = "AN-94 MOD"
SWEP.TS2Desc = "Modified Assault Rifle"


 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 10
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 190
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-4.063099861145, 0.76620000600815, -6.0598001480103)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(5, -3.1999998092651, -8)
SWEP.Primary.HolsteredAng = Vector(7, 60, 0)

SWEP.ItemWidth = 4
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(5, -81.88, 19)
SWEP.IconLookAt = Vector(5.83, 2, -1.84)
SWEP.IconFOV = 33.9

SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	2.4,
		OffR	=	2.58,
		OffU	=	-0.18,
		OffRotR	=	1414.5,
		OffRotF	=	-3.3,
		OffRotU	=	-179.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
