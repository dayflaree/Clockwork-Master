if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.ViewModelFlip				= true
SWEP.Base 						= "ts2_base"
SWEP.HoldType 					= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable				= true

SWEP.ViewModel					= "models/weapons/v_shot_winch1300.mdl"
SWEP.WorldModel					= "models/weapons/w_shot_winch1300.mdl"
SWEP.Primary.Sound				= Sound("Weapons/shotgun.wav")

SWEP.PrintName					= "Ithaca 37 Shotgun"
SWEP.TS2Desc 					= "Chrome Pump Action - 12 Gauge"

SWEP.ShotgunReload 				= true

SWEP.Primary.Recoil				= .3
SWEP.Primary.RecoilAdd			= .2
SWEP.Primary.RecoilMin 			= .3
SWEP.Primary.RecoilMax 			= 1

SWEP.Primary.ViewPunchMul 		= 30
SWEP.Primary.Damage				= 10
SWEP.Primary.NumShots			= 9

SWEP.TS2HoldType 				= "SHOTGUN"
SWEP.Category 					= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 		= true
SWEP.Primary.HighPowered 		= true
SWEP.Primary.ClipSize 			= 8
SWEP.Primary.DefaultClip 		= 30
SWEP.Primary.Ammo 				= "smg1"
SWEP.Primary.Delay 				= 1
SWEP.Primary.Automatic 			= false
SWEP.Primary.SpreadCone 		= Vector(.05, .05, .05)
SWEP.Primary.Spread 			= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 		= Vector(3.1517000198364, 1.6706000566483, -1.9603999853134)
SWEP.Primary.IronSightAng 		= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 		= Vector(-1.4000008106232, -3.9999997615814, -3.2000002861023)
SWEP.Primary.HolsteredAng 		= Vector(-5, -50, 31.400009155273)

SWEP.ItemWidth 					= 3
SWEP.ItemHeight					= 1

SWEP.IconCamPos = Vector(33, 97, 36)
SWEP.IconLookAt = Vector(-1, -2, 0)
SWEP.IconFOV = 19.9

SWEP.IsPrimary 					= true

SWEP.AmmoType = "12gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	3,
		OffR	=	3.38,
		OffU	=	0.12,
		OffRotR	=	204.4,
		OffRotF	=	-2530.9,
		OffRotU	=	-719.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end