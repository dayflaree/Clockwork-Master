if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/l22.wav")

SWEP.WorldModel 			= "models/weapons/w_l22.mdl"
SWEP.ViewModel 				= "models/weapons/v_l22.mdl"

SWEP.PrintName 				= "L22A2 Rifle"
SWEP.TS2Desc 				= "Donator weapon"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 8
SWEP.Primary.Damage			= 14
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 400
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(2.5936000347137, 1.6066000461578, -3.2146999835968)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5, -0.79999911785126, -5)
SWEP.Primary.HolsteredAng = Vector(5, -50, -15)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(0, -200, -34)
SWEP.IconLookAt = Vector(-8.5073097801637, -5, -2)
SWEP.IconFOV = 6.6068504630386

SWEP.IsPrimary = true

SWEP.AltFire= 1
SWEP.AdminOnly				= true
SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	10.2,
		OffR	=	4.88,
		OffU	=	-2.68,
		OffRotR	=	342.7,
		OffRotF	=	-2514.6,
		OffRotU	=	-718.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
