
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

 SWEP.Base = "ts2_base"

if CLIENT then

	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
end

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.ViewModel			= "models/weapons/v_boomstickyo.mdl"
SWEP.WorldModel			= "models/weapons/w_doublebarrel.mdl"
SWEP.Primary.Sound			= Sound("Weapons/xm1014/XM1014-1.wav")

SWEP.PrintName = "Double Barrelled Shotgun"
SWEP.TS2Desc = "And this.....is my BOOMSTICK!"


SWEP.ShotgunReload = true

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = 1

 SWEP.Primary.ViewPunchMul = 20
 SWEP.Primary.Damage			= 8
 SWEP.Primary.NumShots		= 12

 SWEP.TS2HoldType = "SHOTGUN"
 SWEP.Category = "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 2
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 0.9
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.05, .05, .05)
SWEP.Primary.Spread =  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-2.75, 1.6548000574112, -7.3007998466492)
SWEP.Primary.IronSightAng = Vector(0.58920001983643, 0, -0.13969999551773)

SWEP.Primary.HolsteredPos = Vector(4.8000001907349, -4, -7)
SWEP.Primary.HolsteredAng = Vector(-5, 52, -16)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(6, -83, 1)
SWEP.IconLookAt = Vector(3, -15, -2)
SWEP.IconFOV = 26.9

SWEP.IsPrimary = true

SWEP.AmmoType = "12gauge"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-2.1,
		OffR	=	2.48,
		OffU	=	-1.98,
		OffRotR	=	205,
		OffRotF	=	-2165.5,
		OffRotU	=	-535.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
