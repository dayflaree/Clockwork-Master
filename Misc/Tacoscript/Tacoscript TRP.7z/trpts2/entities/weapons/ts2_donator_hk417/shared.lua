
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/silenced.wav")

SWEP.ViewModel			= "models/weapons/v_snip_hk416.mdl"
SWEP.WorldModel			= "models/weapons/w_snip_hk416.mdl"

SWEP.PrintName = "HK 417 - Silenced"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(4.019100189209, 1.1928000450134, -10.582599639893)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-9.1541957855225, -5.3716988563538, -6.1859984397888)
SWEP.Primary.HolsteredAng = Vector(18.518100738525, -70.610824584961, -11.821999549866)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(3, -45, -10)
SWEP.IconLookAt = Vector(3.48, -4, -2)
SWEP.IconFOV = 50

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.20000000000001,
		OffR	=	4.88,
		OffU	=	-0.67999999999999,
		OffRotR	=	342.7,
		OffRotF	=	-2514.6,
		OffRotU	=	-718.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
