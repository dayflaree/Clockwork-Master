if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/k98_shoot2.wav")

SWEP.ViewModel				= "models/weapons/v_rif_fnfal.mdl"
SWEP.WorldModel				= "models/weapons/w_rif_fnfal.mdl"

SWEP.PrintName 				= "FN FAL Rifle"
SWEP.TS2Desc 				= "Donator weapon"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 2
SWEP.Primary.Damage			= 13
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize		= 20
SWEP.Primary.DefaultClip 	= 120
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .12
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(-3.1756999492645, 1.2941000461578, -4.2600998878479)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(10.800000190735, -5, -2)
SWEP.Primary.HolsteredAng = Vector(-5, 50, 0)

SWEP.ItemWidth 				= 4
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(200, 11.71, -100)
SWEP.IconLookAt = Vector(31.04, 4.13, -17.83)
SWEP.IconFOV = 11.5

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.80000000000001,
		OffR	=	4.38,
		OffU	=	-0.17999999999999,
		OffRotR	=	336,
		OffRotF	=	-2160,
		OffRotU	=	-811.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
