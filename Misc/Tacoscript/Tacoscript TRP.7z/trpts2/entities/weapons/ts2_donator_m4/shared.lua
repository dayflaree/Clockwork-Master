
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes		= true
	SWEP.MuzzleEffect			= "rg_muzzle_highcal"
	SWEP.DrawCrosshair 			= false
	SWEP.ViewModelFlip			= true
end

SWEP.Base 						= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable				= true

SWEP.Primary.Sound 				= Sound("weapons/mp5.wav")

SWEP.ViewModel					= "models/weapons/v_rif_m203.mdl"
SWEP.WorldModel					= "models/weapons/w_rif_m203.mdl"

SWEP.PrintName 					= "M4 M203 Avenger"
SWEP.TS2Desc 					= "Donator weapon"

SWEP.Primary.Recoil				= .2
SWEP.Primary.RecoilAdd			= .3
SWEP.Primary.RecoilMin 			= .3
SWEP.Primary.RecoilMax 			= .4

SWEP.Primary.ViewPunchMul 		= 6
SWEP.Primary.Damage				= 9
SWEP.Primary.NumShots			= 1

SWEP.TS2HoldType 				= "RIFLE"
SWEP.Category 					= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 		= true
SWEP.Primary.HighPowered 		= true
SWEP.Primary.ClipSize 			= 30
SWEP.Primary.DefaultClip 		= 200
SWEP.Primary.Ammo 				= "smg1"
SWEP.Primary.Delay 				= .1
SWEP.Primary.Automatic 			= true
SWEP.Primary.SpreadCone 		= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 		= 2.3

SWEP.Primary.IronSightPos = Vector(3.101900100708, 0.42010000348091, -5.3681998252869)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-7, -1, -5)
SWEP.Primary.HolsteredAng = Vector(5, -59.5, -15)

SWEP.ItemWidth 					= 3
SWEP.ItemHeight 				= 1

SWEP.IconCamPos = Vector(3, -45, -10)
SWEP.IconLookAt = Vector(1, -1, -2)
SWEP.IconFOV = 43.7

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	2.2,
		OffR	=	2.38,
		OffU	=	-0.67999999999999,
		OffRotR	=	383.7,
		OffRotF	=	-2328.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end