if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
 	SWEP.ViewModelFlip		= true

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.ViewModel				= "models/weapons/v_35watt_40mm.mdl"
SWEP.WorldModel				= "models/weapons/w_35watt_40mm.mdl"

SWEP.PrintName 				= "M54A3 - Assault"
SWEP.TS2Desc 				= "Burner with a 40mm launcher"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 9
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos 	= Vector(3.9203, 1.5283, -5.37)
SWEP.Primary.IronSightAng 	= Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos 	= Vector(-0.2273, -13.4934, -7.5877)
SWEP.Primary.HolsteredAng 	= Vector(53.7318, -5.4051, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(200, 0, 0)
SWEP.IconLookAt = Vector(0, -11.43, 2)
SWEP.IconFOV = 8.7

SWEP.IsBurst 				= false

SWEP.IsPrimary 				= true
SWEP.AltFire 				= 3

SWEP.UseHeatsink 			= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.3
SWEP.heatsinkPower 			= 2

if CLIENT then
SWEP.PositionData = {
		OffF	=	10.8,
		OffR	=	3.38,
		OffU	=	6.82,
		OffRotR	=	1290.5,
		OffRotF	=	-1080.8,
		OffRotU	=	-269.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
