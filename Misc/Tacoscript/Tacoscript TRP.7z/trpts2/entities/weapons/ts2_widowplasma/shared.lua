if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.ViewModel				= "models/weapons/v_plasma.mdl"
SWEP.WorldModel				= ""

SWEP.PrintName 				= "HK Widow Plasma"
SWEP.TS2Desc 				= "20watt plasma weapon."

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 30
SWEP.Primary.Damage			= 5
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Other"

SWEP.Primary.ClipSize 		= 9999
SWEP.Primary.DefaultClip 	= 9999
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .04
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos 	= Vector(-2.9952, 1.5068, -8.4835)
SWEP.Primary.IronSightAng 	= Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos 	= Vector(-0.2273, -13.4934, -7.5877)
SWEP.Primary.HolsteredAng 	= Vector(53.7318, -5.4051, 0)

SWEP.ItemWidth 				= 0
SWEP.ItemHeight 			= 0

SWEP.IconCamPos 			= Vector(90, 0, 0)
SWEP.IconLookAt 			= Vector(0, -3, 1)
SWEP.IconFOV 				= 11

SWEP.IgnoreAmmoSystem		= true

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= .12
SWEP.heatsinkPower 			= 2

SWEP.AltFire				= 1
SWEP.AdminOnly				= true

function SWEP:Equip(Owner)

	if SERVER then
		Owner:DrawWorldModel(false)
		self.Weapon:SetNoDraw(true)
		self.Weapon:DrawShadow(false)
	end

end

function SWEP:DrawWorldModel()

    return

end