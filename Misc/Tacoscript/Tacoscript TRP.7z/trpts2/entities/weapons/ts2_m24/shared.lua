
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV 		= 60
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Category = "Tacoscript 2 - Rifles"

 SWEP.Primary.Sound = Sound("weapons/k98_shoot2.wav")

SWEP.ViewModel			= "models/weapons/v_m24.mdl"
SWEP.WorldModel			= "models/weapons/w_m24.mdl"

SWEP.PrintName = "M24 Sniper Rifle"
SWEP.TS2Desc = "Alpha Issue Recon Weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 13
 SWEP.Primary.Damage			= 80
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 20
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 1.5
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.001, .001, .001)
 SWEP.Primary.ReloadDelay = 2

SWEP.Primary.IronSightPos = Vector(3.14240193367, 0.96669888496399, -2.5199995040894)
SWEP.Primary.IronSightAng = Vector(-2.9309000968933, -0.0063999998383224, 0.098980188369751)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -10)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-0.33, -200, -17)
SWEP.IconLookAt = Vector(6, 4, 0)
SWEP.IconFOV = 14.3

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.0658141036402e-014,
		OffR	=	5.08,
		OffU	=	0.12,
		OffRotR	=	147.6,
		OffRotF	=	-2339.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
