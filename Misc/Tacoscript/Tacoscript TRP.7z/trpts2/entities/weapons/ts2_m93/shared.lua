if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 83
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_pist_alyxgun.mdl"
SWEP.WorldModel				= "models/weapons/w_alyx_gun.mdl"

SWEP.PrintName 				= "M93R Tac-Spec"
SWEP.TS2Desc 				= "TechComm Automatic Sidearm"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5
SWEP.Primary.RecoverTime 	= .4

SWEP.Primary.Sound 			= Sound("Weapons/p228/p228-1.wav")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 60
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= .08
SWEP.Primary.Damage 		= 5
SWEP.Primary.Automatic 		= true

SWEP.Primary.ViewPunchMul 	= 3

SWEP.TS2HoldType 			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(3.7, 1.2, -5)
SWEP.Primary.IronSightAng 	= Vector(4.7989, -1.3847, -1.3891)

SWEP.Primary.HolsteredPos 	= Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-15.0, 15.0, 0.0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-11, 25, -7)
SWEP.IconLookAt = Vector(0, 0, -3.5)
SWEP.IconFOV = 29.7

SWEP.AmmoType = "9x19mm"