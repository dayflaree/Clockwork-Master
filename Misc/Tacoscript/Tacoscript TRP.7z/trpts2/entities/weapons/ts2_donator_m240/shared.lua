
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound("weapons/ak47.wav")

SWEP.WorldModel = 		"models/weapons/w_m240.mdl"
SWEP.ViewModel  = 		"models/weapons/v_m240.mdl"

SWEP.PrintName = "M240"
SWEP.TS2Desc = "US ARMY LMG"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .7

 SWEP.Primary.ViewPunchMul = 9
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - LMGs"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 200
SWEP.Primary.DefaultClip = 600
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(-4.2213997840881, 2.2656002044678, -3.5817999839783)
SWEP.Primary.IronSightAng = Vector(0.58000004291534, -4.4703482582342e-010, 0)

SWEP.Primary.HolsteredPos = Vector(10.800000190735, -3.0800018310547, -2)
SWEP.Primary.HolsteredAng = Vector(-5, 50, 0)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(5, -124, -62)
SWEP.IconLookAt = Vector(4.76, 3, -0.41)
SWEP.IconFOV = 18.5

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62box"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	1.1,
		OffR	=	2.88,
		OffU	=	-2.08,
		OffRotR	=	1293,
		OffRotF	=	-1776.3,
		OffRotU	=	-539.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
