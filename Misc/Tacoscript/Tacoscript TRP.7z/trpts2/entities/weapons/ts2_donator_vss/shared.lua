
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false
	SWEP.CSMuzzleFlashes	= false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/silenced.wav")

SWEP.ViewModel			= "models/weapons/v_snip_vinto.mdl"
SWEP.WorldModel			= "models/weapons/w_snip_vinto.mdl"

SWEP.PrintName = "VSS Vintorez"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 4
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 10
SWEP.Primary.DefaultClip = 50
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(5.2191004753113, 2.5928001403809, -2.0825996398926)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-9.6341953277588, -4.7716994285583, -9.3859958648682)
SWEP.Primary.HolsteredAng = Vector(18.518100738525, -70.410827636719, -11.821999549866)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-1, 50, -10)
SWEP.IconLookAt = Vector(0, 0, -2.35)
SWEP.IconFOV = 50

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1
SWEP.AdminOnly				= true
SWEP.AmmoType = "9x39mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	4.9,
		OffR	=	1.78,
		OffU	=	0.019999999999999,
		OffRotR	=	205,
		OffRotF	=	-2162.5,
		OffRotU	=	-720.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
