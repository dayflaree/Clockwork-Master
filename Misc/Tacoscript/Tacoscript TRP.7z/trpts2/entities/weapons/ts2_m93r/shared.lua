if SERVER then

 	AddCSLuaFile("shared.lua")

end

 	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 83
	SWEP.DrawCrosshair = false

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true



SWEP.ViewModel			= "models/weapons/v_m93r.mdl"
SWEP.WorldModel			= "models/weapons/w_m93r.mdl"
SWEP.Primary.Sound			= Sound("Weapon_usp.Single")

SWEP.PrintName = "M93R Autoloader"
SWEP.TS2Desc = "Millitary Burst Fire Sidearm"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .5
 SWEP.Primary.RecoverTime = .4

 SWEP.Primary.ViewPunchMul 	= 3


 SWEP.Primary.NumShots		= 1
 SWEP.Primary.ClipSize = 30
 SWEP.Primary.DefaultClip = 120
 SWEP.Primary.Ammo = "pistol"
 SWEP.Primary.Delay = .06
 SWEP.Primary.Damage = 5
 SWEP.Primary.Automatic = false

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - Pistols"

 SWEP.Primary.SpreadCone = Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-4.5069, 2.341, -9.1776)
SWEP.Primary.IronSightAng = Vector(0 , 0 , 0)


SWEP.Primary.HolsteredPos = Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-15.0, 15.0, 0.0)

SWEP.ItemWidth = 2
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(8, 38, 15)
SWEP.IconLookAt = Vector(10, 1, 0)
SWEP.IconFOV = 25.5

SWEP.AmmoType = "9x19mm"

SWEP.AltFire = ALTFIRE_SETTING8

if CLIENT then
SWEP.PositionData = {
		OffF	=	19.1,
		OffR	=	-0.22,
		OffU	=	-3.18,
		OffRotR	=	450.8,
		OffRotF	=	-2436.8,
		OffRotU	=	-628.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
