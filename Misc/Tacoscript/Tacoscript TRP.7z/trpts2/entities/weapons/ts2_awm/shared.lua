if SERVER then

	AddCSLuaFile("shared.lua")

end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end


SWEP.Base = "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable		= true


SWEP.Primary.Sound = Sound("weapons/k98_shoot2.wav")

SWEP.WorldModel = "models/weapons/w_awm.mdl"
SWEP.ViewModel = "models/weapons/v_awm.mdl"

SWEP.PrintName = "L96A1"
SWEP.TS2Desc = "Resistance Marksman Weapon"


SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd			= .4
SWEP.Primary.RecoilMin = .3
SWEP.Primary.RecoilMax = .5

SWEP.Primary.ViewPunchMul = 10
SWEP.Primary.Damage			= 80
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType = "RIFLE"
SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize = 10
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 1.5
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(4.9424004554749, 1.2866983413696, 0)
SWEP.Primary.IronSightAng = Vector(1.4691001176834, -0.20640002191067, 0.058987904340029)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -3.8000056743622)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

SWEP.ItemWidth = 4
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(16, 38, 5)
SWEP.IconLookAt = Vector(6, 0, 2)
SWEP.IconFOV = 56.216750798283

SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 0

SWEP.AmmoType = "7.62mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.38,
		OffU	=	4.82,
		OffRotR	=	1284.5,
		OffRotF	=	-725.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
