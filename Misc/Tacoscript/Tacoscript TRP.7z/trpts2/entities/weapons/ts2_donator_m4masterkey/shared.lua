if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "rifle"
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/mp5.wav")

SWEP.WorldModel 			= "models/weapons/w_m4masterkey.mdl"
SWEP.ViewModel				= "models/weapons/v_m4masterkey.mdl"

SWEP.PrintName 				= "M4 MasterKey"
SWEP.TS2Desc 				= "Donator weapon"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 12
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "rifle"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 400
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(4.3534002304077, 0.24750000238419, -5.1624999046326)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-11.59999370575, -1.4500026702881, -7.1999979019165)
SWEP.Primary.HolsteredAng = Vector(5.3999996185303, -64.55004119873, -15.999999046326)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(3, -45, -10)
SWEP.IconLookAt = Vector(-0.45, -2, -2.46)
SWEP.IconFOV = 40.9

SWEP.IsPrimary = true

SWEP.AltFire = 4
SWEP.Firemode = 2

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

SWEP.CustomAmmo = "12gauge"


if CLIENT then
SWEP.PositionData = {
		OffF	=	2.2,
		OffR	=	2.38,
		OffU	=	-0.67999999999999,
		OffRotR	=	383.7,
		OffRotF	=	-2328.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

function SWEP:CustomBullet()
	local succ, i, x, y, amt = self.Owner:HasItem("12gauge")

	local bullet = { }

		bullet.Num 		= 12
		bullet.Src 		= self.Owner:GetShootPos()
		bullet.Dir 		= self.Owner:GetAimVector()
		bullet.Spread 	= self.Primary.SpreadCone + Vector(.04, .04, .04)
		bullet.Tracer	= 1
		bullet.Force	= .1
		bullet.Damage	= 8
		bullet.TracerName = self.Primary.Tracer
		bullet.Callback	= NormalHit

 	self.Owner:FireBullets(bullet)

	if succ then
		if (amt - 1) == 0 then
			self.Owner:TakeItemAt(i, x, y)
		else
			self.Owner:ModifyItemAmount(i, x, y, amt - 1)
		end
	end

end