if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModelFlip			= true

SWEP.Primary.Sound 			= Sound("Weapons/silenced.wav")

SWEP.WorldModel 			= "models/weapons/w_p90.mdl"
SWEP.ViewModel 				= "models/weapons/v_p90.mdl"

SWEP.PrintName 				= "P90 Silenced"
SWEP.TS2Desc 				= "RIS Rigged and customised FN SMG"

SWEP.Primary.Recoil			= .01
SWEP.Primary.RecoilAdd		= .01
SWEP.Primary.RecoilMin 		= .02
SWEP.Primary.RecoilMax 		= .03

SWEP.Primary.ViewPunchMul 	= 1
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize 		= 50
SWEP.Primary.DefaultClip 	= 200
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(3.116800069809, -0.34369999170303, -6.289999961853)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-1.1999998092651, -1, -2)
SWEP.Primary.HolsteredAng = Vector(-5, -37, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-18.04, -91.5, 0.32)
SWEP.IconLookAt = Vector(-6.56, -5, 1.18)
SWEP.IconFOV = 18.5

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.7x28mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	5,
		OffR	=	3.18,
		OffU	=	3.12,
		OffRotR	=	34.6,
		OffRotF	=	-2340.9,
		OffRotU	=	-358.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
