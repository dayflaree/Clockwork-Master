
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/l22.wav")

SWEP.WorldModel = "models/weapons/w_g36k.mdl"
SWEP.ViewModel = "models/weapons/v_g36k.mdl"

SWEP.PrintName = "G36"
SWEP.TS2Desc = "German Assault Rifle - 5.56"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 5
 SWEP.Primary.Damage			= 9
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 32
SWEP.Primary.DefaultClip = 160
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
 SWEP.Primary.ReloadDelay = 2.3

 SWEP.Primary.IronSightPos = Vector(3.3626 , 0.989 , -14.5748)
 SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(52, 172.33, -3)
SWEP.IconLookAt = Vector(8.33, 0, 2)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	8,
		OffR	=	3.38,
		OffU	=	4.52,
		OffRotR	=	202,
		OffRotF	=	-2160,
		OffRotU	=	-716.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
