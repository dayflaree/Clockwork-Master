if SERVER then

 	AddCSLuaFile("shared.lua")

end

 	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFOV = 60
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true



SWEP.ViewModel			= "models/weapons/v_m92_silenced.mdl"
SWEP.WorldModel			= "models/weapons/w_m92_silenced.mdl"

SWEP.PrintName = "M92F Silenced Pistol"
SWEP.TS2Desc = "US Millitary Specops Issue"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .5
 SWEP.Primary.RecoverTime = .4

SWEP.Primary.ViewPunchMul 	= 3

 SWEP.Primary.Sound = Sound("weapons/silenced.wav")

 SWEP.Primary.NumShots		= 1
 SWEP.Primary.ClipSize = 16
 SWEP.Primary.DefaultClip = 80
 SWEP.Primary.Ammo = "pistol"
 SWEP.Primary.Delay = .09
 SWEP.Primary.Damage = 6

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - Pistols"

 SWEP.Primary.SpreadCone = Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(1.8995, 2.2574, -2.1648  )
SWEP.Primary.IronSightAng = Vector(0 , 0 , 0)

SWEP.Primary.HolsteredPos = Vector(-2.2273, -9.4934, -3.5877)
SWEP.Primary.HolsteredAng = Vector(53.7318, 6.4051, 0)


SWEP.IconCamPos = Vector(-19, 64, 3)
SWEP.IconLookAt = Vector(-9, 39, 2)
SWEP.IconFOV = 12.9


SWEP.ItemWidth = 2
SWEP.ItemHeight = 1

SWEP.ReloadSound = ""

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	19.1,
		OffR	=	-0.22,
		OffU	=	-3.18,
		OffRotR	=	450.8,
		OffRotF	=	-2436.8,
		OffRotU	=	-628.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
