
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound		 = Sound("weapons/k98_shoot.wav")

SWEP.WorldModel = "models/weapons/w_dragunov__.mdl"
SWEP.ViewModel = "models/weapons/v_dragunov__.mdl"

SWEP.PrintName = "Dragunov SVD Rifle"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 4
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 10
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 1.5
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.001, .001, .001)
 SWEP.Primary.ReloadDelay = 2

SWEP.Primary.IronSightPos = Vector(3.2999978065491, 0.19999971985817, -2.0000042915344)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-4.8399996757507, -2.2000002861023, -2.0000052452087)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(37.8, -200, 47)
SWEP.IconLookAt = Vector(11, -30.59, 7.52)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.1,
		OffR	=	2.58,
		OffU	=	-0.079999999999993,
		OffRotR	=	743,
		OffRotF	=	-1979.1,
		OffRotU	=	-718.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

