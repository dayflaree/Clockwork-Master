
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/rtak.wav")

SWEP.ViewModel			= "models/weapons/v_rtak_drum.mdl"
SWEP.WorldModel			= "models/weapons/w_rtak_drum.mdl"

SWEP.PrintName = "R-TAK Assault"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 10
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SMG"
 SWEP.Category 	= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 75
SWEP.Primary.DefaultClip = 150
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(3.1698000431061, 1.6030000448227, -3.1189999580383)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-4.7937998771667, -1.4358017444611, 0.41170001029968)
SWEP.Primary.HolsteredAng = Vector(-11.007599830627, -51.138412475586, 10.586000442505)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(0, -200, 41)
SWEP.IconLookAt = Vector(0, 2, -3)
SWEP.IconFOV = 11.5

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AmmoType = "5.45mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.80000000000001,
		OffR	=	4.88,
		OffU	=	-0.17999999999999,
		OffRotR	=	341,
		OffRotF	=	-2155,
		OffRotU	=	-721.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
