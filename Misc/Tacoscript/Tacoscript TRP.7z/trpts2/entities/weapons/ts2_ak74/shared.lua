
if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound = Sound("Weapons/ak47.wav")

SWEP.WorldModel = "models/weapons/w_ak74.mdl"
SWEP.ViewModel = "models/weapons/v_ak74.mdl"

SWEP.PrintName 				= "AK74"
SWEP.TS2Desc 				= "Russian Assault Rifle"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .6

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 12
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 60
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 2.3

 SWEP.Primary.IronSightPos = Vector(-3.8706, 1.5377, -10.4976)
 SWEP.Primary.IronSightAng = Vector(0, 0, 0)
SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(11, 200, 5)
SWEP.IconLookAt = Vector(6.69, 30, 1.01)
SWEP.IconFOV = 10.1

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.38,
		OffU	=	4.82,
		OffRotR	=	1284.5,
		OffRotF	=	-725.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
