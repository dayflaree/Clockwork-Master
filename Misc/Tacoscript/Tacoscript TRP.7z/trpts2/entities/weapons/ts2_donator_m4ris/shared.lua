
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/mp5.wav")

SWEP.WorldModel = "models/weapons/w_smg4.mdl"
SWEP.ViewModel = "models/weapons/v_smg4.mdl"

SWEP.PrintName = "M4-RIS M203"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 9
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 400
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.Primary.IronSightPos = Vector(-4.1842, 1.5686 , -8.1373)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(3, -45, -10)
SWEP.IconLookAt = Vector(1, -1, -2)
SWEP.IconFOV = 43.7

SWEP.IsPrimary = true

SWEP.AltFire= 2

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	2.2,
		OffR	=	2.38,
		OffU	=	-0.67999999999999,
		OffRotR	=	383.7,
		OffRotF	=	-2328.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
