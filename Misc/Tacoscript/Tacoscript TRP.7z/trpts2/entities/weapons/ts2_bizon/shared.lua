
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/silenced.wav")

SWEP.ViewModel			= "models/weapons/v_bizon_v.mdl"
SWEP.WorldModel			= "models/weapons/w_bizon.mdl"

SWEP.PrintName = "Bizon SMG - Silenced"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 3
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - SMGs"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 60
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(3.3364000320435, 0.33210000395775, -4.7287998199463)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-6.4541988372803, -4.2716999053955, -6.4860000610352)
SWEP.Primary.HolsteredAng = Vector(18.518100738525, -70.010902404785, -11.821999549866)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(2, -55, 0)
SWEP.IconLookAt = Vector(0, 14, -1)
SWEP.IconFOV = 39.5

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	2.8,
		OffR	=	2.58,
		OffU	=	-0.18,
		OffRotR	=	1099.5,
		OffRotF	=	-535,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
