if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_shot_automa.mdl"
SWEP.WorldModel				= "models/weapons/w_shot_automa.mdl"
SWEP.Primary.Sound			= Sound("Weapons/shotgun.wav")

SWEP.PrintName 				= "12 Gauge Autoloader"
SWEP.TS2Desc 				= "Semi Automatic Combat Shotgun"

SWEP.ShotgunReload 			= true

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 10
SWEP.Primary.Damage			= 8
SWEP.Primary.NumShots		= 12

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 5
SWEP.Primary.DefaultClip 	= 30
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= 0.9
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)
SWEP.Primary.Spread 		=  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(1.9615000486374, 1.6778000593185, 0)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-3.6999998092651, -1, -3.5)
SWEP.Primary.HolsteredAng = Vector(-6, -51.5, 8)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(106.79316563842, 200, 56.75700351011)
SWEP.IconLookAt = Vector(8.4458376294877, 6, 3.5073223688611)
SWEP.IconFOV = 5.2759712787451

SWEP.IsPrimary			 	= true

SWEP.AmmoType 				= "12gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.38,
		OffU	=	2.82,
		OffRotR	=	1284.5,
		OffRotF	=	-725.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
