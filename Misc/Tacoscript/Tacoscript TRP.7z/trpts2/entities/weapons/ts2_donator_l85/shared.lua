
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip	= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/l85.wav")

SWEP.WorldModel = "models/weapons/w_l85.mdl"
SWEP.ViewModel = "models/weapons/v_l85.mdl"

SWEP.PrintName = "L85A2 Rifle"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 5
 SWEP.Primary.Damage			= 14
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 400
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(4.0158004760742, 2.3686015605927, 0.66270911693573)
SWEP.Primary.IronSightAng = Vector(0, -1.2000000476837, 0)

SWEP.Primary.HolsteredPos = Vector(-4.4000053405762, 0.39999973773956, -2.2000002861023)
SWEP.Primary.HolsteredAng = Vector(-4.6000003814697, -54.399978637695, 0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-4, -43, -10)
SWEP.IconLookAt = Vector(-4, -6, -2)
SWEP.IconFOV = 40.9

SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.2,
		OffR	=	4.88,
		OffU	=	-2.68,
		OffRotR	=	342.7,
		OffRotF	=	-2514.6,
		OffRotU	=	-718.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
