if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.Primary.Sound 			= Sound("weapons/k98_shoot2.wav")

SWEP.ViewModel			= "models/weapons/v_mosin_sniper.mdl"
SWEP.WorldModel			= "models/weapons/w_mosin_sniper.mdl"

SWEP.PrintName = "Mosin Sniper Rifle"
SWEP.TS2Desc 				= "Ancient Sniper Rifle"


 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 8
 SWEP.Primary.Damage			= 25
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .2
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(-5.5200009346008, 1.0199997425079, -18.240001678467)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(9.5200052261353, -7.7200016975403, -8.7399997711182)
SWEP.Primary.HolsteredAng = Vector(1.2599999904633, 55.31995010376, -7.5600004196167)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(10, 200, 0)
SWEP.IconLookAt = Vector(0, -25, 1)
SWEP.IconFOV = 14.3

SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.0658141036402e-014,
		OffR	=	4.08,
		OffU	=	-1.88,
		OffRotR	=	-27.4,
		OffRotF	=	-2506.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
