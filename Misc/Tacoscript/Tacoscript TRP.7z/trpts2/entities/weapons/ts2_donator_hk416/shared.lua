
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/kriss.wav")

SWEP.ViewModel			= "models/weapons/v_hk416.mdl"
SWEP.WorldModel			= "models/weapons/w_hk416.mdl"

SWEP.PrintName = "HK 416"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 14
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SMG"
 SWEP.Category 	= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(4.019100189209, 1.1928000450134, -10.582599639893)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-7.034197807312, -4.9716992378235, -8.1859970092773)
SWEP.Primary.HolsteredAng = Vector(18.518100738525, -65.210906982422, -11.821999549866)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(3, -45, -10)
SWEP.IconLookAt = Vector(-2, -3, -2)
SWEP.IconFOV = 39.5

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	3.2,
		OffR	=	4.88,
		OffU	=	-1.68,
		OffRotR	=	342.7,
		OffRotF	=	-2514.6,
		OffRotU	=	-718.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
