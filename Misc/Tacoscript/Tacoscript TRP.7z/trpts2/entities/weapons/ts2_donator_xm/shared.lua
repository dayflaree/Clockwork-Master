
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false
	SWEP.ViewModelFOV = 75

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/lrshot.wav")

SWEP.ViewModel			= "models/weapons/v_battlefield_smg.mdl"
SWEP.WorldModel			= "models/weapons/w_battlefield_smg.mdl"

SWEP.PrintName = "M25A1 'Tempest'"
SWEP.TS2Desc = ""

SWEP.IsBluePlasma = true
SWEP.IsRedPlasma = false

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 4
 SWEP.Primary.Damage			= 15
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Light Plasma"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30000
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .10
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.01, .01, .01)

SWEP.Primary.IronSightPos = Vector(3.293300151825, 0.45659998059273, -5.0277986526489)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5.3341999053955, -3.7716999053955, -6.4860000610352)
SWEP.Primary.HolsteredAng = Vector(18.518100738525, -77.010894775391, -11.821999549866)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(7.3767316438492, -200, -35.187195722468)
SWEP.IconLookAt = Vector(-3.2746880727995, -2.9998339470055, -1.1722275967677)
SWEP.IconFOV = 7.1716796026127

SWEP.ReloadSound = ""

SWEP.IsPrimary 				= true

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.12
SWEP.heatsinkPower 			= 1
SWEP.AmmoType				= "plasmacell"

SWEP.ScopeScale 					= 0.4
SWEP.UseScope 						= true
SWEP.ScopeFOV 						= 45
SWEP.ParabolicScope 				= false
SWEP.ScopeSpeed						= 0.1

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.3,
		OffR	=	3.28,
		OffU	=	0.019999999999999,
		OffRotR	=	331,
		OffRotF	=	-2148.5,
		OffRotU	=	-543.28,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
