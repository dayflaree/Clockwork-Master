 if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

 	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
	SWEP.ViewModelFlip		= true
end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.WorldModel					= "models/weapons/w_svu.mdl"
SWEP.ViewModel					= "models/weapons/v_svu.mdl"

SWEP.PrintName 					= "Dragunov SVU"
SWEP.TS2Desc 					= "Russian Sniper Rifle - 7.62mm"

 SWEP.Primary.ViewPunchMul 		= 15
 SWEP.Primary.Damage			= 80
 SWEP.Primary.NumShots			= 1

SWEP.Primary.SpreadCone = Vector(.02, .02, .02)

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .8
SWEP.Primary.RecoverTime 	= .3

SWEP.Primary.Sound 			= Sound("Weapons/usp/usp1.wav")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 10
SWEP.Primary.DefaultClip 	= 20000
SWEP.Primary.Ammo 			= "ar2"
SWEP.Primary.Delay 			= .12
SWEP.Primary.Automatic		= false
SWEP.Primary.Damage 		= 80

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(14.500003814697, 2.5999999046326, -12.550013542175)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-11.26000213623, -3.3999998569489, -26.200010299683)
SWEP.Primary.HolsteredAng = Vector(0, -58.399978637695, 0)

SWEP.ItemWidth 				= 4
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(7, 64, -2)
SWEP.IconLookAt = Vector(8, 19, 1.16)
SWEP.IconFOV = 35.3

SWEP.ReloadSound 			= ""
SWEP.UseScope				= true

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	10.1,
		OffR	=	3.58,
		OffU	=	7.92,
		OffRotR	=	569,
		OffRotF	=	-2164.1,
		OffRotU	=	-718.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
