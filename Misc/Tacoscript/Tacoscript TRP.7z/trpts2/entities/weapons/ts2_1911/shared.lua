if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFOV 		= 60
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel 				= "models/weapons/v_191145.mdl"
SWEP.WorldModel 			= "models/weapons/w_191145.mdl"

SWEP.PrintName 				= "Colt 1911"
SWEP.TS2Desc 				= "Old .45 calibre pistol"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5
SWEP.Primary.RecoverTime 	= .4

SWEP.Primary.Sound 			= Sound("Weapon_deagle.Single")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 8
SWEP.Primary.DefaultClip 	= 32
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Damage 		= 10

SWEP.Primary.ViewPunchMul 	= 2

SWEP.TS2HoldType 			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-3.8417999744415, 2.0622000694275, -11.896499633789)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(1.3931000232697, -7.0348997116089, -12.463399887085)
SWEP.Primary.HolsteredAng = Vector(51.160491943359, -1.5, 5.411600112915)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-85, 6, -7)
SWEP.IconLookAt = Vector(3, 0, -2)
SWEP.IconFOV = 8.7

SWEP.ReloadSound 			= ""

SWEP.AmmoType = ".45ACP"

if CLIENT then
SWEP.PositionData = {
		OffF	=	9.1,
		OffR	=	3.18,
		OffU	=	-1.78,
		OffRotR	=	374,
		OffRotF	=	-2457.6,
		OffRotU	=	-648.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
