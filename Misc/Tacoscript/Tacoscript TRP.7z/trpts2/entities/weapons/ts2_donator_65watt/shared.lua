if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"
SWEP.ViewModelFlip			= true
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_65watt.mdl"
SWEP.ViewModel 				= "models/weapons/v_65watt.mdl"

SWEP.PrintName 				= "65watt"
SWEP.TS2Desc 				= "Rapidfire heavy plasma weapon"

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 50
SWEP.Primary.Damage			= 18
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Other"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay			= .14
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos 	= Vector(1.0427, -0.9007, -7.6322)
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 5
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-6.5982698514861, 68.792734244002, 18)
SWEP.IconLookAt = Vector(-7.8242887626696, -25.30203959236, -4.087110042572)
SWEP.IconFOV = 46.820843516718

SWEP.AmmoType 				= "plasmacell"

SWEP.IsPrimary 				= true

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.15
SWEP.heatsinkPower 			= 1

SWEP.SkynetOnly				= true
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.20000000000001,
		OffR	=	3.98,
		OffU	=	5.82,
		OffRotR	=	1283.5,
		OffRotF	=	-351,
		OffRotU	=	-4.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
