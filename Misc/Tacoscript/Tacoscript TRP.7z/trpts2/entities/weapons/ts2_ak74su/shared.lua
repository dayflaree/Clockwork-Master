
if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound = Sound("Weapons/ak47.wav")

SWEP.WorldModel = "models/weapons/w_ak74su.mdl"
SWEP.ViewModel = "models/weapons/v_ak74su.mdl"

SWEP.PrintName 				= "AK74SU"
SWEP.TS2Desc 				= "Russian Carbine Assault Rifle"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .6

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 9
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 60
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)


 SWEP.Primary.IronSightPos = Vector(2.5929, 0.8773, -6.8524)
SWEP.Primary.IronSightAng = Vector(0 , 0, 0 )

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(51.812845568577, 200, -10)
SWEP.IconLookAt = Vector(7.7691256906852, -6, 0.76063615940581)
SWEP.IconFOV = 9.1384371900454

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.38,
		OffU	=	4.82,
		OffRotR	=	1284.5,
		OffRotF	=	-725.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
