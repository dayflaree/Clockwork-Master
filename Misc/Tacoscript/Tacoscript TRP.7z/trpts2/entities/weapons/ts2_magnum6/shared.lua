 if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

 	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

 end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.ViewModel		= "models/weapons/v_350.mdl"
SWEP.WorldModel		= "models/weapons/w_351.mdl"

SWEP.PrintName = ".44 Magnum"
SWEP.TS2Desc = "6 inch barrel revolver - .357"

 SWEP.Primary.Recoil			= .4
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .8
 SWEP.Primary.RecoverTime = .3

 SWEP.Primary.Sound = Sound("weapons/elephantgun.wav")

 SWEP.ReloadSound 			= "weapons/357/357_reload4.wav"

 SWEP.Primary.NumShots		= 1
 SWEP.Primary.ClipSize = 6
 SWEP.Primary.DefaultClip = 24
 SWEP.Primary.Ammo = "pistol"
 SWEP.Primary.Delay = 1
 SWEP.Primary.Damage = 11

 SWEP.Primary.ViewPunchMul 	= 10

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - Pistols"

 SWEP.Primary.SpreadCone = Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-5.6301007270813, 2.8822000026703, -7.1307997703552)
SWEP.Primary.IronSightAng = Vector(2.9802322831785e-009, -0.019999999552965, 0.019999999552965)

SWEP.Primary.HolsteredPos = Vector(2.7999999523163, -2, -2)
SWEP.Primary.HolsteredAng = Vector(-15, 15, 0)

SWEP.ItemWidth = 2
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(9, 200, 2)
SWEP.IconLookAt = Vector(-6.32, -4, -2)
SWEP.IconFOV = 5.9

  SWEP.ReloadSound = ""

  SWEP.AmmoType = ".44"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.6,
		OffR	=	1.68,
		OffU	=	-2.78,
		OffRotR	=	266.8,
		OffRotF	=	-2784.8,
		OffRotU	=	-809.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
