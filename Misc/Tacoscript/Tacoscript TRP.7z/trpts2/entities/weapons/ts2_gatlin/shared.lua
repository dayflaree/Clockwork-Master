
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/chaingun.wav")

SWEP.WorldModel = "models/weapons/w_minigun.mdl"
SWEP.ViewModel = "models/weapons/v_minigun.mdl"

SWEP.PrintName = "T-600 Gattling Cannon"
SWEP.TS2Desc = "A fast and powerfull gatling cannon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 30
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Other"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 200
SWEP.Primary.DefaultClip = 1000
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.04, .04, .04)
SWEP.Primary.ReloadDelay = 2.3

 SWEP.Primary.IronSightPos = Vector(-6.4, 2.5, -2.0)
 SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.ReloadSound = ""

SWEP.ItemWidth = 4
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-18.389217503194, -0.19880720078077, 7)
SWEP.IconLookAt = Vector(-1.545113302437, 0.20173136461447, 3.8255479423645)
SWEP.IconFOV = 113.45303804005

SWEP.IsPrimary = true

if CLIENT then
SWEP.PositionData = {
		OffF	=	23.3,
		OffR	=	5.08,
		OffU	=	0.02,
		OffRotR	=	352.8,
		OffRotF	=	-2374.8,
		OffRotU	=	-607.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
