if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 50
	SWEP.DrawCrosshair = false

 end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.IsBluePlasma = true
SWEP.IsRedPlasma = false

SWEP.ViewModel			= "models/weapons/v_pist_plasma.mdl"
SWEP.WorldModel			= "models/weapons/w_pist_plasma.mdl"
SWEP.Primary.Sound			= Sound("npc/strider/strider_minigun.wav")

SWEP.PrintName = "S-18"
SWEP.TS2Desc = "Heavy plasma pistol"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .8
 SWEP.Primary.RecoverTime = .3
SWEP.Primary.ZPunch			= 10

 SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
 SWEP.Primary.Ammo = "pistol"
 SWEP.Primary.Delay = 1.5
 SWEP.Primary.Damage = 40

 SWEP.Primary.ViewPunchMul 	= 0

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - Heavy Plasma"

 SWEP.Primary.SpreadCone = Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(2.2541, 1.1445, -3.1041)
SWEP.Primary.IronSightAng 	= Vector( 0.3686, 0, -0.1642)


SWEP.Primary.HolsteredPos = Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-15.0, 15.0, 0.0)

SWEP.ItemWidth = 2
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-3, -44, -2)
SWEP.IconLookAt = Vector(-1, 15, -2)
SWEP.IconFOV = 19.9

SWEP.SkynetOnly = true

  SWEP.ReloadSound = ""

  SWEP.AmmoType = "plasmacell"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	9.6,
		OffR	=	1.28,
		OffU	=	-3.78,
		OffRotR	=	458.2,
		OffRotF	=	-2076.2,
		OffRotU	=	-457.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
