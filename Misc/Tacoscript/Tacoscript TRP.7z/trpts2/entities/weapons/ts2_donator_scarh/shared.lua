if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true
SWEP.ViewModelFlip			= true

SWEP.Primary.Sound 			= Sound("Weapons/fal.wav")

SWEP.WorldModel 			= "models/weapons/w_scarh.mdl"
SWEP.ViewModel 				= "models/weapons/v_scarh.mdl"

SWEP.PrintName 				= "SCAR-H MK17"
SWEP.TS2Desc 				= "FN 7.62 Modern Assault Rifle"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 8
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType		 	= "SMG"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 200
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(2.8900005817413, 0.7386999130249, -4.8411011695862)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5.4599990844727, -1.4000000953674, -5.3999996185303)
SWEP.Primary.HolsteredAng = Vector(5, -65.400032043457, -9.6000051498413)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(0, -200, 0)
SWEP.IconLookAt = Vector(-1, 2, 0)
SWEP.IconFOV = 10.1

SWEP.UseScope 				= true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	3.1,
		OffR	=	2.48,
		OffU	=	-0.079999999999993,
		OffRotR	=	923,
		OffRotF	=	-1806.3,
		OffRotU	=	-534.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
