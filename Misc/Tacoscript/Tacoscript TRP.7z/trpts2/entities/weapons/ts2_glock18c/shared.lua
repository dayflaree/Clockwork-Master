if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/silenced.wav")
SWEP.WorldModel 			= "models/weapons/w_smg_glc18.mdl"
SWEP.ViewModel 				= "models/weapons/v_smg_glc18.mdl"

SWEP.PrintName 				= "Glock 18C"
SWEP.TS2Desc				= "Donator Weapon"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5
SWEP.Primary.RecoverTime 	= .4

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 120
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= .08
SWEP.Primary.Damage 		= 6
SWEP.Primary.Automatic 		= true

SWEP.TS2HoldType 			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.ViewPunchMul 	= 3

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(2.5548,  1.6568 , -3.9373)
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-15.0, 0.0, 15.0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(0, -49, 0)
SWEP.IconLookAt = Vector(0, 8, -4)
SWEP.IconFOV = 25.5

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = false

SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	12.32,
		OffR	=	0.56,
		OffU	=	-4.18,
		OffRotR	=	269.5,
		OffRotF	=	-2788.3,
		OffRotU	=	-631,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
