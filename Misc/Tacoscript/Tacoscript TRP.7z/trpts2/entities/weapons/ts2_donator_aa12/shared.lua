if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType		 		= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true
SWEP.ViewModelFlip			= true
SWEP.ViewModel				= "models/weapons/v_aa12.mdl"
SWEP.WorldModel				= "models/weapons/w_aa12.mdl"
SWEP.Primary.Sound			= Sound("Weapons/elephantgun.wav")

SWEP.PrintName 				= "AA12 Assault Shotgun"
SWEP.TS2Desc 				= "Heavy Duty Autoloader"

SWEP.ShotgunReload 			= false

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 10
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 12

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 160
SWEP.Primary.Ammo 			= "buckshot"
SWEP.Primary.Delay 			= 0.2
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)
SWEP.Primary.Spread 		=  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(4.8791999816895, 0.33239993453026, 0)
SWEP.Primary.IronSightAng 	= Vector(-2.4997999668121, 0, -0.086499996483326)

SWEP.Primary.HolsteredPos 	= Vector(-3.1600999832153, -2.0882000923157, -6.5731978416443)
SWEP.Primary.HolsteredAng	= Vector(-3.7325999736786, -61.153118133545, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(6, 70, 36)
SWEP.IconLookAt = Vector(7, 0, 2)
SWEP.IconFOV = 26.9

SWEP.IsPrimary = true

SWEP.AmmoType = "12gauge"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	5.18,
		OffU	=	5.82,
		OffRotR	=	1463.5,
		OffRotF	=	-156,
		OffRotU	=	-179.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
