if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV 		= 60
	SWEP.DrawCrosshair = false

end

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/garand_shoot.wav")

SWEP.ViewModel				= "models/weapons/v_psg1.mdl"
SWEP.WorldModel				= "models/weapons/w_psg1.mdl"

SWEP.PrintName 				= "H&K PSG1"
SWEP.TS2Desc 				= "Scoped Marksman Rifle - 7.62x51mm"

SWEP.Primary.ViewPunchMul 	= 10
SWEP.Primary.Damage			= 60
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.HoldType 				= "pistol"

SWEP.Category			 	= "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize 		= 5
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "ar2"
SWEP.Primary.Delay 			= 0.15
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.001, .001, .001)

SWEP.IsPrimary 				= true

SWEP.Primary.IronSightPos = Vector(2.7020008563995, 0.83000016212463, -4.8489995002747)
SWEP.Primary.IronSightAng = Vector(3.1999990940094, 0.17999951541424, 0.40000003576279)

SWEP.Primary.HolsteredPos = Vector(-7.5868997573853, -8.5348997116089, -5.463399887085)
SWEP.Primary.HolsteredAng = Vector(19.46049118042, -60, -2.088399887085)

SWEP.ItemWidth 				= 4
SWEP.ItemHeight 			= 1

SWEP.IconCamPos 			= Vector(2, 200, -5)
SWEP.IconLookAt				= Vector(3.9200000762939, 5, 2)
SWEP.IconFOV				= 12.528983793402

SWEP.ReloadSound 			= ""
SWEP.ScopeScale 			= 0.6
SWEP.UseScope 				= true
SWEP.ScopeFOV 				= 10
SWEP.ParabolicScope 		= false

SWEP.AmmoType 				= "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	5,
		OffR	=	3.18,
		OffU	=	5.12,
		OffRotR	=	208.6,
		OffRotF	=	-2160.9,
		OffRotU	=	-358.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
