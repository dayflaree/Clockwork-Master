
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound("weapons/l22.wav")

SWEP.WorldModel = 		"models/weapons/w_m249.mdl"
SWEP.ViewModel  = 		"models/weapons/v_m249.mdl"

SWEP.PrintName = "M249"
SWEP.TS2Desc = "Special Operations S.A.W"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .7

 SWEP.Primary.ViewPunchMul = 15
 SWEP.Primary.Damage			= 16
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - LMGs"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 100
SWEP.Primary.DefaultClip = 600
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)


SWEP.Primary.IronSightPos = Vector(-4.3957 , 2.2583 , -5.6446)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(3, -200, 47)
SWEP.IconLookAt = Vector(-0.27, -5, 0.18)
SWEP.IconFOV = 10.1

SWEP.AdminOnly				= true
SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AmmoType = "5.56box"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.0658141036402e-014,
		OffR	=	5.08,
		OffU	=	0.12,
		OffRotR	=	147.6,
		OffRotF	=	-2317.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end