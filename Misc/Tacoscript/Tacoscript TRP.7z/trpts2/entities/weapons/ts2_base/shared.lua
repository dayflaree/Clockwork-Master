/*

September 8, 2011

Optimized and cleaned base.
Combined Melee and Aim stat in base.
Combined Shotgun reloading in base.

*/

/*

November 20, 2011

Dave/Firehawk fixed spreadcone

*/

/*

December 12, 2011

Removed Melee table stuff...
...probably going to remove the aim table too.

-Firehawk

*/

/*
s
Feburary 5, 2012 - Feburary 24, 2012

Added SWEP.UseHeatsink - See documentation.
Added SWEP.AmmoType - See documentation.
Added SWEP.IsPrimary
Added SWEP.IsBurst
Added SWEP.AltFire

Incorporated stat raising and recoil reduction.
Redux on recoil rates.

M203 combined with swep, now relies on SWEP.AltFire.
This will require a 40mm grenade to be in your inventory
for use of the firemode.

-Firehawk

*/

/*

ToDo:

Redo zooming. Relying on eng_seescope is just silly, and exploitable.

*/

if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 						= "pistol"
SWEP.Slot 							= 2
SWEP.Spawnable						= false
SWEP.AdminSpawnable					= false
SWEP.UseCustomMuzzleFlash			= false

SWEP.Primary.HighPowered 			= false
SWEP.Primary.DoorBreach 			= false
SWEP.Primary.PenetrateDoors 		= true
SWEP.Primary.CanCauseBleeding 		= true

SWEP.Primary.PositionPosOffset 		= Vector(0, 0, 0)
SWEP.Primary.PositionAngleOffset 	= Angle(0, 0, 0)
SWEP.Primary.PositionOffsetSet 		= false

SWEP.Primary.Sound					= Sound("Weapon_AK47.Single")
SWEP.Primary.Damage					= 40
SWEP.Primary.NumShots				= 1
SWEP.Primary.Automatic				= false
SWEP.Primary.Delay					= 0.2
SWEP.Primary.Tracer 				= "Tracer"
SWEP.Primary.ZPunch					= 0

SWEP.Primary.ClipSize				= -1
SWEP.Primary.DefaultClip			= -1
SWEP.Primary.ReloadDelay 			= 1.5
SWEP.Primary.Ammo					= "none"
SWEP.Primary.RecoverTime 			= 1.0

SWEP.Primary.SpreadCone 			= Vector(.05, .05, .05)
SWEP.Primary.ViewPunchMul 			= 0.1
SWEP.Primary.Recoil					= 0.1
SWEP.Primary.Cone					= 0.02

SWEP.TS2HoldType 					= "PISTOL"

SWEP.ItemWidth 						= 1
SWEP.ItemHeight 					= 1
SWEP.IconCamPos 					= Vector(0, 0, 0)
SWEP.IconLookAt 					= Vector(0, 0, 0)
SWEP.IconFOV 						= 90

SWEP.IsBluePlasma 					= false
SWEP.IsRedPlasma 					= false

SWEP.ShotgunReload 					= false

SWEP.ReloadSound 					= ""

SWEP.ScopeScale 					= 0.4
SWEP.UseScope 						= false
SWEP.ScopeFOV 						= 10
SWEP.ScopeSpeed						= 0.5
SWEP.ParabolicScope 				= false

SWEP.CoolSights						= true --Testing stuff
SWEP.IsZoomed						= false

SWEP.data 							= {}
SWEP.data.IsBursting 				= false
SWEP.data.BurstTimer 				= 0
SWEP.data.BurstCounter 				= 0

SWEP.AltFire						= 0 // 0 = Static, 1 = Semi/Full, 2 = Semi/Full/M203, 3 = M203/Semi, 4 = Semi/Full/Masterkey
SWEP.Firemode						= 1

SWEP.IsMelee						= false
SWEP.IsBurst						= false
SWEP.IsPrimary						= false

SWEP.IronsightAddEffectiveness		= 0

SWEP.Reloading 						= false

SWEP.RecoilReductionAim				= 0
SWEP.RecoilReductionStr				= 0

//Allows your gun to reload without ammo.
SWEP.IgnoreAmmoSystem				= false
SWEP.AmmoType						= "##UNDEFINED##"

/* Heatsink stuff */
SWEP.UseHeatsink					= false

//Cooldown rate
SWEP.heatsinkRate 					= 0.5
//Heat Generation
SWEP.heatsinkPower 					= 3
//Are we overheated?
SWEP.heatsinkOverheated				= false
//For clientside/serverside prediction.
SWEP.heatsinkNextThink				= 0

//Ignore this stuff.
SWEP.heatsinkHeat					= 0
SWEP.heatsinkBeginCooldown			= false

SWEP.SkynetOnly						= false

SWEP.MasterkeyDamage				= 8
SWEP.LastShotSound					= nil

SWEP._BEAM							= 8

SWEP.IsGun							= true

SWEP.FOVOffset = 0
SWEP.FOVApprUp = -20

if CLIENT then
	SWEP.LastHeat = nil
end

FIREMODE_SEMI 		= 1
FIREMODE_FULL 		= 2
FIREMODE_M203 		= 3
FIREMODE_CUSTOM 	= 4
FIREMODE_BURST		= 5
FIREMODE_PLASMA		= 6

ALTFIRE_STATIC		= 0
ALTFIRE_SETTING1		= 1
ALTFIRE_SETTING2		= 2
ALTFIRE_SETTING3		= 3
ALTFIRE_SETTING4		= 4
ALTFIRE_SETTING5		= 5
ALTFIRE_SETTING6		= 6
ALTFIRE_SETTING7		= 7
ALTFIRE_SETTING8		= 8

--[[ Alternate Fire Data ]]--

SWEP.AltFire = ALTFIRE_STATIC

SWEP.Firemodes = {
	i_fPos 		= 1,
	i_selected	= 1,
	b_canswitch = true,
	SelectedFiremode = 1,
	Firemodes 	= {
		[ALTFIRE_SETTING1] = {
			FIREMODE_SEMI,
			FIREMODE_FULL
		},
		[ALTFIRE_SETTING2] = {
			FIREMODE_SEMI,
			FIREMODE_FULL,
			FIREMODE_M203
		},
		[ALTFIRE_SETTING3] = {
			FIREMODE_SEMI,
			FIREMODE_M203
		},
		[ALTFIRE_SETTING4] = {
			FIREMODE_SEMI,
			FIREMODE_FULL,
			FIREMODE_CUSTOM
		},
		[ALTFIRE_SETTING5] = {
			FIREMODE_SEMI,
			FIREMODE_BURST
		},
		[ALTFIRE_SETTING6] = {
			FIREMODE_SEMI,
			FIREMODE_FULL,
			FIREMODE_BURST
		},
		[ALTFIRE_SETTING7] = {
			FIREMODE_SEMI,
			FIREMODE_FULL,
			FIREMODE_PLASMA
		},
		[ALTFIRE_SETTING8] = {
			FIREMODE_SEMI,
			FIREMODE_BURST
		},

	},

	Callbacks = {
		[FIREMODE_SEMI] = function(self) self.Primary.Automatic = false end,
		[FIREMODE_FULL] = function(self) self.Primary.Automatic = true end,
		[FIREMODE_PLASMA] = function(self)
			self.UseHeatsink = true
			self.Primary.Automatic = self.FullAutoPlasma
		end
	},

	data = {
		IsBursting = false,
		BurstTimer = 0,
		BurstCounter = 0
	}
}

function SWEP:Swap()
	if self.Firemodes.Firemodes[ self.AltFire ] then
		local data = self.Firemodes.Firemodes[ self.AltFire ]

		if self.Firemodes.i_fPos < #data then
			self.Firemodes.i_fPos = self.Firemodes.i_fPos + 1
		else
			self.Firemodes.i_fPos = 1
		end

		local callback = self.Firemodes.Callbacks[ data[ self.Firemodes.i_fPos ]]

		if callback then
			callback(self)
		end

		self.Firemodes.SelectedFiremode = self.Firemodes.Firemodes[ self.AltFire ][ self.Firemodes.i_fPos ]

		if not(self.Firemodes.SelectedFiremode == FIREMODE_PLASMA) then
			self.UseHeatsink = false
		end

		self.Owner:EmitSound("weapons/smg1/switch_single.wav", 70, math.random(99, 101))

		umsg.Start("UPFM", self.Owner)
			umsg.Entity(self)
			umsg.Short(self.Firemodes.SelectedFiremode)
			umsg.Bool(self.Primary.Automatic)
			umsg.Bool(self.UseHeatsink)
		umsg.End()
	end
end

usermessage.Hook("UPFM", function(msg)
	local self = msg:ReadEntity()

	self.Firemodes.SelectedFiremode = msg:ReadShort()
	self.Primary.Automatic = msg:ReadBool()
	self.UseHeatsink = msg:ReadBool()
end)

function SWEP:GetData()
	return self.Firemodes.SelectedFiremode
end

function SWEP:DoImpactEffect()
	if self.IsRedPlasma || self.IsBluePlasma || self:GetData() == FIREMODE_PLASMA then
		return true
	end
end

//Update OverHeat
usermessage.Hook("UO", function(msg)

	local self = LocalPlayer():GetActiveWeapon()

	self.heatsinkOverheated = msg:ReadBool()

end)

//Update HeatValue
usermessage.Hook("UH", function(msg)

	local self = LocalPlayer():GetActiveWeapon()

	self.heatsinkHeat = msg:ReadShort()

end)

//Remove Ammo Dependency (Client)
usermessage.Hook("IAMMOSYS", function(msg)

	local self = msg:ReadEntity()

	self.IgnoreAmmoSystem = msg:ReadBool()

end)

function SWEP:GetTracerShootPos(attach)
    local pos = nil

    local id = self:LookupAttachment(attach)
    local att = self:GetAttachment(id)
    if att then
        pos = att.Pos
    end

    return pos
end


function SWEP:FireM203()

	local shotpos = self.Owner:GetShootPos()

	self.DrawTimer = CurTime() + 5

	shotpos = shotpos + self.Owner:GetUp() * -13
	shotpos = shotpos + self.Owner:GetRight() * 9
	shotpos = shotpos + self.Owner:GetForward() * 25

	if SERVER then

		local rocket = ents.Create("ts2_40mm")

		if IsValid(rocket) then

			rocket:SetPos(shotpos)
			rocket:SetAngles(self.Owner:EyeAngles())
			rocket:SetOwner(self.Owner)
 			rocket:Spawn()
			rocket.Owner = self.Owner
			rocket.damage = 100

		end

		local b = ents.Create("info_target")

		if IsValid(b) then

			b:SetPos(self.Owner:GetEyeTrace().HitPos + Vector(0, 0, 0))
			b:Spawn()
			rocket:PointAtEntity(b)
			b:Remove()

		end

	end

	self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:MuzzleFlash()
	self.Owner:SetAnimation(PLAYER_ATTACK1)

	self:SetNextPrimaryFire(CurTime() + 3)

end

function SWEP:Initialize()

	if self.IsBluePlasma || self.IsRedPlasma then
		self.Primary.Tracer = "effect_laser"
	end

	if self.LastShotSound then
		self.LastShotSound = Sound(self.LastShotSound)
	end

	self.data.IsBursting = false
	self.data.BurstTimer = 0
	self.data.BurstCounter = 0

	self.HoldType = string.lower(self.TS2HoldType) or "normal"

	if self.HoldType == "rifle" then
		self.HoldType = "ar2"
	end

	if !self.HolsterType then
		if (self.HoldType == "ar2" ||
		   self.HoldType == "smg" ||
		   self.HoldType == "shotgun" ||
		   self.HoldType == "crossbow" ||
		   self.HoldType == "rpg" ||
		   self.HoldType == "gravgun" ||
		   self.HoldType == "passive") then
			self.HolsterType = "passive"
		else
			self.HolsterType = "normal"
		end
	else
		self.HolsterType = "passive"
	end

	self:SetWeaponHoldType(self.HolsterType)

	if self.Primary.Automatic then
		self.Firemodes.SelectedFiremode = FIREMODE_FULL
	end

	if self.Firemodes.Firemodes[ self.AltFire ] then
		self.Firemodes.SelectedFiremode = self.Firemodes.Firemodes[ self.AltFire ][ self.Firemodes.i_fPos ]

		if self.Firemodes.SelectedFiremode == FIREMODE_SEMI then
			self.Primary.Automatic = false
		elseif self.Firemodes.SelectedFiremode == FIREMODE_FULL then
			self.Primary.Automatic = true
		end
	else
		self.Firemodes.SelectedFiremode = self.FiremodeOverride or 1
	end

	if CLIENT then
		local iScreenWidth 		= surface.ScreenWidth()
		local iScreenHeight 	= surface.ScreenHeight()

		self.ScopeTable 		= { }
		self.ScopeTable.l 		= iScreenHeight * self.ScopeScale
		self.ScopeTable.x1 		= 0.5 * (iScreenWidth + self.ScopeTable.l)
		self.ScopeTable.y1 		= 0.5 * (iScreenHeight - self.ScopeTable.l)
		self.ScopeTable.x2 		= self.ScopeTable.x1
		self.ScopeTable.y2 		= 0.5 * (iScreenHeight + self.ScopeTable.l)
		self.ScopeTable.x3 		= 0.5 * (iScreenWidth - self.ScopeTable.l)
		self.ScopeTable.y3 		= self.ScopeTable.y2
		self.ScopeTable.x4 		= self.ScopeTable.x3
		self.ScopeTable.y4 		= self.ScopeTable.y1

		self.ParaScopeTable 	= { }
		self.ParaScopeTable.x 	= 0.5 * iScreenWidth - self.ScopeTable.l
		self.ParaScopeTable.y 	= 0.5 * iScreenHeight - self.ScopeTable.l
		self.ParaScopeTable.w 	= 2 * self.ScopeTable.l
		self.ParaScopeTable.h 	= 2 * self.ScopeTable.l

		self.ScopeTable.l 		= (iScreenHeight + 1) * self.ScopeScale

		self.QuadTable 			= { }
		self.QuadTable.x1		= 0
		self.QuadTable.y1 		= 0
		self.QuadTable.w1 		= iScreenWidth
		self.QuadTable.h1 		= 0.5 * iScreenHeight - self.ScopeTable.l
		self.QuadTable.x2 		= 0
		self.QuadTable.y2 		= 0.5 * iScreenHeight + self.ScopeTable.l
		self.QuadTable.w2 		= self.QuadTable.w1
		self.QuadTable.h2 		= self.QuadTable.h1
		self.QuadTable.x3 		= 0
		self.QuadTable.y3 		= 0
		self.QuadTable.w3 		= 0.5 * iScreenWidth - self.ScopeTable.l
		self.QuadTable.h3 		= iScreenHeight
		self.QuadTable.x4 		= 0.5 * iScreenWidth + self.ScopeTable.l
		self.QuadTable.y4 		= 0
		self.QuadTable.w4 		= self.QuadTable.w3
		self.QuadTable.h4 		= self.QuadTable.h3

		self.LensTable 			= { }
		self.LensTable.x 		= self.QuadTable.w3
		self.LensTable.y 		= self.QuadTable.h1
		self.LensTable.w 		= 2 * self.ScopeTable.l
		self.LensTable.h 		= 2 * self.ScopeTable.l

		self.CrossHairTable		= { }
		self.CrossHairTable.x11 = 0
		self.CrossHairTable.y11 = 0.5 * iScreenHeight
		self.CrossHairTable.x12 = iScreenWidth
		self.CrossHairTable.y12 = self.CrossHairTable.y11
		self.CrossHairTable.x21 = 0.5 * iScreenWidth
		self.CrossHairTable.y21 = 0
		self.CrossHairTable.x22 = 0.5 * iScreenWidth
		self.CrossHairTable.y22 = iScreenHeight

	end

end

function SWEP:OnRemove()
	if CLIENT then
		if self.mdl then
			self.mdl:Remove()
			self.mdl = nil
		end
	end
end

function SWEP:IsIgnoringAmmoSystem()

	if self.Owner.IgnoreAmmo then return true end
	if SERVER && self.IsMelee then return true end

end

function SWEP:GetWeaponHoldType()

 	return self.TS2HoldType

end


function SWEP:Deploy()

 	self.Owner:CrosshairDisable()
 	self.Reloading = false

 	self:SetWeaponHoldType("passive")

	self:SendWeaponAnim(ACT_VM_DRAW)
	return true
end


function SWEP:Equip()

	if (SERVER)  then

		if self:IsIgnoringAmmoSystem() then

			self.IgnoreAmmoSystem = true

			umsg.Start("IAMMOSYS", self.Owner)
				umsg.Entity(self)
				umsg.Bool(true)
			umsg.End()

		end

	end

end

function SWEP:CanReload()

    if SERVER and self.Owner.IsTied then

		return false

	end

	if self.Primary.PositionMode == 1 then return false end

	if self:IsIgnoringAmmoSystem() then return true end

	local d = 0
	local reloaddelay = tonumber(self.NextReload)

	if reloaddelay then

		d = self.NextReload - CurTime()

	end

	local i2 = (d > 0)

	if reloaddelay and i2 then

		return false

	end

	return true

end

function SWEP:CustomReload()

	if self.IgnoreAmmoSystem then

		self:SetClip1(self.Primary.ClipSize)
		return

	end

	//Find our ammo box.
	local succ, i, x, y, amt = self.Owner:HasItem(self.AmmoType)
	local ClipSize = 0

	if (self.IsRedPlasma || self.IsBluePlasma) then
		ClipSize = amt
	else
		ClipSize = self.Primary.ClipSize
	end

	//If we found one..
	if succ && not self.IgnoreAmmoSystem  then

		//Calculate how much ammo we need to reach the max. Max - Current.
		local needed = ClipSize - self:Clip1()

		//Is our needed amount somehow greater than it allows? or less than zero..?
		if (needed > ClipSize) or (needed < 0) then

			//Here, have one on the house!
			self:SetClip1(ClipSize)
			return

		elseif needed == 0 then

			//You. Get. NOTHING.
			return

		end

		//Do we have enough to supply your gun?
		if amt >= needed then

			//Load the gun up.
			self:SetClip1(self:Clip1() + needed)

			//Take the amount.
			amt = amt - needed

			//If there's nothing left...
			if amt == 0 then
				self.Owner:TakeItemAt(i, x, y)
			else
				self.Owner:ModifyItemAmount(i, x, y, amt)
			end

			return

		//Okay, we have ammo here. Take what I have.
		elseif amt > 0 then

			//Load the gun up.
			self:SetClip1(self:Clip1() + amt)

			//Take the box away.
			self.Owner:TakeItemAt(i, x, y)

			//FIND ME MORE AMMO. I'M NOT SATISFIED.
			self:CustomReload()

		end

	end

end

function SWEP:Reload()

	if self.IsMelee then

		return

	end

    if not self:CanReload() then

		return

	end

	if self.ShotgunReload && SERVER then

		local succ, i, x, y, amt = self.Owner:HasItem(self.AmmoType)

		if succ || self:IsIgnoringAmmoSystem() then

			if self:Clip1() < self.Primary.ClipSize then

				self.ShotgunReloading = true
				self:SetVar("reloadtimer", CurTime() + 0.5)
				self:SendWeaponAnim(ACT_SHOTGUN_RELOAD_START)
				self.Owner:SetAnimation(PLAYER_RELOAD)
				return

			end

		end

	end

	if SERVER then

	    if ((self:Clip1() < self.Primary.ClipSize) ||
			(self:Clip1() == 0 && !(self.IsBluePlasma || self.IsRedPlasma))) then

	    	if self.Reloading == false then

	    		local succ, i, x, y, amt = self.Owner:HasItem(self.AmmoType)

	    		if succ || self:IsIgnoringAmmoSystem() then

					self:SendWeaponAnim(ACT_VM_RELOAD)
					local nextact = CurTime() + self:SequenceDuration()
					self.Owner:SetAnimation(PLAYER_RELOAD)

					self:EmitSound(self.ReloadSound)
					self.NextReload = nextact
					self:SetNextPrimaryFire(nextact)

					self.Reloading = true

				end

			end

		end

	end

end

function SWEP:SecondaryAttack()

end

function SWEP:CanFire()

	if SERVER and self.Owner:GetPlayerHolstered() or CLIENT and ClientVars["Holstered"] then

		return false

	end

	if self.data.IsBursting == true then
		return false
	end

	if self.Owner:WaterLevel() >= 3 then -- They're underwater

		return false

	end

	if self.Owner.InStanceAction then

   		return false

   	end

	local Firemode = self:GetData()

	if Firemode == FIREMODE_M203 || Firemodee == FIREMODE_CUSTOM || Firemode == FIREMODE_PLASMA then return true end

	--if self:IsIgnoringAmmoSystem() || self.IgnoreAmmoSystem then return true end

	if not self.IsMelee and (self:Clip1() <= 0) then -- They're out of ammo

		if SeeSniperScope then
		RunConsoleCommand("eng_seescope", "0")
		SeeSniperScope = false
		end

		self:EmitSound("Weapon_Pistol.Empty")
		self:SetNextPrimaryFire(CurTime() + 0.3)
		return false

	end

	return true

end

function SWEP:DoHit(dmg, type)

	local trace = self.Owner:GetEyeTrace()

	if trace.HitPos:Distance(self.Owner:GetShootPos()) <= 75 then

		bullet = {}
		bullet.Num    = 1
		bullet.Src    = self.Owner:GetShootPos()
		bullet.Dir    = self.Owner:GetAimVector()
		bullet.Spread = Vector(0, 0, 0)
		bullet.Tracer = 0
		bullet.Force  = 3
		bullet.Damage = 2
		bullet.Callback  = function()

			trace.Entity:EmitSound(table.Random(self.HitSounds))

		end

		self.Owner:FireBullets(bullet)

	else

		self.Weapon:EmitSound("Zombie.AttackMiss")

	end

end

function SWEP:HandleMelee()

	self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	self.Owner:SetAnimation(PLAYER_ATTACK1)

	self.Weapon:EmitSound(table.Random(self.SwipeSounds))

	self.Weapon:SetNextPrimaryFire(CurTime() + .7)

	if SERVER then

		--tr.Entity:EmitSound(table.Random(self.HitSounds) or "weapons/crossbow/hitbod1.wav")

		self.Owner:SetPlayerSprint(self.Owner:GetPlayerSprint() - math.random(2, 5))

		local t = DMG_SLASH
		if self.IsKnife then t = DMG_SLASH else t = DMG_CLUB end

		self:DoHit(5, t)

	end

end

function SWEP:PrimaryAttack()

	local Firemode = self.Firemodes.SelectedFiremode

	if SERVER and self.Owner.IsTied then return end

	if not (self:CanFire()) then return end

	if self.Weapon:GetNWBool("Overheated", false) || self.heatsinkOverheated && self.UseHeatsink then return end

	if SERVER and self.Owner.InStanceAction || self:IsPlayerRunning() then

		return

	end

	if self.IsMelee then

		self:HandleMelee()
		return

	end

	if Firemode == FIREMODE_BURST then
		self.data.IsBursting = true
		return
	end

	if Firemode == FIREMODE_M203 then
		if SERVER then
			local succ, i, x, y, amt = self.Owner:HasItem("40mm")

			if succ then
				self:FireM203()
				self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
				if (amt - 1) == 0 then
					self.Owner:TakeItemAt(i, x, y)
				else
					self.Owner:ModifyItemAmount(i, x, y, amt - 1)
				end
			end
		end
	end

	if Firemode == FIREMODE_STATIC || Firemode == FIREMODE_SEMI || Firemode == FIREMODE_FULL || Firemode == FIREMODE_CUSTOM then
		self:ShootBullets()

		if self.UseHeatsink then
			self:AddHeat()
		end
	elseif Firemode == FIREMODE_PLASMA then
		self:ShootBullets(self.PlasmaData)
		self:AddHeat()
	end
end

local AimTbl =
{

	{ Aim = 10, Rec = 0 },
	{ Aim = 15, Rec = .20 },
	{ Aim = 20, Rec = .40 },
	{ Aim = 25, Rec = .42 },
	{ Aim = 30, Rec = .44 },
	{ Aim = 35, Rec = .46 },
	{ Aim = 40, Rec = .48 },
	{ Aim = 45, Rec = .50 },
	{ Aim = 50, Rec = .52 },
	{ Aim = 60, Rec = .54 },
	{ Aim = 70, Rec = .56 },
	{ Aim = 80, Rec = .58 },
	{ Aim = 90, Rec = .60 },
	{ Aim = 100, Rec = .62 },

}

local StrTbl =
{

	{ Str = 10, Rec = 0 },
	{ Str = 15, Rec = .20 },
	{ Str = 20, Rec = .40 },
	{ Str = 25, Rec = .42 },
	{ Str = 30, Rec = .44 },
	{ Str = 35, Rec = .46 },
	{ Str = 40, Rec = .48 },
	{ Str = 45, Rec = .50 },
	{ Str = 50, Rec = .60 },
	{ Str = 60, Rec = .62 },
	{ Str = 70, Rec = .64 },
	{ Str = 80, Rec = .66 },
	{ Str = 90, Rec = .68 },
	{ Str = 100, Rec = .70 },

}

function SWEP:IsPlayerRunning()

	if self.Owner:KeyDown(IN_SPEED) && self.Owner:GetVelocity():Length() > 0 then

		return true

	end

	return false

end

local function RaiseAim(attacker, tr, dmginfo)

	if tr.Entity and tr.Entity:IsValid() then

		if attacker:IsValid() and attacker:GetActiveWeapon():IsValid() then

			if SERVER then

				if CurTime() - attacker:GetTable().LastAimProgress > 2 then

					local exp = (attacker:GetActiveWeapon().Primary.ViewPunchMul / 4) *
					(1 - (attacker:GetPlayerAim() / 100))

					attacker:RaiseAimProgress(exp)
					attacker:GetTable().LastAimProgress = CurTime()

				end

			end

		end

	end

end

local function RaiseStrength(attacker, tr, dmginfo)

	if attacker:IsValid() and attacker:GetActiveWeapon():IsValid() then

		if SERVER then

			if CurTime() - attacker:GetTable().LastStrengthProgress > 5 then

				if attacker:KeyDown(IN_ATTACK2) then

					local exp = (attacker:GetActiveWeapon().Primary.ViewPunchMul / 4) *
					(1 - (attacker:GetPlayerStrength() / 100))

					attacker:RaiseStrengthProgress(exp)
					attacker:GetTable().LastStrengthProgress = CurTime()

				end

			end

		end

	end

end


function SWEP.PlasmaHit(attacker, tr, dmginfo)
	local laserhit = EffectData()
	laserhit:SetOrigin(tr.HitPos)
	laserhit:SetNormal(tr.HitNormal)
	laserhit:SetScale(dmginfo:GetBaseDamage())
	laserhit:SetStart(attacker:GetShootPos())
	util.Effect("effect_laserhit", laserhit)

	RaiseAim(attacker, tr, dmginfo)
	RaiseStrength(attacker, tr, dmginfo)

	return true
end

function SWEP.NormalHit(attacker, tr, dmginfo)

	/*local hit = EffectData()
	hit:SetOrigin(tr.HitPos)
	hit:SetNormal(tr.HitNormal)
	hit:SetScale(.3)
	util.Effect("effect_hit", hit);*/

	RaiseAim(attacker, tr, dmginfo)
	RaiseStrength(attacker, tr, dmginfo)

	return true

end

function SWEP:ShootBullets()

	local mul = 1
	local minspread = Vector(0, 0, 0)

 	if self.Owner:KeyDown(IN_SPEED) and self.Owner:GetVelocity():Length() > 110 then

 		mul = 5
 		minspread = Vector(.01, .01, .01)

 	elseif self.Owner:GetVelocity():Length() > 40 then

		mul = 2
		minspread = Vector(.01, .01, .01)

	end

	if SERVER then

		if self.Owner:GetPlayerDrunkMul() > 0 then

			mul = mul + self.Owner:GetPlayerDrunkMul() / .15
			minspread = Vector(.1, .1, .1)

		end

	end

	if self.Owner:KeyDown(IN_ATTACK2) then

		if self.UseScope then
			mul = mul * .2
		else
			mul = mul * .5
		end

	end

	if self.Owner:KeyDown(IN_DUCK) then

		mul = mul * .5

	end

	--Firehawk fix?
	--local spread = ((self.Primary.SpreadCone + Vector(.04, .04, .04) * self.Primary.Recoil) + minspread) * mul * aimoffset

	local spread = ((self.Primary.SpreadCone + Vector(.04, .04, .04) * self.Primary.Recoil) + minspread) * mul

	local t = team.GetName(self.Owner:Team())

	if SERVER && self.Owner:CanBeSkyNet() || (t == "SkyNet" or t == "SkyNet Stealth")  then
		spread = spread * .45
	end

	if self.ShotgunReload then

		spread = self.Primary.SpreadCone

	end

	local effectiveness = 1 - (self.IronsightAddEffectiveness / 100)
	spread = spread * effectiveness

	if self.ShotgunReloading then
		--self:SendWeaponAnim(ACT_SHOTGUN_RELOAD_PUMP)
		self.ShotgunReloading = false
		self:SetNextPrimaryFire(CurTime() + 0.3)
		return
	end

	if (self.CustomBullet && not (self:GetData() == FIREMODE_CUSTOM || self:GetData() == FIREMODE_PLASMA)) || not self.CustomBullet then
		local bullet = { }
	 	bullet.Num 		= self.Primary.NumShots
		bullet.Src 		= self.Owner:GetShootPos()
	 	bullet.Dir 		= self.Owner:GetAimVector()
	 	bullet.Spread 	= spread
	 	bullet.Tracer	= 0
	 	bullet.Force	= .1
	 	bullet.Damage	= self.Primary.Damage
	 	bullet.TracerName = self.Primary.Tracer

		bullet.Callback	= self.NormalHit

		if self.IsBluePlasma || self.IsRedPlasma then
			bullet.Tracer	= 1
			bullet.Callback = self.PlasmaHit
		end

		if self.BulletMod && self.Firemode == 5 then
			local delay, sound = self:BulletMod(bullet)
			self:SetNextPrimaryFire(CurTime() + delay)
			self:EmitSound(sound)
		else
			self:EmitSound(self.Primary.Sound)
			self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
		end

	 	self.Owner:FireBullets(bullet)
	 else
		if self.CustomBullet then
			self:CustomBullet()
			self:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
		end
	 end

	if (self:Clip1() - 1) == 0 && self.LastShotSound then
		self:EmitSound(self.LastShotSound)
	end

	if (self.CustomBullet && not (self:GetData() == FIREMODE_CUSTOM || self:GetData() == FIREMODE_PLASMA)) || not self.CustomBullet then
		self:TakePrimaryAmmo(1)
	end

	self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:SetAnimation(PLAYER_ATTACK1)

 	self.Owner:MuzzleFlash()

	for k, v in pairs(AimTbl) do

		if SERVER and self.Owner:GetPlayerAim() <= v.Aim or CLIENT and ClientVars["Aim"] <= v.Aim then

			self.RecoilReductionAim = math.Clamp(v.Rec, .1, .9)
			break

		end

	end

	for k, v in pairs(StrTbl) do

		if SERVER and self.Owner:GetPlayerStrength() <= v.Str or CLIENT and ClientVars["Strength"] <= v.Str then

			self.RecoilReductionStr = math.Clamp(v.Rec, .1, .9)
			break

		end

	end

	if self.Primary.DoorBreach then

		local trace = { }
	 	trace.start = self.Owner:GetShootPos()
	 	trace.endpos = trace.start + self.Owner:GetAimVector() * 600
	 	trace.filter = self.Owner

	 	local tr = util.TraceLine(trace)

	 	if tr.Entity and tr.Entity:IsValid() then
		 	if tr.Entity:IsDoor() and tonumber(tr.Entity:GetSkin()) ~= 12 then

				tr.Entity:EmitSound(Sound( "physics/wood/wood_box_impact_hard3.wav"))

				if SERVER then

					tr.Entity:Fire("unlock", "", 0)
					self.Owner:ConCommand("+use\n")
					timer.Simple(.2, function()
						self.Owner:ConCommand("-use\n")
					end)
					--Hide the original door
					tr.Entity:SetNotSolid(true)
					tr.Entity:SetNoDraw(true)

					--Make the fake door in it's place
					local ent = ents.Create("prop_physics")
					ent:SetPos(tr.Entity:GetPos())
					ent:SetAngles(tr.Entity:GetAngles())
					ent:SetModel(tr.Entity:GetModel())
					ent:SetSkin(tr.Entity:GetSkin())
					ent:Spawn()

					--Push the door down etc
					local norm = (tr.Entity:GetPos() - self.Owner:GetPos()):Normalize()
					local push = 19000 * norm

					timer.Simple(.2, function()
						ent:SetVelocity(push)
						ent:GetPhysicsObject().ApplyForceCenter(ent:GetPhysicsObject(), push)
					end)

					timer.Simple(280, function()

						--Make the original door visible again
						tr.Entity:SetNotSolid(false)
						tr.Entity:SetNoDraw(false)

						--Remove fake door
						if ent && IsValid(ent) then
							ent:Remove()
							ent = nil
						end

					end)

				end

			end
		end

	end

	self:ApplyRecoil()

end

function SWEP:ApplyRecoil()

	if SERVER then

		if self.Owner.NoRecoil then return end

	 	local eyeang = Angle(self.Primary.ViewPunchMul * math.Rand(-.6, .3), self.Primary.ViewPunchMul * math.Rand(-.6, .6), 0)
	 	local mult = 1

		//Is our player running?
	 	if self.Owner:KeyDown(IN_SPEED) and self.Owner:GetVelocity():Length() > 110 then
		 	eyeang = eyeang * 3

	 	//Is our player walking?
	 	elseif self.Owner:GetVelocity():Length() > 40 then
		 	eyeang = eyeang * 2

		end

		//Strength and Aim stat reduction.
		eyeang = eyeang * (1 - self.RecoilReductionStr)

		if self.Owner:KeyDown(IN_ATTACK2) then
			mult = .3
			eyeang = eyeang * (1 - self.RecoilReductionAim)
		end

		eyeang = eyeang * mult

		self.Owner:ViewPunch(eyeang  + Angle(-self.Primary.ZPunch, 0, 0))

		if SERVER and not self.Owner:IsListenServerHost() then return end

	 	self.Owner:SetEyeAngles(eyeang + Angle(-self.Primary.ZPunch, 0, 0)  + self.Owner:EyeAngles())

	end

end

SWEP.Primary.PositionMode = 3
SWEP.Primary.PositionTime = .2
SWEP.Primary.PositionMul = 1

function SWEP:GoIntoPosition(pos, ang, newpos, newang)

	local mul = self.Primary.PositionMul

	if self.Primary.PositionMode == 1 then

		self.SwayScale 	= 0.3
		self.BobScale 	= 0.1

	else

		self.SwayScale 	= 1.0
		self.BobScale 	= 1.0

	end

	if newang then

		local x, y, z

		if type (newang) == "Vector" then
			x, y, z = newang.x, newang.y, newang.z
		else
			x, y, z = newang.p, newang.y, newang.r
		end

		ang = ang * 1
		ang:RotateAroundAxis(ang:Right(), mul * x)
		ang:RotateAroundAxis(ang:Up(), mul * y)
		ang:RotateAroundAxis(ang:Forward(), mul * z)

	end

	pos = pos + newpos.x * ang:Right() * mul
	pos = pos + newpos.y * ang:Up() * mul
	pos = pos + newpos.z * ang:Forward() * mul

	return pos, ang

end

function SWEP:CalcViewModelView(vm, pos, ang, epos, eang)

	local IronAdd = Vector(0, 0, 0)

	if self.CoolSights && !self.UseScope then IronAdd = Vector(0, 0, 3) end

	if self.Primary.PositionMode == 1 then

		if self.Primary.IronSightPos then
			pos, ang = self:GoIntoPosition(epos * 1, eang * 1, self.Primary.IronSightPos + IronAdd, self.Primary.IronSightAng or Vector(0, 0, 0) )
		end
	elseif self.Primary.PositionMode == 2 or self.Primary.PositionMode == 3 then

		if self.Primary.HolsteredPos then
			pos, ang = self:GoIntoPosition(epos * 1, eang * 1, self.Primary.HolsteredPos, self.Primary.HolsteredAng or Vector(0, 0, 0))
		end

	elseif self.Primary.PositionMode == 0 then
		return
	end

 	vm:SetPos(pos)
	vm:SetAngles(ang)
end

if SERVER then

	function SWEP:SaveSwep(dt)

		local Ammo = self:Clip1()
		local Slot = (self.IsPrimary && not self.IsPrimary == false)

		if Slot == true then
			dt[1] = self:GetClass() .. ";" .. Ammo
		else
			dt[2] = self:GetClass() .. ";" .. Ammo
		end

	end

end

function SWEP:AddHeat(heat)

	heat = heat or self.heatsinkPower

	if CLIENT then

		if self.LastHeat and CurTime() - self.LastHeat < self.Primary.Delay then
			return
		end

		self.LastHeat = CurTime()

	end

	if self.UseHeatsink && not (self.heatsinkOverheated || self.heatsinkCooldown) then

		self.heatsinkHeat = self.heatsinkHeat + self.heatsinkPower

		if self.heatsinkHeat > 10 then self.heatsinkHeat = 10 end

	end

end

function SWEP:DoHeatsink()
	//Is it time for another tick already?
	if not (self.heatsinkNextThink < CurTime()) then return end

	//Is our weapon overheated? Are we cooling down our gun?
	if not (self.heatsinkOverheated || self.heatsinkCooldown) then

		//If heat is less than ten, but also greater than zero...
		if self.heatsinkHeat < 10  then

			if self.heatsinkHeat > 0 then

				//Take one from our heat
				self.heatsinkHeat = self.heatsinkHeat - 1
				//Set our think time.
				self.heatsinkNextThink = CurTime() + self.heatsinkRate

				umsg.Start("UH", self.Owner)
					umsg.Short(self.heatsinkHeat)
				umsg.End()

				return

			end

		//Is our heat greater or equal to ten?
		elseif self.heatsinkHeat >= 10 then

			//If yes, we've overheated the gun.
			self.heatsinkHeat = 10
			self.heatsinkOverheated = true
			self.heatsinkNextThink = CurTime() + 2

			umsg.Start("UO", self.Owner)
				umsg.Bool(self.heatsinkOverheated)
			umsg.End()

			umsg.Start("UH", self.Owner)
				umsg.Short(self.heatsinkHeat)
			umsg.End()

			return

		end

	//Are we overheated and not yet cooling down after our three second wait?
	elseif self.heatsinkOverheated && not self.heatsinkCooldown then

		//It's time to start cooling down.
		self.heatsinkCooldown = true
		self.heatsinkNextThink = CurTime() + 0.5

		umsg.Start("UO", self.Owner)
			umsg.Bool(self.heatsinkOverheated)
		umsg.End()

	end

	//Is it time to cool down our weapon?
	if self.heatsinkCooldown && self.heatsinkOverheated then

		//Can we take heat away?
		if self.heatsinkHeat <= 10 && self.heatsinkHeat > 0 then

			//Start cooling down with half a second delay.
			self.heatsinkHeat = self.heatsinkHeat - 1
			self.heatsinkNextThink = CurTime() + 0.5

			umsg.Start("UH", self.Owner)
				umsg.Short(self.heatsinkHeat)
			umsg.End()

			return

		//Are we done cooling down?
		elseif self.heatsinkHeat == 0 then

			//Now we're not.
			self.heatsinkOverheated = false
			self.heatsinkCooldown = false

			umsg.Start("UO", self.Owner)
				umsg.Bool(self.heatsinkOverheated)
			umsg.End()

			return

		end

	end

end

function SWEP:Think()

	self.HolsterOnce = self.HolsterOnce or false

	if CLIENT then
		if self.mdl && GetViewEntity() == self.Owner then
			self.mdl:SetNoDraw(true)
		end
	end

	if self:IsPlayerRunning() then
		if self.HolsterOnce == false then
			self:SetWeaponHoldType(self.HolsterType)
			self.HolsterOnce = true
		end
	else
		if not self.Holstered then
			if self.HolsterOnce == true then
				self:SetWeaponHoldType(self.HoldType)
				self.HolsterOnce = false
			end
		end
	end


	if SERVER then

		if self.ShotgunReload and self.ShotgunReloading then

			//TODO: Fix this shit.
			local succ, i, x, y, amt = self.Owner:HasItem(self.AmmoType)

			if self:GetVar("reloadtimer", 0) < CurTime() then

				if not (succ || self:IsIgnoringAmmoSystem()) then return end

				if self:Clip1() >= self.Primary.ClipSize then
					self.ShotgunReloading = false
					return
				end

				self:SetVar("reloadtimer", CurTime() + 0.45)

				if not (self:IsIgnoringAmmoSystem()) then
					if amt > 0 then
						self.Owner:ModifyItemAmount(i, x, y, amt - 1)
					else
						self.Owner:TakeItemAt(i, x, y)
					end
				end

				self:SetClip1( self:Clip1() + 1)

				self:ResetSequence(ACT_VM_RELOAD)
				self:SendWeaponAnim(ACT_VM_RELOAD)


				if self:Clip1() >= self.Primary.ClipSize || amt == 0 then

					self:SendWeaponAnim(ACT_SHOTGUN_RELOAD_FINISH)

				end

				self:EmitSound(Sound("Weapon_Shotgun.Reload"))

			end

		end

	end

	if self.data.IsBursting then
		if (self.data.BurstTimer < CurTime() &&
			self.data.BurstCounter < 3) then

			if self:Clip1() <= 0 then
				self:EmitSound("Weapon_Pistol.Empty")
				self.data.IsBursting = false
				self.data.BurstTimer = 0
				self.data.BurstCounter = 0
				return
			end

			if self.UseHeatsink then
				self:AddHeat()
			end

			self:ShootBullets()

			self.data.BurstTimer = CurTime() + self.Primary.Delay
			self.data.BurstCounter = self.data.BurstCounter + 1

		elseif self.data.BurstCounter == 3 then

			self.data.IsBursting = false
			self.data.BurstTimer = 0
			self.data.BurstCounter = 0

		end
	end

	--[[
	//Strictly the visual aspect. The client and server won't be 100% in sync, but should give
	//a good enough idea.
	if CLIENT then

		if self.UseHeatsink then

			local lastThink = self.heatsinkNextThink

			if not (lastThink < CurTime()) then return end

			if self.heatsinkHeat && self.heatsinkCooldown then

				if self.heatsinkHeat <= 10 && self.heatsinkHeat > 0 then

					self.heatsinkHeat = self.heatsinkHeat - 1
					lastThink = CurTime() + 0.1

				else

					self.heatsinkCooldown = false

				end

			elseif not (self.heatsinkOverheated || self.heatsinkCooldown) then

				if self.heatsinkHeat <= 10 && self.heatsinkHeat > 0 then

					self.heatsinkHeat = self.heatsinkHeat - 1
					lastThink = CurTime() + self.heatsinkRate

				end

			end

			self.heatsinkNextThink = lastThink

		end

	end
	]]--

	if SERVER then
		if self.Owner:KeyDown(IN_USE) then
			if self.Owner:KeyPressed(IN_ATTACK2) && self.AltFire ~= ALTFIRE_STATIC then
				self:Swap()
			end
		end
	end

	if SERVER then

		self:DoHeatsink()

		if self.Reloading == true && (self.NextReload < CurTime()) then

			if not (self:IsIgnoringAmmoSystem()) then
				self:CustomReload()
			else
				self:SetClip1(self.Primary.ClipSize)
			end

			self.Reloading = false

		end

	end

end

SeeSniperScope = false

function SWEP:DrawHUD()

	if self.UseScope then

		if math.floor(self.Primary.PositionMode) == 1 and math.floor(self.Primary.PositionMul) == 1 then

			if not SeeSniperScope then

				RunConsoleCommand("eng_seescope", "1")
				SeeSniperScope = true

			end

			local scope = "jaanus/ep2snip_parascope"

			--TODO: Add new scope.
			if self.ParabolicScope then
				scope = "jaanus/ep2snip_parascope"
			else
				scope = "jaanus/ep2snip_parascope" --Add a regular scope texture here!
			end

			surface.SetDrawColor(0, 0, 0, 255)
			surface.SetTexture(surface.GetTextureID(scope))
			surface.DrawTexturedRect(self.ParaScopeTable.x,self.ParaScopeTable.y,self.ParaScopeTable.w,self.ParaScopeTable.h)

			-- Draw the lens
			surface.SetDrawColor(0, 0, 0, 255)
			surface.SetTexture(surface.GetTextureID("overlays/scope_lens"))
			surface.DrawTexturedRect(self.LensTable.x,self.LensTable.y,self.LensTable.w,self.LensTable.h)

			-- Draw the scope
			surface.SetDrawColor(0, 0, 0, 255)
			surface.SetTexture(surface.GetTextureID("jaanus/sniper_corner"))
			surface.DrawTexturedRectRotated(self.ScopeTable.x1,self.ScopeTable.y1,self.ScopeTable.l,self.ScopeTable.l,270)
			surface.DrawTexturedRectRotated(self.ScopeTable.x2,self.ScopeTable.y2,self.ScopeTable.l,self.ScopeTable.l,180)
			surface.DrawTexturedRectRotated(self.ScopeTable.x3,self.ScopeTable.y3,self.ScopeTable.l,self.ScopeTable.l,90)
			surface.DrawTexturedRectRotated(self.ScopeTable.x4,self.ScopeTable.y4,self.ScopeTable.l,self.ScopeTable.l,0)

			-- Fill in everything else
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawRect(self.QuadTable.x1,self.QuadTable.y1,self.QuadTable.w1,self.QuadTable.h1)
			surface.DrawRect(self.QuadTable.x2,self.QuadTable.y2,self.QuadTable.w2,self.QuadTable.h2)
			surface.DrawRect(self.QuadTable.x3,self.QuadTable.y3,self.QuadTable.w3,self.QuadTable.h3)
			surface.DrawRect(self.QuadTable.x4,self.QuadTable.y4,self.QuadTable.w4,self.QuadTable.h4)

			if self.ParabolicScope then

				local rotatick = CurTime()*90/5
				surface.SetTexture(surface.GetTextureID("jaanus/rotatingthing"))
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawTexturedRectRotated(ScrW()/2, ScrH()/2,self.LensTable.w * 1.2, self.LensTable.h * 1.2, rotatick)

			end

		else

			if SeeSniperScope then

				RunConsoleCommand("eng_seescope", "0")
				SeeSniperScope = false

			end

		end

	elseif self.CoolSights then

		if not self.Owner:KeyDown(IN_USE) then
			if not (self.Owner:KeyDown(IN_SPEED)) then
				if self.Owner:KeyDown(IN_ATTACK2) then
					self.FOVOffset = math.Approach(self.FOVOffset, self.FOVApprUp, (self.FOVApprUp - self.FOVOffset) * (FrameTime() * 12))
				else
					self.FOVOffset = math.Approach(self.FOVOffset, 0, (0 - self.FOVOffset) * (FrameTime() * 12))
				end
			else
				self.FOVOffset = math.Approach(self.FOVOffset, 0, (0 - self.FOVOffset) * (FrameTime() * 12))
			end

		end

	end

end

function SWEP:CalcView(ply, origin, angles, fov)

	local view = {}
	view.origin = origin
	view.angles = angles
	view.fov = fov + self.FOVOffset

	return view.origin, view.angles, view.fov

end

function SWEP:HolsterToggle()

	self.Owner:ConCommand("eng_seescope 0\n")

end

function SWEP:SetHolstered(holstered)
	if holstered != self.Holstered then
		self.Holstered = holstered
		if self.Holstered then
			self:SetWeaponHoldType(self.HolsterType)
		else
			self:SetWeaponHoldType(self.HoldType)
		end
	end
end