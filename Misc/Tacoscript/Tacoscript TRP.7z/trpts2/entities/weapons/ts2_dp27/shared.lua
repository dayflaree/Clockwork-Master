
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then
		SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/ak47.wav")

SWEP.WorldModel = "models/weapons/w_dp27.mdl"
SWEP.ViewModel = "models/weapons/v_dp27.mdl"

SWEP.PrintName = "Degtyaryov DP27"
SWEP.TS2Desc = "Soviet LMG - 7.62mm Belt"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .7

 SWEP.Primary.ViewPunchMul = 12
 SWEP.Primary.Damage			= 15
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SHOTGUN"
 SWEP.Category = "Tacoscript 2 - LMGs"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 47
SWEP.Primary.DefaultClip = 300
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)


SWEP.Primary.IronSightPos = Vector(3.2757, 1.1871, 0)
SWEP.Primary.IronSightAng = Vector(0, 0, 0 )


SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(11, 200, -5)
SWEP.IconLookAt = Vector(1.44, 2, -0.96)
SWEP.IconFOV = 14.3

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62box"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-5,
		OffR	=	0.48,
		OffU	=	-0.88,
		OffRotR	=	181,
		OffRotF	=	80,
		OffRotU	=	-2,
		Bone	=	'ValveBiped.Bip01_Spine4'
}
end
