
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.ViewModelFlip		= true

SWEP.Primary.Sound = Sound("Weapons/silenced.wav")

SWEP.ViewModel			= "models/weapons/v_mp9_tmp.mdl"
SWEP.WorldModel			= "models/weapons/w_mp9.mdl"

SWEP.PrintName = "MP9"
SWEP.TS2Desc = "Silenced MP9 TMP"


 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 3
 SWEP.Primary.Damage			= 8
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .07
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.02, 0.02, 0.02)

SWEP.Primary.IronSightPos = Vector(2.611200094223, 2.0278000831604, -4.8014998435974)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5.6999969482422, -4, 3)
SWEP.Primary.HolsteredAng = Vector(-5, -35.5, 18)

 SWEP.ItemWidth = 2
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(50, -86, 4)
SWEP.IconLookAt = Vector(-2.67, -1, -3)
SWEP.IconFOV = 15.7

SWEP.ReloadSound = "weapons/smg1/smg1_reload.wav"

SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5,
		OffR	=	2.68,
		OffU	=	3.12,
		OffRotR	=	34.6,
		OffRotF	=	-2340.9,
		OffRotU	=	-358.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
