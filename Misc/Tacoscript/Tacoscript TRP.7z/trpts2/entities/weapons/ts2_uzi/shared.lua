
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.ViewModelFlip		= false

SWEP.ViewModel			= "models/weapons/v_uzi.mdl"
SWEP.WorldModel			= "models/weapons/w_uzi.mdl"
SWEP.Primary.Sound			= Sound("weapons/l22.wav")

SWEP.PrintName = "UZI"
SWEP.TS2Desc = "Fully Automatic SMG - 9x19mm"


 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 3
 SWEP.Primary.Damage			= 8
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .07
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.02, 0.02, 0.02)

SWEP.Primary.IronSightPos = Vector(-4.5652, 1.4946, -6.1375)
SWEP.Primary.IronSightAng = Vector(0 , 0 , 0)


SWEP.Primary.HolsteredPos = Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-15.0, 15.0, 0.0)

 SWEP.ItemWidth = 2
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(53, 118.65, 4)
SWEP.IconLookAt = Vector(11.06, -1, -0.17)
SWEP.IconFOV = 10.1

SWEP.ReloadSound = "weapons/smg1/smg1_reload.wav"

SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-16.8,
		OffR	=	1.38,
		OffU	=	2.72,
		OffRotR	=	359.7,
		OffRotF	=	-2534.6,
		OffRotU	=	-723.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
