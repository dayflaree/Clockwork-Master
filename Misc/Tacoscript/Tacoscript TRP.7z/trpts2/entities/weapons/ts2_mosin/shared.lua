if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/k98_shoot2.wav")

SWEP.ViewModel				= "models/weapons/v_mosin.mdl"
SWEP.WorldModel				= "models/weapons/w_mosin.mdl"

SWEP.PrintName 				= "Mosin Rifle"
SWEP.TS2Desc 				= "Ancient battle rifle"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 8
SWEP.Primary.Damage			= 40
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 5
SWEP.Primary.DefaultClip 	= 50
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .6
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.001, .001, .001)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(-4.8849997520447, 1.539999961853, -8.8179998397827)
SWEP.Primary.IronSightAng = Vector(1.6526000499725, 1.6393003463745, -5.779999256134)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(35.25, 200, 77.49)
SWEP.IconLookAt = Vector(-30.61, -200, -77.3)
SWEP.IconFOV = 14.3

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.0658141036402e-014,
		OffR	=	4.08,
		OffU	=	-1.88,
		OffRotR	=	-27.4,
		OffRotF	=	-2506.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end