if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/lrshot.wav")

SWEP.ViewModel				= "models/weapons/v_smg6.mdl"
SWEP.WorldModel				= "models/weapons/w_smg5.mdl"

SWEP.PrintName 				= "M50A1 'Spitfire'"
SWEP.TS2Desc 				= "Heavy rapid fire plasma SMG"

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Recoil			= .15
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 19
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-3.3155999183655, 1.042100071907, -5.6546998023987)
SWEP.Primary.IronSightAng = Vector(0.99999982118607, -2.9802322831785e-009, 0)

SWEP.Primary.HolsteredPos = Vector(2.9362001419067, -1.7506012916565, -5.2210988998413)
SWEP.Primary.HolsteredAng = Vector(-1.3145999908447, 60.608200073242, -4.3667998313904)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-42, -200, 0)
SWEP.IconLookAt = Vector(-3, 8, 1)
SWEP.IconFOV = 10.1

SWEP.IsPrimary			 	= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.22
SWEP.heatsinkPower 			= 1

if CLIENT then
SWEP.PositionData = {
		OffF	=	7.8,
		OffR	=	3.38,
		OffU	=	2.82,
		OffRotR	=	1110.5,
		OffRotF	=	-898.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
