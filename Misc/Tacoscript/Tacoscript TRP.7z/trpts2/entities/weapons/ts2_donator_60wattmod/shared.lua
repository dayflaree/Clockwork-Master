if SERVER then

 	AddCSLuaFile("shared.lua")


 end

  	SWEP.HoldType = "pistol"
 SWEP.Base = "ts2_base"
SWEP.ViewModelFlip		= false
 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.Primary.Sound = Sound("weapons/plasma.wav")

SWEP.WorldModel = "models/weapons/w_60watt.mdl"
SWEP.ViewModel = "models/weapons/v_60watt.mdl"

SWEP.PrintName = "60 Watt Belt-Fed HMG"
SWEP.TS2Desc = "Oh dear..."

SWEP.IsBluePlasma = true
SWEP.IsRedPlasma = false

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 25
 SWEP.Primary.Damage			= 18
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Other"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .14
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-5.279, 1.7644, -0.826)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(10, 69, 18)
SWEP.IconLookAt = Vector(8, -27, -3)
SWEP.IconFOV = 32.5

SWEP.AmmoType = "plasmacell"

SWEP.IsPrimary = true
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	9.8,
		OffR	=	4.58,
		OffU	=	7.82,
		OffRotR	=	1283.5,
		OffRotF	=	-367,
		OffRotU	=	-1.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
