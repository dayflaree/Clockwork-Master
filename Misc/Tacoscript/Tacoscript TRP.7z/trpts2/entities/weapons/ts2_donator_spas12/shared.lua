
if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.ViewModelFlip			= true

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound			= Sound("Weapons/warhammer.wav")

SWEP.ViewModel				= "models/weapons/v_spas12.mdl"
SWEP.WorldModel				= "models/weapons/w_spas12.mdl"

SWEP.PrintName 				= "SPAS 12 Assault Shotgun"
SWEP.TS2Desc 				= "Autoloader"

SWEP.Primary.Recoil			= .3
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 30
SWEP.Primary.Damage			= 12
SWEP.Primary.NumShots		= 10

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 8
SWEP.Primary.DefaultClip 	= 40
SWEP.Primary.Ammo 			= "buckshot"
SWEP.Primary.Delay 			= 0.5
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)

SWEP.Primary.IronSightPos 	= Vector(2.6800005435944, 0.80000007152557, -9.8200073242188)
SWEP.Primary.IronSightAng 	= Vector(4.4703482582342e-010, 0.059999633580446, 0)

SWEP.Primary.HolsteredPos 	= Vector(-1.9999980926514, -0.40000000596046, -2.8000001907349)
SWEP.Primary.HolsteredAng 	= Vector(-5, -47.000064849854, 5.5999989509583)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-57.87, 200, -48.33)
SWEP.IconLookAt = Vector(-2.82, 1.56, -1.19)
SWEP.IconFOV = 8.7

SWEP.ShotgunReload 			= true
SWEP.AltFire				= false
SWEP.IsPrimary 				= true
SWEP.AmmoType 				= "12gauge"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.1,
		OffR	=	2.98,
		OffU	=	-0.079999999999993,
		OffRotR	=	922,
		OffRotF	=	-1804.3,
		OffRotU	=	-714.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
