if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 				= "RIFLE"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_srifle.mdl"
SWEP.ViewModel 				= "models/weapons/v_srifle.mdl"

SWEP.PrintName 				= "RSB-70"
SWEP.TS2Desc 				= "Heavy plasma machinegun"

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Recoil			= .3
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 0
SWEP.Primary.Damage			= 25
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Heavy Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .2
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos 	= Vector(-5.1625, 1.4744, -11.1282)
SWEP.Primary.IronSightAng 	= Vector(-0.4867, -0.6123, -11.0532)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(7, 71, 13)
SWEP.IconLookAt = Vector(8, -40, -3.24)
SWEP.IconFOV = 29.7

SWEP.IsPrimary 				= true

SWEP.AmmoType			 	= "plasmacell"


SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.3
SWEP.heatsinkPower 			= 1

SWEP.SkynetOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.8,
		OffR	=	4.38,
		OffU	=	4.82,
		OffRotR	=	925.5,
		OffRotF	=	-1085.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end