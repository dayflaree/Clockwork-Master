
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

if CLIENT then
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
end

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_sawnoff.mdl"
SWEP.WorldModel				= "models/weapons/w_sawnoff.mdl"
SWEP.Primary.Sound			= Sound("Weapons/elephantgun.wav")

SWEP.PrintName 				= "Sawnoff Shotgun"
SWEP.TS2Desc				= "Double Barrelled - 12 Gauge"

SWEP.ShotgunReload 			= true

SWEP.Primary.ViewPunchMul 	= 20
SWEP.Primary.Damage			= 8
SWEP.Primary.NumShots		= 12

SWEP.TS2HoldType			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.ClipSize 		= 2
SWEP.Primary.DefaultClip 	= 10
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= 0.1
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.2, .2, .2)


SWEP.Primary.IronSightPos 	= Vector(-2.7594, 1.702, -4.01)
SWEP.Primary.IronSightAng 	= Vector(0.5892, 0, -0.1397)

SWEP.Primary.HolsteredPos 	= Vector(-0.667, 0.514, -4.9061)
SWEP.Primary.HolsteredAng 	= Vector(-14.031, 0, 4.8206)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(24.300100764701, -200, 50)
SWEP.IconLookAt = Vector(-1.3324073881637, 6, -2.7068736845885)
SWEP.IconFOV = 5.0580179973112

SWEP.IsPrimary = false

SWEP.AltFire= 0

SWEP.AmmoType 				= "12gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	10.2,
		OffR	=	1.78,
		OffU	=	-4.28,
		OffRotR	=	614.8,
		OffRotF	=	-2426.8,
		OffRotU	=	-615.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
