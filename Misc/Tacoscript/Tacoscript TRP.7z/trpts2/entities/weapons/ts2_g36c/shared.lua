if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound = Sound("weapons/l22.wav")

SWEP.WorldModel = "models/weapons/w_g36c.mdl"
SWEP.ViewModel = "models/weapons/v_g36c.mdl"

SWEP.PrintName 				= "G36C"
SWEP.TS2Desc 				= "Modern Assault Rifle - 5.56"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 8
SWEP.Primary.Damage			= 9
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 90
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(4.8006, -0.977, -3.4317)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(200, 78, 6)
SWEP.IconLookAt = Vector(17.79, 5, -0.34)
SWEP.IconFOV = 10.1

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
	SWEP.PositionData = {
		OffF	=	1,
		OffR	=	5,
		OffU	=	5.54,
		OffRotR 	= 	90,
		Bone	=	"ValveBiped.Bip01_R_Clavicle"
	}
end