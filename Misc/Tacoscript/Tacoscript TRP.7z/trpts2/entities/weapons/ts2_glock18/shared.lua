if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true
SWEP.ViewModelFOV 			= 60


SWEP.ViewModel 				= "models/weapons/v_pist_glock18.mdl"
SWEP.WorldModel 			= "models/weapons/w_pist_glock18.mdl"

SWEP.PrintName 				= "Glock 18"
SWEP.TS2Desc 				= "A small fully-automatic pistol"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5
SWEP.Primary.RecoverTime 	= .4

SWEP.Primary.Sound 			= Sound("Weapons/glock/Glock18-1.wav")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 80
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Damage 		= 5
SWEP.Primary.Automatic 		= true

SWEP.Primary.ViewPunchMul 	= 3

SWEP.TS2HoldType 			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(4.340, 3.0, 2.0)
SWEP.Primary.IronSightAng 	= Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos 	= Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-15.0, 15.0, 0.0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight				= 1

SWEP.IconCamPos = Vector(9, -36, 8)
SWEP.IconLookAt = Vector(5, 8, 0)
SWEP.IconFOV = 18.5

SWEP.ReloadSound 			= ""

SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	2.7,
		OffR	=	-3.62,
		OffU	=	-3.68,
		OffRotR	=	272.3,
		OffRotF	=	-2784.9,
		OffRotU	=	-632.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end

