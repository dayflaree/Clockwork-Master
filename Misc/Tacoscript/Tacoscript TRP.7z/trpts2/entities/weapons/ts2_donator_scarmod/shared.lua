if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "SMG"

SWEP.ViewModelFlip			= true
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/usp/usp_unsil-1.wav")

SWEP.WorldModel 			= "models/weapons/w_scar.mdl"
SWEP.ViewModel 				= "models/weapons/v_scar.mdl"

SWEP.PrintName 				= "SCAR-L MK16"
SWEP.TS2Desc 				= "FN 5.56 Modern Assault Rifle"


SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 0
SWEP.Primary.Damage			= 16
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 3000
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.001, .001, .001)
SWEP.Primary.ReloadDelay 	= 1

SWEP.Primary.IronSightPos 	= Vector(2.967600107193, 0.51660007238388, -5.5040998458862)
SWEP.Primary.IronSightAng 	= Vector(0.23000004887581, -0.10999999195337, 0)

SWEP.Primary.HolsteredPos 	= Vector(-5.5999994277954, -1.5999991893768, -6.9999980926514)
SWEP.Primary.HolsteredAng 	= Vector(5, -64.400047302246, -7.8000068664551)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos 			= Vector(200, -47, 44)
SWEP.IconLookAt 			= Vector(24.17, -13.63, 7)
SWEP.IconFOV 				= 10.1

SWEP.ReloadSound 			= ""

SWEP.IsPrimary 				= true

SWEP.AltFire				= 1

SWEP.AmmoType 				= "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	7.1,
		OffR	=	3.98,
		OffU	=	4.92,
		OffRotR	=	923,
		OffRotF	=	-1806.3,
		OffRotU	=	-626.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
