if SERVER then

 	AddCSLuaFile("shared.lua")

 end
  	SWEP.HoldType = "pistol"
if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Sound 			= Sound("weapons/lrshot.wav")

SWEP.ViewModel				= "models/weapons/v_plasma_xp.mdl"
SWEP.WorldModel				= "models/weapons/w_plasmaxp.mdl"

SWEP.PrintName 				= "M30A1 'Canner'"
SWEP.TS2Desc 				= "Lightweight plasma rifle"


SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 16
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10
SWEP.Primary.DefaultClip 	= 9999
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(-4.4861998558044, -0.30829998850822, -6.8472995758057)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(8.3727054595947, -7.2934007644653, -11.587693214417)
SWEP.Primary.HolsteredAng = Vector(50.931789398193, 78.594734191895, 36.599987030029)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(200, -5, -10)
SWEP.IconLookAt = Vector(-1, -4, 0)
SWEP.IconFOV = 10.1

SWEP.ScopeScale 			= 0.4
SWEP.UseScope 				= true
SWEP.ScopeFOV 				= 20
SWEP.ParabolicScope 		= true

SWEP.IsPrimary 				= true

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.15
SWEP.heatsinkPower 			= 3
SWEP.AmmoType				= "plasmacell"

if CLIENT then
SWEP.PositionData = {
		OffF	=	8.8,
		OffR	=	2.88,
		OffU	=	1.82,
		OffRotR	=	1290.5,
		OffRotF	=	-1080.8,
		OffRotU	=	-269.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
