if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "revolver"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_taurus.mdl"
SWEP.WorldModel				= "models/weapons/w_taurus.mdl"

SWEP.PrintName 				= "Taurus Raging Bull"
SWEP.TS2Desc 				= "Revolver with 6 inch barrel"

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .8
SWEP.Primary.RecoverTime 	= .3

SWEP.Primary.Sound 			= Sound("Weapon_357.Single")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 6
SWEP.Primary.DefaultClip 	= 24
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= 0.15
SWEP.Primary.Damage 		= 18
SWEP.Primary.ViewPunchMul	= 7

SWEP.TS2HoldType 			= "revolver"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-5.6420998573303, 2.6822001934052, -7.1307997703552)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(2.7999999523163, -0.14000038802624, -2)
SWEP.Primary.HolsteredAng = Vector(-15, 15, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(5, 44.3, 7)
SWEP.IconLookAt = Vector(6.93, 8, 2.56)
SWEP.IconFOV = 22.7

SWEP.ReloadSound 			= ""
SWEP.AdminOnly				= true

SWEP.AmmoType 				= ".44"

if CLIENT then
SWEP.PositionData = {
		OffF	=	17.2,
		OffR	=	-2.22,
		OffU	=	-3.78,
		OffRotR	=	433.8,
		OffRotF	=	-2435.8,
		OffRotU	=	-612.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
