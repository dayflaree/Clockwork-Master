
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_shotcop.mdl"
SWEP.WorldModel				= "models/weapons/w_shotcop.mdl"
SWEP.Primary.Sound			= Sound("Weapons/warhammer.wav")

SWEP.PrintName 				= "8 Gauge Shotgun"
SWEP.TS2Desc 				= "Advanced Bot-Shotting Cannon"

SWEP.ShotgunReload 			= true

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .4
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 70
SWEP.Primary.Damage			= 12
SWEP.Primary.NumShots		= 12

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered	= true
SWEP.Primary.ClipSize 		= 6
SWEP.Primary.DefaultClip 	= 18
SWEP.Primary.Ammo 			= "buckshot"
SWEP.Primary.Delay 			= 1
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)
SWEP.Primary.Spread 		=  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos 	= Vector(-4.7138, 1.9404, -5.8676)
SWEP.Primary.IronSightAng 	= Vector(-0.0275, 0, -0.2153)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-26, 174, -91)
SWEP.IconLookAt = Vector(0.16, 1, 0)
SWEP.IconFOV = 8.7

SWEP.IsPrimary = true

SWEP.AmmoType = "8gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	4.8,
		OffR	=	4.88,
		OffU	=	1.82,
		OffRotR	=	915.5,
		OffRotF	=	-1465.8,
		OffRotU	=	-352.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
