-- finish laster

if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.Base = "ts2_base"

SWEP.HoldType = "pistol"
SWEP.TS2HoldType = "PISTOL"

SWEP.PrintName = "God Finger"
SWEP.TS2Desc = "SMITE THE INFIDELS"

SWEP.ViewModel = "models/weapons/v_fists.mdl"
SWEP.WorldModel = "models/weapons/w_fists.mdl"

if CLIENT then

	SWEP.CSMuzzleFlashes = false
	SWEP.DrawCrosshair = false
 	SWEP.ViewModelFlip = false

end

SWEP.Spawnable = false
SWEP.AdminSpawnable = true

SWEP.Primary.Sound = Sound("")

SWEP.Primary.ViewPunchMul = 0
SWEP.Primary.Damage = 0
SWEP.Primary.NumShots = 1

SWEP.Primary.ClipSize = 1024
SWEP.Primary.DefaultClip = 1024
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .12
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(0.01, 0.01, 0.01)

SWEP.Category = "Tacoscript 2 - Other"

SWEP.ItemWidth = 1
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(90, 0, 0)
SWEP.IconLookAt = Vector(0, -3, 1)
SWEP.IconFOV = 11

LastGodFingerModeSwitch = 0

GodFingerModes =
{
	"Shoot Bullet",
	"Shoot Red Plasma",
	"Shoot Blue Plasma",
	"Explode",
	"Knock out",
}

function SWEP:Initialize()

	CurrentGodFingerMode = 1

	if CLIENT then

		AddChat({ 1 }, "God Finger mode", GodFingerModes[CurrentGodFingerMode], "NewChatFont", Color(255, 0, 0, 255), Color(255, 0, 0, 255))

	end

end

function SWEP:PrimaryAttack()

	if CurrentGodFingerMode < 3 then

		self:ShootBullets()

	end

end

function SWEP:ShootBullets()

	if CurrentGodFingerMode == 1 then
		bullet.TracerName = "Tracer"
	elseif CurrentGodFingerMode == 2 then
		bullet.TracerName = "effect_laser"
	elseif CurrentGodFingerMode == 3 then
		bullet.TracerName = "effect_ionbeam"
	end

	if CurrentGodFingerMode == 1 then
		bullet.Callback = NormalHit
	elseif CurrentGodFingerMode == 2 then
		bullet.Callback = RedHit
	elseif CurrentGodFingerMode == 3 then
		bullet.Callback	= BlueHit
	end

	local bullet = { }
 	bullet.Num 		= self.Primary.NumShots
 	bullet.Src 		= self.Owner:GetShootPos()
 	bullet.Dir 		= self.Owner:GetAimVector()
 	bullet.Spread 	= Vector(0, 0, 0)
 	bullet.Tracer	= 1
 	bullet.Force	= .1
 	bullet.Damage	= 50

 	self.Owner:FireBullets(bullet)
 	self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
 	self.Owner:MuzzleFlash()
 	self.Owner:SetAnimation(PLAYER_ATTACK1)

 	self.Weapon:EmitSound(self.Primary.Sound)

end

function SWEP:SecondaryAttack()

	if CurTime() - LastGodFingerModeSwitch < 0.5 then return end

	if CurrentGodFingerMode < #GodFingerModes then

		CurrentGodFingerMode = CurrentGodFingerMode + 1

	else

		CurrentGodFingerMode = 1

	end

	if CLIENT then

		AddChat({ 1 }, "God Finger mode", GodFingerModes[CurrentGodFingerMode], "NewChatFont", Color(255, 0, 0, 255), Color(255, 0, 0, 255))

	end

	LastGodFingerModeSwitch = CurTime()

end
