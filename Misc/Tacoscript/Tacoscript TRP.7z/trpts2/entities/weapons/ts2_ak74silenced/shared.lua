if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/silenced.wav")

SWEP.WorldModel = "models/weapons/w_ak74su_mod.mdl"
SWEP.ViewModel = "models/weapons/v_ak74su_mod.mdl"

SWEP.PrintName 				= "AK74SU - Silenced"
SWEP.TS2Desc 				= "Modified Tactical Assault Rifle"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .6

SWEP.Primary.ViewPunchMul 	= 4
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 180
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(2.6024000644684, 0.43050000071526, -6.8523998260498)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5, -2, -5)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(50, 200, -12)
SWEP.IconLookAt = Vector(5.4199935173036, -8, 2)
SWEP.IconFOV = 9.9369967521476

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.38,
		OffU	=	4.82,
		OffRotR	=	1284.5,
		OffRotF	=	-725.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
