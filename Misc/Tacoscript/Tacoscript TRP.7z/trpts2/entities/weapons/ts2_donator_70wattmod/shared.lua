if SERVER then

 	AddCSLuaFile("shared.lua")


 end

  	SWEP.HoldType = "pistol"
 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.Primary.Sound = Sound("npc/strider/strider_minigun.wav")

SWEP.WorldModel = "models/weapons/w_ar3oisaw.mdl"
SWEP.ViewModel = "models/weapons/v_ar3oisaw.mdl"

SWEP.PrintName = "X-15"
SWEP.TS2Desc = "Be careful..."

SWEP.IsBluePlasma = false
SWEP.IsRedPlasma = true

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = 0
 SWEP.Primary.Damage			= 50
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SHOTGUN"
 SWEP.Category 	= "Tacoscript 2 - Heavy Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .2
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-5.1625, 1.4744, -11.1282)
SWEP.Primary.IronSightAng = Vector(-0.4867, -0.6123, -11.0532)

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-200, -30, 18)
SWEP.IconLookAt = Vector(8, 8, 2)
SWEP.IconFOV = 10.1

SWEP.IsPrimary = false

SWEP.AmmoType = "plasmacell"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	5.8,
		OffR	=	3.98,
		OffU	=	5.82,
		OffRotR	=	1283.5,
		OffRotF	=	-351,
		OffRotU	=	-89.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
