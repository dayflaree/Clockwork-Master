if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"
SWEP.ViewModelFlip			= true
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_75watt.mdl"
SWEP.ViewModel 				= "models/weapons/v_75watt.mdl"

SWEP.PrintName 				= "M50A2 'Firefly'"
SWEP.TS2Desc 				= "Lighter variant of the Spitfire"

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul	= 5
SWEP.Primary.Damage			= 16
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .14
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(5.0981001853943, -0.75849997997284, 0)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-2.6000001430511, -4, -2)
SWEP.Primary.HolsteredAng = Vector(-5, -48.200031280518, 7.3999972343445)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(10, 69, 18)
SWEP.IconLookAt = Vector(4, -27, -4)
SWEP.IconFOV = 31.1

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.3
SWEP.heatsinkPower 			= 1

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.8,
		OffR	=	4.38,
		OffU	=	4.82,
		OffRotR	=	925.5,
		OffRotF	=	-1085.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
