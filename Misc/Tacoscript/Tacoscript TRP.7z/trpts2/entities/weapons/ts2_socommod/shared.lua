if SERVER then

 	AddCSLuaFile("shared.lua")

end

 	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFOV = 50
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.ViewModel			= "models/weapons/v_socom.mdl"
SWEP.WorldModel			= "models/weapons/w_socom.mdl"
SWEP.Primary.Sound			= Sound("Weapons/silenced.wav")

SWEP.PrintName = "SOCOM Silenced"
SWEP.TS2Desc = "H&K Tactical Pistol - .45"

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize = 16
SWEP.Primary.DefaultClip = 60
SWEP.Primary.Ammo = "pistol"
SWEP.Primary.Delay = .09
SWEP.Primary.Damage = 9

SWEP.Primary.ViewPunchMul 	= 3

SWEP.TS2HoldType = "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone = Vector(.03, .02, .02)

SWEP.Primary.IronSightPos = Vector(-3.8844, 2.1651, -9.8495)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(0.8931,  -1.5349, -7.9634 )
SWEP.Primary.HolsteredAng = Vector(35.3605, 0, 4.9116)

SWEP.ItemWidth 		= 2
SWEP.ItemHeight 	= 1

SWEP.IconCamPos = Vector(-5, 200, -67)
SWEP.IconLookAt = Vector(-4, -10.897874475916, 2)
SWEP.IconFOV = 4.530523206079

SWEP.ReloadSound = ""

SWEP.AltFire= 0

SWEP.AmmoType = ".45ACP"

if CLIENT then
SWEP.PositionData = {
		OffF	=	7.1,
		OffR	=	1.58,
		OffU	=	-1.78,
		OffRotR	=	432.8,
		OffRotF	=	-2434.8,
		OffRotU	=	-615.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end

