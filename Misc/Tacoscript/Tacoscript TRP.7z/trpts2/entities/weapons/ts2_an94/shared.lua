
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/sg550/sg550-1.wav")

SWEP.WorldModel 			= "models/weapons/w_rif_an94.mdl"
SWEP.ViewModel 				= "models/weapons/v_rif_an94k.mdl"

SWEP.PrintName 				= "AN-94 Rifle"
SWEP.TS2Desc 				= "Advanced Russian Rifle"

SWEP.Primary.Recoil			= .05
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 25
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 60
SWEP.Primary.DefaultClip 	= 600
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 0.5

SWEP.Primary.IronSightPos = Vector(-4.023099899292, 2.4865000247955, -4.9018998146057)
SWEP.Primary.IronSightAng = Vector(-0.92990005016327, -0.080000005662441, -0.10719998925924)

SWEP.Primary.HolsteredPos = Vector(8.9499931335449, -2.2999980449677, -2.0499999523163)
SWEP.Primary.HolsteredAng = Vector(-5, 50, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(12.19, 200, 5)
SWEP.IconLookAt = Vector(5.45, 30, 0.67)
SWEP.IconFOV = 11.5

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-4.2,
		OffR	=	2.28,
		OffU	=	1.82,
		OffRotR	=	1409.5,
		OffRotF	=	-723.8,
		OffRotU	=	-3.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
