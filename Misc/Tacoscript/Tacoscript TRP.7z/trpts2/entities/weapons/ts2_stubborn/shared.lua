if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip = false
	SWEP.ViewModelFOV = 80

 end

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Sound 			=  Sound("npc/env_headcrabcanister/launch.wav")

SWEP.WorldModel 			= "models/weapons/w_stubborn.mdl"
SWEP.ViewModel 				= "models/weapons/v_stubborn.mdl"

SWEP.PrintName 				= "'Stubborn' Rifle"
SWEP.TS2Desc 				= "Plasma rifle made from various scavanged parts."

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 12
SWEP.Primary.Damage			= 9
SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .11
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-3.9537007808685, 2.3837006092072, -10.16822052002)
SWEP.Primary.IronSightAng = Vector(-1.2685992717743, 0.079999998211861, 0.055100001394749)

SWEP.Primary.HolsteredPos = Vector(2.3999996185303, -0.48000013828278, -5.5)
SWEP.Primary.HolsteredAng = Vector(-0.5, 55.900020599365, 1.1920929132714e-008)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-44.767473622338, 200, -68.275467010422)
SWEP.IconLookAt = Vector(2.2671117857584, 8.1235257562188, -1.8358388221153)
SWEP.IconFOV = 10.15707262017

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 1
SWEP.heatsinkPower 			= 10
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-3.6,
		OffR	=	4.88,
		OffU	=	-2.98,
		OffRotR	=	341,
		OffRotF	=	-2155,
		OffRotU	=	-721.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
