
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "RIFLE"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/rtak.wav")

SWEP.ViewModel			= "models/weapons/v_risky.mdl"
SWEP.WorldModel			= "models/weapons/w_risky.mdl"

SWEP.PrintName = "RKBR-13 'Risky King'"
SWEP.TS2Desc = "33rd Pacific Army Rifle"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 15
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 120
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(4.5184001922607, 1.7789999246597, -10.642495155334)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-4.3938007354736, -1.2557992935181, -3.3883004188538)
SWEP.Primary.HolsteredAng = Vector(-11.007599830627, -47.738399505615, 10.586000442505)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-60.614305712058, 165.14926529377, -51.240635348039)
SWEP.IconLookAt = Vector(-3.2811682344044, 26.008349900596, -7.411751827711)
SWEP.IconFOV = 8.5558734685259

SWEP.ReloadSound = ""


SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
	SWEP.PositionData = {
			OffF	=	-5.18,
			OffR	=	2.68,
			OffU	=	1.22,
			OffRotR	=	331,
			OffRotF	=	-2149,
			OffRotU	=	-720.3,
			Bone	=	'ValveBiped.Bip01_Spine2'
	}
end

