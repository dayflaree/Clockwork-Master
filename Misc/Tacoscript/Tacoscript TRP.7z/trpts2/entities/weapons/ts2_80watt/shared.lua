if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_xrifle.mdl"
SWEP.ViewModel 				= "models/weapons/v_xrifle.mdl"

SWEP.PrintName 				= "RSB-90"
SWEP.TS2Desc 				= "Rapid fire heavy plasma weapon"

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 0
SWEP.Primary.Damage			= 10
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Heavy Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .05
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.05, 0.05, 0.05)

SWEP.Primary.IronSightPos 	= Vector(-3.3709, 1.0427, -7.4501)
SWEP.Primary.IronSightAng 	= Vector(-2.4048, 0, 0.18)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(0, 69, 20)
SWEP.IconLookAt = Vector(9, -19, -2)
SWEP.IconFOV = 28.3

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.06
SWEP.heatsinkPower 			= 1

SWEP.SkynetOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.8,
		OffR	=	4.38,
		OffU	=	4.82,
		OffRotR	=	925.5,
		OffRotF	=	-1085.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
