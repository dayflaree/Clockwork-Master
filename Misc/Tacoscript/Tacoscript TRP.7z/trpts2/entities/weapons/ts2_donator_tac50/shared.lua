
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV 		= 60
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/as50.wav")

SWEP.WorldModel = "models/weapons/w_tac50.mdl"
SWEP.ViewModel = "models/weapons/v_tac50.mdl"

SWEP.PrintName = "TAC-50 Sniper Rifle"
SWEP.TS2Desc = "Anti Material Bolt Action"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 30
 SWEP.Primary.Damage			= 100
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Other"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 20
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 1.5
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.001, .001, .001)
 SWEP.Primary.ReloadDelay = 2

SWEP.Primary.IronSightPos = Vector(3.196, 1.9062, 0)
SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

 SWEP.ItemWidth = 5
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(21.04, -8.16, 200)
SWEP.IconLookAt = Vector(19.09, 2.02, 50.91)
SWEP.IconFOV = 15.7

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.AmmoType = ".50BMG"

SWEP.IsPrimary = true
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-9.8,
		OffR	=	7.58,
		OffU	=	0.32000000000001,
		OffRotR	=	381.7,
		OffRotF	=	-2255.6,
		OffRotU	=	-723.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

