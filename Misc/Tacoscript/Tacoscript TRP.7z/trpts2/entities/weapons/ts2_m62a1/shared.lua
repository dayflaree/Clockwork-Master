if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip = true

 end

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_battlefield_rifle.mdl"
SWEP.ViewModel 				= "models/weapons/v_battlefield_rifle.mdl"

SWEP.PrintName 				= "M62A1"
SWEP.TS2Desc 				= ""

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 10
SWEP.Primary.Damage			= 25
SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .13
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(3.1062998771667, 0.20370006561279, -1.5881948471069)
SWEP.Primary.IronSightAng = Vector(0.91140002012253, 0, 0.055100001394749)

SWEP.Primary.HolsteredPos = Vector(-5.1999998092651, -0.88000011444092, -2)
SWEP.Primary.HolsteredAng = Vector(-0.5, -49.200000762939, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(3.7839965963439, 200, 71.245483472596)
SWEP.IconLookAt = Vector(5.6599785834855, -200, -66.240921989149)
SWEP.IconFOV = 9.4451018178717

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true
SWEP.UseScope 				= true

SWEP.heatsinkRate 			= 0.16
SWEP.heatsinkPower 			= 1
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-2.8,
		OffR	=	3.08,
		OffU	=	-2.78,
		OffRotR	=	340,
		OffRotF	=	-2155.2,
		OffRotU	=	-716.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

