if SERVER then

	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
	SWEP.ViewModelFOV 		= 70

end

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_deserteagle.mdl"
SWEP.WorldModel				= "models/weapons/w_deserteagle.mdl"

SWEP.PrintName 				= "Desert Eagle 50"
SWEP.TS2Desc 				= "High Calibre Sidearm - .50Cal"

SWEP.Primary.Sound 			= Sound("Weapons/deagle/deagle-1.wav")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 8
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "ar2"
SWEP.Primary.Delay 			= .08
SWEP.Primary.Damage 		= 30
SWEP.Primary.ViewPunchMul 	= 15

SWEP.TS2HoldType 			= "revolver"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.HoldType 				= "revolver"

SWEP.IsPrimary 				= false

SWEP.Primary.SpreadCone 	= Vector(.015, .015, .015)

SWEP.Primary.IronSightPos = Vector(5.1220002174377, 1.2899997234344, -4.8289995193481)
SWEP.Primary.IronSightAng = Vector(3.1999990940094, -3.5200009346008, 0.40000003576279)

SWEP.Primary.HolsteredPos = Vector(0.89310002326965, -8.5348997116089, -4.963399887085)
SWEP.Primary.HolsteredAng = Vector(49.360500335693, -1, 3.911600112915)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-5, -70.33, -5)
SWEP.IconLookAt = Vector(-2.79, 5, -1.98)
SWEP.IconFOV = 12.9

SWEP.ReloadSound 			= ""
SWEP.AmmoType 				= ".50AE"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	12.7,
		OffR	=	0.58,
		OffU	=	-4.68,
		OffRotR	=	265.1,
		OffRotF	=	-2784.8,
		OffRotU	=	-623.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
