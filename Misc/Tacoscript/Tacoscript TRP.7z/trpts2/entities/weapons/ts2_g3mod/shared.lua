if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
end

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/ak47.wav")

SWEP.WorldModel 			= "models/weapons/w_g3_mod.mdl"
SWEP.ViewModel 				= "models/weapons/v_g3_mod.mdl"

SWEP.PrintName 				= "G3 Assault Carbine"
SWEP.TS2Desc 				= "H&K Rifle with drum mag - 7.62"

SWEP.HoldType = "pistol"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 14
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 120
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .12
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.01, .01, .01)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos 	= Vector(-3.9305999279022, 1.2977002859116, -10.497599601746)
SWEP.Primary.IronSightAng	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(8.8000001907349, -3, -2)
SWEP.Primary.HolsteredAng 	= Vector(-5, 50, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(10, 200, 31)
SWEP.IconLookAt = Vector(4.63, 17, 3.49)
SWEP.IconFOV = 7.3

SWEP.ReloadSound 			= ""

SWEP.IsPrimary 				= true
SWEP.AdminOnly				= true
SWEP.AmmoType 				= "7.62mm"
SWEP.AltFire = 1

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.3,
		OffR	=	4.68,
		OffU	=	5.12,
		OffRotR	=	208.6,
		OffRotF	=	-2543.4,
		OffRotU	=	-719.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
