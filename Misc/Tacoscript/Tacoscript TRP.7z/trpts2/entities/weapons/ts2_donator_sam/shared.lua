if SERVER then
 	AddCSLuaFile("shared.lua")
end

if CLIENT then
	SWEP.DrawCrosshair 		= false
end

SWEP.Base 					= "ts2_base"
SWEP.HoldType				= "rifle"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.WorldModel 			= "models/weapons/w_combine_sam_kit.mdl"
SWEP.ViewModel 				= "models/weapons/v_sam.mdl"

SWEP.Primary.Sound			= Sound("weapons/stinger_fire1.wav")

SWEP.PrintName 				= "Javelin TAC-SAM Launcher"
SWEP.TS2Desc 				= "US Millitary Converted Anti-HK Launcher"

SWEP.Primary.Recoil			= .7
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .6

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 100
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "rifle"
SWEP.Category 				= "Tacoscript 2 - Explosive"

SWEP.Primary.ClipSize 		= 1
SWEP.Primary.DefaultClip 	= 10
SWEP.Primary.Ammo 			= "RPG_Round"
SWEP.Primary.Delay 			= 0.3
SWEP.Primary.SpreadCone 	= Vector(0,0,0)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos 	= Vector(-3.7399997711182, 4.0200004577637, -9)
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(10.800000190735, -5, -2)
SWEP.Primary.HolsteredAng 	= Vector(-5, 50, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos				= Vector(50, 141, -5.6956905202846)
SWEP.IconLookAt 			= Vector(13.196629643007, -20.035969143096, 4.1507982827948)
SWEP.IconFOV 				= 16.492044291071

SWEP.AmmoType				= "rocketgrenade"
SWEP.CustomAmmo				= "rocketgrenade"

SWEP.AltFire = 0
SWEP.FiremodeOverride = FIREMODE_CUSTOM

SWEP.IsPrimary 				= true
SWEP.AdminOnly				= true

SWEP.ScopeScale 			= 0.4
SWEP.UseScope 				= true
SWEP.ScopeFOV 				= 20
SWEP.ParabolicScope 		= true

SWEP.ReloadSound 			= ""

if CLIENT then
SWEP.PositionData = {
		OffF	=	14.2,
		OffR	=	2.38,
		OffU	=	10.32,
		OffRotR	=	569.7,
		OffRotF	=	-2509.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end


function SWEP:CustomBullet()
	local shotpos = self.Owner:GetShootPos()

	shotpos = shotpos + self.Owner:GetForward() * 30
	shotpos = shotpos + self.Owner:GetRight() * 10
	shotpos = shotpos + self.Owner:GetUp() * -5

	if self.Owner:KeyDown(IN_ATTACK2) then
		local v = self.Owner:GetShootPos()
			v = v + self.Owner:GetForward() * 25
			v = v + self.Owner:GetRight() * -1
			v = v + self.Owner:GetUp() * -6
		shotpos = v
	end

	if SERVER then
		local rocket = ents.Create("sent_rpgrocket")

		if IsValid(rocket) then
			rocket:SetPos(shotpos)
			rocket:SetAngles(self.Owner:EyeAngles())
			rocket:SetOwner(self.Owner)
 			rocket:Spawn()
			rocket.Owner = self.Owner
			rocket.damage = self.Primary.Damage
		end
	end

	self:TakePrimaryAmmo(1)
	self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:MuzzleFlash()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
end