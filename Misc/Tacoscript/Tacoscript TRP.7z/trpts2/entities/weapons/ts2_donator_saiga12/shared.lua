
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.HoldType				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true
SWEP.ViewModelFlip			= true
SWEP.ViewModel				= "models/weapons/v_saiga12.mdl"
SWEP.WorldModel				= "models/weapons/w_saiga12.mdl"
SWEP.Primary.Sound			= Sound("Weapons/warhammer.wav")

SWEP.PrintName 				= "Saiga12 Assault Shotgun"
SWEP.TS2Desc 				= "Compact Autoloader"


SWEP.ShotgunReload 			= false

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 10
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 8

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 12
SWEP.Primary.DefaultClip 	= 160
SWEP.Primary.Ammo 			= "buckshot"
SWEP.Primary.Delay 			= 0.2
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)
SWEP.Primary.Spread 		=  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(5.3800001144409, -0.16000002622604, -9.1599998474121)
SWEP.Primary.IronSightAng = Vector(0.099999569356441, -0.040000006556511, 0)

SWEP.Primary.HolsteredPos = Vector(-4.0600991249084, -1.3282001018524, -5.2731971740723)
SWEP.Primary.HolsteredAng = Vector(-3.7325999736786, -56.353099822998, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(2.7578018185689, 200, 6.713983652006)
SWEP.IconLookAt = Vector(5.3557270972575, 1.5599999427795, -0.06332936216206)
SWEP.IconFOV = 6.7326210770335

SWEP.IsPrimary = true

   SWEP.AmmoType = "12gauge"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.1,
		OffR	=	3.48,
		OffU	=	4.92,
		OffRotR	=	1118,
		OffRotF	=	-1611.3,
		OffRotU	=	-534.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
