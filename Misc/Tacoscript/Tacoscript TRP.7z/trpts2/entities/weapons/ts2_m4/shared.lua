if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then


	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound = Sound("weapons/mp5.wav")

SWEP.WorldModel = "models/weapons/w_m4beowolf.mdl"
SWEP.ViewModel = "models/weapons/v_m4beowolf.mdl"

SWEP.PrintName 				= "M4 Rifle"
SWEP.TS2Desc 				= "US Millitary Standard Issue Carbine"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .4
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul	= 6
SWEP.Primary.Damage			= 10
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 150
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(2.433000087738, 0.26120001077652, -4.5974998474121)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-5.3000001907349, -3, -4)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(11, -163, 5)
SWEP.IconLookAt = Vector(-2.05, 7, -2.49)
SWEP.IconFOV = 11.5

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	3,
		OffR	=	5.08,
		OffU	=	0.12,
		OffRotR	=	147.6,
		OffRotF	=	-2338.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
