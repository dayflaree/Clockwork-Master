if SERVER then
 	AddCSLuaFile("shared.lua")
end

  	SWEP.HoldType = "smg"

if CLIENT then
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair		= false
end

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapon_AR2.Double")

SWEP.WorldModel 			= "models/weapons/w_rg6.mdl"
SWEP.ViewModel 				= "models/weapons/v_rg6.mdl"

SWEP.PrintName 				= "RG6"
SWEP.TS2Desc 				= "Rotary Cylinder Grenade Launcher - Vog25"

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 12
SWEP.Primary.Damage			= 50
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "smg"
SWEP.Category 				= "Tacoscript 2 - Explosive"

SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 6
SWEP.Primary.DefaultClip 	= 160
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .5
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(15.155584335327, 0.1157998368144, -20.927810668945)
SWEP.Primary.IronSightAng = Vector(-6.6530990600586, 2.1999998092651, 0.043599963188171)

SWEP.Primary.HolsteredPos = Vector(-8.0180997848511, -9.7594003677368, -1.794499874115)
SWEP.Primary.HolsteredAng = Vector(-6.9388999938965, -52.711128234863, 13.464757919312)

SWEP.ItemWidth 			= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-8, -200, 0)
SWEP.IconLookAt = Vector(-3.6159136295319, 15, -2.132783708373)
SWEP.IconFOV = 8.7828088657323

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AltFire = 0
SWEP.FiremodeOverride = FIREMODE_CUSTOM
SWEP.AdminOnly = true

SWEP.AmmoType = "40mm"
SWEP.CustomAmmo = "40mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	4.8,
		OffR	=	3.08,
		OffU	=	1.02,
		OffRotR	=	924.5,
		OffRotF	=	-1812.4,
		OffRotU	=	-176.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

function SWEP:CustomBullet()
	local shotpos = self.Owner:GetShootPos()

	shotpos = shotpos + self.Owner:GetForward() * 25
	shotpos = shotpos + self.Owner:GetUp() * -2
	shotpos = shotpos + self.Owner:GetRight() * 9

	if self.Owner:KeyDown(IN_ATTACK2) then
		local v = self.Owner:GetShootPos()
			v = v + self.Owner:GetForward() * 25
			v = v + self.Owner:GetRight() * -2
			v = v + self.Owner:GetUp() * -6
		shotpos = v
	end

	if SERVER then
		local rocket = ents.Create("ts2_40mm")

		if IsValid(rocket) then
			rocket:SetPos(shotpos)
			rocket:SetAngles(self.Owner:EyeAngles())
			rocket:SetOwner(self.Owner)
 			rocket:Spawn()
			rocket.Owner = self.Owner
			rocket.damage = self.Primary.Damage
		end
	end
	self:TakePrimaryAmmo(1)
	self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:MuzzleFlash()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
end