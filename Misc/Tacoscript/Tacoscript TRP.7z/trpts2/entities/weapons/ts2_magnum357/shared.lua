 if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

 	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable 				= true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/Weapons/v_357.mdl"
SWEP.WorldModel				= "models/Weapons/W_357.mdl"

SWEP.PrintName 				= ".357 Magnum"
SWEP.TS2Desc 				= "Six shot weapon."

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .8
SWEP.Primary.RecoverTime 	= .3

SWEP.Primary.Sound 			= Sound("Weapon_357.Single")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 6
SWEP.Primary.DefaultClip 	= 24
SWEP.Primary.Ammo 			= "pistol"
SWEP.Primary.Delay 			= 1
SWEP.Primary.Damage 		= 11

SWEP.ReloadSound 			= "weapons/357/357_reload4.wav"

SWEP.Primary.ViewPunchMul 	= 6

SWEP.TS2HoldType 			= "PISTOL"
SWEP.Category 				= "Tacoscript 2 - Pistols"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-5.6301007270813, 2.8822000026703, -7.1307997703552)
SWEP.Primary.IronSightAng = Vector(2.9802322831785e-009, -0.019999999552965, 0.019999999552965)

SWEP.Primary.HolsteredPos = Vector(2.7999999523163, -2, -2)
SWEP.Primary.HolsteredAng = Vector(-15, 15, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-2.9997711218194, -200, -2)
SWEP.IconLookAt = Vector(7.2486765854229, 7, 0.14405999550923)
SWEP.IconFOV = 4.2822762801312

SWEP.ReloadSound 			= ""
SWEP.AmmoType 				= ".357"

if CLIENT then
SWEP.PositionData = {
		OffF	=	17.4,
		OffR	=	-1.72,
		OffU	=	-4.28,
		OffRotR	=	358.1,
		OffRotF	=	-2805.8,
		OffRotU	=	-899,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end


