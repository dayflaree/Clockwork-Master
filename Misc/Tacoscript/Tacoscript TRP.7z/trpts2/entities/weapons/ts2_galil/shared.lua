if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/fal.wav")

SWEP.WorldModel 			= "models/weapons/w_rif_galil.mdl"
SWEP.ViewModel 				= "models/weapons/v_rif_galil.mdl"

SWEP.PrintName 				= "Israeli Galil Rifle"
SWEP.TS2Desc 				= "Israeli Millitary Issue Rifle"

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .4
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 12
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach 	= false
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 150
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.03, .03, .03)
SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(-5.1382999420166, 2.2242000102997, -8.8487997055054)
SWEP.Primary.IronSightAng = Vector(0.072400003671646, 0, 0.13860000669956)

SWEP.Primary.HolsteredPos = Vector(4.4000024795532, -4.8000011444092, -9)
SWEP.Primary.HolsteredAng = Vector(5, 60, -7.6000070571899)

SWEP.ItemWidth				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(94, -200, 7)
SWEP.IconLookAt = Vector(-49.71, 154, -4.69)
SWEP.IconFOV = 10.1

SWEP.ReloadSound			= ""

SWEP.IsPrimary = true

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-9.8,
		OffR	=	3.48,
		OffU	=	-0.27999999999999,
		OffRotR	=	342.7,
		OffRotF	=	-2514.6,
		OffRotU	=	-718.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
