
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/rtak.wav")

SWEP.ViewModel			= "models/weapons/v_rif_rtak.mdl"
SWEP.WorldModel			= "models/weapons/w_rif_rtak.mdl"

SWEP.PrintName = "R-TAK Rifle"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 10
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 120
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(2.9184000492096, 0.87900000810623, -5.6824998855591)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-4.3938007354736, -1.2557992935181, -3.3883004188538)
SWEP.Primary.HolsteredAng = Vector(-11.007599830627, -47.738399505615, 10.586000442505)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-9, -200, 7)
SWEP.IconLookAt = Vector(0, 28, -2)
SWEP.IconFOV = 11.5

SWEP.ReloadSound = ""


SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.45mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.80000000000001,
		OffR	=	4.88,
		OffU	=	-1.18,
		OffRotR	=	341,
		OffRotF	=	-2155,
		OffRotU	=	-721.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
