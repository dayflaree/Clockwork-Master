
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/riflecrack.wav")

SWEP.WorldModel = "models/weapons/w_groza.mdl"
SWEP.ViewModel = "models/weapons/v_groza.mdl"

SWEP.PrintName = "Groza Rifle"
SWEP.TS2Desc = "Russian Bullpup - 9x39mm"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 9
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(-8.9763031005859, 0.2937003672123, -10.358500480652)
SWEP.Primary.IronSightAng = Vector(2.0127999782562, 0.96000021696091, 1.1567000150681)

SWEP.Primary.HolsteredPos = Vector(10.800000190735, -5, -2)
SWEP.Primary.HolsteredAng = Vector(-5, 50, 0)

 SWEP.ItemWidth = 2
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(-1.53, 134.05, -8)
SWEP.IconLookAt = Vector(15.8, -29.11, 3.53)
SWEP.IconFOV = 11.5

SWEP.IsPrimary = true

SWEP.AmmoType = "9x39mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	12.7,
		OffR	=	2.88,
		OffU	=	8.12,
		OffRotR	=	208.4,
		OffRotF	=	-2528.3,
		OffRotU	=	-719.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end




