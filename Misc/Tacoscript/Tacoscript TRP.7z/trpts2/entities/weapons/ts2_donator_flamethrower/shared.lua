if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip		= true

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "shotgun"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

local sndAttackLoop 		= Sound("fire_large")
local sndSprayLoop 			= Sound("ambient.steam01")
local sndAttackStop 		= Sound("ambient/_period.wav")
local sndIgnite 			= Sound("PropaneTank.Burst")

SWEP.PrintName				= "Flamethrower"
SWEP.TS2Desc 				= "FK-REAPER Standard Weapon"

SWEP.Category 				= "Tacoscript 2 - Other"

SWEP.TS2HoldType 			= "SHOTGUN"

SWEP.WorldModel 			= "models/weapons/w_flamethrower.mdl"
SWEP.ViewModel 				= "models/weapons/v_flamethrower.mdl"

SWEP.Primary.Recoil			= 0
SWEP.Primary.Damage			= 1
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.02
SWEP.Primary.Delay			= 0.08

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "pistol"

SWEP.Primary.IronSightPos 	= Vector(-3.7400000095367, 0.20000000298023, -5)
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(-8.1999998092651, -3.5, -5.5)
SWEP.Primary.HolsteredAng 	= Vector(-5, -50.5, 0)

SWEP.AmmoType 				= "flamefuel"
SWEP.IsPrimary 				= true

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-21.39, 98.28, 0)
SWEP.IconLookAt = Vector(-0.23, 0, 2.02)
SWEP.IconFOV = 19.9

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.1,
		OffR	=	2.88,
		OffU	=	1.92,
		OffRotR	=	1473,
		OffRotF	=	-1606.3,
		OffRotU	=	-539.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end


function SWEP:Initialize()
	if SERVER then
		self:SetWeaponHoldType(self.HoldType)
	end

	self.EmittingSound = false
end

function SWEP:Think()
	if self.Owner:KeyDown(IN_ATTACK) then
		local trace = self.Owner:GetEyeTrace()
		if SERVER && self:CanPrimaryAttack() then
			local Flame = EffectData()
			Flame:SetOrigin(trace.HitPos)
			Flame:SetStart(self.Owner:GetShootPos())
			Flame:SetAttachment(1)
			Flame:SetEntity(self.Weapon)
			util.Effect("flamepuffs", Flame, true, true)
		end
	elseif self.Owner:KeyReleased(IN_ATTACK) then
		self:StopSounds()
	end
	if self.Reloading == true && (self.NextReload < CurTime()) then
		if not (self:IsIgnoringAmmoSystem()) then
			self:CustomReload()
		else
			self:SetClip1(self.Primary.ClipSize)
		end

		self.Reloading = false
	end
end

function SWEP:CanPrimaryAttack()
	if SERVER and self.Owner.IsTied then
		return false
	end

	if not self:CanFire() then
		return false
	end

	if SERVER and self.Owner:GetTable().InStanceAction then
		return false
	end

	if not (self:Clip1() > 0) then
		return false
	end

	if self:IsPlayerRunning() then
		return false
	end

	return true
end

function SWEP:PrimaryAttack()
	if not (self:CanPrimaryAttack()) then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

	if not self:CanPrimaryAttack() or self.Owner:WaterLevel() > 1 then
		self:StopSounds()
		return
	end

	if not self.EmittingSound then
		self.Weapon:EmitSound(sndAttackLoop)
		self.EmittingSound = true
	end

	self:TakePrimaryAmmo(1)

	local trace = self.Owner:GetEyeTrace()
	local Distance = self.Owner:GetPos():Distance(trace.HitPos)

	if SERVER and Distance < 520 then
		local flame = ents.Create("point_hurt")
			flame:SetPos(trace.HitPos)
			flame:SetOwner(self.Owner)
			flame:SetKeyValue("DamageRadius",30)
			flame:SetKeyValue("Damage", 2)
			flame:SetKeyValue("DamageDelay", 0.32)
			flame:SetKeyValue("DamageType", 8)
		flame:Spawn()

		flame:Fire("TurnOn", "", 0)
		flame:Fire("kill", "", 0.72)

		local entities = ents.FindInSphere(trace.HitPos, 20)
		for i = 1, #entities do
			local ent = entities[i]

			if not ent:IsWorld() then
				if ent:GetPhysicsObject():IsValid() then
					if stuff != self.Owner then
						if not (ent:IsPlayer()) then
							ent:Ignite(15, 60)
						elseif ent:IsNPC() then
							ent:Ignite(5, 20)
						else
							ent:Ignite(0.5, 20)
						end
					end
				end
			end
		end
		local Fire = EffectData()
		Fire:SetOrigin(trace.HitPos)
		util.Effect("immolate", Fire, true, true)
	end

	if CLIENT then

	end
end

function SWEP:SecondaryAttack()
end

function DeFlamitize(ply)
	if ply:IsOnFire() then
		ply:Extinguish()
	end
end

hook.Add("PlayerDeath", "deflame", DeFlamitize)

function SWEP:StopSounds()
	if self.EmittingSound then
		self.Weapon:StopSound(sndAttackLoop)
		self.Weapon:StopSound(sndSprayLoop)
		self.Weapon:EmitSound(sndAttackStop)
		self.EmittingSound = false
	end
end

function SWEP:Holster()
	self:StopSounds()
	return true
end

function SWEP:OnRemove()
	self:StopSounds()
	return true
end