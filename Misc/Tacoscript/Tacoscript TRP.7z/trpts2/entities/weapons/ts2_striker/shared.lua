if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"
SWEP.ViewModelFlip			= true
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModel				= "models/weapons/v_shot_strike.mdl"
SWEP.WorldModel				= "models/weapons/w_shot_strike.mdl"
SWEP.Primary.Sound			= Sound("weapons/ar2/npc_ar2_altfire.wav")

SWEP.PrintName 				= "Striker Riot Shotgun"
SWEP.TS2Desc 				= "Drum-Mag Combat Shotgun"

SWEP.ShotgunReload 			= true

SWEP.Primary.Recoil			= .2
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= 1

SWEP.Primary.ViewPunchMul 	= 20
SWEP.Primary.Damage			= 8
SWEP.Primary.NumShots		= 12

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Shotguns"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 12
SWEP.Primary.DefaultClip 	= 60
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= 0.9
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(.05, .05, .05)
SWEP.Primary.Spread 		=  Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(4.3390002250671, 3.5999999046326, 0)
SWEP.Primary.IronSightAng = Vector(-1.8784999847412, 3.2049000263214, 0)

SWEP.Primary.HolsteredPos = Vector(-3.4599995613098, -0.15999999642372, -2.5199995040894)
SWEP.Primary.HolsteredAng = Vector(-4.5, -47, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(4, -75, -5)
SWEP.IconLookAt = Vector(1, 2, -1)
SWEP.IconFOV = 17.1

SWEP.IsPrimary = true

SWEP.AltFire= 0

SWEP.AmmoType = "12gauge"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.20000000000001,
		OffR	=	3.38,
		OffU	=	-0.98,
		OffRotR	=	924.5,
		OffRotF	=	-1466.4,
		OffRotU	=	-180.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
