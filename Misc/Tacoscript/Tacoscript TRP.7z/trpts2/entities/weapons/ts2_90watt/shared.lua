if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("npc/env_headcrabcanister/launch.wav")

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.ViewModel				= "models/weapons/v_combinesniper_e2.mdl"
SWEP.WorldModel				= "models/weapons/w_combinesniper_e2.mdl"

SWEP.PrintName 				= "X-10"
SWEP.TS2Desc 				= "Laser Weapon"

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .4
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 80
SWEP.Primary.Damage			= 200
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - Other"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .4
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(-6.4000000953674, 1, -12.5)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(5.1999969482422, -4, -10)
SWEP.Primary.HolsteredAng = Vector(0, 58, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(19, 200, 7)
SWEP.IconLookAt = Vector(-6, 0, 5)
SWEP.IconFOV = 18.5

SWEP.UseScope 				= true
SWEP.ParabolicScope 		= true

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.1
SWEP.heatsinkPower 			= 1

SWEP._BEAM					= 20