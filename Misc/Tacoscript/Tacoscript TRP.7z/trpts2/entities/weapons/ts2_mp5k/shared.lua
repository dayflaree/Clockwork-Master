
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false
	SWEP.ViewModelFlip = true

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true



SWEP.Primary.Sound = Sound("Weapons/usp/usp_unsil-1.wav")

SWEP.WorldModel = "models/weapons/w_mp5k.mdl"
SWEP.ViewModel = "models/weapons/v_mp5k.mdl"

SWEP.PrintName = "MP5K"
SWEP.TS2Desc = "Compact MP5 for CQB and crew use"


 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 3
 SWEP.Primary.Damage			= 8
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SMG"
 SWEP.Category = "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize = 32
SWEP.Primary.DefaultClip = 64
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .07
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos   = Vector(3.205, -0.23, -2)
SWEP.Primary.IronSightAng   = Vector(3, 0, 0)


SWEP.Primary.HolsteredPos = Vector(-3.0781, -0.9194, -3.7345 )
SWEP.Primary.HolsteredAng = Vector(-5.0, -50.0, 0.0)

 SWEP.ItemWidth = 2
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(5, -200, -21)
SWEP.IconLookAt = Vector(-1, -5, -3)
SWEP.IconFOV = 5.9

SWEP.ReloadSound = ""


SWEP.AltFire= 1

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	11.2,
		OffR	=	0.28,
		OffU	=	-3.78,
		OffRotR	=	428.8,
		OffRotF	=	-2433.8,
		OffRotU	=	-792.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
