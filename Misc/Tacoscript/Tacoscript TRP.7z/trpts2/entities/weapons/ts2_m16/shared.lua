
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false
	SWEP.ViewModelFlip		= true

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

 SWEP.Primary.Sound = Sound("weapons/l22.wav")

SWEP.WorldModel = "models/weapons/w_m16.mdl"
SWEP.ViewModel = "models/weapons/v_m16.mdl"

SWEP.PrintName = "M16"
SWEP.TS2Desc = "US Millitary Standard Issue Rifle"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 12
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 150
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)

SWEP.Primary.IronSightPos = Vector(2.5241, -0.1971, -5.6857)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(3, -200, 3)
SWEP.IconLookAt = Vector(0.28, 200, -7)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	2,
		OffR	=	5.08,
		OffU	=	-0.88,
		OffRotR	=	147.6,
		OffRotF	=	-2339.9,
		OffRotU	=	-543.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
