if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true


SWEP.Primary.Sound = Sound("npc/strider/fire.wav")

SWEP.ViewModel= "models/weapons/v_atgun.mdl"
SWEP.WorldModel= "models/jaanus/atgun.mdl"

SWEP.PrintName = "Electromagnetic Pulse Rifle"
SWEP.TS2Desc = "Knock down a human, or Disable a Terminator"

SWEP.IsBluePlasma = false
SWEP.IsRedPlasma = false

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .3

 SWEP.Primary.ViewPunchMul = .5
 SWEP.Primary.Damage			= 0
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "SHOTGUN"
 SWEP.Category = "Tacoscript 2 - Other"

SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 40
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 1.2
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)
SWEP.Primary.CanCauseBleeding = false

SWEP.Primary.IronSightPos = Vector(-4.8469, -4.586, -2.3813)
SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(0, 134, 51)
SWEP.IconLookAt = Vector(5, -39, -12)
SWEP.IconFOV = 14.3

SWEP.UseScope = true
SWEP.AmmoType = "Cannothasium"

--It's a knockout gun - aka non lethal so we override the Primary Attack
function SWEP:PrimaryAttack()

	if SERVER and self.Owner.IsTied then return end
	if not self:CanFire() then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)

	if not self.OwnerIsNPC then
		self:TakePrimaryAmmo(1); -- NPCs get infinate ammo, as they don't know how to reload
	end

	self:ShootBullets()

	if SERVER then

		local trace = { }
		trace.start = self.Owner:EyePos()
		trace.endpos = trace.start + self.Owner:GetAimVector() * 2000
		trace.filter = self.Owner

		local tr = util.TraceLine(trace)

		if tr.Entity and tr.Entity:IsValid() and tr.Entity:IsPlayer() then

			tr.Entity:SetPlayerConsciousness(math.Clamp(tr.Entity:GetPlayerConsciousness() - 100, 0, 100))
			tr.Entity:Unconscious()

		end

    end

end
