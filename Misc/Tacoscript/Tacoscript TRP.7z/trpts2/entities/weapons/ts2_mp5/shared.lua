if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/usp/usp_unsil-1.wav")

SWEP.WorldModel 			= "models/weapons/w_mp5.mdl"
SWEP.ViewModel 				= "models/weapons/v_mp5.mdl"

SWEP.PrintName 				= "HK MP5"
SWEP.TS2Desc 				= "High Quality Modern SMG"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 7
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize 		= 32
SWEP.Primary.DefaultClip 	= 64
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(4.7480001449585, 0.97970062494278, -6.8102998733521)
SWEP.Primary.IronSightAng = Vector(1.8492995500565, -1.3411043386924e-009, -0.077899999916553)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -10)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(11, -123, 0)
SWEP.IconLookAt = Vector(-5, 21, -2)
SWEP.IconFOV = 14.3

SWEP.ReloadSound 			= ""
SWEP.AltFire= 1

SWEP.IsPrimary = true

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-1.0658141036402e-014,
		OffR	=	2.98,
		OffU	=	2.12,
		OffRotR	=	-27.4,
		OffRotF	=	-2506.9,
		OffRotU	=	-544.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
