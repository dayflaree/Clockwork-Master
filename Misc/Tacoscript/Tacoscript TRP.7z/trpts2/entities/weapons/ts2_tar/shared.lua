
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end

 	SWEP.ViewModelFlip		= true
 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound("weapons/riflecrack.wav")

SWEP.ViewModel			= "models/weapons/v_rif_tar.mdl"
SWEP.WorldModel			= "models/weapons/w_rif_tar.mdl"


SWEP.AltFire= 1

SWEP.PrintName = "TAR 21"
SWEP.TS2Desc = "Isotope Rifle"

 SWEP.Primary.Recoil			= .5
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 3
 SWEP.Primary.Damage			= 25
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = true
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 50
SWEP.Primary.DefaultClip = 400
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 0.5

SWEP.Primary.IronSightPos = Vector(3.4498000144958, 0.95480000972748, -4.9257998466492)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-2.6999998092651, -1, -4)
SWEP.Primary.HolsteredAng = Vector(-5, -48.5, 4.5)

SWEP.ItemWidth = 3
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(94, -31, 4)
SWEP.IconLookAt = Vector(-200, 36.43, -14)
SWEP.IconFOV = 22.7

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AmmoType = "5.56mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	9.8,
		OffR	=	3.28,
		OffU	=	1.82,
		OffRotR	=	914.5,
		OffRotF	=	-1444.8,
		OffRotU	=	-264.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
