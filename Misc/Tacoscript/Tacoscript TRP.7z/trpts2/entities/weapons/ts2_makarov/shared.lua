if SERVER then

 	AddCSLuaFile("shared.lua")

end

 	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFOV = 60
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair = false

end


 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true



SWEP.WorldModel = "models/weapons/w_makaro.mdl"
SWEP.ViewModel = "models/weapons/v_makaro.mdl"

SWEP.PrintName = "Makarov"
SWEP.TS2Desc = "Coke Powered Mirror-Rifle"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .3
 SWEP.Primary.RecoilMax = .5
 SWEP.Primary.RecoverTime = .4

 SWEP.Primary.Sound = Sound("Weapons/fiveseven/fiveseven-1.wav")

SWEP.Primary.ViewPunchMul 	= 10
 SWEP.Primary.NumShots		= 1
 SWEP.Primary.ClipSize = 8
 SWEP.Primary.DefaultClip = 80
 SWEP.Primary.Ammo = "pistol"
 SWEP.Primary.Delay = .15
 SWEP.Primary.Damage = 7

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - Pistols"

 SWEP.Primary.SpreadCone = Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(-3.7956, 2.5957, -5.9375 )
SWEP.Primary.IronSightAng = Vector(0 , 0 , 0)

SWEP.Primary.HolsteredPos = Vector(0.5946, 3.5118, -6.7105 )
SWEP.Primary.HolsteredAng = Vector(-24.903,  -8.167, 10.7103)

SWEP.IconCamPos = Vector(50, 128, -3)
SWEP.IconLookAt = Vector(0, 1, -2)
SWEP.IconFOV = 3.1

SWEP.ItemWidth = 1
SWEP.ItemHeight = 1

SWEP.ReloadSound = ""
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	7.6,
		OffR	=	1.68,
		OffU	=	-2.48,
		OffRotR	=	438.8,
		OffRotF	=	-2435.8,
		OffRotU	=	-620.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
