if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/silenced.wav")

SWEP.WorldModel 			= "models/weapons/w_mp5sd.mdl"
SWEP.ViewModel 				= "models/weapons/v_mp5sd.mdl"

SWEP.PrintName 				= "HK MP5SD"
SWEP.TS2Desc 				= "High Quality Modern SMG"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .4

SWEP.Primary.ViewPunchMul 	= .5
SWEP.Primary.Damage			= 7
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize 		= 32
SWEP.Primary.DefaultClip 	= 64
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(4.7789993286133, 0.66769987344742, -6.8102998733521)
SWEP.Primary.IronSightAng = Vector(0.0083007458597422, 0.015000002458692, -0.077899999916553)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -10)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

SWEP.ItemWidth 				= 2
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-28, -105, -1)
SWEP.IconLookAt = Vector(5, 20, 0)
SWEP.IconFOV = 18.5

SWEP.IsPrimary 				= true

SWEP.ReloadSound 			= ""

SWEP.AmmoType 				= "9x19mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	0.99999999999999,
		OffR	=	2.98,
		OffU	=	1.12,
		OffRotR	=	34.6,
		OffRotF	=	-2347.9,
		OffRotU	=	-360.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
