if SERVER then

 	AddCSLuaFile("shared.lua")

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModelFlip			= true

SWEP.Primary.Sound			= Sound("Weapons/usp/usp1.wav")

SWEP.ViewModel				= "models/weapons/v_ump.mdl"
SWEP.WorldModel				= "models/weapons/w_ump.mdl"

SWEP.PrintName 				= "UMP45 RIS"
SWEP.TS2Desc 				= "Silenced HK SMG"


SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 18
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 200
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .07
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.02, 0.02, 0.02)

SWEP.Primary.IronSightPos = Vector(3.0315001010895, 0.2301000058651, -5.2287998199463)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-7.2799978256226, -3.6200006008148, -5.7999992370605)
SWEP.Primary.HolsteredAng = Vector(5, -60, -2.8000102043152)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-18, -134, 8)
SWEP.IconLookAt = Vector(-2, 0, -3)
SWEP.IconFOV = 19.9

SWEP.ReloadSound 			= "weapons/smg1/smg1_reload.wav"

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = ".45ACP"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	4.9,
		OffR	=	1.78,
		OffU	=	0.019999999999999,
		OffRotR	=	390,
		OffRotF	=	-2337.1,
		OffRotU	=	-720.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
