
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV 		= 60
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

 SWEP.Primary.Sound = Sound("Weapons/k98_shoot.wav")

SWEP.ViewModel			= "models/weapons/v_m14_scope1.mdl"
SWEP.WorldModel			= "models/weapons/w_m14_scope.mdl"

SWEP.PrintName = "M14 Specops Rifle"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 13
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 120
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 0.1
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.001, .001, .001)
 SWEP.Primary.ReloadDelay = 2

SWEP.Primary.IronSightPos = Vector(4.8501992225647, 1.3262000083923, -4.8540005683899)
SWEP.Primary.IronSightAng = Vector(0, -1.8000001907349, 0)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -10)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

 SWEP.ItemWidth = 4
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(0, -200, -97)
SWEP.IconLookAt = Vector(5, 15, 5.19)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.79999999999999,
		OffR	=	4.18,
		OffU	=	1.32,
		OffRotR	=	342.7,
		OffRotF	=	-2517.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
