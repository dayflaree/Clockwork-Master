
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/ak47.wav")

SWEP.WorldModel = "models/weapons/w_ak47.mdl"
SWEP.ViewModel = "models/weapons/v_ak47.mdl"

SWEP.PrintName = "AK-47"
SWEP.TS2Desc = "Russian Rifle - 7.62mm"

 SWEP.Primary.Recoil			= .3
 SWEP.Primary.RecoilAdd			= .1
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 6
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots		= 1


 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 200
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .1
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.03, .03, .03)

SWEP.Primary.IronSightPos = Vector(2.5810000896454, 0.67560011148453, -8.7506999969482)
SWEP.Primary.IronSightAng = Vector(0.83670002222061, 0, -0.024399999529123)

SWEP.Primary.HolsteredPos = Vector(-0.80000001192093, -1, -10)
SWEP.Primary.HolsteredAng = Vector(0, -50, 0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(11, -158, 5)
SWEP.IconLookAt = Vector(0, 14, -3.17)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AltFire = 1
SWEP.AmmoType = "7.62mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.20000000000001,
		OffR	=	2.38,
		OffU	=	-0.18,
		OffRotR	=	1110.5,
		OffRotF	=	-890.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
