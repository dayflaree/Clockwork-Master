
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true



SWEP.Primary.Sound = Sound("Weapons/usp/usp_unsil-1.wav")

SWEP.WorldModel = "models/weapons/w_mac10.mdl"
SWEP.ViewModel = "models/weapons/v_mac10.mdl"

SWEP.PrintName = "Mac 11"
SWEP.TS2Desc = "A small sub-machine gun"


 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .4

 SWEP.Primary.ViewPunchMul = 4
 SWEP.Primary.Damage			= 6
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "PISTOL"
 SWEP.Category = "Tacoscript 2 - SMGs"

SWEP.Primary.ClipSize = 32
SWEP.Primary.DefaultClip = 130
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .06
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(-4.5652, 1.4946, -6.1375)
SWEP.Primary.IronSightAng = Vector(0 , 0 , 0)


SWEP.Primary.HolsteredPos = Vector(2.8, -2.0, -2.0)
SWEP.Primary.HolsteredAng = Vector(-15.0, 15.0, 0.0)

 SWEP.ItemWidth = 2
 SWEP.ItemHeight = 2

SWEP.IconCamPos = Vector(34.29, 200, 11)
SWEP.IconLookAt = Vector(16, 22.86, 0)
SWEP.IconFOV = 5.9

SWEP.ReloadSound = ""

SWEP.AmmoType = "9x19mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	18.2,
		OffR	=	-1.22,
		OffU	=	-3.78,
		OffRotR	=	433.8,
		OffRotF	=	-2435.8,
		OffRotU	=	-612.8,
		Bone	=	'ValveBiped.Bip01_R_Thigh'
}
end
