if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true

	SWEP.DrawCrosshair 		= false

end

SWEP.HoldType 				= "smg"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("npc/env_headcrabcanister/launch.wav")

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.ViewModel				= "models/weapons/v_battlefield_sniper.mdl"
SWEP.WorldModel				= "models/weapons/w_battlefield_sniper.mdl"

SWEP.PrintName 				= "M40R"
SWEP.TS2Desc 				= "A long range, bulky plasma rifle."

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .4
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 18
SWEP.Primary.Damage			= 50
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .3
SWEP.Primary.Automatic 		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos = Vector(3.5199987888336, 1.7400000095367, -7.2200040817261)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-6.8000030517578, -3.1999998092651, -6)
SWEP.Primary.HolsteredAng = Vector(0, -45.000015258789, 4)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(19, 200, 7)
SWEP.IconLookAt = Vector(-6, 0, 5)
SWEP.IconFOV = 18.5

SWEP.UseScope 				= true
SWEP.ParabolicScope 		= true

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.4
SWEP.heatsinkPower 			= 6

SWEP.AdminOnly				= true

SWEP._BEAM					= 20