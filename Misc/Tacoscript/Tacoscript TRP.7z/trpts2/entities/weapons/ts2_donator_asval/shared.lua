 if SERVER then

 	AddCSLuaFile("shared.lua")

 end

if CLIENT then

 	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
	SWEP.ViewModelFlip		= true

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.WorldModel 				= "models/weapons/w_asval.mdl"
SWEP.ViewModel 					= "models/weapons/v_asval.mdl"

SWEP.PrintName 					= "AS VAL"
SWEP.TS2Desc 					= "Russian Specops Rifle - 9x39mm"

 SWEP.Primary.ViewPunchMul 		= 3
 SWEP.Primary.Damage			= 20
 SWEP.Primary.NumShots			= 1

SWEP.Primary.SpreadCone = Vector(.02, .02, .02)

SWEP.Primary.Recoil			= .4
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .8
SWEP.Primary.RecoverTime 	= .3

SWEP.Primary.Sound 			= Sound("Weapons/usp/usp1.wav")

SWEP.Primary.NumShots		= 1
SWEP.Primary.ClipSize 		= 20
SWEP.Primary.DefaultClip 	= 20000
SWEP.Primary.Ammo 			= "XBowBolt"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Damage 		= 20
SWEP.Primary.Automatic		= true

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.SpreadCone 	= Vector(.04, .04, .04)

SWEP.Primary.IronSightPos = Vector(2.3807, 1.5506, -2.2582)
SWEP.Primary.IronSightAng = Vector(0 , 0, 0 )

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(8.36, 200, -17)
SWEP.IconLookAt = Vector(6, -1, 1)
SWEP.IconFOV = 10.1

SWEP.ReloadSound 			= ""

SWEP.IsPrimary = true

SWEP.AmmoType = "9x39mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-6.3,
		OffR	=	2.28,
		OffU	=	0.82,
		OffRotR	=	878.5,
		OffRotF	=	-177,
		OffRotU	=	-183.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
