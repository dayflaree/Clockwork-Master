
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV 		= 60
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

 SWEP.Primary.Sound = Sound("Weapons/fal.wav")

SWEP.ViewModel			= "models/weapons/v_m14.mdl"
SWEP.WorldModel			= "models/weapons/w_m14.mdl"

SWEP.PrintName = "M14 EBR-MOD"
SWEP.TS2Desc = "Donator weapon"

 SWEP.Primary.Recoil			= .2
 SWEP.Primary.RecoilAdd			= .2
 SWEP.Primary.RecoilMin = .2
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 13
 SWEP.Primary.Damage			= 22
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 20
SWEP.Primary.DefaultClip = 120
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = 0.09
SWEP.Primary.Automatic = false
SWEP.Primary.SpreadCone = Vector(.001, .001, .001)
 SWEP.Primary.ReloadDelay = 2

SWEP.Primary.IronSightPos = Vector(5.0363, 0.9078, -7.4349)
SWEP.Primary.IronSightAng = Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

 SWEP.ItemWidth = 3
 SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(0, -200, 0)
SWEP.IconLookAt = Vector(4, 13, -1)
SWEP.IconFOV = 11.5

SWEP.IsPrimary = true

SWEP.AmmoType = "7.62mm"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-0.79999999999999,
		OffR	=	2.38,
		OffU	=	-1.68,
		OffRotR	=	383.7,
		OffRotF	=	-2328.6,
		OffRotU	=	-720.8,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end

