if SERVER then

 	AddCSLuaFile("shared.lua")

end

if CLIENT then

	SWEP.ViewModelFOV 		= 60
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false

end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"
SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.Primary.Sound 			= Sound("Weapons/ak47.wav")

SWEP.WorldModel 			= "models/weapons/w_pkm.mdl"
SWEP.ViewModel 				= "models/weapons/v_pkm.mdl"

SWEP.PrintName 				= "PKM LMG"
SWEP.TS2Desc 				= "Russian machinegun"

SWEP.Primary.Recoil			= .3
SWEP.Primary.RecoilAdd		= .2
SWEP.Primary.RecoilMin 		= .4
SWEP.Primary.RecoilMax 		= .7

SWEP.Primary.ViewPunchMul 	= 8
SWEP.Primary.Damage			= 15
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - LMGs"

SWEP.Primary.DoorBreach 	= true
SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 100
SWEP.Primary.DefaultClip 	= 300
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .12
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone	 	= Vector(.02, .02, .02)


SWEP.Primary.IronSightPos 	= Vector(-4.2499, 2.5817, -10.5952)
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0 )

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 4
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-11, 187, -9)
SWEP.IconLookAt = Vector(2, 15, -0.27)
SWEP.IconFOV = 12.9

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "7.62box"
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	-5.8,
		OffR	=	4.58,
		OffU	=	-1.18,
		OffRotR	=	341.7,
		OffRotF	=	-2188.1,
		OffRotU	=	-724.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
