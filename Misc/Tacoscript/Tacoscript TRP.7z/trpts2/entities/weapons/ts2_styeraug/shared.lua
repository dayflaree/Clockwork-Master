if SERVER then

 	AddCSLuaFile("shared.lua")

 end

SWEP.Base 					= "ts2_base"
SWEP.HoldType 				= "pistol"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true
SWEP.ViewModelFlip			= true

SWEP.Primary.Sound 			= Sound("Weapons/aug/aug-1.wav")

SWEP.WorldModel 			= "models/weapons/w_rif_aug.mdl"
SWEP.ViewModel 				= "models/weapons/v_rif_aug.mdl"

SWEP.PrintName 				= "Styer Aug"
SWEP.TS2Desc 				= "Modern European Assault Rifle"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin	 	= .2
SWEP.Primary.RecoilMax	 	= .3

SWEP.Primary.ViewPunchMul	= 3
SWEP.Primary.Damage			= 10
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 150
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .1
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(5.6000003814697, 1.5, -6)
SWEP.Primary.IronSightAng = Vector(0, 1, 0)

SWEP.Primary.HolsteredPos = Vector(0, -1, -5)
SWEP.Primary.HolsteredAng = Vector(5, -50, -15)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(43, -200, 11.43)
SWEP.IconLookAt = Vector(0, 34.29, 0)
SWEP.IconFOV = 10.1

SWEP.UseScope 				= true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	-2.2,
		OffR	=	2.48,
		OffU	=	1.82,
		OffRotR	=	924.5,
		OffRotF	=	-1444.8,
		OffRotU	=	-174.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
