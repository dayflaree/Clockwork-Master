
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then


	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair		= false

end

 SWEP.Base 					= "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("Weapons/l22.wav")

SWEP.WorldModel = "models/weapons/w_sg550.mdl"
SWEP.ViewModel = "models/weapons/v_sg550.mdl"

SWEP.PrintName 				= "Sig SG550"
SWEP.TS2Desc 				= "Modern Assault Rifle - 5.56"

 SWEP.Primary.Recoil		= .2
 SWEP.Primary.RecoilAdd		= .2
 SWEP.Primary.RecoilMin 	= .2
 SWEP.Primary.RecoilMax 	= .5

 SWEP.Primary.ViewPunchMul 	= 6
 SWEP.Primary.Damage		= 9
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType 			= "RIFLE"
 SWEP.Category 				= "Tacoscript 2 - Rifles"

SWEP.Primary.HighPowered 	= true
SWEP.Primary.ClipSize 		= 30
SWEP.Primary.DefaultClip 	= 160
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(.02, .02, .02)
 SWEP.Primary.ReloadDelay 	= 2.3

SWEP.Primary.IronSightPos = Vector(2.5555860996246, -1.4842002391815, -7.627799987793)
SWEP.Primary.IronSightAng = Vector(1.1469000577927, 0, 0.043600000441074)

SWEP.Primary.HolsteredPos = Vector(-2.0180997848511, -5.7594003677368, -3.794499874115)
SWEP.Primary.HolsteredAng = Vector(-5.9388999938965, -52.711128234863, 26.464757919312)

 SWEP.ItemWidth 			= 3
 SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-8, 196.43, 0)
SWEP.IconLookAt = Vector(5.33, 15, 1.8)
SWEP.IconFOV = 10.1

SWEP.ReloadSound = ""
SWEP.UseScope = true

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.8,
		OffR	=	3.08,
		OffU	=	5.02,
		OffRotR	=	744.5,
		OffRotF	=	-1616.4,
		OffRotU	=	-180.1,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
