if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip = true

 end

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_famas.mdl"
SWEP.ViewModel 				= "models/weapons/v_famas.mdl"

SWEP.PrintName 				= "Famas Prototype"
SWEP.TS2Desc 				= "Custom made plasma weapon based on a Famas."

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 4
SWEP.Primary.Damage			= 11
SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .08
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(3.1062998771667, 0.20370006561279, -1.5881948471069)
SWEP.Primary.IronSightAng = Vector(0.91140002012253, 0, 0.055100001394749)

SWEP.Primary.HolsteredPos = Vector(-5.1999998092651, -0.88000011444092, -2)
SWEP.Primary.HolsteredAng = Vector(-0.5, -49.200000762939, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(5, -200, -3)
SWEP.IconLookAt = Vector(-4.789999961853, -4, -0.54000002145767)
SWEP.IconFOV = 10.942167284574

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"
SWEP.AdminOnly				= true

SWEP.UseHeatsink 			= true
SWEP.UseScope 				= true

SWEP.heatsinkRate 			= 0.16
SWEP.heatsinkPower 			= 1

if CLIENT then
SWEP.PositionData = {
		OffF	=	3.8,
		OffR	=	4.88,
		OffU	=	-3.18,
		OffRotR	=	341,
		OffRotF	=	-2155,
		OffRotU	=	-721.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
