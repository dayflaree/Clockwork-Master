if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType 			= "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawCrosshair 		= false
 	SWEP.ViewModelFlip		= true

end


SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= true
SWEP.IsRedPlasma 			= false

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.ViewModel				= "models/weapons/v_35watt_recon.mdl"
SWEP.WorldModel				= "models/weapons/w_35watt_recon.mdl"

SWEP.PrintName 				= "M54A2 - Recon"
SWEP.TS2Desc 				= "Recon variant of the Burner"

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .3
SWEP.Primary.RecoilMin 		= .3
SWEP.Primary.RecoilMax 		= .5

SWEP.Primary.ViewPunchMul 	= 3
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SMG"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .09
SWEP.Primary.Automatic		= false
SWEP.Primary.SpreadCone 	= Vector(0.01, 0.01, 0.01)

SWEP.Primary.IronSightPos 	= Vector(2.4138, 1.5575, -3.8191)
SWEP.Primary.IronSightAng 	= Vector(0.0, 0.0, 0.0)

SWEP.Primary.HolsteredPos 	= Vector(-0.2273, -13.4934, -7.5877)
SWEP.Primary.HolsteredAng 	= Vector(53.7318, -5.4051, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(90, 0, 1)
SWEP.IconLookAt = Vector(55, -4, 1)
SWEP.IconFOV = 18.5

SWEP.UseScope 				= true
SWEP.ParabolicScope 		= true

SWEP.IsBurst 				= false
SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.3
SWEP.heatsinkPower 			= 2
SWEP.AdminOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	11.8,
		OffR	=	4.58,
		OffU	=	-6.18,
		OffRotR	=	1052.5,
		OffRotF	=	-369,
		OffRotU	=	-88.6,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
