if SERVER then

 	AddCSLuaFile("shared.lua")

else

	SWEP.ViewModelFlip = true

 end

SWEP.HoldType 				= "pistol"

SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_40wattm95.mdl"
SWEP.ViewModel 				= "models/weapons/v_40wattm95.mdl"

SWEP.PrintName 				= "M95A1 'Pig'"
SWEP.TS2Desc 				= "Very heavy automatic plasma weapon"


SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 6
SWEP.Primary.Damage			= 25
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "RIFLE"
SWEP.Category 				= "Tacoscript 2 - Light Plasma"

SWEP.Primary.ClipSize 		= 10000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .12
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.03, 0.03, 0.03)

SWEP.Primary.IronSightPos = Vector(4.1462998390198, 1.2037000656128, -1.5881948471069)
SWEP.Primary.IronSightAng = Vector(0.91140002012253, 0, 0.055100001394749)

SWEP.Primary.HolsteredPos = Vector(-5.1999998092651, -0.88000011444092, -2)
SWEP.Primary.HolsteredAng = Vector(-0.5, -49.200000762939, 0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-2.0966882522474, -200, -2.7599999904633)
SWEP.IconLookAt = Vector(-3.8879969906056, -3.7913122692051, -2.3942990296523)
SWEP.IconFOV = 9.69789297284

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"

SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.23
SWEP.heatsinkPower 			= 1

if CLIENT then
SWEP.PositionData = {
		OffF	=	7.8,
		OffR	=	2.38,
		OffU	=	-0.18,
		OffRotR	=	1110.5,
		OffRotF	=	-896.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
