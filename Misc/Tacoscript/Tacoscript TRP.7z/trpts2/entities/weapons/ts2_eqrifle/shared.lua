
if SERVER then

 	AddCSLuaFile("shared.lua")

 end

  	SWEP.HoldType = "pistol"

if CLIENT then

	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFlip		= true
	SWEP.DrawCrosshair = false

end

 SWEP.Base = "ts2_base"

 SWEP.Spawnable = true
 SWEP.AdminSpawnable		= true

SWEP.Primary.Sound = Sound("weapons/riflecrack.wav")

SWEP.ViewModel			= "models/weapons/v_eq_gun1.mdl"
SWEP.WorldModel			= "models/weapons/w_eqgun.mdl"

SWEP.PrintName = "Resistance EQ Rifle"
SWEP.TS2Desc = "Advanced TechComm weaponry"

 SWEP.Primary.Recoil			= .1
 SWEP.Primary.RecoilAdd			= .3
 SWEP.Primary.RecoilMin = .4
 SWEP.Primary.RecoilMax = .5

 SWEP.Primary.ViewPunchMul = 5
 SWEP.Primary.Damage			= 12
 SWEP.Primary.NumShots		= 1

 SWEP.TS2HoldType = "RIFLE"
 SWEP.Category = "Tacoscript 2 - Rifles"

SWEP.Primary.DoorBreach = false
SWEP.Primary.HighPowered = true
SWEP.Primary.ClipSize = 40
SWEP.Primary.DefaultClip = 160
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Delay = .09
SWEP.Primary.Automatic = true
SWEP.Primary.SpreadCone = Vector(.02, .02, .02)
SWEP.Primary.ReloadDelay = 2.3

SWEP.Primary.IronSightPos = Vector(3.832, 1.2977, -11)
SWEP.Primary.IronSightAng = Vector(0, 0, 0)

SWEP.Primary.HolsteredPos = Vector(-0.8, -1.0, -10.0)
SWEP.Primary.HolsteredAng = Vector(0.0, -50.0, 0.0)

SWEP.ItemWidth = 2
SWEP.ItemHeight = 1

SWEP.IconCamPos = Vector(94, -1.87, 4)
SWEP.IconLookAt = Vector(-200, -5.27, -14.42)
SWEP.IconFOV = 12.9

SWEP.ReloadSound = ""

SWEP.IsPrimary = true

SWEP.AltFire= 1

SWEP.AmmoType = "5.56mm"

if CLIENT then
SWEP.PositionData = {
		OffF	=	6,
		OffR	=	2.28,
		OffU	=	-0.48,
		OffRotR	=	202,
		OffRotF	=	-2162,
		OffRotU	=	-628.3,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end
