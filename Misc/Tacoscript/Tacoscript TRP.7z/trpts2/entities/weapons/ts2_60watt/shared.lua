if SERVER then

	AddCSLuaFile("shared.lua")

end

SWEP.HoldType 				= "pistol"
SWEP.Base 					= "ts2_base"

SWEP.Spawnable = true
SWEP.AdminSpawnable			= true

SWEP.ViewModelFOV 			= 50
SWEP.Primary.Sound 			= Sound("weapons/plasma.wav")

SWEP.WorldModel 			= "models/weapons/w_irifle.mdl"
SWEP.ViewModel 				= "models/weapons/v_irifle.mdl"

SWEP.PrintName 				= "S25"
SWEP.TS2Desc 				= "Heavy plasma burst weapon"

SWEP.IsBluePlasma 			= false
SWEP.IsRedPlasma 			= true

SWEP.Primary.Recoil			= .1
SWEP.Primary.RecoilAdd		= .1
SWEP.Primary.RecoilMin 		= .2
SWEP.Primary.RecoilMax 		= .3

SWEP.Primary.ViewPunchMul 	= 0
SWEP.Primary.Damage			= 20
SWEP.Primary.NumShots		= 1

SWEP.TS2HoldType 			= "SHOTGUN"
SWEP.Category 				= "Tacoscript 2 - Heavy Plasma"

SWEP.Primary.ClipSize 		= 30000
SWEP.Primary.DefaultClip 	= 0
SWEP.Primary.Ammo 			= "smg1"
SWEP.Primary.Delay 			= .02
SWEP.Primary.Automatic 		= true
SWEP.Primary.SpreadCone 	= Vector(0.02, 0.02, 0.02)

SWEP.Primary.IronSightPos 	= Vector(-4.6003, 2.2885, -11.6739 )
SWEP.Primary.IronSightAng 	= Vector(0, 0, 0)

SWEP.Primary.HolsteredPos 	= Vector(10.8, -5.0, -2.0)
SWEP.Primary.HolsteredAng 	= Vector(-5.0, 50.0, 0.0)

SWEP.ItemWidth 				= 3
SWEP.ItemHeight 			= 1

SWEP.IconCamPos = Vector(-93, 200, -7)
SWEP.IconLookAt = Vector(0, 10, 0.61)
SWEP.IconFOV = 10.1

SWEP.IsPrimary 				= true

SWEP.AmmoType 				= "plasmacell"


SWEP.UseHeatsink 			= true

SWEP.heatsinkRate 			= 0.025
SWEP.heatsinkPower 			= 2

SWEP.SkynetOnly				= true

if CLIENT then
SWEP.PositionData = {
		OffF	=	6.8,
		OffR	=	4.38,
		OffU	=	4.82,
		OffRotR	=	925.5,
		OffRotF	=	-1085.8,
		OffRotU	=	1.4,
		Bone	=	'ValveBiped.Bip01_Spine2'
}
end