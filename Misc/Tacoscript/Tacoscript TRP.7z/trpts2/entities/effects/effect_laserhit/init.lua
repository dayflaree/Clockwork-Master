function EFFECT:Init(data)
	local pos, scale, vel, spos = data:GetOrigin(), data:GetScale(), Vector(), data:GetStart()

	local size = data:GetMagnitude()
	local color = data:GetAngles()

	--self.Color = HSVToColor(math.Clamp(360 * (scale / 30), 280, 360), 5, 1)
    --self.Color.a = 255

    self.Color = Color(150, 100, 255)

	local Normal = data:GetNormal()
	local Emitter = ParticleEmitter(pos)

	for i = 1, 80 do
		local pt = Emitter:Add("sprites/gmdm_pickups/light", pos + VectorRand() * math.random(4, 6))
		pt:SetVelocity(Normal * math.random(2, 6) + VectorRand() * math.random(2, 5)) 
		pt:SetDieTime(math.random(1, 8) / 10)
		pt:SetStartAlpha(255)
		pt:SetEndAlpha(0)
		pt:SetStartSize(1)
		pt:SetEndSize(0)
		pt:SetColor(self.Color.r, self.Color.g, self.Color.b)
		pt:VelocityDecay(false)
	end

	Emitter:Finish()

	local dynlight = DynamicLight(0)
	dynlight.Pos = pos + Normal * 10
	dynlight.Size = 350
	dynlight.Brightness = 1
	dynlight.Decay = 3000
	dynlight.R = self.Color.r
	dynlight.G = self.Color.g
	dynlight.B = self.Color.b
	dynlight.DieTime = CurTime() + 0.1

	if spos then
		local dynlight = DynamicLight(0)
		dynlight.Pos = spos
		dynlight.Size = 350
		dynlight.Brightness = 1
		dynlight.Decay = 3000
		dynlight.R = self.Color.r
		dynlight.G = self.Color.g
		dynlight.B = self.Color.b
		dynlight.DieTime = CurTime() + 0.1
	end
end

function EFFECT:Think()
	return false
end

function EFFECT:Render() end