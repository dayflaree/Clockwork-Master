function EFFECT:Init(data)
	self.Ent = data:GetEntity()

	if TS.LightWell.Lights[self.Ent] then
		TS.LightWell.Lights[self.Ent][2]:Remove()
		TS.LightWell.Lights[self.Ent] = nil
	end

	self.Lifetime = (data:GetMagnitude() or 1) + CurTime()
	self.Size = data:GetScale() or 256
	self.Style = data:GetRadius() or 0
	self.Permanant = data:GetNormal().x
	self.Brightness = data:GetNormal().y

	self.Color = data:GetOrigin()
	self.Color = Color(self.Color.x, self.Color.y, self.Color.z)

	TS.LightWell.Lights[self.Ent] = { self.Lifetime, self.Entity, (self.Permanant == 1), self.Ent:EntIndex() }
end

function EFFECT:Think()

	if self.Ent:IsPlayer() && not (self.Ent:Alive()) then
		TS.LightWell.Lights[self.Ent] = nil
		return false
	end

	if IsValid(self.Ent) then
		self.Entity:SetParent(nil)
		self.Entity:SetPos((!self.Ent:IsPlayer() && self.Ent:LocalToWorld(self.Ent:OBBCenter()) || self.Ent:GetPos()))
		self.Entity:SetParent(self.Ent)

		local light = DynamicLight(self.Ent:EntIndex())

		if light then
			light.Pos = self.Entity:GetPos()
			light.r = self.Color.r
			light.g = self.Color.g
			light.b = self.Color.b
			light.Brightness = self.Brightness
			light.Size = self.Size
			light.Decay = self.Size * 5
			light.DieTime = CurTime() + 0.01
			light.Style = self.Style
		end
	end

	return true
end

function EFFECT:Render()

end
