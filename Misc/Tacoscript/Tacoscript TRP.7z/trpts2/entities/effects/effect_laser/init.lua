EFFECT.Mat = Material("trails/laser")

function EFFECT:Init(data)

        self.Position = data:GetStart()
        self.WeaponEnt = data:GetEntity()
        self.Attachment = data:GetAttachment()

        // Keep the start and end pos - we're going to interpolate between them
        self.StartPos = self:GetTracerShootPos(self.Position, self.WeaponEnt, self.Attachment)
        self.EndPos = data:GetOrigin()

        self.Alpha = 150

end

function EFFECT:Think()

        self.Alpha = self.Alpha - FrameTime() * 2048

        self.StartPos = self:GetTracerShootPos(self.Position, self.WeaponEnt, self.Attachment)
        self.Entity:SetRenderBoundsWS(self.StartPos, self.EndPos)

        if self.Alpha < 0 then return false end
        return true

end

function EFFECT:Render()

        if self.Alpha < 1 then return end

        self.Length = (self.StartPos - self.EndPos):Length()

        render.SetMaterial(self.Mat)
        local texcoord = math.Rand(0, 1)

        --local col = HSVToColor(math.Clamp(360 * (self.PlasmaDamage or self.WeaponEnt.Primary.Damage / 30), 260, 360), 5, 1)
        --col.a = self.Alpha

       col = Color(150, 100, 255)
        for i = 1, 1 do

                render.DrawBeam(self.StartPos,                                                                                 // Start
                                         self.EndPos,                                                                                   // End
                                         self.WeaponEnt._BEAM,                                                                                                     // Width
                                         texcoord,                                                                                                              // Start tex coord
                                         texcoord + self.Length / 128,                                                                  // End tex coord
                                         col)           // Color (optional)
        end

end