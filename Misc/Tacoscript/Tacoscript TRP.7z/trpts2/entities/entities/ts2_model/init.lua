AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()

	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_NONE)
	self.Entity:SetSolid(SOLID_NONE)

	local phys = self.Entity:GetPhysicsObject()

	if phys:IsValid() then
		phys:Sleep()
	end

end

function ENT:SetRemoveFunc(func)

	self.RemoveFunc = func

end

function ENT:SetPlayer(ply, model)
	self.Player = ply

	self:SetParent(ply)
	self:SetOwner(ply)

	self.Entity:SetModel(model)
	self.Entity:SetParent(ply)
	self.Entity:AddEffects(bit.bor(EF_BONEMERGE,EF_BONEMERGE_FASTCULL,EF_PARENT_ANIMATES))

end


function ENT:PhysicsSimulate(phys, delta)


end

function ENT:Think()

	self:SetEyeTarget(self.Player:EyePos())

	if not self.Player or not self.Player:IsValid() then
		self:Remove()
		return
	end


	if self.Player:GetMaterial() != "models/humans/nodraw'" then
		self.Player:SetMaterial("models/humans/nodraw")
	end

	if (self.Player.InCloak or
		self.Player.ObserveMode or
		self.Player.CharacterMenu or
		self.Player:GetObserverMode() != OBS_MODE_NONE or
		!self.Player:Alive()) then

		self:SetNoDraw(true)

	else

		self:SetNoDraw(false)

	end


end


