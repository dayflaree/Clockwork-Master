-----------------------
-- Combine Gunship   --
-- shared.lua        --
-- Written by th0r   --
-----------------------

ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.Category 		= "HL2RP"
ENT.PrintName		= "Combine Gunship"
ENT.Author			= "th0r"
ENT.Contact			= "th0r"  //fill in these if you want it to be in the spawn menu
ENT.Purpose			= ":)"
ENT.Instructions	= ":)"
ENT.Spawnable			= false
ENT.AdminSpawnable		= true

ENT.AutomaticFrameAdvance = true
ENT.SequenceEnd = CurTime()


//Self explanatory.
function ENT:Think()

	if self.SequenceEnd < CurTime() then

		local sequence = self:LookupSequence("ACT_GUNSHIP_PATROL")

		self:SetSequence(sequence)

		self.SequenceEnd = CurTime() + self:SequenceDuration()

	end

	self:NextThink(CurTime())

end

//Also self explanatory.
function ENT:OnRemove()

end