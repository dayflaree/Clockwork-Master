-----------------------
-- Combine Gunship   --
-- init.lua          --
-- Written by th0r   --
-----------------------

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include('shared.lua')

function ENT:SpawnFunction(player,trace)

	if trace.Hit then
		local ent = ents.Create("hl2_gunship")
		// set the spawn pos
		ent:SetPos(trace.HitPos + trace.HitNormal * 64)
		ent:Spawn()
		ent:Activate()
		return ent
	end

end

function ENT:Initialize()

	self:SetModel("models/gunship.mdl")
	self.Entity:PhysicsInit(SOLID_BBOX)
	self.Entity:SetMoveType(MOVETYPE_FLY)
	self.Entity:SetSolid(SOLID_BBOX)

	local phys = self.Entity:GetPhysicsObject()

	if phys:IsValid() then
		phys:Wake()
	end

end

//Called
function ENT:OnTakeDamage(dmg)

end

//On Use
function ENT:AcceptInput(name, activator, caller)

	if name == "Use" && IsValid(activator) && activator:IsPlayer() then

		Msg("\nGunship used\n")

	end

end

//This will make it so every player knows about the Entity, it's always networked, even if not in your PVS.
function ENT:UpdateTransmitState()

	return TRANSMIT_ALWAYS

end