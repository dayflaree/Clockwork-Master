ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "RPG"
ENT.Author		= "Seenie"
ENT.Contact		= ""
