AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

local sndThrustLoop = Sound("Missile.Accelerate")
local sndStop = Sound("ambient/_period.wav")

local FlightSound = Sound("PhysicsCannister.ThrusterLoop")

function ENT:Initialize()

	self.Damage = 100
	self.DoUnconscious = false

	PrecacheParticleSystem("grenade_explosion_01")

	self.Entity:SetModel("models/weapons/w_missile_closed.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_NONE)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:SetColor(Color(255, 255, 255, 0))

	self.dietime = CurTime() + 10
	self.spreadtime = CurTime() + 3
	self.flightvector = self.Entity:GetForward() * 50

	util.SpriteTrail(self.Entity, 0, Color(255, 255, 255, 255), false, 6, 0, 0.1, 8, "trails/smoke.vmt")

	self:Think()

end

function ENT:DoExplosion(damage, radius, tr)

	local targets = ents.FindInSphere(self.Entity:GetPos(), radius)

	for k, v in pairs (targets) do

		if not (v:IsPlayer() || v:IsNPC()) then else

			local dist = v:GetPos():Distance(self.Entity:GetPos())

			damage = damage - (damage * (dist / radius))

			local dmginfo = DamageInfo()

			dmginfo:SetDamage(damage)
			dmginfo:SetDamageType(DMG_BLAST)
			dmginfo:SetAttacker(self:GetOwner())
			dmginfo:SetDamageForce(Vector(0, 0, 100))

			v:TakeDamageInfo(dmginfo)

			if dist < radius && (dist <  (radius / 2)) && self.DoUnconscious then

				if v:IsPlayer() && v:Alive() then
					v:SetPlayerConsciousness(100 * (dist / radius))
					v:Unconscious()
				end

			end

		end

	end

	util.ScreenShake(tr.HitPos, 10, 5, 1, 1000)
	util.Decal("Scorch", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)

	ParticleEffect("grenade_explosion_01", tr.HitPos, Angle(0,0,0), nil)

	--self.Entity:EmitSound("explode_4")

	sound.Play("explode_4", tr.HitPos, 180, 100, 1)

	self.Entity:Remove()

end

function ENT:Think()

	local vectors = { self:GetForward() *30, self:GetUp() *25, self:GetUp() *-25 }

	for i = 1, #vectors do
		local v = vectors[i]
		local tracedata = {}
		tracedata.start = self:GetPos()
		tracedata.endpos = self:GetPos() +v
		tracedata.filter = { self, self.owner }
		local trace = util.TraceLine(tracedata)
		if trace.HitWorld || (IsValid(trace.Entity) && !trace.Entity:IsWeapon()) then
			self:DoExplosion(self.Damage, 300, trace)
			return
		end
	end

	if CurTime() > self.dietime then
		self.Entity:Remove()
		return
	end

	self.SwayOffsetZ = self.SwayOffsetZ or 0
	self.SwayOffsetZ = self.SwayOffsetZ + 0.05

	local sway = Vector(0, 0, math.Rand(-self.SwayOffsetZ * 2,0))

	self.flightvector = self.flightvector
	self.Entity:SetPos (self.Entity:GetPos() + self.flightvector + sway)
	self.Entity:SetAngles((self.flightvector + sway):Angle())

	self.Entity:NextThink(CurTime())

	return true
end

function ENT:OnRemove()

	self.Entity:StopSound(FlightSound)

end

local function ShotNadeTool(trace)

	if trace.Entity:GetClass() == "sent_rpgrocket" then
		return false
	end

end

hook.Add("CanTool", "ShotNadeTool", ShotNadeTool)

local function ShotNadePhys(ent)

	if ent:GetClass() == "sent_rpgrocket" then
		return false
	end

end
hook.Add("PhysgunPickup", "ShotNadePhys" , ShotNadePhys)