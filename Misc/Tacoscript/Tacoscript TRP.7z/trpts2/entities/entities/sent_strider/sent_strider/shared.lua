ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName		= "Combine Strider"
ENT.Author			= "th0r"
ENT.Contact			= "th0r"
ENT.Purpose			= "ahuehuehuehuehue"

ENT.Spawnable			= false
ENT.AdminSpawnable		= true

ENT.AutomaticFrameAdvance = true

AnimTable = { }
AnimTable["Idle"] = 1
AnimTable["Walk"] = 9
AnimTable["Run"] = 10
AnimTable["Crouch"] = 2
AnimTable["Stand"] = 3