include('shared.lua')

function ENT:Draw()

	--[[local pos = self:GetPos()
	local offset = Vector(0, 0, 495)

	self:SetRenderOrigin(pos + offset)
	self:SetRenderAngles(self:GetAngles());]]

	self:SetupBones()
	self:DrawModel()

	--[[self:SetRenderOrigin(nil)
	self:SetRenderAngles(nil);]]

end

function StriderCalcView(ply, origin, angles, fov)

	local strider = LocalPlayer():GetNWEntity("strider")

	if strider and IsValid(strider) then

		local boneIndex = strider:LookupBone("body_bone")

		local bpos, bang = strider:GetBonePosition(boneIndex)

		local pos = bpos + (Vector(0, 0, 100) + (strider:GetAngles():Forward() * -50))

		local trace = { }

		trace.start = bpos

		trace.endpos = pos

		trace.filter = { LocalPlayer(), strider }

		pos = util.TraceLine(trace).HitPos

		local view = {}
			view.origin = pos
			view.angles = angles
			view.fov = fov
		return view

	end

end
hook.Add("CalcView", "striderCalcView", StriderCalcView)