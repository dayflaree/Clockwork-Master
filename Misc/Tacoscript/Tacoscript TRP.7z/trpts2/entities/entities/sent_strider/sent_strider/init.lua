include("shared.lua")

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

ENT.CurAnim = 1
ENT.LastAnim = 1
ENT.overrideAnim = nil
ENT.NextMoveLoop = CurTime()
ENT.NextIdleLoop = CurTime()

ENT.CanMove = true
ENT.doingCrouch = false
ENT.Crouching = true

ENT.NextPrimaryAttack = CurTime()
ENT.NextPenetration = CurTime()

ENT.BigGunShooting = false
ENT.BigGunShootTime = CurTime()

ENT.Controller = nil
ENT.GunProp = nil

function ENT:SpawnFunction(ply, tr)

	if !tr.Hit then return end

	local SpawnPos = tr.HitPos + tr.HitNormal * 500

	local ent = ents.Create("sent_strider")
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()

	ent:SetController(ply)

	return ent

end

function ENT:Initialize()

	self:SetModel("models/combine_strider.mdl")

	local ent = ents.Create("prop_physics")
	ent:SetModel("models/props_junk/PopCan01a.mdl")
	ent:SetNoDraw(true)
	ent:SetNotSolid(true)

	self.GunProp = ent

end

/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide(data, physobj)
//Nothing here
end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage(dmginfo)
//Nothing here
end


/*---------------------------------------------------------
   Name: Use
---------------------------------------------------------*/
function ENT:Use(activator, caller, Player)
//Nothing here
end

/*---------------------------------------------------------
   Name: OnRemove
---------------------------------------------------------*/
function ENT:OnRemove()

	self.GunProp:Remove()

	self.Controller:SetMoveType(2)
	self.Controller.Strider = nil

	self.Controller:SetNoDraw(false)

	self.Controller:SetNWEntity("strider", nil)

	self.Controller:ResetHull()

	self.Controller:Kill()

end

function ENT:Think()

	if self.doingCrouch then

		self:handleTrace()

		if self.crouchEnd <= CurTime() then

			self.doingCrouch = false

			if self.Crouching then
				self:SetPoseParameter("body_height", 0)
			else
				self:SetPoseParameter("body_height", 500)
			end

			self.NextIdleLoop = CurTime()
			self.NextMoveLoop = CurTime()

		end

	else

		if self.Controller then

			if self.Crouching then

				self.Controller:SetPos(self:GetPos() - Vector(0, 0, 250))

			else

				self.Controller:SetPos(self:GetPos())

			end

			self.GunProp:SetPos(self:GetPos())

			if self.Controller:KeyDown(IN_RELOAD) then

				self:handleCrouch()

			end

		end

		if self.Moving then

			if self.NextMoveLoop <= CurTime() then

				if self.Walking then

					self:ResetSequence(9)

				else

					self:ResetSequence(10)

				end

				self.NextMoveLoop = CurTime() + self:SequenceDuration()

			end

		else

			if self.NextIdleLoop <= CurTime() then

				self:ResetSequence(1)

				self.NextIdleLoop = CurTime() + self:SequenceDuration()

			end

		end

		self:handleMovement()

		self:handleMinigun()
		self:handleDickCannon()

	end

	self:NextThink(CurTime())
end

local function isNear(num, num2)

	if ((num2-5) <= num) and ((num2+5) >= num) then

		return true

	end

	return false

end

local function traceUp(self)

	local trace = { }
	trace.start = self:GetPos() - Vector(0, 0, 250)
	trace.endpos = trace.start + (Vector(0, 0, 1) * 10000)
	trace.filter = {self,self.Controller,self.GunProp}

	local tr = util.TraceLine(trace)

	if (trace.start - tr.HitPos).z < 250 then

		return true

	end

	return false

end

function ENT:handleTrace(override)

	local pos = self:GetPos()
	local ang = Vector(0, 0, -1)

	local trace = { }
	trace.start = pos
	trace.endpos = pos + (ang * 10000)
	trace.filter = {self,self.Controller,self.GunProp}

	local tr = util.TraceLine(trace)

	if self.Crouching then

		if !isNear(((self:GetPos() - Vector(0, 0, 250)) - tr.HitPos).z, 250) then

			if traceUp(self) then

				trace = { }
				trace.start = pos - Vector(0, 0, 250)
				trace.endpos = pos + (ang * 10000)
				trace.filter = {self,self.Controller,self.GunProp}

				tr = util.TraceLine(trace)

			end

			self:SetPos(tr.HitPos + Vector(0, 0, 500))

		end

	else

		if (tr.HitPos - self:GetPos()).z != 500 then

			self:SetPos(tr.HitPos + Vector(0, 0, 500))

		end

	end

end

function ENT:handleMovement()

	self:handleTrace()
	self:handleWalkSounds()

	if self.Controller then

		if !self.CanMove then
			self.Moving = false
			self.NextIdleLoop = CurTime()
			return
		end

		local ang = self.Controller:GetAimVector():Angle()

		ang.p = self:GetAngles().p

		self:SetAngles(ang)

		if self.Controller:KeyDown(IN_FORWARD) then

			if !self.Moving then
				self.NextMoveLoop = CurTime()
				self.Moving = true
			end

			self:SetPos(self:GetPos() + (self:GetAngles():Forward()) * 75)

		else

			if self.Moving then
				self.NextIdleLoop = CurTime()
				self.Moving = false
			end

		end

	end

end

function ENT:handleCrouch()

	if self.Crouching then

		self:ResetSequenceInfo()

		self.doingCrouch = true
		self:SetSequence(3)
		self:SetCycle(0)
		self.crouchEnd = CurTime() + self:SequenceDuration() - 0.5

	else

		self:ResetSequenceInfo()

		self.doingCrouch = true
		self:SetSequence(2)
		self:SetCycle(0)
		self.crouchEnd = CurTime() + self:SequenceDuration() - 0.5

	end

	self.Crouching = !self.Crouching
end

function ENT:handleMinigun()

	if self.Controller:KeyDown(IN_ATTACK) then

		if CurTime() >= self.NextPrimaryAttack then

			//Most everything below is for visual effect.

			local boneIndex = self:LookupBone("head_bone")

			local atIndex = self:LookupAttachment("minigun")

			local atpos = self:GetAttachment(atIndex)

			local bpos, bang = self:GetBonePosition(boneIndex)

			self.Controller:SetPos(atpos.Pos)
			self.GunProp:SetPos(atpos.Pos)

			//We're going to want to make the shot hit the center of the screen, so we're going to need to replicate the client's position serverside, and get a normal for the bullet.

			local boneIndex2 = self:LookupBone("body_bone")
			local bpos2, bang2 = self:GetBonePosition(boneIndex2)

			local trace = { }
			trace.start = bpos2 + (Vector(0, 0, 100) + (self:GetAngles():Forward() * -50))
			trace.endpos = trace.start + (self.Controller:GetAimVector() * 10000)
			trace.filter = { self, self.Controller, self.GunProp }

			local tr = util.TraceLine(trace)

			local newNormal = tr.HitPos - atpos.Pos

			newNormal = newNormal:Normalize()

			//We have the normal, create and shoot the bullet.

			local bullet = { }
			bullet.Num = 1
			bullet.Src = atpos.Pos
			bullet.Dir = newNormal
			bullet.Spread = { 0, 0, 0 }
			bullet.Tracer = 1
			bullet.Force = 1
			bullet.Damage = 50
			bullet.TracerName = "AirboatGunHeavyTracer"

			self.Controller:FireBullets(bullet)

			//What is a strider without a muzzleflash?

			local effectdata2 = EffectData()
				effectdata2:SetEntity(self)
				effectdata2:SetAttachment(atIndex)
			util.Effect("StriderMuzzleFlash", effectdata2)

			//And of course, sound!

			math.randomseed(os.time())

			local num = math.random(1, 2)

			local path

			if num == 1 then

				path = "npc/strider/strider_minigun.wav"

			else

				path = "npc/strider/strider_minigun2.wav"

			end

			sound.Play(path, atpos.Pos, 70, 100)

			self.NextPrimaryAttack = CurTime() + 0.05

		end

	end

end

ENT.CannonHitPos = nil
ENT.CannonHitNormal = nil

function ENT:handleDickCannon()

	if self.Controller:KeyDown(IN_ATTACK2) then

		if CurTime() >= self.NextPenetration then

			local atIndex = self:LookupAttachment("biggun")
			local atpos = self:GetAttachment(atIndex)

			local boneIndex = self:LookupBone("body_bone")
			local bpos, bang = self:GetBonePosition(boneIndex)

			local trace = { }
			trace.start = bpos + (Vector(0, 0, 100) + (self:GetAngles():Forward() * -50))
			trace.endpos = trace.start + (self.Controller:GetAimVector() * 10000)
			trace.filter = { self, self.Controller, self.GunProp }

			local tr = util.TraceLine(trace)

			self.CannonHitPos = tr.HitPos

			local newNormal = tr.HitPos - atpos.Pos

			newNormal = newNormal:Normalize()

			self.CannonHitNormal = newNormal

			//i took these effects from the strider cannon swep, thanks for making them!

			local effect = EffectData()
			effect:SetEntity(self)
			effect:SetAttachment(atIndex)
			effect:SetStart(tr.HitPos)
			util.Effect("stridcan_charge",effect)

			self.BigGunShooting = true
			self.BigGunShootTime = CurTime() + 1.35

			sound.Play("NPC_Strider.Charge", atpos.Pos, 100, 100)

			self.CanMove = false
			self.NextPenetration = CurTime() + 2

		end

	end

	if self.BigGunShooting then

		if CurTime() >= self.BigGunShootTime then

			local atIndex = self:LookupAttachment("biggun")
			local atpos = self:GetAttachment(atIndex)

			local fx = EffectData()
			fx:SetEntity(self)
			fx:SetOrigin(self.CannonHitPos)
			fx:SetAttachment(atIndex)
			util.Effect("stridcan_fire",fx)
			util.Effect("stridcan_mzzlflash",fx)

			sound.Play("NPC_Strider.Shoot", atpos.Pos, 100, 100)

			local dist = (self.CannonHitPos - atpos.Pos):Length()
			local delay = dist/8000

			timer.Simple(delay, function() self:CannonExplosion() end)

			self.CanMove = true
			self.BigGunShooting = false

		end

	end

end

function ENT:CannonExplosion()

	local fx = EffectData()
	fx:SetOrigin(self.CannonHitPos)
	fx:SetNormal(self.CannonHitNormal)
	util.Effect("stridcan_expld",fx)
	util.Effect("Explosion",fx)

	local vaporizer = ents.Create("point_hurt")
	vaporizer:SetKeyValue("Damage", 200)
	vaporizer:SetKeyValue("DamageRadius", 512)
	vaporizer:SetKeyValue("DamageType", DMG_DISSOLVE | DMG_BLAST)
	vaporizer:SetPos(self.CannonHitPos)
	vaporizer:SetOwner(self.Controller)
	vaporizer:Spawn()
	vaporizer:Fire("hurt","",0)
	vaporizer:Fire("kill","",0.1)

end

ENT.didC1 = false
ENT.didC2 = false
ENT.didC3 = false

local function shakeTraceDown(self, pos)

	local trace = { }
	trace.start = pos
	trace.endpos = trace.start + (Vector(0, 0, -1) * 10000)
	trace.filter = {self,self.Controller,self.GunProp}

	local tr = util.TraceLine(trace)

	return tr.HitPos

end

function ENT:handleWalkSounds()

	if self:GetSequence() == 10 then

		if (math.Round(self:GetCycle(), 2) > .2 and math.Round(self:GetCycle(), 2) < .4) and !self.didC1 then

			local boneIndex = self:LookupBone("leg_left_bone1")

			local bpos, bang = self:GetBonePosition(boneIndex)

			math.randomseed(os.time())
			sound.Play("npc/strider/strider_step" .. math.random(1, 6) .. ".wav", bpos, 75, 100)

			util.ScreenShake(shakeTraceDown(self, bpos), 5, 5, 1, 512)

			self.didC1 = true
			self.didC2 = false
			self.didC3 = false

		elseif math.Round(self:GetCycle(), 2) > .5 and math.Round(self:GetCycle(), 2) < .7 and !self.didC2 then

			local boneIndex = self:LookupBone("leg_left_bone1")

			local bpos, bang = self:GetBonePosition(boneIndex)

			math.randomseed(os.time())
			sound.Play("npc/strider/strider_step" .. math.random(1, 6) .. ".wav", bpos, 75, 100)

			util.ScreenShake(shakeTraceDown(self, bpos), 5, 5, 1, 512)

			self.didC1 = false
			self.didC2 = true
			self.didC3 = false

		elseif math.Round(self:GetCycle(), 2) > .8 and math.Round(self:GetCycle(), 2) < 1 and !self.didC3 then

			local boneIndex = self:LookupBone("leg_left_bone1")

			local bpos, bang = self:GetBonePosition(boneIndex)

			math.randomseed(os.time())
			sound.Play("npc/strider/strider_step" .. math.random(1, 6) .. ".wav", bpos, 75, 100)

			util.ScreenShake(shakeTraceDown(self, bpos), 5, 5, 1, 512)

			self.didC1 = false
			self.didC2 = false
			self.didC3 = true

		end

	end

end

function ENT:handleDeath()

	self:Remove()

end

function ENT:SetController(ply)

	self.Controller = ply
	ply:SetMoveType(0)
	ply.Strider = ent

	ply:StripWeapons()
	ply:SetNoDraw(true)

	ply:SetHull(Vector(-32, -32, -32), Vector(32, 32, 32))
	ply:SetHealth(10000)
	ply:SetArmor(20000)

	ply:SetNWEntity("strider", self)

	self.GunProp:SetOwner(ply)

end