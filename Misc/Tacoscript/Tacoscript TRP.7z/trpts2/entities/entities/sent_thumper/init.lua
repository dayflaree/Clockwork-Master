


resource.AddFile("materials/VGUI/entities/sent_SakariasJet.vmt")
resource.AddFile("materials/VGUI/entities/sent_SakariasJet.vtf")

AddCSLuaFile("shared.lua")
include('shared.lua')




------------------------------------VARIABLES END
function ENT:SpawnFunction(ply, tr)
--------Spawning the entity and getting some sounds i use.
 	if !tr.Hit then return end

 	local SpawnPos = tr.HitPos + tr.HitNormal * 10 - Vector(0,0,1)

	local vec = ply:GetAimVector():Angle()
	local newAng = Angle(0,vec.y,0)
 	local ent = ents.Create("prop_thumper")
	ent:SetPos(SpawnPos)
	ent:SetAngles(newAng)
 	ent:Spawn()
 	ent:Activate()
 	ent.Owner = ply
	return ent

end

