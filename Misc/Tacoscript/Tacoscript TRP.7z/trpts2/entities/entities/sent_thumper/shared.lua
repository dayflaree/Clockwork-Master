
ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName		= "Thumper"
ENT.Author			= "florian5440"
ENT.Category 		= "Thumpers"
ENT.Contact    		= ""
ENT.Purpose 		= "keeps antlions away"
ENT.Instructions 	= ""

ENT.Spawnable			= true
ENT.AdminSpawnable		= true
ENT.crap = 0


