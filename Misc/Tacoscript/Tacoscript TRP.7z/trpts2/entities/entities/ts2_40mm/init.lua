AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include('shared.lua')

local FlightSound = Sound("PhysicsCannister.ThrusterLoop")

function ENT:Initialize()

	self.Damage = 100
	self.DoUnconscious = true

	PrecacheParticleSystem("grenade_explosion_01")

	self.Entity:SetModel("models/items/ar2_grenade.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:SetColor(Color(255, 255, 255, 0))
	self.Owner = self:GetOwner()

	local phys = self.Entity:GetPhysicsObject()
    if phys:IsValid() then
        phys:Wake()
    end

	self.dietime = CurTime() + 10
	self.spreadtime = CurTime() + 3
	self.flightvector = self.Entity:GetForward() * 40

	util.SpriteTrail(self.Entity, 0, Color(255, 255, 255, 255), false, 6, 0, 0.1, 8, "trails/smoke.vmt")

	self.drop = Vector(0,0,-0.15)

	self:Think()

end

function ENT:DoExplosion(damage, radius, tr)

	local targets = ents.FindInSphere(self.Entity:GetPos(), radius)

	for k, v in pairs (targets) do

		if v:IsPlayer() || v:IsNPC() then

			local dist = v:GetPos():Distance(self.Entity:GetPos())

			damage = damage - (damage * (dist / radius))

			local dmginfo = DamageInfo()

			dmginfo:SetDamage(damage)
			dmginfo:SetDamageType(DMG_BLAST)
			dmginfo:SetAttacker(self.Owner)
			dmginfo:SetDamageForce(Vector(0, 0, 100))

			v:TakeDamageInfo(dmginfo)

			if dist < radius && self.DoUnconscious then

				if v:IsPlayer() && v:Alive() then
					v:SetPlayerConsciousness(math.Clamp(100 * (dist / radius), 60, 100))

					if dist < 90 then
						v:Unconscious()
					end
				end

			end

		end

	end

	local effectdata = EffectData()

	effectdata:SetOrigin(tr.HitPos)
	effectdata:SetNormal(tr.HitNormal)
	effectdata:SetScale(0.5)
	effectdata:SetRadius(1)
	util.Effect("HelicopterMegaBomb", effectdata)
	util.Effect("Rocket_Explosion", effectdata)
	util.ScreenShake(tr.HitPos, 10, 5, 1, 1000)
	util.Decal("Scorch", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal)

	ParticleEffect("grenade_explosion_01", tr.HitPos, Angle(0, 0, 0), nil)

	sound.Play("explode_4", tr.HitPos, 180, 100, 1)

	self.Entity:Remove()

end

function ENT:Think()

	local vectors = { self:GetForward() *30, self:GetUp() *25, self:GetUp() *-25 }

	for i = 1, #vectors do
		local v = vectors[i]
		local tracedata = {}
		tracedata.start = self:GetPos()
		tracedata.endpos = self:GetPos() +v
		tracedata.filter = { self, self.owner }
		local trace = util.TraceLine(tracedata)
		if trace.HitWorld || (IsValid(trace.Entity) && !trace.Entity:IsWeapon()) then
			if (not ((self.dietime - CurTime()) < 1) && trace.Entity:IsPlayer()) || not trace.Entity:IsPlayer() then
				if not (trace.Entity:GetClass() == "ts2_40mm") then
					self:DoExplosion(self.Damage, 300, trace)
					return
				end
			else
				if trace.Entity:IsPlayer() && trace.HitBox == HITGROUP_HEAD then
					v:SetPlayerConsciousness(50 * (1 - ((self.dietime - CurTime()) / 10)))
					v:Unconscious()
					self.Entity:Remove()
				end
			end
		end
	end

	if CurTime() > self.dietime then

		self.Entity:Remove()
		return

	end

	self.flightvector = self.flightvector + self.drop
	self.Entity:SetPos(self.Entity:GetPos() + self.flightvector)

	self.flightvector = self.flightvector + self.drop
	self.Entity:SetAngles(self.flightvector:Angle())

	self.Entity:NextThink(CurTime())

	return true

end

function ENT:OnRemove()

	self.Entity:StopSound(FlightSound)

end

local function ShotNadeTool(ply, trace, tool)

	if trace.Entity:GetClass() == "ts2_40mm" then

		return false

	end

end

hook.Add("CanTool", "ShotNadeTool", ShotNadeTool)

local function ShotNadePhys(ent)

	if ent:GetClass() == "ts2_40mm" then

		return false

	end

end
hook.Add("PhysgunPickup", "ShotNadePhys" , ShotNadePhys)