ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"
ENT.PrintName		= "40mm Grenade"
ENT.Author			= "Firehawk"
ENT.Contact			= "youdontgetthis@gmail.com"
ENT.Purpose			= "shoot the mans!"
ENT.Instructions	= "freedumbs"

ENT.Spawnable		= false
ENT.AdminSpawnable	= false

