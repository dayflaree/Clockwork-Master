function TSCalcView( ply, origin, angles, fov )
if( ValidEntity( LocalPlayer() ) ) then

	if( CrackDrug and CurTime() - DrugTime > 4 ) then
	
		local view = { }
	
		CrackDrugAng = CrackDrugAng or Angle( 0, 0, 0 );		
		CrackDrugAng.y = CrackDrugAng.y + 180 * FrameTime();
		
		view.origin = origin;
		view.angles = ply:GetAimVector():Angle() + CrackDrugAng;
		
		return view;
		
	end
	
end
end
hook.Add( "CalcView", "TSCalcView", TSCalcView );	