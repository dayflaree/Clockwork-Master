
local function MetroPlayerPush( ply )

	local trace = { }
	trace.start = ply:EyePos();
	trace.endpos = trace.start + ply:GetAimVector() * 35;
	trace.filter = ply;
	
	local tr = util.TraceLine( trace );
	
	if( ValidEntity( tr.Entity ) and tr.Entity:IsPlayer() ) then
	
		local norm = ( tr.Entity:GetPos() - ply:GetPos() ):Normalize();
		local push = 100 * norm;
					
		tr.Entity:SetVelocity( push );
		
		tr.Entity:EmitSound( Sound( "weapons/crossbow/hitbod1.wav" ) );
	
	end

end

AnimsList = { }

local function AddAnim( team, time, seq, desc, cb )

	table.insert( AnimsList, { team = team, seq = seq, desc = desc, time = time, cb = cb } );

end


AddAnim( 3, 30, "melee_gunhit", "OverWatch-push a player", MetroPlayerPush );
AddAnim( 3, 38, "signal_advance", "Signal advance" );
AddAnim( 3, 38, "signal_forward", "Signal forward" );
AddAnim( 3, 45, "signal_group", "Signal group" );
AddAnim( 3, 48, "signal_halt", "Signal halt" );
AddAnim( 3, 39, "signal_left", "Signal left" );
AddAnim( 3, 40, "signal_right", "Signal other left" );
AddAnim( 3, 41, "signal_takecover", "Signal take cover" );

AddAnim( 4, 30, "melee_gunhit", "OverWatch-push a player", MetroPlayerPush );
AddAnim( 4, 38, "signal_advance", "Signal advance" );
AddAnim( 4, 38, "signal_forward", "Signal forward" );
AddAnim( 4, 45, "signal_group", "Signal group" );
AddAnim( 4, 48, "signal_halt", "Signal halt" );
AddAnim( 4, 39, "signal_left", "Signal left" );
AddAnim( 4, 40, "signal_right", "Signal right" );
AddAnim( 4, 41, "signal_takecover", "Signal take cover" );

AddAnim( 2, 30, "pushplayer", "Metrocop-push a player", MetroPlayerPush );
AddAnim( 2, 160, "plazathreat1", "Threaten 1" );
AddAnim( 2, 200, "plazathreat2", "Threaten 2" );
AddAnim( 2, 80, "luggagewarn", "Threaten 3" );
AddAnim( 2, 28, "point", "Point" );
AddAnim( 2, 40, "cower", "Cower" );
AddAnim( 2, 120, "BlockEntry", "Block entry" );
AddAnim( 2, 135, "adoorknock", "Door knock" );
AddAnim( 2, 66, "motionleft", "Motion left" );
AddAnim( 2, 66, "motionright", "Motion other left" );
AddAnim( 2, 105, "adoorkick", "Door kick breach" );
AddAnim( 2, 105, "adoorenter", "Door enter" );
--AddAnim( 2, 105, "APCidle", "Lean (no weapon out)" );
--AddAnim( 2, 150, "dooridle", "Look around" );

AddAnim( 1, 300, "arrestidle", "[Male] Eat the ground" );
AddAnim( 1, 56, "cheer1", "[Male + Female] Victory" );
AddAnim( 1, 75, "cheer2", "[Male] Clap + Arm Pump" );
AddAnim( 1, 100, "d1_town05_Leon_Door_Knock", "[Male] Knock" );
--AddAnim( 1, 294, "apcarrestidle", "[Male] Spread for patdown" );
--AddAnim( 1, 294, "spreadwallidle", "[Male] Spread for patdown 2" );
--AddAnim( 1, 294, "Lean_Back", "[Male + Female] Lean_Back" );
--AddAnim( 1, 294, "Lean_Left", "[Male + Female] Lean Left" );
--AddAnim( 1, 294, "lookoutidle", "[Male] Look out" );
--AddAnim( 1, 294, "Lying_Down", "[Male + Female] Lie down" );
--AddAnim( 1, 294, "Sit_Ground", "[Male + Female] Sit" );


function ccAnimList( ply, cmd, args )

	ply:PrintMessage( 2, "Use rp_playanim <id> to play an animation on yourself.  You cannot move while the animation is in effect" );
	
	local team = ply:Team();
	
	ply:PrintMessage( 2, "ID   |   ANIMATION" );

	if( team == 2 and ply:IsTempCP() ) then return; end
	
	local n = 1;

	for k, v in pairs( AnimsList ) do
	
		if( v.team == 0 or v.team == team ) then
			ply:PrintMessage( 2, n .. ") " .. v.desc );
			n = n + 1;
		end
	
	end

end
concommand.Add( "rp_animslist", ccAnimList );

function ccPlayAnim( ply, cmd, args )

	if( ply:GetField( "OverrideAnim" ) ) then
		ply:PrintMessage( 2, "Another animation is playing" );
		return;
	end


	local anims = { }

	local team = ply:Team();
	local n = 1;

	if( team == 2 and ply:IsTempCP() ) then return; end

	for k, v in pairs( AnimsList ) do
	
		if( v.team == 0 or v.team == team ) then
			anims[n] = { }
			anims[n].seq = v.seq;
			anims[n].time = v.time;
			anims[n].cb = v.cb;
			n = n + 1;
		end
	
	end
	
	local chosen = tonumber( args[1] );
	
	if( not anims[chosen] ) then
	
		ply:PrintMessage( 2, "Unknown animation" );
		return;
	
	end
	
	ply:OverrideAnimation( anims[chosen].seq, anims[chosen].time * FrameTime() );
	
	if( anims[chosen].cb ) then
		anims[chosen].cb( ply );
	end

end
concommand.Add( "rp_playanim", ccPlayAnim );