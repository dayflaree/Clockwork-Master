
ITEM.Name = "Light Padding";

ITEM.Weight = .5;
ITEM.Size = 3;
ITEM.Model = "models/props_c17/suitcase001a.mdl";
ITEM.Usable = true;

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 920;
ITEM.FactoryStock = 2;

ITEM.License = 5;

ITEM.BlackMarket = false;
ITEM.LightMarket = true;

ITEM.Desc = "Some light padding..";

function ITEM:OnUse()

	self.Owner:SetArmor( 15 );
		
end