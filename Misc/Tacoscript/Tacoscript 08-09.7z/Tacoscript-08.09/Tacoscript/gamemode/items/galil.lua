

ITEM.Name = "Galil Assault Rifle";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_rif_galil.mdl";
ITEM.Usable = false;

ITEM.Desc = "Israeli-manufactured Rifle";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 2900;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 20;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_galil" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end


