

ITEM.Name = "Jar O' Crack Rocks";

ITEM.Weight = .5;
ITEM.Size = 2;
ITEM.Model = "models/props_lab/jar01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Head asplode";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 30;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

	self.Owner:SetFOV( 60, 2.5 );
	
	umsg.Start( "CrackDrug", self.Owner );
	umsg.End();
	
	timer.Simple( 17, self.Owner.SetFOV, self.Owner, 90, 3.5 );
	
	local function MakeKO( ply )
		ply:SetNWFloat( "conscious", 20 );
		ply:GoUnconscious();
	end
	
	timer.Simple( 17, MakeKO, self.Owner );

end

