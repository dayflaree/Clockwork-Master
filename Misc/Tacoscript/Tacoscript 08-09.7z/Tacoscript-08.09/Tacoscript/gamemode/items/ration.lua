
ITEM.Name = "Combine Ration";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/weapons/w_package.mdl";
ITEM.Usable = true;

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 140;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 2;

ITEM.Desc = "Combine issued ration containing necessary food and tokens";


function ITEM:OnPickup()
	
	if( self.Owner:IsCombineDefense() ) then
		
		SetGlobalInt( "CombineRations", GetGlobalInt( "CombineRations" ) + 1 );
		timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
		timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
		
	end
	
end

function ITEM:OnUse()

	self.Owner:SetNWFloat( "money", self.Owner:GetNWFloat( "money" ) + 150 );
	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 5, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:AddMaxStamina( 70 );

end
