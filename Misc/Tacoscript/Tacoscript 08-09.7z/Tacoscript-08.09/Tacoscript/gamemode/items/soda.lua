ITEM.Name = "Soda";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/PopCan01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Mmmm tasty, it'll give you some extra energy for a bit.";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 3;
ITEM.FactoryStock = 12;

ITEM.LastSoda = 0;
ITEM.SodaCount = 0;

ITEM.SupplyLicense = 1;

ITEM.License = 1;

function ITEM:OnUse()

	if( CurTime() - self.LastSoda > 180 ) then
		
		self.SodaCount = 0;
		
	end

	self.SodaCount = self.SodaCount + 1;
	
	if( self.SodaCount <= 4 ) then

		self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 15, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
		self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 20, 0, 100 ) );
		self.Owner:TempStatBoost( "Speed", 3, 60 );
		
	else
	
		self.Owner:TempStatBoost( "Sprint", -5, 60 );
	
	end
	
	self.LastSoda = CurTime();
	
	self.Owner:AddMaxStamina( 22 );
	
end
