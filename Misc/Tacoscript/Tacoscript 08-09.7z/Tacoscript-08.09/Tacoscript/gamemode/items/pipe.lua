

ITEM.Name = "Pipe";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/props_canal/mattpipe.mdl";
ITEM.Usable = false;

ITEM.Desc = "Melee weapon";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 50;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 5;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_pipe" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
