ITEM.Name = "CWU ID Card";
 
ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_lab/clipboard.mdl";
ITEM.Usable = false;
 
ITEM.Desc = "CWU Priviledged Citizen Identification Card";
 
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice =  6000;
ITEM.FactoryStock = 10;
ITEM.License = 5;
ITEM.LightMarket = true;

