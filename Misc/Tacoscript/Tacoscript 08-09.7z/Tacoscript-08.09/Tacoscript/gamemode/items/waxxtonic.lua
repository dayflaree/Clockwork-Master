

ITEM.Name = "Waxx's Tonic";

ITEM.Weight = .5;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Restores some health and stamina";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 10;
ITEM.FactoryStock = 5;

ITEM.License = 1;


function ITEM:OnUse()

	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 20, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 25, 0, 100 ) );
	self.Owner:AddMaxStamina( 25 );

end
