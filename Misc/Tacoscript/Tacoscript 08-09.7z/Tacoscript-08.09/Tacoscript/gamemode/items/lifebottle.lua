

ITEM.Name = "Bottle O' LSD laced water";

ITEM.Weight = .1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_glassbottle001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "THIS IS FUCKIN' CRAZY, MAN.";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 15;
ITEM.FactoryStock = 5;

function ITEM:OnUse()

	self.Owner:SetFOV( 150, 3.5 );
	
	umsg.Start( "Drug", self.Owner );
	umsg.End();
	
	timer.Simple( 10, self.Owner.SetFOV, self.Owner, 90, 3.5 );

end

