ITEM.Name = "Resistance M93R";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_alyx_gun.mdl";
ITEM.Usable = false;

ITEM.Desc = "A small, easily concealed automatic pistol.";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 1700;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 5;

function ITEM:OnPickup()

self.Owner:ForceGive( "weapon_ts_m93r" );

timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
timer.Simple( .4, self.Owner.CheckInventory, self.Owner );

self.Owner:SaveWeapons();

end