
ITEM.Name = "Combat Vest";

ITEM.Weight = .5;
ITEM.Size = 1;
ITEM.Model = "models/props_c17/suitcase001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "A suitcase, containing a resistance outfit.";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = false;
ITEM.FactoryPrice = 3000;
ITEM.FactoryStock = 1;

local VestTable = {}
VestTable["models/Humans/Group01/Male_01.mdl"] = "models/Humans/Group03/Male_01.mdl"
VestTable["models/Humans/Group01/male_02.mdl"] = "models/Humans/Group03/male_02.mdl"
VestTable["models/Humans/Group01/male_03.mdl"] = "models/Humans/Group03/male_03.mdl"
VestTable["models/Humans/Group01/Male_04.mdl"] = "models/Humans/Group03/male_04.mdl"
VestTable["models/Humans/Group01/Male_05.mdl"] = "models/Humans/Group03/male_05.mdl"
VestTable["models/Humans/Group01/male_06.mdl"] = "models/Humans/Group03/male_06.mdl"
VestTable["models/Humans/Group01/male_07.mdl"] = "models/Humans/Group03/male_07.mdl"
VestTable["models/Humans/Group01/male_08.mdl"] = "models/Humans/Group03/male_08.mdl"
VestTable["models/Humans/Group01/male_09.mdl"] = "models/Humans/Group03/male_09.mdl"
VestTable["models/Humans/Group02/Male_01.mdl"] = "models/Humans/Group03/Male_01.mdl"
VestTable["models/Humans/Group02/male_02.mdl"] = "models/Humans/Group03/Male_02.mdl"
VestTable["models/Humans/Group02/male_03.mdl"] = "models/Humans/Group03/Male_03.mdl"
VestTable["models/Humans/Group02/Male_04.mdl"] = "models/Humans/Group03/Male_04.mdl"
VestTable["models/Humans/Group02/Male_05.mdl"] = "models/Humans/Group03/Male_05.mdl"
VestTable["models/Humans/Group02/male_06.mdl"] = "models/Humans/Group03/Male_06.mdl"
VestTable["models/Humans/Group02/male_07.mdl"] = "models/Humans/Group03/Male_07.mdl"
VestTable["models/Humans/Group02/male_08.mdl"] = "models/Humans/Group03/Male_08.mdl"
VestTable["models/Humans/Group02/male_09.mdl"] = "models/Humans/Group03/Male_09.mdl"

VestTable["models/Humans/Group01/Female_01.mdl"] = "models/Humans/Group03/Female_01.mdl"
VestTable["models/Humans/Group01/Female_02.mdl"] = "models/Humans/Group03/Female_02.mdl"
VestTable["models/Humans/Group01/Female_03.mdl"] = "models/Humans/Group03/Female_03.mdl"
VestTable["models/Humans/Group01/Female_04.mdl"] = "models/Humans/Group03/Female_04.mdl"
VestTable["models/Humans/Group01/Female_06.mdl"] = "models/Humans/Group03/Female_06.mdl"
VestTable["models/Humans/Group01/Female_07.mdl"] = "models/Humans/Group03/Female_07.mdl"
VestTable["models/Humans/Group02/Female_01.mdl"] = "models/Humans/Group03/Female_01.mdl"
VestTable["models/Humans/Group02/Female_02.mdl"] = "models/Humans/Group03/Female_02.mdl"
VestTable["models/Humans/Group02/Female_03.mdl"] = "models/Humans/Group03/Female_03.mdl"
VestTable["models/Humans/Group02/Female_04.mdl"] = "models/Humans/Group03/Female_04.mdl"
VestTable["models/Humans/Group02/Female_06.mdl"] = "models/Humans/Group03/Female_06.mdl"
VestTable["models/Humans/Group02/Female_07.mdl"] = "models/Humans/Group03/Female_07.mdl"

function ITEM:OnUse()

	if VestTable[self.Owner:GetModel()] then self.Owner:SetModel(VestTable[self.Owner:GetModel()]) end 
	self.Owner:SetArmor( "45" )
	self.Owner:GiveItem( "citizensclothes1", false, true )
	
end 