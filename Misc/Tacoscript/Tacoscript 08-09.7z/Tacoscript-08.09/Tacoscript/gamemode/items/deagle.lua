

ITEM.Name = "Desert Eagle .50";

ITEM.Weight = 1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_pist_deagle.mdl";
ITEM.Usable = false;

ITEM.Desc = "Rare, powerful handgun";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 3500;
ITEM.FactoryStock = 3;

ITEM.RebelCost = 50;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_deagle" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
end
