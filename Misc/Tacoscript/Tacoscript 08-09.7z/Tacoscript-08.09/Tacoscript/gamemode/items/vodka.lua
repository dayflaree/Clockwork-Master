

ITEM.Name = "Vodka";

ITEM.Weight = .2;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_glassbottle001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Hell yeah!";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryPrice = 25;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

	umsg.Start( "CrackDrug", self.Owner );
	umsg.End();

self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 20, 0, 100 ) );
self.Owner:TempStatBoost( "Strength", 3, 600 );

self.Owner:SetFOV( 50, 2.5 );
	
	timer.Simple( 6, self.Owner.SetFOV, self.Owner, 70, 3.5 );
	
		timer.Simple( .2, self.Owner.DropOneItem, self.Owner, self.UniqueID );
		timer.Simple( .2, self.Owner.CheckInventory, self.Owner );

end

