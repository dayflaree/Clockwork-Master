

ITEM.Name = "Beer";

ITEM.Weight = .2;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Contraband alchohol";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice =25;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

	self.Owner:TempStatBoost( "Strength", 15, 600 );

	self.Owner:SetFOV( 60, 2.5 );
	
	timer.Simple( 17, self.Owner.SetFOV, self.Owner, 90, 3.5 );
	
	local function MakeKO( ply )
		ply:SetNWFloat( "conscious", 20 );
		ply:GoUnconscious();
	end
	

end

