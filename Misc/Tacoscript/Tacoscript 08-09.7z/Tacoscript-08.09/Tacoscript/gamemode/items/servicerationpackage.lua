

ITEM.Name = "Service Ration Package";

ITEM.Weight = .1;
ITEM.Size = 1;
ITEM.Model = "models/weapons/w_package.mdl";
ITEM.Usable = true;

ITEM.Desc = "A stolen CCA ration package containing water, a meal and tokens";

ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryPrice = 160;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

		self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 35, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
		self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 20, 0, 100 ) );
		self.Owner:SetNWFloat( "money", self.Owner:GetNWFloat( "money" ) + 50 );

		self.Owner:GiveItem( "ration" );
		self.Owner:GiveItem( "cannedwater" );

	timer.Simple( .5, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .5, self.Owner.CheckInventory, self.Owner );

end

