ITEM.Name = "Dog Food";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Survival at all costs";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 5;
ITEM.FactoryStock = 10;

ITEM.License = 1;


function ITEM:OnUse()

	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 5, 0, 100 ) );
	self.Owner:AddMaxStamina( 17 );
	
end
