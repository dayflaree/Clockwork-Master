ITEM.Name = "Chinese Take Away";

ITEM.Weight = 3;
ITEM.Size = 3;
ITEM.Model = "models/props_junk/garbage_takeoutcarton001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Rice and Beefy Goodness";

ITEM.License = 5;
ITEM.LightMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 6;
ITEM.FactoryStock = 3;

ITEM.License = 1;

function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 38, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
self.Owner:AddMaxStamina( 30 );

end