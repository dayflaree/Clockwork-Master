

ITEM.Name = "Remmington Shotgun";

ITEM.Weight = 1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_remmy_fix.mdl";
ITEM.Usable = false;

ITEM.Desc = "Old School 12-guage!";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 5000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 40;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_remington" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
