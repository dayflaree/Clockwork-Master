

ITEM.Name = "Strange Bottle";

ITEM.Weight = .2;
ITEM.Size = 2;
ITEM.Model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Wounder what it is..";

ITEM.FactoryBuyable = true;
ITEM.License = 3;
ITEM.FactoryPrice = 9;
ITEM.FactoryStock = 1;


function ITEM:OnUse()

self.Owner:SetFOV( 50, 2.5 );
	
	timer.Simple( 3, self.Owner.SetFOV, self.Owner, 70, 3.5 );
	
	local function Killself( ply )
		self.Owner:Kill();
	end
	
	timer.Simple( 7, Killself, self.Owner );

end

