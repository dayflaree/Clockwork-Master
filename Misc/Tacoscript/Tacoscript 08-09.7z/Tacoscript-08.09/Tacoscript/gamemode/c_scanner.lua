--created by seiteki a long time ago, modified by looter so it would actually work.
--removed offensive comments, some people are hurt by the internets serious business :(
--Those comments have been there since May 2007, anyway!


scnr = { }
scnr.plyr = { }

function scnr.Init( pl )
--if( !pl:IsDispatch() ) then return false; end

local already = false
for k, v in pairs( scnr.plyr ) do
if v[1] == pl then
already = true
end
end

if !already then
s = ents.Create( "npc_cscanner" )
s:SetPos( pl:GetPos() )
s:SetAngles( pl:GetAngles() )
s:SetKeyValue( "SetDistanceOverride", "64" )
s:SetKeyValue( "spawnflags" , "272" )
s:SetKeyValue( "renderfx" , "0" )
s:SetKeyValue( "disablespotlight" , "0" )
s:SetKeyValue( "ShouldInspect", "0" )

t = ents.Create( "path_corner" )
t:SetPos( pl:GetPos() )
t:SetAngles( pl:GetAngles() )
t:Spawn()
t:SetName( "scanner_target_" .. string.gsub( tostring( s:GetTable() ), "table: ", "" ) )

s:SetKeyValue( "target", t:GetName() )
s:Fire( "clearfollowtarget", "", 0 )
s:Fire( "setfollowtarget", "scanner_target_" .. string.gsub( tostring( s:GetTable() ), "table: ", "" ), 0 )

s:Spawn()

pl:StripWeapons()
pl:Spectate( OBS_MODE_CHASE ) 
pl:SpectateEntity( s )

table.insert( scnr.plyr, { pl, s, t } )
end
end

function scnr.Think()
	for k, v in pairs( scnr.plyr ) do
		local pl = v[1]
		local s = v[2]
		local t = v[3]
		if pl:IsValid() and s:IsValid() and t:IsValid() then
			if pl:KeyDown(IN_FORWARD) then
				local ang = pl:GetAimVector()
				local pos = s:GetPos()+(s:GetForward()*25)+(s:GetUp()*-50)
				t:SetPos(pos+(ang*150))
				pl:SetPos(pos)
				s:Fire( "clearfollowtarget", "", 0 )
				s:Fire( "setfollowtarget", "scanner_target_" .. string.gsub( tostring( s:GetTable() ), "table: ", "" ), 0 )
			end
		end
	end
end
hook.Add( "Think", "scnrThink", scnr.Think )

function scnr.Close( pl )

for k, v in pairs( scnr.plyr ) do

if v[1] == pl then
pl:UnSpectate()
v[2]:Fire( "break", "", 0 )
v[2]:Remove()
v[3]:Remove()
pl:Spawn();
table.remove( scnr.plyr, k )
end

end



end

function scnr.Killed( victim, killer, wep )

for k, v in pairs( scnr.plyr ) do

if v[2] == victim then
TS.TalkToFreq( v[1]:GetField( "radiofreq" ), "Vital signs for " .. v[1]:Nick() .. " have ceased." );
v[1]:EmitSound( "HL1/fvox/flatline.wav", 100, 100);
v[1]:EmitSound( "npc/overwatch/radiovoice/lostbiosignalforunit.wav", 100, 100);
v[1]:UnSpectate()
v[3]:Remove()
v[1]:Spawn();

table.remove( scnr.plyr, k )
end

end

end
hook.Add( "OnNPCKilled", "scnrKilled", scnr.Killed )

function scnr.PlayerGone( victim, weapon, killer )

for k, v in pairs( scnr.plyr ) do

if v[1] == victim then
v[1]:UnSpectate()
v[2]:Remove()
v[3]:Remove()
v[1]:Spawn()
table.remove( scnr.plyr, k )
end

end

end
hook.Add( "PlayerDeath", "scnrPlayerKilled", scnr.PlayerGone )
hook.Add( "PlayerDisconnected", "scnrPlayerDisconnected", scnr.PlayerGone )