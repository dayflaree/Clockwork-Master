--Resources!  Instead of using .res files.

resource.AddFile( "models/weapons/w_boom_xm1014.mdl.phy" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.vvd" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.sw.vtx" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.mdl" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.dx90.vtx" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.dx80.vtx" );
resource.AddFile( "models/weapons/w_boom_xm1014.mdl.vtx" );

resource.AddFile( "models/humans/group01/female_fringe.dx80.vtx" );
resource.AddFile( "models/humans/group01/female_fringe.dx90.vtx" );
resource.AddFile( "models/humans/group01/female_fringe.mdl" );
resource.AddFile( "models/humans/group01/female_fringe.sw.vtx" );
resource.AddFile( "models/humans/group01/female_fringe.vvd" );
resource.AddFile( "models/humans/group01/female_fringe.phy" );
resource.AddFile( "materials/models/humans/female/group01/deleriumfringe.vmt" );
resource.AddFile( "materials/models/humans/female/group01/deleriumfringe.vtf" );
resource.AddFile( "materials/models/humans/female/fringe.vtf" );
resource.AddFile( "materials/models/humans/female/fringe.vmt" );
resource.AddFile( "materials/models/humans/female/sidehair.vtf" );
resource.AddFile( "materials/models/humans/female/sidehair.vmt" );

resource.AddFile( "models/weapons/v_blade_m11.vvd" );
resource.AddFile( "models/weapons/v_blade_m11.sw.vtx" );
resource.AddFile( "models/weapons/v_blade_m11.mdl" );
resource.AddFile( "models/weapons/v_blade_m11.dx90.vtx" );
resource.AddFile( "models/weapons/v_blade_m11.dx80.vtx" );
resource.AddFile( "models/weapons/w_blade_m11.phy" );
resource.AddFile( "models/weapons/w_blade_m11.vvd" );
resource.AddFile( "models/weapons/w_blade_m11.sw.vtx" );
resource.AddFile( "models/weapons/w_blade_m11.mdl" );
resource.AddFile( "models/weapons/w_blade_m11.dx90.vtx" );
resource.AddFile( "models/weapons/w_blade_m11.dx80.vtx" );
resource.AddFile( "materials/models/weapons/v_models/go_mac11/m11_1.vtf" );
resource.AddFile( "materials/models/weapons/v_models/go_mac11/m11_1.vmt" );
resource.AddFile( "materials/models/weapons/v_models/go_mac11/m11_2.vtf" );
resource.AddFile( "materials/models/weapons/v_models/go_mac11/m11_2.vmt" );
resource.AddFile( "sound/weapons/lrshot.wav" );


resource.AddFile( "models/humans/group01/jillshaal.dx80.vtx" );
resource.AddFile( "models/humans/group01/jillshaal.dx90.vtx" );
resource.AddFile( "models/humans/group01/jillshaal.mdl" );
resource.AddFile( "models/humans/group01/jillshaal.sw.vtx" );
resource.AddFile( "models/humans/group01/jillshaal.vvd" );
resource.AddFile( "models/humans/group01/jillshaal.phy" );
resource.AddFile( "models/humans/group01/jillshaal.xbox.vtx" );
resource.AddFile( "models/humans/group01/lambda1.dx80.vtx" );
resource.AddFile( "models/humans/group01/lambda1.dx90.vtx" );
resource.AddFile( "models/humans/group01/lambda1.mdl" );
resource.AddFile( "models/humans/group01/lambda1.sw.vtx" );
resource.AddFile( "models/humans/group01/lambda1.vvd" );
resource.AddFile( "models/humans/group01/lambda1.phy" );
resource.AddFile( "models/humans/group01/lambda2.dx80.vtx" );
resource.AddFile( "models/humans/group01/lambda2.dx90.vtx" );
resource.AddFile( "models/humans/group01/lambda2.mdl" );
resource.AddFile( "models/humans/group01/lambda2.sw.vtx" );
resource.AddFile( "models/humans/group01/lambda2.vvd" );
resource.AddFile( "models/humans/group01/lambda2.phy" );
resource.AddFile( "materials/models/humans/male/group01/nob_facemap.vmt" );
resource.AddFile( "materials/models/humans/male/group01/nob_facemap.vtf" );
resource.AddFile( "materials/models/humans/male/group01/tlm_facemap.vmt" );
resource.AddFile( "materials/models/humans/male/group01/tlm_facemap.vtf" );
resource.AddFile( "materials/models/humans/male/group01/tlm_facemap_normal.vtf" );
resource.AddFile( "materials/models/mossman/eyeball_k.vmt" );
resource.AddFile( "materials/models/mossman/eyeball_k.vtf" );
resource.AddFile( "materials/models/mossman/tossman_face.vmt" );
resource.AddFile( "materials/models/mossman/tossman_face.vtf" );
resource.AddFile( "materials/models/mossman/tossman_hair.vmt" );
resource.AddFile( "materials/models/mossman/tossman_hair.vtf" );





--resource.AddFile( "materials/models/props/cs_office/amariapc.vmt" );
--resource.AddFile( "materials/models/props/cs_office/amariapc.vtf" );
--resource.AddFile( "materials/models/props/cs_office/computer_ref.vtf" );
--resource.AddFile( "materials/models/props/cs_office/sceeen.vmt" );
--resource.AddFile( "materials/models/props_lab/cs_office/sceeen.vtf" );
--resource.AddFile( "materials/models/props_lab/cs_office/screenb.vmt" );
--resource.AddFile( "materials/models/props_lab/cs_office/screenb.vtf" );
--resource.AddFile( "materials/models/props/amariaclipboard.vmt" );
--resource.AddFile( "materials/models/props/amariaclipboard.vtf" );
--resource.AddFile( "materials/models/props/amariaclipboard_n.vtf" );
--resource.AddFile( "materials/models/props_wasteland/amaria_container1.vmt" );
--resource.AddFile( "materials/models/props_wasteland/amaria_container1.vtf" );
--resource.AddFile( "materials/models/props_wasteland/amaria_container1_normal.vtf" );
--resource.AddFile( "models/props/cs_office/amariapc.dx80.vtx" );
--resource.AddFile( "models/props/cs_office/amariapc.dx90.vtx" );
--resource.AddFile( "models/props/cs_office/amariapc.mdl" );
--resource.AddFile( "models/props/cs_office/amariapc.phy" );
--resource.AddFile( "models/props/cs_office/amariapc.sw.vtx" );
--resource.AddFile( "models/props/cs_office/amariapc.vvd" );
--resource.AddFile( "models/props_lab/amariaclb.dx80.vtx" );
--resource.AddFile( "models/props_lab/amariaclb.dx90.vtx" );
--resource.AddFile( "models/props_lab/amariaclb.mdl" );
--resource.AddFile( "models/props_lab/amariaclb.phy" );
--resource.AddFile( "models/props_lab/amariaclb.sw.vtx" );
--resource.AddFile( "models/props_lab/amariaclb.vvd" );
--resource.AddFile( "models/props_wasteland/amaria_container1.dx80.vtx" );
--resource.AddFile( "models/props_wasteland/amaria_container1.dx90.vtx" );
--resource.AddFile( "models/props_wasteland/amaria_container1.mdl" );
--resource.AddFile( "models/props_wasteland/amaria_container1.phy" );
--resource.AddFile( "models/props_wasteland/amaria_container1.sw.vtx" );
--resource.AddFile( "models/props_wasteland/amaria_container1.vvd" );



resource.AddFile( "models/weapons/w_mp7_specops.vtx" );
resource.AddFile( "models/weapons/w_mp7_specops.dx90.vtx" );
resource.AddFile( "models/weapons/w_mp7_specops.mdl" );
resource.AddFile( "models/weapons/w_mp7_specops.phy" );
resource.AddFile( "models/weapons/w_mp7_specops.sw.vtx" );
resource.AddFile( "models/weapons/w_mp7_specops.vvd" );
resource.AddFile( "models/weapons/w_mp7_specops.xbox.vtx" );
resource.AddFile( "models/weapons/w_remmy_fix.vtx" );
resource.AddFile( "models/weapons/w_remmy_fix.dx90.vtx" );
resource.AddFile( "models/weapons/w_remmy_fix.mdl" );
resource.AddFile( "models/weapons/w_remmy_fix.phy" );
resource.AddFile( "models/weapons/w_remmy_fix.sw.vtx" );
resource.AddFile( "models/weapons/w_remmy_fix.vvd" );
resource.AddFile( "models/weapons/w_remmy_fix.xbox.vtx" );




resource.AddFile( "models/police_opcmd.dx80.vtx" );
resource.AddFile( "models/police_opcmd.dx90.vtx" );
resource.AddFile( "models/police_opcmd.mdl" );
resource.AddFile( "models/police_opcmd.phy" );
resource.AddFile( "models/police_opcmd.sw.vtx" );
resource.AddFile( "models/police_opcmd.vvd" );



resource.AddFile( "materials/models/thespectator/assassin/boot8normal.vmt" );
resource.AddFile( "materials/models/thespectator/assassin/boot8normal.vtf" );
resource.AddFile( "materials/models/thespectator/assassin/boot8sheet.vmt" );
resource.AddFile( "materials/models/thespectator/assassin/boot8sheet.vtf" );
resource.AddFile( "materials/models/thespectator/assassin/atsushic8_sheet.vmt" );
resource.AddFile( "materials/models/thespectator/assassin/atsushic8_sheet.vtf" );
resource.AddFile( "materials/models/thespectator/assassin/atsushic8_normal.vtf" );
resource.AddFile( "materials/models/thespectator/assassin/atsushic8_phong.vtf" );
resource.AddFile( "models/thespectator/atsushi8.dx80.vtx" );
resource.AddFile( "models/thespectator/atsushi8.dx90.vtx" );
resource.AddFile( "models/thespectator/atsushi8.mdl" );
resource.AddFile( "models/thespectator/atsushi8.phy" );
resource.AddFile( "models/thespectator/atsushi8.sw.vtx" );
resource.AddFile( "models/thespectator/atsushi8.vvd" );


resource.AddFile( "materials/jaanus/ep2snip_parascope.vtf" );
resource.AddFile( "materials/jaanus/ep2snip_parascope.vmt" );
resource.AddFile( "materials/jaanus/sniper_corner.vtf" );
resource.AddFile( "materials/jaanus/sniper_corner.vmt" );
resource.AddFile( "materials/jaanus/w_sniper.vmt" );
resource.AddFile( "materials/jaanus/w_sniper_new.vtf" );
resource.AddFile( "materials/jaanus/w_sniper_new_n.vtf" );
resource.AddFile( "materials/jaanus/w_sniper_phong.vtf" );
resource.AddFile( "materials/jaanus/w_sniper.vmt" );
resource.AddFile( "materials/jaanus/w_sniper.vmt" );
resource.AddFile( "models/weapons/w_combinesniper_e2.vtx" );
resource.AddFile( "models/weapons/w_combinesniper_e2.dx90.vtx" );
resource.AddFile( "models/weapons/w_combinesniper_e2.mdl" );
resource.AddFile( "models/weapons/w_combinesniper_e2.phy" );
resource.AddFile( "models/weapons/w_combinesniper_e2.sw.vtx" );
resource.AddFile( "models/weapons/w_combinesniper_e2.vvd" );
resource.AddFile( "models/weapons/w_combinesniper_e2.xbox.vtx" );
resource.AddFile( "models/weapons/v_combinesniper_e2.vtx" );
resource.AddFile( "models/weapons/v_combinesniper_e2.dx90.vtx" );
resource.AddFile( "models/weapons/v_combinesniper_e2.mdl" );
resource.AddFile( "models/weapons/v_combinesniper_e2.phy" );
resource.AddFile( "models/weapons/v_combinesniper_e2.sw.vtx" );
resource.AddFile( "models/weapons/v_combinesniper_e2.vvd" );
resource.AddFile( "models/weapons/v_combinesniper_e2.xbox.vtx" );
resource.AddFile( "sound/jaanus/ep2sniper_empty.wav	" );
resource.AddFile( "sound/jaanus/ep2sniper_fire.wav" );
resource.AddFile( "sound/jaanus/ep2sniper_reload.wav" );



--APC
resource.AddFile( "models/contron/combapc.mdl" );
resource.AddFile( "models/contron/combapc.phy" );
resource.AddFile( "models/contron/combapc.sw.vtx" );
resource.AddFile( "models/contron/combapc.vvd" );
resource.AddFile( "models/contron/combapc.dx90.vtx" );
resource.AddFile( "models/contron/combapc.dx80.vtx" );

resource.AddFile( "models/police_female_finalcop.mdl" );
resource.AddFile( "models/police_female_finalcop.vvd" );
resource.AddFile( "models/police_female_finalcop.phy" );
resource.AddFile( "models/police_female_finalcop.xbox.vtx" );
resource.AddFile( "models/police_female_finalcop.sw.vtx" );
resource.AddFile( "models/police_female_finalcop.dx80.vtx" );
resource.AddFile( "models/police_female_finalcop.dx90.vtx" );
resource.AddFile( "models/police_female_blondecp.mdl" );
resource.AddFile( "models/police_female_blondecp.vvd" );
resource.AddFile( "models/police_female_blondecp.phy" );
resource.AddFile( "models/police_female_blondecp.xbox.vtx" );
resource.AddFile( "models/police_female_blondecp.sw.vtx" );
resource.AddFile( "models/police_female_blondecp.dx80.vtx" );
resource.AddFile( "models/police_female_blondecp.dx90.vtx" );
resource.AddFile( "materials/models/humans/female/eyeball_k.vmt" );
resource.AddFile( "materials/models/humans/female/pupal_k.vmt" );
resource.AddFile( "materials/models/humans/female/pupal_k.vtf" );
resource.AddFile( "materials/models/humans/female/group01/female8_cylmap.vmt" );
resource.AddFile( "materials/models/humans/female/group02/female8_cylmap.vmt" );
resource.AddFile( "materials/models/humans/female/group01/female8_cylmap.vtf" );
resource.AddFile( "materials/models/humans/female/group03/female8_cylmap.vmt" );
resource.AddFile( "materials/models/humans/female/group03m/female8_facemap.vmt" );
resource.AddFile( "materials/models/humans/female/group01/finalc8_cylmap.vmt" );
resource.AddFile( "materials/models/humans/female/group02/finalc8_cylmap.vmt" );
resource.AddFile( "materials/models/humans/female/group01/finalc8_cylmap.vtf" );





--city8 combine

resource.AddFile( "materials/models/police/eliteshockunit.vmt" );
resource.AddFile( "materials/models/police/eliteshockunit.vtf" );
resource.AddFile( "materials/models/police/eliteshockunit_normal.vtf" );
resource.AddFile( "materials/models/police/squadleaderco8.vmt" );
resource.AddFile( "materials/models/police/squadleaderco8.vtf" );
resource.AddFile( "materials/models/police/squadleaderco8n.vtf" );
resource.AddFile( "materials/models/police/metroc08_sheet.vmt" );
resource.AddFile( "materials/models/police/metroc08_sheet.vtf" );
resource.AddFile( "materials/models/police/metroc08sheetn.vtf" );
resource.AddFile( "materials/models/combine_soldier/city08soldiersheet.vtf" );
resource.AddFile( "materials/models/combine_soldier/city08soldiersheet.vmt" );
resource.AddFile( "materials/models/combine_soldier/city08soldiersheetn.vtf" );
resource.AddFile( "materials/models/combine_soldier/combine_eowc8.vtf" );
resource.AddFile( "materials/models/combine_soldier/combine_hexc8.vmt" );
resource.AddFile( "materials/models/combine_soldier/combine_hexc8_normal.vtf" );





resource.AddFile( "models/c08coptrench.mdl" );
resource.AddFile( "models/c08coptrench.vvd" );
resource.AddFile( "models/c08coptrench.phy" );
resource.AddFile( "models/c08coptrench.sw.vtx" );
resource.AddFile( "models/c08coptrench.dx80.vtx" );
resource.AddFile( "models/c08coptrench.dx90.vtx" );
resource.AddFile( "models/c08cop_female.dx80.vtx" );
resource.AddFile( "models/c08cop_female.dx90.vtx" );
resource.AddFile( "models/c08cop_female.mdl" );
resource.AddFile( "models/c08cop_female.phy" );
resource.AddFile( "models/c08cop_female.sw.vtx" );
resource.AddFile( "models/c08cop_female.vvd" );
resource.AddFile( "models/c08cop.dx80.vtx" );
resource.AddFile( "models/c08cop.dx90.vtx" );
resource.AddFile( "models/c08cop.mdl" );
resource.AddFile( "models/c08cop.phy" );
resource.AddFile( "models/c08cop.sw.vtx" );
resource.AddFile( "models/c08cop.vvd" );
resource.AddFile( "models/c08sql.dx80.vtx" );
resource.AddFile( "models/c08sql.dx90.vtx" );
resource.AddFile( "models/c08sql.mdl" );
resource.AddFile( "models/c08sql.phy" );
resource.AddFile( "models/c08sql.sw.vtx" );
resource.AddFile( "models/c08sql.vvd" );
resource.AddFile( "models/eliteshockcp.dx80.vtx" );
resource.AddFile( "models/eliteshockcp.dx90.vtx" );
resource.AddFile( "models/eliteshockcp.mdl" );
resource.AddFile( "models/eliteshockcp.phy" );
resource.AddFile( "models/eliteshockcp.sw.vtx" );
resource.AddFile( "models/eliteshockcp.vvd" );
resource.AddFile( "models/combine_bacon_soldier.dx80.vtx" );
resource.AddFile( "models/combine_bacon_soldier.dx90.vtx" );
resource.AddFile( "models/combine_bacon_soldier.mdl" );
resource.AddFile( "models/combine_bacon_soldier.phy" );
resource.AddFile( "models/combine_bacon_soldier.sw.vtx" );
resource.AddFile( "models/combine_bacon_soldier.vvd" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.dx80.vtx" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.dx90.vtx" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.mdl" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.phy" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.sw.vtx" );
resource.AddFile( "models/jbarnes/soldiers/city08soldier.vvd" );
--resource.AddFile( "models/leet_police2.mdl" );
--resource.AddFile( "models/leet_police2.phy" );
--resource.AddFile( "models/leet_police2.vvd" );
--resource.AddFile( "models/leet_police2.sw.vtx" );
--resource.AddFile( "models/leet_police2.dx90" );
--resource.AddFile( "models/leet_police2.dx80" );


resource.AddFile( "materials/models/cc/combinesoldiersheet.vmt" );
resource.AddFile( "materials/models/cc/combinesoldiersheet_trench.vtf" );
resource.AddFile( "materials/models/cc/t_arctic.vmt" );
resource.AddFile( "materials/models/cc/t_arctic_trench.vtf" );
resource.AddFile( "models/urbantrenchcoat.mdl" );
resource.AddFile( "models/urbantrenchcoat.vvd" );
resource.AddFile( "models/urbantrenchcoat.phy" );
resource.AddFile( "models/urbantrenchcoat.sw.vtx" );
resource.AddFile( "models/urbantrenchcoat.dx80.vtx" );
resource.AddFile( "models/urbantrenchcoat.dx90.vtx" );


resource.AddFile( "models/weapons/v_fists.mdl" );
resource.AddFile( "models/weapons/v_fists.sw.vtx" );
resource.AddFile( "models/weapons/v_fists.vvd" );
resource.AddFile( "models/weapons/v_fists.dx90.vtx" );
resource.AddFile( "models/weapons/v_fists.dx80.vtx" );
resource.AddFile( "models/weapons/w_fists.mdl" );
resource.AddFile( "models/weapons/w_fists.sw.vtx" );
resource.AddFile( "models/weapons/w_fists.vvd" );
resource.AddFile( "models/weapons/w_fists.dx90.vtx" );
resource.AddFile( "models/weapons/w_fists.dx80.vtx" );


resource.AddFile( "models/weapons/v_stunstick.dx80.vtx" );
resource.AddFile( "models/weapons/v_stunstick.dx90.vtx" );
resource.AddFile( "models/weapons/v_stunstick.mdl" );
resource.AddFile( "models/weapons/v_stunstick.sw.vtx" );
resource.AddFile( "models/weapons/v_stunstick.vvd" );

resource.AddFile( "models/weapons/w_venicase_passenger.phy" );
resource.AddFile( "models/weapons/w_venicase_passenger.mdl" );
resource.AddFile( "models/weapons/w_venicase_passenger.vvd" );
resource.AddFile( "models/weapons/w_venicase_passenger.xbox.vtx" );
resource.AddFile( "models/weapons/w_venicase_passenger.sw.vtx" );
resource.AddFile( "models/weapons/w_venicase_passenger.dx80.vtx" );
resource.AddFile( "models/weapons/w_venicase_passenger.dx90.vtx" );

