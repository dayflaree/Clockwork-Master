----------------------------
-- TacoScript (March 23, 2007)
-- by Rick Darkaliono
--
-- First beta - June 1, 2007
-- Second beta - July 2, 2007
-- Completion - March 8, 2008
----------------------------

-- Good luck to whoever reads this line of text, and may the scripting prosper.
-- -Rick (March 08 2008)

-- Bone Scale Example:
-- local Bone = ent:FindNearestBone( Pos );
-- local VarName = "InflateSize"..Bone
-- ent:SetNetworkedInt( VarName, NewSize )
-- Min: -10
-- Max: 50

--CHANGELOGS--

--26 July 2009--
-- Started the view biography - rp_viewbiography, need to get the Entity's (targets) bio label/info.Bio to display

--25 July 2009--
-- Redid the Biography PlayerMenu tab
-- Removed the Business Name and Job Title shit
-- Script bans are now done in special_chars, TJA list
-- Fixed Light BlackMarket flag glitch

--24 July 2009--
-- Added LOLScript disabler
-- Redone the CP Model Changer so it uses TacoFrame
-- Fixed rp_combineroster and rp_checkflags
-- Workshop fully removed (some bits remained)
-- Fixed scrollbar and titlebar glitches
-- Cleaned up the HUD
-- Fixed the slow movement after jump + crouching

--July 11 2009--
-- Removed more unneeded coding
-- Updated the HUD again
-- Fixed the F4 menu
-- Controllable scanner added by Suicide Bomber (rp_scanner)

--June 29 2009--
-- Updated the HUD and stat bars
-- Removed sneak stat as it was useless
-- Fixed and cleaned up some coding
-- Citizen patdown added
-- Added feature that prevents unconscious people spawning props
-- Light Blackmarket added
-- CP Model Changer added
-- Removed rp_headbob on Dave's request

--January 16
-- Updated the script to work with the new GMod update...

--July 25--
-- Finished majority of new weapons menu

--July 24--
-- Rewrote target info HUD
-- Enabled door knocking
-- Prevented players from getting "decimal money"
-- Added rp_admintitle command (Rick only)
-- Perma bans are now done both by SteamID AND IP address 

--Later July 24--
-- Fixed door HUD error

--July 9--
-- Fixed players bypassing the sbox_maxprops limit
-- Added rp_propspawning toggle command
-- Added rp_maxttprops (how many props TTers can spawn), tooltrusted players by default can spawn more then non-tooltrusted
-- Lowered stat raising rate for strength
-- Added Stats to help menu
-- You could listen in on radio even if you don't have one
-- Hopefully fixed Combine radio thing

--July 7--
-- Enabled letters/weapons saving
-- Only TS weapons save
-- Backup loading fixed
-- Speed, sprint stat-raising rate lowered
-- Raised black market prices (even higher)
-- Medic stat raising
-- Sneak stat raising
-- Began adding workshop functionality to items

--July 5--
-- Fixed letter appearing to everyone
-- SWEP spawning is super admin only
-- Disabled weapon saving/loading
-- Giving Tooltrust is super admin only
-- Disabled letter item saving/loading


--[[
playerz = { }

playerz["ConsoleCommandRick"] = game["ConsoleCommand"];

game["ConsoleCommand"] = nil;
]]--
include( "NPCAnims.lua" );

DeriveGamemode( "sandbox" );

TACOSCRIPT_RUNNING = true;
TS = { }

NPC_ANIMS_ENABLED = true;

--TS_DEBUG_MODE = true;

require( "mysql" );

--Mysql safe guard
if( not mysql ) then

	MYSQL_DED = true;
	
	mysql = { }
	
	mysql.connect = function() return 1; end
	mysql.disconnect = function() end
	mysql.query = function() return { }; end
	mysql.escape = function( sql, str ) return str; end

end

TS.GlobalInts = { }
TS.GlobalStrings = { }
TS.GlobalFloats = { }

function SetGlobalInt( key, val )

	TS.GlobalInts[key] = val;
	
	umsg.Start( "SetGlobalInt" );
		umsg.String( key );
		umsg.Long( val );
	umsg.End();

end

function SetGlobalFloat( key, val )

	TS.GlobalFloats[key] = val;

	umsg.Start( "SetGlobalFloat" );
		umsg.String( key );
		umsg.Float( val );
	umsg.End();

end

function SetGlobalString( key, val )

	TS.GlobalStrings[key] = val;
	
	umsg.Start( "SetGlobalString" );
		umsg.String( key );
		umsg.String( val );
	umsg.End();

end


function GetGlobalInt( var )

	return TS.GlobalInts[var];

end

function GetGlobalFloat( var )

	return TS.GlobalFloats[var];

end

function GetGlobalString( var )

	return TS.GlobalStrings[var];

end

TS.Models = {

	          "models/Humans/Group01/Male_01.mdl",
              "models/Humans/Group01/male_02.mdl",
              "models/Humans/Group01/male_03.mdl",
              "models/Humans/Group01/Male_04.mdl",
              "models/Humans/Group01/Male_05.mdl",
              "models/Humans/Group01/male_06.mdl",
              "models/Humans/Group01/male_07.mdl",
              "models/Humans/Group01/male_08.mdl",
              "models/Humans/Group01/male_09.mdl",
              "models/Humans/Group02/Male_01.mdl",
              "models/Humans/Group02/male_02.mdl",
              "models/Humans/Group02/male_03.mdl",
              "models/Humans/Group02/Male_04.mdl",
              "models/Humans/Group02/Male_05.mdl",
              "models/Humans/Group02/male_06.mdl",
              "models/Humans/Group02/male_07.mdl",
              "models/Humans/Group02/male_08.mdl",
              "models/Humans/Group02/male_09.mdl",

              "models/Humans/Group01/Female_01.mdl",
              "models/Humans/Group01/Female_02.mdl",
              "models/Humans/Group01/Female_03.mdl",
              "models/Humans/Group01/Female_04.mdl",
              "models/Humans/Group01/Female_06.mdl",
              "models/Humans/Group01/Female_07.mdl",
              "models/Humans/Group02/Female_01.mdl",
              "models/Humans/Group02/Female_02.mdl",
              "models/Humans/Group02/Female_03.mdl",
              "models/Humans/Group02/Female_04.mdl",
              "models/Humans/Group02/Female_06.mdl",
              "models/Humans/Group02/Female_07.mdl",
}



AddCSLuaFile( "cl_init.lua" );
AddCSLuaFile( "cl_hud.lua" );
AddCSLuaFile( "cl_render.lua" );
AddCSLuaFile( "cl_fade.lua" );
AddCSLuaFile( "cl_view.lua" );
AddCSLuaFile( "cl_notify.lua" );
AddCSLuaFile( "cl_target.lua" );
AddCSLuaFile( "shared.lua" );
AddCSLuaFile( "entity.lua" );
AddCSLuaFile( "cl_inventory.lua" );
AddCSLuaFile( "cl_playermenu.lua" );
AddCSLuaFile( "cl_think.lua" );
AddCSLuaFile( "cl_alterchat.lua" );
AddCSLuaFile( "cl_help.lua" );
AddCSLuaFile( "cl_scoreboard.lua" );
AddCSLuaFile( "cl_charactercreate.lua" );
AddCSLuaFile( "cl_letters.lua" );
AddCSLuaFile( "cl_actionmenu.lua" );
AddCSLuaFile( "cl_weaponslotmenu.lua" );
AddCSLuaFile( "cl_accountcreation.lua" );
AddCSLuaFile( "cl_rostermenu.lua" );
AddCSLuaFile( "cl_quiz.lua" );
AddCSLuaFile( "cl_processbar.lua" );
AddCSLuaFile( "cl_chatbox.lua" );

AddCSLuaFile( "tacovgui/cl_panel.lua" );
AddCSLuaFile( "tacovgui/cl_button.lua" );
AddCSLuaFile( "tacovgui/cl_button2.lua" );
AddCSLuaFile( "tacovgui/cl_closebutton.lua" );
AddCSLuaFile( "tacovgui/cl_titlelabel.lua" );
AddCSLuaFile( "tacovgui/cl_body.lua" );
AddCSLuaFile( "tacovgui/cl_scroll.lua" );
AddCSLuaFile( "tacovgui/cl_tacoentry.lua" );
AddCSLuaFile( "tacovgui/cl_tacoframe.lua" );
AddCSLuaFile( "tacovgui/cl_link.lua" );

AddCSLuaFile( "player_shared.lua" );

include( "admin.lua" );
include( "parse.lua" );
include( "concmd.lua" );
include( "player_shared.lua" );
include( "server_vars.lua" );
include( "player_server.lua" );
include( "player_hooks.lua" );
include( "player_stats.lua" );
include( "player_dmg.lua" );
include( "util.lua" );
include( "entity.lua" );
include( "combine_sounds.lua" );
include( "chat.lua" );
include( "rp_chat.lua" );
include( "shared.lua" );
include( "player_doorownership.lua" );
include( "player_status.lua" );
include( "server_events.lua" );
include( "special_chars.lua" );
include( "admin_cc.lua" );
include( "server_util.lua" );
include( "player_sqldata.lua" );
include( "player_anims.lua" );
include( "player_actionmenu.lua" );
include( "resources.lua" );
include( "custom_spawnpoints.lua" );
include( "rp_tooltrust.lua" );
include( "item_concmd.lua" );
include( "player_vars.lua" );
include( "c_scanner.lua");

--game.ConsoleCommand( "lua_networkvar_bytespertick 64\n" );

LAG_TEST = false;

SAVE_VERSION = 1;

TS.QuizFailers = { }

--TS.Port = "27015";

local function FillRebelWeaponry()

	SetGlobalInt( "RebelWeaponry", math.Clamp( GetGlobalInt( "RebelWeaponry" ) + 33.333334, 1, 100 ) );

end
timer.Create( "FillRebelWeaponry", 600, 0, FillRebelWeaponry );

SetGlobalInt( "RebelWeaponry", 100 );

--Is there properties? (or just door owning)
SetGlobalInt( "PropertyPaying", 1 );

--Both functions are called 2 seconds after initial map load (for good reason too)
timer.Simple( 2, TS.CreateThirdPersonCamera );

if( GetGlobalInt( "PropertyPaying" ) == 1 ) then
	timer.Simple( 2, TS.CreateDoorInfo );
end

TS.LastSQLReconnect = 0;

function SQLReconnect()

	TS.CheckSQLStatus();

end
timer.Create( "SQLReconnect", 30, 0, SQLReconnect );

TS.LoadMapData();

TS.ConnectToSQL();

--TS.ClearActiveList();

TS.LoadCIDs();

TS.LoadPhysgunBans();

--Open all the item scripts
TS.ParseItems();

--Load teams
TS.ParseTeams();

--Load tooltrust
--TS.LoadToolTrust();

--Load Combine Roster
--TS.LoadCombineRoster();

--Load Misc Flags
--TS.LoadMiscFlags();

--Load admin flags
--TS.LoadAdminFlags();

TS.PropLogs = { }
TS.ToolLogs = { }
TS.PreID = "STEAM_0:1:";

--Load economy money amount
SetGlobalFloat( "EconomyMoney", tonumber( file.Read( "TacoScript/data/economymoney.txt" ) or 0 ) );

SetGlobalInt( "CombineRations", 20 );

function GiveRations()

	if( GetGlobalInt( "CombineRations" ) < 20 ) then
	
		SetGlobalInt( "CombineRations", 20 );
		
		for k, v in pairs( player.GetAll() ) do
		
			if( v:IsCombineDefense() ) then
				v:PrintMessage( 3, "Citizen rations have arrived" );
			end
			
		end
	
	end

end
timer.Create( "GiveRations", 600, 0, GiveRations );

local function PeriodicSave()
	
	local function PlySave( ply )
	
		if( ply:IsValid() and ply:GetTable().SaveLoaded ) then
		
			ply:SaveItems();
			ply:SaveCharacter();
			
		end
	
	end
	
	local num = 0;
	
	for k, v in pairs( player.GetAll() ) do
	
		timer.Simple( num, PlySave, v );
		num = num + 2;
	
	end
	
	TS.PrintMessageAll( 2, "Now Saving Characters" );
	
end
timer.Create( "PeriodicSave", 180, 0, PeriodicSave );

local function GenerateCombineRadio()

	math.randomseed(os.time());	
		
	TS.CombineRadioFreq = 0;
		
	TS.CombineRadioFreq = tonumber( math.random( 100, 850 ) .. "." .. math.random( 0, 9 ) );
	
end

timer.Simple( 5, GenerateCombineRadio );

if( ScriptBusinessID ) then

	for n = 1, ScriptBusinessID do
		
		for j = 1, TS.GetBusinessInt( n, "itemcount" ) do
		
			TS.SetBusinessString( n, "item." .. j .. ".name", "" );
		
		end
		
		TS.SetBusinessInt( n, "itemcount", 0 )
	
	end

end

ScriptBusinessID = 0;

GM.Name = "TacoScript - Complete, Bitch -";

function GM:Initialize()

	self.BaseClass:Initialize();

end

local function SQLCheck()

	TS.CheckSQLStatus();
	
end
--timer.Create( "SQLCheck", 90, 0, SQLCheck );

timer.Create( "DonateCheck", 300, 0, TS.DoRealTimeDonation );

local function F1Reminder()

	TS.NotifyAll( "Press F1 for help", 5 );

end
timer.Create( "F1Reminder", 300, 0, F1Reminder );

local function CreateSessionID()

	TS.CrntSessionID = math.random( 1, 255 );

end
timer.Simple( 3, CreateSessionID );

local function DestroyAllOldOwnerships()

	sql.Query( "DELETE FROM `tb_doors` WHERE `SessionID` != '" .. TS.CrntSessionID .. "'" );

end
timer.Simple( 720, DestroyAllOldOwnerships );

--Initialize any active players on gamemode reload
for k, v in pairs( player.GetAll() ) do

	if( v:GetField( "isko" ) == 1 ) then
		v:GoConscious();
	end

	GAMEMODE:PlayerInitialSpawn( v );

end

function GM:ShowHelp( ply )

	umsg.Start( "ShowHelpMenu", ply ); umsg.End();

end

--Fixes for gm_showspare because F3 and F4 are binded to "gm_share1" and "gm_spare2" for
--whatever reason..
function ShowSpare1Fix( ply )

	ply:ConCommand( "gm_showspare1\n" );

end
concommand.Add( "gm_spare1", ShowSpare1Fix );

function ShowSpare2Fix( ply )

	ply:ConCommand( "gm_showspare2\n" );

end
concommand.Add( "gm_spare2", ShowSpare2Fix );

TS.DebugFile( "Server start" );


local function SpawnProp( ply, cmd, arg )

	if( not string.find( arg[1], "maps/" ) and not string.find( arg[1], ".bsp" ) ) then
	
		CCSpawn( ply, cmd, arg );
	
	else
	
		TS.Log( "jetboomhax.txt", ply:LogInfo() .. " tried to hax" );
	
	end

end
concommand.Add( "gm_spawn", SpawnProp );

concommand.Add( "impulse", function() end );

function GM:PlayerSpray( ply )

	if( not ply:IsAdmin() or ply:IsSuperAdmin() or ply:HasItem( "spraycan" ) ) then
	
		return false;
		
	end

end