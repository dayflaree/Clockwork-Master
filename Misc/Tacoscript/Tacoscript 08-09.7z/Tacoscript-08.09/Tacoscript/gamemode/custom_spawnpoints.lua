
-- Might as well hard code it.

CustomSpawnPoints = { }
CustomCPSpawnPoints = { }

local function AddSpawnPoint( map, pos, ang, cp )

	if( not cp ) then

		if( not CustomSpawnPoints[map] ) then
		
			CustomSpawnPoints[map] = { }
		
		end
		
	else
	
		if( not CustomCPSpawnPoints[map] ) then
		
			CustomCPSpawnPoints[map] = { }
		
		end	
	
	end
	
	local sp = { }
	sp.Pos = pos;
	sp.Ang = ang;
	
	if( not cp ) then
		table.insert( CustomSpawnPoints[map], sp );
	else
		table.insert( CustomCPSpawnPoints[map], sp );
	end

end

AddSpawnPoint( "rp_c18_v1", Vector( 1350.0252685547, 816.03125, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1356.4797363281, 940.02874755859, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1364.0885009766, 1086.2012939453, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1369.6772460938, 1193.5651855469, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1434.3415527344, 877.03863525391, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1441.0847167969, 1006.5814208984, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1446.9621582031, 1119.4906005859, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1451.3967285156, 1204.6800537109, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1542.2143554688, 980.4208984375, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1547.2260742188, 1076.703125, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_c18_v1", Vector( 1551.6606445313, 1161.8969726563, 512.03125 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( -126, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( -80, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( -50, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( -20, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( 10, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );
AddSpawnPoint( "rp_salvation", Vector( 80, 4742, -44 ), 
Angle( 4.5000243186951, 87.019859313965, 0 ), true );

AddSpawnPoint( "rp_destroyedcity_final", Vector( -1320 , -15171, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1375 , -15171, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1410 , -15171, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1470 , -15171, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1500 , -15171, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1500 , -15088, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1320 , -15088, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1375 , -15088, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1410 , -15088, -333 ), 
Angle( 0, 0, 0 ), true );
AddSpawnPoint( "rp_destroyedcity_final", Vector( -1470 , -15088, -333 ), 
Angle( 0, 0, 0 ), true );