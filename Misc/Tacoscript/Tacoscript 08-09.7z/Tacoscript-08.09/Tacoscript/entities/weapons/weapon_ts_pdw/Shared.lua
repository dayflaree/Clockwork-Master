
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "smg";

end

if( CLIENT ) then

	SWEP.PrintName = "Custom MP7 PDW";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_SMG1.Single" );

SWEP.WorldModel = "models/weapons/w_smg1.mdl";
SWEP.ViewModel = "models/weapons/v_smg3.mdl";

SWEP.Primary.ClipSize = 45;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .06;
SWEP.Primary.Damage = 5;
SWEP.Primary.Force = 2;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .047, .047, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(-5.4157, 2.3729, -10.5088);
SWEP.IronSightAng = Vector( 0.0, 0.0, 0.0 );

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_pdw" )

	end
end
hook.Add( "PlayerDeath", "pdwdeath", weaponremove )