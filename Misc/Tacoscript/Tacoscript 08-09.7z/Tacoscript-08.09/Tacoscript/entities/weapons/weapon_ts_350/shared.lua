

if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "44 Magnum";
	SWEP.Slot = 2;
	SWEP.SlotPos = 3;
	SWEP.ViewModelFlip		= false	
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 50	
	
	SWEP.DrawCrosshair = false;
	
end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModel		= "models/weapons/v_350.mdl"
SWEP.WorldModel		= "models/weapons/w_351.mdl"
SWEP.Primary.Sound			= Sound("Weapon_357.Single")

SWEP.InvSize = 1;
SWEP.InvWeight = 0.5;

SWEP.Primary.ClipSize = 6;
SWEP.Primary.DefaultClip = 24;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .3;
SWEP.Primary.Damage = 15;
SWEP.Primary.Force = 20;
SWEP.Primary.RunCone = Vector( .05, .05, 0 );
SWEP.Primary.SpreadCone = Vector( .035, .035, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = false;


SWEP.IronSightPos 		= Vector( -5.6821, 2.8822, -7.1308 )
SWEP.IronSightAng 		= Vector( 0 , 0 , 0 )

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_350" )

	end
end
hook.Add( "PlayerDeath", "350death", weaponremove )
