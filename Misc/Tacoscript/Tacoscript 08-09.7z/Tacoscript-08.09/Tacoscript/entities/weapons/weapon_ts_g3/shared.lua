
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";
	SWEP.FOVAmt = 70;
	SWEP.NoDrawOnIronSights = true;

end

SWEP.PrintName = "HK G3 Rifle";

if( CLIENT ) then

	
	SWEP.Slot = 3;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFlip		= true
	SWEP.CSMuzzleFlashes	= true
	SWEP.MuzzleEffect		= "rg_muzzle_cmb"
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.InvSize = 1;
SWEP.InvWeight = 2;

SWEP.Primary.Sound = Sound( "Weapon_sg550.Single" );

SWEP.WorldModel = "models/weapons/w_snip_g3sg1.mdl";
SWEP.ViewModel = "models/weapons/v_snip_g3sg1.mdl";

SWEP.Primary.ClipSize = 20;
SWEP.Primary.DefaultClip = 40;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .18;
SWEP.Primary.Damage = 20;
SWEP.Primary.Force = 2;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .015, .015, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -10, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.ReloadAtEnd = true;

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = 0.5;

SWEP.AimSway = true;
SWEP.SwayCone = Vector( .1, .1, 0 );

SWEP.IronSightPos = Vector( -6.4, 2.5, -9.0 );
SWEP.IronSightAng = Vector( 0.0, 0.0, 0.0 );

SWEP.IronSightSound = Sound( "weapons/sniper/sniper_zoomin.wav" );

SWEP.Volume = 80;

if( CLIENT ) then
	SWEP.Mat = Material( "models/weapons/msg-90/vscope" );
end

function SWEP:DrawHUD()
	
	if( self.Weapon:GetNWBool( "ironsights" ) ) then

		surface.SetDrawColor( 0, 0, 0, 255 );
		
		surface.SetMaterial( self.Mat );
		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() );

	end

end



function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_g3" )

	end
end
hook.Add( "PlayerDeath", "g3death", weaponremove )