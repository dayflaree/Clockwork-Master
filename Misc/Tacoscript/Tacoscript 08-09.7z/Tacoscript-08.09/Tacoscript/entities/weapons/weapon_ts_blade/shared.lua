

if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "Mac 19";
	SWEP.Slot = 1;
	SWEP.SlotPos = 3;
	SWEP.ViewModelFlip		= true	
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 83	
	
	SWEP.DrawCrosshair = false;
	
end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModel			= "models/weapons/v_blade_m11.mdl"
SWEP.WorldModel			= "models/weapons/w_blade_m11.mdl"
SWEP.Primary.Sound			= Sound("weapons/lrshot.wav")

SWEP.InvSize = 1;
SWEP.InvWeight = 0.5;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 120;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .06;
SWEP.Primary.Damage = 7;
SWEP.Primary.Force = 2;
SWEP.Primary.RunCone = Vector( .05, .05, 0 );
SWEP.Primary.SpreadCone = Vector( .045, .045, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .04, .04, 0 );
SWEP.Primary.ViewPunch = Angle( -0.5, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(3.4577, 2.592, -3.1343);
SWEP.IronSightAng = Vector(0 , 0, 0);


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_blade" )

	end
end
hook.Add( "PlayerDeath", "bladedeath", weaponremove )