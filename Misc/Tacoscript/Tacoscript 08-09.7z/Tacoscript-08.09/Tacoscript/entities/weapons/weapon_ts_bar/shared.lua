
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "shotgun";

	
	
end

SWEP.PrintName = "BAR";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 60;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3.5;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "Weapon_sg552.Single" );

SWEP.WorldModel = "models/weapons/w_browningbar.mdl";
SWEP.ViewModel = "models/weapons/v_ba1.mdl";


SWEP.Primary.ClipSize = 20;
SWEP.Primary.DefaultClip = 100;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .12;
SWEP.Primary.Damage = 12;
SWEP.Primary.Force = 3;
SWEP.Primary.RunCone = Vector( 0.04, 0.04, 0 );
SWEP.Primary.SpreadCone = Vector( .035, .035, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .02, .02, 0 );
SWEP.Primary.ViewPunch = Angle( -1, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector( -6.4066, 5.1763, -3.8825 );
SWEP.IronSightAng = Vector( 0, 0, 0 );

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = 0.1;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_bar" )

	end
end
hook.Add( "PlayerDeath", "bardeath", weaponremove )
