

if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "Resistance M93R";
	SWEP.Slot = 1;
	SWEP.SlotPos = 3;
	SWEP.ViewModelFlip		= true	
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 83	
	
	SWEP.DrawCrosshair = false;
	
end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModel			= "models/weapons/v_pist_alyxgun.mdl"
SWEP.WorldModel			= "models/weapons/w_alyx_gun.mdl"
SWEP.Primary.Sound			= Sound("Weapon_p228.Single")

SWEP.InvSize = 1;
SWEP.InvWeight = 0.5;

SWEP.Primary.ClipSize = 20;
SWEP.Primary.DefaultClip = 60;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .1;
SWEP.Primary.Damage = 6;
SWEP.Primary.Force = 2;
SWEP.Primary.RunCone = Vector( .05, .05, 0 );
SWEP.Primary.SpreadCone = Vector( .045, .045, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .04, .04, 0 );
SWEP.Primary.ViewPunch = Angle( -0.5, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(3.8529, 1.5211, -0.4732);
SWEP.IronSightAng = Vector(4.7989, -1.3847, -1.3891);


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_m93r" )

	end
end
hook.Add( "PlayerDeath", "m93rdeath", weaponremove )
