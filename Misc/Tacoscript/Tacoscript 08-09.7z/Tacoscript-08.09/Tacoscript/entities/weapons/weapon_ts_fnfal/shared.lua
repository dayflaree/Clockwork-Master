
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

	
	
end

SWEP.PrintName = "FN-FAL";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 60;
	SWEP.ViewModelFlip		= false	
	SWEP.CSMuzzleFlashes	= true
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3.5;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "Weapon_sg550.Single" );

SWEP.WorldModel = "models/weapons/w_rif_fnfal.mdl";
SWEP.ViewModel = "models/weapons/v_rif_fnfal.mdl";

SWEP.Primary.ClipSize = 20;
SWEP.Primary.DefaultClip = 80;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .12;
SWEP.Primary.Damage = 18;
SWEP.Primary.Force = 4;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector( -3.1657, 1.2841, -4.2601 );
SWEP.IronSightAng = Vector( 0 , 0 , 0 );



SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .02, .02, .02 ); 
SWEP.StraySpeed = .7;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_fnfal" )

	end
end
hook.Add( "PlayerDeath", "faldeath", weaponremove )