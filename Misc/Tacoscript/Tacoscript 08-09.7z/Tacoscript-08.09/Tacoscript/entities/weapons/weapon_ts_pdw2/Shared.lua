
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "MP7 PDW Spec-ops";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
        SWEP.ViewModelFlip = true;
	SWEP.DrawCrosshair = false;
	SWEP.ViewModelFOV	= 80;
        SWEP.CSMuzzleFlashes = true;

end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_TMP.Single" );

SWEP.WorldModel = "models/weapons/w_mp7_specops.mdl";
SWEP.ViewModel = "models/weapons/v_smg_tma.mdl";

SWEP.Primary.ClipSize = 45;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .06;
SWEP.Primary.Damage = 5;
SWEP.Primary.Force = 2;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .047, .047, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(5.1696, 1.0159, -2.1185);
SWEP.IronSightAng = Vector(0, 0, 0);

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_pdw2" )

	end
end
hook.Add( "PlayerDeath", "pdw2death", weaponremove )