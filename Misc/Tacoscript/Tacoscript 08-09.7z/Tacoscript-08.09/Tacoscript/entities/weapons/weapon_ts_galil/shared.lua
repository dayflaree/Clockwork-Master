
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

	
	
end

SWEP.PrintName = "Israeli Galil Rifle";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 60;
	SWEP.ViewModelFlip		= false	
	SWEP.CSMuzzleFlashes	= true
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3.5;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "Weapon_galil.Single" );

SWEP.WorldModel = "models/weapons/w_rif_galil.mdl";
SWEP.ViewModel = "models/weapons/v_rif_galil.mdl";

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .14;
SWEP.Primary.Damage = 12;
SWEP.Primary.Force = 5;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .025, .025, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -0.6, 0.2, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(-5.1383, 2.2242, -8.8488);
SWEP.IronSightAng = Vector(0.0724, 0, 0.1386);

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = .7;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_galil" )

	end
end
hook.Add( "PlayerDeath", "galildeath", weaponremove )