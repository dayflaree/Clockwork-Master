if( SERVER ) then
 
	AddCSLuaFile( "shared.lua" );
 
	SWEP.HoldType = "pistol";
 
end
  
if( CLIENT ) then
 
	SWEP.PrintName = "Silenced USP";
	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	
	SWEP.ViewModelFOV = 83	
	SWEP.ViewModelFlip	= true	
	SWEP.CSMuzzleFlashes = true
 
	SWEP.DrawCrosshair = false;
 
end
 
SWEP.Base = "weapon_ts_base";

SWEP.WorldModel = "models/weapons/w_pist_usp.mdl";
SWEP.ViewModel = "models/weapons/v_pist_usp.mdl";
 
SWEP.Primary.Sound = Sound( "Weapon_USP.SilencedShot" );
 
SWEP.ViewModelFOV = 83	
 
SWEP.InvSize = 2;
SWEP.InvWeight = 1;
 
SWEP.Primary.ClipSize = 12;
SWEP.Primary.DefaultClip = 32;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .2;
SWEP.Primary.Damage = 9;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( .1, .1, 0 );
SWEP.Primary.SpreadCone = Vector( .05, .05, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -1, 0, 0 );

SWEP.Primary.Automatic = false;

SWEP.IronSightPos = Vector (4.5203, 2.4797, 2.7541);
SWEP.IronSightAng = Vector (2.0, 0.0, 0.0);

SWEP.HolsterPos = Vector( 0, 0, 0 );
SWEP.HolsterAng = Vector( -2, 0, 0 );

SWEP.IsSilenced = true;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_spistol" )
 
	end
end
hook.Add( "PlayerDeath", "spistoldeath", weaponremove )