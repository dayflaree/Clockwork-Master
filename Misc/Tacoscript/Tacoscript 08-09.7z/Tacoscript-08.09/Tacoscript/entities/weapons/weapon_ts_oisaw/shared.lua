
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "shotgun";

	
	
end

if( CLIENT ) then

	SWEP.PrintName = "AR3 / OISAW";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 60;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 4;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "npc/strider/strider_minigun.wav" );

SWEP.WorldModel = "models/weapons/w_srifle.mdl";
SWEP.ViewModel = "models/weapons/v_srifle.mdl";

SWEP.Primary.ClipSize = 60;
SWEP.Primary.DefaultClip = 300;
SWEP.Primary.Ammo = "ar2";
SWEP.Primary.Delay = .06;
SWEP.Primary.Damage = 15;
SWEP.Primary.Force = 10;
SWEP.Primary.RunCone = Vector( 0.02, 0.02, 0 );
SWEP.Primary.SpreadCone = Vector( 0.08, 0.08, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( 0.03, 0.03, 0 );
SWEP.Primary.ViewPunch = Angle( -1, 0.0, 1 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(-5.1625, 1.4744, -11.1282);
SWEP.IronSightAng = Vector(-0.4867, -0.6123, -11.0532);

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( -4, .02, .02 ); 
SWEP.StraySpeed = 0.5;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_oisaw" )

	end
end
hook.Add( "PlayerDeath", "oisawdeath", weaponremove )
