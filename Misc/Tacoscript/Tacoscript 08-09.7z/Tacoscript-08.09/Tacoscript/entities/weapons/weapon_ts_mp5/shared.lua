
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "smg";

end

SWEP.PrintName = "MP5";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.CSMuzzleFlashes	= true;
	SWEP.ViewModelFlip		= true;	
	SWEP.ViewModelFOV		= 60;	
	
	SWEP.DrawCrosshair = false;
	
end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModel			= "models/weapons/v_smg_mp5.mdl"
SWEP.WorldModel			= "models/weapons/w_smg_mp5.mdl"
SWEP.Primary.Sound			= Sound( "Weapon_MP5Navy.Single" )

SWEP.ViewModelFOV		= 65;

SWEP.InvSize = 2;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 60;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .085;
SWEP.Primary.Damage = 6;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .04, .04, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .02, .02, 0 );
SWEP.Primary.ViewPunch = Angle( -0.5, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos   = Vector(4.748, 1.8997, -6.8103);
SWEP.IronSightAng   = Vector(1.3693, 0, -0.0779);

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = .3;


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_mp5" )

	end
end
hook.Add( "PlayerDeath", "mp5kdeath", weaponremove )