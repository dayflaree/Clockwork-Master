
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

end

SWEP.PrintName = "M4 RIS Rifle";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.CSMuzzleFlashes	= true;
	SWEP.ViewModelFOV		= 50;
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_famas.Single" );

SWEP.ViewModel		= "models/weapons/v_smg4.mdl";
SWEP.WorldModel		= "models/weapons/w_smg4.mdl";

SWEP.InvSize = 2;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .09;
SWEP.Primary.Damage = 10;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .047, .047, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -1, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector( -4.1842, 1.5686 , -8.1373 );
SWEP.IronSightAng = Vector( 0, 0, 0 );

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .02, .02, .02 ); 
SWEP.StraySpeed = 0.2;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_m4ris" )

	end
end
hook.Add( "PlayerDeath", "m4risdeath", weaponremove )