
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";
	SWEP.FOVAmt = 80;
	SWEP.NoDrawOnIronSights = true;

end

SWEP.PrintName = "CISR-762-T";

if( CLIENT ) then

	
	SWEP.Slot = 3;
	SWEP.SlotPos = 2;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.InvSize = 4;
SWEP.InvWeight = 2.5;

SWEP.Primary.Sound = Sound( "npc/sniper/sniper1.wav" );

SWEP.WorldModel = "models/weapons/w_msg90.mdl";
SWEP.ViewModel = "models/weapons/v_msg90.mdl";

SWEP.Primary.ClipSize = 12;
SWEP.Primary.DefaultClip = 12;
SWEP.Primary.Ammo = "ar2";
SWEP.Primary.Delay = 2.1;
SWEP.Primary.Damage = 0;
SWEP.Primary.Force = 15;
SWEP.Primary.RunCone = Vector( 0.01, 0.01, 0 );
SWEP.Primary.SpreadCone = Vector( 0.002, 0.002, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( 0.001, 0.001, 0 );
SWEP.Primary.ViewPunch = Angle( -1.75, 0.0, 0 );
SWEP.Primary.Automatic = false;

SWEP.AimSway = true;
SWEP.SwayCone = Vector( .1, .1, 0 );

SWEP.IronSightPos = Vector( -6.4, 2.5, -9.0 );
SWEP.IronSightAng = Vector( 0.0, 0.0, 0.0 );

SWEP.IronSightSound = Sound( "weapons/sniper/sniper_zoomin.wav" );

SWEP.Volume = 300;

if( CLIENT ) then
	SWEP.Mat = Material( "models/weapons/msg-90/vscope" );
end

function SWEP:PrimaryAttack()

	if( not self:CanShootPrimary() ) then return; end

	if( self.Weapon:GetNWBool( "ironsights" ) and self.NoIronSightAttack ) then return; end
	if( self.Owner:KeyDown( IN_SPEED ) and self.Owner:GetVelocity():Length() >= 140 ) then return; end

	if( CLIENT ) then
		self.Weapon:EmitSound( self.Primary.Sound );
	else
		self.Weapon:EmitSound( self.Primary.Sound, self.Volume, 100 );
	end
	
	self.Weapon:SetNextPrimaryFire( CurTime() + ( self.Primary.Delay or .5 ) );
	
	self:TakePrimaryAmmo( 1 );
	self:TSShootBullet();

	if( SERVER ) then
    
		local trace = { }
		trace.start = self.Owner:EyePos();
		trace.endpos = trace.start + self.Owner:GetAimVector() * 100000;
		trace.filter = self.Owner;
		
		local tr = util.TraceLine( trace );

     	if( tr.Entity:IsValid() and tr.Entity:IsPlayer() ) then

			local hitgroup = tr.Hitgroup;
			
			--local dmg = math.Clamp( 9000, 9000, 9000 );
			local dmg = 90000
     	
     		if( hitgroup == HITGROUP_HEAD ) then
     			dmg = dmg * 1.7;
     		elseif( hitgroup == HITGROUP_CHEST ) then
     			dmg = dmg * 1.4;
     		elseif( hitgroup == HITGROUP_STOMACH ) then
     			dmg = dmg * 1.2;
     		else
     			dmg = dmg * .9;
     		end
     		
     		tr.Entity:SetNWFloat( "conscious", math.Clamp( tr.Entity:GetNWFloat( "conscious" ) - dmg, 0, 50 ) );
     		tr.Entity:GoUnconscious();
     		
     		local function ApplyRagdollForce( ply, attacker, hitpos )
     		
     			local shootpos = attacker:GetPos() + Vector( 0, 0, 32 );
     			local norm = ( shootpos - hitpos ):Normalize();
     		
     			local ragdoll = ply:GetRagdoll();
     		
     			ragdoll:GetPhysicsObject():ApplyForceOffset( norm * -10000, hitpos );
     		
     		end
     		
     		ApplyRagdollForce( tr.Entity, self.Owner, tr.HitPos );
     		
     		tr.Entity:TempStatBoost( "Endurance", -13, 60 );
     		
     	end

	end

end

function SWEP:DrawHUD()
	
	if( self.Weapon:GetNWBool( "ironsights" ) ) then

		surface.SetDrawColor( 0, 0, 0, 255 );
		
		surface.SetMaterial( self.Mat );
		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() );

	end

end

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_combinesniper" )

	end
end
hook.Add( "PlayerDeath", "combinesdeath", weaponremove )

