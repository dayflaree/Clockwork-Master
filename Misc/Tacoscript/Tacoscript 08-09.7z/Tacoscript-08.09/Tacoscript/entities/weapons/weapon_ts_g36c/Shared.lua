
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

end

SWEP.PrintName = "G36C";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.CSMuzzleFlashes	= true;
	SWEP.ViewModelFlip		= true	
	SWEP.ViewModelFOV		= 50;
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_famas.Single" );

SWEP.ViewModel		= "models/weapons/v_rif_g36c.mdl";
SWEP.WorldModel		= "models/weapons/w_rif_g36f.mdl";

SWEP.InvSize = 2;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 120;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .09;
SWEP.Primary.Damage = 10;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .05, .05, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( -1, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector( 5.9647, 2.0889, -5.2693 );
SWEP.IronSightAng = Vector(-0.8609, 0, -0.2417 );

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = 0.3;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_g36c" )

	end
end
hook.Add( "PlayerDeath", "g36cdeath", weaponremove )