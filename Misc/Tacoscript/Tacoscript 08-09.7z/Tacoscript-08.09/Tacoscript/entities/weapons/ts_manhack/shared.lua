

if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	function Manhack(owner)
local trace = owner:GetEyeTrace()
local hitpos = trace.HitPos 
local hitnormal = trace.HitNormal
	local ent = ents.Create("npc_manhack")
			if ent:IsValid() then
			ent:PhysicsInit( SOLID_VPHYSICS )
			ent:SetSolid( SOLID_VPHYSICS )
			ent:SetPos( hitpos + hitnormal * 32 )
			ent:SetOwner(owner)
			ent:SetKeyValue("spawnflags", "4")
			ent:Spawn()
			if not ent:IsInWorld() then
				ent:Remove()
				return
			end
			for _, pl in pairs(player.GetAll()) do
				if pl:Team() == 1 then
					ent:AddEntityRelationship(pl, D_HT, 99)
				else
					ent:AddEntityRelationship(pl, D_LI, 99)
				end
			end
		end	
	end	

end

SWEP.PrintName = "Manhack";

if( CLIENT ) then

	
	SWEP.Slot = 0;
	SWEP.SlotPos = 1;
	SWEP.DrawAmmo = false;
	SWEP.DrawCrosshair = false;
	SWEP.DrawDotCrosshair = true;

end

// Variables that are used on both client and server

SWEP.Base = "weapon_ts_base";

SWEP.Author			= "Kochheimer"
SWEP.Instructions	= "Left click to release manhack"
SWEP.Contact		= "http://taconbanana.com/forums/"
SWEP.Purpose		= ""
SWEP.NotHolsterAnim = ACT_HL2MP_IDLE;

SWEP.ViewModel = Model( "models/weapons/v_fists.mdl" );
SWEP.WorldModel = Model( "models/weapons/w_fists.mdl" );

SWEP.ViewModelFOV	= 62
SWEP.ViewModelFlip	= false
SWEP.AnimPrefix		= "rpg"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

SWEP.InvSize = 0;
SWEP.InvWeight = 0;
  
  
SWEP.Primary.ClipSize		= 1					// Size of a clip
SWEP.Primary.DefaultClip	= 1				// Default number of bullets in a clip
SWEP.Primary.Automatic		= false				// Automatic/Semi Auto
SWEP.Primary.Ammo			= ""

SWEP.Secondary.ClipSize		= -1				// Size of a clip
SWEP.Secondary.DefaultClip	= 0				// Default number of bullets in a clip
SWEP.Secondary.Automatic	= false				// Automatic/Semi Auto
SWEP.Secondary.Ammo			= ""

// Ironsights not really needed 'cause there aint no pancake mix!
SWEP.IronSightPos = Vector( 0, 6.2, -8.0 );
SWEP.IronSightAng = Vector( -4, 0, 0.0 );
SWEP.NoIronSightFovChange = true;
SWEP.NoIronSightAttack = true;

/*---------------------------------------------------------
   Name: SWEP:Initialize( )
   Desc: Called when the weapon is first loaded
---------------------------------------------------------*/
function SWEP:Initialize()

	if( SERVER ) then
	
		self:SetWeaponHoldType( "ar2" );
	
	end

end


/*---------------------------------------------------------
   Name: SWEP:Precache( )
--   Desc: Use this function to precache stuff
---------------------------------------------------------*/
function SWEP:Precache()
end


/*---------------------------------------------------------
   Name: SWEP:PrimaryAttack( )
   Desc: +attack1 has been pressed
---------------------------------------------------------*/
function SWEP:PrimaryAttack()
if self.Weapon:Clip1( ) > 0 then
timer.Simple(1, Manhack, self.Owner)
	else
end
self.Weapon:SetClip1( 0 )

end
  
function SWEP:SecondaryAttack()
end
  
function SWEP:Think()
end
