if (SERVER) then
AddCSLuaFile ("shared.lua");
SWEP.Weight = 8;
SWEP.AutoSwitchTo = true;
SWEP.AutoSwitchFrom = false;
SWEP.HoldType = "shotgun";
end

if (CLIENT) then
SWEP.PrintName = "M203 Launcher";
SWEP.Slot = 2;
SWEP.SlotPos = 2;
SWEP.DrawAmmo = false;
SWEP.DrawCrosshair = false;
end


SWEP.Primary.ClipSize = 1;
SWEP.Primary.DefaultClip = 4;
SWEP.Primary.Automatic = false;
SWEP.Primary.Ammo = "none";


SWEP.Spawnable = false;
SWEP.AdminSpawnable = true;

SWEP.ViewModel = "models/weapons/v_m16_famas.mdl";
SWEP.WorldModel = "models/weapons/w_m16_goose.mdl";

local ShootSound = Sound ("NPC_Combine.GrenadeLaunch");

function SWEP:Initialize()
	if ( SERVER ) then
	self:SetWeaponHoldType(smg)
	end
end

function SWEP:Think()
end

function SWEP:throw_attack(range)
         self.Weapon:EmitSound (ShootSound);
         self.BaseClass.ShootEffects (self);
         if (!SERVER) then return end;
         local ent = ents.Create ("npc_grenade_frag");
         ent:SetPos (self.Owner:EyePos() + (self.Owner:GetAimVector() * 14));
         ent:SetAngles (self.Owner:EyeAngles());
		 ent:SetOwner(self.Owner)
		 ent:Input("settimer",self.Owner,self.Owner,"4")
         ent:Spawn();
         local phys = ent:GetPhysicsObject();
         phys:ApplyForceCenter (self.Owner:GetAimVector():GetNormalized() * range);
end

function SWEP:PrimaryAttack()
self:throw_attack (10000);
self.Weapon:SetNextPrimaryFire( CurTime() + 0.9 )
self.Owner:ViewPunch( Angle( -5, 0, 0 ) )
end


