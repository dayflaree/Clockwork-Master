
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

	
	
end

SWEP.PrintName = "AN-94";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 50;
	SWEP.ViewModelFlip		= false	
	SWEP.CSMuzzleFlashes	= true
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3.5;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "Weapon_sg550.Single" );

SWEP.WorldModel = "models/weapons/w_rif_an94.mdl";
SWEP.ViewModel = "models/weapons/v_rif_an94k.mdl";

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .13;
SWEP.Primary.Damage = 15;
SWEP.Primary.Force = 4;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .015, .015, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector( -4.0231, 2.4265, -4.9019 );
SWEP.IronSightAng = Vector( -1.0299, 0, -0.1072 );

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = .6;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_an94" )

	end
end
hook.Add( "PlayerDeath", "an94death", weaponremove )