
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "smg";

end

SWEP.PrintName = "HK UMP45";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFlip		= true;
	SWEP.DrawCrosshair = false;
	SWEP.CSMuzzleFlashes	= true;

end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModelFOV		= 55;
SWEP.Primary.Sound = Sound( "Weapon_ump45.Single" );

SWEP.WorldModel = "models/weapons/w_smg_ump45.mdl";
SWEP.ViewModel = "models/weapons/v_smg_ump45.mdl";

SWEP.InvSize = 2;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 90;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .11;
SWEP.Primary.Damage = 6;
SWEP.Primary.Force = 3;
SWEP.Primary.RunCone = Vector( .07, .07, 0 );
SWEP.Primary.SpreadCone = Vector( .047, .047, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .02, .02, 0 );
SWEP.Primary.ViewPunch = Angle( -0.4, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(7.3, 3.2221, -4.6471);
SWEP.IronSightAng = Vector(-1.5622, 0, 0.082);

SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .04, .04, .04 ); 
SWEP.StraySpeed = 0.1;


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_ump45" )

	end
end
hook.Add( "PlayerDeath", "umpdeath", weaponremove )