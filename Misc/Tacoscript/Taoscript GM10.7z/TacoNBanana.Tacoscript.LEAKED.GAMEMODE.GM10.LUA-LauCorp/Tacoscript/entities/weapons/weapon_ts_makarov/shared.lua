
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";
	
	SWEP.FOVAmt = 0;

end

SWEP.PrintName = "Makarov Pistol";


if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;


end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_USP.Single" );

SWEP.WorldModel = "models/weapons/w_makaro.mdl";
SWEP.ViewModel = "models/weapons/v_makaro.mdl";

SWEP.InvSize = 1;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 12;
SWEP.Primary.DefaultClip = 32;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .08;
SWEP.Primary.Damage = 5;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( .1, .1, 0 );
SWEP.Primary.SpreadCone = Vector( .05, .05, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.ViewPunch = Angle( .8, .8, 0 );

SWEP.IronSightPos = Vector(-3.7956, 2.5957, -5.9375);
SWEP.IronSightAng = Vector(0, 0, 0);



function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_makarov" )

	end
end
hook.Add( "PlayerDeath", "makarovdeath", weaponremove )