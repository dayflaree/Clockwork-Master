
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

	
	
end

if( CLIENT ) then

	SWEP.PrintName = "Mosin Rifle";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 50;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "weapons/k98_shoot2.wav" );

SWEP.WorldModel = "models/weapons/w_mosin.mdl";
SWEP.ViewModel = "models/weapons/v_mosin.mdl";

SWEP.Primary.ClipSize = 5;
SWEP.Primary.DefaultClip = 30;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = 1.2;
SWEP.Primary.Damage = 40;
SWEP.Primary.Force = 7;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -2.5, 0.0, 0 );
SWEP.Primary.Automatic = false;

SWEP.IronSightPos = Vector(-5.0069, 1.9907, -8.818);
SWEP.IronSightAng = Vector(1.6526, 1.8193, -3.7435);

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_mosin" )

	end
end
hook.Add( "PlayerDeath", "mosindeath", weaponremove )