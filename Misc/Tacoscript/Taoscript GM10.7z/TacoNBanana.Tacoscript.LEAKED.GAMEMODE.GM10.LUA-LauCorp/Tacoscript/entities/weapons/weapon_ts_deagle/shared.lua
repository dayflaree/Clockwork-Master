

if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "Desert Eagle .50cal";
	SWEP.Slot = 1;
	SWEP.SlotPos = 3;
	SWEP.ViewModelFlip		= true	
	SWEP.CSMuzzleFlashes	= true
	SWEP.ViewModelFOV		= 60	
	
	SWEP.DrawCrosshair = false;
	
end

SWEP.Base = "weapon_ts_base";

SWEP.ViewModel			= "models/weapons/v_pist_deagle.mdl"
SWEP.WorldModel			= "models/weapons/w_pist_deagle.mdl"
SWEP.Primary.Sound			= Sound("Weapon_deagle.Single")

SWEP.InvSize = 1;
SWEP.InvWeight = 0.5;

SWEP.Primary.ClipSize = 7;
SWEP.Primary.DefaultClip = 21;
SWEP.Primary.Ammo = "pistol";
SWEP.Primary.Delay = .12;
SWEP.Primary.Damage = 20;
SWEP.Primary.Force = 15;
SWEP.Primary.RunCone = Vector( .02, .02, 0 );
SWEP.Primary.SpreadCone = Vector( .03, .03, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .02, .02, 0 );
SWEP.Primary.ViewPunch = Angle( -0.9, 0.0, 0 );
SWEP.Primary.Automatic = false;

SWEP.IronSightPos = Vector( 5.142, 2.6068, -2.629 );
SWEP.IronSightAng = Vector( 0, 0, 0 );


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_deagle" )

	end
end
hook.Add( "PlayerDeath", "deagledeath", weaponremove )
