
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "pistol";

end

if( CLIENT ) then

	SWEP.PrintName = "Mac11 Submachine Gun";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFlip		= true	;
	SWEP.CSMuzzleFlashes	= true;	
	SWEP.ViewModelFOV		= 60;	
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

SWEP.Primary.Sound = Sound( "Weapon_MAC10.Single" );

SWEP.WorldModel = "models/weapons/w_smg_mac10.mdl";
SWEP.ViewModel = "models/weapons/v_smg_mac10.mdl";

SWEP.InvSize = 2;
SWEP.InvWeight = 1;

SWEP.Primary.ClipSize = 30;
SWEP.Primary.DefaultClip = 150;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .065;
SWEP.Primary.Damage = 1.5;
SWEP.Primary.Force = 0.5;
SWEP.Primary.RunCone = Vector( .125, .125, 0 );
SWEP.Primary.SpreadCone = Vector( .16, .16, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .09, .09, 0 );
SWEP.Primary.ViewPunch = Angle( -0.9, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(6.5197, 2.933, -4.5831);
SWEP.IronSightAng = Vector(0.5993, 5.3269, 8.7508);


function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_mac11" )

	end
end
hook.Add( "PlayerDeath", "mac11death", weaponremove )