
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "ar2";

	
	
end

if( CLIENT ) then

	SWEP.PrintName = "Winchester Rifle";
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFlip		= true;
	SWEP.ViewModelFOV = 50;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "weapons/scout/scout_fire-1.wav" );

SWEP.WorldModel = "models/weapons/w_boom_m3super90.mdl";
SWEP.ViewModel = "models/weapons/v_beef_m3super90.mdl";

SWEP.Primary.ClipSize = 10;
SWEP.Primary.DefaultClip = 30;
SWEP.Primary.Ammo = "ar2";
SWEP.Primary.Delay = 1.2;
SWEP.Primary.Damage = 20;
SWEP.Primary.Force = 10;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .005, .005, 0 );
SWEP.Primary.ViewPunch = Angle( -2.5, 0.0, 0 );
SWEP.Primary.Automatic = false;

SWEP.IronSightPos = Vector(4.3564, 2.5088, -5.5596);
SWEP.IronSightAng = Vector(0.119, 0, -0.1378);

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_winchester" )

	end
end
hook.Add( "PlayerDeath", "mosindeath", weaponremove )