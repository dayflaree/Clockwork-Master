
if( SERVER ) then

	AddCSLuaFile( "shared.lua" );
	
	SWEP.HoldType = "shotgun";

	
	
end

SWEP.PrintName = "M249 Support Weapon";

if( CLIENT ) then

	
	SWEP.Slot = 2;
	SWEP.SlotPos = 2;
	SWEP.ViewModelFOV = 60;
	
	SWEP.DrawCrosshair = false;

end

SWEP.Base = "weapon_ts_base";

if( SERVER ) then SWEP.FOVAmt = 20; end

SWEP.InvSize = 3.5;
SWEP.InvWeight = 1;

SWEP.Primary.Sound = Sound( "Weapon_m249.Single" );

SWEP.WorldModel = "models/weapons/w_mach_m249para.mdl";
SWEP.ViewModel = "models/weapons/v_mach_m249para.mdl";

SWEP.Primary.ClipSize = 200;
SWEP.Primary.DefaultClip = 400;
SWEP.Primary.Ammo = "smg1";
SWEP.Primary.Delay = .09;
SWEP.Primary.Damage = 15;
SWEP.Primary.Force = 1;
SWEP.Primary.RunCone = Vector( 0.05, 0.05, 0 );
SWEP.Primary.SpreadCone = Vector( .02, .02, 0 );
SWEP.Primary.CrouchSpreadCone = Vector( .01, .01, 0 );
SWEP.Primary.ViewPunch = Angle( -10, 0.0, 0 );
SWEP.Primary.Automatic = true;

SWEP.IronSightPos = Vector(-4.4426, 2.0106, -2.8307 );
SWEP.IronSightAng = Vector( 0.3264, 0, 0.0798 );


SWEP.ViewPunchStray = true;
SWEP.ViewPunchAdd = Vector( .02, .02, .02 ); 
SWEP.StraySpeed = 0.5;

function weaponremove()
	for _, v in pairs( player.GetAll() ) do
	v:RemoveFromInventory( "weapon_ts_m249" )

	end
end
hook.Add( "PlayerDeath", "m249death", weaponremove )
