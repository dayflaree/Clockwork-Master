AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:SpawnFunction( userid, tr )

	local trace = util.GetPlayerTrace( userid, userid:GetAimVector() )
	local tr = util.TraceLine( trace )
	local thisent = ents.Create( "combine_sensor" )
		thisent:SetPos( tr.HitPos + tr.HitNormal * 32 )
--		thisent:SetAngles( tr.HitNormal:Angle() )
		thisent:Spawn()
	thisent:Activate()

end

function ENT:Initialize()

self.BeepShit = {

	Sound( "buttons/combine_button1.wav" );
	Sound( "buttons/combine_button2.wav" );
	Sound( "buttons/combine_button3.wav" );
	Sound( "buttons/combine_button5.wav" );
	Sound( "buttons/combine_button7.wav" );

}

self.Entity:SetModel("models/Items/combine_rifle_ammo01.mdl")
self.Entity:PhysicsInit( SOLID_VPHYSICS )
self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
self.Entity:SetSolid( SOLID_VPHYSICS )
util.PrecacheSound("buttons/combine_button_locked.wav")
self.Off = false
self.Timer = CurTime() + 2.5

end

function ENT:OnTakeDamage()

    local vPoint = self.Entity:GetPos()
    local effectdata = EffectData()
    effectdata:SetStart(vPoint)
    effectdata:SetOrigin(vPoint)
    effectdata:SetScale(1)
    util.Effect("Explosion", effectdata)
	self.Entity:Remove()
		
end

function ENT:Use( activator, caller )

	 if self.Timer < CurTime() then
			self.Timer = CurTime() + 1
		
		if caller:IsCombineDefense() then
		
				self.Entity:EmitSound( self.BeepShit[math.random( 1, #self.BeepShit )] );

			if self.Off == true then
				self.Off = false
			
			elseif self.Off == false then
				self.Off = true
			
			end
			
		end
		
		if !caller:IsCombineDefense() then
			self.Entity:EmitSound("buttons/combine_button_locked.wav", 75, 100)
		end
		
	end
	
end

function ENT:StartTouch()

end

function ENT:EndTouch()

end

local function search(xent)

	local nearby=ents.FindInSphere(xent:GetPos(),100)
		for i=1,table.getn(nearby) do
			if( nearby[i]:GetClass()=="player" )then
		
			xent:SetNWBool( "beeping", true );
			xent:EmitSound("buttons/blip1.wav", 150, 100)
			
			end

	end
		
end


function ENT:Think()

	self.Entity:SetNWBool( "beeping", false )
	
	if self.Off == true then
	self.Entity:SetNWBool( "beeping", false )
	end
	
	if self.Off == false then
	search(self.Entity)
	end
	
end

