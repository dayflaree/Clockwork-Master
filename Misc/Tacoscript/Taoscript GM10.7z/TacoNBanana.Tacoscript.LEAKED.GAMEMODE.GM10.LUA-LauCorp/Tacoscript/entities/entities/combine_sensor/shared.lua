ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Combine Sensor"
ENT.Author= "Ace"
ENT.Contact= ""
ENT.Purpose= ""
ENT.Instructions= "Aliens style." // Don't durundal this one up guys.

ENT.Spawnable			= true
ENT.AdminSpawnable		= true