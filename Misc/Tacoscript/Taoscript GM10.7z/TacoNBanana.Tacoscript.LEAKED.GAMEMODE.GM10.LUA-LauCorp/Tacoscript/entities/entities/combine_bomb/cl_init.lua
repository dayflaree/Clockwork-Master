include('shared.lua')

function ENT:Initialize()

end

function ENT:Draw()
self.BaseClass.Draw(self)
end

function ENT:StartTouch()
end

function ENT:EndTouch()
end

function ENT:Touch()
end
