ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Combine Explosive"
ENT.Author= "Ace"
ENT.Contact= ""
ENT.Purpose= ""
ENT.Instructions= "What the fuck -BOOM." // Don't durundal this one up guys.

ENT.Spawnable			= true
ENT.AdminSpawnable		= true