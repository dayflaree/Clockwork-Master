ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Combine Lock"
ENT.Author= "Ace"
ENT.Contact= ""
ENT.Purpose= ""
ENT.Instructions= "Place on door, no really." // Cryptic metaphor

ENT.Spawnable			= true
ENT.AdminSpawnable		= true