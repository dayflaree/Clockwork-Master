
TS.ServerVars = { }

TS.ServerVars["alltalk"] = 1;
TS.ServerVars["oocdelay"] = 0;
TS.ServerVars["allow_tools"] = 1;

TS.ServerVars["allow_maxstats"] = 0;

TS.ServerVars["maxoweamount"] = 2000;

TS.ServerVars["talkrange"] = 230;
TS.ServerVars["whisperrange"] = 90;
TS.ServerVars["yellrange"] = 490;

TS.ServerVars["propspawning"] = 1;
TS.ServerVars["maxttprops"] = 30;

TS.ServerVars["RebelWeaponrySpent"] = 0;


--These lines appear as notifications when a player enters the server
TS.FunLines = 
{

	"If your models are twisted, tab out and back in",
	"Welcome to Taco 'n' Banana Serious HL2 Roleplay",
	"Errors? Download our HL2 pack at www.taconbanana.com",
	"Visit our website and register today at www.taconbanana.com!"
	
}

