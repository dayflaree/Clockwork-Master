
if( HelpMenuParent ) then
	HelpMenuParent:Remove();
end

if( HelpMenuContent ) then
	HelpMenuContent:Remove();
end	

if( HelpMenuSide ) then
	HelpMenuSide:Remove();
end	

HelpMenuParent = nil;
HelpMenuContent = nil;
HelpMenuSide = nil;

HelpMenuVisible = false;



function ShowHelp()
if( ValidEntity( LocalPlayer() ) ) then
	HelpMenuVisible = !HelpMenuVisible;
	
	gui.EnableScreenClicker( HelpMenuVisible );
	
	if( HelpMenuVisible ) then
	
		if( not HelpMenuParent ) then
			CreateHelpMenu();
		end
		
		HelpMenuParent:SetVisible( true );
	
	elseif( HelpMenuParent ) then
	
		HelpMenuParent:SetVisible( false );
	
	end
end
end
usermessage.Hook( "ShowHelpMenu", ShowHelp );

function ShowDavesGuide()
	ShowHelp();
	CreateHelpContents();
	ApplyDaveG();
end
usermessage.Hook( "ShowDavesGuide", ShowDavesGuide );

local function HelpParentPaint()
if( ValidEntity( LocalPlayer() ) ) then
	if( not ChristmasMod ) then

		draw.DrawText( "TacoScript", "GModToolName", 2, 2, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 8, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 8, 2, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 2, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 8, 5, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 5, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "TacoScript", "GModToolName", 5, 5, Color( 255, 255, 255, 255 ) );
	
	else
	
		draw.DrawText( "Happy Holidays!", "GmodToolName", 2, 2, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 8, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 8, 2, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 2, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 8, 5, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 5, 8, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Happy Holidays!", "GmodToolName", 5, 5, Color( 255, 255, 255, 255 ) );
	
	end
	
	if( ChristmasMod ) then

		surface.SetFont( "GModToolName" );
		local w = surface.GetTextSize( "Happy Holidays!" );
	
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 22, 19, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 28, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 28, 19, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 22, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText("bitch.", "GmodToolSubtitle", w + 28, 22, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 25, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "bitch.", "GmodToolSubtitle", w + 25, 22, Color( 255, 255, 255, 255 ) );
	
	else
	
		surface.SetFont( "GModToolName" );
		local w = surface.GetTextSize( "TacoScript" );
	
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 22, 19, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 28, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 28, 19, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 22, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 28, 22, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 25, 25, Color( 0, 0, 0, 128 ) );
		draw.DrawText( "Created by Rick Darkaliono", "GModToolSubtitle", w + 25, 22, Color( 255, 255, 255, 255 ) );

	end
end
end

function CreateHelpMenu()
if( ValidEntity( LocalPlayer() ) ) then
	local function close()
	
		ShowHelp();
	
	end

	HelpMenuParent = vgui.Create( "TacoPanel" );
	HelpMenuParent:SetPos( 50, 50 );
	HelpMenuParent:SetSize( ScrW() - 100, ScrH() - 100 );
	HelpMenuParent:SetTitle( "TacoScript Help" );
	HelpMenuParent:SetPaintHook( HelpParentPaint );
	HelpMenuParent:SetCloseEvent( close );
	
	HelpMenuParent.HeaderTall = 80;
	HelpMenuParent.ColWidth = HelpMenuParent:GetWide() * .14;
	HelpMenuParent.Col2Width = HelpMenuParent:GetWide() - HelpMenuParent.ColWidth;
	
	HelpMenuSide = vgui.Create( "TacoPanel", HelpMenuParent );
	HelpMenuSide:SetPos( 0, HelpMenuParent.HeaderTall );
	HelpMenuSide:SetSize( HelpMenuParent.ColWidth + 20, HelpMenuParent:GetTall() );
	HelpMenuSide:SetColor( Color( 30, 30, 30, 255 ) );
	HelpMenuSide:EnableTitle( false );
	HelpMenuSide:EnableCloseButton( false );
	HelpMenuSide:EnableDragging( false );
	HelpMenuSide:EnableFullWindow( true );
	
	CreateHelpContents();
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 15 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Basic Info" );
	link.ID = 0;
	link:SetCallback( SetContents );

	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 30 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Rules" );
	link.ID = 1;
	link:SetCallback( SetContents );

	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 45 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Chat Commands" );
	link.ID = 2;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 60 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Console Commands" );
	link.ID = 3;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 75 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Getting Tokens" );
	link.ID = 4;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 90 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Business" );
	link.ID = 5;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 105 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Stats" );
	link.ID = 6;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 120 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Credits" );
	link.ID = 7;
	link:SetCallback( SetContents );
	
	local link = vgui.Create( "TacoLink", HelpMenuSide );
	link:SetPos( 10, 135 );
	link:SetLinkFont( "Default" );
	link:SetLinkText( "Dave's Guide" );
	link.ID = 8;
	link:SetCallback( SetContents );
	ApplyBasicInfo();
	
 end
end

function CreateHelpContents()
if( ValidEntity( LocalPlayer() ) ) then
	if( HelpMenuContent ) then
		HelpMenuContent:Remove();
		HelpMenuContent = nil;
	end

	HelpMenuContent = vgui.Create( "TacoPanel", HelpMenuParent );
	HelpMenuContent:SetPos( HelpMenuParent.ColWidth, HelpMenuParent.HeaderTall );
	HelpMenuContent:SetSize( HelpMenuParent.Col2Width, HelpMenuParent:GetTall() );
	HelpMenuContent:EnableTitle( false );
	HelpMenuContent:EnableCloseButton( false );
	HelpMenuContent:EnableDragging( false );
	HelpMenuContent:EnableFullWindow( true );
end
end

function SetContents( link )
if( ValidEntity( LocalPlayer() ) ) then
	local id = link.ID;
	
	CreateHelpContents();
	
	if( id == 0 ) then
		ApplyBasicInfo();
	end
	
	if( id == 1 ) then
		ApplyRules();
	end
	
	if( id == 2 ) then
		ApplyChatCommands();
	end
	
	if( id == 3 ) then
		ApplyConsoleCommands();
	end
	
	if( id == 4 ) then
		ApplyGettingTokens();
	end
	
	if( id == 5 ) then
		ApplyBusiness();
	end
	
	if( id == 6 ) then
		ApplyStats();
	end
	
	if( id == 7 ) then
		ApplyCredits();
	end
	
	if( id == 8 ) then
		ApplyDaveG();
	end
	end
end

function ApplyBasicInfo()

	HelpMenuContent:AddLabel( FormatLine( "TacoScript is an RP(G) gamemode created by Rick Dark.", "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );
	
end

function ApplyRules()
if( ValidEntity( LocalPlayer() ) ) then
	local text = "These are the rules.\n\n";
	text = text .. "1) A roleplay name is needed.\n\nAcceptable names are:\n\nFirst Name + Last Name (example: Rick Darkaliono)\nFirst Name + Middle Initial + Last Name (example: Richard K. Darkaliono)\nTwo Initials + Last Name (example: J.R. Menson )\n\nAny other format is not acceptable and you will be kicked after being warned for not having an RP name. And, names like Mike Hunt or other extremely witty names are bannable.\n\n2) Grav-gun DMing is bannable.\n\n3) Killing another player for non-RP reasons can be kickable. Excluding accidents or the like.\n\n4) Arguing in OOC excessively or not shutting up can be kickable or even bannable.\n\n5) Building gigantic, space-taking things, or something completely unrelated to any roleplay is kickable/bannable. Unless an RDA or SEA allows it.\n\n6) Abusing tool trust, like removing random doors or placing dynamites and killing everyone can you get you banned from the server, temporarily or permanently, based on severity.\n\n7) \"Stupid/Dumb\" roleplay can be kickable/bannable.";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	

end
end

function ApplyChatCommands()
if( ValidEntity( LocalPlayer() ) ) then
	local text = "These commands are typed in chat\n\n";
	text = text .. "// <text> - Speak in OOC (or \"Out-Of-Character\" chat)  This text is global, and not used for RP.  Other OOC prefixes are /a, and ((\n";
	text = text .. "[[ or .// <text> - Speak in local OOC\n";
	text = text .. "/w <text> - Whisper text locally\n";
	text = text .. "/y <text> - Yell text locally\n";
	text = text .. "/an <text> - Talk anonymously locally\n";
	text = text .. "/r <text> - If you have a radio, send a radio message\n";
	text = text .. "/cr <text> - Send a request for Combine (make it short and offer your location)\n";
	text = text .. "/pm <Name< <text> - Send a private message to someone\n";
	text = text .. "/me <text> - Outputs third person text\n\n";
	text = text .. "/adv <text> - Advertise something for 25 tokens\n";
	text = text .. "/cid <5 digit number> - Your CID, this cannot change after it is set\n";
	text = text .. "/bc <text> - Combine can use this to broadcast something\n\n";
	text = text .. "/write - Write a letter, if you have paper\n";
	text = text .. "/title <text> - Set your character title (viewable by other players)\n\n";
	text = text .. "/adddoorowner <Name> - Add an owner to your door\n";
	text = text .. "/removedoorowner <Name> - Remove owner from your door\n";
	text = text .. "/doortitle <text> - Set the name of a door you're looking at (viewable by other players)\n\n";
	text = text .. "/givegun - Give the player you're looking at the gun you're holding\n";
	text = text .. "/dropgun - Drop the current gun you're holding\n\n";
	text = text .. "/givemoney or /givetokens <Amount> - Give a player you're looking at a specified number of tokens\n\n";
	text = text .. "/help - Open help menu\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	

	surface.SetFont( "Default" );
	local w, h = surface.GetTextSize( text );

	text = "";

	if( LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() ) then
	
		text = text .. "!kick <Name/PartialName> <Reason> - Kick a player\n";
		text = text .. "!ban <Name/PartialName> <Length in minutes> - Ban a player\n";
		text = text .. "!slap <Name/PartialName> - Slap a player\n";
		text = text .. "!slay <Name/PartialName> - Slay a player\n";
		text = text .. "!bring <Name/PartialName> - Bring a player to you\n";
		text = text .. "!goto <Name/PartialName> - Goto a player to you\n";
		text = text .. "!noclip - Noclip yourself\n";
		
	end
	
	text = text .. "!a <Message> - Speak to admins\n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9 + h, Color( 255, 255, 255, 255 ) );	

end
end

function ApplyConsoleCommands()
if( ValidEntity( LocalPlayer() ) ) then
	local text = "These commands are typed in console\n\n";
	text = text .. "rp_selectcpmodel - Bring up CP model selection menu\n";
	text = text .. "rp_headbob <1/0> - Toggle head bobbing\n";
	text = text .. "rp_toggleholster - Holster and unholster your weapon\n";
	text = text .. "rp_changename <name> - Change your current character's name (doesn't create new character)\n";
	text = text .. "setname <name> - Create a new character\n";
	text = text .. "rp_ramdoor - Ram a door, as opposed to pressing with reload with unholstered fists\n";
	text = text .. "rp_loans - If you're a Combine, list the debts of all players in game\n";
	text = text .. "rp_listsaves - List all of your current saves\n";
	text = text .. "rp_deletesave <name> - Delete a save.  PUT QUOTATION MARKS AROUND THE NAME\n";
	text = text .. "rp_animslist - Get a list of player anims\n";
	text = text .. "rp_soundlist - Get a list of all Combine lines\n";
	text = text .. "rp_combineroster - Get a view of all current Combine flags and members\n";
	text = text .. "rp_proplog [Amount of logs] - Retrieve a log of prop spawning.\n";
	text = text .. "rp_toollog [Amount of logs] - Retrieve a log of tool gun actions\n";
	
	if( LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() or LocalPlayer():HasCombineFlag( "E" ) ) then
	
		text = text .. "rp_setcombineflag <Target> <Flags> - Set a player's current Combine flags\n\n";
	
	else
		text = text .. "\n";
	end
	
	text = text .. "gm_showhelp - Show this menu\n";
	text = text .. "gm_showspare1 or F3 - Show your player menu\n";
	text = text .. "gm_showspare2 or F4 - Own properties and doors\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	
	
	surface.SetFont( "Default" );
	local w, h = surface.GetTextSize( text );

	text = "";
	
	if( LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() ) then
	
		text = text .. "Admin commands:\n\n";
		text = text .. "rp_name <Target> - Issue name warning\n";
		text = text .. "rp_seeall - See where all players are\n";
		text = text .. "rp_addtooltrust <Target> - Give tool trust\n";
		text = text .. "rp_removetooltrust <Target> - Remove tool trust\n";
		text = text .. "rp_addttsteamid, rp_removettsteamid <SteamID>\n";
		text = text .. "rp_ttlist - Get TT list\n";
		text = text .. "rp_allowtools <1 or 0> - Enable/disable toolgun\n";
		text = text .. "rp_oocdelay <Amount> - Delay OOC in seconds\n";
		text = text .. "rp_cp, rp_ow, rp_ce, rp_ca <Target> - Team commands\n";
		text = text .. "rp_kick <Name/PartialName> <Reason> - Kick a player\n";
		text = text .. "rp_ban <Name/PartialName> <Length in minutes> - Ban a player\n";
		text = text .. "rp_slap <Name/PartialName> - Slap a player\n";
		text = text .. "rp_slay <Name/PartialName> - Slay a player\n";
		text = text .. "rp_bring <Name/PartialName> - Bring a player to you\n";
		text = text .. "rp_goto <Name/PartialName> - Goto a player to you\n";
		text = text .. "rp_physgunban <Name/PartialName> - Ban a player from physgun\n";
		text = text .. "rp_physgununban <Name/PartialName> - Un-Ban a player from physgun\n";
		text = text .. "rp_noclip - Noclip yourself\n";
		text = text .. "rp_restartmap - Restart the map\n";
		
	end
	
	text = text .. "rp_asay <Message> - Speak to admins\n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9 + h, Color( 255, 255, 255, 255 ) );	
 
 	if( LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() ) then
 	
	 	surface.SetFont( "Default" );
		local w, h = surface.GetTextSize( text );
	
		text = "";
		
		text = text .. "rp_findowner - Find owner of door you're looking at\n";
		text = text .. "rp_unowndoor - Unown door you're looking at\n";
		text = text .. "rp_unownproperty - Unown property of the door you're looking at\n";
		
		HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 300, 9 + h, Color( 255, 255, 255, 255 ) );	
 	
 	end
 
 	
 end
end

function ApplyGettingTokens()
if( ValidEntity( LocalPlayer() ) ) then
	text = "Tokens is your currency in TacoScript.  You can get tokens by:\n\n";
	text = text .. "1) Having transactions with other players, working for other players and getting paid\n";
	text = text .. "2) Getting Combine rations. Each ration contains some food and 20 tokens\n";
	text = text .. "3) Creating a business and selling products.\n";
	text = text .. "4) Getting loans.  Check the Finance tab under your F3 menu.  Remember to pay these loans back or the Combine will be on your back.\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	
end
end

function ApplyBusiness()

	text = "Businesses are a good way of becoming rich, if you know what you're doing.\n\n";
	text = text .. "To create a business:\n";
	text = text .. "1) Open the player menu\n";
	text = text .. "2) Go under the Business tab\n";
	text = text .. "3) Press Create Business\n";
	text = text .. "4) Ponder why you needed to read this to figure out how to make a business\n\n";
	
	text = text .. "You can purchase a supply license, allowing you to purchase products and sell them\n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	


end

function ApplyStats()

	text = "Strength - The amount of damage your punches or any other melee attacks do.  Punching/melee attacking something will increase your strength.\n";
	text = text .. "Speed - The speed at which your character runs.  Running increases this.\n";
	text = text .. "Sprint - How long you can sprint for.  Running increases this.\n";
	text = text .. "Endurance - Your ability to handle damage or regenerate health over time.  Taking damage increases your endurance overtime. (Melee damage only)\n";
	text = text .. "Aim - Your character's ability to aim. Shooting raises this\n";
	text = text .. "Medic - Your character's ability to heal someone.  Healing/bandaging raises this\n";
	text = text .. "Sneak - How agile you are in moving while sneaking. Crouching around while moving raises this.\n\n";
	
	text = text .. "Raising stats will become more difficult as your stat is higher.  At 85 or higher, it will be the most difficult to raise a stat.\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	

	

end

function ApplyCredits()

	text = "Coder/Developer - \nRick Dark\n\n";
	
	text = text .. "With thanks to - \n";
	text = text .. "Dave Brown - For being an awesome RPer and head admin.\n";
	text = text .. "Gen - For being an epicly awesome BFF.\n";
	text = text .. "Spaz - For the work done on TnB site.\n";
	text = text .. "Kama - For all the site and server shit.\n";
	text = text .. "Staplegun - For helping TnB while it was ded after TylerM.\n";
	text = text .. "Waxx - For badassery.\n";
	text = text .. "Durundal - For being the appleman.\n";
	text = text .. "humiliation - For mapping the most epic shit ever.\n";
	text = text .. "HC - For being a friend since the beginning of time.\n";
	text = text .. "Baker - For ALSO being a friend since the beginning of time.\n";
	text = text .. "Naru - For being a catgirl friend since the beginning of time.\n";
	text = text .. "Spartan5150 - For being an angry dick friend since a long long time ago\n";
	text = text .. "Kuromatsu - For giving crazy RP ideas and for CREATING Rick Dark.\n";
	text = text .. "RickV - For using his clever British wit, having his eccentric fashion, and being an RPer.\n";	
	text = text .. "Looter - For deleting my website and gameserver's database.\n";	
	text = text .. "Beastmasta - For the initial idea of TnB.\n";
	text = text .. "Wrinkles - For leaking TS, and then mellowing out.\n";
	text = text .. "Pivot - For being confused all the time, and making pretty pictures.\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	


	surface.SetFont( "Default" );
	local w, h = surface.GetTextSize( text );

	text = "";
	
	text = text .. "Zombie - For being a good admin and wtf ever else.\n";
	text = text .. "AFNY - Who are you again.\n";
	text = text .. "George Vince - For bringing up the server and being British.\n";
	text = text .. "Bennet Dyson - For having no balls, you dirty irish bastard.\n";			
	text = text .. "Anony - For being HIGHLARIOUS.\n";	
	text = text .. "eatdamuffin - For being also HIGHLARIOUS, and apparantly, a good leader.\n";
	text = text .. "JetBoom - For creating Zombie Survival, of which I stole the code for and turned into TS.\n";
	text = text .. "pcwizdan - For being a dick to me for no reason just because you disliked TS.  You no-talented little fag muncher.\n";
	text = text .. "Saphira - For liking dragons and RPing.\n";	
	text = text .. "The Providence - For being funneys and being The Providence.\n";
	text = text .. "Tripod - For smoking pot and wanting to be a cool cat.\n";	
	text = text .. "Fig - For bitching at me to put your SWEPs on the server for a month, and then taking them away from me later.\n";		
	text = text .. "TylerM - For being a fatass that made TnB even more popular.\n";
	text = text .. "Loam - LOAM... LOAM!!\n";
	text = text .. "DSRP - For all the epic, good times we had.\n";
	text = text .. "MineDog - For being really elitist, but nice folks otherwise.\n";
	text = text .. "And TnB - For being an awesome community with fun peoples."
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h - 3, Color( 255, 255, 255, 255 ) );	

	surface.SetFont( "Default" );
	local w, h2 = surface.GetTextSize( text );

	text = "";

	text = text .. "Thanks guys, and good luck.\n";
	text = text .. "\n";
	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 - 3, Color( 255, 255, 255, 255 ) );	

	
end

function ApplyDaveG()

	HelpMenuContent:AddScrollBar();
	HelpMenuContent:SetMaxScroll( 32 * ( 58 + 1 ) );
	 
	local scroll = HelpMenuContent:GetScrollAmount();
	--print(scroll)
	
	text = "";
text = text .. "Here you will find the answers to almost everything you need to know when starting out in our community. I will keep it as simple as possible. We will cover -\n";
text = text .. "\n";
text = text .. "1. Info on the Community / Server\n";
text = text .. "2. Our Roleplay Scenario\n";
text = text .. "3. Opportunities for Roleplay via Tacoscript\n";
text = text .. "4. Rules\n";
text = text .. "5. Useful Commands\n";
text = text .. "\n";
text = text .. "----------------------------------------------------\n";
text = text .. "\n";
text = text .. "1. Info on the Community / Server\n";
text = text .. "\n";
text = text .. 'Taco & Banana was created by "Rick Darkaliono" around March 2007, along with Tacoscript.\n';
text = text .. "\n";
text = text .. "Tacoscript is constantly under development, and is scheduled for completion sometime next year. However, T&B reserves the right to the most up-to-date version at all times, with its new features and so forth. Other servers using TacoScript are approximately 5 months behind our current version.\n";
text = text .. "\n";
text = text .. "Taco & Banana is run by the top admin Dave Brown (me) and a series of senior admins such as Eatdamuffin, George Vince, AFNY, Bennet Dyson, Zombie, RickV and Anony.\n";
text = text .. "\n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, 9, Color( 255, 255, 255, 255 ) );	


	surface.SetFont( "Default" );
	local w, h = surface.GetTextSize( text );
	
	text = "";
text = text .. "Taco & Banana is now hosted entirely by the admin team, not an outisde source. Inpendently.\n";
text = text .. "\n";
text = text .. "We are no longer associated with Kama or PIX guild.\n";
text = text .. "\n";
text = text .. "--------------------------------------------------------\n";
text = text .. "\n";
text = text .. "2. Our Roleplay Scenario\n";
text = text .. "\n";
text = text .. "- T&B is a Half Life 2 themed roleplay server, set *BEFORE* the arrival of Gordon Freeman.\n";
text = text .. "\n";
text = text .. '- There are no "Cops", they are replaced by "Civil Protection" and "Overwatch" Millitary soldiers.\n';
text = text .. "\n";
text = text .. "- T&B is a strictly SERIOUS Roleplay server, with no exceptions. We believe that we offer the finest in Serious Roleplay on a large scale. If you wish to do any of the following things, you are best finding a community running DarkRP or so forth -\n";
text = text .. "= Starting gangs or mafias.\n";
text = text .. "= Deathmatching (DMing) - killing people with no reason.\n";
text = text .. "= Assuming TacoScript is an RPG gamemode - The aim of our server is to Roleplay, do not become sidetracked by TacoScripts inventory features etc.\n";
text = text .. "\n";
text = text .. "-------------------------------------------------------------------\n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + 32, Color( 255, 255, 255, 255 ) );	

	surface.SetFont( "Default" );
	local w, h2 = surface.GetTextSize( text );
	
	text = "";
	
text = text .. "\n";
text = text .. "3. Opportunities for Roleplay at Taco & Banana\n";
text = text .. "\n";
text = text .. "- We have 3 main Factions -\n";
text = text .. "\n";
text = text .. "> The Combine\n";
text = text .. "> The Citizens\n";
text = text .. "> The Resistance\n";
text = text .. "\n";
text = text .. "Everyone starts out as a Citizen. If you wish to join the Combine, you must first become familiar with life as a Citizen, then apply via the appropriate section on the forum. Joining the Resistance is done more covertly, as they have no visible 'application' or training process viewable to the public.\n";
text = text .. "\n";
text = text .. "Combine Civil Authority (CCA) -\n";
text = text .. "\n";
text = text .. "Applications are read once every week (usually saturday or sunday) and those with good enough applications are accepted for their training week.\n";
text = text .. "During this week you will be issued with soley a USP pistol and stunbaton, and will learn all about work in the Civil Protection. If you are deemed acceptable,\n";
text = text .. "you will be promoted to a Standard Unit the following weekend, when the next batch begins training.\n";
text = text .. "\n";
text = text .. "The Combine at current uses a squad system. After completion of training, you will be assigned a squad. You may then progress through \n";

	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + 28, Color( 255, 255, 255, 255 ) );	
surface.SetFont( "Default" );
	local w, h3 = surface.GetTextSize( text );
	
	text = "";
text = text .. "the ranks to become an Elite unit, or even a Squadleader yourself.\n";
text = text .. "\n";
text = text .. 'Those with excellent millitary capability can be picked to join the Overwatch. This group is "invite only", and one of the most sought-after.\n';
text = text .. "\n";
text = text .. 'Also you may apply to become a "City Administrator" (Similar to Dr Breen in HL2), although this spot is reserved for more Experianced Roleplayers.\n';
text = text .. "\n";
text = text .. "\n";
text = text .. "The Resistance -\n";
text = text .. "\n";
text = text .. "The Resistance at Taco&Banana is a proffesional affair, we do not allow inexperianced Roleplayers or the like access to the ranks. To become affiliated with the Resistance, you must meet with a leader or member In-Character (IC) on the server. You can then be tested and tought exactly how to operate.\n";
text = text .. "\n";
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + 40, Color( 255, 255, 255, 255 ) );	

surface.SetFont( "Default" );
	local w, h4 = surface.GetTextSize( text );
	
	text = "";
text = text .. "The Resistances main objectives are kept totally secretive both in and out of the game, although they will often be planting propoganda, helping Citizens with food and supplies, and occasionally mounting guerilla raids. There will very rarely be any form of direct combat,\n";
text = text .. "and therefore this group is recommended for experianced roleplayers only.\n";
text = text .. "\n";
text = text .. "\n";
text = text .. "Other Roleplay groups -\n";
text = text .. "\n";
text = text .. "We currently have the following opportunities for Roleplayers also,\n";
text = text .. "= Stalkers (limbless slaves used by the Combine in the Citadel / nexus)\n";
text = text .. "= Vortigaunts (Limited placement for trusted players)\n";
text = text .. "= Black Market Dealers (VERY limited placements available - reserved for excellent Roleplayers)\n";
text = text .. "= Standard Supply Dealers (Tacoscript allows extensive business opportunities)\n";
text = text .. "= Numerous player-created groups such as -\n";
text = text .. "  - The Church Of Rebirth\n";
text = text .. "  - Amaria Industries\n";
text = text .. "  - The Iron Legion\n";
text = text .. "  - City Engineering\n";
text = text .. "  - Blue Skye Publications\n";
text = text .. "  - Brotherhood of street magicians.\n";
text = text .. "\n";
text = text .. "Application for all groups can be done via the main area of the forum.\n";
text = text .. "\n";
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + 52, Color( 255, 255, 255, 255 ) );	

surface.SetFont( "Default" );
	local w, h5 = surface.GetTextSize( text );
text = "----------------------------------------------------------------------------\n";
text = text .. "\n";
text = text .. "4. Rules / terms\n";
text = text .. "\n";
text = text .. "A list of helpful terms -\n";
text = text .. "\n";
text = text .. "TT - Tooltrust. The ability to use toolgun, basic or advanced. Apply on the forum.\n";
text = text .. "\n";
text = text .. "IC / OOC - In-Character / Out-Of-Character -\n";
text = text .. "= In Character is what your character can say or do such as 'Hello, may I buy a newspaper?'\n";
text = text .. "= Out-Of-Character is what you say to other gamers such as 'How do I open my inventory?'\n";
text = text .. "\n";
text = text .. "Metagaming - This term describes when one player is using 'OOC' information IC. For example -\n";
text = text .. "= Knowing somebodies name by looking at the tag above their head.\n";
text = text .. "= Changing how you act due to something that has been said in OOC Chat - eg 'OOC: Somebody just dropped a gun in the bar'\n";
text = text .. "= The New Life Rule. If you are killed, you do NOT know who killed you, you forget your immediate thoughts IC. DO NOT GO BACK TO WHERE YOU DIED.\n";
text = text .. "\n";
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + h5 + 58, Color( 255, 255, 255, 255 ) );	
surface.SetFont( "Default" );
	local w, h6 = surface.GetTextSize( text );
	text = "";
text = text .. "Deathmatching (DMing) - Killing somebody without a decent In-Character reason is TOTALLY FORBIDDEN. We have plenty of admins present at all times of the day,\n"; 
text = text .. "and they WILL remove you from the server.\n";
text = text .. "\n";
text = text .. "Use of the Physgun - You may not propsurf (use the physgun to climb the map, or move on props). You may not move other peoples props without valid RP reasons and motives. You will have this tool removed if you abuse it.\n";
text = text .. "\n";
text = text .. "Punchwhoring - Abuse of the 'hands / fists' swep. if you are seen to be punching people for no or little reason, you will be removed.\n";
text = text .. "\n";
text = text .. "CID - Combine ID number - Set this by typing /cid ##### (5 digits)\n";
text = text .. "CCA - Combine Civil Authority (collective term for the Combine)\n";
text = text .. "CCH - Combine Civil Housing (a building organised by the Combine for free housing)\n";
text = text .. "ACA - Anti Civil Activity (criminal activity)\n";
text = text .. "BM - Black Market (abreviation)\n";
text = text .. "CP - Civil Protection (metrocops)\n";
text = text .. "OW - Overwatch\n";
text = text .. "CA - City Administrator\n";
text = text .. "RCT - Recruit units (Cp in training)\n";
text = text .. "SQL - Squad Leader (Fully black armour)\n";
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + h5 + h6 + 72, Color( 255, 255, 255, 255 ) );	
surface.SetFont( "Default" );
	local w, h7 = surface.GetTextSize( text );
	text = "";
text = text .. "ESU - CP Elite Shock Unit (Red&Black armour)\n";
text = text .. "DVL - Division Leader (Black Trenchcoat)\n";
text = text .. "\n";
text = text .. "Ration Distribution - Every Hour or so, the Civil Protection will give out rations (usually from a building next to the Nexus). Get in line and be ready to provide your 5 digit CID and name.\n";
text = text .. "\n";
text = text .. "-----------------------------------------------------------\n";
text = text .. "\n";
text = text .. "5. Useful Commands -\n";
text = text .. "\n";
text = text .. "// - OOC Chat\n";
text = text .. "[[ - Local OOC chat\n";
text = text .. "/cr - Combine Request (must include name, location, and crime commited)\n";
text = text .. "/y - yell\n";
text = text .. "/w - whisper\n";
text = text .. "/pm Name (or part of name) - Send an PM.\n";
text = text .. "/r - Radio chat\n";
text = text .. "F3 - Open player menu / Inventory\n";
text = text .. "/givemoney ## - Gives money\n";
text = text .. "/dropweapon\n";
text = text .. "/giveweapon (must be looking closely at the player)\n";
text = text .. "It is a good idea to bind those also ^\n";
text = text .. 'bind "o" "say /dropweapon"\n';
text = text .. ' bind "p" say /giveweapon"\n';
text = text .. '!a ------ - Send a message to the admins eg "!a Someone is propsurfing onto the Nexus"\n';
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + h5 + h6 + h7 + 83, Color( 255, 255, 255, 255 ) );	
local w, h8 = surface.GetTextSize( text );
	text = "";
text = text .. "\n";
text = text .. "\n";
text = text .. "Console commands -\n";
text = text .. "rp_headbob 0 / 1 - Set this to turn off the headbob effect.\n";
text = text .. 'rp_toggleholster - toggles you lowering or aiming your weapon, bind it in console as     bind "x" "rp_toggleholster"\n';
text = text .. "(when your weapon is holstered, you are still holding it by your side, so take out your hands to put it away fully)\n";
text = text .. "rp_changename - Change the name of the current character\n";
text = text .. "name a - Opens the character creation screen. Used also for swapping to another character.\n";
text = text .. "\n";
text = text .. "\n";
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + h5 + h6 + h7 + h8 + 89, Color( 255, 255, 255, 255 ) );	
local w, h9 = surface.GetTextSize( text );
	text = "";
text = text .. "------------------------------------------------------------------\n";
text = text .. "\n";
text = text .. "\n";
text = text .. "\n";
text = text .. "A FINAL NOTE -\n";
text = text .. "\n";
text = text .. "At Taco & Banana, we believe that the key to succesful Roleplaying is the fair and balanced integration of everyone within the\n";
text = text .. "community and server, working together to create a scenario which can be enjoyed by everyone.\n";
text = text .. "\n";
text = text .. "We encourage people to constantly strive to learn and develop their characters in as many ways as possible, and we hope to provide \n";
text = text .. "opportunities for players to be as creative as possible.\n";
text = text .. "\n";
text = text .. "Taco & Banana is one of the only Garrysmod Roleplay Communities that provides 100% serious Roleplay, with a fair, proffesional and \n";
text = text .. "unbiased administration team. Most of all, we want YOU to enjoy your time here\n";	
	HelpMenuContent:AddLabel( FormatLine( text, "Default", HelpMenuParent.Col2Width - 120 ), "Default", 10, h + h2 + h3 + h4 + h5 + h6 + h7 + h8 + h9 + 93, Color( 255, 255, 255, 255 ) );	

end	
