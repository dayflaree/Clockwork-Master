
function CheckSpecialCharacter( ply )

	--Rick Darkaliono fix :D
	--and ply:IPAddress() != "71.77.201.231"
	--if ply:SteamID() == "STEAM_0:1:4976333" then ply:ConCommand("quit") end
	
	local TJA_list = {
	"STEAM_0:0:14498745", --Stan
	"STEAM_0:1:8611567", -- Stans main
	"STEAM_0:0:6363693",
	"STEAM_0:0:14974871",
	"STEAM_0:0:16442291",
	"STEAM_0:1:18111565", -- troll
	"STEAM_0:0:17724368", -- troll
	"STEAM_0:1:14478438",
	"STEAM_0:0:12022230", -- never unban
	"STEAM_0:0:15227622",
	"STEAM_0:0:7754825",
	"STEAM_0:0:16693285",
	"STEAM_0:0:3095345", -- spreading lua viruses
	"STEAM_0:0:18763808", -- uses hacks
	"STEAM_0:0:11022059",
	"STEAM_0:0:7754825", -- Earthhunter
	"STEAM_0:1:21256779",
	"STEAM_0:0:18596358", -- using hacks
	"STEAM_0:1:5144532", -- reeces mate
	"STEAM_0:0:3144427", -- reece
	"STEAM_0:0:4386443", -- reece
	"STEAM_0:1:13419170",
	"STEAM_0:1:17077413", -- hacker
	"STEAM_0:0:11793378",
	"STEAM_0:1:6052852", -- cheesums or pac
	"STEAM_0:1:25046203", -- pac
	"STEAM_0:0:13389090", -- cant be brought/hack
	"STEAM_0:1:18008485", -- stan new
	"STEAM_0:1:4151423", -- Racid
	"STEAM_0:0:14498745", --stan too main?
	"STEAM_0:0:13864953", -- stan too
	"STEAM_0:1:13067659", -- stan too
	"STEAM_0:1:21727917", -- ezeral
	"STEAM_0:1:8387555", -- Kudo
	"STEAM_0:0:16693285", -- Kudo2
	"STEAM_0:1:3307510", -- jetboom
	"STEAM_0:1:81298483", -- jetbooms bumboi
	"STEAM_0:1:2512273", -- xalphox
	"STEAM_0:0:6167077", -- grio
	"STEAM_0:1:3480183", -- wesker
	"STEAM_0:1:22860119", -- flagabuse
	"STEAM_0:0:11997609", -- flagabuse
	"STEAM_0:1:11012884", -- Adrian50
	"STEAM_0:0:11243559", -- was using my account
	"STEAM_0:1:23327299", -- beef this one hard
	"STEAM_0:0:14498745", -- stan 
	"STEAM_0:1:21069091",
	"STEAM_0:1:18008485",
	"STEAM_0:0:12022230",
	"STEAM_0:0:7754825",
	"STEAM_0:1:8387555",
	"STEAM_0:1:8611567",
	"STEAM_0:1:25000908" --stans newest
	}
	
	if table.HasValue( TJA_list, ply:SteamID() ) then
	
		ply:Kick( "PermaBanned, proceed to forums to request an unban" );
		ply:ConCommand( "disconnect\n" );
		
	end
	
	if( ply:Team() == 5 ) then
	
		if( ply:SteamID() == "STEAM_0:1:16000877" ) then
		ply:SetTitle( "Metroplex Admin. Executive" );
		end
		
	end	
	
	if( ply:Team() == 1 ) then
		
		if( ply:SteamID() == "STEAM_0:1:17637678" and ply:Nick() == "Eva Snow" ) then
		
			ply:ForceGive( "weapon_ts_bar" );

		end		

		if( ply:SteamID() == "STEAM_0:0:1585387" and ply:Nick() == "Nathan Connors" ) then
		
			ply:ForceGive( "weapon_ts_bar" );

		end	
						
		if( ply:SteamID() == "STEAM_0:0:2256580" and ply:Nick() == "Seth Iron" ) then		
			ply:SetTeam( 7 );
			ply:SetArmor("100");
			ply:SetField( "radiofreq", tonumber( TS.CombineRadioFreq ) );
			ply:SetModel("models/Humans/Group01/Male_98.mdl");
			ply:ForceGive( "weapon_ts_CISR" );
			ply:ForceGive( "weapon_ts_tranq" );
			ply:ForceGive( "weapon_ts_needle" );
			ply:ForceGive( "weapon_ts_flashnade" );
			ply:ForceGive( "weapon_ts_zipties" );
			ply:ForceGive( "weapon_ts_riot" );
			ply:ForceGive( "weapon_grenade" );
			ply:ForceGive( "weapon_ts_spistol" );
			ply:ForceGive( "weapon_ts_breachingshotgun" );
		end
		
		if( ply:SteamID() == "STEAM_0:1:8951693" and ply:Nick() == "Vaccine" ) then		
			ply:SetTeam( 7 );
			ply:SetArmor("100");
			ply:SetField( "radiofreq", tonumber( TS.CombineRadioFreq ) );
			ply:SetPrivateFloat( "radiofreq", tonumber( TS.CombineRadioFreq ) );
			ply:SetModel("models/Humans/Group03/gurne_vaccine_citizen.mdl");
			ply:ForceGive( "weapon_ts_needle" );
			ply:ForceGive( "weapon_ts_flashnade" );
			ply:ForceGive( "weapon_ts_zipties" );
			ply:ForceGive( "weapon_ts_tranq" );
			ply:ForceGive( "weapon_ts_spistol" );
			ply:ForceGive( "weapon_ts_combinesniper" );
			ply:ForceGive( "weapon_ts_pdw2" );
		end
		
		 if( ply:SteamID() == "STEAM_0:0:1425918" and ply:Nick() == "Icarus" ) then
			ply:SetTeam( 5 );
			ply:SetField( "radiofreq", tonumber( TS.CombineRadioFreq ) );
			ply:SetPrivateFloat( "radiofreq", tonumber( TS.CombineRadioFreq ) );
			ply:SetModel("models/icarus_anon.mdl");
		end
		
		if ( ply:SteamID() == "STEAM_0:0:11855594" ) then
			ply:StripWeapons();
			ply:Lock();
		
		end
		
		if ( ply:SteamID() == "STEAM_0:1:8611567" ) then
			ply:StripWeapons();
			ply:Lock();
		
		end

		if ( ply:SteamID() == "STEAM_0:1:8387555" ) then
			ply:StripWeapons();
			ply:Lock();
		
		end

		local query = "SELECT `CustomModel`, `CustomModelName` FROM `tb_donations` WHERE `STEAMID` = '" .. ply:SteamID() .. "'";	
		local tab = mysql.query( TS.SQL, query );	
		
		if( tab and #tab > 0 and string.len( tab[1][1] ) > 6 ) then
		
			local model = tab[1][1];
			local name = tab[1][2];
			
			if( ply:Nick() == name ) then
			
				ply:SetModel( model );
			
			end
		
		end
	
		
	end

end
