--------------------------------------------
--TnB CP Model Changer - Coded by Horsey----
--PUT THE FUNCTION SHIT IN THE cl_init.lua--
--------------------------------------------



function SelectCPModel()

if( LocalPlayer():HasCombineFlag( "A" ) ) then

        local MFrame = vgui.Create( "DFrame")
        MFrame:SetSize( 300, 347 )
        MFrame:Center()
        MFrame:SetTitle( "Civil Protection Model Changer" )
        MFrame:SetVisible( true )
        MFrame:SetDraggable( false )
        MFrame:ShowCloseButton( true )
        MFrame:MakePopup()

	local GryBck = vgui.Create( "DPanelList", MFrame )
	GryBck:SetPadding( 4 ) 
	GryBck:SetPos( 10, 30 )
	GryBck:SetSize( 278, 280 )

	local CPIcon1 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon1:SetPos( 15, 35 )
	CPIcon1:SetModel( "models/purvis/male_01_metrocop.mdl" )
	CPIcon1.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_01_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon2 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon2:SetPos( 83, 35 )
	CPIcon2:SetModel( "models/purvis/male_24_metrocop.mdl" )
	CPIcon2.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_24_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon3 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon3:SetPos( 151, 35 )
	CPIcon3:SetModel( "models/purvis/male_03_metrocop.mdl" )
	CPIcon3.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_03_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon4 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon4:SetPos( 219, 35 )
	CPIcon4:SetModel( "models/purvis/male_04_metrocop.mdl" )
	CPIcon4.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_04_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon5 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon5:SetPos( 15, 105 )
	CPIcon5:SetModel( "models/purvis/male_05_metrocop.mdl" )
	CPIcon5.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_05_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon6 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon6:SetPos( 83, 105 )
	CPIcon6:SetModel( "models/purvis/male_06_metrocop.mdl" )
	CPIcon6.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_06_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon7 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon7:SetPos( 151, 105 )
	CPIcon7:SetModel( "models/purvis/male_07_metrocop.mdl" )
	CPIcon7.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_07_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon8 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon8:SetPos( 219, 105 )
	CPIcon8:SetModel( "models/purvis/male_08_metrocop.mdl" )
	CPIcon8.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_08_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon9 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon9:SetPos( 15, 173 )
	CPIcon9:SetModel( "models/purvis/male_09_metrocop.mdl" )
	CPIcon9.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_09_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon10 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon10:SetPos( 83, 173 )
	CPIcon10:SetModel( "models/purvis/male_18_metrocop.mdl" )
	CPIcon10.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_18_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon11 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon11:SetPos( 151, 173 )
	CPIcon11:SetModel( "models/purvis/male_12_metrocop.mdl" )
	CPIcon11.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_12_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon12 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon12:SetPos( 219, 173 )
	CPIcon12:SetModel( "models/purvis/male_25_metrocop.mdl" )
	CPIcon12.DoClick = function()
		LocalPlayer():SetModel( "models/purvis/male_25_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon13 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon13:SetPos( 15, 242 )
	CPIcon13:SetModel( "models/c08cop.mdl" )
	CPIcon13.DoClick = function()
		LocalPlayer():SetModel( "models/c08cop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon14 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon14:SetPos( 83, 242 )
	CPIcon14:SetModel( "models/police_female_finalcop.mdl" )
	CPIcon14.DoClick = function()
		LocalPlayer():SetModel( "models/police_female_finalcop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon15 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon15:SetPos( 151, 242 )
	CPIcon15:SetModel( "models/c08cop_female.mdl" )
	CPIcon15.DoClick = function()
		LocalPlayer():SetModel( "models/c08cop_female.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon16 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon16:SetPos( 219, 242 )
	CPIcon16:SetModel( "models/barney.mdl" )
	CPIcon16.DoClick = function()
		LocalPlayer():SetModel( "models/barney.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	NoticeLabel1 = vgui.Create( "DLabel", MFrame );
	NoticeLabel1:SetPos( 15, 316 );
	NoticeLabel1:SetText( "To change your model, simply click the icon of your choice." );
	NoticeLabel1:SizeToContents();

	NoticeLabel2 = vgui.Create( "DLabel", MFrame );
	NoticeLabel2:SetPos( 15, 328 );
	NoticeLabel2:SetText( "The window will then close, setting your model also." );
	NoticeLabel2:SizeToContents();

	else

	LocalPlayer():PrintMessage( 3, "You need to be a CP to use this command!" );
end	
end
   concommand.Add( "rp_selectcpmodel", SelectCPModel )