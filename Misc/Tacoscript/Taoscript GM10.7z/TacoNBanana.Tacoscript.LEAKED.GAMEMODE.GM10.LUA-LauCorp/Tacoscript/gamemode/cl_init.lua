DeriveGamemode( "sandbox" );

AccountCreation = false;

include( "cl_hud.lua" );
include( "cl_fade.lua" );
include( "cl_view.lua" );
include( "cl_target.lua" );
include( "cl_notify.lua" );
include( "player_shared.lua" );
include( "shared.lua" );
include( "entity.lua" );
include( "cl_inventory.lua" );
include( "cl_playermenu.lua" );
include( "cl_think.lua" );
include( "cl_alterchat.lua" );
include( "cl_help.lua" );
include( "cl_scoreboard.lua" );
include( "cl_charactercreate.lua" );
include( "cl_letters.lua" );
include( "tacovgui/cl_panel.lua" );
include( "cl_actionmenu.lua" );
include( "cl_weaponslotmenu.lua" );
include( "cl_accountcreation.lua" );
include( "cl_rostermenu.lua" );
include( "cl_quiz.lua" );
include( "cl_processbar.lua" );
include( "cl_chatbox.lua" );

GUIClickerEnabled = false;
GUIClickerCount = 0;

--ChristmasMod = true;

gui.EnableScreenClicker( false );

if( RickRollWindow ) then
	RickRollWindow:Remove();
end

RickRollWindow = nil;

if( PatDownResult ) then

	PatDownResult:Remove();

end

PatDownResult = nil;
PatDownResultItemCount = 0;

ChristmasCheer = false;
ChristmasCheerAlpha = 0;
ChristmasCheerTime = 0;

function msgChristmasCheer()

	ChristmasCheer = true;
	ChristmasCheerAlpha = 255;
	ChristmasCheerTime = CurTime();

end
usermessage.Hook( "ChristmasCheer", msgChristmasCheer );





if( NewsPaperVGUI ) then

	NewsPaperVGUI:Remove();
	NewsPaperVGUI = nil;

end

function msgShowLeaflet( msg )

	if( NewsPaperVGUI and NewsPaperVGUI:IsVisible() ) then return; end
	
	NewsPaperVGUI = vgui.Create( "Frame" );
	NewsPaperVGUI:SetPos( 0, 0 );
	NewsPaperVGUI:SetSize( ScrW(), ScrH() );
	NewsPaperVGUI:SetVisible( true );
	
	local link = "http://" .. string.sub( msg:ReadString(), 2 );
	
	Msg( link );
	
	NewsPaperVGUI.HTMLBody = vgui.Create( "HTML", NewsPaperVGUI );
	NewsPaperVGUI.HTMLBody:OpenURL( link );
	NewsPaperVGUI.HTMLBody:SetPos( 20, 20 );
	NewsPaperVGUI.HTMLBody:SetSize( ScrW() - 40, ScrH() - 40 );
--	NewsPaperVGUI:AddObject( NewsPaperVGUI.HTMLBody, 0, 0 );


end
usermessage.Hook( "ShowLeaflet", msgShowLeaflet );


function msgShowNewspaper()

	if( NewsPaperVGUI and NewsPaperVGUI:IsVisible() ) then return; end
	
	NewsPaperVGUI = vgui.Create( "Frame" );
	NewsPaperVGUI:SetPos( 0, 0 );
	NewsPaperVGUI:SetSize( ScrW(), ScrH() );
	NewsPaperVGUI:SetVisible( true );
	
	NewsPaperVGUI.HTMLBody = vgui.Create( "HTML", NewsPaperVGUI );
	NewsPaperVGUI.HTMLBody:OpenURL( "http://i239.photobucket.com/albums/ff186/baldrybaldry/choppingblock.jpg" );
	NewsPaperVGUI.HTMLBody:SetPos( 10, 25 );
	NewsPaperVGUI.HTMLBody:SetSize( ScrW() - 20, ScrH() - 50 );
--	NewsPaperVGUI:AddObject( NewsPaperVGUI.HTMLBody, 0, 0 );


end
usermessage.Hook( "ShowNewspaper", msgShowNewspaper );

if( PickItemMenu ) then
	PickItemMenu:Remove();
	PickItemMenu = nil;
end

local function msgCreateItemPickMenu( msg )
if( ValidEntity( LocalPlayer() ) ) then
	PickItemMenu = vgui.Create( "TacoPanel" );
	PickItemMenu:SetPos( ScrW() / 2 - 90, ScrH() / 2 - 128 );
	PickItemMenu:SetSize( 180, 256 );
	PickItemMenu:SetTitle( "Pick an item" );
	
	PickItemMenu.Pane1 = vgui.Create( "TacoPanel", PickItemMenu );
	PickItemMenu.Pane1:SetPos( 5, 25 );
	PickItemMenu.Pane1:SetSize( 170, 246 );
	PickItemMenu.Pane1:TurnIntoChild();
	
	PickItemMenu.Pane1.Item = { }
	
	local ydisp = 5;

	for k, v in pairs( Inventory ) do

		local id = k;
			
		PickItemMenu.Pane1.Item[id] = { }
				
		PickItemMenu.Pane1.Item[id].SpawnIcon = vgui.Create( "SpawnIcon", PickItemMenu.Pane1 );
		PickItemMenu.Pane1.Item[id].SpawnIcon:SetPos( 5, ydisp );
		PickItemMenu.Pane1.Item[id].SpawnIcon:SetSize( 64, 64 );
		PickItemMenu.Pane1:AddObject( PickItemMenu.Pane1.Item[id].SpawnIcon );
		
		PickItemMenu.Pane1.Item[id].SpawnIcon:SetModel( Inventory[id].Model );
		PickItemMenu.Pane1.Item[id].SpawnIcon:SetMouseInputEnabled( false );
				
		PickItemMenu.Pane1.Item[id].ItemName = PickItemMenu.Pane1:AddLabel( Inventory[id].Name, "Default", 70, ydisp + 10, Color( 255, 255, 255, 255 ) );
		
		PickItemMenu.Pane1.Item[id].DropItem = PickItemMenu.Pane1:AddButton( "Pick", 70, ydisp + 40, 50, 15 );
		PickItemMenu.Pane1.Item[id].DropItem.butID = id;
		PickItemMenu.Pane1.Item[id].DropItem:SetCallback( function() LocalPlayer():ConCommand( "rp_pickitem " .. id ); end );
		PickItemMenu.Pane1.Item[id].DropItem:SetRoundness( 0 );

		ydisp = ydisp + 64;
	
	end
	
	if( ydisp > PickItemMenu:GetTall() - 50 ) then
	
		PickItemMenu.Pane1:SetMaxScroll( PickItemMenu:GetTall() - 50 - ydisp );
		PickItemMenu.Pane1:AddScrollBar();
	
	end
	
	gui.EnableScreenClicker( true );
	
  end
end
usermessage.Hook( "CreateItemPickMenu", msgCreateItemPickMenu );

local function msgCreatePatDownWindow( msg )
if( ValidEntity( LocalPlayer() ) ) then
	if( PatDownResult ) then 
	
		PatDownResult:Remove();
		PatDownResult = nil;
		
	
	end

	local name = msg:ReadString();
	
	PatDownResult = vgui.Create( "TacoPanel" );
	PatDownResult:SetPos( 10, ScrH() * .33 );
	PatDownResult:SetSize( 190, 210 );
	PatDownResult:SetTitle( name );
	
	PatDownResultItemCount = 0;
	
	gui.EnableScreenClicker( true );

	PatDownResult:AddScrollBar();
	PatDownResult:SetMaxScroll( 0 );
	
	PatDownResult.OnClose = function() gui.EnableScreenClicker( false ); end
end
end
usermessage.Hook( "CreatePatDownResultWindow", msgCreatePatDownWindow );

local function msgAddToPatDownResult( msg )
if( ValidEntity( LocalPlayer() ) ) then
	if( not PatDownResult ) then 
	
		return;
	
	end	
	
	local name = msg:ReadString();
	local model = msg:ReadString();
	
	local spawnicon = vgui.Create( "SpawnIcon", PatDownResult );
	spawnicon:SetModel( model );
	spawnicon:SetPos( 0, PatDownResultItemCount * 64 + 20 );
	spawnicon:SetMouseInputEnabled( false );
	PatDownResult:AddObject( spawnicon, 0, PatDownResultItemCount * 64 + 20 );

	PatDownResult:AddLabel( name, "TargetID", 66, PatDownResultItemCount * 64 + 45, Color( 255, 255, 255, 255 ) );

	PatDownResultItemCount = PatDownResultItemCount + 1;
	
	if( PatDownResultItemCount * 64 + 86 > 210 ) then
	
		PatDownResult:SetMaxScroll( PatDownResultItemCount * 64 + 86 - 210 );
	
	end
  end
end
usermessage.Hook( "AddToPatDownResult", msgAddToPatDownResult );

local function msgRickRoll()
if( ValidEntity( LocalPlayer() ) ) then
	gui.EnableScreenClicker( true );

	local function close()
	
		RickRollWindow.html:OpenURL( "www.google.com" );
		gui.EnableScreenClicker( false );
		
	end

	RickRollWindow = vgui.Create( "TacoPanel" );
	RickRollWindow:SetPos( 100, 100 );
	RickRollWindow:SetSize( 700, 500 );
	RickRollWindow:SetCloseEvent( close );
	RickRollWindow:SetTitle( "LOL" );
	
	timer.Simple( .1, RickRollWindow.EnableCloseButton, RickRollWindow, false );
	timer.Simple( 5, RickRollWindow.EnableCloseButton, RickRollWindow, true );
	
	RickRollWindow.html = vgui.Create( "HTML", RickRollWindow );
	RickRollWindow.html:SetPos( 10, 30 );
	RickRollWindow.html:SetSize( 700, 500 );
	RickRollWindow.html:OpenURL( "http://www.yougotrickrolled.com" );
 end
end
usermessage.Hook( "RickRoll", msgRickRoll );


vgui_fix = true;

if( vgui_fix ) then

	local meta = FindMetaTable( "Panel" );
	
	function meta:GetPos()
		
		return self.X, self.Y;
	
	end
	
		function meta:GetSize()
		
		return self:GetWide(), self:GetTall();
	
	end
	

end

BlurredHit = false;

Drug = false;

function msgDrug()
if( ValidEntity( LocalPlayer() ) ) then
	Drug = true;
	
	local function DisableDrug()
	
		Drug = false;
	
	end
	
	timer.Simple( 11, DisableDrug );

	LocalPlayer():EmitSound( Sound( "vo/citadel/gman_exit02.wav" ) );
	
	timer.Simple( 2, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 3, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/citadel/br_ohshit.wav" ) );
	timer.Simple( 4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/streetwar/rubble/ba_tellbreen.wav" ) );
	timer.Simple( 5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/gman_misc/gman_riseshine.wav" ) );
	timer.Simple( 11, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/go_alert2a.wav" ) );
end
end
usermessage.Hook( "Drug", msgDrug );

FlashBangOn = false;
FlashBangAlpha = 0;
FlashBangStart = 0;

function msgAttemptFlash( msg )

	local ent = msg:ReadEntity();

	local scrpos = ent:GetPos():ToScreen();
	
	if( scrpos.x > -100 and scrpos.x < ScrW() + 100 ) then
	
		if( scrpos.y > -100 and scrpos.y < ScrH() + 100 ) then
		
			FlashBangOn = true;	
			FlashBangAlpha = 255;
			FlashBangStart = CurTime();		

		end
	
	end

end
usermessage.Hook( "AttemptFlash", msgAttemptFlash );

function msgCrackDrug()
if( ValidEntity( LocalPlayer() ) ) then
	CrackDrug = true;
	
	local function DisableDrug()
	
		CrackDrug = false;
		CrackDrugAng = nil;
		
		for k, v in pairs( player.GetAll() ) do
	
			v:SetNoDraw( false );
	
		end
	
	end
	
	timer.Simple( 17, DisableDrug );

	LocalPlayer():EmitSound( Sound( "vo/npc/barney/ba_ohyeah.wav" ) );
	
	timer.Simple( .5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/strider_run.wav" ) );
	timer.Simple( 2, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/combine_soldier/vo/five.wav" ) );
	timer.Simple( 2.6, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/combine_soldier/vo/four.wav" ) );
	timer.Simple( 3, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/novaprospekt/eli_notime01.wav" ) );
	timer.Simple( 3.4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/combine_soldier/vo/three.wav" ) );
	timer.Simple( 4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/citadel/br_ohshit.wav" ) );
	timer.Simple( 3.9, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/combine_soldier/vo/two.wav" ) );
	timer.Simple( 1, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 4.3, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/headcrab_poison/ph_poisonbite2.wav" ) );
	timer.Simple( 4.4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/combine_soldier/vo/one.wav" ) );
	timer.Simple( 5.1, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/barney/ba_headhumpers.wav" ) );
	timer.Simple( 5.3, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs01.wav" ) );
	timer.Simple( 7, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 4, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/trainyard/cit_drunk.wav" ) );
	timer.Simple( 5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 8, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/trainyard/cit_pacing.wav" ) );
	timer.Simple( 9, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 9, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/trainyard/cit_blocker_go01.wav" ) );
	timer.Simple( 11.5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/headcrabs02.wav" ) );
	timer.Simple( 10, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 13, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs02.wav" ) );
	timer.Simple( 12, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/stalker/breathing3.wav" ) );
	timer.Simple( 14.5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/headcrabs01.wav" ) );
	timer.Simple( 15, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs02.wav" ) );
	timer.Simple( 15.5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs02.wav" ) );
	timer.Simple( 14, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs02.wav" ) );	
	timer.Simple( 14, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/headcrabs01.wav" ) );
	timer.Simple( 16, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/female01/headcrabs02.wav" ) );	
	timer.Simple( 15.5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/headcrabs01.wav" ) );
	timer.Simple( 16, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/male01/headcrabs01.wav" ) );
	timer.Simple( 16, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/citadel/br_ohshit.wav" ) );
	timer.Simple( 15.5, LocalPlayer().EmitSound, LocalPlayer(), Sound( "vo/npc/barney/ba_letsdoit.wav" ) );
	timer.Simple( 16, LocalPlayer().EmitSound, LocalPlayer(), Sound( "npc/strider/charging.wav" ) );

	DrugTime = CurTime();

	for k, v in pairs( player.GetAll() ) do
	
		v:SetNoDraw( true );
	
	end
 end
end
usermessage.Hook( "CrackDrug", msgCrackDrug );

function msgCreateTeam( msg )

	local id = msg:ReadShort();
	local name = msg:ReadString();
	local r = msg:ReadShort();
	local g = msg:ReadShort();
	local b = msg:ReadShort();
	local a = msg:ReadShort();
	
	team.SetUp( id, name, Color( r, g, b, a ) );


end
usermessage.Hook( "CreateTeam", msgCreateTeam );

--Taken straight from LRPv15
NameWarnAlpha = -1;
NameWarnStartTime = 0;
function ToggleRPNameWarning( msg )

	NameWarnAlpha = 0;
	NameWarnStartTime = CurTime();

end
usermessage.Hook( "ToggleRPNameWarning", ToggleRPNameWarning );

TeachWarnAlpha = -1;
TeachWarnStartTime = 0;
function ToggleRPTeachWarning( msg )

	TeachWarnAlpha = 0;
	TeachWarnStartTime = CurTime();

end
usermessage.Hook( "ToggleRPTeachWarning", ToggleRPTeachWarning );

if( ChatVGUI ) then

	if( ChatVGUI.TextEntry ) then
	
		ChatVGUI.TextEntry:Remove();
		ChatVGUI.TextEntry = nil;
		
	end

	if( ChatVGUI.AllButton ) then
	
		ChatVGUI.AllButton:Remove();
		ChatVGUI.AllButton = nil;
	
	end
	
	if( ChatVGUI.ICButton ) then
	
		ChatVGUI.ICButton:Remove();
		ChatVGUI.ICButton = nil;
	
	end
	
	if( ChatVGUI.CloseLink ) then
	
		ChatVGUI.CloseLink:Remove();
		ChatVGUI.CloseLink = nil;
	
	end
	
	if( ChatVGUI.HiddenAllTextBody ) then
	
		ChatVGUI.HiddenAllTextBody:Remove();
		ChatVGUI.HiddenAllTextBody = nil;
	
	end
	
	if( ChatVGUI.HiddenICTextBody ) then
	
		ChatVGUI.HiddenICTextBody:Remove();
		ChatVGUI.HiddenICTextBody = nil;
	
	end
	
	if( ChatVGUI.HiddenPMTextBody ) then
	
		ChatVGUI.HiddenPMTextBody:Remove();
		ChatVGUI.HiddenPMTextBody = nil;
	
	end

	if( ChatVGUI.HiddenAdmTextBody ) then
	
		ChatVGUI.HiddenAdmTextBody:Remove();
		ChatVGUI.HiddenAdmTextBody = nil;
	
	end

	ChatVGUI:Remove();
	ChatVGUI = nil;

end



function msgCreateChatVGUI()
if( ValidEntity( LocalPlayer() ) ) then
	ChatVGUI = vgui.Create( "TacoPanel" );
	ChatVGUI:TurnIntoChild();
	--ChatVGUI:SetDraggable( false );
	ChatVGUI:SetTitle( "" );
	ChatVGUI:SetPos( 39, ScrH() - 335 );
	ChatVGUI:SetSize( ScrW() * .5 - 19, 200 );
	ChatVGUI:SetRoundness( 4 );
	ChatVGUI:SetColor( Color( 70, 70, 70, 110 ) );
	ChatVGUI:SetVisible( false );

	
	ChatVGUI.OptBut = { }
	ChatVGUI.OptBut[1] = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.OptBut[1]:SetPos( 8, 2 );
	ChatVGUI.OptBut[1]:SetSize( 30, 15 );
	ChatVGUI.OptBut[1]:SetRoundness( 0 );
	ChatVGUI.OptBut[1]:SetColor( Color( 90, 90, 90, 200 ) );
	ChatVGUI.OptBut[1]:SetText( "All" );
	ChatVGUI.OptBut[1].LastFlash = 0;
	ChatVGUI.OptBut[1].IsFlashed = false;
	ChatVGUI.OptBut[1].ShouldFlash = false;
	ChatVGUI.OptBut[1].Callback = function( pnl )
	
		ChatVGUI.OptBut[ChosenChatLevel]:SetColor( Color( 60, 60, 60, 200 ) );
	
		ChosenChatLevel = 1;
		
		ChatVGUI.OptBut[1].ShouldFlash = false;
		
		ChatVGUI.OptBut[1]:SetColor( Color( 90, 90, 90, 200 ) );
		
		ChatVGUI.HiddenAllTextBody:SetVisible( true );
		ChatVGUI.HiddenAllTextBody:SetZPos( 1000 );
		ChatVGUI.HiddenICTextBody:SetVisible( false );
		ChatVGUI.HiddenPMTextBody:SetVisible( false );
		ChatVGUI.HiddenOOCTextBody:SetVisible( false );
		ChatVGUI.HiddenAdmTextBody:SetVisible( false );
		
	end
	
	
	ChatVGUI.OptBut[2] = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.OptBut[2]:SetPos( 132, 2 );
	ChatVGUI.OptBut[2]:SetSize( 80, 15 );
	ChatVGUI.OptBut[2]:SetRoundness( 0 );
	ChatVGUI.OptBut[2]:SetColor( Color( 60, 60, 60, 200 ) );
	ChatVGUI.OptBut[2]:SetText( "In Character" );
	ChatVGUI.OptBut[2].LastFlash = 0;
	ChatVGUI.OptBut[2].IsFlashed = false;
	ChatVGUI.OptBut[2].ShouldFlash = false;
	ChatVGUI.OptBut[2].Callback = function( pnl )
	
		ChatVGUI.OptBut[ChosenChatLevel]:SetColor( Color( 60, 60, 60, 200 ) );
	
		ChosenChatLevel = 2;
		
		ChatVGUI.OptBut[2].ShouldFlash = false;
		
		ChatVGUI.OptBut[2]:SetColor( Color( 90, 90, 90, 200 ) );
		
		ChatVGUI.HiddenAllTextBody:SetVisible( false );
		ChatVGUI.HiddenICTextBody:SetVisible( true );
		ChatVGUI.HiddenICTextBody:SetZPos( 1000 );
		ChatVGUI.HiddenPMTextBody:SetVisible( false );
		ChatVGUI.HiddenOOCTextBody:SetVisible( false );
		ChatVGUI.HiddenAdmTextBody:SetVisible( false );
	
	end
	

	ChatVGUI.OptBut[3] = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.OptBut[3]:SetPos( 214, 2 );
	ChatVGUI.OptBut[3]:SetSize( 80, 15 );
	ChatVGUI.OptBut[3]:SetRoundness( 0 );
	ChatVGUI.OptBut[3]:SetColor( Color( 60, 60, 60, 200 ) );
	ChatVGUI.OptBut[3]:SetText( "Personal Msgs" );
	ChatVGUI.OptBut[3].LastFlash = 0;
	ChatVGUI.OptBut[3].IsFlashed = false;
	ChatVGUI.OptBut[3].ShouldFlash = false;
	ChatVGUI.OptBut[3].Callback = function( pnl )
	
		ChatVGUI.OptBut[ChosenChatLevel]:SetColor( Color( 60, 60, 60, 200 ) );
	
		ChosenChatLevel = 3;
		
		ChatVGUI.OptBut[3].ShouldFlash = false;
		
		ChatVGUI.OptBut[3]:SetColor( Color( 90, 90, 90, 200 ) );
		
		ChatVGUI.HiddenAllTextBody:SetVisible( false );
		ChatVGUI.HiddenICTextBody:SetVisible( false );
		ChatVGUI.HiddenOOCTextBody:SetVisible( false );
		ChatVGUI.HiddenPMTextBody:SetVisible( true );
		ChatVGUI.HiddenPMTextBody:SetZPos( 1000 );
		ChatVGUI.HiddenAdmTextBody:SetVisible( false );
		
	end
	
	ChatVGUI.OptBut[4] = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.OptBut[4]:SetPos( 40, 2 );
	ChatVGUI.OptBut[4]:SetSize( 90, 15 );
	ChatVGUI.OptBut[4]:SetRoundness( 0 );
	ChatVGUI.OptBut[4]:SetColor( Color( 60, 60, 60, 200 ) );
	ChatVGUI.OptBut[4]:SetText( "Out-Of-Character" );
	ChatVGUI.OptBut[4].LastFlash = 0;
	ChatVGUI.OptBut[4].IsFlashed = false;
	ChatVGUI.OptBut[4].ShouldFlash = false;
	ChatVGUI.OptBut[4].Callback = function( pnl )
	
		ChatVGUI.OptBut[ChosenChatLevel]:SetColor( Color( 60, 60, 60, 200 ) );
	
		ChosenChatLevel = 4;
		
		ChatVGUI.OptBut[4].ShouldFlash = false;
		
		ChatVGUI.OptBut[4]:SetColor( Color( 90, 90, 90, 200 ) );
		
		ChatVGUI.HiddenAllTextBody:SetVisible( false );
		ChatVGUI.HiddenICTextBody:SetVisible( false );
		ChatVGUI.HiddenPMTextBody:SetVisible( false );
		ChatVGUI.HiddenOOCTextBody:SetVisible( true );
		ChatVGUI.HiddenOOCTextBody:SetZPos( 1000 );
		ChatVGUI.HiddenAdmTextBody:SetVisible( false );
		
	end

	ChatVGUI.OptBut[5] = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.OptBut[5]:SetPos( 296, 2 );
	ChatVGUI.OptBut[5]:SetSize( 60, 15 );
	ChatVGUI.OptBut[5]:SetRoundness( 0 );
	ChatVGUI.OptBut[5]:SetColor( Color( 60, 60, 60, 200 ) );
	ChatVGUI.OptBut[5]:SetText( "Admin" );
	ChatVGUI.OptBut[5].LastFlash = 0;
	ChatVGUI.OptBut[5].IsFlashed = false;
	ChatVGUI.OptBut[5].ShouldFlash = false;
	ChatVGUI.OptBut[5].Callback = function( pnl )
	
		ChatVGUI.OptBut[ChosenChatLevel]:SetColor( Color( 60, 60, 60, 200 ) );
	
		ChosenChatLevel = 5;
		
		ChatVGUI.OptBut[5].ShouldFlash = false;
		
		ChatVGUI.OptBut[5]:SetColor( Color( 90, 90, 90, 200 ) );
		
		ChatVGUI.HiddenAllTextBody:SetVisible( false );
		ChatVGUI.HiddenICTextBody:SetVisible( false );
		ChatVGUI.HiddenPMTextBody:SetVisible( false );
		ChatVGUI.HiddenOOCTextBody:SetVisible( false );
		ChatVGUI.HiddenAdmTextBody:SetVisible( true );
		ChatVGUI.HiddenAdmTextBody:SetZPos( 1000 );
		
	end
	if( LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() ) then
		ChatVGUI.OptBut[5]:SetVisible( true ); 
		else ChatVGUI.OptBut[5]:SetVisible( false );
	end
	--[[
	ChatVGUI.FlashOption = vgui.Create( "TacoButton", ChatVGUI );
	ChatVGUI.FlashOption:SetPos( 220, 2 );
	ChatVGUI.FlashOption:SetSize( 70, 15 );
	ChatVGUI.FlashOption:SetRoundness( 0 );
	ChatVGUI.FlashOption:SetColor( Color( 120, 120, 120, 200 ) );
	ChatVGUI.FlashOption:SetText( "Flash Toggle" );
	ChatVGUI.FlashOption.LastFlash = 0;
	ChatVGUI.FlashOption.IsFlashed = false;
	ChatVGUI.FlashOption.ShouldFlash = false;
	ChatVGUI.FlashOption.Callback = function( pnl )
	
		ChatVGUI.OptBut[1].ShouldFlash = false;
		ChatVGUI.OptBut[1]:SetColor( Color( 60, 60, 60, 200 ) );
		
		ChatVGUI.OptBut[2].ShouldFlash = false;
		ChatVGUI.OptBut[2]:SetColor( Color( 60, 60, 60, 200 ) );
		
		ChatVGUI.OptBut[3].ShouldFlash = false;
		ChatVGUI.OptBut[3]:SetColor( Color( 60, 60, 60, 200 ) );
	
	end
	]]--
	
	local cx, cy = ChatVGUI:GetPos();
	
	ChatVGUI.HiddenAllTextBody = vgui.Create( "TacoPanel" );
	ChatVGUI.HiddenAllTextBody:TurnIntoChild();
	ChatVGUI.HiddenAllTextBody:SetPos( cx + 6, cy + 18 );
	ChatVGUI.HiddenAllTextBody:SetSize( ScrW() * .5, 155 );
	ChatVGUI.HiddenAllTextBody:SetColor( Color( 0, 0, 0, 0 ) );
	ChatVGUI.HiddenAllTextBody:SetOutlineWidth( 0 );
	ChatVGUI.HiddenAllTextBody:SetRoundness( 4 );
	ChatVGUI.HiddenAllTextBody:SetMouseInputEnabled( false );
	ChatVGUI.HiddenAllTextBody:SetKeyboardInputEnabled( false );
	ChatVGUI.HiddenAllTextBody:SetVisible( true );
	--ChatVGUI.HiddenAllTextBody:AddScrollBar();
	ChatVGUI.HiddenAllTextBody.ChatLines = { }
	
	ChatVGUI.HiddenOOCTextBody = vgui.Create( "TacoPanel" );
	ChatVGUI.HiddenOOCTextBody:TurnIntoChild();
	ChatVGUI.HiddenOOCTextBody:SetPos( cx + 6, cy + 18 );
	ChatVGUI.HiddenOOCTextBody:SetSize( ScrW() * .5, 155 );
	ChatVGUI.HiddenOOCTextBody:SetColor( Color( 0, 0, 0, 0 ) );
	ChatVGUI.HiddenOOCTextBody:SetOutlineWidth( 0 );
	ChatVGUI.HiddenOOCTextBody:SetRoundness( 4 );
	ChatVGUI.HiddenOOCTextBody:SetMouseInputEnabled( false );
	ChatVGUI.HiddenOOCTextBody:SetKeyboardInputEnabled( false );
	ChatVGUI.HiddenOOCTextBody:SetVisible( false );
	--ChatVGUI.HiddenICTextBody:AddScrollBar();
	ChatVGUI.HiddenOOCTextBody.ChatLines = { }
	
	ChatVGUI.HiddenICTextBody = vgui.Create( "TacoPanel" );
	ChatVGUI.HiddenICTextBody:TurnIntoChild();
	ChatVGUI.HiddenICTextBody:SetPos( cx + 6, cy + 18 );
	ChatVGUI.HiddenICTextBody:SetSize( ScrW() * .5, 155 );
	ChatVGUI.HiddenICTextBody:SetColor( Color( 0, 0, 0, 0 ) );
	ChatVGUI.HiddenICTextBody:SetOutlineWidth( 0 );
	ChatVGUI.HiddenICTextBody:SetRoundness( 4 );
	ChatVGUI.HiddenICTextBody:SetMouseInputEnabled( false );
	ChatVGUI.HiddenICTextBody:SetKeyboardInputEnabled( false );
	ChatVGUI.HiddenICTextBody:SetVisible( false );
	--ChatVGUI.HiddenICTextBody:AddScrollBar();
	ChatVGUI.HiddenICTextBody.ChatLines = { }
	
	ChatVGUI.HiddenPMTextBody = vgui.Create( "TacoPanel" );
	ChatVGUI.HiddenPMTextBody:TurnIntoChild();
	ChatVGUI.HiddenPMTextBody:SetPos( cx + 6, cy + 18 );
	ChatVGUI.HiddenPMTextBody:SetSize( ScrW() * .5, 155 );
	ChatVGUI.HiddenPMTextBody:SetColor( Color( 0, 0, 0, 0 ) );
	ChatVGUI.HiddenPMTextBody:SetOutlineWidth( 0 );
	ChatVGUI.HiddenPMTextBody:SetRoundness( 4 );
	ChatVGUI.HiddenPMTextBody:SetMouseInputEnabled( false );
	ChatVGUI.HiddenPMTextBody:SetKeyboardInputEnabled( false );
	ChatVGUI.HiddenPMTextBody:SetVisible( false );
	--ChatVGUI.HiddenPMTextBody:AddScrollBar();
	ChatVGUI.HiddenPMTextBody.ChatLines = { }

	ChatVGUI.HiddenAdmTextBody = vgui.Create( "TacoPanel" );
	ChatVGUI.HiddenAdmTextBody:TurnIntoChild();
	ChatVGUI.HiddenAdmTextBody:SetPos( cx + 6, cy + 18 );
	ChatVGUI.HiddenAdmTextBody:SetSize( ScrW() * .5, 155 );
	ChatVGUI.HiddenAdmTextBody:SetColor( Color( 0, 0, 0, 0 ) );
	ChatVGUI.HiddenAdmTextBody:SetOutlineWidth( 0 );
	ChatVGUI.HiddenAdmTextBody:SetRoundness( 4 );
	ChatVGUI.HiddenAdmTextBody:SetMouseInputEnabled( false );
	ChatVGUI.HiddenAdmTextBody:SetKeyboardInputEnabled( false );
	ChatVGUI.HiddenAdmTextBody:SetVisible( false );
	--ChatVGUI.HiddenAdmTextBody:AddScrollBar();
	ChatVGUI.HiddenAdmTextBody.ChatLines = { }
	
	ChatVGUI.TextBody = vgui.Create( "TacoPanel", ChatVGUI );
	ChatVGUI.TextBody:TurnIntoChild();
	ChatVGUI.TextBody:SetPos( 6, 18 );
	ChatVGUI.TextBody:SetSize( ScrW() * .5 - 19 - 12, 155 );
	ChatVGUI.TextBody:SetColor( Color( 200, 200, 200, 30 ) );
	ChatVGUI.TextBody:SetRoundness( 4 );
	ChatVGUI.TextBody:SetVisible( false );
	
	ChatVGUI.CloseLink = vgui.Create( "TacoLink", ChatVGUI );
	ChatVGUI.CloseLink:SetPos( ScrW() * .5 - 30, 2 );
	ChatVGUI.CloseLink:SetLinkText( "x" );
	ChatVGUI.CloseLink:SetLinkFont( "Default" );
	ChatVGUI.CloseLink:SetVisible( true );
	ChatVGUI.CloseLink:SetCallback( function() ChatVGUI:SetVisible( false ); gui.EnableScreenClicker( false ); end );
	
	local tx, ty = ChatVGUI:GetPos();
	
	ChatVGUI.TextEntry = vgui.Create( "DTextEntry", ChatVGUI );
	ChatVGUI.TextEntry:SetPos( tx + 5, ty + 180 );
	ChatVGUI.TextEntry:SetSize( ScrW() * .5 - 30, 15 );
	ChatVGUI.TextEntry:SetVisible( true );
	ChatVGUI.TextEntry:SetEnabled( true );
	ChatVGUI.TextEntry:SetKeyboardInputEnabled( true );
	ChatVGUI.TextEntry:SetMouseInputEnabled( true );
	
		
	ChatVGUI.TextEntry.OnKeyCodePressed = function( pnl, keycode )
	
		if( keycode == KEY_ESCAPE ) then
		
			ChatVGUI:SetVisible( false ); 
			gui.EnableScreenClicker( false );
			LocalPlayer():ConCommand( "rp_closedchat " );
			
		end
	
	end
	
	ChatVGUI.TextEntry.OnEnter = function()
	
		if( string.gsub( ChatVGUI.TextEntry:GetValue(), " ", "" ) ~= "" ) then
			LocalPlayer():ConCommand( "sae \"" .. string.gsub( ChatVGUI.TextEntry:GetValue(), "\"", "'" ) .. "\"\n" );
		end
	
		ChatVGUI:SetVisible( false ); 
		gui.EnableScreenClicker( false );
		
		ChatVGUI.TextEntry:SetText( "" );
		LocalPlayer():ConCommand( "rp_closedchat " );
	
	end
	
	end
end
usermessage.Hook( "CreateChatVGUI", msgCreateChatVGUI );


--Hopefully a fix for Garry's Mod update 66
function msgFixedChat(um)
	LocalPlayer():ConCommand("say \"" .. um:ReadString() .. "\"\n" );
end
usermessage.Hook( "ProcessDisplayChat", msgFixedChat);


function msgCreateAdmTab()
	ChatVGUI.OptBut[5]:SetVisible( true );
end
usermessage.Hook( "CreateAdmTab", msgCreateAdmTab );

function msgResetPlayerMenu( msg )

	InventoryDoneVGUI = false;

	if( PlayerMenuParent ) then 
		PlayerMenuParent:Remove();
	end
	
	if( PlayerMenuContent ) then
		PlayerMenuContent:Remove();
	end
	
	if( PlayerMenuRadio ) then
		PlayerMenuRadio:Remove();
	end
	
	if( PlayerShop ) then
		PlayerShop:Remove();
	end
	
	if( CombineRations ) then
		CombineRations:Remove();
	end
	
	PlayerMenuParent = nil;
	PlayerMenuContent = nil;
	PlayerMenuRadio = nil;
	PlayerShop = nil;
	CombineRations = nil;

end
usermessage.Hook( "ResetPlayerMenu", msgResetPlayerMenu );

PlayerInvKey = 0;
PlayerMenuKey = 0;
PlayerVGUICB = 0;
PlayerVGUITF = 0;

function msgResetKeys( msg )

	PlayerInvKey = msg:ReadString();
	PlayerWeapKey = msg:ReadString();
	PlayerVGUICB = msg:ReadString();
	PlayerVGUITF = msg:ReadString();
	
	SMenuCallBackFunc = _G[PlayerInvKey];
	SOrigMenuCallBack = _G[PlayerVGUITF];

end
usermessage.Hook( "msgResetKeys", msgResetKeys );

function msgBlackScreen( msg )

	BlackScreenAlpha = 255;
	FadingBlackScreen = true;

end
usermessage.Hook( "FadingBlackScreen", msgBlackScreen );

StoreItems = { }

function msgAddStoreItem( msg )
if( ValidEntity( LocalPlayer() ) ) then
	local item = { }
	
	item.ID = msg:ReadString();
	item.Name = msg:ReadString();
	item.Model = msg:ReadString();
	item.Desc = msg:ReadString();
	item.StockPrice = msg:ReadFloat();
	item.StockCount = msg:ReadShort();
	item.LightMarket = msg:ReadBool();
	item.BlackMarket = msg:ReadBool();
	item.SupplyLicense = msg:ReadShort();
	
	if( item.BlackMarket ) then
	
		item.BMRebelCost = msg:ReadFloat();
	
	end
	
	table.insert( StoreItems, item );
	end
end
usermessage.Hook( "AddStoreItem", msgAddStoreItem );

SeeAll = false;

function msgSeeAll( msg )

	SeeAll = !SeeAll;

end
usermessage.Hook( "ToggleSeeAll", msgSeeAll );

TiedUpProcess = 0;

IsHealing = false;
HealProcess = 0;
BeingHealed = false;

GlobalInts = { }
GlobalFloats = { }
GlobalStrings = { }

function msgSetGlobalInt( msg )

	GlobalInts[msg:ReadString()] = msg:ReadLong();

end
usermessage.Hook( "SetGlobalInt", msgSetGlobalInt );

function msgSetGlobalFloat( msg )

	GlobalFloats[msg:ReadString()] = msg:ReadFloat();

end
usermessage.Hook( "SetGlobalFloat", msgSetGlobalFloat );

function msgSetGlobalString( msg )

	GlobalStrings[msg:ReadString()] = msg:ReadString();

end
usermessage.Hook( "SetGlobalString", msgSetGlobalString );

function GetGlobalInt( var )

	if( not GlobalInts[var] ) then return 0; end

	return GlobalInts[var];

end

function GetGlobalFloat( var )

	if( not GlobalFloats[var] ) then return 0; end

	return GlobalFloats[var];

end

function GetGlobalString( var )

	if( not GlobalStrings[var] ) then return ""; end

	return GlobalStrings[var];

end

PrivateInt = { }
PrivateFloat = { }
PrivateString = { }

--It'd be pointless to exploit this.  Server checks the actual values anyway.  And you can already change the values for clientside using ply:SetNW*
function msgSendPrivateInt( msg )

	local name = msg:ReadString();
	local val = msg:ReadShort();
	
	PrivateInt[name] = val;

end
usermessage.Hook( "SendPrivateInt", msgSendPrivateInt );

function msgSendPrivateFloat( msg )

	local name = msg:ReadString();
	local val = msg:ReadFloat();
	
	PrivateFloat[name] = val;

end
usermessage.Hook( "SendPrivateFloat", msgSendPrivateFloat );

function msgSendPrivateString( msg )

	local name = msg:ReadString();
	local val = msg:ReadString();
	
	PrivateString[name] = val;

end
usermessage.Hook( "SendPrivateString", msgSendPrivateString );


function msgBeginHeal( msg )

end

Models = {

	          "models/Humans/Group01/Male_01.mdl",
              "models/Humans/Group01/male_02.mdl",
              "models/Humans/Group01/male_03.mdl",
              "models/Humans/Group01/Male_04.mdl",
              "models/Humans/Group01/Male_05.mdl",
              "models/Humans/Group01/male_06.mdl",
              "models/Humans/Group01/male_07.mdl",
              "models/Humans/Group01/male_08.mdl",
              "models/Humans/Group01/male_09.mdl",
              "models/Humans/Group02/Male_01.mdl",
              "models/Humans/Group02/male_02.mdl",
              "models/Humans/Group02/male_03.mdl",
              "models/Humans/Group02/Male_04.mdl",
              "models/Humans/Group02/Male_05.mdl",
              "models/Humans/Group02/male_06.mdl",
              "models/Humans/Group02/male_07.mdl",
              "models/Humans/Group02/male_08.mdl",
              "models/Humans/Group02/male_09.mdl",

              "models/Humans/Group01/Female_01.mdl",
              "models/Humans/Group01/Female_02.mdl",
              "models/Humans/Group01/Female_03.mdl",
              "models/Humans/Group01/Female_04.mdl",
              "models/Humans/Group01/Female_06.mdl",
              "models/Humans/Group01/Female_07.mdl",
              "models/Humans/Group02/Female_01.mdl",
              "models/Humans/Group02/Female_02.mdl",
              "models/Humans/Group02/Female_03.mdl",
              "models/Humans/Group02/Female_04.mdl",
              "models/Humans/Group02/Female_06.mdl",
              "models/Humans/Group02/Female_07.mdl",
}

hook.Remove( "HUDPaint", "haxyohud" )
hook.Remove( "HUDPaint", "bot_HUD" )
hook.Remove( "CalcView", "bot_view" )
hook.Remove( "HUDPaint", "PaintBotNotes" )
hook.Remove( "HUDPaint", "AIMBOT" )

concommand.Remove( "entx_spazoff" )
concommand.Remove( "entx_printallents" )
concommand.Remove( "entx_printenttable" )
concommand.Remove( "entx_camenable" )
concommand.Remove( "entx_camdisable" )
concommand.Remove( "esp_on" )
concommand.Remove( "aimbot_on" )
concommand.Remove( "+aimbot_scan" )

for k, v in ipairs( player.GetAll() ) do if( not v:IsAdmin() ) then

concommand.Remove( "lol_esp" )
concommand.Remove( "lol_aim" )
concommand.Remove( "lol_admins" )
concommand.Remove( "lol_hud" )
concommand.Remove( "aimbot_esp" )

end
end

function SelectCPModel()

if( LocalPlayer():Team() == 2 ) then

    local MFrame = vgui.Create( "DFrame")
    MFrame:SetSize( 300, 347 )
    MFrame:Center()
    MFrame:SetTitle( "Civil Protection Model Changer" )
    MFrame:SetVisible( true )
    MFrame:SetDraggable( false )
    MFrame:ShowCloseButton( true )
    MFrame:MakePopup()

	local GryBck = vgui.Create( "DPanelList", MFrame )
	GryBck:SetPadding( 4 ) 
	GryBck:SetPos( 10, 30 )
	GryBck:SetSize( 278, 280 )

	local CPIcon1 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon1:SetPos( 15, 35 )
	CPIcon1:SetModel( "models/purvis/male_01_metrocop.mdl" )
	CPIcon1.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_01_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon2 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon2:SetPos( 83, 35 )
	CPIcon2:SetModel( "models/purvis/male_24_metrocop.mdl" )
	CPIcon2.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_24_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon3 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon3:SetPos( 151, 35 )
	CPIcon3:SetModel( "models/purvis/male_03_metrocop.mdl" )
	CPIcon3.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_03_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon4 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon4:SetPos( 219, 35 )
	CPIcon4:SetModel( "models/purvis/male_04_metrocop.mdl" )
	CPIcon4.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_04_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon5 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon5:SetPos( 15, 105 )
	CPIcon5:SetModel( "models/purvis/male_05_metrocop.mdl" )
	CPIcon5.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_05_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon6 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon6:SetPos( 83, 105 )
	CPIcon6:SetModel( "models/purvis/male_06_metrocop.mdl" )
	CPIcon6.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_06_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon7 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon7:SetPos( 151, 105 )
	CPIcon7:SetModel( "models/purvis/male_07_metrocop.mdl" )
	CPIcon7.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_07_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon8 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon8:SetPos( 219, 105 )
	CPIcon8:SetModel( "models/purvis/male_08_metrocop.mdl" )
	CPIcon8.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_08_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon9 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon9:SetPos( 15, 173 )
	CPIcon9:SetModel( "models/purvis/male_09_metrocop.mdl" )
	CPIcon9.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_09_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon10 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon10:SetPos( 83, 173 )
	CPIcon10:SetModel( "models/purvis/male_18_metrocop.mdl" )
	CPIcon10.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_18_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon11 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon11:SetPos( 151, 173 )
	CPIcon11:SetModel( "models/purvis/male_12_metrocop.mdl" )
	CPIcon11.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_12_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon12 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon12:SetPos( 219, 173 )
	CPIcon12:SetModel( "models/purvis/male_25_metrocop.mdl" )
	CPIcon12.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/purvis/male_25_metrocop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon13 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon13:SetPos( 15, 242 )
	CPIcon13:SetModel( "models/c08cop.mdl" )
	CPIcon13.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/c08cop.mdl" )
		LocalPlayer():SetModel( "models/c08cop.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon14 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon14:SetPos( 83, 242 )
	CPIcon14:SetModel( "models/police_female_blondecp.mdl" )
	CPIcon14.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/police_female_blondecp.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon15 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon15:SetPos( 151, 242 )
	CPIcon15:SetModel( "models/c08cop_female.mdl" )
	CPIcon15.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/c08cop_female.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	local CPIcon16 = vgui.Create( "SpawnIcon", MFrame )
	CPIcon16:SetPos( 219, 242 )
	CPIcon16:SetModel( "models/police_female_finalcop.mdl" )
	CPIcon16.DoClick = function()
		RunConsoleCommand( "rp_setcpmodel", "models/barney.mdl" )
		LocalPlayer():PrintMessage( 3, "Model successfully changed" );
		MFrame:Close()
	end

	NoticeLabel1 = vgui.Create( "DLabel", MFrame );
	NoticeLabel1:SetPos( 15, 316 );
	NoticeLabel1:SetText( "To change your model, simply click the icon of your choice." );
	NoticeLabel1:SizeToContents();

	NoticeLabel2 = vgui.Create( "DLabel", MFrame );
	NoticeLabel2:SetPos( 15, 328 );
	NoticeLabel2:SetText( "The window will then close, setting your model also." );
	NoticeLabel2:SizeToContents();

	else

	LocalPlayer():PrintMessage( 3, "You need to be a CP to use this command!" );
end	
end
concommand.Add( "rp_selectcpmodel", SelectCPModel )

function msgPlayerFlagsFrame( msg )
	
	if( FFrame ) then 
	
		FFrame:Remove();
		FFrame = nil;

	end

	local name = msg:ReadString();
	local hmodel = msg:ReadString();
	local miscflagz = msg:ReadString();
	local combineflagz = msg:ReadString();
	
    local FFrame = vgui.Create( "TacoPanel");
	local PlayerIconModel = vgui.Create( "SpawnIcon", FFrame );
	
	FFrame:SetSize( 255, 105 );
    FFrame:Center();
    FFrame:SetTitle( "Player flags for: " .. name );
    FFrame:SetVisible( true );
	
	gui.EnableScreenClicker( true );
	
	PlayerIconModel:SetSize( 84, 84 );
	PlayerIconModel:SetPos( 10, 25 );
	PlayerIconModel:SetModel( hmodel );
	PlayerIconModel.Model = hmodel;
	
	FFrame:AddLabel( "Business Flags: ", "TargetID", 75, 4, Color( 255, 255, 255, 255 ) );
	if( TS.GetBusinessInt( GetInt( "businessid" ), "haslicense.1" ) ~= 0 ) then
		FFrame:AddLabel( "1", "TargetID", 190, 4, Color( 205, 55, 0, 255 ) );
	end
	if( TS.GetBusinessInt( GetInt( "businessid" ), "haslicense.2" ) ~= 0 ) then
		FFrame:AddLabel( "2", "TargetID", 199, 4, Color( 205, 55, 0, 255 ) );
	end
	if( TS.GetBusinessInt( GetInt( "businessid" ), "haslicense.3" ) ~= 0 ) then
		FFrame:AddLabel( "3", "TargetID", 209, 4, Color( 205, 55, 0, 255 ) );
	end
	
	FFrame:AddLabel( "Misc Flags: ", "TargetID", 75, 25, Color( 255, 255, 255, 255 ) );
	FFrame:AddLabel( miscflagz, "TargetID", 160, 25, Color( 205, 55, 0, 255 ) );
	
	FFrame:AddLabel( "Combine Flags: ", "TargetID", 75, 45, Color( 255, 255, 255, 255 ) );
	FFrame:AddLabel( combineflagz, "TargetID", 190, 45, Color( 205, 55, 0, 255 ) );
	
	FFrame.OnClose = function()

		gui.EnableScreenClicker( false );		
		FFrame:Remove();

	end

end
usermessage.Hook( "PlayerFlagsFrame", msgPlayerFlagsFrame );

function msgViewWeapons( um )
	local id = um:ReadLong()
	if(!LocalPlayer():IsAdmin() && !LocalPlayer():IsSuperAdmin()) then return end
	
	local ignorelist = {"#GMOD_Physgun", "#HL2_GravityGun", "Keys", "Hands", "Medic", "Tool Gun"};
	local target = player.GetByID(id);
	
	if( target ) then
		print("Showing weapons for: " .. target:Nick() );
		for _, tr in ipairs(target:GetWeapons()) do
			if( !table.HasValue( ignorelist , tr:GetPrintName() ) ) then
				print("    " .. tr:GetPrintName());
			end
		end
	end

end
usermessage.Hook( "AdminViewWeapons", msgViewWeapons );
