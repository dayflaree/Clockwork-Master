
ITEM.Name = "Briefcase";

ITEM.Weight = .5;
ITEM.Size = 1;
ITEM.Model = "models/props_c17/SuitCase_Passenger_Physics.mdl";
ITEM.Usable = false;

ITEM.License = 3;

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 125;
ITEM.FactoryStock = 2;
ITEM.Desc = "Portable storage";

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_case" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end

