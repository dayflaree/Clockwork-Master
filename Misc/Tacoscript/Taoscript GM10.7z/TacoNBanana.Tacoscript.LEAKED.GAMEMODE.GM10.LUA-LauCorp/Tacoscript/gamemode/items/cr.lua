ITEM.Name = "CR Device";

ITEM.Weight = .5;
ITEM.Size = .1;
ITEM.Model = "models/alyx_EmpTool_prop.mdl";
ITEM.Usable = false;
ITEM.Wearable = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 20;
ITEM.FactoryStock = 2;

ITEM.License = 2;

ITEM.Desc = "Use this to contact the Combine Civil Authority.";