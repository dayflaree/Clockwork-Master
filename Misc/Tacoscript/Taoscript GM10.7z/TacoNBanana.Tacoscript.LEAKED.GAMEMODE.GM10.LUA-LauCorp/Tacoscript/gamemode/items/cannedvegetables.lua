

ITEM.Name = "Canned Vegetables";

ITEM.Weight = .3;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Stringier than Mom's!";

ITEM.FactoryBuyable = true;
ITEM.License = 1;
ITEM.FactoryPrice = 12;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );

end

