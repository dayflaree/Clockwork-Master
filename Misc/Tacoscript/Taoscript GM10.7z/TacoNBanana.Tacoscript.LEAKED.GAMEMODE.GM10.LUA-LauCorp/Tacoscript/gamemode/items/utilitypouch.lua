
ITEM.Name = "Utility Pouch";

ITEM.Weight = .1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_defuser.mdl";
ITEM.Usable = false;
ITEM.Wearable = true;

ITEM.Desc = "A pouch to carry more items";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 30;
ITEM.FactoryStock = 3;

ITEM.License = 3;

function ITEM:CanPickup( ply )

	if( ply:HasItem( "utilitypouch" ) ) then
		ply:PrintMessage( 3, "You already have a utility pouch!" );
		return false;
	end
	
	return true;

end

function ITEM:OnPickup( )

	if( self.Owner:HasItem( "backpack" ) ) then
		self.Owner:SetField( "inventory.MaxSize", 48 );
		self.Owner:SetPrivateFloat( "inventory.MaxSize", 48 );
	else
		self.Owner:SetField( "inventory.MaxSize", 20 );
		self.Owner:SetPrivateFloat( "inventory.MaxSize", 20 );
		
	end
end

function ITEM:OnDrop( )

	if( self.Owner:HasItem( "backpack" ) ) then
		self.Owner:SetField( "inventory.MaxSize", 32 );
		self.Owner:SetPrivateFloat( "inventory.MaxSize", 32 );
	else
		self.Owner:SetField( "inventory.MaxSize", 6 );
		self.Owner:SetPrivateFloat( "inventory.MaxSize", 6 );
		
	end
end