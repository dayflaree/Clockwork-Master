ITEM.Name = "Tampered Ration";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/weapons/w_package.mdl";
ITEM.Usable = true;

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = "Canned Meat - Normal - Like Morphine";
ITEM.FactoryStock = 6;

ITEM.RebelCost = 4;

ITEM.Desc = "A Combine Ration with added tokens and canned meat loaf and rice";

function ITEM:OnUse()

self.Owner:SetNWFloat( "money", self.Owner:GetNWFloat( "money" ) + 90 );
self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 25, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
self.Owner:AddMaxStamina( 70 );

end