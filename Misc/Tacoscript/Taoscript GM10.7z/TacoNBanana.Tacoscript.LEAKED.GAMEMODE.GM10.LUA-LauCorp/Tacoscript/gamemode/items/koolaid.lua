


ITEM.Name = "Bottled Koolaid";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/GlassBottle01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Oh yeah!";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 8;
ITEM.FactoryStock = 20;

ITEM.License = 1;


function ITEM:OnUse()

	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 15, 0, 100 ) );
	self.Owner:AddMaxStamina( 14 );
	
end
