

ITEM.Name = "Canned Water";

ITEM.Weight = .1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/PopCan01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "It's eerily clean...";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryPrice = 15;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
self.Owner:AddMaxStamina( 15 );

		timer.Simple( .2, self.Owner.DropOneItem, self.Owner, self.UniqueID );
		timer.Simple( .2, self.Owner.CheckInventory, self.Owner );
		
end

