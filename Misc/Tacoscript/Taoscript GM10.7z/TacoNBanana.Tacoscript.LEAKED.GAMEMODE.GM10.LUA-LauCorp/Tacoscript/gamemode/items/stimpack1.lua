ITEM.Name = "Tetra-Propine";

ITEM.Weight = 2;
ITEM.Size = 1;
ITEM.Model = "models/Items/battery.mdl";
ITEM.Usable = true;

ITEM.Desc = "Magnifies replication of muscle cells";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 500;
ITEM.FactoryStock = 3;


function ITEM:OnUse()

	self.Owner:RaiseStat( "Strength", 2 );
	self.Owner:SaveCharacter();
	
end
