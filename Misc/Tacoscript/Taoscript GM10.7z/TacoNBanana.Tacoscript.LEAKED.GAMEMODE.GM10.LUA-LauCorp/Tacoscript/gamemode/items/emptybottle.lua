


ITEM.Name = "Empty Bottle";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/GlassBottle01a.mdl";
ITEM.Usable = false;

ITEM.Desc = "Emptiness in a bottle";

--ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 1;
ITEM.FactoryStock = 20;

ITEM.License = 1;

ITEM.IsContainer = true;
ITEM.ContainerSize = 1;

ITEM.Actions = 
{

	{ "Place Something Inside", "rp_ia_placeinside" }

}


