
ITEM.Name = "Old Spray Can";

ITEM.Weight = .3;
ITEM.Size = 1;
ITEM.Model = "models/Items/grenadeAmmo.mdl";
ITEM.Usable = false;

ITEM.Desc = "Dented and half empty..";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryPrice = 180;
ITEM.FactoryStock = 1;
