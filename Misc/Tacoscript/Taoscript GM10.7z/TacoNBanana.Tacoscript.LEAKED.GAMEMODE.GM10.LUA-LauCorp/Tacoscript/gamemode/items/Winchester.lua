

ITEM.Name = "Winchester Rifle";

ITEM.Weight = 1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_beef_m3super90.mdl";
ITEM.Usable = false;

ITEM.Desc = "Vintage Long Range Rifle";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 6000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 30;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_winchester" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
