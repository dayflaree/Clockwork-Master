
ITEM.Name = "Mac11";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_smg_mac10.mdl";
ITEM.Usable = false;

ITEM.Desc = "Compact Sub Machine gun, high right of fire, low accuracy";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 650;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 2;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_mac11" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end


