


ITEM.Name = "Mysterious Bottled Water";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/GlassBottle01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Some mysterious water in a bottle";

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 5;
ITEM.FactoryStock = 20;

ITEM.License = 1;

ITEM.CanMix = true;

function ITEM:OnUse()

	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:SetNWInt( "sprint", math.Clamp( self.Owner:GetNWInt( "sprint" ) + 15, 0, 100 ) );
	self.Owner:AddMaxStamina( 20 );

	umsg.Start( "Drug", self.Owner );
	umsg.End();
	
end
