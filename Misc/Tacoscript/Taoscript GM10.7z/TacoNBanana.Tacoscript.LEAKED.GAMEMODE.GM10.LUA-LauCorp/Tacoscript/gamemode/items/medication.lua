

ITEM.Name = "Medication";

ITEM.Weight = .2;
ITEM.Size = 1;
ITEM.Model = "models/props_lab/jar01a.mdl";
ITEM.Usable = true;

ITEM.Desc = "For Medicinal Use only";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 30;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

	self.Owner:TempStatBoost( "Endurance", 60, 600 );

	self.Owner:SetFOV( 60, 2.5 );
	
	timer.Simple( 17, self.Owner.SetFOV, self.Owner, 90, 3.5 );
	
	local function MakeKO( ply )
		ply:SetNWFloat( "conscious", 20 );
		ply:GoUnconscious();
	end
	
	timer.Simple( 17, MakeKO, self.Owner );

end

