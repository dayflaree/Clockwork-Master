

ITEM.Name = "Styer Aug";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_rif_aug.mdl";
ITEM.Usable = false;

ITEM.Desc = "Modern Bullpup Rifle";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 2200;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 20;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_styeraug" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end


