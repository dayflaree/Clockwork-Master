

ITEM.Name = "Healthvial";

ITEM.Weight = .2;
ITEM.Size = 1;
ITEM.Model = "models/healthvial.mdl";
ITEM.Usable = false;

ITEM.Desc = "An antibiotic, and full of stem cells!";

ITEM.License = 3;

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 6;
ITEM.FactoryStock = 2;
