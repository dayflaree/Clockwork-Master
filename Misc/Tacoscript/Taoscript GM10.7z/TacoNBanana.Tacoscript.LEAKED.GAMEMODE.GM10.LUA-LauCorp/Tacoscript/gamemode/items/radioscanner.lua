
ITEM.Name = "Radio Scanner";

ITEM.Weight = 3;
ITEM.Size = 6;

ITEM.Model = "models/props_lab/reciever01b.mdl";
ITEM.Usable = true;

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 7000;

ITEM.Desc = "Scans for the CCA radio frequency";

function ITEM:OnUse()

	local ccafreq = tonumber( TS.CombineRadioFreq );
	self.Owner:PrintMessage( 3, "The CCA Radio Frequency: "..ccafreq.."\n" );

end
