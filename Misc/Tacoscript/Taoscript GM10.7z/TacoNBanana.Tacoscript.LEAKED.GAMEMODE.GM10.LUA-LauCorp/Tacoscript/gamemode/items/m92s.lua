ITEM.Name = "Silenced M92";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_silenced_92.mdl";
ITEM.Usable = false;

ITEM.Desc = "Jojo's donator weapon - Do not buy";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 2000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 5;

function ITEM:OnPickup()

self.Owner:ForceGive( "weapon_ts_m92s" );

timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
timer.Simple( .4, self.Owner.CheckInventory, self.Owner );

self.Owner:SaveWeapons();

end