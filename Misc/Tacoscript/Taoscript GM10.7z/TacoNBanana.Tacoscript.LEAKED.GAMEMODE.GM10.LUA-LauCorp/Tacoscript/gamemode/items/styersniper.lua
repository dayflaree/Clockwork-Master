
ITEM.Name = "Styer Scout";

ITEM.Weight = 3;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_snip_scout.mdl";
ITEM.Usable = false;

ITEM.Desc = "The Steyr Scout, a reliable weapon.";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 8000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 40;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_styersniper" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
