
ITEM.Name = "Radio";

ITEM.Weight = .5;
ITEM.Size = .1;
ITEM.Model = "models/Items/combine_rifle_cartridge01.mdl";
ITEM.Usable = false;
ITEM.Wearable = true;

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 250;
ITEM.FactoryStock = 2;
ITEM.License = 5;
ITEM.LightMarket = true;



ITEM.Desc = "Use to listen to the radio or send transmissions back and forth.";


