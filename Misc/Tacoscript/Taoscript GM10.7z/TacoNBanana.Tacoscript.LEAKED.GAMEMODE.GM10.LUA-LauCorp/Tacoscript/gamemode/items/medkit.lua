

ITEM.Name = "Medkit";

ITEM.Weight = .2;
ITEM.Size = 2.5;
ITEM.Model = "models/Items/HealthKit.mdl";
ITEM.Usable = true;

ITEM.Desc = "This'll patch me up good";

ITEM.License = 5;

ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.FactoryPrice = 45;
ITEM.FactoryStock = 3;

function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 45, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );

	if( self.Owner:IsBleeding() ) then

		if( self.Owner:GetNWInt( "bleedwound" ) > 0 ) then
		
			local wound = self.Owner:GetNWInt( "bleedwound" );
			local amt = 0;
			
			amt = 5 * ( self.Owner:GetNWFloat( "stat.Medic" ) / 80 );
		
			self.Owner:SetNWInt( "bleedwound", math.Clamp( wound - amt, 0, 100 ) );
		
			if( ( wound - amt ) <= 0 ) then
			
				self.Owner:StopBleed();
			
			end
		
		end
		
	else
		
		self.Owner:PrintMessage( 3, "I'm not bleeding, so I didn't bandage myself." );
		
	end
	
		timer.Simple( .1, self.Owner.DropOneItem, self.Owner, self.UniqueID );
		timer.Simple( .1, self.Owner.CheckInventory, self.Owner )
		
	end