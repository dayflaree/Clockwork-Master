

ITEM.Name = "Morphine";

ITEM.Weight = .2;
ITEM.Size = 1;
ITEM.Model = "models/healthvial.mdl";
ITEM.Usable = true;

ITEM.Desc = "I hope this'll take away the pain..";

ITEM.License = 5;

ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.FactoryPrice = 19;
ITEM.FactoryStock = 5;
ITEM.License = 5;

function ITEM:OnUse()

	self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 50, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
	self.Owner:AddMaxStamina( 10 );
	
end