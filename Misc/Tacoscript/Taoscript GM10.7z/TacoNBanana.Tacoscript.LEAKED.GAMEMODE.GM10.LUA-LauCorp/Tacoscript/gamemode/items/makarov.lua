
ITEM.Name = "Makarov Pistol";

ITEM.Weight = 3;
ITEM.Size = 2;
ITEM.Model = "models/weapons/w_makaro.mdl";
ITEM.Usable = false;

ITEM.Desc = "Small and concealable, 12 round mag";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 800;
ITEM.FactoryStock = 3;

ITEM.RebelCost = 15;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_makarov" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
end
