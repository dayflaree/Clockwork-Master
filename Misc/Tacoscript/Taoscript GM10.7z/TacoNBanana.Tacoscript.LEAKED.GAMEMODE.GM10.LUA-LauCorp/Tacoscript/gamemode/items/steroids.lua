
ITEM.Name = "Steroids";

ITEM.Weight = 1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Illegal strength boost (temporary)";

ITEM.License = 5;
ITEM.LightMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 10;
ITEM.FactoryStock = 10;

function ITEM:OnUse()

	self.Owner:TempStatBoost( "Strength", 100, 300 );
	
end
