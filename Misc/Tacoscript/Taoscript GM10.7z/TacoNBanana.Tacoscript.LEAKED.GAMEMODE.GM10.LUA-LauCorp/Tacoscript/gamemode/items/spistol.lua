
ITEM.Name = "Advanced Combine Sidearm";

ITEM.Weight = 3;
ITEM.Size = 2;
ITEM.Model = "models/weapons/w_pist_usp_silencer.mdl";
ITEM.Usable = false;

ITEM.Desc = "Silenced USP";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 2375;
ITEM.FactoryStock = 3;

ITEM.RebelCost = 15;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_spistol" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
end
