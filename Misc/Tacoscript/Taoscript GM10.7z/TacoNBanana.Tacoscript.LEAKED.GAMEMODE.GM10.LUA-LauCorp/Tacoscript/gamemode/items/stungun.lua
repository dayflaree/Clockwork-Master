

ITEM.Name = "Stungun - Riot Rounds";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_stungun_beasta.mdl";
ITEM.Usable = false;

ITEM.Desc = "Jojos Donator Weapon - Do not use";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 3500;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 30;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_stungun" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end


