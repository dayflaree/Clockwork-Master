
ITEM.Name = "Citizen Clothes";

ITEM.Weight = .5;
ITEM.Size = 1;
ITEM.Model = "models/props_c17/suitcase001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "A suitcase, containing a citizen outfit.";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = false;
ITEM.FactoryPrice = 3000;
ITEM.FactoryStock = 1;


function ITEM:OnUse()

	self.Owner:SetModel( self.Owner:GetField( "model" ) )
	self.Owner:SetArmor( "0" )
	self.Owner:GiveItem( "medicvest", false, true )
	
end 