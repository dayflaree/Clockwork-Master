
ITEM.Name = "AWP Sniper Rifle";

ITEM.Weight = 3;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_snip_awp.mdl";
ITEM.Usable = false;

ITEM.Desc = "Powerful Sniper Rifle";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 10000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 80;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_awp" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
