

ITEM.Name = "Riot Shotgun";

ITEM.Weight = 1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_boom_xm1014.mdl";
ITEM.Usable = false;

ITEM.Desc = "Non-Lethal Pacification Weapon";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 4000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 50;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_riot" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
