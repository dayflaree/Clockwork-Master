

ITEM.Name = "RPG";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_rocket_launcher.mdl";
ITEM.Usable = false;

ITEM.Desc = "Millitary RPG-7";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 80000;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 1000;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_rpg" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
