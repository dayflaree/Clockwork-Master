

ITEM.Name = "Marijuana";

ITEM.Weight = .3;
ITEM.Size = 1;
ITEM.Model = "models/props_lab/box01b.mdl";
ITEM.Usable = true;

ITEM.Desc = "Skunkiest stuff on this side of the canals.";

ITEM.BlackMarket = false;
ITEM.FactoryBuyable = true;
ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryPrice = 300;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() - 10, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );
self.Owner:AddMaxStamina( 10 );
self.Owner:TempStatBoost( "Strength", 5, 600 );

	umsg.Start( "ImHigh", self.Owner );
	umsg.End();

	local function MakeKO( ply )
		ply:SetNWFloat( "conscious", 4 );
		ply:GoUnconscious();
	end
	
	timer.Simple( 8, MakeKO, self.Owner );

end

