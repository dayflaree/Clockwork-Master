

ITEM.Name = "Zipties";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_defuser.mdl";
ITEM.Usable = false;

ITEM.Desc = "Used for apprehending scoundrels";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 50;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 5;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_zipties" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
