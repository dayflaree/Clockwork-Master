

ITEM.Name = "Brick";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/props_junk/meleeblock007a.mdl";
ITEM.Usable = false;

ITEM.Desc = "Used for building houses or busting heads open";

ITEM.LightMarket = true;
ITEM.License = 5;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 50;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 5;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_brick" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
