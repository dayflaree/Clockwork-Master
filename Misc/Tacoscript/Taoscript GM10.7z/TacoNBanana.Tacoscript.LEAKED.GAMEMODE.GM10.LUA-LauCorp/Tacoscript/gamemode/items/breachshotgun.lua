

ITEM.Name = "Door Breaching Shotgun";

ITEM.Weight = 1;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_boom_xmbeef.mdl";
ITEM.Usable = false;

ITEM.Desc = "Breach/Entry Weapon";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 2500;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 30;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_doorbreacher" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
