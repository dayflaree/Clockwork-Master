

ITEM.Name = "Canned Meat";

ITEM.Weight = .1;
ITEM.Size = 1;
ITEM.Model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.Usable = true;

ITEM.Desc = "Ew, this is worse than Spam!";

ITEM.FactoryBuyable = true;
ITEM.License = 1;
ITEM.FactoryPrice = 12;
ITEM.FactoryStock = 5;


function ITEM:OnUse()

self.Owner:SetHealth( math.Clamp( self.Owner:Health() + 12, 0, self.Owner:GetNWInt( "MaxHealth" ) ) );

end

