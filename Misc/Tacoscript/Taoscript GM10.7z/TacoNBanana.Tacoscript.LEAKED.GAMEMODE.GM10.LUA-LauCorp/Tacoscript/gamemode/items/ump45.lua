

ITEM.Name = "MP5";

ITEM.Weight = 2;
ITEM.Size = 0;
ITEM.Model = "models/weapons/w_smg_ump45.mdl";
ITEM.Usable = false;

ITEM.Desc = "Combine H&K SMG";

ITEM.BlackMarket = true;
ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 1200;
ITEM.FactoryStock = 6;

ITEM.RebelCost = 15;

function ITEM:OnPickup()
	
	self.Owner:ForceGive( "weapon_ts_ump" );

	timer.Simple( .4, self.Owner.DropOneItem, self.Owner, self.UniqueID );
	timer.Simple( .4, self.Owner.CheckInventory, self.Owner );
	
	self.Owner:SaveWeapons();
	
end
