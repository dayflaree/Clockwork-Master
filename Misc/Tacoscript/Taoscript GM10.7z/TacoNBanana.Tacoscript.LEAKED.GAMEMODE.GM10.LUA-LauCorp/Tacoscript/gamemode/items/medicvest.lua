
ITEM.Name = "Rebel Medic Clothing";

ITEM.Weight = .5;
ITEM.Size = 3;
ITEM.Model = "models/props_c17/suitcase001a.mdl";
ITEM.Usable = false;

ITEM.FactoryBuyable = true;
ITEM.FactoryPrice = 100000;
ITEM.FactoryStock = 2;

ITEM.License = 3;

ITEM.BlackMarket = true;

ITEM.Desc = "Rebel medic clothing (/medicclothes).  /citizenclothes to change back.";


