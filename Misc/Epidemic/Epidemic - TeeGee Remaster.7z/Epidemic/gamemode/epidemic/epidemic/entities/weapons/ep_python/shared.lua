if( SERVER ) then
   
 	AddCSLuaFile( "shared.lua" );
	
end 

SWEP.Base = "ep_base";

SWEP.Spawnable			= false;
SWEP.AdminSpawnable		= false;

if( CLIENT ) then
	
	SWEP.ViewModelFlip = true;
	SWEP.DrawCrosshair = false;

end

SWEP.ViewModel				= "models/necropolis/v_models/v_chaos303030.mdl";
SWEP.WorldModel				= "models/necropolis/w_models/w_chaos303030.mdl";
SWEP.HoldType = "revolver";
SWEP.Primary.Sound			=  Sound( "weapons/necropolis/chaos303030/deagle-1.wav" );

SWEP.PrintName 				= "Colt Python";
SWEP.EpiDesc 				= "6 inch barrel Revolver";

SWEP.Primary.Recoil			= .3;
SWEP.Primary.RecoilAdd		= .5;
SWEP.Primary.RecoilMin 		= .3;
SWEP.Primary.RecoilMax 		= 10;

SWEP.Primary.ViewPunchMul 	= 20;
SWEP.Primary.Damage			= 15;
SWEP.Primary.NumShots		= 1;

SWEP.EpiHoldType 			= "PISTOL";

SWEP.DegradeAmt 			= 2;
SWEP.JamChance 				= 20;
SWEP.HealthAmt 				= 100;

SWEP.Primary.MaxAmmoClip 	= 6;
SWEP.Primary.AmmoString 	= " .357 Magnum";
SWEP.Primary.AmmoType 		= 9;
SWEP.Primary.Delay 			= 0.457;
SWEP.Primary.Automatic 		= false;
SWEP.Primary.SpreadCone 	= Vector( 0.015, 0.015, 0.015 );
SWEP.Primary.ReloadDelay 	= 2.794;

SWEP.Primary.IronSightPos = Vector( 1.454, 0.80, -3.64 );
SWEP.Primary.IronSightAng = Angle( 0, 0, 0 );

SWEP.Primary.HolsteredPos 	= Vector( 0, 0, 0 );
SWEP.Primary.HolsteredAng 	= Angle( -25, 0, 0 );

SWEP.ItemWidth 		= 2;
SWEP.ItemHeight 	= 2;

SWEP.IconCamPos 	= Vector( 0, 200, 0 )
SWEP.IconLookAt 	= Vector( 7, 0, 2 ) 
SWEP.IconFOV		= 5
SWEP.HUDWidth 		= 200;
SWEP.HUDHeight 		= 100;
SWEP.NicePhrase 	= "a Colt Python";
SWEP.LightWeight 	= true;

function SWEP:OnReloadSound()
	
	timer.Simple( 0.113, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/chaos303030/bulletsout.wav" ) );
	end );
	timer.Simple( 1.138, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/chaos303030/bulletsin.wav" ) );
	end );
	timer.Simple( 1.785, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/chaos303030/spin.wav" ) );
	end );
	timer.Simple( 1.919, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/chaos303030/blick.wav" ) );
	end );
	
end


function SWEP:OnDrawSound()
	
	self.Owner:EmitSound( Sound( "weapons/necropolis/44magnum/bulldraw.wav" ) );
	
end