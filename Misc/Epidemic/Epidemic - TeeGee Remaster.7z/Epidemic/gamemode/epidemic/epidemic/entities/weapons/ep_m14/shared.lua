if( SERVER ) then
   
 	AddCSLuaFile( "shared.lua" );
	
end 

SWEP.Base = "ep_base";

SWEP.Spawnable			= false;
SWEP.AdminSpawnable		= false;

if( CLIENT ) then
	
	SWEP.ViewModelFlip = true;
	SWEP.DrawCrosshair = false;

end

SWEP.ViewModel				= "models/necropolis/v_models/v_jubbert.mdl";
SWEP.WorldModel				= "models/necropolis/w_models/w_jubbert.mdl";

SWEP.Primary.Sound			= Sound( "weapons/necropolis/m14/sg550-1.wav" );
SWEP.HoldType = "rpg"
SWEP.PrintName 				= "M14 Scoped";
SWEP.EpiDesc 				= "Sniper rifle";

SWEP.Primary.Recoil			= .3;
SWEP.Primary.RecoilAdd		= .5;
SWEP.Primary.RecoilMin 		= .3;
SWEP.Primary.RecoilMax 		= 10;

SWEP.Primary.ViewPunchMul 	= 5;
SWEP.Primary.Damage			= 20;
SWEP.Primary.NumShots		= 1;

SWEP.EpiHoldType 			= "SNIPER";

SWEP.DegradeAmt 			= 2;
SWEP.JamChance 				= 20;
SWEP.HealthAmt 				= 100;

SWEP.MuzzleDepth 			= 30;

SWEP.Primary.MaxAmmoClip 	= 20;
SWEP.Primary.AmmoString 	= " 7.62mm rounds";
SWEP.Primary.AmmoType 		= 4;
SWEP.Primary.Delay 			= 0.6;
SWEP.Primary.Automatic 		= false;
SWEP.Primary.SpreadCone 	= Vector( 0, 0, 0 );
SWEP.Primary.ReloadDelay 	= 2.9;

SWEP.Primary.IronSightPos = Vector( 2.87, 1.79, -3.48 );
SWEP.Primary.IronSightAng = Angle( 0, -0, -0 );

SWEP.Primary.HolsteredPos 	= Vector( 0, 0, 0 );
SWEP.Primary.HolsteredAng 	= Angle( -25, 0, 0 );

SWEP.ItemWidth 		= 4;
SWEP.ItemHeight 	= 2;

SWEP.IconCamPos 	= Vector( 0, 200, 0 )
SWEP.IconLookAt 	= Vector( 15, 0, 2 ) 
SWEP.IconFOV		= 10
SWEP.HUDWidth 		= 200;
SWEP.HUDHeight 		= 100;
SWEP.NicePhrase 	= "an m14";
SWEP.HeavyWeight 	= true;

SWEP.Scoped = true;
SWEP.VariableZoom = true;


function SWEP:OnReloadSound()
	
	timer.Simple( 0.433, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/m14/sg550_clipout.wav" ) );
	end );
	timer.Simple( 1.6, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/m14/sg550_clipin.wav" ) );
	end );
	timer.Simple( 2.4, function()
		self.Owner:EmitSound( Sound( "weapons/necropolis/m14/sg550_boltpull.wav" ) );
	end );

	
end

function SWEP:OnDrawSound()

		self.Owner:EmitSound( Sound( "weapons/necropolis/m14/sg550_draw.wav" ) );

end