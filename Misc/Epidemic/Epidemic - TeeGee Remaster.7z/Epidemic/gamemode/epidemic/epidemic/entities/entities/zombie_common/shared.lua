ENT.Base = "base_ai";
ENT.Type = "ai";
  
ENT.AutomaticFrameAdvance = true;

ENT.PrintName = "Zombie"
ENT.Category		= "Apocalypse Narrative Role-Play (S)NPCs"

ENT.Spawnable = true
ENT.AdminSpawnable = true