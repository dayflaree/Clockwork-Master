include( "shared.lua" );

function ENT:Draw()
	
	self:DrawModel();
	
end

local function Gore( len )
	
	local dmgpos = net.ReadVector();
	local self = net.ReadEntity();
	
	if( not self or not self:IsValid() ) then return; end
	
	local effectdata = EffectData();
	effectdata:SetOrigin( dmgpos + Vector( math.Rand( -1, 1 ), math.Rand( -1, 1 ), math.Rand( -1, 1 ) ) );
	
	for k = 1, 2 do
		util.Effect( "BloodImpact", effectdata );
	end
	
	local trace = { }
	
	trace.start = dmgpos;
	trace.endpos = trace.start + self:GetRight() * math.random( -90, 90 ) + self:GetForward() * math.random( -90, 90 ) + self:GetUp() * -60;
	trace.filter = self;
	
	local tr = util.TraceLine( trace );
	
	local pos = tr.HitPos;
	local norm = tr.HitNormal;
	
	util.Decal( "Blood", pos + norm, pos - norm );
	
end
net.Receive( "zGore", Gore );