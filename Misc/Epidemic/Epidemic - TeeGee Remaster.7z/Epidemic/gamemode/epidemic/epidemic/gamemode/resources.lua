
resource.AddFile( "sound/heartbeat.wav" );
resource.AddFile( "resource/fonts/MyUnderwood.ttf" );
resource.AddFile( "resource/fonts/digital-7.TTF" );
resource.AddFile( "resource/fonts/type-ra.ttf" );

resource.AddFile( "materials/scope/scope_sniper_lr.vmt" );
resource.AddFile( "materials/scope/scope_sniper_ll.vmt" );
resource.AddFile( "materials/scope/scope_sniper_ur.vmt" );
resource.AddFile( "materials/scope/scope_sniper_ul.vmt" );
resource.AddFile( "materials/scope/scope_dudv_ul.vtf" );
resource.AddFile( "materials/scope/scope_normal_ul.vtf" );
