ITEM.Name = "357 Magnum Rounds";
ITEM.NicePhrase = "356 ammo";
ITEM.Description = "Ammo"; 
ITEM.Model = "models/Items/357ammo.mdl"
ITEM.CamPos = Vector( 50, 50, 50 );
ITEM.LookAt = Vector( 0, 0, 7 ); 
ITEM.FOV = 22;
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.Flags = "ax";
ITEM.Amount = 12;
ITEM.AmmoType = 9;

ITEM.Tier = 4;

ITEM.AddsOn = true;
ITEM.AddOnMax = 24;

function ITEM:Examine()

	self.Owner:NoticePlainWhite( "There are " .. self.Amount .. " rounds left in this." );

end

