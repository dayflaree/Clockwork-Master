ITEM.Name = "HECU helmet";
ITEM.NicePhrase = "A standard issue HECU helmet.";
ITEM.Description = "A standard issue HECU helmet. | /helmetoff to take off."; 
ITEM.Model = "models/props_lab/box01a.mdl"
ITEM.CamPos = Vector( 50, 78, 90 );
ITEM.LookAt = Vector( 0, 0, 0 ); 
ITEM.FOV = 5;
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.Flags = "i";

ITEM.AddsOn = false;
ITEM.AddOnMax = 3;

ITEM.Tier = 1;


function ITEM:Pickup()
	local mdl = string.lower( self.Owner:GetModel() );

if( string.find( mdl, "pmc" ) ) then
	self.Owner:SetBodygroup( 5, 1 )
		self.Owner:NoticePlainWhite( "You equipped your standard issue helmet." );

	else

	self.Owner:NoticePlainWhite( "You couldn't possibly wear this helmet." );
	
	end
end

function ITEM:Drop()
	local mdl = string.lower( self.Owner:GetModel() );

if( string.find( mdl, "pmc" ) ) then
	self.Owner:SetBodygroup( 5, 0 )
		self.Owner:NoticePlainWhite( "You dropped your standard issue helmet." );

			else
	end
end

function ITEM:Examine()
	
	local n = math.random( 1, 3 );
	if( n == 1 ) then
		
		self.Owner:NoticePlainWhite( "Very useful for dangerous and deadly environments." );
		
	elseif( n == 2 ) then
		
		self.Owner:NoticePlainWhite( "Protective against hostile fire and hard objects." );
		
	else
		
		self.Owner:NoticePlainWhite( "It is standard issue, they must all wear it." );
		
	end

end
