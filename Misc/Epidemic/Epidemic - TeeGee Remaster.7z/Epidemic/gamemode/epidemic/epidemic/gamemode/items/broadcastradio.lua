

ITEM.Name = "Broadcast Radio";

ITEM.Description = "Receives all radio transmissions."; 

ITEM.Model = "models/props/cs_office/radio.mdl"
ITEM.CamPos = Vector( 50, 50, 50 ) 
ITEM.LookAt = Vector( -3, 0, 9 ) 
ITEM.FOV = 10
ITEM.Flags = "";
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.NicePhrase = "";

ITEM.Tier = 3;