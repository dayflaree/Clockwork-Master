
local meta = FindMetaTable( "Player" );

function meta:FirstTimeSpawnHelp()

	local dotip = function( ply, text )
	
		if( ply and ply:IsValid() ) then
	
			ply:NoticePlainWhiteEx( text );
	
		end
	
	end

	timer.Simple( 10, function() dotip( self, "For help, press F1." ) end );
	timer.Simple( 15, function() dotip( self, "Press F3 for your player menu and inventory." ) end );
	timer.Simple( 20, function() dotip( self, "Press F4 to recognize another player." ) end );
	timer.Simple( 25, function() dotip( self, "Press the use-key on an item to interact with it." ) end );
	timer.Simple( 32, function() dotip( self, "Use SHIFT + ALT to sprint at full speed." ) end );

end
