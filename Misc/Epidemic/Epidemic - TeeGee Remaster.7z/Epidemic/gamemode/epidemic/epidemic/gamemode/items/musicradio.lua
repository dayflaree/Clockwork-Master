

ITEM.Name = "Music Radio";

ITEM.Description = "Play a tune."; 

ITEM.Model = "models/props/cs_office/radio.mdl"
ITEM.CamPos = Vector( 50, 50, 50 ) 
ITEM.LookAt = Vector( -3, 0, 9 ) 
ITEM.FOV = 10
ITEM.Flags = "u"
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.NicePhrase = "";


function ITEM:Use()
	for k,v in pairs (player.GetAll()) do
	
		local entity = ents.Create("ent_radio");
	
		entity:SetModel("models/props/cs_office/radio.mdl");
		entity:SetPos(Vector(0,0,0))
		entity:Spawn();
		
		if (IsValid(itemEntity)) then
			local physicsObject = itemEntity:GetPhysicsObject();
			
			entity:SetPos( itemEntity:GetPos() );
			entity:SetAngles( itemEntity:GetAngles() );
			
			if (IsValid(physicsObject)) then
				if (!physicsObject:IsMoveable()) then
					physicsObject = entity:GetPhysicsObject();
					
					if (IsValid(physicsObject)) then
						physicsObject:EnableMotion(false);
					end
					else
					entity:Spawn()
				end
			end
		end
	end
end