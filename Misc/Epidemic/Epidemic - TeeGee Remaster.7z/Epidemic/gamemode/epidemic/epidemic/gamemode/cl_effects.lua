
--This handles the playing and timing of audio hallucinations that occur randomly during gameplay.
NextAudioHallucinationTime = CurTime() + 70;
LastAudioHallucination = 0;

AudioHallucinationEffects = 
{

	{ Sound = "ambient/creatures/town_child_scream1.wav", Min =  15, Max = 40 },
	{ Sound = "ambient/creatures/town_moan1.wav", Min = 20, Max = 30 },
	{ Sound = "ambient/creatures/town_muffled_cry1.wav", Vol = 25 },
	{ Sound = "ambient/creatures/town_scared_breathing1.wav", Vol = 35 },
	{ Sound = "ambient/creatures/town_scared_breathing2.wav", Vol = 35 },
	{ Sound = "ambient/creatures/town_scared_sob1.wav", Vol = 30 },
	{ Sound = "ambient/creatures/town_scared_sob2.wav", Vol = 30 },
	{ Sound = "ambient/levels/streetwar/city_scream3.wav", Vol = 30 },
	{ Sound = "ambient/levels/prison/inside_battle_zombie1.wav", Vol = 35 },
	{ Sound = "ambient/levels/prison/inside_battle_zombie3.wav", Vol = 35 },
	{ Sound = "npc/zombie/zombie_pain3.wav", Vol = 25 },
	{ Sound = "npc/zombie/zombie_pain4.wav", Vol = 15 },
	{ Sound = "npc/zombie/zombie_pain5.wav", Vol = 13 },
	{ Sound = "npc/stalker/stalker_scream1.wav", Vol = 20 },
	{ Sound = "npc/stalker/stalker_scream2.wav", Vol = 20 },
	{ Sound = "npc/stalker/stalker_scream3.wav", Vol = 20 },
	{ Sound = "npc/stalker/stalker_scream4.wav", Vol = 20 },

}

function HandleAudioHallucination( bypasswait )

	if( bypasswait or ( NextAudioHallucinationTime > 0 and CurTime() > NextAudioHallucinationTime ) ) then
	
		local audio = LastAudioHallucination;
		
		while( audio == LastAudioHallucination ) do
		
			audio = math.random( 1, #AudioHallucinationEffects );
		
		end
		
		LastAudioHallucination = audio;
		
		if( AudioHallucinationEffects[audio].Vol ) then
		
			LocalPlayer():EmitSound( AudioHallucinationEffects[audio].Sound, AudioHallucinationEffects[audio].Vol );
			
		else
		
			LocalPlayer():EmitSound( AudioHallucinationEffects[audio].Sound, math.random( AudioHallucinationEffects[audio].Min, AudioHallucinationEffects[audio].Max ) );
		
		end
		
		--Have a chance of doing another sound
		if( not bypasswait and math.random( 1, 5 ) == 4 ) then
		
			timer.Simple( math.random( 3, 20 ), HandleAudioHallucination, true );
		
		end
		
		if( not bypasswait ) then
		
			local mul = 1;
		
			if( ClientVars["Conscious"] < 45 ) then
				mul = math.Clamp( ClientVars["Conscious"] / 80, 0, 1 );
			end
			
			NextAudioHallucinationTime = math.random( 70 * mul, 620 * mul ) + CurTime();
		
		end
	
	end

end

NextSirenSound = 0;

function HandleSiren()

	if( CurTime() >= NextSirenSound ) then

		LocalPlayer():EmitSound( "siren.wav", 25 );
		NextSirenSound = CurTime() + 7;
	end

end

--This handles the volume, sound and speed of the heartbeat that you hear.
--It's based off sprint and possibly other factors.
HeartBeat = {

	AudiblePerc = 0,
	RateMul = 0,
	PitchPerc = 100,
	NextHeartBeat = CurTime(),
	SimulatedCalmness = 100,
	NextCalmnessHeal = 0,

}
function HandleHeartBeatRate()

	if( HeartBeat.NextHeartBeat < CurTime() ) then

		if( HeartBeat.AudiblePerc > 0 ) then

			LocalPlayer():EmitSound( "heartbeat.wav", HeartBeat.AudiblePerc, HeartBeat.PitchPerc );

		end

	end
	
	if( HeartBeat.SimulatedCalmness < 100 and
		CurTime() > HeartBeat.NextCalmnessHeal ) then
	
		HeartBeat.SimulatedCalmness = math.Clamp( HeartBeat.SimulatedCalmness + 2, 0, 100 );
		HeartBeat.NextCalmnessHeal = CurTime() + 2;
		
	end
	
	local diff;
	local sub = 0;
	
	if( ClientVars["Sprint"] < HeartBeat.SimulatedCalmness ) then
		sub = ClientVars["Sprint"];
	else
		sub = HeartBeat.SimulatedCalmness;
	end
	
	diff = 100 - sub;
	
	--Sprint based
	HeartBeat.RateMul = diff / 10;
	HeartBeat.PitchPerc = 100 + ( 5 * HeartBeat.RateMul );
	HeartBeat.AudiblePerc = math.Clamp( 10 * HeartBeat.RateMul, 0, 150 );

	if( HeartBeat.NextHeartBeat < CurTime() ) then
		
		HeartBeat.NextHeartBeat = CurTime() + math.Clamp( 2 * sub / 100, .5, 1.5 );
			
	end
	
	--Conscious based
	local conscious = ClientVars["Conscious"];

	if( conscious < 50 ) then

		HeartBeat.AudiblePerc = math.Clamp( 10 * ( 100 - conscious ) * .5, 0, 150 );
		
	end
	

end

BattleSounds =
{

	NextTime = 0;
	
	Effects = 
	{
	
		{ Sound = "ambient/levels/prison/inside_battle1.wav", Vol = 15 },
		{ Sound = "ambient/levels/prison/inside_battle2.wav", Vol = 15 },
		{ Sound = "ambient/levels/prison/inside_battle3.wav", Vol = 15 },
		{ Sound = "ambient/levels/prison/inside_battle4.wav", Vol = 15 },
		{ Sound = "ambient/levels/streetwar/city_battle2.wav", Vol = 15 },
		{ Sound = "ambient/levels/streetwar/city_battle3.wav", Vol = 15 },
		{ Sound = "ambient/levels/streetwar/city_battle4.wav", Vol = 15 },
		{ Sound = "ambient/levels/streetwar/city_battle5.wav", Vol = 15 },
	
	}

}
function HandleBattleSounds()

	if( CurTime() > BattleSounds.NextTime ) then
	
		local val = math.random( 1, #BattleSounds.Effects );
		
		LocalPlayer():EmitSound( BattleSounds.Effects[val].Sound, BattleSounds.Effects[val].Vol );
	
		if( math.random( 1, 10 ) < 7 ) then
		
			BattleSounds.NextTime = CurTime() + math.random( 2, 15 );
		
		else
		
			BattleSounds.NextTime = CurTime() + math.random( 5, 80 );
		
		end
		
		
	end

end


NextWindNoise = CurTime() + math.random( 1, 10 );

WindNoiseEffects = 
{
	
	 "ambient/levels/forest/treewind1.wav",
	 "ambient/levels/forest/treewind2.wav",

}

function HandleWindNoise()

	if( CurTime() > NextWindNoise ) then
	
		local val = math.random( 1, #WindNoiseEffects );
		
		LocalPlayer():EmitSound( WindNoiseEffects[val], 25 );
	
		NextWindNoise = CurTime() + math.random( 2, 25 );
	
	end

end


ConsciousBlur = 
{

	HeadBob = 0,
	HeadBobRoll = 0,
	HeadBobDir = 1,
	HeadBobRollDesp = 0,
	HeadBobNewRoll = true,
	HeadBobRollToOrigin = false,
	Levels = { },

}
function CreateConsciousBlurEffects()

	for n = 1, 100 do
	
		if( n < 65 ) then
	
			ConsciousBlur.Levels[n] =
			{
			
				AddTransp = math.Clamp( .8 - ( 2 * ( ( 60 - n ) * .01 ) ), .1, 1 ),
				DrawTransp = .99,
				FrameDelay = .02 + ( ( 40 - n ) * .001 ),
				HeadBobMin = -4 * ( ( 100 - n ) * .01 ),
				HeadBobMax = 4 * ( ( 100 - n ) * .01 ),
				HeadBobAmount = ( 60 - n ) * .01;
			
			}
			
		else

			ConsciousBlur.Levels[n] =
			{
			
				AddTransp = 1,
				DrawTransp = 1,
				FrameDelay = 0,
				HeadBobAmount = 0,
				HeadBobMin = 0,
				HeadBobMax = 0,
			
			}
		
		end
		
	end

end

CreateConsciousBlurEffects();

function DrawConsciousBlur()

	local conscious = ClientVars["Conscious"];

	if( ConsciousBlur.Levels[conscious] ) then

		DrawMotionBlur( ConsciousBlur.Levels[conscious].AddTransp, ConsciousBlur.Levels[conscious].DrawTransp, ConsciousBlur.Levels[conscious].FrameDelay );

	end

end

function event.HH()

	DoMotionBlurHit = true;
	MotionBlurHitEnd = CurTime() + .3;

	HeartBeat.SimulatedCalmness = 20;
	HeartBeat.NextCalmnessHeal = CurTime() + 2;

end

function event.HMH()

	DoMotionBlurHit = true;
	MotionBlurHitEnd = CurTime() + 1;

	HeartBeat.SimulatedCalmness = 20;
	HeartBeat.NextCalmnessHeal = CurTime() + 2;

end

DoMotionBlurHit = false;
MotionBlurHitEnd = 0;

function DrawMotionBlurHit()

	if( DoMotionBlurHit ) then

		DrawMotionBlur( .2, .99, 0 );
	
		if( CurTime() > MotionBlurHitEnd ) then
		
			DoMotionBlurHit = false;
		
		end
	
	end

end

