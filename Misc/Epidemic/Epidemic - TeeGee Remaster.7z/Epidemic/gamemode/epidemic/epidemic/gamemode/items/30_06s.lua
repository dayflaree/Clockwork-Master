ITEM.Name = ".30-06 Springfield Ammo Box";
ITEM.NicePhrase = ".30-06 Springfield Ammo Box";
ITEM.Description = "Ammo"; 
ITEM.Model = "models/Items/BoxSRounds.mdl"
ITEM.CamPos = Vector( 50, 50, 50 );
ITEM.LookAt = Vector( 0, 0, 7 ); 
ITEM.FOV = 22;
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.Flags = "ax";
ITEM.Amount = 40;
ITEM.AmmoType = 8;

ITEM.Tier = 5;

ITEM.AddsOn = true;
ITEM.AddOnMax = 80;

function ITEM:Examine()

	self.Owner:NoticePlainWhite( "There are " .. self.Amount .. " rounds left in this." );

end

