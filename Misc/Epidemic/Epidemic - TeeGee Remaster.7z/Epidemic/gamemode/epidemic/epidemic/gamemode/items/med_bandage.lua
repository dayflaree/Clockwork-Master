
ITEM.Name = "Bandage";
ITEM.NicePhrase = "a bandage roll";
ITEM.Description = "A good to have."; 
ITEM.Model = "models/props_wasteland/prison_toiletchunk01f.mdl"
ITEM.CamPos = Vector( 200, 78, 90 );
ITEM.LookAt = Vector( 0, 0, 0 ); 
ITEM.FOV = 5;
ITEM.Width = 1;
ITEM.Height = 1;
ITEM.Flags = "mx";

ITEM.AddsOn = true;
ITEM.AddOnMax = 3;

ITEM.Tier = 2;

function ITEM:Use()

	self.Owner:GiveHealth( math.random( 10, 30 ) );
	
	return true;

end

function ITEM:Examine()
	
	local n = math.random( 1, 3 );
	if( n == 1 ) then
		
		self.Owner:NoticePlainWhite( "Not even blood on it!" );
		
	elseif( n == 2 ) then
		
		self.Owner:NoticePlainWhite( "White as pure silk" );
		
	else
		
		self.Owner:NoticePlainWhite( "Dried blood on white wool." );
		
	end

end
