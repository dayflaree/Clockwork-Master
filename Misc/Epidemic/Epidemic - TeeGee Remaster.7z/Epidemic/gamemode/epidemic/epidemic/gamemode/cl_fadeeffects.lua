

if( not _Color ) then

	_Color = Color;

end

Fade = { }

function Fade.Start( val )

	Fade.Toggle = true;
	Fade.MaxAlpha = val;

end


function Fade.End()

	FadeIn.Toggle = false;

end

function Color( r, g, b, a )

	_Color( r, g, b, math.Clamp( a, 0, Fade.MaxAlpha ) );

end
