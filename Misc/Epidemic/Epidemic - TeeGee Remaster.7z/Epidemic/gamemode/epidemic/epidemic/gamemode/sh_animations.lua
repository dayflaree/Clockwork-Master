AnimConvert = { }

AnimConvert["gmod_tool"] = "PISTOL";
AnimConvert["weapon_physgun"] = "RIFLE";
AnimConvert["weapon_physcannon"] = "RIFLE";

function FindCorrectAnimTable( model )

	for k, v in pairs( AnimTables ) do
	
		if( table.HasValue( v.Models, string.lower( model ) ) ) then
			return k;
		end
	
	end
	
	return 1;

end

local NeedManualRotation = {
	"cyclops.mdl",
	"necropolis/bloodsucker",
	"necropolis/boomer",
	"boomette.mdl",
	"charger.mdl",
	"failure.mdl",
	"gigante.mdl",
	"snork.mdl",
	"ghoul.mdl",
	"zombie/classic.mdl",
	"zombie/classic_torso.mdl",
	"zombie/fast_torso.mdl",
	"zombie/fast.mdl",
	"zombie/zombie_soldier.mdl",
	"fat.mdl",
	"spitter.mdl",
	"models/props_outland/pumpkin01.mdl",
	"models/lostcoast/fisherman/fisherman.mdl",
	"models/scientist.mdl"
};

function GM:UpdateAnimation( ply, velocity, maxseqgroundspeed ) -- This handles everything about how sequences run, the framerate, boneparameters, everything.

	local len = velocity:Length()
	local movement = 1.0
	if ( len > 0.2 ) then
		movement =  ( len / maxseqgroundspeed )
	end
	local eye = ply:EyeAngles()
	
	rate = math.min( movement * 0.8, 2 )

	if ( (!ply:IsOnGround() and len >= 1000) or ply:WaterLevel() >= 2 ) then 
		rate = 0.1
	end

	if ply:GetNWInt( "emote", 0) != 0 then
		rate = 1
	end
	
	ply:SetPlaybackRate( rate )

	if ( ply:InVehicle() ) then
		local Vehicle =  ply:GetVehicle()
		
		// We only need to do this clientside..
		if CLIENT and Vehicle then
			//
			// This is used for the 'rollercoaster' arms
			//
			local Velocity = Vehicle:GetVelocity()
			ply:SetPoseParameter( "vertical_velocity", Velocity.z * 0.01 ) 

			// Pass the vehicles steer param down to the player
			local steer = Vehicle:GetPoseParameter( "vehicle_steer" )
			steer = steer * 2 - 1 // convert from 0..1 to -1..1
			ply:SetPoseParameter( "vehicle_steer", steer  ) 
		end
		
	end
	
	local eye = ply:EyeAngles()
	local estyaw = math.Clamp( math.atan2(velocity.y, velocity.x) * 180 / 3.141592, -180, 180 )
	local myaw = math.NormalizeAngle(math.NormalizeAngle(eye.y) - estyaw)

	if !ply:GetNWBool( "sittingchair", false ) then
		ply:SetPoseParameter("move_yaw", myaw * -1 )
	else
		ply:SetPoseParameter("move_yaw", 0 )
	end

	if ply:GetNWAngle( "tiramisulookat", Angle( 0, 0, 0 )) != Angle( 0, 0, 0 ) and ( SERVER or ply != LocalPlayer()) then
		if !ply.CurrentLookAt then
			ply.CurrentLookAt = ply:GetNWAngle( "tiramisulookat")
		end
		
		if SERVER then timefunc = FrameTime() end
		if CLIENT then timefunc = RealFrameTime() end
		
		ang = LerpAngle( 5 * timefunc, ply.CurrentLookAt, ply:GetNWAngle( "tiramisulookat"))
		ply.CurrentLookAt = ang
		ply:SetPoseParameter("head_pitch", ang.p + 20)
		if ang.y > 0 then
			if ang.y < 60 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", 0)
				ply:SetPoseParameter("spine_yaw", 0)
			elseif ang.y >= 60 and ang.y <= 90 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", (ang.y - 60))
				ply:SetPoseParameter("spine_yaw", 0)
			elseif ang.y > 90 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", (ang.y - 60))
				ply:SetPoseParameter("spine_yaw", (ang.y - 90))
			end
		else
			if ang.y > -60 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", 0)
				ply:SetPoseParameter("spine_yaw", 0)
			elseif ang.y <= -60 and ang.y >= -90 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", (ang.y + 60))
				ply:SetPoseParameter("spine_yaw", 0)
			elseif ang.y < -90 then
				ply:SetPoseParameter("head_yaw", ang.y)
				ply:SetPoseParameter("body_yaw", (ang.y + 60))
				ply:SetPoseParameter("spine_yaw", (ang.y + 90))
			end
		end
		--print("HEAD YAW:", ply:GetPoseParameter("head_yaw"))
	elseif (SERVER or ply != LocalPlayer()) then
		--This set of boneparameters are all set to 0 to avoid having the engine setting them to something else, thus resulting in  awkwardly twisted models
		ply.CurrentLookAt = Angle( 0, 0, 0 )
		--ply:SetPoseParameter("aim_yaw", 0 )
		ply:SetPoseParameter("head_yaw", 0 )
		ply:SetPoseParameter("body_yaw", 0 )
		ply:SetPoseParameter("spine_yaw", 0 )
	end
	ply:SetPoseParameter("head_roll", 0 )
	
end

function GM:HandlePlayerSwimming( ply, velocity ) --Handles swimming.

	if ( ply:WaterLevel() < 2 ) then 
		ply.m_bInSwim = false
		return false 
	end
	
	if !CAKE.ConVars[ "LinuxHotfix" ] then
		ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "swim" ] )
	else
		ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "fly" ] )
	end
	
	if SERVER then
		ply:SetAiming(false)
	end
	ply.m_bInSwim = true
	return true
end

function GM:HandlePlayerDriving( ply ) --Handles sequences while in vehicles.

	local vehicle
	local class
 
	if ply:InVehicle() then
		vehicle = ply:GetVehicle()
		class = vehicle:GetClass()
		if ( class == "prop_vehicle_jeep" ) then
			ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "drivejeep" ] )
		elseif ( class == "prop_vehicle_airboat" ) then
			ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "driveairboat" ] )
		elseif ( class == "prop_vehicle_prisoner_pod" and vehicle:GetModel() == "models/vehicles/prisoner_pod_inner.mdl" ) then
			ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "drive_pd" ] )
		else
			ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "drive_chair" ] )
		end
		return true
	end
end

function GM:HandlePlayerNoClipping( ply, velocity )

	if ( false ) then

		if ( ply:GetMoveType() != MOVETYPE_NOCLIP ) then 
			return false 
		end
		
		if ( velocity:Length() > 1000 ) then
			ply.CalcIdeal, calc = ACT_MP_SWIM
		else
			ply.CalcIdeal = ACT_MP_SWIM_IDLE
		end
			
		return true
	end

	return false

end

function GM:HandlePlayerVaulting( ply, velocity )

	if ( velocity:Length() < 1000 ) then return end
	if ( ply:IsOnGround() or ply:WaterLevel() >= 2 ) then return end

	ply.CalcIdeal, ply.CalcSeqOverride = HandleSequence( ply, Anims[ ply:GetGender() ][ "default" ][ "swim" ] )	
	return true

end

function GM:DoAnimationEvent( ply, event, data )

	if ( event == PLAYERANIMEVENT_ATTACK_PRIMARY ) then
	
		if ply:Crouching() then
			ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_MP_ATTACK_CROUCH_PRIMARYFIRE, true )
		else
			ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_MP_ATTACK_STAND_PRIMARYFIRE, true )
		end
		
		return ACT_VM_PRIMARYATTACK
	
	elseif ( event == PLAYERANIMEVENT_ATTACK_SECONDARY ) then
	
		-- there is no gesture, so just fire off the VM event
		return ACT_VM_SECONDARYATTACK
		
	elseif ( event == PLAYERANIMEVENT_RELOAD ) then
	
		if ply:Crouching() then
			ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_MP_RELOAD_CROUCH, true )
		else
			ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_MP_RELOAD_STAND, true )
		end
		
		return ACT_INVALID
		
	elseif ( event == PLAYERANIMEVENT_JUMP ) then
	
		ply.m_bJumping = true
		ply.m_bFirstJumpFrame = true
		ply.m_flJumpStartTime = CurTime()
	
		ply:AnimRestartMainSequence()
	
		return ACT_INVALID
	
	elseif ( event == PLAYERANIMEVENT_CANCEL_RELOAD ) then
	
		ply:AnimResetGestureSlot( GESTURE_SLOT_ATTACK_AND_RELOAD )
		
		return ACT_INVALID
	end

end

function GM:HandlePlayerJumping( ply, velocity )

	if ( ply:GetMoveType() == MOVETYPE_NOCLIP ) then
		ply.m_bJumping = false
		return
	end

	-- airwalk more like hl2mp, we airwalk until we have 0 velocity, then it's the jump animation
	-- underwater we're alright we airwalking
	if ( !ply.m_bJumping && !ply:OnGround() && ply:WaterLevel() <= 0 ) then

		if ( !ply.m_fGroundTime ) then

			ply.m_fGroundTime = CurTime()
			
		elseif ( CurTime() - ply.m_fGroundTime ) > 0 && velocity:Length2D() < 0.5 then

			ply.m_bJumping = true
			ply.m_bFirstJumpFrame = false
			ply.m_flJumpStartTime = 0

		end
	end

	if ply.m_bJumping then
	
		if ply.m_bFirstJumpFrame then

			ply.m_bFirstJumpFrame = false
			ply:AnimRestartMainSequence()

		end
		
		if ( ply:WaterLevel() >= 2 ) || ( ( CurTime() - ply.m_flJumpStartTime ) > 0.2 && ply:OnGround() ) then

			ply.m_bJumping = false
			ply.m_fGroundTime = nil
			ply:AnimRestartMainSequence()

		end
		
		if ply.m_bJumping then
			ply.CalcIdeal = ACT_MP_JUMP
			return true
		end
	end

	return false

end

function GM:CalcMainActivity( ply, velocity )
	
	local act = "";
	
	local skipanimation = false;
	local activeweap = ply:GetActiveWeapon();
	
	local ForcedAnimTime = ply.ForcedAnimTime or 0;
	local ForcedAnimStart = ply.ForcedAnimStart or 0;
	
	local customanim = false;
	
	local vel2d = velocity:Length2D();
	
	if( ForcedAnimTime == -1 or CurTime() - ForcedAnimStart < ForcedAnimTime ) then
		
		customanim = true;
		
	end
	
	if( not customanim and not skipanimation ) then
		
		local cansprint = true;
		
		if( ply:Crouching() ) then
			act = "CROUCH";
			cansprint = false;
		else
			act = "STAND";
		end
		
		if( ply:GetTable().AnimTable and AnimTables[ply:GetTable().AnimTable]._NOWEPS ) then
			
			if( ply:OnGround() and ply:WaterLevel() < 4 ) then
				
				if( vel2d == 0 ) then
				
					act = act .. "_idle";
				
				elseif( vel2d > 120 and cansprint ) then
				
					if( ply:KeyDown( IN_WALK ) ) then
					
						act = act .. "_run";
					
					else
				
						act = act .. "_jog";
				
					end
				
				else
				
					act = act .. "_walk";
				
				end
				
			else
			
				act = "jump";
			
			end
			
		else
			
			if( ply:OnGround() and ply:WaterLevel() < 4 ) then
				
				if( activeweap:IsValid() ) then
					
					if( activeweap:GetTable() and activeweap:GetTable().EpiHoldType ) then
						
						if( activeweap:GetTable().EpiHoldType == "SHOTGUN" ) then
							act = act .. "_RIFLE";
						elseif( activeweap:GetTable().EpiHoldType == "SNIPER" ) then
							act = act .. "_RIFLE";
						else
							act = act .. "_" .. activeweap:GetTable().EpiHoldType;
						end
					
					elseif( AnimConvert[activeweap:GetClass()] ) then
					
						act = act .. "_" .. AnimConvert[activeweap:GetClass()];
					
					end
				
				end
				
				if( !ply:GetNWBool( "Holstered", true ) ) then
				
					act = act .. "_AIM";
				
				end

				if( vel2d == 0 ) then
				
					act = act .. "_idle";
				
				elseif( vel2d > 120 and cansprint ) then
				
					if( ply:KeyDown( IN_WALK ) ) then
					
						act = act .. "_run";
					
					else
				
						act = act .. "_jog";
				
					end
				
				else
				
					act = act .. "_walk";
				
				end
				
			else
			
				act = "jump";
			
			end
			
		end
		
		if( ply:InVehicle() and ply:GetTable().AnimTable and ( AnimTables[ply:GetTable().AnimTable].Anim["vehicle"] ) ) then
			
			act = "vehicle";
			
		end
		
		if( ply:GetTable().AnimLastModel ~= ply:GetModel() ) then
			
			ply:GetTable().AnimTable = FindCorrectAnimTable( ply:GetModel() );
			ply:GetTable().AnimLastModel = ply:GetModel();
			
		end
		
		local key = act;
		
		act = AnimTables[ply:GetTable().AnimTable].Anim[key] or 1;
		
		if( ply:GetNWBool( "Holstered", true ) and !string.find( key, "PISTOL" ) and !string.find( key, "SMG" ) and !string.find( key, "RIFLE" ) ) then
			
			act = DoChosenAnim( ply, key, act );
			
		end

	else
	
		act = ply.ForcedAnimation;
	
	end
	
	if( string.find( ply:GetNWString( "RPName" ), "Donglord" ) ) then return ACT_ROLL_LEFT, -1; end
	
	if( type( act ) == "string" ) then
		return 1, ply:LookupSequence( act );
	end
	
	return act, -1;
	
end


function DoChosenAnim( ply, key, act )
	
	if( string.find( key, "STAND" ) and string.find( key, "idle" ) ) then
		
		if( ply:GetNWInt( "SelectedIdleAnim", 1 ) > 1 and ply:GetTable().AnimTable ) then
			
			if( ply:GetTable().AnimTable == 1 ) then
				
				if( ply:GetNWInt( "SelectedIdleAnim", 1 ) == 2 ) then -- Crossed Arms
					
					return "LineIdle02";
					
				elseif( ply:GetNWInt( "SelectedIdleAnim", 1 ) == 3 ) then -- Hands in Pockets
					
					return "LineIdle04";
					
				end
				
			elseif( ply:GetTable().AnimTable == 3 ) then
				
				if( ply:GetNWInt( "SelectedIdleAnim", 1 ) == 2 ) then
					
					return "LineIdle01";
					
				elseif( ply:GetNWInt( "SelectedIdleAnim", 1 ) == 3 ) then
					
					return "LineIdle03";
					
				elseif( ply:GetNWInt( "SelectedIdleAnim", 1 ) == 4 ) then
					
					return "LineIdle02";
					
				end
				
			end
			
		end
		
	end
	
	if( string.find( key, "CROUCH" ) and string.find( key, "idle" ) ) then
		
		if( ply:GetNWInt( "SelectedCrouchAnim", 1 ) > 1 and ply:GetTable().AnimTable ) then
			
			if( ply:GetTable().AnimTable == 1 ) then
				
				if( ply:GetNWInt( "SelectedCrouchAnim", 1 ) == 2 ) then -- kungfu
					
					return "crouchidlehide";
					
				elseif( ply:GetNWInt( "SelectedCrouchAnim", 1 ) == 3 ) then -- kneel
					
					return "d2_coast03_prebattle_kneel_idle";
					
				end
				
			elseif( ply:GetTable().AnimTable == 3 ) then
				
				if( ply:GetNWInt( "SelectedCrouchAnim", 1 ) == 2 ) then -- kungfu
					
					return "crouchidlehide";
					
				end
				
			end
			
		end
		
	end
	
	if( string.find( key, "STAND" ) and string.find( key, "walk" ) ) then
		
		if( ply:GetNWInt( "SelectedWalkAnim", 1 ) > 1 and ply:GetTable().AnimTable ) then
			
			if( ply:GetTable().AnimTable == 1 ) then
				
				if( ply:GetNWInt( "SelectedWalkAnim", 1 ) == 2 ) then -- 
					
					
					
				end
				
			elseif( ply:GetTable().AnimTable == 3 ) then
				
				
				
			end
			
		end
		
	end
	
	return act;
	
end

function ForceSequence( ply, anim, time )
	
	if( SERVER ) then
		
		umsg.Start( "FSP" );
			umsg.Entity( ply );
			umsg.String( anim );
			umsg.Short( time or -1 );
		umsg.End();
		
	end
	
	ply:SetCycle( 0 );
	
	ply.ForcedAnimation = anim;
	ply.ForcedAnimStart = CurTime();
	
	if( not time ) then
		
		ply.ForcedAnimTime = -1;
		
	else
		
		ply.ForcedAnimTime = time;
		
	end
	
end

if( CLIENT ) then
	
	function DoAnimEventCl( um )
		
		local ent = um:ReadEntity();
		local act = um:ReadShort();
		
		ent:DoAnimationEvent( act );
		
	end
	usermessage.Hook( "DoAnimEventCl", DoAnimEventCl );

	function msgs.FSP( um )
		
		local ply = um:ReadEntity();
		local anim = um:ReadString();
		local time = um:ReadShort();
		ForceSequence( ply, anim, time );
		
	end
	
	function msgs.RFAT( um )
		
		local ply = um:ReadEntity();
		ply.ForcedAnimTime = 0;
		
	end
	
end