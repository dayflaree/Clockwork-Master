-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2017 at 11:07 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epidemic`
--

-- --------------------------------------------------------

--
-- Table structure for table `epi_characters`
--

CREATE TABLE `epi_characters` (
  `id` int(11) NOT NULL,
  `Name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `SteamID` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Class` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `Age` tinyint(2) NOT NULL,
  `PhysDesc` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `OriMdl` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `CharFlags` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `HeavyWeaponry` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LightWeaponry` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `HasBackpack` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `HasPouch` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `HWAmmo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LWAmmo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `HWDeg` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `LWDeg` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `epi_characters`
--

INSERT INTO `epi_characters` (`id`, `Name`, `SteamID`, `Class`, `Age`, `PhysDesc`, `OriMdl`, `CharFlags`, `HeavyWeaponry`, `LightWeaponry`, `HasBackpack`, `HasPouch`, `HWAmmo`, `LWAmmo`, `HWDeg`, `LWDeg`) VALUES
(35, 'Sarah Zimmer', 'STEAM_0:0:14977049', 'Survivor', 20, 'This physical description won\'t see the light of day.', 'models/drem/cch/female_01.mdl#1', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `epi_inv`
--

CREATE TABLE `epi_inv` (
  `id` int(11) NOT NULL,
  `itemid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `x` tinyint(4) NOT NULL,
  `y` tinyint(4) NOT NULL,
  `amt` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `inv` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `SteamID` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `epi_inv`
--

INSERT INTO `epi_inv` (`id`, `itemid`, `x`, `y`, `amt`, `inv`, `SteamID`) VALUES
(1, 'binoculars', 1, 1, '1', '2', 'STEAM_0:1:2035653'),
(1, '762mm_rounds', 3, 1, '3', '2', 'STEAM_0:1:2035653'),
(27, 'HECU_gasmask', 1, 1, '1', '4', 'STEAM_0:1:2035653'),
(20, 'HECU_gasmask', 1, 1, '1', '3', 'STEAM_0:1:2035653'),
(0, 'HECU_gasmask', 1, 1, '1', '4', 'STEAM_0:1:2035653'),
(0, '762mm_rounds', 2, 1, '25', '3', 'STEAM_0:1:2035653'),
(27, '762mm_rounds', 2, 1, '25', '3', 'STEAM_0:1:2035653'),
(9, '556mm_rounds', 1, 1, '30', '3', 'STEAM_0:1:2035653'),
(9, '30_06s', 2, 1, '40', '3', 'STEAM_0:1:2035653'),
(9, '38_rounds', 1, 2, '30', '3', 'STEAM_0:1:2035653'),
(9, '762mm_rounds', 2, 2, '30', '3', 'STEAM_0:1:2035653'),
(9, '18mm_rounds', 1, 1, '5', '4', 'STEAM_0:1:2035653');

-- --------------------------------------------------------

--
-- Table structure for table `epi_recog`
--

CREATE TABLE `epi_recog` (
  `i` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `recogid` int(255) NOT NULL,
  `SteamID` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `epi_recog`
--

INSERT INTO `epi_recog` (`i`, `id`, `recogid`, `SteamID`) VALUES
(0, 4, 4, 0),
(0, 5, 5, 0),
(0, 6, 6, 0),
(0, 7, 7, 0),
(0, 9, 10, 0),
(0, 10, 9, 0),
(0, 33, 9, 0),
(0, 34, 34, 0),
(0, 35, 34, 0),
(0, 36, 34, 0);

-- --------------------------------------------------------

--
-- Table structure for table `epi_users`
--

CREATE TABLE `epi_users` (
  `id` int(11) NOT NULL,
  `SteamName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SteamID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IP` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Date` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Flags` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `PlayerDesc` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `epi_users`
--

INSERT INTO `epi_users` (`id`, `SteamName`, `SteamID`, `IP`, `Date`, `Flags`, `PlayerDesc`) VALUES
(1, 'Modest Mouse', 'STEAM_0:1:4976333', 'loopback', 'Oct-29-2009', '', ''),
(2, 'teegee', 'STEAM_0:1:2035653', '192.168.0.10:27006', 'May-15-2017', '!#+', 'saucy'),
(3, 'JackHay', 'STEAM_0:1:29236320', '10.49.10.3:27005', 'May-15-2017', '!#+', ''),
(4, 'Eskay-', 'STEAM_0:0:14977049', '98.213.176.49:27005', 'May-16-2017', '!#+', '');
(5, 'Kerrigan', 'STEAM_0:1:27045583', '98.213.176.49:27005', 'May-16-2017', '!#+', '');
(6, 'Bangsi', 'STEAM_0:0:9855450', '98.213.176.49:27005', 'May-16-2017', '!#+', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `epi_characters`
--
ALTER TABLE `epi_characters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `epi_recog`
--
ALTER TABLE `epi_recog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `epi_users`
--
ALTER TABLE `epi_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `epi_characters`
--
ALTER TABLE `epi_characters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `epi_recog`
--
ALTER TABLE `epi_recog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `epi_users`
--
ALTER TABLE `epi_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
