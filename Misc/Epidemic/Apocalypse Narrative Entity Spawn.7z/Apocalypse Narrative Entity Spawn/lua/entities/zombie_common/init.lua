AddCSLuaFile( "cl_init.lua" );
AddCSLuaFile( "shared.lua" );
include( "shared.lua" ); 

local sharedtasks_e = { }
sharedtasks_e["TASK_INVALID"] = 0
sharedtasks_e["TASK_RESET_ACTIVITY"] = 1
sharedtasks_e["TASK_WAIT"] = 2
sharedtasks_e["TASK_ANNOUNCE_ATTACK"] = 3
sharedtasks_e["TASK_WAIT_FACE_ENEMY"] = 4
sharedtasks_e["TASK_WAIT_FACE_ENEMY_RANDOM"] = 5
sharedtasks_e["TASK_WAIT_PVS"] = 6
sharedtasks_e["TASK_SUGGEST_STATE"] = 7
sharedtasks_e["TASK_TARGET_PLAYER"] = 8
sharedtasks_e["TASK_SCRIPT_WALK_TO_TARGET"] = 9
sharedtasks_e["TASK_SCRIPT_RUN_TO_TARGET"] = 10
sharedtasks_e["TASK_SCRIPT_CUSTOM_MOVE_TO_TARGET"] = 11
sharedtasks_e["TASK_MOVE_TO_TARGET_RANGE"] = 12
sharedtasks_e["TASK_MOVE_TO_GOAL_RANGE"] = 13
sharedtasks_e["TASK_MOVE_AWAY_PATH"] = 14
sharedtasks_e["TASK_GET_PATH_AWAY_FROM_BEST_SOUND"] = 15
sharedtasks_e["TASK_SET_GOAL"] = 16
sharedtasks_e["TASK_GET_PATH_TO_GOAL"] = 17
sharedtasks_e["TASK_GET_PATH_TO_ENEMY"] = 18
sharedtasks_e["TASK_GET_PATH_TO_ENEMY_LKP"] = 19
sharedtasks_e["TASK_GET_CHASE_PATH_TO_ENEMY"] = 20
sharedtasks_e["TASK_GET_PATH_TO_ENEMY_LKP_LOS"] = 21
sharedtasks_e["TASK_GET_PATH_TO_ENEMY_CORPSE"] = 22
sharedtasks_e["TASK_GET_PATH_TO_PLAYER"] = 23
sharedtasks_e["TASK_GET_PATH_TO_ENEMY_LOS"] = 24
sharedtasks_e["TASK_GET_FLANK_RADIUS_PATH_TO_ENEMY_LOS"] = 25
sharedtasks_e["TASK_GET_FLANK_ARC_PATH_TO_ENEMY_LOS"] = 26
sharedtasks_e["TASK_GET_PATH_TO_RANGE_ENEMY_LKP_LOS"] = 27
sharedtasks_e["TASK_GET_PATH_TO_TARGET"] = 28
sharedtasks_e["TASK_GET_PATH_TO_TARGET_WEAPON"] = 29
sharedtasks_e["TASK_CREATE_PENDING_WEAPON"] = 30
sharedtasks_e["TASK_GET_PATH_TO_HINTNODE"] = 31
sharedtasks_e["TASK_STORE_LASTPOSITION"] = 32
sharedtasks_e["TASK_CLEAR_LASTPOSITION"] = 33
sharedtasks_e["TASK_STORE_POSITION_IN_SAVEPOSITION"] = 34
sharedtasks_e["TASK_STORE_BESTSOUND_IN_SAVEPOSITION"] = 35
sharedtasks_e["TASK_STORE_BESTSOUND_REACTORIGIN_IN_SAVEPOSITION"] = 36
sharedtasks_e["TASK_REACT_TO_COMBAT_SOUND"] = 37
sharedtasks_e["TASK_STORE_ENEMY_POSITION_IN_SAVEPOSITION"] = 38
sharedtasks_e["TASK_GET_PATH_TO_COMMAND_GOAL"] = 39
sharedtasks_e["TASK_MARK_COMMAND_GOAL_POS"] = 40
sharedtasks_e["TASK_CLEAR_COMMAND_GOAL"] = 41
sharedtasks_e["TASK_GET_PATH_TO_LASTPOSITION"] = 42
sharedtasks_e["TASK_GET_PATH_TO_SAVEPOSITION"] = 43
sharedtasks_e["TASK_GET_PATH_TO_SAVEPOSITION_LOS"] = 44
sharedtasks_e["TASK_GET_PATH_TO_RANDOM_NODE"] = 45
sharedtasks_e["TASK_GET_PATH_TO_BESTSOUND"] = 46
sharedtasks_e["TASK_GET_PATH_TO_BESTSCENT"] = 47
sharedtasks_e["TASK_RUN_PATH"] = 48
sharedtasks_e["TASK_WALK_PATH"] = 49
sharedtasks_e["TASK_WALK_PATH_TIMED"] = 50
sharedtasks_e["TASK_WALK_PATH_WITHIN_DIST"] = 51
sharedtasks_e["TASK_WALK_PATH_FOR_UNITS"] = 52
sharedtasks_e["TASK_RUN_PATH_FLEE"] = 53
sharedtasks_e["TASK_RUN_PATH_TIMED"] = 54
sharedtasks_e["TASK_RUN_PATH_FOR_UNITS"] = 55
sharedtasks_e["TASK_RUN_PATH_WITHIN_DIST"] = 56
sharedtasks_e["TASK_STRAFE_PATH"] = 57
sharedtasks_e["TASK_CLEAR_MOVE_WAIT"] = 58
sharedtasks_e["TASK_SMALL_FLINCH"] = 59
sharedtasks_e["TASK_BIG_FLINCH"] = 60
sharedtasks_e["TASK_DEFER_DODGE"] = 61
sharedtasks_e["TASK_FACE_IDEAL"] = 62
sharedtasks_e["TASK_FACE_REASONABLE"] = 63
sharedtasks_e["TASK_FACE_PATH"] = 64
sharedtasks_e["TASK_FACE_PLAYER"] = 65
sharedtasks_e["TASK_FACE_ENEMY"] = 66
sharedtasks_e["TASK_FACE_HINTNODE"] = 67
sharedtasks_e["TASK_PLAY_HINT_ACTIVITY"] = 68
sharedtasks_e["TASK_FACE_TARGET"] = 69
sharedtasks_e["TASK_FACE_LASTPOSITION"] = 70
sharedtasks_e["TASK_FACE_SAVEPOSITION"] = 71
sharedtasks_e["TASK_FACE_AWAY_FROM_SAVEPOSITION"] = 72
sharedtasks_e["TASK_SET_IDEAL_YAW_TO_CURRENT"] = 73
sharedtasks_e["TASK_RANGE_ATTACK1"] = 74
sharedtasks_e["TASK_RANGE_ATTACK2"] = 75
sharedtasks_e["TASK_MELEE_ATTACK1"] = 76
sharedtasks_e["TASK_MELEE_ATTACK2"] = 77
sharedtasks_e["TASK_RELOAD"] = 78
sharedtasks_e["TASK_SPECIAL_ATTACK1"] = 79
sharedtasks_e["TASK_SPECIAL_ATTACK2"] = 80
sharedtasks_e["TASK_FIND_HINTNODE"] = 81
sharedtasks_e["TASK_FIND_LOCK_HINTNODE"] = 82
sharedtasks_e["TASK_CLEAR_HINTNODE"] = 83
sharedtasks_e["TASK_LOCK_HINTNODE"] = 84
sharedtasks_e["TASK_SOUND_ANGRY"] = 85
sharedtasks_e["TASK_SOUND_DEATH"] = 86
sharedtasks_e["TASK_SOUND_IDLE"] = 87
sharedtasks_e["TASK_SOUND_WAKE"] = 88
sharedtasks_e["TASK_SOUND_PAIN"] = 89
sharedtasks_e["TASK_SOUND_DIE"] = 90
sharedtasks_e["TASK_SPEAK_SENTENCE"] = 91
sharedtasks_e["TASK_WAIT_FOR_SPEAK_FINISH"] = 92
sharedtasks_e["TASK_SET_ACTIVITY"] = 93
sharedtasks_e["TASK_RANDOMIZE_FRAMERATE"] = 94
sharedtasks_e["TASK_SET_SCHEDULE"] = 95
sharedtasks_e["TASK_SET_FAIL_SCHEDULE"] = 96
sharedtasks_e["TASK_SET_TOLERANCE_DISTANCE"] = 97
sharedtasks_e["TASK_SET_ROUTE_SEARCH_TIME"] = 98
sharedtasks_e["TASK_CLEAR_FAIL_SCHEDULE"] = 99
sharedtasks_e["TASK_PLAY_SEQUENCE"] = 100
sharedtasks_e["TASK_PLAY_PRIVATE_SEQUENCE"] = 101
sharedtasks_e["TASK_PLAY_PRIVATE_SEQUENCE_FACE_ENEMY"] = 102
sharedtasks_e["TASK_PLAY_SEQUENCE_FACE_ENEMY"] = 103
sharedtasks_e["TASK_PLAY_SEQUENCE_FACE_TARGET"] = 104
sharedtasks_e["TASK_FIND_COVER_FROM_BEST_SOUND"] = 105
sharedtasks_e["TASK_FIND_COVER_FROM_ENEMY"] = 106
sharedtasks_e["TASK_FIND_LATERAL_COVER_FROM_ENEMY"] = 107
sharedtasks_e["TASK_FIND_BACKAWAY_FROM_SAVEPOSITION"] = 108
sharedtasks_e["TASK_FIND_NODE_COVER_FROM_ENEMY"] = 109
sharedtasks_e["TASK_FIND_NEAR_NODE_COVER_FROM_ENEMY"] = 110
sharedtasks_e["TASK_FIND_FAR_NODE_COVER_FROM_ENEMY"] = 111
sharedtasks_e["TASK_FIND_COVER_FROM_ORIGIN"] = 112
sharedtasks_e["TASK_DIE"] = 113
sharedtasks_e["TASK_WAIT_FOR_SCRIPT"] = 114
sharedtasks_e["TASK_PUSH_SCRIPT_ARRIVAL_ACTIVITY"] = 115
sharedtasks_e["TASK_PLAY_SCRIPT"] = 116
sharedtasks_e["TASK_PLAY_SCRIPT_POST_IDLE"] = 117
sharedtasks_e["TASK_ENABLE_SCRIPT"] = 118
sharedtasks_e["TASK_PLANT_ON_SCRIPT"] = 119
sharedtasks_e["TASK_FACE_SCRIPT"] = 120
sharedtasks_e["TASK_PLAY_SCENE"] = 121
sharedtasks_e["TASK_WAIT_RANDOM"] = 122
sharedtasks_e["TASK_WAIT_INDEFINITE"] = 123
sharedtasks_e["TASK_STOP_MOVING"] = 124
sharedtasks_e["TASK_TURN_LEFT"] = 125
sharedtasks_e["TASK_TURN_RIGHT"] = 126
sharedtasks_e["TASK_REMEMBER"] = 127
sharedtasks_e["TASK_FORGET"] = 128
sharedtasks_e["TASK_WAIT_FOR_MOVEMENT"] = 129
sharedtasks_e["TASK_WAIT_FOR_MOVEMENT_STEP"] = 130
sharedtasks_e["TASK_WAIT_UNTIL_NO_DANGER_SOUND"] = 131
sharedtasks_e["TASK_WEAPON_FIND"] = 132
sharedtasks_e["TASK_WEAPON_PICKUP"] = 133
sharedtasks_e["TASK_WEAPON_RUN_PATH"] = 134
sharedtasks_e["TASK_WEAPON_CREATE"] = 135
sharedtasks_e["TASK_ITEM_PICKUP"] = 136
sharedtasks_e["TASK_ITEM_RUN_PATH"] = 137
sharedtasks_e["TASK_USE_SMALL_HULL"] = 138
sharedtasks_e["TASK_FALL_TO_GROUND"] = 139
sharedtasks_e["TASK_WANDER"] = 140
sharedtasks_e["TASK_FREEZE"] = 141
sharedtasks_e["TASK_GATHER_CONDITIONS"] = 142
sharedtasks_e["TASK_IGNORE_OLD_ENEMIES"] = 143
sharedtasks_e["TASK_DEBUG_BREAK"] = 144
sharedtasks_e["TASK_ADD_HEALTH"] = 145
sharedtasks_e["TASK_ADD_GESTURE_WAIT"] = 146
sharedtasks_e["TASK_ADD_GESTURE"] = 147
sharedtasks_e["TASK_GET_PATH_TO_INTERACTION_PARTNER"] = 148
sharedtasks_e["TASK_PRE_SCRIPT"] = 149

ai.GetTaskID = function( taskName )

	return sharedtasks_e[taskName]

end

local WalkToPoint = ai_schedule.New( "WalkToPoint" );
WalkToPoint:EngTask( "TASK_GET_PATH_TO_ENEMY", 0 );
WalkToPoint:EngTask( "TASK_WALK_PATH", 0 );

local RunAimless = ai_schedule.New( "RunAimless" );
RunAimless:EngTask( "TASK_GET_PATH_TO_RANDOM_NODE", 100 );
RunAimless:EngTask( "TASK_RUN_PATH", 0 );
RunAimless:EngTask( "TASK_WAIT_FOR_MOVEMENT", 0 );

local WanderAimless = ai_schedule.New( "WanderAimless" );
WanderAimless:EngTask( "TASK_GET_PATH_TO_RANDOM_NODE", 200 );
WanderAimless:EngTask( "TASK_WALK_PATH", 0 );
WanderAimless:EngTask( "TASK_WAIT_FOR_MOVEMENT", 0 );

local FacePoint = ai_schedule.New( "FacePoint" );
FacePoint:EngTask( "TASK_FACE_ENEMY", 0 );

local RunToPoint = ai_schedule.New( "RunToPoint" );
RunToPoint:EngTask( "TASK_FACE_ENEMY", 0 );
RunToPoint:EngTask( "TASK_GET_PATH_TO_ENEMY", 0 );
RunToPoint:EngTask( "TASK_RUN_PATH", 0 );
RunToPoint:EngTask( "TASK_WAIT_FOR_MOVEMENT", 0 );

InfectedSounds = { };

InfectedSounds["Idle"] = { };
InfectedSounds["Alert"] = { };
InfectedSounds["Jump"] = { };
InfectedSounds["Attack"] = { };
InfectedSounds["Die"] = { };
InfectedSounds["Miss"] = { };
InfectedSounds["Pain"] = { };
InfectedSounds["Warn"] = { };

InfectedSounds["Attack"]["Male"] = {
	"necropolis/infected/common/action/rage/shoved_1.wav",
	"necropolis/infected/common/action/rage/shoved_2.wav",
	"necropolis/infected/common/action/rage/shoved_3.wav",
	"necropolis/infected/common/action/rage/shoved_4.wav",
	"necropolis/infected/common/action/rage/male/rage_50.wav",
	"necropolis/infected/common/action/rage/male/rage_51.wav",
	"necropolis/infected/common/action/rage/male/rage_52.wav",
	"necropolis/infected/common/action/rage/male/rage_53.wav",
	"necropolis/infected/common/action/rage/male/rage_54.wav",
	"necropolis/infected/common/action/rage/male/rage_55.wav",
	"necropolis/infected/common/action/rage/male/rage_56.wav",
	"necropolis/infected/common/action/rage/male/rage_57.wav",
	"necropolis/infected/common/action/rage/male/rage_58.wav",
	"necropolis/infected/common/action/rage/male/rage_59.wav",
	"necropolis/infected/common/action/rage/male/rage_60.wav",
	"necropolis/infected/common/action/rage/male/rage_61.wav",
	"necropolis/infected/common/action/rage/male/rage_62.wav",
	"necropolis/infected/common/action/rage/male/rage_64.wav",
	"necropolis/infected/common/action/rage/male/rage_65.wav",
	"necropolis/infected/common/action/rage/male/rage_66.wav",
	"necropolis/infected/common/action/rage/male/rage_67.wav",
	"necropolis/infected/common/action/rage/male/rage_68.wav",
	"necropolis/infected/common/action/rage/male/rage_69.wav",
	"necropolis/infected/common/action/rage/male/rage_70.wav",
	"necropolis/infected/common/action/rage/male/rage_71.wav",
	"necropolis/infected/common/action/rage/male/rage_72.wav",
	"necropolis/infected/common/action/rage/male/rage_73.wav",
	"necropolis/infected/common/action/rage/male/rage_74.wav",
	"necropolis/infected/common/action/rage/male/rage_75.wav",
	"necropolis/infected/common/action/rage/male/rage_76.wav",
	"necropolis/infected/common/action/rage/male/rage_77.wav",
	"necropolis/infected/common/action/rage/male/rage_78.wav",
	"necropolis/infected/common/action/rage/male/rage_79.wav",
	"necropolis/infected/common/action/rage/male/rage_80.wav",
	"necropolis/infected/common/action/rage/male/rage_81.wav",
	"necropolis/infected/common/action/rage/male/rage_82.wav",
}

InfectedSounds["Alert"]["Male"] = {
	"necropolis/infected/common/alert/alert/alert13.wav",
	"necropolis/infected/common/alert/alert/alert16.wav",
	"necropolis/infected/common/alert/alert/alert22.wav",
	"necropolis/infected/common/alert/alert/alert23.wav",
	"necropolis/infected/common/alert/alert/alert25.wav",
	"necropolis/infected/common/alert/alert/alert26.wav",
	"necropolis/infected/common/alert/alert/alert27.wav",
	"necropolis/infected/common/alert/alert/alert36.wav",
	"necropolis/infected/common/alert/alert/alert37.wav",
	"necropolis/infected/common/alert/alert/alert38.wav",
	"necropolis/infected/common/alert/alert/alert39.wav",
	"necropolis/infected/common/alert/alert/alert40.wav",
	"necropolis/infected/common/alert/alert/alert41.wav",
	"necropolis/infected/common/alert/alert/alert42.wav",
	"necropolis/infected/common/alert/alert/alert43.wav",
	"necropolis/infected/common/alert/alert/alert44.wav",
	"necropolis/infected/common/alert/alert/male/alert50.wav",
	"necropolis/infected/common/alert/alert/male/alert51.wav",
	"necropolis/infected/common/alert/alert/male/alert52.wav",
	"necropolis/infected/common/alert/alert/male/alert53.wav",
	"necropolis/infected/common/alert/alert/male/alert54.wav",
	"necropolis/infected/common/alert/alert/male/alert55.wav",
}

InfectedSounds["Die"]["Male"] = {
	"necropolis/infected/common/action/die/death_14.wav",
	"necropolis/infected/common/action/die/death_17.wav",
	"necropolis/infected/common/action/die/death_18.wav",
	"necropolis/infected/common/action/die/death_19.wav",
	"necropolis/infected/common/action/die/death_22.wav",
	"necropolis/infected/common/action/die/death_23.wav",
	"necropolis/infected/common/action/die/death_24.wav",
	"necropolis/infected/common/action/die/death_25.wav",
	"necropolis/infected/common/action/die/death_26.wav",
	"necropolis/infected/common/action/die/death_27.wav",
	"necropolis/infected/common/action/die/death_28.wav",
	"necropolis/infected/common/action/die/death_29.wav",
	"necropolis/infected/common/action/die/death_30.wav",
	"necropolis/infected/common/action/die/death_32.wav",
	"necropolis/infected/common/action/die/death_33.wav",
	"necropolis/infected/common/action/die/death_34.wav",
	"necropolis/infected/common/action/die/death_35.wav",
	"necropolis/infected/common/action/die/death_36.wav",
	"necropolis/infected/common/action/die/death_37.wav",
	"necropolis/infected/common/action/die/death_38.wav",
	"necropolis/infected/common/action/die/male/death_40.wav",
	"necropolis/infected/common/action/die/male/death_41.wav",
	"necropolis/infected/common/action/die/male/death_42.wav",
	"necropolis/infected/common/action/die/male/death_43.wav",
	"necropolis/infected/common/action/die/male/death_44.wav",
	"necropolis/infected/common/action/die/male/death_45.wav",
	"necropolis/infected/common/action/die/male/death_46.wav",
	"necropolis/infected/common/action/die/male/death_47.wav",
	"necropolis/infected/common/action/die/male/death_48.wav",
	"necropolis/infected/common/action/die/male/death_49.wav",
}

InfectedSounds["Idle"]["Male"] = {
	"necropolis/infected/common/idle/breathing/breathing01.wav",
	"necropolis/infected/common/idle/breathing/breathing08.wav",
	"necropolis/infected/common/idle/breathing/breathing09.wav",
	"necropolis/infected/common/idle/breathing/breathing10.wav",
	"necropolis/infected/common/idle/breathing/breathing13.wav",
	"necropolis/infected/common/idle/breathing/breathing16.wav",
	"necropolis/infected/common/idle/breathing/breathing18.wav",
	"necropolis/infected/common/idle/breathing/breathing25.wav",
	"necropolis/infected/common/idle/breathing/breathing26.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_01.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_02.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_03.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_04.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_06.wav",
	"necropolis/infected/common/idle/moaning/moan01.wav",
	"necropolis/infected/common/idle/moaning/moan02.wav",
	"necropolis/infected/common/idle/moaning/moan03.wav",
	"necropolis/infected/common/idle/moaning/moan04.wav",
	"necropolis/infected/common/idle/moaning/moan05.wav",
	"necropolis/infected/common/idle/moaning/moan06.wav",
	"necropolis/infected/common/idle/moaning/moan07.wav",
	"necropolis/infected/common/idle/moaning/moan08.wav",
	"necropolis/infected/common/idle/moaning/moan09.wav",
	"necropolis/infected/common/idle/mumbling/mumbling01.wav",
	"necropolis/infected/common/idle/mumbling/mumbling02.wav",
	"necropolis/infected/common/idle/mumbling/mumbling03.wav",
	"necropolis/infected/common/idle/mumbling/mumbling04.wav",
	"necropolis/infected/common/idle/mumbling/mumbling05.wav",
	"necropolis/infected/common/idle/mumbling/mumbling06.wav",
	"necropolis/infected/common/idle/mumbling/mumbling07.wav",
	"necropolis/infected/common/idle/mumbling/mumbling08.wav",
}

InfectedSounds["Alert"]["Female"] = {
	"necropolis/infected/common/alert/alert/alert13.wav",
	"necropolis/infected/common/alert/alert/alert16.wav",
	"necropolis/infected/common/alert/alert/alert22.wav",
	"necropolis/infected/common/alert/alert/alert23.wav",
	"necropolis/infected/common/alert/alert/alert25.wav",
	"necropolis/infected/common/alert/alert/alert26.wav",
	"necropolis/infected/common/alert/alert/alert27.wav",
	"necropolis/infected/common/alert/alert/alert36.wav",
	"necropolis/infected/common/alert/alert/alert37.wav",
	"necropolis/infected/common/alert/alert/alert38.wav",
	"necropolis/infected/common/alert/alert/alert39.wav",
	"necropolis/infected/common/alert/alert/alert40.wav",
	"necropolis/infected/common/alert/alert/alert41.wav",
	"necropolis/infected/common/alert/alert/alert42.wav",
	"necropolis/infected/common/alert/alert/alert43.wav",
	"necropolis/infected/common/alert/alert/alert44.wav",
	"necropolis/infected/common/alert/alert/female/alert50.wav",
	"necropolis/infected/common/alert/alert/female/alert51.wav",
	"necropolis/infected/common/alert/alert/female/alert52.wav",
	"necropolis/infected/common/alert/alert/female/alert53.wav",
	"necropolis/infected/common/alert/alert/female/alert54.wav",
	"necropolis/infected/common/alert/alert/female/alert55.wav",
}

InfectedSounds["Idle"]["Female"] = {
	"necropolis/infected/common/idle/breathing/breathing01.wav",
	"necropolis/infected/common/idle/breathing/breathing08.wav",
	"necropolis/infected/common/idle/breathing/breathing09.wav",
	"necropolis/infected/common/idle/breathing/breathing10.wav",
	"necropolis/infected/common/idle/breathing/breathing13.wav",
	"necropolis/infected/common/idle/breathing/breathing16.wav",
	"necropolis/infected/common/idle/breathing/breathing18.wav",
	"necropolis/infected/common/idle/breathing/breathing25.wav",
	"necropolis/infected/common/idle/breathing/breathing26.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_01.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_02.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_03.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_04.wav",
	"necropolis/infected/common/idle/breathing/idle_breath_06.wav",
	"necropolis/infected/common/idle/moaning/moan01.wav",
	"necropolis/infected/common/idle/moaning/moan02.wav",
	"necropolis/infected/common/idle/moaning/moan03.wav",
	"necropolis/infected/common/idle/moaning/moan04.wav",
	"necropolis/infected/common/idle/moaning/moan05.wav",
	"necropolis/infected/common/idle/moaning/moan06.wav",
	"necropolis/infected/common/idle/moaning/moan07.wav",
	"necropolis/infected/common/idle/moaning/moan08.wav",
	"necropolis/infected/common/idle/moaning/moan09.wav",
	"necropolis/infected/common/idle/mumbling/mumbling01.wav",
	"necropolis/infected/common/idle/mumbling/mumbling02.wav",
	"necropolis/infected/common/idle/mumbling/mumbling03.wav",
	"necropolis/infected/common/idle/mumbling/mumbling04.wav",
	"necropolis/infected/common/idle/mumbling/mumbling05.wav",
	"necropolis/infected/common/idle/mumbling/mumbling06.wav",
	"necropolis/infected/common/idle/mumbling/mumbling07.wav",
	"necropolis/infected/common/idle/mumbling/mumbling08.wav",
}

InfectedSounds["Attack"]["Female"] = {
	"necropolis/infected/common/action/rage/shoved_1.wav",
	"necropolis/infected/common/action/rage/shoved_2.wav",
	"necropolis/infected/common/action/rage/shoved_3.wav",
	"necropolis/infected/common/action/rage/shoved_4.wav",
	"necropolis/infected/common/action/rage/female/rage_50.wav",
	"necropolis/infected/common/action/rage/female/rage_51.wav",
	"necropolis/infected/common/action/rage/female/rage_52.wav",
	"necropolis/infected/common/action/rage/female/rage_53.wav",
	"necropolis/infected/common/action/rage/female/rage_54.wav",
	"necropolis/infected/common/action/rage/female/rage_55.wav",
	"necropolis/infected/common/action/rage/female/rage_56.wav",
	"necropolis/infected/common/action/rage/female/rage_57.wav",
	"necropolis/infected/common/action/rage/female/rage_58.wav",
	"necropolis/infected/common/action/rage/female/rage_59.wav",
	"necropolis/infected/common/action/rage/female/rage_60.wav",
	"necropolis/infected/common/action/rage/female/rage_61.wav",
	"necropolis/infected/common/action/rage/female/rage_62.wav",
	"necropolis/infected/common/action/rage/female/rage_64.wav",
	"necropolis/infected/common/action/rage/female/rage_65.wav",
	"necropolis/infected/common/action/rage/female/rage_66.wav",
	"necropolis/infected/common/action/rage/female/rage_67.wav",
	"necropolis/infected/common/action/rage/female/rage_68.wav",
	"necropolis/infected/common/action/rage/female/rage_69.wav",
	"necropolis/infected/common/action/rage/female/rage_70.wav",
	"necropolis/infected/common/action/rage/female/rage_71.wav",
	"necropolis/infected/common/action/rage/female/rage_72.wav",
	"necropolis/infected/common/action/rage/female/rage_73.wav",
	"necropolis/infected/common/action/rage/female/rage_74.wav",
	"necropolis/infected/common/action/rage/female/rage_75.wav",
	"necropolis/infected/common/action/rage/female/rage_76.wav",
	"necropolis/infected/common/action/rage/female/rage_77.wav",
	"necropolis/infected/common/action/rage/female/rage_78.wav",
	"necropolis/infected/common/action/rage/female/rage_79.wav",
	"necropolis/infected/common/action/rage/female/rage_80.wav",
	"necropolis/infected/common/action/rage/female/rage_81.wav",
	"necropolis/infected/common/action/rage/female/rage_82.wav",
}

InfectedSounds["Die"]["Female"] = {
	"necropolis/infected/common/action/die/death_14.wav",
	"necropolis/infected/common/action/die/death_17.wav",
	"necropolis/infected/common/action/die/death_18.wav",
	"necropolis/infected/common/action/die/death_19.wav",
	"necropolis/infected/common/action/die/death_22.wav",
	"necropolis/infected/common/action/die/death_23.wav",
	"necropolis/infected/common/action/die/death_24.wav",
	"necropolis/infected/common/action/die/death_25.wav",
	"necropolis/infected/common/action/die/death_26.wav",
	"necropolis/infected/common/action/die/death_27.wav",
	"necropolis/infected/common/action/die/death_28.wav",
	"necropolis/infected/common/action/die/death_29.wav",
	"necropolis/infected/common/action/die/death_30.wav",
	"necropolis/infected/common/action/die/death_32.wav",
	"necropolis/infected/common/action/die/death_33.wav",
	"necropolis/infected/common/action/die/death_34.wav",
	"necropolis/infected/common/action/die/death_35.wav",
	"necropolis/infected/common/action/die/death_36.wav",
	"necropolis/infected/common/action/die/death_37.wav",
	"necropolis/infected/common/action/die/death_38.wav",
	"necropolis/infected/common/action/die/female/death_40.wav",
	"necropolis/infected/common/action/die/female/death_41.wav",
	"necropolis/infected/common/action/die/female/death_42.wav",
	"necropolis/infected/common/action/die/female/death_43.wav",
	"necropolis/infected/common/action/die/female/death_44.wav",
	"necropolis/infected/common/action/die/female/death_45.wav",
	"necropolis/infected/common/action/die/female/death_46.wav",
	"necropolis/infected/common/action/die/female/death_47.wav",
	"necropolis/infected/common/action/die/female/death_48.wav",
	"necropolis/infected/common/action/die/female/death_49.wav",
}

local ZombieHit = {
	"necropolis/infected/common/hit/hit_punch_01.wav",
	"necropolis/infected/common/hit/hit_punch_02.wav",
	"necropolis/infected/common/hit/hit_punch_03.wav",
	"necropolis/infected/common/hit/hit_punch_04.wav",
	"necropolis/infected/common/hit/hit_punch_05.wav",
	"necropolis/infected/common/hit/hit_punch_06.wav",
	"necropolis/infected/common/hit/hit_punch_07.wav",
	"necropolis/infected/common/hit/hit_punch_08.wav",
	"necropolis/infected/common/hit/Punch_Boxing_BodyHit03.wav",
	"necropolis/infected/common/hit/Punch_Boxing_BodyHit04.wav",
	"necropolis/infected/common/hit/Punch_Boxing_FaceHit4.wav",
	"necropolis/infected/common/hit/Punch_Boxing_FaceHit5.wav",
	"necropolis/infected/common/hit/Punch_Boxing_FaceHit6.wav",
};

local ZombieModels = { 

	"models/infected/necropolis/common/female_01.mdl",
	"models/infected/necropolis/common/female_02.mdl",
	"models/infected/necropolis/common/female_03.mdl",
	"models/infected/necropolis/common/female_04.mdl",
	"models/infected/necropolis/common/female_06.mdl",
	"models/infected/necropolis/common/female_07.mdl",
	"models/infected/necropolis/common/male_01.mdl",
	"models/infected/necropolis/common/male_02.mdl",
	"models/infected/necropolis/common/male_03.mdl",
	"models/infected/necropolis/common/male_04.mdl",
	"models/infected/necropolis/common/male_05.mdl",
	"models/infected/necropolis/common/male_06.mdl",
	"models/infected/necropolis/common/male_07.mdl",
	"models/infected/necropolis/common/male_08.mdl",
	"models/infected/necropolis/common/male_12.mdl",
	"models/infected/necropolis/common/male_13.mdl",
	"models/infected/necropolis/common/male_14.mdl",
	"models/infected/necropolis/common/male_15.mdl",
	"models/infected/necropolis/common/male_16.mdl",
	"models/infected/necropolis/common/male_17.mdl",
	"models/infected/necropolis/common/male_18.mdl",
	"models/infected/necropolis/common/male_19.mdl",

};

local MaleInfectedBecomeAlertSounds =
{

	"necropolis/infected/common/alert/becomeAlert/become_alert01.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert04.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert09.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert11.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert12.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert14.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert17.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert18.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert21.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert23.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert25.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert26.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert29.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert38.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert41.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert54.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert55.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert56.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert57.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert58.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert59.wav",
	"necropolis/infected/common/alert/becomeAlert/hiss01.wav",
	"necropolis/infected/common/alert/becomeAlert/howl01.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize01.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize02.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize03.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize04.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize05.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize06.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize07.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize08.wav",
	"necropolis/infected/common/alert/becomeAlert/shout01.wav",
	"necropolis/infected/common/alert/becomeAlert/shout02.wav",
	"necropolis/infected/common/alert/becomeAlert/shout03.wav",
	"necropolis/infected/common/alert/becomeAlert/shout04.wav",
	"necropolis/infected/common/alert/becomeAlert/shout06.wav",
	"necropolis/infected/common/alert/becomeAlert/shout07.wav",
	"necropolis/infected/common/alert/becomeAlert/shout08.wav",
	"necropolis/infected/common/alert/becomeAlert/shout09.wav",
	"necropolis/infected/common/alert/becomeAlert/male/become_alert60.wav",
	"necropolis/infected/common/alert/becomeAlert/male/become_alert61.wav",
	"necropolis/infected/common/alert/becomeAlert/male/become_alert62.wav",
	"necropolis/infected/common/alert/becomeAlert/male/become_alert63.wav",
	
}

local FemaleInfectedBecomeAlertSounds =
{

	"necropolis/infected/common/alert/becomeAlert/become_alert01.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert04.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert09.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert11.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert12.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert14.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert17.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert18.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert21.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert23.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert25.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert26.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert29.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert38.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert41.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert54.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert55.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert56.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert57.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert58.wav",
	"necropolis/infected/common/alert/becomeAlert/become_alert59.wav",
	"necropolis/infected/common/alert/becomeAlert/hiss01.wav",
	"necropolis/infected/common/alert/becomeAlert/howl01.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize01.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize02.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize03.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize04.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize05.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize06.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize07.wav",
	"necropolis/infected/common/alert/becomeAlert/recognize08.wav",
	"necropolis/infected/common/alert/becomeAlert/shout01.wav",
	"necropolis/infected/common/alert/becomeAlert/shout02.wav",
	"necropolis/infected/common/alert/becomeAlert/shout03.wav",
	"necropolis/infected/common/alert/becomeAlert/shout04.wav",
	"necropolis/infected/common/alert/becomeAlert/shout06.wav",
	"necropolis/infected/common/alert/becomeAlert/shout07.wav",
	"necropolis/infected/common/alert/becomeAlert/shout08.wav",
	"necropolis/infected/common/alert/becomeAlert/shout09.wav",
	"necropolis/infected/common/alert/becomeAlert/female/become_alert60.wav",
	"necropolis/infected/common/alert/becomeAlert/female/become_alert61.wav",
	"necropolis/infected/common/alert/becomeAlert/female/become_alert62.wav",
	"necropolis/infected/common/alert/becomeAlert/female/become_alert63.wav",
	
}

local MaleRageAtSounds =
{

	"necropolis/infected/common/action/rageAt/rage_at_victim01.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim02.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim21.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim22.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim25.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim26.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim34.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim35.wav",
	"necropolis/infected/common/action/rageAt/snarl_4.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim20.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim21.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim22.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim23.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim24.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim25.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim26.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim27.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim28.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim29.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim30.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim31.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim32.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim33.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim34.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim35.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim36.wav",
	"necropolis/infected/common/action/rageAt/male/rage_at_victim37.wav",
	
}

local FemaleRageAtSounds =
{

	"necropolis/infected/common/action/rageAt/rage_at_victim01.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim02.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim21.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim22.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim25.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim26.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim34.wav",
	"necropolis/infected/common/action/rageAt/rage_at_victim35.wav",
	"necropolis/infected/common/action/rageAt/snarl_4.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim20.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim21.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim22.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim23.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim24.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim25.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim26.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim27.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim28.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim29.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim30.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim31.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim32.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim33.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim34.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim35.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim36.wav",
	"necropolis/infected/common/action/rageAt/female/rage_at_victim37.wav",
	
}

local GoreSounds =
{

	"necropolis/infected/common/gore/bullets/bullet_gib_01.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_02.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_03.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_04.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_05.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_06.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_07.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_08.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_09.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_10.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_11.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_12.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_13.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_14.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_15.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_16.wav",
	"necropolis/infected/common/gore/bullets/bullet_gib_17.wav",
	
}

local HeadshotSounds =
{

	"necropolis/infected/common/gore/headless/headless_1.wav",
	"necropolis/infected/common/gore/headless/headless_2.wav",
	"necropolis/infected/common/gore/headless/headless_3.wav",
	"necropolis/infected/common/gore/headless/headless_4.wav",
	
}

function ENT:Initialize()
   
    self:SetModel( table.Random( ZombieModels ) );

    self:SetHullType( HULL_HUMAN );
    self:SetHullSizeNormal();
	
    self:SetSolid( SOLID_BBOX );
    self:SetMoveType( MOVETYPE_STEP );
	
   	self:CapabilitiesAdd( bit.bor( bit.bor( bit.bor( bit.bor( CAP_MOVE_GROUND, CAP_ANIMATEDFACE ), CAP_TURN_HEAD ), CAP_MOVE_CLIMB ), CAP_MOVE_JUMP ) );
   	
    self:SetMaxYawSpeed( 5000 );

	self:SetHealth( math.random( 7, 15 ) );
	
	if( string.find( self:GetModel(), "female" ) ) then
	
		self.IsMale = false;
	
	else
	
		self.IsMale = true;
	
	end
	
	self.Alerted = false;
	self.Target = nil;
	self.NextThinkTime = 0;
	self.NextEntityBlockCheck = 0;
	self.LastSeen = -30;
	
	self.RageSoundTime = 0;
	
	self.SearchTime = math.random( 6, 14 );
	
	self.AnimationRunning = false;
	
	self.NextRandomPathWander = 0;
	self.CanIdleWalk = true;
	
	self.NextSoundTime = 0;
	
end

function ENT:Death( num )
	
	self:SetRenderFX( 23 );
	self.Dead = true;
	
	for n = 1, num do
	
		local trace = { }
		
		trace.start = self:GetPos() + Vector( 0, 0, 50 );
		trace.endpos = trace.start + self:GetRight() * math.random( -40, 40 ) + self:GetForward() * math.random( -40, 40 ) + self:GetUp() * -80;
		trace.filter = self;
		
		local tr = util.TraceLine( trace );
		
		local pos = tr.HitPos;
		local norm = tr.HitNormal;
	
		util.Decal( "Blood", pos + norm, pos - norm );
		
	end
	--[[
	timer.Simple( 0.1, function() -- delay till next frame
		
		umsg.Start( "FindMyRagEnt" );
			umsg.Entity( self );
		umsg.End();
		
	end );
	
	local gored = false;
	
	if( self.RandomBodyPartExplode ) then
	
		local f = function()

			umsg.Start( "DRRP" );
				umsg.Entity( self );
			umsg.End();	
			
		end
		timer.Simple( .15, f );

		gored = true;
	
	else
		
		if( self.LegShot ) then
		
			local f = function()

				umsg.Start( "DRL" );
					umsg.Entity( self );
				umsg.End();	
				
			end
			timer.Simple( .15, f );		
			
			gored = true;
		
		end
		
		if( self.ArmShot ) then
			
			local f = function()

				umsg.Start( "DRA" );
					umsg.Entity( self );
				umsg.End();	
				
			end
			timer.Simple( .15, f );
			
			gored = true;
			
		end
		
		if( self.HeadShot ) then
			
			local f = function()

				umsg.Start( "DRH" );
					umsg.Entity( self );
				umsg.End();
				
			end
			timer.Simple( .15, f );
			
			gored = true;
			
		end
		
	end
	
	if( gored ) then
		
		self:DoCommonGibSound();
		
	end
	--]]
	if( self.HeadShot ) then
		
		self:DoCommonHSDeathSound();
		
	else
		
		self:DoCommonDeathSound();
		
	end
	
	timer.Simple( 1, function()
		if( self and self:IsValid() ) then
			self:Remove();
		end
	end );

end

util.AddNetworkString( "zGore" );

function ENT:OnTakeDamage( dmg, ignorehs, gorey, lowhschance )
	
	if( self.Dead ) then return end
	
	local bldamt = 6;
	
	if( gorey ) then
		
		bldamt = 15;
		
		if( math.random( 1, 4 ) <= 3 ) then
		
			self.RandomBodyPartExplode = true;
		
		end
	
	end
	
	net.Start( "zGore" );
		net.WriteVector( dmg:GetDamagePosition() );
		net.WriteEntity( self );
	net.Broadcast();
	
	if( lowhschance ) then
	
		if( math.random( 1, 12 ) > 2 ) then
		
			ignorehs = true;
		
		end
	
	end
	
	if( !ignorehs and ( dmg:GetDamagePosition() - self:GetPos() ):Length() > 58 ) then

		self:SetHealth( 0 ); -- headshote
		self.HeadShot = true;
	
	else

		self:SetHealth( self:Health() - dmg:GetDamage() );
		
		if( ( dmg:GetDamagePosition() - self:GetPos() ):Length() < 30 ) then
			
			self.LegShot = true;
			
		elseif( math.random( 1, 5 ) <= 2 ) then
			
			self.ArmShot = true;
			
		end

	end
	
	if( self:Health() <= 0 ) then
		
		self:Death( bldamt );
 	
	end

end

function ENT:AttackTarget()
	
	if( self.Dead ) then return end
	
	if( self.Target and self.Target:IsValid() and self.Target:Health() > 0 and not self.Target:GetTable().ObserveMode and self.Entity:Health() > 0 ) then
		
		self.Target:TakeDamage( math.random( 7, 14 ), self );
		--self.Target:CallEvent( "HH" );
		self.Target:ViewPunch( Angle( math.random( -1, 1 ), math.random( -1, 1 ), 0 ) * 4 );
		self.Target:EmitSound( table.Random( ZombieHit ) );

	end

end

function ENT:DoCommonIdleSound()
	
	if( self.Dead ) then return end
	
	self:EmitSound( InfectedSounds["Idle"]["Male"][math.random( 1, #InfectedSounds["Idle"]["Male"] )] );
	
end

function ENT:DoCommonAlertSound( volume )
	
	if( self.Dead ) then return end
	
	if( self.IsMale ) then
		
		self:EmitSound( table.Random( InfectedSounds["Alert"]["Male"] ), volume );
	
	else
	
		self:EmitSound( table.Random( InfectedSounds["Alert"]["Female"] ), volume );
	
	end

end

function ENT:DoCommonBecomeAlertSound( volume )
	
	if( self.Dead ) then return end
	
	if( self.IsMale ) then
		
		self:EmitSound( table.Random( MaleInfectedBecomeAlertSounds ), volume );
	
	else
	
		self:EmitSound( table.Random( FemaleInfectedBecomeAlertSounds ), volume );
	
	end

end

function ENT:DoCommonRageSound( volume )
	
	if( self.Dead ) then return end
	
	if( self.IsMale ) then
		
		self:EmitSound( table.Random( InfectedSounds["Attack"]["Male"] ), volume );
	
	else
	
		self:EmitSound( table.Random( InfectedSounds["Attack"]["Female"] ), volume );
	
	end

end

function ENT:DoCommonDeathSound( volume )
	
	if( self.IsMale ) then
		
		self:EmitSound( table.Random( InfectedSounds["Die"]["Male"] ), volume );
	
	else
	
		self:EmitSound( table.Random( InfectedSounds["Die"]["Female"] ), volume );
	
	end

end

function ENT:DoCommonHSDeathSound( volume )
	
	self:EmitSound( table.Random( HeadshotSounds ), volume );

end

function ENT:DoCommonGibSound()
	
	self:EmitSound( table.Random( GoreSounds ) );
	
end

function ENT:HandleSound()
	
	if( self.Dead ) then return end
	
	if( CurTime() > self.NextSoundTime ) then
		
		if( self.Alerted ) then
		
			self:DoCommonAlertSound();
			self.NextSoundTime = CurTime() + math.random( 1.5, 3 );
			
		else
		
			self:DoCommonIdleSound();
			self.NextSoundTime = CurTime() + math.random( 4, 7 );
		
		end
		
	end

end

function ENT:RunToPoint( pos )
	
	if( self.Dead ) then return end
	
	self:SetEnemy( self );
	self:UpdateEnemyMemory( self, pos );
	self:StartSchedule( RunToPoint );
	
	self.CanIdleWalk = false;
	
end

function ENT:FacePoint( pos )
	
	if( self.Dead ) then return end
	
	self:SetEnemy( self );
	self:UpdateEnemyMemory( self, pos );
	self:StartSchedule( FacePoint );

end

function ENT:RunToEnemy( enemy )
	
	if( self.Dead ) then return end
	
	local offsetvec = Vector( 0, 0, 0 );
	offsetvec.x = math.random( -45, 45 );
	offsetvec.y = math.random( -45, 45 );
	
	if( type( enemy ) == "Vector" ) then
		
		self:SetEnemy( self );
		self:UpdateEnemyMemory( self, self:GetPos() + offsetvec );
		self:StartSchedule( RunToPoint );
		
	else
		
		self:SetEnemy( enemy );
		self:UpdateEnemyMemory( enemy, enemy:GetPos() + offsetvec );
		self:StartSchedule( RunToPoint );
		
	end

end

function ENT:UpdateEnemy( enemy )
	
	if( self.Dead ) then return end
	
	local offsetvec = Vector( 0, 0, 0 );
	offsetvec.x = math.random( -45, 45 );
	offsetvec.y = math.random( -45, 45 );
	
	if( type( enemy ) == "Vector" ) then
		
		self:UpdateEnemyMemory( self, self:GetPos() + offsetvec );
		
	else
		
		self:UpdateEnemyMemory( enemy, enemy:GetPos() + offsetvec );
		
	end

end

function ENT:TargetEntity( enemy )
	
	if( self.Dead ) then return end
	
	self.Alerted = true;
	self.Target = enemy;

end

function ENT:CanSee( ent )
	
	if( self.Dead ) then return false end
	
	if( self:Visible( ent ) ) then
		
		return true;
		
	end
	
	local trace = { };
	trace.start = self:EyePos();
	trace.endpos = ent:EyePos();
	trace.filter = self;
	
	local tr = util.TraceLine( trace );
	
	if( tr.Entity and tr.Entity:IsValid() and tr.Entity == ent ) then
		
		return true;
		
	end
	
	return false;
	
end

function ENT:QualifiedTarget( target )
	
	if( self.Dead ) then return false end
	
	if( not target or not target:IsValid() ) then
		return false;
	end

	if( not target:IsPlayer() or not target:Alive() ) then
		return false;
	end
	
	return true;

end

function ENT:PlayAnimation( anim )
	
	local seq = 0;
	
	if( type( anim ) == "string" ) then
		seq = self:LookupSequence( anim );
	else
		seq = self:SelectWeightedSequence( anim );
	end
	
	self:SetNPCState( NPC_STATE_SCRIPT );
	self:ResetSequence( seq );
	
	self.AnimationRunning = true;
	
	local seqdur = self:SequenceDuration();
	self.AnimationEndTime = CurTime() + seqdur;
	
	timer.Simple( seqdur, function() 
	
		self.AnimationRunning = false;
		
		if( self:IsValid() ) then
		
			self:SetNPCState( NPC_STATE_NONE );
		
		end
		
	end );
	
	return seqdur;

end

function ENT:FindEnemy()
	
	if( self.Dead ) then return end
	
	local lowestdist = math.huge;

	for k, v in pairs( player.GetAll() ) do
	
		if( self:QualifiedTarget( v ) ) then
		
			local dist = ( v:GetPos() - self:GetPos() ):Length();
			local reqdist = 100;
			local vis = self:CanSee( v );
			
			if( vis ) then
			
				reqdist = 330;
			
			end
			
			if( vis and v:FlashlightIsOn() ) then
			
				reqdist = 800;
			
			end		
			
			if( v == self.Target ) then
			
				reqdist = 2500;
			
			end		
			
			if( reqdist >= dist ) then
			
				if( lowestdist > dist ) then
				
					lowestdist = dist;
					self.LastSeen = CurTime();
					self.Target = v;
				
				end
	
			end
			
		end
	
	end

end

function ENT:SelectSchedule()

end

function ENT:ZombieThink()
	
	if( self.Dead ) then return end
	
	if( not self.Alerted ) then
	
		self:FindEnemy();
		
		if( self.Target and self.Target:IsValid() ) then
			
			local pos = self.Target:GetPos();
			self:DoCommonBecomeAlertSound();
			self.Alerted = true;
		
		else
			
			if( self.CanIdleWalk and CurTime() > self.NextRandomPathWander ) then
			
				local d = math.random( 1, 30 );
				
				if( d > 5 ) then
					
					self:StartSchedule( WanderAimless );
					
				else
				
					self:StartSchedule( RunAimless );
					self:DoCommonAlertSound();
				
				end
				
				self.NextRandomPathWander = CurTime() + math.random( 4, 10 );
				
			end
		
		end
	
	else
		
		if( not self:QualifiedTarget( self.Target ) ) then
		
			self.Target = nil;
			self.Alerted = false;
			self.CanIdleWalk = true;
			self.LastSeen = -30;
			
			return;
		
		else
		
			self:FindEnemy();
		
		end
		
		local tdist = ( self:GetPos() - self.Target:GetPos() ):Length();
		
		local vis = self:CanSee( self.Target );
		
		if( vis ) then
			
			self.LastSeen = CurTime();
			
		end
		
		if( CurTime() - self.LastSeen < self.SearchTime ) then
			
			self:RunToEnemy( self.Target );
			
			if( CurTime() - self.RageSoundTime > 1 ) then
				
				self:DoCommonRageSound();
				self.RageSoundTime = CurTime();
				
			end
			
		elseif( CurTime() - self.LastSeen > self.SearchTime and CurTime() - self.LastSeen < self.SearchTime + 2 ) then
			
			self.Target = nil;
			self.Alerted = false;
			self.CanIdleWalk = true;
			self.LastSeen = -30;
			
			return;
			
		end
		
		if( tdist < 70 ) then
			
			if( vis ) then
				
				if( !self.AnimationRunning ) then
				
					self:PlayAnimation( "attack0" .. math.random( 1, 3 ) );
					self.Target:EmitSound( "necropolis/infected/common/miss/claw_miss_" .. math.random( 1, 2 ) .. ".wav" );
					self:AttackTarget();
					
				end
				
			end
		
		end
		
		if( CurTime() > self.NextEntityBlockCheck ) then
		
			local trace = { }
			trace.start = self:GetPos() + Vector( 0, 0, 32 );
			trace.endpos = trace.start + self:GetForward() * 70;
			trace.filter = self;
			
			local tr = util.TraceLine( trace );

			if( tr.Entity:IsValid() ) then
			
				if( tr.Entity:GetClass() == "func_breakable_surf" ) then
				
					self:StopMoving();
					self:PlayAnimation( "attack0" .. math.random( 1, 3 ) );
				
					timer.Simple( .5, function()
						
						if( tr.Entity:IsValid() ) then
							
							tr.Entity:EmitSound( "physics/glass/glass_sheet_break2.wav" );
							tr.Entity:Remove();
							
						end
						
					end );
				
				elseif( tr.Entity:GetClass() == "prop_door_rotating" ) then -- replaced IsDoor as brush ents don't have physics objects or models to create!
					
					self:StopMoving();
					self:PlayAnimation( "attack0" .. math.random( 1, 3 ) );
					
					tr.Entity:EmitSound( "physics/wood/wood_crate_impact_hard2.wav" );
					tr.Entity:EmitSound( "physics/wood/wood_panel_impact_hard1.wav", 100, math.random( 70, 130 ) );
					
					HandleDoorDamage( tr.Entity, self );
					
				elseif( tr.Entity:GetClass() == "prop_physics" ) then
				
					self:StopMoving();
					self:PlayAnimation( "attack0" .. math.random( 1, 3 ) );
					
					self:EmitSound( ZombieHit[math.random( 1, #ZombieHit )] );
					
					local norm = ( tr.Entity:GetPos() - self:GetPos() ):Normalize();
				
					tr.Entity:GetPhysicsObject():ApplyForceOffset( norm * 6000, tr.HitPos );
					
				end
				
			end
			
			self.NextEntityBlockCheck = CurTime() + .7;
			
		end
		
	
	end

end

function ENT:Think()
	
	if( self.Dead ) then return end
	
	self:HandleSound();
	
	if( CurTime() > self.NextThinkTime ) then
	
		self:ZombieThink();
		self.NextThinkTime = CurTime() + .3;
	
	end 

end
	

