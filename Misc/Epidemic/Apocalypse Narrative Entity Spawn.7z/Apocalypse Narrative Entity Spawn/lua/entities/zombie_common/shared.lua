ENT.Base = "base_ai";
ENT.Type = "ai";
  
ENT.AutomaticFrameAdvance = true;

ENT.PrintName = "Zombie"
ENT.Category		= "Revenant Role-Play NPCs"

ENT.Spawnable = true
ENT.AdminSpawnable = true