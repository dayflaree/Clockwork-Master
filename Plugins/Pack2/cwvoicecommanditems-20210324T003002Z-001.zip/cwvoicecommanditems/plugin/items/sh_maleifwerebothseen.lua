local ITEM = Clockwork.item:New();
ITEM.name = "If I talk to you out here we will both be in trouble";
ITEM.cost = 1;
ITEM.model = "models/props_lab/bindergraylabel01a.mdl";
ITEM.weight = 0;
ITEM.useText = "If I talk to you out here, we will both be in trouble.-VoiceCommand";
ITEM.useSound = "vo/trainyard/male01/cit_pedestrian03.wav", 80, 80;
ITEM.category = "Voice Commands";
ITEM.business = true;
ITEM.access = "V";
ITEM.batch = 1;
ITEM.description = "A re-useable voice command. Handed out to trusted roleplayers.";
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
    if (Schema:PlayerIsCombine(player)) then
        Clockwork.player:Notify(player, "You cannot open this ration!");
       
        return false;
    elseif (player:GetFaction() == FACTION_ADMIN) then
        Clockwork.player:Notify(player, "You cannot open this ration!");
       
        return false;
    else
        Clockwork.player:GiveCash(player, 0, "ration packet");
       
        player:GiveItem(Clockwork.item:CreateInstance("If I talk to you out here we will both be in trouble"), true);
       
        Clockwork.plugin:Call("PlayerUseRation", player);
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();