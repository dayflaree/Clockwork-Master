--[[
This plugin was initially created for Bitter Avalanche.

Use is public, but these credits must not be removed at any date or time.
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");