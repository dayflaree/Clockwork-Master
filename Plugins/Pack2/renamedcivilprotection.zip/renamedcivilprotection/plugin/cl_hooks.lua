local PLUGIN = PLUGIN;

-- Called when a player's scoreboard class is needed.
function PLUGIN:GetPlayerScoreboardClass(player)
	local customClass = player:GetSharedVar("customClass");
	local faction = player:GetFaction();
	
	if (customClass != "") then
		return customClass;
	end;
	
	if (faction == FACTION_MPF) then
		return "Combine Civil Authority";
	elseif (faction == FACTION_OTA) then
		return "Overwatch Transhuman Arm";
	end;
end;