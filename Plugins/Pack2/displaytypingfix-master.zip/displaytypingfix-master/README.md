## Display Typing - **Clockwork Fix**

This plugin fixes some issues with the 'displaytyping' plugin in version **[0.96.2-alpha]**,
such as sounds not playing when typing messages, incorrect messages appearing above player's
heads, e.g. "Performing..." not being shown when a player is attempting to use /me. (6/7/2017)

To install, put this into your 'clockwork/plugins/' directory and **remove the original version
with the name 'displaytyping'.**

You may want to remove this plugin in the future when an official fix is applied to the Framework. - Viz
