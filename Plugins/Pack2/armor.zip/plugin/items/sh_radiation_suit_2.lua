
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Hazmat Suit MK. 2";
ITEM.uniqueID = "hazmat_suit2";
ITEM.actualWeight = 6;
ITEM.invSpace = 8;
ITEM.radiationResistance = 3;
ITEM.maxArmor = 10;
ITEM.protection = 0.2;
ITEM.business = false;
ITEM.gasmask = true;
ITEM.replacement = "models/industrial_uniforms/industrial_uniform.mdl";
ITEM.description = "A high grade radiation suit. It is capable of keeping radiation and gas out.";

ITEM:Register();
