local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF SCAR DvL Uniform";
ITEM.uniqueID = "mpf_scarleader";
ITEM.actualWeight = 7;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 150;
ITEM.protection = 0.7;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/cppackredux/eliteconceptunits/c_cmd_orange.mdl";
ITEM.description = "A SCAR divisional Uniform.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);

