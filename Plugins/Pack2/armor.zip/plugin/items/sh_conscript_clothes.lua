local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Conscript Uniform";
ITEM.uniqueID = "conscript_clothing_1";
ITEM.actualWeight = 5;
ITEM.invSpace = 5;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 150;
ITEM.protection = 1;
ITEM.gasmask = true;
ITEM.cost = 2000;
ITEM.business = false;
ITEM.access = "A";
ITEM.replacement = "models/wichacks/ted.mdl";
ITEM.description = "A Conscript Uniform. Made for the soldiers that fight for the union.";

ITEM:Register();

