
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Heavy Rebel Uniform MK. II";
ITEM.uniqueID = "rebel_uniform_mk2";
ITEM.actualWeight = 15;
ITEM.invSpace = 6;
ITEM.radiationResistance = 0.6;
ITEM.maxArmor = 125;
ITEM.protection = 0.8;
ITEM.gasmask = true;
ITEM.cost = 200;
ITEM.business = false;
ITEM.access = "a";
ITEM.replacement = "models/tactical_rebel_coat.mdl";
ITEM.description = "A heavier version of the Resistance Uniform.";

ITEM:Register();