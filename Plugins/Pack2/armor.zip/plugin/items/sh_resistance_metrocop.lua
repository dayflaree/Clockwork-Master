
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Resistance Metropolice Uniform";
ITEM.uniqueID = "resistance_cop";
ITEM.actualWeight = 6;
ITEM.invSpace = 0;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 100;
ITEM.protection = 0.75;
ITEM.gasmask = true;
ITEM.cost = 0;
ITEM.business = false;
ITEM.access = "t";
ITEM.group = "group15";
ITEM.replacement = "models/dpfilms/metropolice/resistance_police.mdl";
ITEM.description = "A set of Metropolice Armor. It seems to be deactivated, and have lambda's on it.";

ITEM:Register();