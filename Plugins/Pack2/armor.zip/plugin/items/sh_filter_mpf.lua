
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "Metropolice Filter";
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.90;
ITEM.maxFilterQuality = 9000000;
ITEM.useText = "Screw On";
ITEM.description = "Filters Gas very well. The filter is in very good shape.";
ITEM.refillItem = "charcoal";

Clockwork.item:Register(ITEM);