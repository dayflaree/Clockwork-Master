local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF Judge Uniform";
ITEM.uniqueID = "mpf_judge";
ITEM.actualWeight = 6;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 100;
ITEM.protection = 0.8;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/dpfilms/metropolice/policetrench.mdl";
ITEM.description = "A JUDGE Uniform for Judge Units.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);