
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Heavy Rebel Uniform MK. I";
ITEM.uniqueID = "heavy_resistance_basic";
ITEM.actualWeight = 10;
ITEM.invSpace = 4;
ITEM.radiationResistance = 0.5;
ITEM.maxArmor = 75;
ITEM.protection = 0.8;
ITEM.gasmask = true;
ITEM.cost = 100;
ITEM.business = false;
ITEM.access = "A";
ITEM.replacement = "models/tactical_rebel.mdl";
ITEM.description = "A heavy rebel gasmask uniform.";


ITEM:Register();