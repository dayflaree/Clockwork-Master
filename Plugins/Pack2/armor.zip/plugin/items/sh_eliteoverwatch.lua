
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Super Heavy Elite Overwatch Kevlar Uniform";
ITEM.uniqueID = "elite_uniform_overwatch";
ITEM.actualWeight = 30;
ITEM.invSpace = 2;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 200;
ITEM.protection = 1;
ITEM.gasmask = true;
ITEM.cost = 5000;
ITEM.business = false;
ITEM.access = "t";
ITEM.replacement = "models/cppackredux/overwatch/combine_betaelite.mdl";
ITEM.description = "An extremely heavy and durable set of Elite Overwatch Armor.";

ITEM:Register();