
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Heavy Combined CDF Uniform";
ITEM.uniqueID = "heavy_cdf_uniform";
ITEM.actualWeight = 5;
ITEM.invSpace = 8;
ITEM.radiationResistance = 2;
ITEM.maxArmor = 150;
ITEM.protection = 0.80;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.replacement = "models/severance/ceda/ceda_operator1.mdl";
ITEM.description = "A heavy set of CDF armor. It comes with a Gasmask, Kevlar Helmet, and a Chest Rig.";

ITEM:Register();