
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "Charcoal Filter";
ITEM.uniqueID = "charcoal_filter";
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.3;
ITEM.maxFilterQuality = 30000;
ITEM.useText = "Screw On";
ITEM.description = "A shoddy version of a filter. Seems to be not that great.";
ITEM.refillItem = "charcoal";

Clockwork.item:Register(ITEM);