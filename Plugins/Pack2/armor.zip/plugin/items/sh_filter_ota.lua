
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "OTA Filter";
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 1.2;
ITEM.maxFilterQuality = 90000000;
ITEM.useText = "Screw On";
ITEM.description = "A heavy Overwatch Transhuman Arm Filter. It has excellent Quality.";
ITEM.refillItem = "charcoal";

Clockwork.item:Register(ITEM);