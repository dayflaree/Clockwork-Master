
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "Filter";
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.50;
ITEM.maxFilterQuality = 90000;
ITEM.useText = "Screw On";
ITEM.description = "Filters poisonous and radioactive gasses to a safe level.";
ITEM.refillItem = "charcoal";

Clockwork.item:Register(ITEM);