
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Overwatch Transhuman Arm Uniform";
ITEM.uniqueID = "overwatch_arm_suit";
ITEM.actualWeight = 25;
ITEM.invSpace = 5;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 150;
ITEM.protection = 1;
ITEM.gasmask = true;
ITEM.cost = 2000;
ITEM.business = false;
ITEM.access = "A";
ITEM.replacement = "models/Combine_Soldier.mdl";
ITEM.description = "A set of OTA armor given out to standard troops.";

ITEM:Register();