local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF JUDGE DvL Uniform";
ITEM.uniqueID = "mpf_judgeleader";
ITEM.actualWeight = 6;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 70;
ITEM.protection = 0.6;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/cppackredux/trenchcoatunits/trench_shockjock.mdl";
ITEM.description = "A JUDGE DvL uniform.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);
