
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Light CDF Uniform";
ITEM.uniqueID = "light_cdf_uniform";
ITEM.actualWeight = 4;
ITEM.invSpace = 8;
ITEM.radiationResistance = 2;
ITEM.maxArmor = 100;
ITEM.protection = 0.80;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.replacement = "models/severance/ceda/ceda_operator2.mdl";
ITEM.description = "A light set of CDF armor. It comes with a Gasmask, Kevlar Helmet, and a Chest Rig.";

function ITEM:GetReplacement(player) 
	if (player:GetGender() == GENDER_FEMALE) then
		return "models/kake/ceda_operator_female.mdl" 
	else 
		return "models/kake/ceda_operator_female.mdl"
	end;
end

ITEM:Register();



