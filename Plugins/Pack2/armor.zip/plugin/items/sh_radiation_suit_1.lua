
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Hazmat Suit MK. 1";
ITEM.uniqueID = "hazmat_suit1";
ITEM.actualWeight = 6;
ITEM.invSpace = 8;
ITEM.radiationResistance = 2;
ITEM.maxArmor = 0;
ITEM.protection = 0.05;
ITEM.business = false;
ITEM.gasmask = true;
ITEM.replacement = "models/industrial_uniforms/industrial_uniform.mdl";
ITEM.description = "A full set of radiation armor. It is capable of keeping out gas, but not radiation.";

ITEM:Register();


