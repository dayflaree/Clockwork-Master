
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "High Quality Filter";
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.60;
ITEM.maxFilterQuality = 180000;
ITEM.useText = "Screw On";
ITEM.description = "A high Quality Filter. Mainly given out to CWU or Workers that work in Factories.";
ITEM.refillItem = "charcoal";

Clockwork.item:Register(ITEM);