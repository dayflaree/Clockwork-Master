local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF Recruit Uniform";
ITEM.uniqueID = "mpf_rct";
ITEM.actualWeight = 5;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 50;
ITEM.protection = 0.4;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/cppackredux/groundunits/betaunit_sentinel.mdl";
ITEM.description = "A recruit uniform for the Metropolice.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);