local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF UNION Uniform";
ITEM.uniqueID = "mpf_union";
ITEM.actualWeight = 5;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 50;
ITEM.protection = 0.7;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/dpfilms/metropolice/urban_police.mdl";
ITEM.description = "A UNION Metropolice Uniform.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);