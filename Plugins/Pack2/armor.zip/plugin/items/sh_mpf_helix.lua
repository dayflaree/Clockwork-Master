local ITEM = Clockwork.item:New("armor_clothes_base");

ITEM.name = "MPF HELIX Uniform";
ITEM.uniqueID = "mpf_helix";
ITEM.actualWeight = 5;
ITEM.invSpace = 8;
ITEM.radiationResistance = 1;
ITEM.maxArmor = 60;
ITEM.protection = 0.5;
ITEM.gasmask = true;
ITEM.business = false;
ITEM.isPA = true;
ITEM.replacement = "models/dpfilms/metropolice/hl2beta_police.mdl";
ITEM.description = "An MPF HELIX Uniform.";
ITEM.repairItem = "cloth";

Clockwork.item:Register(ITEM);