
local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

Clockwork.flag:Add("A", "Heavy Clothes (Armor)", "Access to heavy clothes (armor) on the trader menu.");
Clockwork.flag:Add("S", "Light Clothes", "Access to light clothes on the trader menu.");