--[[
	� 2013 TheGarry =D
    Have fun with this plugin.
--]]

Clockwork.config:Add("apply_recognize_enable", true);