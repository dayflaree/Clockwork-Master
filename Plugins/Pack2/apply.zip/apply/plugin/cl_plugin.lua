--[[
	© 2013 TheGarry =D
    Have fun with this plugin.
--]]

PLUGIN = PLUGIN

Clockwork.config:AddToSystem("Enable Apply Recognize", "apply_recognize_enable", "Enables /Apply Recognize System.");