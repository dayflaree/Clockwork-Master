local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Adds the workshop file to the server's FastDL.
resource.AddWorkshop("128967611");