Clockwork.config:AddToSystem("Disable NPC Drops", "disable_npc_drops", "Disables all NPC drops when enabled.");
