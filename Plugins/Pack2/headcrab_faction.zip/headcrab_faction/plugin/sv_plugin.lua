local PLUGIN = PLUGIN

-- A function to check if a player is an Headcrab.
function PLUGIN:PlayerIsHeadcrab(player)
	if (IsValid(player) and player:GetCharacter()) then
		local faction = player:GetFaction();
		
		if (PLUGIN:IsHeadcrabFaction(faction)) then
			return true;
		else
			return false;
		end;
	end;
end;

--Called every second.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	--Slows down Zombie characters to make the animation look smoother.
	if (PLUGIN:PlayerIsZombie(player) and !player:GetNetworkedVar("GhostMode", true)) then
		if (!infoTable.isJogging) then
			infoTable.walkSpeed = 45
		end;
	--Fixes headcrabs not playing an animation when walking.
	if (PLUGIN:PlayerIsHeadcrab(player)) then
		if (player:KeyDown(IN_FORWARD) or player:KeyDown(IN_BACK) or player:KeyDown(IN_MOVELEFT)
		or player:KeyDown(IN_MOVERIGHT) and (!player:KeyDown(IN_SPEED) or !infoTable.isJogging)) then
			player:SetForcedAnimation("Run1", 0, nil)
		else
			player:SetForcedAnimation(false);
		end;
	end;
end;