--[[
	Plugin by confuseth
	   pathamos.com
--]]

local PLUGIN = PLUGIN;

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local skin = player:GetCharacterData("Skins") or player:GetSkin();
	local model = player:GetModel();
	player:SetSkin(tonumber(skin));
end;