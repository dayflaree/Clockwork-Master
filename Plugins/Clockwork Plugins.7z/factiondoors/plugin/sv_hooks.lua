local PLUGIN = PLUGIN
local Clockwork = Clockwork

-- Called when a player attempts to lock an entity.
function PLUGIN:PlayerCanLockEntity(player, entity)
	local doorName = Clockwork.entity:GetDoorName(entity);
	
	if(self.classdoor[doorName])then
		if(table.HasValue(self.classdoor[doorName], player:Team()))then
			return true;
		end;
	end;
end;

-- Called when a player attempts to unlock an entity.
function PLUGIN:PlayerCanUnlockEntity(player, entity)
	local doorName = Clockwork.entity:GetDoorName(entity);
	
	if(self.classdoor[doorName])then
		if(table.HasValue(self.classdoor[doorName], player:Team()))then
			return true;
		end;
	end;
end;