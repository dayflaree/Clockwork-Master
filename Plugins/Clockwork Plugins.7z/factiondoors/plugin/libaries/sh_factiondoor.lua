local Clockwork = Clockwork;

Clockwork.classdoor = Clockwork.kernel:NewLibrary("Faction Doors");
Clockwork.classdoor.stored = {};

function Clockwork.classdoor:Add(faction, doorname)

	self.stored[#self.stored + 1] = {
		faction = faction,
		doorname = doorname
	};

end;


Clockwork.classdoor:Add(CLASS_CITIZEN,"The old yellow pub")