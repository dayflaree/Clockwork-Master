local PLUGIN = PLUGIN;
	
-- A function to load the ration machines.
function PLUGIN:LoadCheckovMachines()
	local CheckovMachines = Clockwork.kernel:RestoreSchemaData("plugins/CheckovMachines/"..game.GetMap());
	
	for k, v in pairs(CheckovMachines) do
		local entity = ents.Create("checkov_machine");
		entity:SetPos(v.pos);
		entity:SetMaterial(v.material)
		entity:SetAngles(v.angles);
		entity:Spawn();
		entity:Activate();
		entity:SetDTBool(0, v.active);
		--entity:SetSharedVar("stocks", v.stocks);
		entity:SetDTFloat(1, v.stock1);
		entity:SetDTFloat(2, v.stock2);
		entity:SetDTFloat(3, v.stock3);
		entity:SetDTFloat(4, v.stock4)
	end;
end;

-- A function to save the ration machines.
function PLUGIN:SaveCheckovMachines()
	local CheckovMachines = {};
	
	for k, v in pairs(ents.FindByClass("checkov_machine")) do
		CheckovMachines[#CheckovMachines + 1] = {
			pos = v:GetPos(),
			angles = v:GetAngles(),
			material = v:GetMaterial(),
			active = v:GetDTBool(0),
			stock1 = v:GetDTFloat(1);
			stock2 = v:GetDTFloat(2);
			stock3 = v:GetDTFloat(3);
			stock4 = v:GetDTFloat(4);
		}
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/CheckovMachines/"..game.GetMap(), CheckovMachines);
end;