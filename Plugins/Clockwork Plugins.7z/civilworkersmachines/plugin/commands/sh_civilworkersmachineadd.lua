--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("WorkersMachineAdd");
COMMAND.tip = "Add a Civil Workers' dispensory machine at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	--local entity = ents.Create("nut_vend");
	local entity = scripted_ents.Get("checkov_machine"):SpawnFunction(player, trace)
	
	--entity:SetPos(trace.HitPos + Vector(0, 0, 48));
	--entity:SpawnFunction(player, trace);
	
	if ( IsValid(entity) ) then
		--entity:SetStock(math.random(10, 20), true);
		--entity:SetAngles(Angle(0, player:EyeAngles().yaw + 180, 0));
		
		Clockwork.player:Notify(player, "You have added a Civil Workers' dispensory machine.");
	end;
end;

COMMAND:Register();