local COMMAND = Clockwork.command:New("Announcement");
COMMAND.tip = "For staff members to announce messages.";
COMMAND.text = "<Text>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has be run
function COMMAND:OnRun(player, arguments)
	local text = table.concat( arguments, " ");
	
	if (text == "") then
		Clockwork.player:Notify(player, "You did not specify enough text!");
		else
			Clockwork.chatBox:SendColored(players, Color(255, 140, 0), "[ADMINISTRATION] ", Color(255, 255, 255), text)
	end;
end;
			
COMMAND:Register();