--[[
	Made by rusty!!!!
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called each frame while the player is connected.
function PLUGIN:Think()
	local curTime = CurTime();

	if (Clockwork.Client:Alive()) then -- Is the player alive?
		if (!Clockwork.Client._nextSong or Clockwork.Client._nextSong < curTime) then
			Clockwork.Client._nextSong = curTime + math.random(600, 900); -- Schedule the next sound play. A random time between 10 and 15 minutes.
			
			local ambienceTracks = {
				"music/hl2_song0.mp3",
				"music/hl1_song20.mp3",
				"music/hl1_song21.mp3",
				"music/hl1_song26.mp3",
				"music/hl1_song3.mp3",
				"music/hl1_song6.mp3",
				"music/hl2_song13.mp3",
				"music/hl2_song17.mp3",
				"music/hl2_song2.mp3",
				"music/hl2_song26.mp3",
				"music/hl2_song33.mp3",
				"music/hl2_song8.mp3"
			};
			
			songAtmosphere = CreateSound(Clockwork.Client, Sound(table.Random(ambienceTracks))); -- Global variable because csoundpatch doesn't work with local variables.
			songAtmosphere:PlayEx(0.75, 100);
		end;
	end;	
end;