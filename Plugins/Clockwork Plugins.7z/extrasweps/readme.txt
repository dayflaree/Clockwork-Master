THE EXTRASWEPS PLUGIN REQUIRES THESE ADDONS TO BE DOWNLOADED ONTO YOUR SERVER:

http://steamcommunity.com/sharedfiles/filedetails/?id=455435228
http://steamcommunity.com/sharedfiles/filedetails/?id=202590506