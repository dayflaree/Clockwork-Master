local PLUGIN = PLUGIN;

-- Called to get whether a player's weapon is raised.
function PLUGIN:GetPlayerWeaponRaised(player, class, weapon)
	if (class == "cw_ration") then
		return true
	end;
end;