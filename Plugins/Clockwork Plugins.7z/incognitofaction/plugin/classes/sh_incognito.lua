local CLASS = Clockwork.class:New("Incognito");
	CLASS.color = Color(150, 125, 100, 255);
	CLASS.factions = {FACTION_INCOG};
	CLASS.isDefault = true;
	CLASS.wagesName = "Funds";
	CLASS.description = "Sneaky Sneaky People";
	CLASS.defaultPhysDesc = "Looks normal.";
CLASS_INCOG = CLASS:Register();