local PLUGIN = PLUGIN;
local cflag = cflag;
local vflag = vflag;

local startSounds = {
	"npc/metropolice/vo/on1.wav",
	"npc/metropolice/vo/on2.wav",
	"npc/overwatch/radiovoice/on3.wav",
	"npc/overwatch/radiovoice/on1.wav"
};

local endSounds = {
	"npc/metropolice/vo/off1.wav",
	"npc/metropolice/vo/off2.wav",
	"npc/metropolice/vo/off3.wav",
	"npc/metropolice/vo/off4.wav",
	"npc/overwatch/radiovoice/off4.wav",
	"npc/overwatch/radiovoice/off2.wav"
};

-- local startSoundsOTA = {
-- 	"npc/combine_soldier/vo/on1.wav",
-- 	"npc/combine_soldier/vo/on2.wav"
-- };
--
-- local endSoundsOTA = {
-- 	"npc/combine_soldier/vo/off1.wav",
-- 	"npc/combine_soldier/vo/off2.wav",
-- 	"npc/combine_soldier/vo/off3.wav"
-- };

cwPly = Clockwork.player;

-- Called when a player's typing display has started.
function PLUGIN:PlayerStartTypingDisplay(player, code)
	if (player:GetFaction() == FACTION_MPF and !player:IsNoClipping() or cwPly:HasFlags(player, "J") and !player:IsNoClipping()) then
		if (code == "n" or code == "y" or code == "w" or code == "r") then
			print(player.typingBeep);
			if (!player.typingBeep) then
				player.typingBeep = true;
				player:EmitSound(startSounds[math.random( #startSounds )]);
			end;
			if(player.typingBeep) then
				player:EmitSound(startSounds[math.random( #startSounds )]);
			end;
		end;
	elseif (player:GetFaction() == FACTION_OTA and !player:IsNoClipping()) then
		if (code == "n" or code == "y" or code == "w" or code == "r") then
			if (!player.typingBeep) then
				player.typingBeep = true;

				player:EmitSound("common/on"..math.random(1, 6)..".mp3");
			end;
		end;
		if(player.typingBeep) then
			player:EmitSound("common/on"..math.random(1, 6)..".mp3");
		end;
	end;
end;

-- Called when a player's typing display has finished.
function PLUGIN:PlayerFinishTypingDisplay(player, textTyped)
	if (player:GetFaction() == FACTION_MPF and textTyped and !player:IsNoClipping() or cwPly:HasFlags(player, "J") and textTyped and !player:IsNoClipping()) then
		if (player.typingBeep or player.typingBeep == nil) then
			player:EmitSound(endSounds[math.random( #endSounds )]);
		end;
	elseif (player:GetFaction() == FACTION_OTA and !player:IsNoClipping()) then
		if (player.typingBeep or player.typingBeep == nil) then
			player:EmitSound("common/off"..math.random(1, 9)..".mp3");
		end;
	end;

	player.typingBeep = nil;
end;

-- -- Called when chat box info should be adjusted.
-- function PLUGIN:ChatBoxAdjustInfo(info)
-- 	if (info.class != "ooc" and info.class != "looc") then
-- 		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
-- 			if (string.sub(info.text, 1, 1) == "?") then
-- 				info.text = string.sub(info.text, 2);
-- 				info.data.anon = true;
-- 			end;
-- 		end;
-- 	end;
--
-- 	if (info.class == "ic" or info.class == "yell" or info.class == "radio" or info.class == "whisper" or info.class == "request") then
-- 		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
-- 			local playerIsCombine = Schema:PlayerIsCombine(info.speaker);
--
-- 			if (playerIsCombine and Schema:IsPlayerCombineRank(info.speaker, "SCN")) then
-- 				for k, v in pairs(Schema.voices.stored.dispatchVoices) do
-- 					if (string.lower(info.text) == string.lower(v.command)) then
-- 						local voice = {
-- 							global = false,
-- 							volume = 90,
-- 							sound = v.sound
-- 						};
--
-- 						if (info.class == "request" or info.class == "radio") then
-- 							voice.global = true;
-- 						elseif (info.class == "whisper") then
-- 							voice.volume = 80;
-- 						elseif (info.class == "yell") then
-- 							voice.volume = 100;
-- 						end;
--
-- 						info.text = "<:: "..v.phrase;
-- 						info.voice = voice;
--
-- 						return true;
-- 					end;
-- 				end;
-- 			else
-- 				for k, v in pairs(Schema.voices.stored.normalVoices) do
-- 					if ((Clockwork.player:HasFlags(info.speaker, vflag)) or (v.faction == "Human" and !playerIsCombine)) then
-- 						if (string.lower(info.text) == string.lower(v.command)) then
-- 							local voice = {
-- 								global = false,
-- 								volume = 80,
-- 								sound = v.sound
-- 							};
--
-- 							if (v.female and info.speaker:QueryCharacter("gender") == GENDER_FEMALE) then
-- 								voice.sound = string.Replace(voice.sound, "/male", "/female");
-- 							end;
--
-- 							if (info.class == "request" or info.class == "radio") then
-- 								voice.global = true;
-- 							elseif (info.class == "whisper") then
-- 								voice.volume = 60;
-- 							elseif (info.class == "yell") then
-- 								voice.volume = 100;
-- 							end;
--
-- 							if (Clockwork.player:HasFlags(info.speaker, cflag)) then
-- 								info.text = "<:: "..v.phrase;
-- 							else
-- 								info.text = v.phrase;
-- 							end;
--
-- 							info.voice = voice;
--
-- 							return true;
-- 						end;
-- 					end;
-- 				end;
-- 			end;
--
-- 			if (Clockwork.player:HasFlags(info.speaker, cflag)) then
-- 				if (string.sub(info.text, 1, 4) != "<:: ") then
-- 					info.text = "<:: "..info.text;
-- 				end;
-- 			end;
-- 		end;
-- 	end;
-- end;
--
-- -- Called when a player's pain sound should be played.
-- function PLUGIN:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
-- 	if (Clockwork.player:HasFlags(player, cflag) ) then
-- 		return "npc/metropolice/pain"..math.random(1, 4)..".wav";
-- 	end;
-- end;
--
-- -- Called when a player's death sound should be played.
-- function PLUGIN:PlayerPlayDeathSound(player, gender)
-- 	if (Clockwork.player:HasFlags(player, cflag) ) then
-- 		local sound = "npc/metropolice/die"..math.random(1, 4)..".wav";
--
-- 		for k, v in ipairs( _player.GetAll() ) do
-- 			if (v:HasInitialized()) then
-- 				if (Clockwork.player:HasFlags(v, cflag)) then
-- 					v:EmitSound(sound);
-- 				end;
-- 			end;
-- 		end;
--
-- 		return sound;
-- 	end;
-- end;
--
--
-- -- Called when a player's footstep sound should be played.
-- function PLUGIN:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
-- 	local running = nil;
-- 	local clothes = player:GetCharacterData("clothes");
-- 	local model = string.lower( player:GetModel() );
--
-- 	if (clothes) then
-- 		local itemTable = Clockwork.item:FindByID(clothes);
--
-- 		if (itemTable) then
-- 			if (player:IsRunning() or player:IsJogging()) then
-- 				if (itemTable.runSound) then
-- 					if (type(itemTable.runSound) == "table") then
-- 						sound = itemTable.runSound[ math.random(1, #itemTable.runSound) ];
-- 					else
-- 						sound = itemTable.runSound;
-- 					end;
-- 				end;
-- 			elseif (itemTable.walkSound) then
-- 				if (type(itemTable.walkSound) == "table") then
-- 					sound = itemTable.walkSound[ math.random(1, #itemTable.walkSound) ];
-- 				else
-- 					sound = itemTable.walkSound;
-- 				end;
-- 			end;
-- 		end;
-- 	end;
--
-- 	if (player:IsRunning() or player:IsJogging()) then
-- 		running = true;
-- 	end;
--
-- 	if (running) then
-- 		if (Clockwork.player:HasFlags(player, cflag) and !string.find(model, "combine") and !string.find(model, "city8_ow") and !string.find(model, "city8_overwatch") or string.find(model, "metropolice") or string.find(model, "police")) then
-- 			if (foot == 0) then
-- 				local randomSounds = {1, 3, 5};
-- 				local randomNumber = math.random(1, 3);
--
-- 				sound = "npc/metropolice/gear"..randomSounds[randomNumber]..".wav";
-- 			else
-- 				local randomSounds = {2, 4, 6};
-- 				local randomNumber = math.random(1, 3);
--
-- 				sound = "npc/metropolice/gear"..randomSounds[randomNumber]..".wav";
-- 			end;
-- 		elseif (string.find(model, "combine") or string.find(model, "city8_ow") or string.find(model, "city8_overwatch")) then
-- 			if (foot == 0) then
-- 				local randomSounds = {1, 3, 5};
-- 				local randomNumber = math.random(1, 3);
--
-- 				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
-- 			else
-- 				local randomSounds = {2, 4, 6};
-- 				local randomNumber = math.random(1, 3);
--
-- 				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
-- 			end;
-- 		end;
-- 	end;
--
-- 	player:EmitSound(sound);
--
-- 	return true;
-- end;
