local PLUGIN = PLUGIN;
local Clockwork = Clockwork;
local cflag = cflag;
-- Called when screen space effects should be rendered.
function PLUGIN:RenderScreenspaceEffects()
		if (Clockwork.player:HasFlags(Clockwork.Client, cflag )) then
			render.UpdateScreenEffectTexture();

			Schema.combineOverlay:SetFloat("$refractamount", 0.3);
			Schema.combineOverlay:SetFloat("$envmaptint", 0);
			Schema.combineOverlay:SetFloat("$envmap", 0);
			Schema.combineOverlay:SetFloat("$alpha", 0.5);
			Schema.combineOverlay:SetInt("$ignorez", 1);

			render.SetMaterial(Schema.combineOverlay);
			render.DrawScreenQuad();
		end;
	end;

	-- Called each tick.
	function PLUGIN:Tick()
		if (IsValid(Clockwork.Client)) then
			if (Clockwork.player:HasFlags(Clockwork.Client, cflag)) then
				local curTime = CurTime();
				local health = Clockwork.Client:Health();
				local armor = Clockwork.Client:Armor();

				if (!Schema.nextHealthWarning or curTime >= Schema.nextHealthWarning) then
					if (Schema.lastHealth) then
						if (health < Schema.lastHealth) then
							if (health == 0) then
								PLUGIN:AddNonCombineDisplayLine( "ERROR! Shutting down...", Color(255, 0, 0, 255) );
							else
								PLUGIN:AddNonCombineDisplayLine( "WARNING! Physical bodily trauma detected...", Color(255, 0, 0, 255) );
							end;

							Schema.nextHealthWarning = curTime + 2;
						elseif (health > Schema.lastHealth) then
							if (health == 100) then
								PLUGIN:AddNonCombineDisplayLine( "Physical body systems restored...", Color(0, 255, 0, 255) );
							else
								PLUGIN:AddNonCombineDisplayLine( "Physical body systems regenerating...", Color(0, 0, 255, 255) );
							end;

							Schema.nextHealthWarning = curTime + 2;
						end;
					end;

					if (Schema.lastArmor) then
						if (armor < Schema.lastArmor) then
							if (armor == 0) then
								PLUGIN:AddNonCombineDisplayLine( "WARNING! External protection exhausted...", Color(255, 0, 0, 255) );
							else
								PLUGIN:AddNonCombineDisplayLine( "WARNING! External protection damaged...", Color(255, 0, 0, 255) );
							end;

							Schema.nextHealthWarning = curTime + 2;
						elseif (armor > Schema.lastArmor) then
							if (armor == 100) then
								PLUGIN:AddNonCombineDisplayLine( "External protection systems restored...", Color(0, 255, 0, 255) );
							else
								PLUGIN:AddNonCombineDisplayLine( "External protection systems regenerating...", Color(0, 0, 255, 255) );
							end;

							Schema.nextHealthWarning = curTime + 2;
						end;
					end;
				end;

				if (!Schema.nextRandomLine or curTime >= Schema.nextRandomLine) then
					local text = PLUGIN.randomNonCombineDisplayLines[ math.random(1, #PLUGIN.randomNonCombineDisplayLines) ];

					if (text and PLUGIN.lastRandomNonCombineDisplayLine != text) then
						PLUGIN:AddNonCombineDisplayLine(text);

						Schema.lastRandomNonCombineDisplayLine = text;
					end;

					Schema.nextRandomLine = curTime + 3;
				end;

				Schema.lastHealth = health;
				Schema.lastArmor = armor;
			end;
		end;
	end;

-- Called when the top screen HUD should be painted.
function PLUGIN:HUDPaintTopScreen(info)
	local blackFadeAlpha = Clockwork.kernel:GetBlackFadeAlpha();
	local colorWhite = Clockwork.option:GetColor("white");
	local curTime = CurTime();

	if (Clockwork.player:HasFlags(Clockwork.Client, cflag)  and self.combineDisplayLines) then
		local height = draw.GetFontHeight("BudgetLabel");

		for k, v in ipairs(self.combineDisplayLines) do
			if (curTime >= v[2]) then
				table.remove(self.combineDisplayLines, k);
			else
				local color = v[4] or colorWhite;
				local textColor = Color(color.r, color.g, color.b, 255 - blackFadeAlpha);

				draw.SimpleText(string.sub( v[1], 1, v[3] ), "BudgetLabel", info.x, info.y, textColor);

				if (v[3] < string.len( v[1] )) then
					v[3] = v[3] + 1;
				end;

				info.y = info.y + height;
			end;
		end;
	end;
end;
