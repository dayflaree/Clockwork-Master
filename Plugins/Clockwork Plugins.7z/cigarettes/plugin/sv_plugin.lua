local PLUGIN = PLUGIN;

resource.AddWorkshop("793269226")