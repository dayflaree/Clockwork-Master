local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Destroyed gardengnome";
	ITEM.worth = 3;
	ITEM.model = "models/clutter/gardengnomedestroyed.mdl";
	ITEM.weight = 1.7
	ITEM.description = "Poor gnome maybe some raiders found him?";
ITEM:Register();