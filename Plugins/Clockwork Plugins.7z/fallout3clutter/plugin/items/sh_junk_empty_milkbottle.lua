local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Empty Milkbottle";
	ITEM.worth = 2;
	ITEM.model = "models/clutter/milkbottle01.mdl";
	ITEM.weight = 0.5
	ITEM.description = "An empty milkbottle maybe its better not sure if you want to taste old milk";
ITEM:Register();