local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Ashtray";
	ITEM.worth = 2;
	ITEM.model = "models/clutter/ashtray.mdl";
	ITEM.weight = 0.1
	ITEM.description = "A old ashtray you still can smell its unpleasend ash";
ITEM:Register();