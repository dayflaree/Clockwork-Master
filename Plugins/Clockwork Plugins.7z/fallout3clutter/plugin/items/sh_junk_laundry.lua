local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Laundry detergent";
	ITEM.worth = 7;
	ITEM.model = "models/clutter/laundrydetergent01.mdl";
	ITEM.weight = 0.7
	ITEM.description = "Laundry detergent! Now your clothes finally can get cleaned!";
ITEM:Register();