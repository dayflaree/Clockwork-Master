local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Cigarette carton";
	ITEM.worth = 8;
	ITEM.model = "models/clutter/cigarettecarton.mdl";
	ITEM.weight = 0.5
	ITEM.description = "Filled with cigarettes! Someone might be interested in buying these";
ITEM:Register();