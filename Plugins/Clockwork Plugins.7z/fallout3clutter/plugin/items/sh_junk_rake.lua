local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Rake";
	ITEM.worth = 7;
	ITEM.model = "models/clutter/rake.mdl";
	ITEM.weight = 1.3
	ITEM.description = "A garden rake to finally beat those nasty stuff on your lawn";
ITEM:Register();