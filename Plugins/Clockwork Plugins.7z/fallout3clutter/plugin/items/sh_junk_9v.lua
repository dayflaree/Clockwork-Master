local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "9 Volt Battery";
	ITEM.worth = 1;
	ITEM.model = "models/clutter/9voltbattery.mdl";
	ITEM.weight = 0.2
	ITEM.description = "A empty 9 Volt battery maybe its not all empty and you can sell it to someone?";
ITEM:Register();