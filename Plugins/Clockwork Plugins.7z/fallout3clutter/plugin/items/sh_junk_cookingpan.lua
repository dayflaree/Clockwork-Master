local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Cookingpan";
	ITEM.worth = 6;
	ITEM.model = "models/clutter/cookingpan.mdl";
	ITEM.weight = 0.7
	ITEM.description = "Time to make some food with these. Or sell it?";
ITEM:Register();