local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Book";
	ITEM.worth = 3;
	ITEM.model = "models/clutter/book.mdl";
	ITEM.weight = 0.3
	ITEM.description = "A old book looks like it even existed before war";
ITEM:Register();