local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Plunger";
	ITEM.worth = 4;
	ITEM.model = "models/clutter/plunger.mdl";
	ITEM.weight = 0.7
	ITEM.description = "Best friend for your own toilet";
ITEM:Register();