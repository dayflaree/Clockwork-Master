local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Big Pot";
	ITEM.worth = 3;
	ITEM.model = "models/clutter/bigpot.mdl";
	ITEM.weight = 2
	ITEM.description = "A big cooking pot without any holes";
ITEM:Register();