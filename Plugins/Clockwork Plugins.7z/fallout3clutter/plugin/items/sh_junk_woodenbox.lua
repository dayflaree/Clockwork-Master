local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Woodenbox";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/milkcarton01.mdl";
	ITEM.weight = 1.5
	ITEM.description = "An dusty old woodenbox probably pretty usefull";
ITEM:Register();