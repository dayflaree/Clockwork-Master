local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Camera";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/camara.mdl";
	ITEM.weight = 0.5
	ITEM.description = "Its a old camera but seems broken to you";
ITEM:Register();