local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Pre-war Money";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/prewarmoney.mdl";
	ITEM.weight = 0.1
	ITEM.description = "Currency used before the war maybe still worth some money1";
ITEM:Register();