local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Teddybear";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/teddybear.mdl";
	ITEM.weight = 0.7
	ITEM.description = "A teddybear for the smaller wastelanders";
ITEM:Register();