local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Hammer";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/hammer.mdl";
	ITEM.weight = 0.3
	ITEM.description = "A pretty solid hammer i bet it sells good";
ITEM:Register();