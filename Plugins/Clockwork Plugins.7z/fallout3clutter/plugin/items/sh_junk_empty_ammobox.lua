local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Empty Ammobox";
	ITEM.worth = 22;
	ITEM.plural = "Empty Ammoboxes";
	ITEM.model = "models/clutter/ammobox.mdl";
	ITEM.weight = 2;
	ITEM.description = "A ammobox! sadly you notice its empty... but you could still sell it";
ITEM:Register();