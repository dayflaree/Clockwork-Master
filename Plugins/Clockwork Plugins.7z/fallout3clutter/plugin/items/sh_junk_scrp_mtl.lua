local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Scrap Metal";
	ITEM.worth = 7;
	ITEM.model = "models/clutter/scrapmetal.mdl";
	ITEM.weight = 0.5
	ITEM.description = "Scrap metal basicly everyone wants this";
ITEM:Register();