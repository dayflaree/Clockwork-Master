local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Broom";
	ITEM.worth = 4;
	ITEM.model = "models/clutter/broom.mdl";
	ITEM.weight = 1
	ITEM.description = "A old dusty broom maybe still able to clean";
ITEM:Register();