local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Conductor";
	ITEM.worth = 10;
	ITEM.model = "models/clutter/conductor.mdl";
	ITEM.weight = 1
	ITEM.description = "An old conductor maybe it still delivers power?";
ITEM:Register();