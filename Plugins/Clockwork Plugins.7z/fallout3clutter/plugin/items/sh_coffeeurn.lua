local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Coffeeurn";
	ITEM.worth = 9;
	ITEM.model = "models/clutter/coffeeurn.mdl";
	ITEM.weight = 2
	ITEM.description = "Only ancient people might know what this is";
ITEM:Register();