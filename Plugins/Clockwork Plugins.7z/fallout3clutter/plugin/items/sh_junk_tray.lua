local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Tray";
	ITEM.worth = 2;
	ITEM.model = "models/clutter/tray.mdl";
	ITEM.weight = 0.2
	ITEM.description = "A food tray probably a bad idea to eat from it";
ITEM:Register();