local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Microscope";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/microscope.mdl";
	ITEM.weight = 2
	ITEM.description = "A microscope lets see what those wasteland has to offer on bacterias";
ITEM:Register();