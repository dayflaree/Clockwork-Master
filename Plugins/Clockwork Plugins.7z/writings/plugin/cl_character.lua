function PANEL:SetModel(model)
	if model == "models/zombie/classic.mdl" then
		model:SetBodygroup(1, 1)
	end;
end;