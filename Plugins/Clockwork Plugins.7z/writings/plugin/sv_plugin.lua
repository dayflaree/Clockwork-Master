--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

-- Called when a character loads
function PLUGIN:PlayerCharacterLoaded(player)
	local ply = player;
	local faction = ply:GetFaction();
	local char = ply:GetCharacter();
	
	timer.Simple(0.001, function() -- Small delay so the model can be determined correctly
		if (faction == "Necrotic") then
		print(char.name)
			if (!string.find(char.name, "Necrotic"))  then
				Clockwork.player:SetName(ply, "Necrotic: "..char.name)
			end
			
			if ply:GetModel() == "models/zombie/classic.mdl" then
				ply:SetBodygroup(1, 1)
			end
		end
	end)
end

function PLUGIN:PlayerThink(player, curTime, infoTable)
	--Fixes headcrabs not playing an animation when walking.
	if (player:GetModel() == "models/headcrabclassic.mdl") then
		if (player:KeyDown(IN_FORWARD) or player:KeyDown(IN_BACK) or player:KeyDown(IN_MOVELEFT)
		or player:KeyDown(IN_MOVERIGHT)) then
			player:SetForcedAnimation("Run1", 0, nil)
		else
			player:SetForcedAnimation(false);
		end;
	end;
end;

-- Called when a character unloads
function PLUGIN:PlayerCharacterUnloaded(player)
	local ply = player
	ply:SetBodygroup(1, 0)
end