
-----------------------------------------------------
local PLUGIN = PLUGIN;

Clockwork.flag:Add("d", "Droidspeak", "Allows a character to speak and understand Droidspeak with /droi.");
Clockwork.flag:Add("E", "Ewokese", "Allows a character to speak and understand Ewokese with /ewo.");
Clockwork.flag:Add("R", "Rodian", "Allows a character to speak and understand Rodian with /rod.");
Clockwork.flag:Add("H", "Huttese", "Allows a character to speak and understand Huttese with /hut.");
Clockwork.flag:Add("J", "Jawaese", "Allows a character to speak and understand Jawaese with /jaw.");
Clockwork.flag:Add("M", "Mando'a", "Allows a character to speak and understand Mando'a with /man.");
Clockwork.flag:Add("S", "Sith", "Allows a character to speak and understand the Sith tongue with /sit.");
Clockwork.flag:Add("Y", "Shyriiwook", "Allows a character to speak and understand Shyriiwook with /shy.");
Clockwork.flag:Add("T", "Tuskenese", "Allows a character to speak and understand Tuskenese with /tus.");