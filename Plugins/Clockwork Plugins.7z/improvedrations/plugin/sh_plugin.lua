local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

--[[if (SERVER) then
	Clockwork.config:Add("cwu_ration_time", 10);
	Clockwork.config:Add("citizen_ration_time", 30);
else
	Clockwork.config:AddToSystem("CWU Ration Timer", "cwu_ration_time", "The time it takes for a CWU to get a ration. (In seconds)", 10);
	Clockwork.config:AddToSystem("Citizen Ration Timer", "citizen_ration_time", "The time it takes for a citizen to get a ration. (In seconds)", 30);
end;--]]
