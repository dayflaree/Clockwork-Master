--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("scoreboardhide");
COMMAND.tip = "Hide a player from the scoreboard.";
COMMAND.text = "<string Name>";
COMMAND.flags = S
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] )
	if (target) then
			target:SetNWBool( "hidden", true )
			target:SetCharacterData("scoreboardhide", true)
			Clockwork.player:Notify(player, "They are now hidden");
			Clockwork.player:Notify(target, "You are now hidden in the scoreboard.");
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

COMMAND:Register();