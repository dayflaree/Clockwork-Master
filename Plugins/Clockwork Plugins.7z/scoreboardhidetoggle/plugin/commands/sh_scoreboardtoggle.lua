local COMMAND = Clockwork.command:New("ScoreboardToggle");
COMMAND.tip = "Hide or show a player on the scoreboard.";
COMMAND.text = "<string Name> <bool ShouldShow>";
COMMAND.flags = "s";
COMMAND.arguments = 2;
 
-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
        local target = Clockwork.player:FindByID(arguments[1]);
        local shouldShow = tobool(arguments[2]);
 
        if (target) then
                if (!shouldShow) then
                        target:SetNWBool("hidden", true);
                        target:SetCharacterData("scoreboardhide", true);
                        player:Notify(target:Name().." is now hidden.");
                        target:Notify("You are now hidden in the scoreboard.");
                else
                        target:SetNWBool("hidden", false);
                        target:SetCharacterData("scoreboardhide", false);
                        player:Notify(target:Name().." is now visible.");
                        target:Notify("You are now visible in the scoreboard.");
                end;
        else
                player:Notify(arguments[1].." is not a valid character!");
        end;
end;
 
COMMAND:Register();