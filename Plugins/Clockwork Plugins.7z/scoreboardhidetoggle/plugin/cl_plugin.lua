local PLUGIN = PLUGIN
local Clockwork= Clockwork

function PLUGIN:PlayerShouldShowOnScoreboard(player)
	local status = player:GetNWBool("hidden")
   if(status) then
       return false;
   end;
end;