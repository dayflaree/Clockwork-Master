local Clockwork = Clockwork
local PLUGIN = PLUGIN

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
        player:SetNWBool( "hidden", player:GetCharacterData("scoreboardhide") or false);
end;
 
function PLUGIN:PlayerCharacterLoaded(player)
        player:SetNWBool( "hidden", player:GetCharacterData("scoreboardhide") or false);
end;