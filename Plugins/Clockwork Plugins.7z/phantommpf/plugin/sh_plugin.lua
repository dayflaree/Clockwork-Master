local PLUGIN = PLUGIN;
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
--Do not change the above--
UndercoverModel = "models/Humans/Group01/male_02.mdl";
PHANTOMModel = "models/dpfilms/metropolice/rogue_police.mdl";