function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:String("icon");
	playerVars:String("permaKilled");
end;
