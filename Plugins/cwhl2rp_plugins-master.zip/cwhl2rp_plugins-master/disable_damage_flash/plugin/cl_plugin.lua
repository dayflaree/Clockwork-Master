Clockwork.config:AddToSystem("Disable Damage Flash", "disable_damage_flash", "Disables the white flash shown upon receiving damage.");
