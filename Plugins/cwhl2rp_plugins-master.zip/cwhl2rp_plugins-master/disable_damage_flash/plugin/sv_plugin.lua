Clockwork.config:Add("disable_damage_flash", true);
