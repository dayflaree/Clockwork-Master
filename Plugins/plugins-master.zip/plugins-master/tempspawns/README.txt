Commands are all in there and straightforward.

Only setup that has to be done is add a FACTION.useTempSpawns to all factions you want to use tempSpawns.