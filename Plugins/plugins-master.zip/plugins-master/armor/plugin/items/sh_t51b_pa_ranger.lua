local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Ranger T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_ranger";
ITEM.replacement = "models/t51b/t51i.mdl";
ITEM.description = "A fully functioning suit of desert T-51b Power Armor with a Ranger insignia.";

Clockwork.item:Register(ITEM);