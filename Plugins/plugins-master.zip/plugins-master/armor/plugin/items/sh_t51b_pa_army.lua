local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "U.S. Army T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_army";
ITEM.replacement = "models/t51b/t51e.mdl";
ITEM.description = "A fully functioning suit of U.S. Army T-51b Power Armor.";

Clockwork.item:Register(ITEM);