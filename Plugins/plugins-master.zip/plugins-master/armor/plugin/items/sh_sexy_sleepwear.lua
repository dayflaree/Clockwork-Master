
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Sexy Sleepwear";
ITEM.uniqueID = "sexy_sleepwear";
ITEM.actualWeight = 0.5;
ITEM.invSpace = 0;
ITEM.radiationResistance = 0;
ITEM.maxArmor = 0;
ITEM.protection = 0.00;
ITEM.cost = 0;
ITEM.business = true;
ITEM.access = "t";
ITEM.group = "group15";
ITEM.description = "A set of sexually-appealing clothing for women.";

ITEM:Register();