local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Red T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_red";
ITEM.replacement = "models/t51b/t51f.mdl";
ITEM.description = "A fully functioning suit of black T-51b Power Armor with red markings.";

Clockwork.item:Register(ITEM);