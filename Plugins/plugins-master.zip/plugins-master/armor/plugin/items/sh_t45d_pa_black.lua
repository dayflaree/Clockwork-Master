local ITEM = Clockwork.item:New("t45_pa");
ITEM.name = "Black T-45d Power Armor";
ITEM.uniqueID = "t45d_pa_black";
ITEM.replacement = "models/power_armor/t45j.mdl";
ITEM.description = "A fully functioning suit of black T-45d Power Armor.";

Clockwork.item:Register(ITEM);