local ITEM = Clockwork.item:New("t45_pa");
ITEM.name = "Olive Drab T-45d Power Armor";
ITEM.uniqueID = "t45d_pa_olive";
ITEM.replacement = "models/power_armor/t45d.mdl";
ITEM.description = "A fully functioning suit of Olive Drab T-45d Power Armor.";

Clockwork.item:Register(ITEM);