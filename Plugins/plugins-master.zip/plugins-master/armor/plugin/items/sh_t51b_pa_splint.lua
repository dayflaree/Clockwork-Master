local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Splinter T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_splint";
ITEM.replacement = "models/t51b/t51g.mdl";
ITEM.description = "A fully functioning suit of black and red T-51b Power Armor with a strange Brotherhood insignia.";

Clockwork.item:Register(ITEM);