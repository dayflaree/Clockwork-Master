local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Winterized T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_winter";
ITEM.replacement = "models/t51b/t51b.mdl";
ITEM.description = "A fully functioning suit of winterized T-51b Power Armor.";

Clockwork.item:Register(ITEM);