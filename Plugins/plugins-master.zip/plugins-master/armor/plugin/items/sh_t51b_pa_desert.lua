local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Desert T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_desert";
ITEM.replacement = "models/t51b/t51d.mdl";
ITEM.description = "A fully functioning suit of desert T-51b Power Armor.";

Clockwork.item:Register(ITEM);