local ITEM = Clockwork.item:New("t51b_pa");
ITEM.name = "Vault-Tec T-51d Power Armor";
ITEM.uniqueID = "t51b_pa_vault";
ITEM.replacement = "models/t51b/t51j.mdl";
ITEM.description = "A fully functioning suit of Vault-Tec T-51b Power Armor.";

Clockwork.item:Register(ITEM);