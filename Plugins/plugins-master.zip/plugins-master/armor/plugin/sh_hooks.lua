
local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("paTraining", true);
end;