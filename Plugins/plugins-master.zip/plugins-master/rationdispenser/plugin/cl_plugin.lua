
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:AddToSystem("Ration Interval", "ration_interval", "Sets the ration interval in MINUTES!", 0, 2880, 0);