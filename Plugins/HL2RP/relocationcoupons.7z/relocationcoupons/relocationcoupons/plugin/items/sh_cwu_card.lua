
local ITEM = Clockwork.item:New();
ITEM.name = "CWU Employee Card";
ITEM.uniqueID = "cwu_card";
ITEM.model = "models/dorado/tarjetazero.mdl";
ITEM.weight = 0.05;
ITEM.description = "A petite, metallic identification card with a magnetic strip used to identify employees of the CWU.";

ITEM:AddData("id", 0, true);
ITEM:AddData("cid", 12345, true);
ITEM:AddData("numbers", "CN#:12345-ED#:67890-02", true);
ITEM:AddData("owner", "John Doe", true);

-- Called when an item is given to a player.
function ITEM:OnGiveToPlayer(player)
	if (player:GetFaction() == FACTION_CWU and self:GetData("id") == 0) then
		local playerName = player:Name();
		local id = player:GetCharacter().key;

		self:SetData("id", id);
		self:SetData("numbers", self:GetDigits(id));
		self:SetData("cid", player:GetCharacterData("citizenid"));
		self:SetData("owner", playerName);
	end;
end;

-- Called when the player's gear is restored.
function ITEM:OnRestorePlayerGear(player)
	local playerName = player:Name();
	local id = player:GetCharacter().key;


	if (player:GetFaction() == FACTION_CWU and self:GetData("id") == 0) then
		self:SetData("id", id);
		self:SetData("numbers", self:GetDigits(id));
		self:SetData("cid", player:GetCharacterData("citizenid"));
		self:SetData("owner", playerName);
	elseif (self:GetData("id") == id) then
		self:SetData("owner", playerName);
	end;
end;

function ITEM:GetDigits(id)
	local idText = Clockwork.kernel:ZeroNumberToDigits(id, 6);
	local cardText = string.sub(self("itemID"), 2, -1);
	local checkText = Clockwork.kernel:ZeroNumberToDigits((tonumber(cardText) * 1000000 + id) % 97, 2);

	return "CN#:"..string.gsub(cardText, "(%d%d%d)(%d%d%d%d)(%d%d)", "%1:%2:%3").."-ED#:"..idText.."-"..checkText;
end;

function ITEM:OnDrop(player, position) end;

function ITEM:GetClientSideInfo()
	return string.format("This identification card belongs to %s, CID %s.\nRegID. %s\nThis card is property of the Civil Worker's Union. If found, return it to a local protection officer immediately. Illegal carrying is a violation and will result in prosecution. This card will be deactivated upon loss.", self:GetData("owner"), self:GetData("cid"), self:GetData("numbers"));
end;

if (CLIENT) then
	function ITEM:OnHUDPaintTargetID(ent, x, y, alpha) 
		return Clockwork.kernel:DrawInfo("["..self:GetData("owner")..": #"..self:GetData("cid").."]", x, y, Color(255, 255, 255), alpha);
	end;
end;

ITEM:Register();
