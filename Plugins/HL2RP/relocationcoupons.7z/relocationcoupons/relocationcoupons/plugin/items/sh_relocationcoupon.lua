
local ITEM = Clockwork.item:New();
ITEM.name = "Citizen Relocation Coupon";
ITEM.model = "models/dorado/tarjeta2.mdl";
ITEM.weight = 0.05;
ITEM.access = "v"
ITEM.cost = 70
ITEM.description = "A petite, metallic identification card that confirms a citizen's transfer to the sector. This is used for identification purposes.";

ITEM:AddData("cid", 0, true);
ITEM:AddData("name", "", true);

-- Called when an item is given to a player.
function ITEM:OnGiveToPlayer(player)
	local playerName = player:Name();
	local citizenID = player:GetCharacterData("citizenid");

	if (self:GetData("cid") == 0) then
		self:SetData("name", playerName);
		self:SetData("cid", citizenID)
	end;
end;

-- Called when the player's gear is restored.
function ITEM:OnRestorePlayerGear(player)
	local playerName = player:Name();
	local citizenID = player:GetCharacterData("citizenid");

	if (self:GetData("cid") == 0) then
		self:SetData("name", playerName);
		self:SetData("cid", citizenID)
	elseif (self:GetData("cid") == citizenID) then
		self:SetData("name", playerName);
	end;
end;

function ITEM:OnDrop(player, position) end;

function ITEM:GetClientSideInfo()
	return string.format(
		"This identification card belongs to %s, CID %s.", self:GetData("name"), tostring(self:GetData("cid"))
	);
end;

if (CLIENT) then
	function ITEM:OnHUDPaintTargetID(ent, x, y, alpha) 
		return Clockwork.kernel:DrawInfo("[CID #"..self:GetData("cid").."]", x, y, Color(255, 255, 255), alpha);
	end;
end;

ITEM:Register();
