
local ITEM = Clockwork.item:New();
ITEM.name = "Unity Party Membership Card";
ITEM.uniqueID = "up_card";
ITEM.model = "models/dorado/tarjeta3.mdl";
ITEM.weight = 0.05;
ITEM.description = "A small, metallic card with a magnetic strip used to identify Unity Party members.";

ITEM:AddData("id", 0, true);
ITEM:AddData("cid", 12345, true);
ITEM:AddData("numbers", "CN#:12345-ID#:67890-02", true);
ITEM:AddData("owner", "John Doe", true);

-- Called when an item is given to a player.
function ITEM:OnGiveToPlayer(player)
	if (Clockwork.player:GetFactionTable(player).hasLoyalistRecord and !Clockwork.player:HasAnyFlags(player, "lL") and self:GetData("id") == 0) then
		local playerName = player:Name();
		local id = player:GetCharacter().key;

		self:SetData("id", id);
		self:SetData("numbers", self:GetDigits(id));
		self:SetData("cid", player:GetCharacterData("citizenid"));
		self:SetData("owner", playerName);
	end;
end;

-- Called when the player's gear is restored.
function ITEM:OnRestorePlayerGear(player)
	local playerName = player:Name();
	local id = player:GetCharacter().key;

	if (Clockwork.player:GetFactionTable(player).hasLoyalistRecord and !Clockwork.player:HasAnyFlags(player, "lL") and self:GetData("id") == 0) then
		self:SetData("id", id);
		self:SetData("numbers", self:GetDigits(id));
		self:SetData("cid", player:GetCharacterData("citizenid"));
		self:SetData("owner", playerName);
	elseif (self:GetData("id") == id) then
		self:SetData("owner", playerName);
	end;
end;

function ITEM:GetDigits(id)
	local idText = Clockwork.kernel:ZeroNumberToDigits(id, 6);
	local cardText = string.sub(self("itemID"), 2, -1);
	local checkText = Clockwork.kernel:ZeroNumberToDigits((tonumber(cardText) * 1000000 + id) % 97, 2);

	return "CN#:"..string.gsub(cardText, "(%d%d%d)(%d%d%d%d)(%d%d)", "%1:%2:%3").."-ID#:"..idText.."-"..checkText;
end;

function ITEM:OnDrop(player, position) end;

function ITEM:GetClientSideInfo()
	return string.format("This ID belongs to %s, CID %s.\nRegID. %s\nThis card is property of the Unity Party. If found, return it to a local protection officer immediately. Illegal carrying is a violation and will result in prosecution.  This card will be deactivated upon loss.", self:GetData("owner"), self:GetData("cid"), self:GetData("numbers"));
end;

if (CLIENT) then
	function ITEM:OnHUDPaintTargetID(ent, x, y, alpha) 
		return Clockwork.kernel:DrawInfo("["..self:GetData("owner")..": #"..self:GetData("cid").."]", x, y, Color(255, 255, 255), alpha);
	end;
end;

ITEM:Register();
