
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local table = table;
local pairs = pairs;

-- Called when a player's default inventory is needed.
function PLUGIN:GetPlayerDefaultInventory(player, character, inventory)
	local factionTable = Clockwork.faction:FindByID(character.faction);
	if (factionTable.relocationCoupon) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("citizen_relocation_coupon")
		);
	end;
end;

-- Called when a player uses a command.
function PLUGIN:PlayerUsedCommand(player, commandTable, arguments)
	if (commandTable.name == "CharSetName") then
		local playerName = table.concat(arguments, " ", 2);
		local target = Clockwork.player:FindByID(playerName);

		if (target) then
			local itemsList = target:GetItemsByID("citizen_relocation_coupon");

			if (itemsList) then
				local citizenID = target:GetCharacterData("citizenid");

				for k, v in pairs(itemsList) do
					if (v:GetData("cid") == citizenID) then
						v:SetData("name", playerName);
					end;
				end;
			end;

			if (target:GetFaction() == FACTION_WI) then
				itemsList = target:GetItemsByID("wi_card");
				if (itemsList) then
					local characterID = target:GetCharacter().key;

					for k, v in pairs(itemsList) do
						if (v:GetData("id") == characterID) then
							v:SetData("owner", playerName);
						end;
					end;
				end;
			elseif (target:GetFaction() == FACTION_CWU) then
				itemsList = target:GetItemsByID("cwu_card");
				if (itemsList) then
					local characterID = target:GetCharacter().key;

					for k, v in pairs(itemsList) do
						if (v:GetData("id") == characterID) then
							v:SetData("owner", playerName);
						end;
					end;
				end;
			end;
		end;
	end;
end;
