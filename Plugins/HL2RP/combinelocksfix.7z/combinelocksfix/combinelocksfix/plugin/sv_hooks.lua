function Schema:LoadCombineLocks()
	local combineLocks = Clockwork.kernel:RestoreSchemaData("plugins/locks/"..game.GetMap());
	
	for k, v in pairs(combineLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16);
		
		for k2, v2 in pairs(entity) do
			if (Clockwork.entity:IsDoor(v2)) then
				entity = v2;
				break;
			end;
		end;
		
		if (IsValid(entity)) then
			local combineLock = self:ApplyCombineLock(entity);
			
			if (combineLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				combineLock:SetLocalAngles(v.angles);
				combineLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					combineLock:Unlock();
				else
					combineLock:Lock();
				end;
			end;
		end;
	end;
end;