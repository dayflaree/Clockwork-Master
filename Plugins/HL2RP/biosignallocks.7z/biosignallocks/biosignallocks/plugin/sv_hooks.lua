local PLUGIN = PLUGIN;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	self:LoadBiosignalLocks();
end;

-- Called just after data should be saved.
function PLUGIN:PostSaveData()
	self:SaveBiosignalLocks();
end;

-- Called when a player attempts to lock an entity.
function PLUGIN:PlayerCanLockEntity(player, entity)
	if (Clockwork.entity:IsDoor(entity) and IsValid(entity.biosignalLock)) then
		if (Clockwork.config:Get("biosignal_lock_overrides"):Get() or entity.biosignalLock:IsLocked()) then
			return false;
		end;
	end;
end;

-- Called when a player attempts to unlock an entity.
function PLUGIN:PlayerCanUnlockEntity(player, entity)
	if (Clockwork.entity:IsDoor(entity) and IsValid(entity.biosignalLock)) then
		if (Clockwork.config:Get("biosignal_lock_overrides"):Get() or entity.biosignalLock:IsLocked()) then
			return false;
		end;
	end;
end;

-- Called when a player attempts to use an entity.
function PLUGIN:PlayerUse(player, entity)
	local overlayText = entity:GetNetworkedString("GModOverlayText");
	local curTime = CurTime();
	local faction = player:GetFaction();
	
	if (player:KeyDown(IN_SPEED) and Clockwork.entity:IsDoor(entity)) then
		if ((player:GetCharacterData("BiosigLevel") >=1) and IsValid(entity.biosignalLock)) then
			if (!player.nextBiosignalLock or curTime >= player.nextBiosignalLock) then
				entity.biosignalLock:ToggleWithChecks(player);
				
				player.nextBiosignalLock = curTime + 3;
			end;
			
			return false;
		end;
	end;
end;

-- Called when an entity has been breached.
function PLUGIN:EntityBreached(entity, activator)
	if (Clockwork.entity:IsDoor(entity)) then
		if (!IsValid(entity.biosignalLock)) then
			if (!IsValid(activator) or string.lower( entity:GetClass() ) != "prop_door_rotating") then
				Clockwork.entity:OpenDoor(entity, 0, true, true);
			else
				self:BustDownDoor(activator, entity);
			end;
		elseif (IsValid(activator) and activator:IsPlayer() and Schema:PlayerIsCombine(activator)) then
			if (string.lower( entity:GetClass() ) == "prop_door_rotating") then
				entity.biosignalLock:ActivateSmokeCharge( (entity:GetPos() - activator:GetPos() ):GetNormal() * 10000 );
			else
				entity.biosignalLock:SetFlashDuration(2);
			end;
		else
			entity.biosignalLock:SetFlashDuration(2);
		end;
	end;
end;