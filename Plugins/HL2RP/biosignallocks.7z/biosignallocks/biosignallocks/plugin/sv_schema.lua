local PLUGIN = PLUGIN;

-- A function to load the Biosignal locks.
function PLUGIN:LoadBiosignalLocks()
	local BiosignalLocks = Clockwork.kernel:RestoreSchemaData( "plugins/BiosignalLocks/"..game.GetMap() );
	
	for k, v in pairs(BiosignalLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16)[1];
		
		if (IsValid(entity)) then
			local biosignalLock = self:ApplyBiosignalLock(entity);
			
			if (biosignalLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				biosignalLock:SetLocalAngles(v.angles);
				biosignalLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					biosignalLock:Unlock();
				else
					biosignalLock:Lock();
				end;
			end;
		end;
	end;
end;

-- A function to save the Biosignal locks.
function PLUGIN:SaveBiosignalLocks()
	local BiosignalLocks = {};
	
	for k, v in pairs( ents.FindByClass("cw_biosignallock") ) do
		if (IsValid(v.entity)) then
			BiosignalLocks[#BiosignalLocks + 1] = {
				key = Clockwork.entity:QueryProperty(v, "key"),
				locked = v:IsLocked(),
				angles = v:GetLocalAngles(),
				position = v:GetLocalPos(),
				uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID"),
				doorPosition = v.entity:GetPos()
			};
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/BiosignalLocks/"..game.GetMap(), BiosignalLocks);
end;

-- A function to apply a Biosignal lock.
function PLUGIN:ApplyBiosignalLock(entity, position, angles)
	local biosignalLock = ents.Create("cw_biosignallock");
	
	biosignalLock:SetParent(entity);
	biosignalLock:SetDoor(entity);
	
	if (position) then
		if (type(position) == "table") then
			biosignalLock:SetLocalPos( Vector(-1.0313, 43.7188, -1.2258) );
			biosignalLock:SetPos( biosignalLock:GetPos() + (position.HitNormal * 4) );
		else
			biosignalLock:SetPos(position);
		end;
	end;
	
	if (angles) then
		biosignalLock:SetAngles(angles);
	end;
	
	biosignalLock:Spawn();
	
	if (IsValid(biosignalLock)) then
		return biosignalLock;
	end;
end;

-- A function to bust down a door.
function PLUGIN:BustDownDoor(player, door, force)
	door.bustedDown = true;
	
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	if (IsValid(door.biosignalLock)) then
		door.biosignalLock:Explode();
		door.biosignalLock:Remove();
	end;
	
	if (IsValid(door.breach)) then
		door.breach:BreachEntity();
	end;
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		if (!force) then
			if (IsValid(player)) then
				physicsObject:ApplyForceCenter( (door:GetPos() - player:GetPos() ):GetNormal() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	Clockwork.entity:Decay(fakeDoor, 300);
	
	Clockwork.kernel:CreateTimer("reset_door_"..door:EntIndex(), 300, 1, function()
		if (IsValid(door)) then
			door.bustedDown = nil;
			
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
		end;
	end);
end;