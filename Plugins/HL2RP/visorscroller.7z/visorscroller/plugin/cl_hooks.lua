local PLUGIN = PLUGIN;

Clockwork.datastream:Hook("VisorOpen", function(data)
	if (isbool(data)) then
		if (!data) then
			if (PLUGIN.Status) then
				PLUGIN.Status:Remove();
				PLUGIN.Status = nil;
			end;
		else
			PLUGIN:CreateScroll();
		end;
	else
		PLUGIN:CreateScroll(data[1], data[2]);
	end;
end);

function PLUGIN:CreateScroll(code, color)
	code = code or Clockwork.kernel:GetSharedVar("VisorStatus");
	local codeData = self.codeData[code];

	color = color or Clockwork.kernel:GetSharedVar("VisorColor") or Color(255, 255, 255);
	local colorData = self.colorData[color]

	if (self.Status and self.Status.open) then
		self.Status:Close();
		return;
	end;

	self.Status = vgui.Create("Scroller");
	self.Status:SetTall(0);
	self.Status:SetWidth(ScrW() * 0.1823);
	self.Status:SetPos(ScrW() - ScrW() * 0.1823 / 2 - 80 - ScrW() * 0.1823 / 2, 80);

	if (codeData) then
		timer.Remove("VisorStatus");
		self.Status:SetText(codeData[1]);
		self.Status:SetTextColor( codeData[2] );
		surface.PlaySound("ui/hint.wav");

		self.Status:Open();
	elseif (code == "green") then
		self.Status:SetText("SOCIO-STABILIZATION RESTORED");
		self.Status:SetTextColor(Color(34, 150, 34));
		surface.PlaySound("ui/hint.wav");

		self.Status:Open();

		timer.Create("VisorStatus", 3, 1, function()
			if (!self.Status and !self.Status.open) then return; end;

			self.Status:Close();
		end);
	else
		timer.Remove("VisorStatus");
		self.Status:SetText(code:upper());
		self.Status:SetTextColor(colorData);
		surface.PlaySound("ui/hint.wav");

		self.Status:Open();
	end
end;