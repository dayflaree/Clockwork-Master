local PLUGIN = PLUGIN;

surface.CreateFont( "Scrolling", {
	font = "DINEngschrift",
	size = ScreenScale(12),
	weight = 0,
	antialias = true,
} )

local PANEL = {}

function PANEL:Init()
	self.scrollingmessage = ""; -- Default Message
	self.scrollspeed = 150; -- Default Scrollspeed
	self.scrollingcolor = Color(255, 255, 255); -- If Color Is Not Defined Fallback On This
	self.width = ScrW() * 0.1823; -- Width Of The Box
end

function PANEL:SetText(text)
	self.scrollingmessage = tostring(text); -- Set The Scrolling Text Variable To "text"
end

function PANEL:SetTextColor(color)
	if (!IsColor(color)) then return; end; -- If "color" Is Not Actually A Color Then Don't Set The Variable

	self.scrollingcolor = color; -- Set The Color Variable To Whatever "color" Is.
end;

function PANEL:DrawScrollingText(w, h)
	local text = self.scrollingmessage .. "     ///     "; -- So The Message Appears Like So, EX: JUDGEMENT WAIVER     ///   JUDGEMENT WAIVER  

	surface.SetFont("Scrolling"); -- Set The Font

	local textw, texth = surface.GetTextSize(text); -- Text Size From The Font

	surface.SetTextColor(self.scrollingcolor); -- Set The Color To The Variable

	local x = RealTime() * self.scrollspeed % textw * -1 -- Magic

	while ( x < w ) do -- More Magic

		surface.SetTextPos( x, 8.5 )
		surface.DrawText( text )

		x = x + textw

	end

end

function PANEL:DrawCorners(x, y, w, h)
	local length = 12
	local thickness = 3

	surface.DrawRect(x, y, length, thickness); -- Top Left
	surface.DrawRect(x, y, thickness, length);

	surface.DrawRect(x + (w - length), y, length, thickness); -- Top Right
	surface.DrawRect(x + (w - thickness), y, thickness, length);

	surface.DrawRect(x, y + (h - length), thickness, length); -- Bottom Left
	surface.DrawRect(x, y + (h - thickness), length, thickness);

	surface.DrawRect(x + (w - thickness), y + (h - length), thickness, length); -- Bottom Right
	surface.DrawRect(x + (w - length), y + (h - thickness), length, thickness);
end


function PANEL:Open()
	if (self.open) then return; end;
	local x, y = self:GetPos();
	
	surface.SetFont("Scrolling");
	local textW, textH = surface.GetTextSize("000");

	self.open = true; -- It's open so it's set to true.

	self:SetAlpha(255); -- Make Sure Its Visible

	self:SizeTo(-1, textH + 15.5, 0.3, 0); -- Animation
	self:MoveTo(x, (y - (textH / 2)), 0.3, 0);
end

function PANEL:Close()
	if (!self.open) then return; end;
	local x, y = self:GetPos();

	surface.SetFont("Scrolling"); -- Get The Height/Width Of The Font So We Can Move It Accordingly
	local textW, textH = surface.GetTextSize("000");

	self.open = false; -- It's not open so it's set to false.

	self:SizeTo(-1, 0, 0.3, 0, -1, function() self:Remove(); end); -- Animation
	self:MoveTo(x, (y + (textH / 2)), 0.3, 0);
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(self.scrollingcolor.r, self.scrollingcolor.g, self.scrollingcolor.b, 25); -- Background
	surface.DrawRect(0, 0, w, h);

	self:DrawScrollingText(self.width, h); -- Scrolling Text

	surface.SetDrawColor( self.scrollingcolor ); -- Corners
	self:DrawCorners(0, 0, w, h)
end

vgui.Register("Scroller", PANEL, Panel)