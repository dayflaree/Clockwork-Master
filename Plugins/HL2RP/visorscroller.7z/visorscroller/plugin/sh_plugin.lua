local PLUGIN = PLUGIN;

-- Codes To Chose From
PLUGIN.codeData = {
	yellow = {"SOCIO-STABILIZATION MARGINAL", Color(255, 255, 0)},
	red = {"SOCIO-STABILIZATION FRACTURED", Color(127,63,63)},
	black = {"SOCIO-STABILIZATION LOST", Color(255, 255, 255)},
	jw = {"JUDGMENT WAIVER", Color(127,63,63)},
	aj = {"AUTONOMOUS JUDGMENT", Color(127,63,63)}
};

-- Colors To Chose From
PLUGIN.colorData = {
	yellow = Color(255, 255, 0),
	red = Color(127,63,63),
	white = Color(255, 255, 255),
	green = Color(34, 150, 34),
	blue = Color(0,100,200)
};

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	globalVars:String("VisorStatus"); -- Visor Message/Status
	globalVars:String("VisorColor"); -- Visor Message/Status Color
end;

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");