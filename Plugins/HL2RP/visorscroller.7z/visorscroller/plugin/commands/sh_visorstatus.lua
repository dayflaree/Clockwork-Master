local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("VisorStatus");
COMMAND.tip = "Notify all combine factions.";
COMMAND.text = "<string Code (green, yellow, red, black, aj, jw)> or <string Text> <string Color>";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;

function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player) and player:GetFaction() == FACTION_OTA) then
		if arguments and arguments[1] and (arguments[2] == "nil" or !arguments[2])  then
			PLUGIN:Send(arguments[1]:lower());
		elseif arguments and arguments[2] and arguments[2] != "nil" then
			PLUGIN:Send(arguments[1]:lower(), arguments[2]:lower());
		end
	else
		Clockwork.player:Notify(player, "You cannot!");
	end;
end;

COMMAND:Register();