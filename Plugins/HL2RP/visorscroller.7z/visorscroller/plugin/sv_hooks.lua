local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:Send(text, color)
	local colorold = color
	if !color then color = "white" end
	for k, v in pairs(player.GetAll()) do
		if (Schema:PlayerIsCombine(v)) then
			Clockwork.datastream:Start(v, "VisorOpen", {text, color});
		end
	end
	
	if (Clockwork.kernel:GetSharedVar("VisorStatus") != "") then
		Clockwork.kernel:SetSharedVar("VisorStatus", "")
		Clockwork.kernel:SetSharedVar("VisorColor", "")
	elseif (text != "green" and colorold != "nil") then
		Clockwork.kernel:SetSharedVar("VisorStatus", text)
		Clockwork.kernel:SetSharedVar("VisorColor", color)
	end
end

function PLUGIN:PlayerCharacterLoaded(player)
	if Clockwork.kernel:GetSharedVar("VisorStatus") != "" and Schema:PlayerIsCombine(player) then
		Clockwork.datastream:Start(player, "VisorOpen", true);
	end
end

function PLUGIN:PlayerCharacterUnloaded(player)
	if Clockwork.kernel:GetSharedVar("VisorStatus") != "" and Schema:PlayerIsCombine(player) then
		Clockwork.datastream:Start(player, "VisorOpen", false);
	end
end;