Clockwork.datastream:Hook("EditData", function(player, data)
	if (player.editDataAuthorised == data[1] and type(data[2]) == "string" and type(data[3]) == "table") then
		data[2] = string.sub(data[2], 0, 5000)
		data[1]:SetCharacterData("combinedata", data[2])

		for k, v in pairs (data[3]) do
			v.subject = string.sub(v.subject or "", 0, 100)
			v.details = string.sub(v.details or "", 0, 500)
		end

		PrintTable(data[3])

		data[1]:SetCharacterData("criminalRecord", data[3])
		
		player.editDataAuthorised = nil;
	end;
end);