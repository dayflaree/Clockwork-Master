
local COMMAND = Clockwork.command:New("ViewData");
COMMAND.tip = "View data about a given character.";
COMMAND.text = "<string Name or CID>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID( arguments[1] );
		
		if (target) then
			if (player != target) then
				Clockwork.datastream:Start( player, "EditData", { target, target:GetCharacterData("citizenid", ""), {text = target:GetCharacterData("combinedata", ""), criminalRecord = target:GetCharacterData("criminalRecord", {})}});
				
				player.editDataAuthorised = target;
			else
				Clockwork.player:Notify(player, "You cannot view or edit your own data!");
			end;
		else
			for k, v in pairs (_player.GetAll()) do
				if v:GetCharacterData("citizenid", "") == arguments[1] then
					Clockwork.datastream:Start( player, "EditData", { v, v:GetCharacterData("citizenid", ""), {text = v:GetCharacterData("combinedata", ""), criminalRecord = v:GetCharacterData("criminalRecord", {})}});
					player.editDataAuthorised = v
					return
				end
			end
			
			Clockwork.player:Notify(player, arguments[1].." is not a valid search parameter!");
		end;
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();