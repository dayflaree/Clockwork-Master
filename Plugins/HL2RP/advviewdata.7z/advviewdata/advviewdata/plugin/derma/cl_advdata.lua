local PANEL = {}

function PANEL:FillOut(player, cid, data)
	if (cid and cid != "") then
		self:SetTitle(player:Name()..", CID#"..cid)
	else
		self:SetTitle(player:Name())
	end
	
	self.recordsList.records = data.criminalRecord
	self.recordsList:Reload()
	self.textEntry:SetText(data.text)
	self.player = player
end

function PANEL:AddRecord()
	local recordManager = vgui.Create("cwAdvDataRecordManager")
	recordManager:Load(self)
end

function PANEL:EditRecord(index)
	local recordManager = vgui.Create("cwAdvDataRecordManager")
	recordManager:Load(self, index)
end

function PANEL:ViewRecord(index)
	local recordManager = vgui.Create("cwAdvDataRecordManager")
	recordManager:Load(self, index, true)
end

function PANEL:Init()
	self.recordsAmt = 0
	self:SetSize(ScrW() * 0.75, ScrH() * 0.75)

	self.textEntry = vgui.Create("DTextEntry", self)
	self.textEntry:SetMultiline(true)
	self.recordsList = vgui.Create("DListView", self)
	self.recordsList.recordLineColors = {[true] = Color(150, 255, 150, 255), [false] = Color(255, 150, 150, 255)}
	self.recordsList.records = {}

	function self.btnClose.DoClick(this)
		self:Close(); self:Remove()
		
		gui.EnableScreenClicker(false)
	end

	function self.textEntry:Think()
		local text = self:GetValue();
		
		if (string.len(text) > 5000) then
			self:SetRealValue( string.sub(text, 0, 5000) );
			surface.PlaySound("common/talk.wav");
		end;
	end

	function self.textEntry:SetRealValue(text)
		self:SetValue(text);
		self:SetCaretPos( string.len(text) );
	end;

	function self.recordsList:Reload()
		self:Clear()
		for k, v in pairs (self.records) do
			local displayText

			if (v.bLoyalty) then
				displayText = v.points.." Loyalty Points"
			else
				displayText = v.points.." Penality Points"
			end

			local line = self:AddLine(v.reason, v.details, displayText)
			local color = self.recordLineColors[v.bLoyalty]
			function line:Paint(w, h)
				surface.SetDrawColor(color)
				surface.DrawRect(0, 0, w, h)
			end
			line.recordIndex = k
		end
	end

	self.recordsList:AddColumn("Reason")
	self.recordsList:AddColumn("Details")
	self.recordsList:AddColumn("Points")
	self.recordsList:SetMultiSelect(false)

	self.addRecordButton = vgui.Create("DButton", self)
	self.editRecordButton = vgui.Create("DButton", self)
	self.removeRecordButton = vgui.Create("DButton", self)
	self.viewRecordButton = vgui.Create("DButton", self)
	self.applyButton = vgui.Create("DButton", self)

	self.totalLabel = vgui.Create("DLabel", self)

	self.addRecordButton:SetText("Add Record")
	self.editRecordButton:SetText("Edit Record")
	self.removeRecordButton:SetText("Remove Record")
	self.viewRecordButton:SetText("View Record")
	self.applyButton:SetText("Save Data")

	self.totalLabel:SetText("Penality Points Subtotal: 0\nLoyalist Points Subtotal: 0\n----------------------------\nTotal: 0")

	function self.totalLabel.Think()
		local total = 0
		local loyaltyPoints = 0
		local penalityPoints = 0
		for k, v in pairs (self.recordsList.records) do
			local points = tonumber(v.points)
			if v.bLoyalty then
				loyaltyPoints = loyaltyPoints + points
				total = total + points
			else
				penalityPoints = penalityPoints + points
				total = total - points
			end
		end
		self.totalLabel:SetText("Penality Points Subtotal: "..penalityPoints.."\nLoyalist Points Subtotal: "..loyaltyPoints.."\n----------------------------\nTotal: "..total)
	end

	function self.addRecordButton.DoClick(this)
		self:AddRecord()
	end

	function self.editRecordButton.DoClick(this)
		if (!self.recordsList:GetSelectedLine()) then return end;

		local selectedLineID = self.recordsList:GetSelectedLine()
		self:EditRecord(self.recordsList:GetLine(selectedLineID).recordIndex)
	end

	function self.removeRecordButton.DoClick(this)
		if (!self.recordsList:GetSelectedLine()) then return end;

		local selectedLineID = self.recordsList:GetSelectedLine()
		local selectedLine = self.recordsList:GetLine(selectedLineID)
		self.recordsList.records[selectedLine.recordIndex] = nil
		self.recordsList:RemoveLine(selectedLineID)
		self.recordsList:Reload()
	end

	function self.viewRecordButton.DoClick(this)
		if (!self.recordsList:GetSelectedLine()) then return end;

		local selectedLineID = self.recordsList:GetSelectedLine()
		self:ViewRecord(self.recordsList:GetLine(selectedLineID).recordIndex)
	end


	function self.applyButton.DoClick(this)
		local player = self.player

		for k, v in pairs (self.recordsList.records) do
			v.subject = string.sub(v.subject or "", 0, 100)
			v.details = string.sub(v.details or "", 0, 500)
		end

		Clockwork.datastream:Start( "EditData", {player, string.sub(self.textEntry:GetValue(), 0, 5000), self.recordsList.records} );
		self:Close(); self:Remove()
		gui.EnableScreenClicker(false)
	end

	self:MakePopup()
	self:Center()
end

function PANEL:PerformLayout()
	self.textEntry:SetPos(5, 29)
	self.textEntry:SetSize(self:GetWide() - 10, ((self:GetTall() - 24) / 2) - 10)

	local x, y = self.textEntry:GetPos()

	self.recordsList:SetPos(x, y + self.textEntry:GetTall() + 5)
	self.recordsList:SetSize(self:GetWide() * 0.75, self.textEntry:GetTall())

	x, y = self.recordsList:GetPos()

	self.addRecordButton:SetPos(x + self.recordsList:GetWide() + 5, y)

	x, y = self.addRecordButton:GetPos()

	self.addRecordButton:SetSize(self:GetWide() - x - 10, 25)

	self.editRecordButton:SetPos(x, y + self.addRecordButton:GetTall() + 5)
	self.editRecordButton:SetSize(self.addRecordButton:GetWide(), self.addRecordButton:GetTall())

	x, y = self.editRecordButton:GetPos()

	self.viewRecordButton:SetPos(x, y + self.addRecordButton:GetTall() + 5)
	self.viewRecordButton:SetSize(self.addRecordButton:GetWide(), self.addRecordButton:GetTall())

	x, y = self.viewRecordButton:GetPos()

	self.removeRecordButton:SetPos(x, y + self.addRecordButton:GetTall() + 5)
	self.removeRecordButton:SetSize(self.addRecordButton:GetWide(), self.addRecordButton:GetTall())

	x, y = self.removeRecordButton:GetPos()

	self.totalLabel:SetPos(x, y + self.removeRecordButton:GetTall() + 5)
	self.totalLabel:SizeToContents()

	self.applyButton:SetPos(x, self:GetTall() - self.addRecordButton:GetTall() - 5)
	self.applyButton:SetSize(self.addRecordButton:GetWide(), self.addRecordButton:GetTall())

	DFrame.PerformLayout(self)
end

vgui.Register("cwAdvData", PANEL, "DFrame")

PANEL = {}

function PANEL:Load(parentWindow, index, bView)
	self.parentWindow = parentWindow
	self.bView = bView
	self:SetTitle("Record Manager - Add New Record")
	if (index) then
		self.recordIndex = index
		local dataTable = parentWindow.recordsList.records[index]

		if dataTable.bLoyalty then
			self.pointsTypeBox:ChooseOptionID(2)
		else
			self.pointsTypeBox:ChooseOptionID(1)
		end

		self.reasonBox:SetText(dataTable.reason)
		self.detailsBox:SetText(dataTable.details)
		self.pointsBox:SetText(dataTable.points)

		self:SetTitle("Record Manager - Edit Existing Record")

		if (bView) then
			self:SetTitle("Record Manager - ReadOnly Mode")
			self.reasonBox:SetEditable(false)
			self.detailsBox:SetEditable(false)
			self.pointsBox:SetEditable(false)
			self.pointsTypeBox:SetKeyboardInputEnabled(false)
			self.pointsTypeBox:SetMouseInputEnabled(false)
			self.pointsBox:SetKeyboardInputEnabled(false)
			self.pointsBox:SetMouseInputEnabled(false)
			self.confirmButton:SetDisabled(true)
		end
	end
end

function PANEL:Init()
	self:SetSize(524, 300)
	self:SetTitle("Record Manager - ACTIONMODE")

	self.reasonBox = vgui.Create("DTextEntry", self)
	self.detailsBox = vgui.Create("DTextEntry", self)
	self.pointsBox = vgui.Create("DNumberWang", self)
	self.pointsTypeBox = vgui.Create("DComboBox", self)
	self.confirmButton = vgui.Create("DButton", self)

	self.confirmButton:SetText("Apply")

	self.pointsTypeBox:AddChoice("Penality Points")
	self.pointsTypeBox:AddChoice("Loyalty Points")

	self.pointsTypeBox:ChooseOptionID(1)

	self.reasonLabel = vgui.Create("DLabel", self)
	self.pointsLabel = vgui.Create("DLabel", self)
	self.detailsLabel = vgui.Create("DLabel", self)

	self.reasonLabel:SetText("Subject")
	self.pointsLabel:SetText("Points")
	self.detailsLabel:SetText("Details")

	self.pointsBox:SetMinMax(0, 255)
	self.pointsBox:SetValue(0)
	self.pointsBox:SetDecimals(0)

	self.detailsBox:SetMultiline(true)

	function self.btnClose.DoClick(this)
		self:Close(); self:Remove()
	end

	function self.reasonBox:Think()
		local text = self:GetValue();
		
		if (string.len(text) > 100) then
			self:SetRealValue( string.sub(text, 0, 100) );
			surface.PlaySound("common/talk.wav");
		end;
	end

	function self.reasonBox:SetRealValue(text)
		self:SetValue(text);
		self:SetCaretPos( string.len(text) );
	end;

	function self.detailsBox:Think()
		local text = self:GetValue();
		
		if (string.len(text) > 500) then
			self:SetRealValue( string.sub(text, 0, 500) );
			surface.PlaySound("common/talk.wav");
		end;
	end

	function self.detailsBox:SetRealValue(text)
		self:SetValue(text);
		self:SetCaretPos( string.len(text) );
	end;

	function self.pointsTypeBox:OnSelect(index, value, data)
		self.selectedIndex = index
	end
		
	function self.confirmButton.DoClick(this)
		local bLoyalty = false
		if self.pointsTypeBox.selectedIndex == 2 then
			bLoyalty = true
		end
		if (!self.bView) then
			if (self.recordIndex) then
				self.parentWindow.recordsList.records[self.recordIndex] = {reason = self.reasonBox:GetText(), details = self.detailsBox:GetText(), points = self.pointsBox:GetValue(), bLoyalty = bLoyalty}
			else
				self.parentWindow.recordsList.records[#self.parentWindow.recordsList.records + 1] = {reason = self.reasonBox:GetText(), details = self.detailsBox:GetText(), points = self.pointsBox:GetValue(), bLoyalty = bLoyalty}
			end
			self.parentWindow.recordsList:Reload()
		end
		self:Close(); self:Remove()
	end

	self:MakePopup()
	self:Center()
end

function PANEL:PerformLayout()
	self.reasonLabel:SetPos(5, 29)
	self.reasonLabel:SizeToContents()

	local x, y = self.reasonLabel:GetPos()

	self.reasonBox:SetPos(x, y + self.reasonLabel:GetTall())
	self.reasonBox:SetWide(self:GetWide() - 10)

	x, y = self.reasonBox:GetPos()

	self.pointsLabel:SetPos(x, y + self.reasonBox:GetTall() + 5)
	self.pointsLabel:SizeToContents()

	x, y = self.pointsLabel:GetPos()

	self.pointsBox:SetPos(x, y + self.pointsLabel:GetTall())
	self.pointsBox:SizeToContents()

	x, y = self.pointsBox:GetPos()

	self.pointsTypeBox:SetPos(x + self.pointsBox:GetWide() + 5, y)
	self.pointsTypeBox:SetWide(self:GetWide() - x - self.pointsBox:GetWide() - 10)

	self.detailsLabel:SetPos(x, y + self.pointsBox:GetTall() + 5)
	self.detailsLabel:SizeToContents()

	x, y = self.detailsLabel:GetPos()

	self.confirmButton:SetSize(self:GetWide() - 10, 25)
	self.confirmButton:SetPos(5, self:GetTall() - self.confirmButton:GetTall() - 5)

	self.detailsBox:SetPos(x, y + self.detailsLabel:GetTall())
	self.detailsBox:SetSize(self:GetWide() - 10, self:GetTall() - y - self.detailsLabel:GetTall() - 5 - self.confirmButton:GetTall())

	DFrame.PerformLayout(self)
end

vgui.Register("cwAdvDataRecordManager", PANEL, "DFrame")