Clockwork.datastream:Hook("EditData", function(data)
	if (IsValid( data[1] )) then
		if (Schema.dataPanel and Schema.dataPanel:IsValid()) then
			Schema.dataPanel:Close();
			Schema.dataPanel:Remove();
		end;
		
		Schema.dataPanel = vgui.Create("cwAdvData");
		Schema.dataPanel:FillOut(data[1], data[2], data[3]);
		
		gui.EnableScreenClicker(true);
	end;
end);