Clockwork.kernel:IncludePrefixed("cl_plugin.lua")
Clockwork.kernel:IncludePrefixed("cl_hooks.lua")
Clockwork.kernel:IncludePrefixed("sv_hooks.lua")
Clockwork.kernel:IncludePrefixed("sv_plugin.lua")

resource.AddFile( "materials/waypointmarker/wpmarker.vmt" )
resource.AddFile( "materials/waypointmarker/wpmarker.vtf" )