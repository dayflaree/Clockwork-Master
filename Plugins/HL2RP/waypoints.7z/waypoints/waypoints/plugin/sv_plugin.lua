resource.AddFile("garrysmod/materials/waypointmarker/wpmarker")

Clockwork.config:Add("waypointmarker_charlimit", 32, true)
Clockwork.config:Add("waypointmarker_duration", 10, true)