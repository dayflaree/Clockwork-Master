local CLASS = Clockwork.class:New("Refugee");

CLASS.color = Color(184, 151, 42, 255);
CLASS.factions = {FACTION_REFUGEE};
CLASS.isDefault = true;
CLASS.wagesName = "Wages";
CLASS.description = "A citizen that is a refugee.";
CLASS.defaultPhysDesc = "A citizen wearing tattered clothing.";
	
CLASS_REFUGEE = CLASS:Register();