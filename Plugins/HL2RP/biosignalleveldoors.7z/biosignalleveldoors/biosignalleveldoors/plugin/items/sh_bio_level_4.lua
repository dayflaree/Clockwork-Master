local ITEM = Clockwork.item:New();
ITEM.name = "Level 4 ID Chip";
ITEM.cost = 400;
ITEM.model = "models/gibs/metal_gib4.mdl";
ITEM.weight = 0.1;
ITEM.access = "I";
ITEM.useText = "Inset";
ITEM.category = "ID Chip";
ITEM.business = true;
ITEM.description = "A flat plastic Chip, reads 'Level 4 ID Chip'";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if((player:GetFaction() == FACTION_MPF) or (player:GetFaction() == FACTION_OTA)) then
	player:SetCharacterData("BiosigLevel", 4);
	end;
end;

ITEM:Register();