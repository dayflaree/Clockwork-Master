-- Called when a player attempts to use a door.
function Schema:PlayerCanUseDoor(player, door)
	if (player:GetSharedVar("tied") != 0) then
	Clockwork.player:Notify(player, "You cannot open doors when you are tied!");
	return false;
	elseif(player:GetSharedVar("tied") == 0) then
	local doorName = string.lower( door:GetName() );
		if(((doorName == "door_level1") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level one door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level one") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level one Door::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level one::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 1::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 1") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 1 door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 1 door::>")) and (player:GetCharacterData("BiosigLevel") >=1)) then
		return true;
		elseif(((doorName == "door_level2") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level two door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level two") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level two Door::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level two::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 2::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 2") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 2 door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 2 door::>")) and (player:GetCharacterData("BiosigLevel") >=2)) then
		return true;
		elseif(((doorName == "door_level3") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level three door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level three") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level three Door::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level three::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 3::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 3") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 3 door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 3 door::>")) and (player:GetCharacterData("BiosigLevel") >=3)) then
		return true;
		elseif(((doorName == "door_level4") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level four door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level four") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level four Door::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level four::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 4::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 4") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 4 door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 4 door::>")) and (player:GetCharacterData("BiosigLevel") >=4)) then
		return true;
		elseif(((doorName == "door_level5") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level five door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level five") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level five Door::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level five::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 5::>") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 5") or (string.lower(Clockwork.entity:GetDoorName(door)) == "level 5 door") or (string.lower(Clockwork.entity:GetDoorName(door)) == "<::level 5 door::>")) and (player:GetCharacterData("BiosigLevel") >=5)) then
		return true;
		else
		return false;
	end;
end;
end;

-- Accepted door names
-- Level One Door, Level One, Level 1, Level 1 Door, <::Level One Door::>, <::Level One::>, <::Level 1::>, <::Level 1 Door::>
-- Level Two Door, Level Two, Level 2, Level 2 Door, <::Level Two Door::>, <::Level Two::>, <::Level 2::>, <::Level 2 Door::>
-- Etc, etc. All the way to Level Five/5 etc.

-- Called when a player's default inventory is needed.
function PLUGIN:GetPlayerDefaultInventory(player, character, inventory)
	if (character.faction == FACTION_MPF) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("level_1_id_chip")
		);
	elseif (character.faction == FACTION_OTA) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("level_5_id_chip")
		);
	end;
end;