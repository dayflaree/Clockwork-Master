local CLASS = Clockwork.class:New("Headcrab");

CLASS.color = Color(235, 117, 1, 255);
CLASS.factions = {FACTION_NECROTIC};
CLASS.wages = false;
CLASS.maleModel = "models/headcrabclassic.mdl"
CLASS.isDefault = true;
CLASS.wagesName = "Flesh";
CLASS.description = "A necrotic creature, I'd stay away.";
CLASS.defaultPhysDesc = "A necrotic creature, I'd stay away.";	
CLASS_NECROTIC = CLASS:Register();