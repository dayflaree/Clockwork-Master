local FACTION = Clockwork.faction:New("Necrotics");

FACTION.isCombineFaction = true;
FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.models = {
	female = {"models/headcrabclassic.mdl"},
	male = {"models/headcrabclassic.mdl"}
};

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (faction.name != FACTION_CITIZEN) then
		return false;
	end;
end;

FACTION_NECROTIC = FACTION:Register();