local PLUGIN = PLUGIN;

function PLUGIN:PlayerCanZoom()
	if PLUGIN:PlayerHasBinoculars(Clockwork.Client) ~= nil then
		if PLUGIN:PlayerHasBinoculars(Clockwork.Client) then
			return true;
		end;
	else
		return false;
	end;
end;