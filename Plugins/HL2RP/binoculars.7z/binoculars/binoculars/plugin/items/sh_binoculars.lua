--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Binoculars";
	ITEM.cost = 15;
	ITEM.model = "models/props_junk/cardboard_box004a.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "v";
	ITEM.category = "Reusables";
	ITEM.uniqueID = "cw_binoculars";
	ITEM.business = true;
	ITEM.isFakeWeapon = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A pair of worn, rusty-looking binoculars! It is within an old-looking, cardboard box.";
	ITEM.value = 0.7;
	ITEM.spawncategory = 3;
ITEM:Register();