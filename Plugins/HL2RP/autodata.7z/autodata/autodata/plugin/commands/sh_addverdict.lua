local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("AddVerdict");
COMMAND.tip = "Add a verdict to a citizen's data.";
COMMAND.text = "<string Name> <string Violation> <number Points> <string Verdict>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 4;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID(arguments[1]);
		if (target) then
			local crime = arguments[2];
			local points = arguments[3];
			local verdict = arguments[4];

			Clockwork:AddBlankLine(target);
			Clockwork:AddLine(target, "<:: "..string.upper(crime).." ::>");
			Clockwork:AddLine(target, "<:: "..player:Name());
			Clockwork:AddLine(target, "<:: "..points.." POINTS");
			Clockwork:AddLine(target, "<:: "..os.date("%x"))
			Clockwork:AddLine(target, "<:: VERDICT: "..string.upper(verdict));
			Clockwork.datastream:Start( player, "EditData", { target, target:GetCharacterData("combinedata") } );
			player.editDataAuthorised = target;
		else
			player:Notiy(arguments[1].." is not a valid character!");
		end;
	else
		player:Notify("You are not the Combine!")
	end;
end;

COMMAND:Register();