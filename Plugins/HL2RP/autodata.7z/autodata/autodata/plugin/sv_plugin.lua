local PLUGIN = PLUGIN;
local Clockwork = Clockwork

-- A function to add a line to someone's data.
function Clockwork:AddLine(player, text)
	player:SetCharacterData("combinedata", player:GetCharacterData("combinedata").."\n"..text);
end;

-- A function to add a blank line to someone's data.
function Clockwork:AddBlankLine(player)
	player:SetCharacterData("combinedata", player:GetCharacterData("combinedata").."\n");
end;

-- A function to set a player's default data.
function PLUGIN:SetDefaultData(player)
	if (player:GetFaction() == FACTION_CITIZEN and !player:GetCharacterData("combinedata") or player:GetCharacterData("combinedata") == "") then
		Clockwork:AddLine(player, "<:: Full Name: "..player:Name());
		Clockwork:AddLine(player, "<:: Citizen ID: "..tonumber(player:GetSharedVar("citizenID")));
		Clockwork:AddLine(player, "<:: Gender: "..player:GetGender());
		Clockwork:AddLine(player, "<:: Reputation: 0");
	end;
end;