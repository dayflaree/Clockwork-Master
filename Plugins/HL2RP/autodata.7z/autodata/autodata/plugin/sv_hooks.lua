local PLUGIN = PLUGIN;

-- Called when a player's shared variables should be set.
-- We do this in this hook so the citizen ID line doesn't shit on itself.
function PLUGIN:PlayerSetSharedVars(player)
	self:SetDefaultData(player);
end;