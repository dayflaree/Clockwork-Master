--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("Gasmask", true);
	playerVars:Number("Filter", true);
	playerVars:Bool("safeAir", true);
end;

PLUGIN.gasmaskBreath = {
	"avoxgaming/gas_mask/gas_mask_light/gas_mask_light_breath1.wav",
	"avoxgaming/gas_mask/gas_mask_light/gas_mask_light_breath2.wav",
	"avoxgaming/gas_mask/gas_mask_light/gas_mask_light_breath3.wav",
	"avoxgaming/gas_mask/gas_mask_light/gas_mask_light_breath4.wav",
	"avoxgaming/gas_mask/gas_mask_light/gas_mask_light_breath5.wav",
	"avoxgaming/gas_mask/gas_mask_middle/gas_mask_middle_breath1.wav",
	"avoxgaming/gas_mask/gas_mask_middle/gas_mask_middle_breath2.wav",
	"avoxgaming/gas_mask/gas_mask_middle/gas_mask_middle_breath3.wav",
	"avoxgaming/gas_mask/gas_mask_middle/gas_mask_middle_breath4.wav",
	"avoxgaming/gas_mask/gas_mask_middle/gas_mask_middle_breath5.wav",
	"avoxgaming/gas_mask/gas_mask_hard/gas_mask_hard_breath1.wav",
	"avoxgaming/gas_mask/gas_mask_hard/gas_mask_hard_breath2.wav",
	"avoxgaming/gas_mask/gas_mask_hard/gas_mask_hard_breath3.wav",
	"avoxgaming/gas_mask/gas_mask_hard/gas_mask_hard_breath4.wav",
	"avoxgaming/gas_mask/gas_mask_hard/gas_mask_hard_breath5.wav"
};

PLUGIN.airAreas = {};

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

PLUGIN:SetGlobalAlias( "AirExtractor" )