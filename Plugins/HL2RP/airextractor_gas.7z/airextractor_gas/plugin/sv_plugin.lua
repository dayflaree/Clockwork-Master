--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.kernel:AddDirectory("materials/models/jake/");
Clockwork.kernel:AddDirectory("materials/effects/gasmask_screen*");
Clockwork.kernel:AddDirectory("models/avoxgaming/mrp/jake/props/");
Clockwork.kernel:AddDirectory("sound/effects/iron_wall/gas_mask/");

Clockwork.config:Add("air_extractor", false);
Clockwork.config:Add("air_extractor_give_mask", false);
Clockwork.config:Add("air_extractor_filter_change_limit", 20);

local playerMeta = FindMetaTable("Player");

function PLUGIN:LoadAirAreas()
	local manualtriggers = {
	{ Vector( -253.000000, -1533.000000, -161.000000 ), Vector( 253.000000, 1533.000000, 161.000000 ), Vector( 3332.000000, 1020.000000, -40.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -893.000000, -129.000000, -57.000000 ), Vector( 893.000000, 129.000000, 57.000000 ), Vector( 2188.000000, 1856.000000, -80.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -1353.000000, -129.000000, -181.000000 ), Vector( 1353.000000, 129.000000, 181.000000 ), Vector( -56.000000, 1856.000000, -204.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -321.000000, -321.000000, -189.000000 ), Vector( 321.000000, 321.000000, 189.000000 ), Vector( -1728.000000, 1856.000000, -196.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -129.000000, -901.000000, -85.000000 ), Vector( 129.000000, 901.000000, 85.000000 ), Vector( 3328.000000, 3452.000000, -116.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -177.000000, -129.000000, -89.000000 ), Vector( 177.000000, 129.000000, 89.000000 ), Vector( 3376.000000, 4480.000000, -112.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -1433.000000, -129.000000, -89.000000 ), Vector( 1433.000000, 129.000000, 89.000000 ), Vector( 2024.000000, 4736.000000, -112.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -593.000000, -577.000000, -89.000000 ), Vector( 593.000000, 577.000000, 89.000000 ), Vector( 4144.000000, 4928.000000, -112.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -129.000000, -1217.000000, -345.000000 ), Vector( 129.000000, 1217.000000, 313.000000 ), Vector( 4608.000000, 6720.000000, 144.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -65.000000, -1057.000000, -69.000000 ), Vector( 65.000000, 1057.000000, 69.000000 ), Vector( 3968.000000, 3616.000000, 68.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -353.000000, -65.000000, -69.000000 ), Vector( 353.000000, 65.000000, 69.000000 ), Vector( 3552.000000, 2624.000000, 68.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -637.000000, -65.000000, -57.000000 ), Vector( 637.000000, 65.000000, 57.000000 ), Vector( 4668.000000, 4160.000000, 56.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -329.000000, -209.000000, -69.000000 ), Vector( 329.000000, 209.000000, 69.000000 ), Vector( 5504.000000, 3888.000000, 44.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -221.000000, -225.000000, -377.000000 ), Vector( 221.000000, 225.000000, 377.000000 ), Vector( 6052.000000, 3752.000000, -8.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -97.000000, -285.000000, -65.000000 ), Vector( 97.000000, 285.000000, 65.000000 ), Vector( 5984.000000, 4260.000000, 40.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -1137.000000, -65.000000, -81.000000 ), Vector( 1137.000000, 65.000000, 81.000000 ), Vector( 5168.000000, 4608.000000, 32.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -49.000000, -1481.000000, -81.000000 ), Vector( 49.000000, 1481.000000, 81.000000 ), Vector( 6352.000000, 3192.000000, 32.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -769.000000, -249.000000, -81.000000 ), Vector( 769.000000, 249.000000, 81.000000 ), Vector( 5632.000000, 1464.000000, 32.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -257.000000, -145.000000, -141.000000 ), Vector( 257.000000, 145.000000, 141.000000 ), Vector( 4608.000000, 1264.000000, 60.000000 ), Angle( 0.000, 0.000, 0.000 ) },
	{ Vector( -389.000000, -209.000000, -65.000000 ), Vector( 389.000000, 209.000000, 65.000000 ), Vector( 3964.000000, 1104.000000, 48.000000 ), Angle( 0.000, 0.000, 0.000 ) }
	}
	for k, v in ipairs( manualtriggers ) do
		local novaboxisepic69 = ents.Create("safezones");
		local entity = novaboxisepic69:SpawnFunction(v[1], v[2], v[3], v[4])
		novaboxisepic69:Remove()
	end;
	print("LOADING NEW SAFEZONES!")
end;

function playerMeta:GetGasmaskData()
	local gasmaskData = self:GetCharacterData("Gasmask");

	if (type(gasmaskData) != "table") then
		gasmaskData = {};
	end;
	
	return gasmaskData;
end;

function playerMeta:RemoveGasmask(bRemoveItem)
	self:PlayerWearGasmask(nil);
	
	if (bRemoveItem) then
		local gasmaskItem = self:GetGasmaskItem();
		
		if (gasmaskItem) then
			self:TakeItem(gasmaskItem);
			return gasmaskItem;
		end;
	end;
end;

function playerMeta:GetGasmaskItem()
	local gasmaskData = self:GetGasmaskData();
	
	if (type(gasmaskData) == "table") then
		if (gasmaskData.itemID != nil and gasmaskData.uniqueID != nil) then
			return self:FindItemByID(
				gasmaskData.uniqueID, gasmaskData.itemID
			);
		end;
	end;
end;

function playerMeta:IsWearingGasmask()
	return (self:GetGasmaskItem() != nil);
end;

function playerMeta:PlayerWearGasmask(itemTable)
	local gasmaskItem = self:GetClothesItem();
	
	if (itemTable) then
		Clockwork.player:CreateGear(self, "Gasmask", itemTable);
		self:SetCharacterData("Gasmask", itemTable.index);
		self:SetSharedVar("Gasmask", itemTable.index);
	else
		Clockwork.player:RemoveGear(self, "Gasmask");
		self:SetCharacterData("Gasmask", nil);
		self:SetSharedVar("Gasmask", 0);
	end;
end;

function PLUGIN:SetSafeAir(player, state)
	player.cwSafeAir = state;
	player:SetSharedVar("safeAir", state);
end;