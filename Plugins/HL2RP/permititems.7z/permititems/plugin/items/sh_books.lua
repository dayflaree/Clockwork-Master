--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("accessory_base");
ITEM.name = "Books Permit";
ITEM.cost = 10;
ITEM.model = "models/gibs/metal_gib4.mdl";
ITEM.weight = 1;
ITEM.category = "Cards";
ITEM.business = false;
ITEM.description = "Permit that gives you access to the books.";

-- Called when a player wears the accessory.
function ITEM:OnWearAccessory(player, bIsWearing)
	if (bIsWearing) then
		Clockwork.player:GiveFlags(player, "3")
	else
		Clockwork.player:TakeFlags(player, "3")
	end;
end;

ITEM:Register();

