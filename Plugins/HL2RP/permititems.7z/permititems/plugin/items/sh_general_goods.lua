--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("accessory_base");
ITEM.name = "General Goods Permit";
ITEM.cost = 10;
ITEM.model = "models/gibs/metal_gib4.mdl";
ITEM.weight = 1;
ITEM.category = "Cards";
ITEM.business = false;
ITEM.description = "Permit that gives you access to the general goods.";

-- Called when a player wears the accessory.
function ITEM:OnWearAccessory(player, bIsWearing)
	if (bIsWearing) then
		Clockwork.player:GiveFlags(player, "1")
	else
		Clockwork.player:TakeFlags(player, "1")
	end;
end;

ITEM:Register();

