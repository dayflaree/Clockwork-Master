--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PANEL = {};
local PLUGIN = PLUGIN;
local texture = Material("novabox/gui/datapadoverlay.png")
texture:SetFloat("$alpha", 0.75);
texture:SetFloat("$multiply", 2);
local bgtexture = Material("novabox/gui/datapadback.png")
local bigcolor = Color( 255, 255, 255, 75 )
local bigcolor3 = Color( 255, 0, 0, 75 )

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetBackgroundBlur(true);
	self:SetDeleteOnClose(false);
	
	-- Called when the button is clicked.
	function self.btnClose.DoClick(button)
		self:Close(); self:Remove();
		
		gui.EnableScreenClicker(false);
		
		LocalPlayer():ConCommand( "cwSay /datapad" )
	end;
end;

-- Called each frame.
function PANEL:Think()
	local scrW = ScrW();
	local scrH = ScrH();
	
	self:SetSize( 500, 800 )
	self:SetPos( (scrW / 2) - (self:GetWide() / 2), (scrH / 2) - (self:GetTall() / 2) );
end;

-- A function to populate the panel.
function PANEL:Populate(player, data)
	self:SetTitle( "DATAPAD: "..player:Name() )
	self:Center()
	self:MakePopup()
	self:ShowCloseButton(false)
	self:SetDeleteOnClose( true )
	
	local ButtonX = vgui.Create( "DButton", self )
	ButtonX:SetText( "" )
	ButtonX:SetPos( 480, 0 )
	ButtonX:SetSize( 20, 20 )
	ButtonX.Paint = function()
		draw.RoundedBox( 0, 0, 0, 20, 20, bigcolor3 )
	end
	ButtonX.DoClick = function()
		gui.EnableScreenClicker(false);
		self:Close();
		Clockwork.option:PlaySound("click");
		LocalPlayer():ConCommand( "cwSay /datapad" )
	end
	
	local textEntry = vgui.Create("DTextEntry", self);
	local button = vgui.Create("DButton", self);
	local x = self:GetWide()/2+70
	
	textEntry:SetMultiline(true);
	textEntry:SetText(data);
	textEntry:SetPos( x, 160 )
	textEntry:SetSize( 300, 346 )	
	
	button:SetText("OKAY");
	button:SetFont("FrameDP")
	button:SetTextColor( Color(0, 0, 0, 255) )
	button:SetPos( x, 542 )
	button:SetSize( 300, 50 )
	button.Paint = function()
		draw.RoundedBox( 0, 0, 0, 515, 50, bigcolor )
	end
	button.OnCursorEntered = function()
		bigcolor = Color( 255, 255, 255, 160 )
	end
	button.OnCursorExited = function()
		bigcolor = Color( 255, 255, 255, 75 )
	end
	
	-- A function to set the text entry's real value.
	function textEntry:SetRealValue(text)
		self:SetValue(text);
		self:SetCaretPos( string.len(text) );
	end;
	
	-- Called each frame.
	function textEntry:Think()
		local text = self:GetValue();
		
		if (string.len(text) > 500) then
			self:SetRealValue( string.sub(text, 0, 5000) );
			
			surface.PlaySound("common/talk.wav");
		end;
	end;
	
	-- Called when the button is clicked.
	function button.DoClick(button)
		self:Close(); self:Remove();
		
		if (IsValid(player)) then
			Clockwork.datastream:Start( "EditData", { player, string.sub(textEntry:GetValue(), 0, 5000) } );
		end;
		
		Clockwork.option:PlaySound("click");
		
		gui.EnableScreenClicker(false);
		
		LocalPlayer():ConCommand( "cwSay /datapad" )
	end;
end;

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	DFrame.PerformLayout(self);
end;

function PANEL:Paint()
	local w = self:GetWide()
	local h = self:GetTall()
	surface.SetDrawColor(255, 255, 255, 255);
	surface.SetMaterial(bgtexture);
    surface.DrawTexturedRect(0,0, w, h);
end

function PANEL:PaintOver()
	local w = self:GetWide()
	local h = self:GetTall()
	surface.SetDrawColor(255, 255, 255, 255);
	texture:SetFloat("$alpha", Lerp( 0.05, .75, 0.75 - math.random( 0, 0.035 ) ));
	surface.SetMaterial(texture);
    surface.DrawTexturedRect(0,0, w, h);
end

vgui.Register("cwData", PANEL, "DFrame");