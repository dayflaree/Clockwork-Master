local PLUGIN = PLUGIN;

PLUGIN.clothes = {
	headgear = {4,{
		cloth_facewrap = 1,
		cloth_gaskmask = 2,
		cloth_beanie = 3
	}},
	
	hands = {3,{
		cloth_gloves = 1
	}},
	
	legs = {2,{
		cloth_grey_pants = 1,
		cloth_jeans = 2,
		cloth_track_pants = 3,
		cloth_black_pants = 6,
		cloth_rebel_pants_green = 4,
		cloth_rebel_pants_blue = 5
	}},
	
	torso = {1,{
		cloth_short_jumpsuit = 1,
		cloth_cwu_shirt = 2,
		cloth_blue_jacket = 4,
		cloth_green_jacket = 5,
		cloth_black_jacket = 6,
		cloth_black_vest = 7,
		cloth_blue_rebel = 8,
		cloth_green_rebel = 9,
		cloth_white_medic = 10,
		cloth_blue_medic = 11,
		cloth_rebel_bag = 12,
		cloth_rebel_ota = 13,
		cloth_rebel_mpf = 14,
		cloth_rebel_molle = 15,
		cloth_wintercoat = 16
	}}
};

function PLUGIN:CanUseHL2TS(player)
	return string.find(player:GetModel(), "citizens/aphelion");
end;

function PLUGIN:UpdateClothBodygroups(player)
	if !self:CanUseHL2TS(player) then
		return;
	end;

	local clothData = cwTS2Model:GetClothData(player);
	for k,v in pairs(self.clothes) do
		if !clothData[k] then
			player:SetBodygroup(v[1],0);
		else
			local bodygroup = 0;
			local item = Clockwork.item:FindInstance(clothData[k].itemID);
			
			if (item and Clockwork.inventory:HasItemInstance(player:GetInventory(), item) and v[2][clothData[k].uniqueID]) then
				bodygroup = v[2][clothData[k].uniqueID];
			end;
			
			player:SetBodygroup(v[1],bodygroup);
		end;
	end;
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	self:UpdateClothBodygroups(player);
end;