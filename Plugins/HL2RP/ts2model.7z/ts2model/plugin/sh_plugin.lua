local PLUGIN = PLUGIN;
PLUGIN:SetGlobalAlias("cwTS2Model");

Clockwork.player:AddCharacterData("TS2Clothes", NWTYPE_STRING, false);
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");

if SERVER then
	function PLUGIN:GetClothData(ply)
		return Clockwork.kernel:Deserialize(ply:GetCharacterData("TS2Clothes"));
	end;
	
	function PLUGIN:SetClothData(ply,data)
		ply:SetCharacterData("TS2Clothes",Clockwork.kernel:Serialize(data));
	end;
else
	function PLUGIN:GetClothData(ply)
		return Clockwork.kernel:Deserialize(ply:GetSharedVar("TS2Clothes"));
	end;
end;

do
	local entityMeta = FindMetaTable("Entity");
	local oldEntityMetaSetModel = entityMeta.SetModel;
	
	function entityMeta:SetModel(model)
		if string.find(model, "=//=", 1, true) then
			local data = string.split(model, "=//=");
			local skin = tonumber(data[2]);
			
			oldEntityMetaSetModel(self, data[1]);

			if (skin) then
				self:SetSkin(skin);
			end;
		else
			oldEntityMetaSetModel(self, model);
		end;
	end;
	
	local oldEntityMetaGetModel = entityMeta.GetModel;
	
	function entityMeta:GetModel()
		local skin = self:GetSkin();
		
		if (skin and skin > 0) then
			return oldEntityMetaGetModel(self).."=//="..skin;
		else
			return oldEntityMetaGetModel(self);
		end;
	end;
	
	function Clockwork.class:GetAppropriateModel(name, player, noSubstitute)
		local defaultModel;
		local class = self:FindByID(name);
		local model;
		local skin;
		
		if (SERVER) then
			defaultModel = player:GetDefaultModel();
		else
			defaultModel = player:GetSharedVar("Model");
		end;
		
		if (class) then
			model, skin = self:GetModelByGender(name, player:GetGender());
			
			if (class.GetModel) then
				model, skin = class:GetModel(player, defaultModel);
			end;
		end;
		
		if (!model and !noSubstitute) then
			model = defaultModel;
		end;
		
		if string.find(model, "=//=", 1, true) then
			local data = string.Split(model, "=//=");
			model = data[1];
			skin = tonumber(data[2]);
		end;
		
		if (!skin and !noSubstitute) then
			skin = 0;
		end;
		
		return model, skin;
	end;
	
	function Clockwork.faction:Register(data, name)
		if (data.models) then
			data.models.female = data.models.female or FACTION_CITIZENS_FEMALE;
			data.models.male = data.models.male or FACTION_CITIZENS_MALE;
		else
			data.models = {
				female = FACTION_CITIZENS_FEMALE,
				male = FACTION_CITIZENS_MALE
			};
		end;
		
		for k, v in pairs(data.models.female) do
			if string.find(v,"=//=",1,true) then
				local data = string.Split(v,"=//=");
				util.PrecacheModel(data[1]);
			else
				util.PrecacheModel(v);
			end;
		end;
		
		for k, v in pairs(data.models.male) do
			if string.find(v, "=//=", 1, true) then
				local data = string.Split(v, "=//=");
				util.PrecacheModel(data[1]);
			else
				util.PrecacheModel(v);
			end;
		end;
		
		data.limit = data.limit or 128;
		data.index = Clockwork.kernel:GetShortCRC(name);
		data.name = data.name or name;
		self.buffer[data.index] = data;
		self.stored[data.name] = data;
		
		if (SERVER) then
			if (data.models) then
				for k, v in pairs(data.models.female) do
					if string.find(v, "=//=", 1, true) then
						local data = string.Split(v, "=//=");
						
						Clockwork.kernel:AddFile(data[1]);
					else
						Clockwork.kernel:AddFile(v);
					end;
				end;
				
				for k, v in pairs(data.models.male) do
					if string.find(v, "=//=", 1, true) then
						local data = string.Split(v, "=//=");
						
						Clockwork.kernel:AddFile(data[1]);
					else
						Clockwork.kernel:AddFile(v);
					end;
				end;
			end;
			
			if (data.material) then
				Clockwork.kernel:AddFile("materials/"..data.material..".png");
			end;
		end;
		
		return data.name;
	end;
end;