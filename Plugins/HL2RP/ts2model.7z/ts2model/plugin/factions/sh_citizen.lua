local FACTION = Clockwork.faction:New("Citizen");
	FACTION.useFullName = true;
	FACTION.material = "halfliferp/factions/citizen";
	FACTION.models = {
		female = {
			"models/tnb/citizens/aphelion/female_11.mdl"
		},
		
		male = {
			"models/tnb/citizens/aphelion/male_16.mdl"
		};
	};

	for i = 1, 2 do
		for j = 0, 3 do
			table.insert(FACTION.models.female,"models/tnb/citizens/aphelion/female_0"..i..".mdl=//="..j);
		end;
	end;
	
	for j = 0, 1 do
		table.insert(FACTION.models.female,"models/tnb/citizens/aphelion/female_03.mdl=//="..j);
	end;
	
	for i = 4, 5 do
		for j = 0, 3 do
			table.insert(FACTION.models.female,"models/tnb/citizens/aphelion/female_0"..i..".mdl=//="..j);
		end;
	end;
	
	for i = 8, 9 do
		for j = 0, 1 do
			table.insert(FACTION.models.female,"models/tnb/citizens/aphelion/female_0"..i..".mdl=//="..j);
		end;
	end;
	
	for i = 1,7 do
		for j = 0,3 do
			table.insert(FACTION.models.male,"models/tnb/citizens/aphelion/male_0"..i..".mdl=//="..j);
		end;
	end;
	
	for j = 0, 3 do
		table.insert(FACTION.models.male,"models/tnb/citizens/aphelion/male_09.mdl=//="..j);
	end;
	
	-- Called when a player is transferred to the faction.
	function FACTION:OnTransferred(player, faction, name)
		if (Schema:PlayerIsCombine(player)) then
			if (name) then
				local models = self.models[ string.lower( player:QueryCharacter("gender") ) ];

				if (models) then
					player:SetCharacterData("model", models[ math.random(#models) ], true);
	
					Clockwork.player:SetName(player, name, true);
				end;
			else
				return false, "You need to specify a name as the third argument!";
			end;
		end;
	end;
	
FACTION_CITIZEN = FACTION:Register();