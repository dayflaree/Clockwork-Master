timer.Simple(1,function()
	local PANEL = vgui.GetControlTable("cwCharacterModel");
	
	function PANEL:SetModel(modelName)
		local skin;
		
		if (string.find(modelName, "=//=", 1, true)) then
			local data = string.split(modelName, "=//=");
			
			modelName = data[1];
			skin = tonumber(data[2]);
		end;

		if (IsValid(self.Entity)) then
			self.Entity:Remove();
			self.Entity = nil;
		end;

		if (!ClientsideModel) then 
			return;
		end;
		
		self.Entity = ClientsideModel(modelName, RENDER_GROUP_OPAQUE_ENTITY);
		
		if (!IsValid(self.Entity)) then 
			return;
		end;
		
		if (skin) then
			self.Entity:SetSkin(skin);
		end;
		
		self.Entity:SetNoDraw(true);
		self.Entity:SetIK(false);
		
		local iSeq = self.Entity:LookupSequence("walk_all");
		
		if (iSeq <= 0) then;
			iSeq = self.Entity:LookupSequence("WalkUnarmed_all");
		end;
		
		if (iSeq <= 0) then;
			iSeq = self.Entity:LookupSequence("walk_all_moderate");
		end;
		
		if (iSeq > 0) then;
			self.Entity:ResetSequence(iSeq);
		end;
	end;
	vgui.Register("cwCharacterModel", PANEL, "DModelPanel");
	
	local PANEL = vgui.GetControlTable("cwSpawnIcon");
	
	function PANEL:SetModel(model, skin, bodygroups)
		if (!model) then 
			debug.Trace();
			
			return;
		end;
		
		if (string.find(model, "=//=", 1, true)) then
			local data = string.split(model, "=//=");
			
			model = data[1];
			skin = tonumber(data[2]);
		end;
		
		if (!skin) then
			skin = 0;
		end;
		
		self:SetModelName(model);
		self:SetSkinID(skin);
		
		if (tostring(bodygroups):len() != 9) then
			bodygroups = "000000000";
		end;
		
		self.m_strBodyGroups = bodygroups;
		self.Icon:SetModel(model, skin, bodygroups);
		
		if (skin && skin > 0) then
			self:SetTooltip(Format("%s (Skin %i)", model, skin + 1));
		else
			self:SetTooltip(Format("%s", model));
		end;
	end;
	
	vgui.Register("cwSpawnIcon", PANEL, "SpawnIcon");
end)