local ITEM = Clockwork.item:New(nil, true);
	ITEM.name = "TS2 Cloth Base";
	ITEM.uniqueID = "ts2cloth_base";
	ITEM.model = "models/gibs/hgibs.mdl";
	ITEM.weight = 0.5;
	ITEM.useText = "Equip";
	ITEM.description = "A base for ts2 items.";
	ITEM.slot = "torso"
	ITEM.category = "Clothing"

	function ITEM:HasPlayerEquipped(player)
		local clothData = cwTS2Model:GetClothData(player);
		
		return clothData[self("slot")] and clothData[self("slot")].itemID == self("itemID");
	end;

	function ITEM:OnUse(player, itemEntity)
		if (player:Alive() and !player:IsRagdolled()) then
			local clothData = cwTS2Model:GetClothData(player);
			
			if (!self:HasPlayerEquipped(player)) then
				clothData[self("slot")] = Clockwork.item:GetSignature(self);
			else
				clothData[self("slot")] = nil;
			end;
			
			cwTS2Model:SetClothData(player, clothData);
			cwTS2Model:UpdateClothBodygroups(player);
			player:RebuildInventory();
		else
			Clockwork.player:Notify(player, "You cannot do this action at the moment!");
		end;
		
		return false;
	end;

	function ITEM:OnPlayerUnequipped(player, extraData)
		if (self:HasPlayerEquipped(player)) then
			local clothData = cwTS2Model:GetClothData(player);
			
			clothData[self("slot")] = nil;
			cwTS2Model:SetClothData(player,clothData);
			cwTS2Model:UpdateClothBodygroups(player);
		end;
		
		player:RebuildInventory();
	end;

	function ITEM:OnStorageTake(player, storageTable)
		if (self:HasPlayerEquipped(player)) then
			local clothData = cwTS2Model:GetClothData(player);
			
			clothData[self("slot")] = nil;
			cwTS2Model:SetClothData(player,clothData);
			cwTS2Model:UpdateClothBodygroups(player);
		end;
		
		player:RebuildInventory();
	end;

	function ITEM:OnStorageGive(player, storageTable)
		if (self:HasPlayerEquipped(player)) then
			local clothData = cwTS2Model:GetClothData(player);
			
			clothData[self("slot")] = nil;
			cwTS2Model:SetClothData(player,clothData);
			cwTS2Model:UpdateClothBodygroups(player);
		end;
		
		player:RebuildInventory();
	end;

	function ITEM:OnDrop(player, position)
		if (self:HasPlayerEquipped(player)) then
			local clothData = cwTS2Model:GetClothData(player);
			clothData[self("slot")] = nil;
			cwTS2Model:SetClothData(player,clothData);
			cwTS2Model:UpdateClothBodygroups(player);
		end;
		
		player:RebuildInventory();
	end;

Clockwork.item:Register(ITEM);