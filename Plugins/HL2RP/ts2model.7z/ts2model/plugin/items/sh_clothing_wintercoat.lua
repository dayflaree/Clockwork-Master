local ITEM = Clockwork.item:New("ts2cloth_base");
	ITEM.name = "Wintercoat";
	ITEM.uniqueID = "cloth_wintercoat";
	ITEM.model = "models/tnb/items/aphelion/wintercoat.mdl";
	ITEM.weight = 1;
	ITEM.description = "A thick and warm coat.";
	ITEM.slot = "torso"
Clockwork.item:Register(ITEM);