local CLASS = Clockwork.class:New("Civil Worker's Union");

CLASS.color = Color(238, 180, 34, 255);
CLASS.factions = {FACTION_CWU};
CLASS.isDefault = true;
CLASS.wagesName = "Wages";
CLASS.description = "A citizen that's part of the CWU.";
CLASS.defaultPhysDesc = "A citizen with a yellow jumpsuit, and a CWU armband.";
	
CLASS_CWU = CLASS:Register();