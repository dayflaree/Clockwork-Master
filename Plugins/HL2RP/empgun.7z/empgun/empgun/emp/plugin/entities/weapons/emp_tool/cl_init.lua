
include('shared.lua')

function SWEP:SetWeaponHoldType( t )
	// Just a fake function so we can define 
	// weapon holds in shared files without errors
end