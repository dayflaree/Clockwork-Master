Place the folder INSIDE of the 	"game-server(You put this on your clockwork server)" folder into your HL2RP plugins
There will be a new setting in your clockwork system area for to change, called "Logger URL" see here http://puu.sh/4TaEq.png
