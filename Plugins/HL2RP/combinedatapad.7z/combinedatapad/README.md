Images
https://raw.githubusercontent.com/trurascalz/clockworkpluginimages/master/hl2rp/combinereport.png
