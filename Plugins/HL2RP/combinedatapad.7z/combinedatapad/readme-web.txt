This is for the web portion. Navigate to your clockwork database, more than likley you will use phpMyadmin.
When in the database click the Import tab, upload both sql files. If you cannot for some reason upload files, open them then copy the SQL function.

!!!You do not need a seperate database! This will use the clockwork database!!!

Upload the web files to a accessible webspace, maybe hidden if you want.
Edit include/config.php with your MYSQL info.