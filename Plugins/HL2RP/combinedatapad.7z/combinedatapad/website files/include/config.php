<?php
//////////////
// SECURITY //
//////////////

///////////////////
//    Global     //
// Configuration //
///////////////////
//    Database   //
// Configuration //
///////////////////

$address = "localhost";
$user = "user";
$pass = "pass";
$database = "clockworkfull";


///////////////////
//     Other     //
// Configuration //
///////////////////
$zone = "Europe/London"; // http://php.net/manual/en/timezones.php
$debug = 0;
## This is Case Sensitive! These are people who can review the reports.
$highranks = array('sec', 'dvl', 'cmd', 'epu', "DvL");

// ▼▼▼▼▼▼▼▼▼▼▼ MUST BE SET!
$apikey ="";  // Visit http://steamcommunity.com/dev !!!! THIS IS A MUST TO CONFIGURE !!!!
// ▲▲▲▲▲▲▲▲▲▲▲ MUST BE SET!



?>