--[[
 Â© 2012 CloudSixteen.com do not share, re-distribute or modify
 without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Union Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 750;
ITEM.weight = 5;
ITEM.business = true;
ITEM.access = "L";
ITEM.useText = "Wear";
ITEM.category = "Clothing";
ITEM.protection = 0.3;
ITEM.replacement = "models/hl2beta_police.mdl";
ITEM.description = "A Civil Protection uniform bearing the 'Union' insignia.";

ITEM:Register();
