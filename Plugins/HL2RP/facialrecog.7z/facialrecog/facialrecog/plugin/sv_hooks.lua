local PLUGIN = PLUGIN;

function PLUGIN:PlayerCharacterLoaded( ply )
	for k, v in pairs( player.GetAll() ) do
		local info = {}
		info[v:EntIndex()] = v:GetCharacterData("citizenid")
		net.Start( "cw_getcids" )
		net.WriteTable( info )
		net.Broadcast()
	end
end
