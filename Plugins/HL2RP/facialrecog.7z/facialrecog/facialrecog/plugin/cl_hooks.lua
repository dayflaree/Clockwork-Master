
-----------------------------------------------------
-- cvars
CreateClientConVar("cw_facialrecog_on", 0, true, false)
CreateClientConVar("cw_facialrecog_range", 256, true, false)

function PLUGIN:Initialize()
	CW_CONVAR_FACIALRECOG = Clockwork.kernel:CreateClientConVar("cwFacialRecog", 0, false, true)
	CW_CONVAR_FACIALRECOG_RANGE = Clockwork.kernel:CreateClientConVar("cwFacialRecogRange", 256, false, true)
end

function PLUGIN:ClockworkConVarChanged()
	RunConsoleCommand("cw_facialrecog_on", tostring(CW_CONVAR_FACIALRECOG:GetInt()))
	RunConsoleCommand("cw_facialrecog_range", tostring(CW_CONVAR_FACIALRECOG_RANGE:GetInt()))
end

Clockwork.setting:AddCheckBox("Facial recognition", "Facial recognition enabled", "cwFacialRecog", "Enable facial recognition for non-combines.", function()
	if LocalPlayer():GetFaction() == FACTION_OTA and LocalPlayer():HasInitialized() then
		return true
	elseif LocalPlayer():GetFaction() == FACTION_MPF and LocalPlayer():HasInitialized() then
		return true
	end
	return false
end)
Clockwork.setting:AddNumberSlider("Facial recognition", "Facial recognition range", "cwFacialRecogRange", 128, 384, 0, "Distance to a person before facial recognition starts.", function()
	if LocalPlayer():GetFaction() == FACTION_OTA and LocalPlayer():HasInitialized() then
		return true
	elseif LocalPlayer():GetFaction() == FACTION_MPF and LocalPlayer():HasInitialized() then
		return true
	end
	return false
end)

-- hud

local alphas = {}
local sizes = {}
local str_lens = {}
local cids = {}
local no_recog_models = {
	"models/dpfilms/metropolice/elite_police.mdl",
	"models/dpfilms/metropolice/hdpolice.mdl",
	"models/dpfilms/metropolice/policetrench.mdl",
	"models/leet_police2.mdl",
	"models/eliteshockcp.mdl",
	"models/eliteghostcp.mdl",
	"models/policetrench.mdl",
	"models/sect_police2.mdl",
	"models/Police.mdl",
	"models/dpfilms/metropolice/hl2concept.mdl",
	"models/tactical_rebel.mdl",
	"models/tactical_rebel_coat.mdl",
	"models/tactical_rebel_female.mdl",
	"models/barnes/refugee/male_12.mdl",
	"models/barnes/refugee/male_13.mdl",
	"models/humans/group03/coalition_female.mdl",
	"models/humans/group03/coalition_male.mdl",
	"models/humans/group03/male_111.mdl",
	"models/humans/group03/male_79.mdl",
	"models/humans/group03/suit_gh.mdl",
	"models/humans/group03/male_118.mdl",
	"models/lambdamovement.mdl",
	"models/lambdamovement_coat.mdl",
	"models/lambdamovement_female.mdl",
	"models/citizen_17.mdl"
}

local function cw_getcids()
	cids = net.ReadTable()
end
net.Receive("cw_getcids", cw_getcids)

local function MatrixText(text, font, x, y, color, scale, rotation)
	surface.SetFont(font)

	local matrix = Matrix()
	matrix:Translate(Vector(x, y, 1))
	matrix:Scale(scale or Vector(1, 1, 1))
	matrix:Rotate(rotation or Angle(0, 0, 0))

	cam.PushModelMatrix(matrix)
		surface.SetTextPos(0, 0)
		surface.SetTextColor(color.r, color.g, color.b, color.a)
		surface.DrawText(text)
	cam.PopModelMatrix()
end

surface.CreateFont("FaceRecog", {
	font = "Default",
	size = 120,
	antialias = true
})

function PLUGIN:HUDPaint()
	if LocalPlayer():GetFaction() ~= FACTION_MPF and LocalPlayer():GetFaction() ~= FACTION_OTA then return end

	for k,v in pairs( player.GetAll() ) do
		-- we can't see the faces of MPF/OTA
		if v ~= LocalPlayer() and v:GetFaction() ~= FACTION_MPF and v:GetFaction() ~= FACTION_OTA then
			if table.HasValue(no_recog_models, v:GetModel()) then return end

			if not alphas[v:EntIndex()] then alphas[v:EntIndex()] = 0 end
			if not sizes[v:EntIndex()] then sizes[v:EntIndex()] = 100 end
			if not str_lens[v:EntIndex()] then str_lens[v:EntIndex()] = 0 end

			local head = v:LookupBone("ValveBiped.Bip01_Head1")
			local headpos
			local headposP
			if head then
				headposP = v:GetBonePosition(head)
				headpos = v:GetBonePosition(head):ToScreen()
			else
				headposP = v:EyePos()
				headpos = v:EyePos():ToScreen()
			end

			-- scale stuff properly with distance
			local size = sizes[v:EntIndex()]
			local scale = v:GetPos():Distance(LocalPlayer():GetPos())/384
			size = size / scale

			local name = v:Name()
			surface.SetFont("FaceRecog")
			local ns_x, ns_y = surface.GetTextSize(name)

			local range = math.Clamp(GetConVarNumber("cw_facialrecog_range"), 128, 384)
			local recog_on = GetConVarNumber("cw_facialrecog_on") == 1

			-- check if the player is in range, that their face is visible and that they're alive. and, of course, if facial recog is turned on.
			local tr = util.TraceLine({
				start = EyePos(),
				endpos = headposP,
				mask = MASK_VISIBLE_AND_NPCS,
				filter = {LocalPlayer(),v}
			})

			if v:GetPos():Distance(LocalPlayer():GetPos()) <= range and v:Alive() and v:GetAimVector():Dot(LocalPlayer():GetAimVector()) < 0 and recog_on and !tr.Hit then
				-- if yes, make magic with alphas, sizes, etc.
				alphas[v:EntIndex()] = Lerp(FrameTime()*5, alphas[v:EntIndex()], 255)
				sizes[v:EntIndex()] = Lerp(FrameTime()*5, sizes[v:EntIndex()], 20)

				local str_len_mul = 6
				if sizes[v:EntIndex()] < 40 then
					str_len_mul = 50
				end

				str_lens[v:EntIndex()] = Lerp(FrameTime()*str_len_mul, str_lens[v:EntIndex()], ns_x)
			else
				alphas[v:EntIndex()] = Lerp(FrameTime()*10, alphas[v:EntIndex()], 0)
				sizes[v:EntIndex()] = Lerp(FrameTime()*10, sizes[v:EntIndex()], 80)
				str_lens[v:EntIndex()] = Lerp(FrameTime()*10, str_lens[v:EntIndex()], 0)
			end

			-- draw the box/line
			surface.SetDrawColor(255, 255, 255, alphas[v:EntIndex()])
			surface.DrawOutlinedRect(headpos.x - size/2, headpos.y - size/2, size, size)

			-- draw the name in their team color (citizens brown, admins yellow, etc.)
			local team_color = _team.GetColor(v:Team())
			local cid = "N/A"
			if cids[v:EntIndex()] then
				cid = cids[v:EntIndex()]
			end
			local gender = v:GetGender() == GENDER_MALE and "Male" or "Female"

			local name_size = 0.075
			
			-- Check for mask bodygroups.
			if (v:GetBodygroup(4) == 1 or v:GetBodygroup(4) == 2) then
				name = "ERROR"
				cid = "N/A"
			end
			
			-- draw text
			MatrixText(name, "FaceRecog", headpos.x + size/1.9, headpos.y-size*0.9, Color(team_color.r, team_color.g, team_color.b, alphas[v:EntIndex()]), Vector(name_size/scale, name_size/scale, 1))
			-- scaling with random numbers sure is fun
			MatrixText("Gender: "..gender, "FaceRecog", headpos.x + size/1.9, headpos.y-size/2, Color(255, 255, 255, alphas[v:EntIndex()]), Vector(0.05/scale, 0.05/scale, 1))
			MatrixText("CID: "..cid, "FaceRecog", headpos.x + size/1.9, headpos.y-size/4, Color(255, 255, 255, alphas[v:EntIndex()]), Vector(0.05/scale, 0.05/scale, 1))

			local line_matrix = Matrix()
			line_matrix:Translate(Vector(headpos.x + size/1.9, headpos.y-size/2, 0))
			line_matrix:Scale(Vector(name_size/scale, 1, 1))

			cam.PushModelMatrix(line_matrix)
				surface.DrawOutlinedRect(0, 0, str_lens[v:EntIndex()], 1)
			cam.PopModelMatrix()
		end
	end
end