
-----------------------------------------------------
Clockwork.kernel:IncludePrefixed("cl_hooks.lua")
Clockwork.kernel:IncludePrefixed("sv_hooks.lua")

if SERVER then
	util.AddNetworkString("cw_getcombinedata")
	util.AddNetworkString("cw_getcids")

	local function cw_getcombinedata()
		local info = net.ReadTable()
		local sender = info.sender
		local subj = info.subj

		local recordData
		local recordText
		local aID = subj:GetCharacterData("currentego", 0)
		if Schema:PlayerIsCombine(subj) then
			recordData = subj:GetCharacterData("criminalRecordmpf", {})
			recordText = subj:GetCharacterData("combinedatampf", "")
		elseif aID == 0 then
			recordData = subj:GetCharacterData("criminalRecord", {})
			recordText = subj:GetCharacterData("combinedata", "")
		else
			recordData = subj:GetCharacterData("criminalRecord"..aID, {})
			recordText = subj:GetCharacterData("combinedata"..aID, "")
		end
		Clockwork.datastream:Start( sender, "EditData", { subj, subj:GetCharacterData("citizenid", ""), {text = recordText, criminalRecord = recordData}});
		
		sender.editDataAuthorised = subj;
	end
	net.Receive("cw_getcombinedata", cw_getcombinedata)
end