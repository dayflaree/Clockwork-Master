local PLUGIN = PLUGIN;

-- Called when a player's weapons should be given.
function Schema:PlayerGiveWeapons(player)
	-- Override
end;