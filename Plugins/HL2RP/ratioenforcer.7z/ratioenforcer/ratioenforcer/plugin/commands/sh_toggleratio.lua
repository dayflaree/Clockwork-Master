local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("ToggleRatio");
COMMAND.tip = "Toggle whether or not the ratio is enforced.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local ratio = Clockwork.config:Get("enforce_ratio");
	local status = ratio:Get();

	if (status) then
		ratio:Set(false);
		Clockwork.player:NotifyAll(player:Name().." has disabled the ratio enforcer.");

		return;
	end;

	ratio:Set(true);
	Clockwork.player:NotifyAll(player:Name().." has enabled the ratio enforcer.");
end;

COMMAND:Register();