local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

if (CLIENT) then
    Clockwork.config:AddToSystem("Enforce ratio", "enforce_ratio", "Whether or not the Metropolice Force to Citizens ratio should be enforced.");

    return;
end;

Clockwork.config:Add("enforce_ratio", true);

-- Called when a player attempts to use a character.
function PLUGIN:PlayerCanUseCharacter(player, character)
    if (character.faction == FACTION_MPF and Clockwork.config:Get("enforce_ratio"):Get()) then
        local MPF = Clockwork.faction:GetPlayers(FACTION_MPF);
        local citizens = #Clockwork.faction:GetPlayers(FACTION_CITIZEN);

        for k, v in pairs(MPF) do
            if (v:Name():find("RCT")) then
                MPF[k] = nil;
            end;
        end;

        MPF = #MPF;

        if (MPF > 5 and citizens / 2 <= MPF) then
            return "The ratio of officers to citizens is out of balance!";
        end;
    end;
end;

