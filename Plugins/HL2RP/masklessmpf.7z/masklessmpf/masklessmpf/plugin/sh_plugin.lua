local PLUGIN = PLUGIN

Clockwork.player:AddCharacterData("MPFMask", NWTYPE_BOOL, false);
/*
Clockwork.animation:AddCivilProtectionModel("models/police/c18_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/c18_police_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/c18_police_"..v.."_0"..i..".mdl");
  end
end
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/commander/c18_police_cmd.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/commander/c18_police_cmd_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/commander/c18_police_cmd_"..v.."_0"..i..".mdl");
  end
end
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/divisional/c18_police_dvl.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/divisional/c18_police_dvl_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/divisional/c18_police_dvl_"..v.."_0"..i..".mdl");
  end
end
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/elite/c18_police_epu.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/elite/c18_police_epu_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/elite/c18_police_epu_"..v.."_0"..i..".mdl");
  end
end
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/sectorial/c18_police_sec.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/sectorial/c18_police_sec_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/highcommand/sectorial/c18_police_sec_"..v.."_0"..i..".mdl");
  end
end
Clockwork.animation:AddCivilProtectionModel("models/police/trenchcoat/c18_trenchcoat_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/police/trenchcoat/c18_trenchcoat_police_female.mdl");
for _,v in pairs({"male","female"}) do
  for i=1,9 do
    Clockwork.animation:AddCivilProtectionModel("models/police/trenchcoat/c18_trenchcoat_police_"..v.."_0"..i..".mdl");
  end
end*/
if SERVER then
  function Schema:PlayerIsCombine(player, bHuman, maskCheck)
    if (IsValid(player) and player:GetCharacter()) then
      if maskCheck then
        return player:GetCharacterData("MPFMask",false)
      end

      local faction = player:GetFaction();

      if (self:IsCombineFaction(faction)) then
        if (bHuman) then
          if (faction == FACTION_MPF) then
            return true;
          end;
        elseif (bHuman == false) then
          if (faction == FACTION_MPF) then
            return false;
          else
            return true;
          end;
        else
          return true;
        end;
      end;
    end
  end;
else
  function Schema:PlayerIsCombine(player, bHuman, maskCheck)
    if (!IsValid(player)) then
      return;
    end;
    if maskCheck then
      return player:GetSharedVar("MPFMask")
    end
    local faction = player:GetFaction();

    if (self:IsCombineFaction(faction)) then
      if (bHuman) then
        if (faction == FACTION_MPF) then
          return true;
        end;
      elseif (bHuman == false) then
        if (faction == FACTION_MPF) then
          return false;
        else
          return true;
        end;
      else
        return true;
      end;
    end;
  end;
end

if SERVER then
  function Schema:PlayerNameChanged(player, previousName, newName)
    if (self:PlayerIsCombine(player)) then
      local faction = player:GetFaction();

      if (faction == FACTION_OTA) then
        if (!self:IsStringCombineRank(previousName, "OWS") and self:IsStringCombineRank(newName, "OWS")) then
          Clockwork.class:Set(player, CLASS_OWS);
        elseif (!self:IsStringCombineRank(previousName, "EOW") and self:IsStringCombineRank(newName, "EOW")) then
          Clockwork.class:Set(player, CLASS_EOW);
        end;
      elseif (faction == FACTION_MPF) then
        if (!self:IsStringCombineRank(previousName, "SCN") and self:IsStringCombineRank(newName, "SCN")) then
          Clockwork.class:Set(player, CLASS_MPS, true);

          self:MakePlayerScanner(player, true);
        elseif (!self:IsStringCombineRank(previousName, "RCT") and self:IsStringCombineRank(newName, "RCT")) then
          Clockwork.class:Set(player, CLASS_MPR);
        elseif (!self:IsStringCombineRank(previousName, "EpU") and self:IsStringCombineRank(newName, "EpU")) then
          Clockwork.class:Set(player, CLASS_EMP);
        elseif (!self:IsStringCombineRank(newName, "RCT")) then
          if (player:Team() != CLASS_MPU) then
            Clockwork.class:Set(player, CLASS_MPU);
          end;
        end;

      end;
    end;
  end;

  function Schema:PlayerAdjustCharacterScreenInfo(player, character, info)
    if (character.data["permakilled"]) then
      info.details = "This character is permanently killed.";
    end;

    if (info.faction == FACTION_OTA) then
      if (self:IsStringCombineRank(info.name, "EOW")) then
        info.model = "models/combine_super_soldier.mdl";
      end;
    elseif (self:IsCombineFaction(info.faction)) then
      if (self:IsStringCombineRank(info.name, "SCN")) then
        if (self:IsStringCombineRank(info.name, "SYNTH")) then
          info.model = "models/shield_scanner.mdl";
        else
          info.model = "models/combine_scanner.mdl";
        end;
      end;
    end

    if (character.data["customclass"]) then
      info.customClass = character.data["customclass"];
    end;
  end;

  function Schema:GetPlayerDefaultModel(player)

  end;
  function Schema:PlayerStartTypingDisplay(player, code)
    if (Schema:PlayerIsCombine(player,false,true) and !player:IsNoClipping()) then
      if (code == "n" or code == "y" or code == "w" or code == "r") then
        if (!player.typingBeep) then
          player.typingBeep = true;

          player:EmitSound("npc/overwatch/radiovoice/on1.wav");
        end;
      end;
    end;
  end;

  -- Called when a player's typing display has finished.
  function Schema:PlayerFinishTypingDisplay(player, textTyped)
    if (Schema:PlayerIsCombine(player,false,true) and textTyped) then
      if (player.typingBeep) then
        player:EmitSound("npc/overwatch/radiovoice/off4.wav");
      end;
    end;

    player.typingBeep = nil;
  end;

  function Schema:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
    if (self:PlayerIsCombine(player,false,true)) then
      return "npc/metropolice/pain"..math.random(1, 4)..".wav";
    end;
  end;

  function Schema:ChatBoxAdjustInfo(info)
    if (info.class != "ooc" and info.class != "looc") then
      if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
        if (string.sub(info.text, 1, 1) == "?") then
          info.text = string.sub(info.text, 2);
          info.data.anon = true;
        end;
      end;
    end;

    if (info.class == "ic" or info.class == "yell" or info.class == "radio" or info.class == "whisper" or info.class == "request") then
      if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
        local playerIsCombine = self:PlayerIsCombine(info.speaker,false,true);

        if (self:PlayerIsCombine(info.speaker) and self:IsPlayerCombineRank(info.speaker, "SCN")) then
          for k, v in pairs(self.voices.stored.dispatchVoices) do
            if (string.lower(info.text) == string.lower(v.command)) then
              local voice = {
                global = false,
                volume = 90,
                sound = v.sound
              };

              if (info.class == "request" or info.class == "radio") then
                voice.global = true;
              elseif (info.class == "whisper") then
                voice.volume = 80;
              elseif (info.class == "yell") then
                voice.volume = 100;
              end;

              info.text = "<:: "..v.phrase;
              info.voice = voice;

              return true;
            end;
          end;
        else
          for k, v in pairs(self.voices.stored.normalVoices) do
            if ((v.faction == "Combine" and playerIsCombine) or (v.faction == "Human" and !playerIsCombine)) then
              if (string.lower(info.text) == string.lower(v.command)) then
                local voice = {
                  global = false,
                  volume = 80,
                  sound = v.sound
                };

                if (v.female and info.speaker:QueryCharacter("gender") == GENDER_FEMALE) then
                  voice.sound = string.Replace(voice.sound, "/male", "/female");
                end;

                if (info.class == "request" or info.class == "radio") then
                  voice.global = true;
                elseif (info.class == "whisper") then
                  voice.volume = 60;
                elseif (info.class == "yell") then
                  voice.volume = 100;
                end;

                if (playerIsCombine) then
                  info.text = "<:: "..v.phrase;
                else
                  info.text = v.phrase;
                end;

                info.voice = voice;

                return true;
              end;
            end;
          end;
        end;

        if (playerIsCombine) then
          if (string.sub(info.text, 1, 4) != "<:: ") then
            info.text = "<:: "..info.text;
          end;
        end;
      end;
    elseif (info.class == "dispatch") then
      for k, v in pairs(self.voices.stored.dispatchVoices) do
        if (string.lower(info.text) == string.lower(v.command)) then
          Clockwork.player:PlaySound(nil, v.sound);

          info.text = v.phrase;

          return true;
        end;
      end;
    end;
  end;
else
  function Schema:RenderScreenspaceEffects()
    if (!Clockwork.kernel:IsScreenFadedBlack()) then
      local curTime = CurTime();

      if (self.flashEffect) then
        local timeLeft = math.Clamp( self.flashEffect[1] - curTime, 0, self.flashEffect[2] );
        local incrementer = 1 / self.flashEffect[2];

        if (timeLeft > 0) then
          modify = {};

          modify["$pp_colour_brightness"] = 0;
          modify["$pp_colour_contrast"] = 1 + (timeLeft * incrementer);
          modify["$pp_colour_colour"] = 1 - (incrementer * timeLeft);
          modify["$pp_colour_addr"] = incrementer * timeLeft;
          modify["$pp_colour_addg"] = 0;
          modify["$pp_colour_addb"] = 0;
          modify["$pp_colour_mulr"] = 1;
          modify["$pp_colour_mulg"] = 0;
          modify["$pp_colour_mulb"] = 0;

          DrawColorModify(modify);

          if (!self.flashEffect[3]) then
            DrawMotionBlur( 1 - (incrementer * timeLeft), incrementer * timeLeft, self.flashEffect[2] );
          end;
        end;
      end;

      if (self:PlayerIsCombine(Clockwork.Client,false,true)) then
        render.UpdateScreenEffectTexture();

        self.combineOverlay:SetFloat("$refractamount", 0.3);
        self.combineOverlay:SetFloat("$envmaptint", 0);
        self.combineOverlay:SetFloat("$envmap", 0);
        self.combineOverlay:SetFloat("$alpha", 0.5);
        self.combineOverlay:SetInt("$ignorez", 1);

        render.SetMaterial(self.combineOverlay);
        render.DrawScreenQuad();
      end;
    end;
  end;

  function Schema:PlayerCanZoom()
    if (!self:PlayerIsCombine(Clockwork.Client,false,true)) then
      return false;
    end;
  end;

  function Schema:HUDPaintTopScreen(info)
    local blackFadeAlpha = Clockwork.kernel:GetBlackFadeAlpha();
    local colorWhite = Clockwork.option:GetColor("white");
    local curTime = CurTime();

    if (self:PlayerIsCombine(Clockwork.Client,false,true) and self.combineDisplayLines) then
      local height = draw.GetFontHeight("BudgetLabel");

      for k, v in ipairs(self.combineDisplayLines) do
        if (curTime >= v[2]) then
          table.remove(self.combineDisplayLines, k);
        else
          local color = v[4] or colorWhite;
          local textColor = Color(color.r, color.g, color.b, 255 - blackFadeAlpha);

          draw.SimpleText(string.sub( v[1], 1, v[3] ), "BudgetLabel", info.x, info.y, textColor);

          if (v[3] < string.len( v[1] )) then
            v[3] = v[3] + 1;
          end;

          info.y = info.y + height;
        end;
      end;
    end;
  end;
end

if CLIENT then
	function Schema:PlayerDoesRecognisePlayer(player, status, isAccurate, realValue)
		if ((self:PlayerIsCombine(LocalPlayer()) and self:PlayerIsCombine(player)) or player:GetFaction() == FACTION_ADMIN) then
			return true;
		end;
	end;
else
	function Schema:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
		if ((self:PlayerIsCombine(target) and self:PlayerIsCombine(player)) or target:GetFaction() == FACTION_ADMIN) then
			return true;
		end;
	end;
end