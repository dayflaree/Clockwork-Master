local COMMAND = Clockwork.command:New("ToggleMask");
COMMAND.tip = "Toggle the mask on your head.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
  local model = player:GetModel()
	if string.find(model,"c18_police") then
    if !player:GetCharacterData("MPFMask",false) and string.find(model,"female_",1,tre) then
      player:SetCharacterData("MPFMaskModel",model)
      local model = string.Left(model,string.len(model)-7)..".mdl"
      player:SetCharacterData("Model", model, true);
		  player:SetModel(model);
      Clockwork.player:Notify(player, "MASK ONLINE!");
      player:SetCharacterData("MPFMask",true)
      return
    elseif !player:GetCharacterData("MPFMask",false) and string.find(model,"male_") then
      player:SetCharacterData("MPFMaskModel",model)
      local model = string.Left(model,string.len(model)-12)..".mdl"
      player:SetCharacterData("Model", model, true);
		  player:SetModel(model);
      Clockwork.player:Notify(player, "MASK ONLINE!");
      player:SetCharacterData("MPFMask",true)
      return
    elseif player:GetCharacterData("MPFMask",false) and player:GetCharacterData("MPFMaskModel",false) then
      player:SetCharacterData("Model", player:GetCharacterData("MPFMaskModel",false), true);
		  player:SetModel(player:GetCharacterData("MPFMaskModel",false));
      Clockwork.player:Notify(player, "MASK OFFLINE!");
      player:SetCharacterData("MPFMask",false)
      return
    end
  end
  Clockwork.player:Notify(player, "You can't toggle your mask!");
end;

COMMAND:Register();
