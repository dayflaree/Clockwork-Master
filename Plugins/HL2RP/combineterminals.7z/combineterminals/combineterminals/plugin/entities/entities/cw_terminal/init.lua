--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Terminal by Rocket
	tbhl2roleplay@gmail.com
	/id/dejectedrocket
--]]

include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

-- Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/props_combine/combine_intmonitor001.mdl");
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
end

-- Called when the entity is spawned.
function ENT:SpawnFunction( ply, tr )
    if ( !tr.Hit ) then return end
    local ent = ents.Create("cw_terminal")
    ent:SetPos( tr.HitPos + tr.HitNormal * 16 )
    ent:Spawn()

    return ent
end


-- Called when the entity is used.
function ENT:Use(activator, caller)
	activator:SendLua("gui.OpenURL('YOUR URL HERE')")
end;

ents.Create("prop_physics")

function ENT:OnRemove()
end

function ENT:Think()
end