--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Terminal by Rocket
	tbhl2roleplay@gmail.com
	/id/dejectedrocket
--]]

DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "Rocket";
ENT.PrintName = "Terminal";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;