--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Terminal by Rocket
	tbhl2roleplay@gmail.com
	/id/dejectedrocket
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
