--[[
	� 2013 TheGarry =D
    Have fun with this plugin.
--]]

local COMMAND = Clockwork.command:New("CEset")
COMMAND.tip = "Sets a player's CE points.";
COMMAND.text = "<string Name> <number>";
COMMAND.arguments = 2;
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	local number = tonumber( arguments[2] )
	local name = target:Name()
	
	if( target and number )then
		if (Schema:PlayerIsCombine(player)) then
			target:SetCharacterData( "cePoints", tostring( number ) )
			Clockwork.chatBox:SendColored(player, Color(255,255,0),[[ CE Points ]],Color(255,255,255), name.." | "..number)
			player:SendLua("surface.PlaySound( \"ambient/machines/keyboard7_clicks_enter.wav\" )")
			Clockwork.chatBox:SendColored(target, Color(255,255,0),[[ CE Points ]],Color(255,255,255), name.." | "..number)
			target:SendLua("surface.PlaySound( \"ambient/machines/keyboard7_clicks_enter.wav\" )")
		else
			Clockwork.player:Notify(player, "You are not a part of the Combine!");
		end
	end
end

COMMAND:Register();