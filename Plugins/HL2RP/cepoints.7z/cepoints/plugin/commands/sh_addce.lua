--[[
	� 2013 TheGarry =D
    Have fun with this plugin.
--]]

local COMMAND = Clockwork.command:New("CEadd")
COMMAND.tip = "Adds to a players CE points.";
COMMAND.text = "<string Name> <number>";
COMMAND.optionalArguments = 2;
COMMAND.arguments = 1;
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	local number = tonumber( arguments[2] ) or 1
	local cePoints = tonumber( target:GetCharacterData("cePoints") )
	local name = target:Name()
    
	if( target and number )then
		if (Schema:PlayerIsCombine(player)) then
			cePoints = cePoints + number
			target:SetCharacterData( "cePoints", tostring( cePoints ) )
			Clockwork.chatBox:SendColored(player, Color(255,255,0),[[ CE Points ]],Color(255,255,255), name.." | "..cePoints)
			player:SendLua("surface.PlaySound( \"ambient/machines/keyboard7_clicks_enter.wav\" )")
			Clockwork.chatBox:SendColored(target, Color(255,255,0),[[ CE Points ]],Color(255,255,255), name.." | "..cePoints)
			target:SendLua("surface.PlaySound( \"ambient/machines/keyboard7_clicks_enter.wav\" )")
		else
			Clockwork.player:Notify(player, "You are not a part of the Combine!");
		end
	end
end

COMMAND:Register();