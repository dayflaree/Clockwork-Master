--[[
	� 2013 TheGarry =D
    Have fun with this plugin.
--]]

local COMMAND = Clockwork.command:New("CEview")
COMMAND.tip = "Views a character's CE points, by default views your own.";
COMMAND.text = "<string Name>";
COMMAND.optionalArguments = 1;
COMMAND.flags = CMD_DEFAULT

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)

	local target;
	if arguments[1] then
		target = Clockwork.player:FindByID(arguments[1])
	else
		target = player
	end
    
	if( target )then
		local cePoints = target:GetCharacterData("cePoints");
		local name = target:Name()
	
		if (Schema:PlayerIsCombine(player)) then
			if (Schema:PlayerIsCombine(target)) then
				Clockwork.chatBox:SendColored(player, Color(255,255,0),[[ CE Points ]],Color(255,255,255), name.." | "..cePoints)
				player:SendLua("surface.PlaySound( \"ambient/machines/keyboard7_clicks_enter.wav\" )")
			else
				Clockwork.player:Notify(player, "That character is not combine!");
			end
		else
			Clockwork.player:Notify(player, "You are not a part of the Combine!");
		end
	else
		Clockwork.player:Notify(player, "Player not found!");
	end
end

COMMAND:Register();