local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");

function PLUGIN:Initialize()
end;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number( "cePoints", 0 );
end