Thumbs up for optimization! :D

===HOW TO ENABLE===
1. While in-game, navigate to: System -> Manage Config

2. a) Enable "CP identities hidden."
b) Modify "CP identity length" to the desired length of CP IDs. (Default=5)

3. Restart the server.

===IMPORTANT===
Every change to the above config(s) requires a server restart for settings to apply.