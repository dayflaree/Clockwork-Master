local PLUGIN = PLUGIN;

Clockwork.config:Add("cp_id_length", 5, true, nil, nil, nil, true);
Clockwork.config:Add("hide_cp_identities", true, true, nil, nil, nil, true);