if (SERVER) then
	AddCSLuaFile()
end

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Antlion Burrow"
ENT.Category		= "Other"
ENT.Spawnable		= false
ENT.AdminOnly		= false
ENT.Model			= Model("models/props_debris/concrete_floorpile01a.mdl")
ENT.RenderGroup 	= RENDERGROUP_BOTH

if (SERVER) then

	local function ApproachVector(startVec, endVec, amount)
		local tempVec = startVec;

		tempVec.x = math.Approach(tempVec.x, endVec.x, amount);
		tempVec.y = math.Approach(tempVec.y, endVec.y, amount);
		tempVec.z = math.Approach(tempVec.z, endVec.z, amount);

		return tempVec;
	end;

	function ENT:SetupDataTables()
		self:NetworkVar("Vector", 0, "CutPos");
		self:NetworkVar("Vector", 1, "CutNormal");
	end;

	function ENT:Initialize()
		self:SetModel(self.Model)
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMaterial("models/props_wasteland/dirtwall001a");
		self:DrawShadow(false);
		self:SetNotSolid(true);

		local phys = self:GetPhysicsObject()
		phys:EnableMotion(false);

		self:SetCutPos(self:GetPos() - self:GetUp() * 1.5);
		self:SetCutNormal(self:GetUp());
	end;

	function ENT:Rise()
		self.goalPos = self:GetPos();
		self:SetPos(self:GetPos() - self:GetUp() * 20);
		self.rising = true;
	end;

	function ENT:Sink(delay)
		timer.Simple(delay or 5, function()
			if (IsValid(self)) then
				self.sinking = true;
				self.deleteDelay = CurTime() + 2;
			end;
		end);
	end;

	function ENT:Think()
		if (self.sinking) then
			self:SetPos(self:GetPos() - self:GetUp() * 0.2);
			if (CurTime() >= self.deleteDelay) then
				SafeRemoveEntity(self);
			end;

			self:NextThink(CurTime());

			return true;
		elseif (self.rising) then
			if (self:GetPos() != self.goalPos) then
				local approachPos = ApproachVector(self:GetPos(), self.goalPos, 0.4);

				self:SetPos(approachPos);
				self:NextThink(CurTime());

				return true;
			else
				self.rising = false;
			end;
		end;
	end;

elseif (CLIENT) then

	function ENT:Initialize()
		local ang = self:GetAngles();

		ang:RotateAroundAxis(self:GetUp(), 180);
		self.other = ents.CreateClientProp(self:GetModel());
		self.other:SetPos(self:GetPos() - self:GetForward() * 10 + self:GetRight() * 15);
		self.other:SetAngles(ang);
		self.other:Spawn();
		self.other:Activate();
		self.other:SetMaterial("models/props_wasteland/dirtwall001a");
		self.other:DrawShadow(false);
		self.other:SetParent(self);
		self.other.RenderOverride = function(ent)
			local normal = self:GetDTVector(1);
			local position = normal:Dot(self:GetDTVector(0));

			render.PushCustomClipPlane(normal, position);
				ent:DrawModel();
			render.PopCustomClipPlane();
		end;

		self:SetSolid( SOLID_VPHYSICS );

		self:CallOnRemove("DeleteGhost", function(ent) SafeRemoveEntity(self.other) end);
	end;

	function ENT:Draw()
		local normal = self:GetDTVector(1);
		local position = normal:Dot(self:GetDTVector(0));

		render.PushCustomClipPlane(normal, position);
			self:DrawModel();
		render.PopCustomClipPlane();
	end;

end;
