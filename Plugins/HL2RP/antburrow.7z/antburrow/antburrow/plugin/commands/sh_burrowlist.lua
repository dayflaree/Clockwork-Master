local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("BurrowList");
COMMAND.tip = "Lists burrow locations for antlions.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);

function COMMAND:OnRun(player, arguments)
	if (player:GetFaction() == FACTION_ANTLION or Clockwork.player:HasFlags(player, "s")) then
		if (#PLUGIN.BurrowLocations > 0) then
			local sorted = PLUGIN.BurrowLocations;

			table.SortByMember(sorted, "name", true);

			Clockwork.player:Notify(player, "Available burrow locations are:");

			for k, v in ipairs(sorted) do
				Clockwork.player:Notify(player, "- " .. v.name);
			end;
			Clockwork.player:Notify(player, "Check your console to see the full list.");
		else
			Clockwork.player:Notify(player, "No available burrows!");
		end;
	end;
end;

COMMAND:Register();