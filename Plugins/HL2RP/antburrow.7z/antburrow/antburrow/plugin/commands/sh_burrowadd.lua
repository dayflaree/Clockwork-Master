local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("BurrowAdd");
COMMAND.tip = "Adds a burrow location for antlions.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.text = "<string BurrowName>";
COMMAND.arguments = 1;
COMMAND.access = "s";

function COMMAND:OnRun(player, arguments)
	local success = PLUGIN:BurrowAdd(arguments[1], player:GetPos());

	if (success) then
		Clockwork.player:Notify(player, "You have successfully added the '" .. arguments[1]:lower() .. "' burrow.");
	else
		Clockwork.player:Notify(player, "A burrow with the name '" .. arguments[1]:lower() .. "' already exists!");
	end;
end;

COMMAND:Register();