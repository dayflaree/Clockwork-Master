local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Burrow");
COMMAND.tip = "As an antlion, burrow to the specified location.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.text = "<string BurrowName>";
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	PLUGIN:BurrowTo(player, arguments[1]);
end;

COMMAND:Register();