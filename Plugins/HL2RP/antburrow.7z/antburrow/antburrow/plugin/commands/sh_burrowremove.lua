local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("BurrowRemove");
COMMAND.tip = "Removes a burrow location for antlions.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.text = "<string BurrowName>";
COMMAND.arguments = 1;
COMMAND.access = "s";

function COMMAND:OnRun(player, arguments)
	local success = PLUGIN:BurrowRemove(arguments[1]);

	if (success) then
		Clockwork.player:Notify(player, "You have successfully removed the '" .. arguments[1]:lower() .. "' burrow.");
	else
		Clockwork.player:Notify(player, "Could not find a burrow with the name '" .. arguments[1]:lower() .. "'!");
	end;
end;

COMMAND:Register();