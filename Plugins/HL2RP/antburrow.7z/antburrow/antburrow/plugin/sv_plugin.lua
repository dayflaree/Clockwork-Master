local PLUGIN = PLUGIN;

PLUGIN.BurrowMats = {};
PLUGIN.BurrowMats[MAT_DIRT] 	= true;
PLUGIN.BurrowMats[MAT_GRASS] 	= true;
PLUGIN.BurrowMats[MAT_SAND] 	= true;
PLUGIN.BurrowMats[MAT_SNOW] 	= true;

function PLUGIN:BurrowAdd(burrowName, burrowPos)
	for k, v in pairs(self.BurrowLocations) do
		if (v.name:lower() == burrowName:lower()) then
			return false;
		end;
	end;

	local buffer = {
		name = burrowName:lower(),
		pos = burrowPos
	};

	self.BurrowLocations[#self.BurrowLocations + 1] = buffer;
	self:SaveBurrows();

	return true;
end;

function PLUGIN:BurrowRemove(burrowName)
	for k, v in pairs(self.BurrowLocations) do
		if (v.name:lower() == burrowName:lower()) then
			table.remove(self.BurrowLocations, k);
			self:SaveBurrows()

			return true;
		end;
	end;

	return false;
end;

function PLUGIN:CreateMound(moundPos, removeDelay)
	local mound = ents.Create("antlion_burrow");
	local tr = {
		start = moundPos + Vector(0, 0, 10),
		endpos = moundPos - Vector(0, 0, 10),
		filter = function(ent) if (ent:GetClass() == "Player") then return false; else return true; end; end;
	};
	local hitTrace = util.TraceLine(tr);

	mound:SetPos(moundPos);
	mound:SetAngles(hitTrace.HitNormal:Angle() + Angle(90, 0, 0));
	mound:Spawn();
	mound:Rise();
	mound:Sink(removeDelay);
end;

function PLUGIN:BurrowPosBlocked(burrowPos)
	local hull = {
		start = burrowPos + Vector(0, 0, 3),
		endpos = burrowPos + Vector(0, 0, 1),
		maxs = Vector(16, 16, 60),
		mins = Vector(-16, -16, 0),
		ignoreworld = true
	};
	local hullTrace = util.TraceHull(hull);

	if (hullTrace.Hit) then
		return true;
	else
		return false;
	end;
end;

function PLUGIN:CancelBurrow(player)
	player:EmitSound("npc/antlion/digup1.wav");
	player:SetForcedAnimation("digout", 1.5);
	player:DrawShadow(true);
	player.burrowed = false;
	timer.Remove("burrowWait" .. player:UniqueID());
	timer.Remove("burrowFade" .. player:UniqueID());

	timer.Simple(1.3, function()
		if (IsValid(player)) then
			player:SetMoveType(MOVETYPE_WALK);
			player:SetNotSolid(false);
		end;
	end);
end;

function PLUGIN:CanBurrow(player)
	local tr = {
		start = player:GetPos() + Vector(0, 0, 5),
		endpos = player:GetPos() - Vector(0, 0, 5),
		mask = MASK_OPAQUE,
		filter = function(ent) if (ent:GetClass() == "Player") then return false; else return true; end; end;
	};
	local matTrace = util.TraceLine(tr);

	if (self.BurrowMats[matTrace.MatType]) then
		return true;
	end;

	return false;
end;

function PLUGIN:GetBurrowTime(player, burrowPos)
	local dist = player:GetPos():Distance(burrowPos);
	local time = math.Clamp(dist * 0.005, 2, 45);

	return time;
end;

function PLUGIN:BurrowTo(player, burrowName)
	if (player:GetFaction() == FACTION_ANTLION) then
		if (self:CanBurrow(player)) then
			local found = false;

			for k, v in pairs(self.BurrowLocations) do
				if (v.name:lower() == burrowName:lower()) then
					found = true;

					if (!self:BurrowPosBlocked(v.pos)) then
						local burrowTime = self:GetBurrowTime(player, v.pos);

						player.burrowed = true;
						player:SetForcedAnimation("digin");
						player:EmitSound("npc/antlion/digdown1.wav");
						player:DrawShadow(false);
						player:SetMoveType(MOVETYPE_NONE);
						player:SetNotSolid(true);
						self:CreateMound(player:GetPos(), 30);

						timer.Create("burrowFade" .. player:UniqueID(), burrowTime - 2, 1, function()
							if (IsValid(player) and player.burrowed) then
								player:ScreenFade(SCREENFADE.OUT, color_black, 1.5, 1);
							end;
						end);

						timer.Create("burrowWait" .. player:UniqueID(), burrowTime, 1, function()
							if (IsValid(player) and player.burrowed) then
								player:SetPos(v.pos);
								player:ScreenFade(SCREENFADE.IN, color_black, 1.5, 0.3);
								player:EmitSound("npc/antlion/digup1.wav", 75, 100, 0.5);
								player:SetForcedAnimation("digout", 1.5);
								player:DrawShadow(true);
								player.burrowed = false;
								self:CreateMound(v.pos, 40);

								timer.Simple(1.3, function()
									if (IsValid(player)) then
										player:SetNotSolid(false);
										player:SetMoveType(MOVETYPE_WALK);
									end;
								end);
							end;
						end);
					else
						Clockwork.player:Notify(player, "That burrow is currently blocked!");
					end;
				end;
			end;

			if (!found) then
				Clockwork.player:Notify(player, "Could not find the burrow specified!");
			end;
		else
			Clockwork.player:Notify(player, "You cannot burrow here!");
		end;
	else
		Clockwork.player:Notify(player, "You are not an antlion!");
	end;
end;