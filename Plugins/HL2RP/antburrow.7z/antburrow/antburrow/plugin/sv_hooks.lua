local PLUGIN = PLUGIN;

PLUGIN.BurrowLocations = {};

function PLUGIN:SaveBurrows()
	Clockwork.kernel:SaveSchemaData("plugins/antburrows/" .. game.GetMap(), self.BurrowLocations);
end;

-- Load the burrows
function PLUGIN:LoadBurrows()
	self.BurrowLocations = Clockwork.kernel:RestoreSchemaData("plugins/antburrows/" .. game.GetMap());
end;

function PLUGIN:PlayerCharacterLoaded(player)
	if (player.burrowed) then
		self:CancelBurrow(player);
	end;
end;

function PLUGIN:KeyPress(player, key)
	if (player.burrowed and (key == IN_FORWARD or key == IN_BACK or key == IN_MOVELEFT or key == IN_MOVERIGHT)) then
		self:CancelBurrow(player);
		Clockwork.player:Notify(player, "Burrowing cancelled due to movement!");
	end;
end;

PLUGIN:LoadBurrows();