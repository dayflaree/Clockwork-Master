local PLUGIN = PLUGIN;

Schema.randomDisplayLines = {
	"Transmitting physical transition vector...",
	"Modulating external temperature levels...",
	"Parsing view ports and data arrays...",
	"Translating Union practicalities...",
	"Updating biosignal co-ordinates...",
	"Parsing Clockwork protocol messages...",
	"Downloading recent dictionaries...",
	"Pinging connection to network...",
	"Updating mainframe connection...",
	"Synchronizing locational data...",
	"Translating radio messages...",
	"Emptying outgoing pipes...",
	"Sensoring proximity...",
	"Pinging loopback...",
	"Idle connection...",
	"Checking integrity of sub-systems...",
	"Clocking internal chip speeds...",
	"Optimizing visual overlay systems...",
	"Modulating internal environment...",
	"Performing sociostability scan...",
	"Filtering request priorities...",
	"Checking objective logs...",
	"Encoding outgoing radio transmissions...",
	"Identifying persons within visual range...",
	"Checking for rogue elements...",
	"Updating patrol logs..."

};
