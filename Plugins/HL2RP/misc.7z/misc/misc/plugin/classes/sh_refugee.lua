--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Refugee");
	CLASS.color = Color(230, 185, 90, 255);
	CLASS.factions = {FACTION_REFUGEE};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "A regular human citizen enslaved by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_REFUGEE = CLASS:Register();