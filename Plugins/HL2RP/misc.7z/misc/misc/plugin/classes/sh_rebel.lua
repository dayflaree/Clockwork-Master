--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Rebel");
	CLASS.color = Color(155, 110, 10, 255);
	CLASS.factions = {FACTION_REBEL};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "HUman, who fights for the freedom of the race.";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_REBEL = CLASS:Register();