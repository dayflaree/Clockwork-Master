--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("Antlion");
	CLASS.color = Color(9, 255, 0, 255);
	CLASS.factions = {FACTION_LION};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "For prepay players";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_LION = CLASS:Register();