--[[
	� 2013 The Orange Gaming By Portal
--]]

local FACTION = Clockwork.faction:New("The Zombie");

FACTION.useFullName = true;
FACTION.attributePointsScale = 4;
FACTION.whitelist = true;
FACTION.models = {
	male = {
"models/Zombie/Poison.mdl",
"models/Zombie/Classic.mdl",
"models/Zombie/Classic_torso.mdl",
"models/Zombie/Fast.mdl"

	};
};

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (faction.name != FACTION_CITIZEN) then
		return false;
	end;
end;

FACTION_ZOMBI = FACTION:Register();
