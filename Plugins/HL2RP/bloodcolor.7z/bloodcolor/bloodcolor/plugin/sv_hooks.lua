
local PLUGIN = PLUGIN;

-- A function to set the player's blood color
function PLUGIN:PlayerBloodColor(player)
	local playerFaction = player:GetFaction();

	if (playerFaction == FACTION_VORTIGAUNT or playerFaction == FACTION_CONSCRIPT_BIOTIC or playerFaction == FACTION_ALIENGRUNT or playerFaction == FACTION_ANTLION) then
		player:SetBloodColor(BLOOD_COLOR_YELLOW);
	else
		player:SetBloodColor(BLOOD_COLOR_RED);
	end;
end;

function PLUGIN:PlayerSpawn(player)
	self:PlayerBloodColor(player);
end;