include('shared.lua') -- At this point the contents of shared.lua are ran on the client only.
ENT.RenderGroup         = RENDERGROUP_BOTH
-- Called when the entity should draw.
local overlayMaterial = Material("effects/combine_binocoverlay")
local televisionMaterial = Material("dev/dev_tvmonitor1a")

function ENT:DrawTranslucent()
    self:DrawModel()
 
    local position = self:GetPos()
    local angles = self:GetAngles()
    angles:RotateAroundAxis(angles:Up(), 90)
    angles:RotateAroundAxis(angles:Forward(), 90)
 
    local f, r, u = self:GetForward(), self:GetRight(), self:GetUp()
 
    cam.Start3D2D(position + f*6 + r*-(-10) + u*5.75, angles, 0.5)
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( televisionMaterial )
        surface.DrawTexturedRect( 0, 0, 30, 23 )
    cam.End3D2D()
 
        cam.Start3D2D(position + f*6.2 + r*-(-10) + u*5.75, angles, 0.5)
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( overlayMaterial )
        surface.DrawTexturedRect( 0, 0, 30, 23 )
    cam.End3D2D()
end;