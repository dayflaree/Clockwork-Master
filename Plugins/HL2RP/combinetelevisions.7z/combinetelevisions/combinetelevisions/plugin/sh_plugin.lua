--[[
	This script has been purchased for "Blt950's HL2RP & Clockwork plugins" from CoderHire.com
	� 2014 Blt950 do not share, re-distribute or modify
	without permission.
--]]

local PLUGIN = PLUGIN;


Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if player:GetFaction() == "FACTION_CITIZEN" then
		if player:GetGender() == GENDER_FEMALE then
			player:SetModelScale( player:GetModelScale() * 0.4, 1 )
		elseif player:GetGender() == GENDER_MALE then
			player:SetModelScale( player:GetModelScale() * 3, 1 )
		end
	elseif (player:GetFaction() == "FACTION_MPF" or player:GetFaction() == "FACTION_OTA") then
		player:SetModelScale( player:GetModelScale() * 4.5, 1 )
	end
end