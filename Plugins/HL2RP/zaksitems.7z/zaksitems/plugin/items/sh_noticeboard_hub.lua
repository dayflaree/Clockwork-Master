local ITEM = Clockwork.item:New();

ITEM.name = "Hub Noticeboard";
ITEM.uniqueID = "noticeboard_hub";
ITEM.model = "models/props/cs_office/offcorkboarda.mdl";
ITEM.weight = 45;
ITEM.category = "Workstations";
ITEM.craftingStation = true;
ITEM.business = false;
ITEM.description = "An old noticeboard, plastered with survivor-made messages.";
ITEM.customFunctions = {"Read"};

if (CLIENT) then
	-- Called when the item entity's menu options are needed.
	function ITEM:GetEntityMenuOptions(entity, options)
		if (!IsValid(entity)) then
			return;
		end;

		options["Read"] = function()
			local customData = {};
		
			Clockwork.datastream:Start(player, "OpenHubURL", true);
			Clockwork.entity:ForceMenuOption(entity, "Read", customData);
		end;
	end
end;

if (SERVER) then
	Clockwork.hint:Add("Hub", "Check out the noticeboard in the Hub to see if there's any useful info!");
else
	Clockwork.datastream:Hook("OpenHubURL", function()
		gui.OpenURL("boy if u dont placeholder");
	end);
end;

function ITEM:OnDrop() end;

function ITEM.CanPickup(player, bQuickUse, entity) 
	return false; 
end;

ITEM:Register();