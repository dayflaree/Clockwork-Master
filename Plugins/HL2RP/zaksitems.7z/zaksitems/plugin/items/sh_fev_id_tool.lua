local ITEM = Clockwork.item:New();

ITEM.name = "FEV Identification Tool";
ITEM.uniqueID = "fev_id_tool";
ITEM.model = "models/props_c17/consolebox05a.mdl";
ITEM.weight = 0.5
ITEM.category = "Medical";
ITEM.description = "A small grey testing kit - around the size of your hand. It contains latex gloves, cheek swabs and small syringes. There's a port at the top where samples are placed for analysis. The instructions read 'Take sample from cheek cells or extract blood using syringe. Place sample in analysis port. Subject status will be communicated swiftly - check display.'";
ITEM.customFunctions = {"Test for mutation"};

function ITEM:OnCustomFunction(player, name)
	if (name == "Test for mutation") then
		Clockwork.player:Notify(player, "You now ICly know if the person you tested is infected with the Forced Evolutionary Virus. Ask them OOCly, and if they refuse to cooperate, call a staff member.");
	end;
end;

function ITEM:OnDrop() end;

ITEM:Register();