local ITEM = Clockwork.item:New();

ITEM.name = "Humanitarian Ration Supply Crate";
ITEM.uniqueID = "supply_crate_human";
ITEM.model = "models/items/item_item_crate.mdl";
ITEM.weight = 5;
ITEM.category = "Supply Crates";
ITEM.business = false;
ITEM.useSound = "physics/cardboard/cardboard_box_break1.wav";
ITEM.description = "A wooden crate labelled 'SUPPLY', containing five Humanitarian Rations. Looks heavy.";
ITEM.customFunctions = {"Unpack"};

function ITEM:OnCustomFunction(player, name)
	if (name == "Unpack") then
		player:GiveItem(Clockwork.item:CreateInstance("human_ration"));
		player:GiveItem(Clockwork.item:CreateInstance("human_ration"));
		player:GiveItem(Clockwork.item:CreateInstance("human_ration"));
		player:GiveItem(Clockwork.item:CreateInstance("human_ration"));
		player:GiveItem(Clockwork.item:CreateInstance("human_ration"));
		player:TakeItem(self);
	end;
end;

function ITEM:OnDrop() end;

ITEM:Register();