local ITEM = Clockwork.item:New();
ITEM.name = "Buckshot Supply Crate";
ITEM.uniqueID = "supply_crate_buckshot";
ITEM.model = "models/items/item_item_crate.mdl";
ITEM.weight = 5;
ITEM.category = "Supply Crates";
ITEM.business = false;
ITEM.useSound = "physics/cardboard/cardboard_box_break1.wav";
ITEM.description = "A wooden crate labelled 'SUPPLY', containing five boxes of 12-Gauge Buckshot.. Looks heavy.";
ITEM.customFunctions = {"Unpack"};

function ITEM:OnCustomFunction(player, name)
	if (name == "Unpack") then
		player:GiveItem(Clockwork.item:CreateInstance("12_gauge_buckshot"));
		player:GiveItem(Clockwork.item:CreateInstance("12_gauge_buckshot"));
		player:GiveItem(Clockwork.item:CreateInstance("12_gauge_buckshot"));
		player:GiveItem(Clockwork.item:CreateInstance("12_gauge_buckshot"));
		player:GiveItem(Clockwork.item:CreateInstance("12_gauge_buckshot"));
		player:TakeItem(self);
	end;
end;

function ITEM:OnDrop() end;

ITEM:Register();