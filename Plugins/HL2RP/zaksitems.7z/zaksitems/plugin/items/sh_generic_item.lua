local ITEM = Clockwork.item:New();
ITEM.name = "Generic Item";
ITEM.uniqueID = "generic_item";
ITEM.model = "models/props_lab/cactus.mdl";
ITEM.description = "This item needs to be customized! Grab a Super Admin to do it!";

ITEM:AddData("Name", ITEM.name, true);
ITEM:AddData("Rarity", 1, true);
ITEM:AddData("Desc", ITEM.description, true);
ITEM:AddData("Model", ITEM.model, true);
ITEM:AddData("Weight", 2, true);
ITEM:AddData("Category", "Other", true);

ITEM:AddQueryProxy("name", "Name", true);
ITEM:AddQueryProxy("color", ITEM.GetRarityColor);
ITEM:AddQueryProxy("description", "Desc", true);
ITEM:AddQueryProxy("model", "Model", true);
ITEM:AddQueryProxy("weight", "Weight", true);
ITEM:AddQueryProxy("category", "Category", true);

-- A function to get the item's rarity color.
function ITEM:GetRarityColor()
	local rarity = self:GetData("Rarity");
	if (rarity == 1) then
		return Color(248, 248, 255, 255);
	elseif (rarity == 2) then
		return Color(61, 210, 11, 255);
	elseif (rarity == 3) then
		return Color(47, 120, 255, 255);
	elseif (rarity == 4) then
		return Color(145, 50, 200, 255);
	elseif (rarity == 5) then
		return Color(255, 150, 0, 255);
	end;
end;

function ITEM:OnDrop() end;

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		if (!self:IsInstance()) then return; end;

		local clientSideInfo = "";

		local itemRarity = self:GetData("Rarity");
		if (itemRarity == 2) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Uncommon", self:GetRarityColor());
		elseif (itemRarity == 3) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Rare", self:GetRarityColor());
		elseif (itemRarity == 4) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Unique", self:GetRarityColor());
		elseif (itemRarity == 5) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Legendary", self:GetRarityColor());
		end;
		
		return (clientSideInfo != "" and clientSideInfo);
	end;

	-- Called when the item entity's menu options are needed.
	function ITEM:GetEntityMenuOptions(entity, options)
		if (!IsValid(entity) or !Clockwork.Client:IsSuperAdmin()) then
			return;
		end;

		options["Customize"] = function()
			local customData = {};
			
			Derma_StringRequest("Name", "Name of the item? Current: "..self("name", ""), self("name", ""), function(text)
				if (!text or text == "") then
					text = self("name", "");
				end;
				customData.Name = text;
				
			Derma_StringRequest("Rarity",
					"Rarity of the item?\n1 is generic (white), 2 is uncommon (green), 3 is rare (blue), 4 is unique (purple), 5 is legendary (orange).", self("Rarity", "1"), function(text)
				text = tonumber(text);
				if (!text) then
					text = self("Rarity", 1);
				end;
				customData.Rarity = math.Clamp(math.Round(text), 1, 5);
					
			Derma_StringRequest("Description", "Description of the item? Current: "..self("description", ""), self("description", ""), function(text)
				if (!text) then
					text = self("description", "");
				end;
				customData.Desc = text;
				
			Derma_StringRequest("Model", "Model of the item? Current: "..self("model", "models/error.mdl"), self("model", ""), function(text)
				if (!text or text == "") then
					text = self("model", "models/error.mdl");
				end;
				customData.Model = text;
				
			Derma_StringRequest("Weight", "Weight of the item? Current: "..self("weight", "0"), self("weight", "0"), function(text)
				text = tonumber(text);
				if (!text) then
					text = self("weight", 0);
				end;
				customData.Weight = text;

			Derma_StringRequest("Category", "Category of the item? Current: "..self("category", "Other"), self("category", "Other"), function(text)
				if (!text or text == "") then
					text = "Other";
				end;
				customData.Category = text;
				
			Clockwork.entity:ForceMenuOption(entity, "Customize", customData);

			end); end); end); end); end); end);
		end;
	end
end;

Clockwork.item:Register(ITEM);