local ITEM = Clockwork.item:New();

ITEM.name = "Bag of Weed";
ITEM.uniqueID = "weed";
ITEM.model = "models/katharsmodels/contraband/zak_wiet/zak_wiet.mdl";
ITEM.weight = 1;
ITEM.category = "Medical";
ITEM.business = false;
ITEM.cost = 75;
ITEM.useSound = "ambient/fire/mtov_flame2.wav";
ITEM.description = "A dimebag of kush, good for just chilling out and forgetting all about the apocalypse.";
ITEM.customFunctions = {"Blaze It"};

function ITEM:OnCustomFunction(player, name)
	if (name == "Blaze It") then
		Clockwork.player:Notify(player, "duuuuuuuuuuude");
		player:TakeItem(self);
	end;
end;

function ITEM:OnDrop() end;

ITEM:Register();