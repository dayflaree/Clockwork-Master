local ITEM = Clockwork.item:New();
ITEM.name = ".357 Magnum Supply Crate";
ITEM.uniqueID = "supply_crate_357";
ITEM.model = "models/items/item_item_crate.mdl";
ITEM.weight = 5;
ITEM.category = "Supply Crates";
ITEM.business = false;
ITEM.useSound = "physics/cardboard/cardboard_box_break1.wav";
ITEM.description = "A wooden crate labelled 'SUPPLY', containing five boxes of .357 Magnum rounds. Looks heavy.";
ITEM.customFunctions = {"Unpack"};

function ITEM:OnCustomFunction(player, name)
	if (name == "Unpack") then
		player:GiveItem(Clockwork.item:CreateInstance("357_magnum"));
		player:GiveItem(Clockwork.item:CreateInstance("357_magnum"));
		player:GiveItem(Clockwork.item:CreateInstance("357_magnum"));
		player:GiveItem(Clockwork.item:CreateInstance("357_magnum"));
		player:GiveItem(Clockwork.item:CreateInstance("357_magnum"));
		player:TakeItem(self);
	end;
end;

function ITEM:OnDrop() end;

ITEM:Register();