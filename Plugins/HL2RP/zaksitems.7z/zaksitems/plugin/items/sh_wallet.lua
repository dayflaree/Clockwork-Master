local ITEM = Clockwork.item:New();

ITEM.name = "Wallet";
ITEM.uniqueID = "wallet";
ITEM.model = "models/props_junk/garbage_bag001a.mdl";
ITEM.weight = .1;
ITEM.category = "Other";
ITEM.business = false;
ITEM.useSound = "physics/cardboard/cardboard_box_break1.wav";
ITEM.useText = "Open";
ITEM.description = "A small leather wallet. Looks like there's a bit of money inside...";

function ITEM:OnUse(player, name)
	Clockwork.player:GiveCash(player, math.random(1,25), "opening wallet");
	player:TakeItem(self);
end;

function ITEM:OnDrop() end;

ITEM:Register();