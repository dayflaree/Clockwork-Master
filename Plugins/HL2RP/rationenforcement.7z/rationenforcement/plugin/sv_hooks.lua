local PLUGIN = PLUGIN;
local ratioEnabled = Clockwork.config:Get("is_ratio_enabled"):Get();

function PLUGIN:PlayerAdjustCharacterScreenInfo(player, character, info)
	if (ratioEnabled) then
		if (info.faction == FACTION_OTA) then
			if self.OTACanUse then
				info.details = "Overwatch Transhuman Arms currently can be used."
			else
				info.details = "Overwatch Transhuman Arms currently cannot be used."
			end;
		elseif (self:IsCombineFaction(info.faction)) then
			if (!self:CanUseCP(player)) then
				info.details = "Access Denied: too many units connected to the network."
			end;
		end;
	end;
end;