--[[
	© 2016 TeslaCloud Studios.
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua")

if (SERVER) then Clockwork.config:Add("is_ratio_enabled", false); end;
if (CLIENT) then Clockwork.config:AddToSystem("Ratio Enforcement Enabled", "is_ratio_enabled", "Whether or not the 1:2 MPF to citizen ratio is enforced."); end;

function PLUGIN:CanUseCP(player)
	local cp = 0
	local cit = 0
	local pl = 0
	local ratio = 0

	if (player:IsAdmin()) then
		return true
	end;

	for k, v in ipairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			if (self:PlayerIsCombine(v)) then
				cp = cp + 1
			else
				cit = cit + 1
			end;

			pl = pl + 1
		end;
	end;

	ratio = cit / cp

	if ((!ratio or ratio <= 2) and pl >= 3) then
		return false
	end;

	return true
end;