--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("isorequest");
COMMAND.tip = "Request an isolation for citizen.";
COMMAND.text = "<string CID> <string REASON>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
OWIsolation = {}
OWIsolation.Target = nil;

OWIsolation.Time = nil;
OWIsolation.Verdict = nil;
	if (Schema:PlayerIsCombine(combine)) then
		if (arguments[1] and arguments[2]) then
				for k,v in pairs(player.GetAll()) do
					if (v:IsPlayer() and v:Alive()) then
						if ((v:GetCharacterData("citizenid") == arguments[1]) and (v:GetFaction() == FACTION_CITIZEN)) then
							OWIsolation.Target = v;
							if (string.find(arguments[2], "ACA-01", 0)) then
								OWIsolation.Time = 0;
								OWIsolation.Verdict = "RE-EDUCATION";
							end;
							if (string.find(arguments[2], "ACA-02", 0)) then
								OWIsolation.Time = 10;
								OWIsolation.Verdict = "2X RE-EDUCATION, 10MIN ISOLATION";
							end;
							if (string.find(arguments[2], "SE-01", 0)) then
								OWIsolation.Time = 20;
								OWIsolation.Verdict = "3X RE-EDUCATION, 20MIN ISOLATION";
							end;
							if (string.find(arguments[2], "SE-02", 0)) then
								OWIsolation.Time = 60;
								OWIsolation.Verdict = "4X RE-EDUCATION, 60MIN ISOLATION";
							end;
							if (string.find(arguments[2], "CM-00", 0)) then
								OWIsolation.Time = 60;
								OWIsolation.Verdict = "60MIN ISOLATION";
							end;
							if (string.find(arguments[2], "SE-03", 0)) then
								OWIsolation.Time = 0;
								OWIsolation.Verdict = "SURGICAL AMPUTATION";
							end;
							if (string.find(arguments[2], "SE-04", 0)) then
								OWIsolation.Time = 0;
								OWIsolation.Verdict = "SURGICAL AMPUTATION";
							end;
							if (string.find(arguments[2], "MAV-00", 0)) then
								OWIsolation.Time = 0;
								OWIsolation.Verdict = "AMPUTATION";
							end;
							if (string.find(arguments[2], "SE-05", 0)) then
								OWIsolation.Time = 0;
								OWIsolation.Verdict = "AMPUTATION";
							end;							
							for k, v in pairs(player.GetAll()) do
								if (Schema:PlayerIsCombine(v)) then
									if (v:Alive()) then							
										v:EmitSound("npc/combine_soldier/vo/on2.wav");
										Clockwork.chatBox:SendColored(v, Color(75, 150, 50), ""..combine:GetName().." radios in ''<:: Isolation request for citizen #"..arguments[1]..", reason: "..arguments[2]..".''");
									end;
								end;
							end;
							for k, v in pairs(ents.FindInSphere(combine:GetPos(), Clockwork.config:Get("talk_radius"):Get())) do
								if (IsValid(v) and v:IsPlayer() and v:Alive()) then
									if (!Schema:PlayerIsCombine(v)) then
										if (v:Alive()) then
											Clockwork.chatBox:SendColored(v, Color(255, 255, 175), ""..combine:GetName().." radios in ''<:: Isolation request for citizen #"..arguments[1]..", reason: "..arguments[2]..".''");
										end;
									end;
								end;
							end;
							if (OWIsolation.Target:GetCharacterData("civ_jail_type") == "None") then
								OWIsolation.Target:SetCharacterData("civ_jail_type", arguments[2]);									
								OWIsolation.Target:SetCharacterData("civ_jail_time", OWIsolation.Time);	
							end;						
							local newREASON = OWIsolation.Target:GetCharacterData("civ_jail_type");							
							local newTIME = OWIsolation.Target:GetCharacterData("civ_jail_time");
							timer.Simple(2, function()
								for k, v in pairs(player.GetAll()) do
									if (Schema:PlayerIsCombine(v)) then									
										if (v:Alive()) then	
											v:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav");
											Clockwork.chatBox:SendColored(v, Color(75, 150, 50), "Overwatch radios in '' <:: Isolation for citizen #"..arguments[1].." has been approved. Citizen isolation reason is: ", Color(63, 127, 127), newREASON, Color(75, 150, 50),". Isolation time: ", Color(63, 127, 127)," "..OWIsolation.Target:GetCharacterData("civ_jail_time").."", Color(75, 150, 50), ".''");
											Clockwork.chatBox:SendColored(v, Color(75, 150, 50), "Overwatch radios in '' <:: Verdict: "..OWIsolation.Verdict..". Don't forget to release citizen #"..arguments[1].." when isolation time is over.''");
										end;
									end;
								end;
							end);
							--v:SetCharacterData("civ_blackmarks", bms+1);
						end;
					end;
				end;
		end;
	else
		Clockwork.player:Notify(combine, "You are not a Combine Unit!");
	end;
end;

COMMAND:Register();