--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("relrequest");
COMMAND.tip = "Request an release for citizen.";
COMMAND.text = "<string CID>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
OWBlackmarks = {}
OWBlackmarks.Target = nil;
	if (Schema:PlayerIsCombine(combine)) then
		if (arguments[1]) then
			local CID = arguments[1];

				for k,v in pairs(player.GetAll()) do
					if (v:IsPlayer() and v:Alive()) then
						if ((v:GetCharacterData("citizenid") == CID) and (v:GetFaction() == FACTION_CITIZEN)) then
							OWBlackmarks.Target = v;
							for k, v in pairs(player.GetAll()) do
								if (Schema:PlayerIsCombine(v)) then
									if (v:Alive()) then							
										v:EmitSound("npc/combine_soldier/vo/on2.wav");
										Clockwork.chatBox:SendColored(v, Color(75, 150, 50), ""..combine:GetName().." radios in ''<:: Release request for citizen #"..CID..".''");
									end;
								end;
							end;
							for k, v in pairs(ents.FindInSphere(combine:GetPos(), Clockwork.config:Get("talk_radius"):Get())) do
								if (IsValid(v) and v:IsPlayer() and v:Alive()) then
									if (!Schema:PlayerIsCombine(v)) then
										if (v:Alive()) then
											Clockwork.chatBox:SendColored(v, Color(255, 255, 175), ""..combine:GetName().." radios in ''<:: Release request for citizen #"..CID..".''");
										end;
									end;
								end;
							end;
							if (OWBlackmarks.Target:GetCharacterData("civ_jail_type") != "None") then								
								OWBlackmarks.Target:SetCharacterData("civ_jail_type", "None");
								timer.Simple(2, function()
									if (combine:Alive()) then							
										combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav");
										Clockwork.chatBox:SendColored(combine, Color(75, 150, 50), "Overwatch radios in '' <:: Release for citizen #"..CID.." has been approved. Escort the citizen from Nexus.''");
									end;
								end);
							elseif (OWBlackmarks.Target:GetCharacterData("civ_jail_type") == "None") then
								timer.Simple(2, function()
									if (combine:Alive()) then							
										combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav");
										Clockwork.chatBox:SendColored(combine, Color(75, 150, 50), "Overwatch radios in '' <:: Denied. Citizen #"..CID.." has no verdict.''");
									end;
								end);								
							end;
							--v:SetCharacterData("civ_blackmarks", bms+1);
						end;
					end;
				end;
		end;
	else
		Clockwork.player:Notify(combine, "You are not a Combine Unit!");
	end;
end;

COMMAND:Register();