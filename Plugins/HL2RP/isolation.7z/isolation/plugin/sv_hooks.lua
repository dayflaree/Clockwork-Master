local PLUGIN = PLUGIN;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (!data["civ_jail_type"]) then
		data["civ_jail_type"] = "None";
	end;
	if (!data["civ_jail_time"]) then
		data["civ_jail_time"] = 0;
	end;	
end;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	if (!player.isolationReminder or CurTime() >= player.isolationReminder) then
		if (player:Alive() and !player:IsRagdolled()) then
			if (faction == FACTION_CITIZEN) then	
				if ((player:GetCharacterData("civ_jail_type") != "None") and (player:GetCharacterData("civ_jail_time") == 0)) then	
					for k, v in pairs(_player.GetAll()) do
						if (Schema:PlayerIsCombine(v)) then
							if (v:Alive()) then							
								v:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav");
								Clockwork.chatBox:SendColored(v, Color(75, 150, 50), "Overwatch radios in '' <:: Isolation time for citizen #"..player:GetCharacterData("citizenid").." is up. Re-educate and release citizen.''");
								OW_Add_Order("low", "ISOLATION #"..player:GetCharacterData("civ_jail_type").."", "Isolation time is up for citizen #"..player:GetCharacterData("citizenid")..".", "INJECT, DIAGNOSE, INTERCEDE.", player:GetPos());
							end;
						end;
					end;
				end;
			end;
		end;
		player.isolationReminder = CurTime() + 60;
	end;
	if (!player.isolationTimer or CurTime() >= player.isolationTimer) then
		if (player:Alive() and !player:IsRagdolled()) then
			if (faction == FACTION_CITIZEN) then	
				if ((player:GetCharacterData("civ_jail_type") != "None") and (player:GetCharacterData("civ_jail_time") > 0)) then	
					player:SetCharacterData("civ_jail_time", player:GetCharacterData("civ_jail_time") - 1);
				end;
			end;
		end;
		player.isolationTimer = CurTime() + 1;
	end;	
end;