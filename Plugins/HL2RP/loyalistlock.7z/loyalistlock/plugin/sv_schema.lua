local PLUGIN = PLUGIN;

-- A function to load the Union locks.
function PLUGIN:LoadLoyalistLocks()
	local loyalistLocks = Clockwork.kernel:RestoreSchemaData( "plugins/loyalistlocks/"..game.GetMap() );
	
	for k, v in pairs(loyalistLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16)[1];
		
		if (IsValid(entity)) then
			local loyalistLock = self:ApplyLoyalistLock(entity);
			
			if (loyalistLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				loyalistLock:SetLocalAngles(v.angles);
				loyalistLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					loyalistLock:Unlock();
				else
					loyalistLock:Lock();
				end;
			end;
		end;
	end;
end;

-- A function to save the Union locks.
function PLUGIN:SaveLoyalistLocks()
	local loyalistLocks = {};
	
	for k, v in pairs( ents.FindByClass("cw_loyalistlock") ) do
		if (IsValid(v.entity)) then
			loyalistLocks[#loyalistLocks + 1] = {
				key = Clockwork.entity:QueryProperty(v, "key"),
				locked = v:IsLocked(),
				angles = v:GetLocalAngles(),
				position = v:GetLocalPos(),
				uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID"),
				doorPosition = v.entity:GetPos()
			};
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/loyalistlocks/"..game.GetMap(), loyalistLocks);
end;

-- A function to apply a Union lock.
function PLUGIN:ApplyLoyalistLock(entity, position, angles)
	local loyalistLock = ents.Create("cw_loyalistlock");
	
	loyalistLock:SetParent(entity);
	loyalistLock:SetDoor(entity);
	
	if (position) then
		if (type(position) == "table") then
			loyalistLock:SetLocalPos( Vector(-1.0313, 43.7188, -1.2258) );
			loyalistLock:SetPos( loyalistLock:GetPos() + (position.HitNormal * 4) );
		else
			loyalistLock:SetPos(position);
		end;
	end;
	
	if (angles) then
		loyalistLock:SetAngles(angles);
	end;
	
	loyalistLock:Spawn();
	
	if (IsValid(loyalistLock)) then
		return loyalistLock;
	end;
end;

-- A function to bust down a door.
function PLUGIN:BustDownDoor(player, door, force)
	door.bustedDown = true;
	
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	if (IsValid(door.loyalistLock)) then
		door.loyalistLock:Explode();
		door.loyalistLock:Remove();
	end;
	
	if (IsValid(door.breach)) then
		door.breach:BreachEntity();
	end;
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		if (!force) then
			if (IsValid(player)) then
				physicsObject:ApplyForceCenter( (door:GetPos() - player:GetPos() ):GetNormal() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	Clockwork.entity:Decay(fakeDoor, 300);
	
	Clockwork.kernel:CreateTimer("reset_door_"..door:EntIndex(), 300, 1, function()
		if (IsValid(door)) then
			door.bustedDown = nil;
			
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
		end;
	end);
end;