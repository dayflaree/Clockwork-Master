local PLUGIN = PLUGIN;

-- Called when a player's weapons should be given.
function PLUGIN:PlayerGiveWeapons(player)
	if (player:GetFaction() == FACTION_CONSCRIPT) then
		Clockwork.player:GiveSpawnWeapon(player, "cw_stunstick");
	end;
end;

-- Called when a player attempts to use a door.
function PLUGIN:PlayerCanUseDoor(player, door)
	if (player:GetFaction() == FACTION_CONSCRIPT) then
		return true;
	end;
end;