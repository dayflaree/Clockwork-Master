local FACTION = Clockwork.faction:New("Conscript");
FACTION.whitelist = true;
FACTION.useFullName = true;
FACTION.material = "";
FACTION.models = {
	female = {
		"models/models/army/female_01.mdl",
		"models/models/army/female_02.mdl",
		"models/models/army/female_03.mdl",
		"models/models/army/female_04.mdl",
		"models/models/army/female_06.mdl",
		"models/models/army/female_07.mdl"
	},
	male = {
		"models/wichacks/artnovest.mdl",
		"models/wichacks/erdimnovest.mdl",
		"models/wichacks/ericnovest.mdl",
		"models/wichacks/joenovest.mdl",
		"models/wichacks/mikenovest.mdl",
		"models/wichacks/tednovest.mdl"
	};
};

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (Schema:PlayerIsCombine(player)) then
		if (name) then
			local models = self.models[ string.lower( player:QueryCharacter("gender") ) ];
			
			if (models) then
				player:SetCharacterData("model", models[ math.random(#models) ], true);
				
				Clockwork.player:SetName(player, name, true);
			end;
		else
			return false, "You need to specify a name as the third argument!";
		end;
	end;
end;

FACTION_CONSCRIPT = FACTION:Register();