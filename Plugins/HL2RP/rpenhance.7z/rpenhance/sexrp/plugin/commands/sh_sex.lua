--[[
	© 2013 Tru
    Have fun with this plugin. o.*
--]]

local COMMAND = Clockwork.command:New("havesex");
COMMAND.tip = "Have sex with the person your looking at.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player)
	local person = player:GetEyeTraceNoCursor().Entity;
	HaveSex(player,person)
end

COMMAND:Register();