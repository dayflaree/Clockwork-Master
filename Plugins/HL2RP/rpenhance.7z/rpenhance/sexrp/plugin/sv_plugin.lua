local Clockwork = Clockwork;
local Schema = Schema;
local SCHEMA = Schema;

local MaleOrgasm = {
"vo/npc/male01/moan01.wav",
"vo/npc/male01/moan02.wav",
"vo/npc/male01/moan03.wav",
"vo/npc/male01/moan04.wav",
"vo/npc/male01/pain04.wav",
"vo/npc/male01/pain01.wav",
"vo/npc/male01/pain02.wav",
"vo/npc/male01/pain03.wav",
"vo/npc/male01/pain04.wav",
"vo/npc/male01/pain05.wav",
"vo/npc/male01/pain06.wav",
"vo/npc/male01/pain09.wav"
}
local FemaleOrgasm =
{
"vo/npc/female01/moan02.wav",
"vo/npc/female01/moan03.wav",
"vo/npc/female01/moan05.wav",
"vo/npc/female01/ow01.wav",
"vo/npc/female01/ow02.wav",
"vo/npc/female01/pain02.wav",
"vo/npc/female01/pain06.wav",
"vo/npc/female01/pain09.wav"
}
local MaleOrgasmText = {
"Harder!",
"Want a piece of me?",
"YES! YEES!",
"Yes.. Yes.. Uhoh... Yes!",
"Fuck me.. Fuck me harder.. FUCK ME!",
"OH YES!",
"RIGHT IN THE ASS!",
"DO IT HARDER!",
"YEEEES!",
"FUCK ME!",
"Do you want to cum for me?",
"Do you 'wanna' cum for me? Huh? Come for me baby.. Come for me..",
"Ah yes.. right there.. right there.. RIGHT THERE!",
"Right there!",
"Faster, Faster!"
}
	
local fapsound ={
"physics/flesh/flesh_squishy_impact_hard1.wav",
"physics/flesh/flesh_squishy_impact_hard2.wav",
"physics/flesh/flesh_squishy_impact_hard3.wav",
"physics/flesh/flesh_squishy_impact_hard4.wav",
"weapons/crossbow/hitbod2.wav"
}

local SpeakMethod = {
"yell",
"ic",
"whisper"
}


function HaveSex(one,two)

local radius = Clockwork.config:Get("talk_radius"):Get();

 	if(!IsValid(two) and !two:IsPlayer()) then
 		return  Clockwork.player:Notify(one, "You need a partner")
 	end
	 -- Are the targets people?
 	if IsValid(one) and one:IsPlayer() then
 		one:Freeze(true)
 	end
 	-- Are the targets people?
 	if IsValid(two) and two:IsPlayer() then
 		two:Freeze(true)
 	end
 	

 	-- Sexy Time!
 	timer.Simple(5, function()
 		local e = {one,two}
 		-- Lets tell them
 		one.hasSex = true
 		two.hasSex = true
 		Clockwork.player:Notify(one, "You are having some fun!")
 		Clockwork.player:Notify(two, "You are having some fun!")

 		-- Person 2
 		timer.Create("Sex: " .. two:UniqueID(), 0.5, 120, function()
 		 	if math.random(1,3) <= 2 then  
 		 		if math.random(1,3) == 2 
 		 			then 
 		 		Clockwork.chatBox:AddInTargetRadius(two, table.Random(SpeakMethod), table.Random(MaleOrgasmText), two:GetPos(), radius);	
 		 		end  
 		 		if (two:GetGender() ==  GENDER_FEMALE) then
 		 		two:EmitSound(table.Random(FemaleOrgasm),100) 
 		 		end  
 		 		if (two:GetGender() ==  GENDER_MALE) then
 		 		two:EmitSound(table.Random(MaleOrgasm),100) 
 		 		end  
 		 	end 
 		end)
 		
 		
 		-- Person 1
 		timer.Create("Sex: " .. one:UniqueID(), 0.5, 120, function() 
 			if math.random(1,3) <= 2 then
				if math.random(1,4) == 2 then 
					Clockwork.chatBox:AddInTargetRadius(one, "ic", table.Random(MaleOrgasmText), one:GetPos(), radius);	
				end 
			 		 		if (one:GetGender() ==  GENDER_FEMALE) then
 		 		one:EmitSound(table.Random(FemaleOrgasm),100) 
 		 		end  
 		 		if (one:GetGender() ==  GENDER_MALE) then
 		 		one:EmitSound(table.Random(MaleOrgasm),100) 
 		 		end 
				if math.random(1,4) == 2 then 
					if math.random(1,5) == 3 
						then one:EmitSound(table.Random(fapsound),500,100) 
					end  
				end 
			end
		end)
 
  	timer.Simple(60, function() 
  		one.hasSex = false
		one:Freeze(false)	 
 		two.hasSex = false
 		two:Freeze(false)
					end
				)


 	-- End of timer at line 49
 	end)
end
