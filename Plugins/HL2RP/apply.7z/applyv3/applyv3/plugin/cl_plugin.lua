--[[
	© 2014 CloudSixteen & TheGarry. Do not edit, share
    or re-distribute the code without the permission of
    it's author (thegarry@teslacloud.net)
--]]

PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("Enable Apply Recognise", "apply_recognise_enable", "Enables /Apply Recognise System.");