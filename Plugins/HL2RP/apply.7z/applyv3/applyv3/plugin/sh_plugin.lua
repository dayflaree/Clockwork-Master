--[[
	© 2014 CloudSixteen & TheGarry. Do not edit, share
    or re-distribute the code without the permission of
    it's author (thegarry@teslacloud.net)
--]]

PLUGIN = PLUGIN;
Apply = Apply or {};
Apply.lang = Apply.lang or {};

Clockwork.kernel:IncludePrefixed("cl_plugin.lua")
Clockwork.kernel:IncludePrefixed("sh_config.lua")
Clockwork.kernel:IncludePrefixed("sv_plugin.lua")

function Apply.getDefaultLanguage(phrase)
	if ( Apply.defaultLanguage == 1 ) then
		Clockwork.kernel:IncludePrefixed("lang/sh_english.lua")
	elseif ( Apply.defaultLanguage == 2) then
		Clockwork.kernel:IncludePrefixed("lang/sh_russian.lua")
	else
		Clockwork.kernel:IncludePrefixed("lang/sh_english.lua")
	end;
end;