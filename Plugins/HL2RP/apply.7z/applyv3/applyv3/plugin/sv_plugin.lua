--[[
	� 2013 TheGarry =D
    Have fun with this plugin.
--]]

Clockwork.config:Add("apply_recognise_enable", true);