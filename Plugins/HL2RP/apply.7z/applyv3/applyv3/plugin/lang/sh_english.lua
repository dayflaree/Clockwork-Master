--[[
	© 2014 CloudSixteen & TheGarry. Do not edit, share
    or re-distribute the code without the permission of
    it's author (thegarry@teslacloud.net)
--]]

PLUGIN = PLUGIN;

-- English language phrases.
Apply.lang:myname         = "My name is ";
Apply.lang:andmycid       = ", and my CID is #";
Apply.lang:nocid          = "Sorry, but you do not have a CID!";
Apply.lang:astip          = "Says your name and CID in less formal way";

Apply.lang:iamunit        = "I am Unit ";
Apply.lang:nstip          = "Says your Name less formal way.";

Apply.lang:atip           = "Says your Name and CID.";

Apply.lang:unit           = "Unit ";
Apply.lang:ntip           = "Says your Name.";