--[[
	© 2014 CloudSixteen & TheGarry. Do not edit, share
    or re-distribute the code without the permission of
    it's author (thegarry@teslacloud.net)
--]]

PLUGIN = PLUGIN;

-- Russian language phrases.
Apply.lang:myname         = "Меня зовут ";
Apply.lang:andmycid       = ", а мой CID - #";
Apply.lang:nocid          = "Извините, но у Вас нет CID!";
Apply.lang:astip          = "Говорит Ваше имя и CID менее формально.";

Apply.lang:iamunit        = "Я Юнит ";
Apply.lang:nstip          = "Говорит Ваше имя менее формально.";

Apply.lang:atip           = "Говорит Ваше имя и CID.";

Apply.lang:unit           = "Юнит ";
Apply.lang:ntip           = "Говорит Ваше имя.";