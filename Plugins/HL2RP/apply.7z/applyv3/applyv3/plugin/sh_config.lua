--[[
	© 2014 CloudSixteen & TheGarry. Do not edit, share
    or re-distribute the code without the permission of
    it's author (thegarry@teslacloud.net)
--]]

PLUGIN = PLUGIN;

-- Available languages:
-- English (code - 1)
-- Russian (code - 2)
Apply.defaultLanguage    = 1;