local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:AddToSystem("[CCH] Apartment Prefix", "cch_apartment_prefix", "Set the apartment prefix used to detect what is an apartment.");
Clockwork.config:AddToSystem("[CCH] Shop Prefix", "cch_shop_prefix", "Set the shop prefix used to detect what is a shop.");
Clockwork.config:AddToSystem("[CCH] Close Doors on Restart", "cch_close_on_restart", "Auto-close all the doors that follow the apartment and shop prefixes.", 0, 1, 0);