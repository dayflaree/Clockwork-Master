local COMMAND = Clockwork.command:New("GetApartment");
COMMAND.tip = "Gets the assigned home of a character.";
COMMAND.text = "<string Name>";
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID( arguments[1] );
		local apartment = Clockwork.player:GetApartment(target)
		if (target) then
			if (apartment) then
				Clockwork.player:Notify(player, "The apartment of "..target:Name().." is: #"..apartment..".");
			else
				Clockwork.player:Notify(player, target:Name().." does not have an apartment assigned.");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();