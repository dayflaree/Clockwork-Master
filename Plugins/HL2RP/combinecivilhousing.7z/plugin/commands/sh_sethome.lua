local COMMAND = Clockwork.command:New("SetApartment");
COMMAND.tip = "Assign a character's apartment";
COMMAND.text = "<string Name> <int Apartment[2]>";
COMMAND.arguments = 2;

function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID( arguments[1] )
		local apartment = arguments[2];
		if (target) then
			if not (Schema:PlayerIsCombine(target)) then
				if (apartment and string.len( apartment ) == 3) then
					Clockwork.player:SetApartment(target, arguments[2]);
					Clockwork.player:Notify(player, "The apartment of "..target:Name().." is now: #"..apartment..".");
					Clockwork.player:Notify(target, "Your new apartment is: #"..apartment..". You already have full access to it.");
				else
					Clockwork.player:Notify(player, "The apartment you entered is not valid.");
				end;
			else
				Clockwork.player:Notify(player, "You cannot assign an apartment to a Combine!!");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();