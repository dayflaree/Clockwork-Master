local COMMAND = Clockwork.command:New("SetShop");
COMMAND.tip = "Assign a character's shop";
COMMAND.text = "<string Name> <int Shop[2]>";
COMMAND.arguments = 2;

function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID( arguments[1] )
		local shop = arguments[2];
		if (target) then
			if not (Schema:PlayerIsCombine(target)) then
				if (shop and string.len(shop) == 2) then
					Clockwork.player:SetShop(target, arguments[2]);
					Clockwork.player:Notify(player, "The shop of "..target:Name().." is now: #"..shop..".");
					Clockwork.player:Notify(target, "Your new shop is: #"..shop..". You already have full access to it.");
				else
					Clockwork.player:Notify(player, "The shop you entered is not valid.");
				end;
			else
				Clockwork.player:Notify(player, "You cannot assign a shop to a Combine!");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();