local COMMAND = Clockwork.command:New("GetShop");
COMMAND.tip = "Gets the assigned shop of a character.";
COMMAND.text = "<string Name>";
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		local target = Clockwork.player:FindByID( arguments[1] );
		local shop = Clockwork.player:GetShop(target)
		if (target) then
			if (shop) then
				Clockwork.player:Notify(player, "The shop of "..target:Name().." is: #"..shop..".");
			else
				Clockwork.player:Notify(player, target:Name().." does not have a shop assigned.");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
		end;
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();