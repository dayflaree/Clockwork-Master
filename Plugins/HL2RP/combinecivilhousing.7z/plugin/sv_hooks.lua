local PLUGIN = PLUGIN

function PLUGIN:PlayerSaveCharacterData(player, data)
	if (data["apartment"]) then
		data["apartment"] = data["apartment"];
	end;
	if (data["shop"]) then
		data["shop"] = data["shop"];
	end;
end;

function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["apartment"] = data["apartment"] or nil;
	data["shop"] = data["shop"] or nil;
end;

function PLUGIN:PlayerCanUnlockEntity(player, entity)
	if (Clockwork.entity:IsDoor(entity)) then
		local apartment = Clockwork.player:GetApartment(player)
		local shop = Clockwork.player:GetShop(player)
		local apartmentNumber = string.sub(Clockwork.entity:GetDoorName(entity), string.len(Clockwork.config:Get("cch_apartment_prefix"):Get())+1)
		local shopNumber = string.sub(Clockwork.entity:GetDoorName(entity), string.len(Clockwork.config:Get("cch_shop_prefix"):Get())+1)
		
		if (apartmentNumber == apartment or shopNumber == shop) then
			return true;
		end;
	end;
end;

function PLUGIN:PlayerCanLockEntity(player, entity)
	if (Clockwork.entity:IsDoor(entity)) then
		local apartment = Clockwork.player:GetApartment(player)
		local shop = Clockwork.player:GetShop(player)
		local apartmentNumber = string.sub(Clockwork.entity:GetDoorName(entity), string.len(Clockwork.config:Get("cch_apartment_prefix"):Get())+1)
		local shopNumber = string.sub(Clockwork.entity:GetDoorName(entity), string.len(Clockwork.config:Get("cch_shop_prefix"):Get())+1)
		
		if (apartmentNumber == apartment or shopNumber == shop) then
			return true;
		end;
	end;
end;

function PLUGIN:ClockworkInitPostEntity()
	if (Clockwork.config:Get("cch_close_on_restart"):Get()) then
		self:LockDoors();
	end
end;