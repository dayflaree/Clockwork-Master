PLUGIN.player = Clockwork.kernel:FindLibrary("Player");

function PLUGIN.player:GetApartment(player)
	local apartment = player:GetCharacterData("apartment");
	if (player) then
		if (apartment) then
			return apartment
		else
			return nil
		end;
	else
		return
	end;
end;

function PLUGIN.player:GetShop(player)
	local shop = player:GetCharacterData("shop");
	if (IsValid(player)) then
		if (shop) then
			return shop
		else
			return nil
		end;
	else
		return
	end;
end;

function PLUGIN.player:SetApartment(player, number)
	if (IsValid(player)) then
		return player:SetCharacterData("apartment", number)
	end;
end;

function PLUGIN.player:SetShop(player, number)
	if (IsValid(player)) then
		return player:SetCharacterData("shop", number)
	end;
end;