local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:Add("cch_apartment_prefix", "Apartment #", true);
Clockwork.config:Add("cch_shop_prefix", "Shop #", true);
Clockwork.config:Add("cch_close_on_restart", false, true, true);

function PLUGIN:LockDoors()
	for k, v in pairs(ents.GetAll()) do
		if (Clockwork.entity:IsDoor(v)) then
			if (string.sub(Clockwork.entity:GetDoorName(v), 1, string.len(Clockwork.config:Get("cch_apartment_prefix"):Get())) == Clockwork.config:Get("cch_apartment_prefix"):Get() or string.sub(Clockwork.entity:GetDoorName(v), 1, string.len(Clockwork.config:Get("cch_shop_prefix"):Get())) == Clockwork.config:Get("cch_shop_prefix"):Get()) then
				v:Fire("Lock", "", 0);
			end;
		end;
	end;
end;