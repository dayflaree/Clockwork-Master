
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "npc_turret_floor") then
		local faction = Clockwork.faction:FindByID(Clockwork.Client:GetFaction());

		if (faction.canDeactivateTurret) then
			options["Deactivate"] = "cw_turretDeactivate";
		end;
	end;
end;