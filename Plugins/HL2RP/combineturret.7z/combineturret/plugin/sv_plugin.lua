
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- A function to load the turrets.
function PLUGIN:LoadTurrets()
	local turrets = Clockwork.kernel:RestoreSchemaData("plugins/turrets/"..game.GetMap());
	
	for k, v in pairs(turrets) do
		local entity = ents.Create("npc_turret_floor");
		
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if (IsValid(physicsObject)) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the turrets.
function PLUGIN:SaveTurrets()
	local turrets = {};
	
	for k, v in pairs(ents.FindByClass("npc_turret_floor")) do
		local physicsObject = v:GetPhysicsObject();
		local moveable;
		
		if (IsValid(physicsObject)) then
			moveable = physicsObject:IsMoveable();
		end;
		
		turrets[#turrets + 1] = {
			angles = v:GetAngles(),
			moveable = moveable,
			position = v:GetPos()
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/turrets/"..game.GetMap(), turrets);
end;
