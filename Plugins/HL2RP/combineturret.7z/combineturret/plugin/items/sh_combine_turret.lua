
local ITEM = Clockwork.item:New();
ITEM.name = "Combine Turret";
ITEM.uniqueID = "combine_turret";
ITEM.cost = 100;
ITEM.model = "models/Combine_turrets/Floor_turret.mdl";
ITEM.weight = 10;
ITEM.factions = {FACTION_MPF, FACTION_OTA};
ITEM.category = "Turret";
ITEM.business = false;
ITEM.description = "A deactivated Combine Turret.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

function ITEM:OnCreateDropEntity(player, position)
	local turret = Clockwork.entity:CreateItem(player, self, position, player:GetAngles());

	local physicsObject = turret:GetPhysicsObject();
	if (IsValid(physicsObject)) then
		physicsObject:EnableMotion(false);
	end;

	return turret;
end;

if (CLIENT) then
	-- Called when the item entity's menu options are needed.
	function ITEM:GetEntityMenuOptions(entity, options)
		if (!IsValid(entity)) then
			return;
		end;

		local faction = Clockwork.faction:FindByID(Clockwork.Client:GetFaction());

		if (faction.canActivateTurret) then
			options["Activate"] = "cw_turretActivate";
		end;
	end;
end;

ITEM:Register();