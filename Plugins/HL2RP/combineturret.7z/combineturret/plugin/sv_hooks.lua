
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	self:LoadTurrets();
end;

-- Called just after data should be saved.
function PLUGIN:PostSaveData()
	self:SaveTurrets();
end;

function PLUGIN:EntityHandleMenuOption(player, entity, option, arguments)
	if (entity:GetClass() == "npc_turret_floor" and arguments == "cw_turretDeactivate") then
		if (Clockwork.player:GetFactionTable(player).canDeactivateTurret) then
			local pos = entity:GetPos();
			local angles = entity:GetAngles();

			entity:Remove();
			local itemEntity = Clockwork.entity:CreateItem(player, Clockwork.item:CreateInstance("combine_turret"), pos, angles);

			local physicsObject = itemEntity:GetPhysicsObject();
			if (IsValid(physicsObject)) then
				physicsObject:EnableMotion(false);
			end;
			
			player:EmitSound("items/battery_pickup.wav");

			return true;
		end;
	elseif (entity:GetClass() == "cw_item" and arguments == "cw_turretActivate") then
		if (Clockwork.player:GetFactionTable(player).canActivateTurret) then
			local turret = ents.Create("npc_turret_floor");

			turret:SetAngles(entity:GetAngles());
			turret:SetPos(entity:GetPos());

			entity:Remove();
			turret:Spawn();

			local physicsObject = turret:GetPhysicsObject();
			if (IsValid(physicsObject)) then
				physicsObject:EnableMotion(false);
			end;

			player:EmitSound("items/battery_pickup.wav");

			return true;
		end;
	end;
end;
