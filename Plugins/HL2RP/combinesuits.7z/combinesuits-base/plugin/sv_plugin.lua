local PLUGIN = PLUGIN;
local Schema = Schema;

function PLUGIN:PutSuitOn(player)
	local CivviName = player:Name();
	local rank = player:GetCharacterData("CombineRank");
	local division = player:GetCharacterData("Division");
	local CID = player:GetSharedVar("citizenID");
	local storedCivviName = player:GetCharacterData("CitizenName");
	
	if (storedCivviName) then
		CivviName = storedCivviName;
	end;

	if (rank != nil and division != nil) then -- Do they have a rank and division?
		player:SetCharacterData("CitizenName", CivviName); 							-- Store their normal name for later
		player:SetCharacterData( "customclass", "Civil Protection" );				-- Set their custom class
		Clockwork.player:SetName(player, "MPF-"..division.."."..rank.."."..CID); 	-- Give them an MPF formated name with their CID as their digits.
	elseif (rank != nil) then 														-- If they don't have both a rank and division, do they at least have a rank?
		player:SetCharacterData("CitizenName", CivviName); 							-- Store their normal name for later
		player:SetCharacterData( "customclass", "Civil Protection" ); 				-- Set their custom class
		Clockwork.player:SetName(player, "MPF-"..rank.."."..CID); 					-- Give them an MPF formated name with their CID as their digits.
	else 																			-- If they have neither, make them a cr00t!
		player:SetCharacterData("CitizenName", CivviName); 							-- Store their normal name for later
		player:SetCharacterData("CombineRank", "RCT"); 								-- Set their rank.
		player:SetCharacterData( "customclass", "Civil Protection" ); 				-- Set their custom class
		Clockwork.player:SetName(player, "MPF-"..rank.."."..CID); 					-- Give them an MPF formated name with their CID as their digits.
	end;
	
	PLUGIN:SetCombineSuitClass(player)
end;

function PLUGIN:TakeSuitOff(player)
	local CivviName = player:GetCharacterData("CitizenName");
	player:SetCharacterData( "customclass", "Citizen" ); 	-- Set their custom class to Citizen
	Clockwork.player:SetName(player, CivviName); 			-- Give 'em back their old name.
	Clockwork.class:Set(player, CLASS_CITIZEN);
end;

function PLUGIN:SetCombineSuitClass(player)
	local rank = player:GetCharacterData("CombineRank");
	
	if PLUGIN:PlayerIsElite(player) then
		Clockwork.class:Set(player, CLASS_EMP);
	elseif rank == "RCT" then
		Clockwork.class:Set(player, CLASS_MPR);
	else
		Clockwork.class:Set(player, CLASS_MPU);										-- Thanks to crater for the class setting idea.
	end;
end;

function PLUGIN:PlayerIsElite(player)
	local eliteClass = {
						"CmD",
						"SeC",
						"OfC",
						"SeC",
						"DvL"
						};
	local playerRank = player:GetCharacterData( "CombineRank" )
	
	if table.HasValue( eliteClass, playerRank ) then
		return true;
	else
		return false;
	end;
end;
--[[
This function checks the player's rank aginst all ranks used by MPF.
To edit this, simply replace the ranks with your own. IF you want to add another rank, place this code:
elseif (rank == "RANK HERE") then
		player:SetCharacterData("CombineRank", "NEXT RANK UP");
place it in where the rank falls amung the listing of ranks.

This is called when using the /Promote command.
--]]
function PLUGIN:PromoteMPF(player)
	local rank = player:GetCharacterData("CombineRank");
	if (rank == "RCT") then
		player:SetCharacterData("CombineRank", "05");
	elseif (rank == "05") then
		player:SetCharacterData("CombineRank", "04");
	elseif (rank == "04") then
		player:SetCharacterData("CombineRank", "03");
	elseif (rank == "03") then
		player:SetCharacterData("CombineRank", "02");
	elseif (rank == "02") then
		player:SetCharacterData("CombineRank", "01");
	elseif (rank == "01") then
		player:SetCharacterData("CombineRank", "OfC");
	elseif (rank == "OfC") then
		player:SetCharacterData("CombineRank", "EpU");
	elseif (rank == "EpU") then
		player:SetCharacterData("CombineRank", "DvL");
	elseif (rank == "DvL") then
		player:SetCharacterData("CombineRank", "SeC");
	end;
end;
-- This is the same as PromoteMPF, but in the inverse.
-- It's called with the /Demote command.
function PLUGIN:DemoteMPF(player)
	local rank = player:GetCharacterData("CombineRank");
	if (rank == "SeC") then
		player:SetCharacterData("CombineRank", "DvL");
	elseif (rank == "DvL") then
		player:SetCharacterData("CombineRank", "EpU");
	elseif (rank == "EpU") then
		player:SetCharacterData("CombineRank", "OfC");
	elseif (rank == "OfC") then
		player:SetCharacterData("CombineRank", "01");
	elseif (rank == "01") then
		player:SetCharacterData("CombineRank", "02");
	elseif (rank == "02") then
		player:SetCharacterData("CombineRank", "03");
	elseif (rank == "03") then
		player:SetCharacterData("CombineRank", "04");
	elseif (rank == "04") then
		player:SetCharacterData("CombineRank", "05");
	elseif (rank == "05") then
		player:SetCharacterData("CombineRank", "RCT");
	end;
end;

-- A function to check if a player is Combine.
function Schema:PlayerIsCombine(player, bHuman)
	if (IsValid(player) and player:GetCharacter()) then
		local hasSuit = player:GetSharedVar("metropoliceSuit");
		local faction = player:GetFaction();
		
		if (self:IsCombineFaction(faction)) then
			if (bHuman) then
				if (faction == FACTION_MPF) then
					return true;
				end;
			elseif (bHuman == false) then
				if (faction == FACTION_MPF) then
					return false;
				else
					return true;
				end;
			else
				return true;
			end;
		elseif (hasSuit) then
			return true;
		end;
	end;
end;