local PLUGIN = PLUGIN;
local Schema = Schema;

-- A function to get whether a player is Combine.
function Schema:PlayerIsCombine(player, bHuman)
	if (!IsValid(player)) then
		return;
	end;

	local faction = player:GetFaction();
	local hasSuit = Clockwork.Client:GetSharedVar("metropoliceSuit");
	if (self:IsCombineFaction(faction)) then
		if (bHuman) then
			if (faction == FACTION_MPF) then
				return true;
			end;
		elseif (bHuman == false) then
			if (faction == FACTION_MPF) then
				return false;
			else
				return true;
			end;
		else
			return true;
		end;
	elseif hasSuit then
		return true;
	end;
end;