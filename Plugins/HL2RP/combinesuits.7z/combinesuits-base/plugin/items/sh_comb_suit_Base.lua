local PLUGIN = PLUGIN;

local ITEM = Clockwork.item:New("clothes_base", true);
	ITEM.name = "Combine Clothes Base";
	ITEM.replacement = "models/police.mdl";
	ITEM.weight = 5;
	ITEM.business = false;
	ITEM.protection = 0.5;
	ITEM.description = "The Enlisted Patrol Armor is the most common Armor System employed by the Union.";
	
	-- Called to get whether a player has the item equipped.
	function ITEM:HasPlayerEquipped(player, arguments)
		return player:GetSharedVar("metropoliceSuit");
	end;
	
	-- Called when a player has unequipped the item.
	function ITEM:OnPlayerUnequipped(player, arguments)
		PLUGIN:TakeSuitOff(player);
		player:SetSharedVar("metropoliceSuit", false);
		player:SetCharacterData("metropoliceSuit", false);
		player:RemoveClothes();
		player:RebuildInventory();
	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position)
		if (player:GetSharedVar("metropoliceSuit") and player:HasItem(self.uniqueID) == 1) then
			Clockwork.player:Notify(player, "You cannot drop this while you are wearing it!");
			
			return false;
		end;
	end;
	
	-- Called when a player uses the item.
	function ITEM:OnUse(player, itemEntity)
		if ( player:Alive() and !player:IsRagdolled() ) then
			PLUGIN:PutSuitOn(player);
			player:SetSharedVar("metropoliceSuit", true);
			player:SetCharacterData("metropoliceSuit", true);
			player:SetClothesData(self);
			player:RebuildInventory();
	
			if (itemEntity) then
				return true;
			end;
		else
			Clockwork.player:Notify(player, "You don't have permission to do this right now!");
		end;
		
		return false;
	end;
ITEM:Register();