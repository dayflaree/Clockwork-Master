local PLUGIN = PLUGIN;

-- Called when the local player attempts to see a class.
function PLUGIN:PlayerCanSeeClass(class)
	local hasSuit = Clockwork.Client:GetSharedVar("metropoliceSuit");
	local isCombine = Schema:PlayerIsCombine(Clockwork.Client);
	if (class.index == CLASS_CITIZEN and hasSuit) then
		return false;
	elseif (class.index == CLASS_MPU and !isCombine) then
		return false;
	elseif (class.index == CLASS_EMP and !isCombine) then
		return false;
	elseif (class.index == CLASS_MPR and !isCombine) then
		return false;
	end;
end;