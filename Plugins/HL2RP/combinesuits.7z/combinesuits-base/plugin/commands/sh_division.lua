local PLUGIN = PLUGIN

local COMMAND = Clockwork.command:New("SetDivision");
COMMAND.tip = "Set an MPF Character's Division (They must be wearing the Suit Item).";
COMMAND.text = "<string Name> <string Division>";
COMMAND.arguments = 1; -- Credit to crater for finding a bug here.
COMMAND.optionalArguments = 1;
-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] );
	local MPFSuit = target:GetSharedVar("metropoliceSuit");
	if (Schema:PlayerIsCombine(player)) then
		if (Schema:IsPlayerCombineRank( player, {"DvL", "SeC", "OfC", "EpU", "CmD"} ) or player:GetFaction() == FACTION_OTA or player:IsAdmin() ) then
			if (target) then
				if (MPFSuit) then
					local customDvL = arguments[2];
					if (customDvL) then
						target:SetCharacterData("Division", customDvL);
						PLUGIN:PutSuitOn(target);
						Clockwork.player:Notify(player, target:Name().." has had their divsion set to "..customDvL..".");
						Clockwork.player:Notify(target, player:Name().." has set your division to "..customDvL..".");
					else
						target:SetCharacterData("Division", nil);
						PLUGIN:PutSuitOn(target);
						Clockwork.player:Notify(player, target:Name().." has had their division cleared.");
						Clockwork.player:Notify(target, player:Name().." has cleared your division.");
					end;
				else
					Clockwork.player:Notify(player, arguments[1].." is not wearing a Combine Uniform!");
				end;
			else
				Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
			end;
		end;
	else
		Clockwork.player:Notify(player, "You are not high ranked enough!");
	end;
end;

COMMAND:Register();