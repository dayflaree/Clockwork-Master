local PLUGIN = PLUGIN

local COMMAND = Clockwork.command:New("Promote");
COMMAND.tip = "Promote an MPF Character (They must be wearing the Suit Item).";
COMMAND.text = "<string Name> <string Rank>";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] );
	local MPFSuit = target:GetSharedVar("metropoliceSuit");
	if (Schema:PlayerIsCombine(player)) then
		if (Schema:IsPlayerCombineRank( player, {"DvL", "SeC", "OfC", "EpU", "CmD"} ) or player:GetFaction() == FACTION_OTA or player:IsAdmin()) then
			if (target) then
				if (MPFSuit) then
					local customRank = arguments[2];
					if (customRank) then
						target:SetCharacterData("CombineRank", customRank);
						PLUGIN:PutSuitOn(target);
						Clockwork.player:Notify(player, target:Name().." has been promoted to "..customRank..".");
						Clockwork.player:Notify(target, player:Name().." has promoted you!");
					else
						PLUGIN:PromoteMPF(target);
						PLUGIN:PutSuitOn(target);
						Clockwork.player:Notify(player, target:Name().." has been promoted.");
						Clockwork.player:Notify(target, player:Name().." has promoted you!");
					end;
				else
					Clockwork.player:Notify(player, arguments[1].." is not wearing a Combine Uniform!");
				end;
			else
				Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
			end;
		end;
	else
		Clockwork.player:Notify(player, "You are not high ranked enough!");
	end;
end;

COMMAND:Register();