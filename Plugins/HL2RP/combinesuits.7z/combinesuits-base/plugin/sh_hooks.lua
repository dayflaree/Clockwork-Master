local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("metropoliceSuit", true);
	playerVars:String("CombineRank");
end;