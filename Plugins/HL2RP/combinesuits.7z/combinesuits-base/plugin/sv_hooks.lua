local PLUGIN = PLUGIN;
local Schema = Schema;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar("metropoliceSuit", player:GetCharacterData("metropoliceSuit"));
	player:SetSharedVar("CombineRank", player:GetCharacterData("CombineRank"));
end;


function PLUGIN:PlayerCharacterInitialized(player)
	local hasSuit = player:GetSharedVar("metropoliceSuit");
	local faction = player:GetFaction();
	
	if hasSuit then
		PLUGIN:SetCombineSuitClass(player)
	elseif faction == FACTION_CITIZEN then
		Clockwork.class:Set(player, CLASS_CITIZEN);
	end;
end;
-- Called when chat box info should be adjusted.
function Schema:ChatBoxAdjustInfo(info)
	if (info.class != "ooc" and info.class != "looc") then
		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
			if (string.sub(info.text, 1, 1) == "?") then
				info.text = string.sub(info.text, 2);
				info.data.anon = true;
			end;
		end;
	end;
	
	if (info.class == "ic" or info.class == "yell" or info.class == "radio" or info.class == "whisper" or info.class == "request") then
		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
			local playerIsCombine = Schema:PlayerIsCombine(info.speaker);
			local hasSuit = info.speaker:GetSharedVar("metropoliceSuit");
			
			if (playerIsCombine and Schema:IsPlayerCombineRank(info.speaker, "SCN")) then
				for k, v in pairs(self.voices.stored.dispatchVoices) do
					if (string.lower(info.text) == string.lower(v.command)) then
						local voice = {
							global = false,
							volume = 90,
							sound = v.sound
						};
						
						if (info.class == "request" or info.class == "radio") then
							voice.global = true;
						elseif (info.class == "whisper") then
							voice.volume = 80;
						elseif (info.class == "yell") then
							voice.volume = 100;
						end;
						
						info.text = "<:: "..v.phrase;
						info.voice = voice;
						
						return true;
					end;
				end;
			else
				for k, v in pairs(self.voices.stored.normalVoices) do
					if ((v.faction == "Combine" and playerIsCombine) or (v.faction == "Combine" and hasSuit) or (v.faction == "Human" and !playerIsCombine and !hasSuit)) then
						if (string.lower(info.text) == string.lower(v.command)) then
							local voice = {
								global = false,
								volume = 80,
								sound = v.sound
							};
							
							if (v.female and info.speaker:QueryCharacter("gender") == GENDER_FEMALE) then
								voice.sound = string.Replace(voice.sound, "/male", "/female");
							end;
							
							if (info.class == "request" or info.class == "radio") then
								voice.global = true;
							elseif (info.class == "whisper") then
								voice.volume = 60;
							elseif (info.class == "yell") then
								voice.volume = 100;
							end;
							
							if (playerIsCombine) then
								info.text = "<:: "..v.phrase;
							else
								info.text = v.phrase;
							end;
							
							info.voice = voice;
							
							return true;
						end;
					end;
				end;
			end;
			
			if (playerIsCombine) then
				if (string.sub(info.text, 1, 4) != "<:: ") then
					info.text = "<:: "..info.text;
				end;
			end;
		end;
	elseif (info.class == "dispatch") then
		for k, v in pairs(self.voices.stored.dispatchVoices) do
			if (string.lower(info.text) == string.lower(v.command)) then
				Clockwork.player:PlaySound(nil, v.sound);
				
				info.text = v.phrase;
				
				return true;
			end;
		end;
	end;
end;

-- lol this is broken in default hl2rp
function PLUGIN:PlayerCanChangeClass(player, class)
	local hasSuit = player:GetCharacterData("metropoliceSuit");
	local isCombine Schema:PlayerIsCombine(player);
	local faction = player:GetFaction();
	--[[
	if hasSuit then
		return false;
	elseif faction == FACTION_CITIZEN and class.name = "Metropolice Unit" then
		return false;
	end;
	--]]
	if (isCombine) then
		if (class.name == "Citizen" and hasSuit) then
			Clockwork.player:Notify(player, "You cant become a citizen while wearing a suit! (That's how it works in real life.)");
			return false;
		end;
	elseif (class.name == "Metropolice Unit") then
		Clockwork.player:Notify(player, "You cant become a Metropolice Unit while a citizen!");
		return false;
	elseif (class.name == "Elite Metropolice") then
		Clockwork.player:Notify(player, "You cant become a Metropolice Unit while a citizen!");
		return false;
	elseif (class.name == "Metropolice Recruit") then
		Clockwork.player:Notify(player, "You cant become a Metropolice Unit while a citizen!");
		return false;
	end;
end;