
local PLUGIN = PLUGIN;

PLUGIN.hunterIdleSounds = {
	"npc/ministrider/hunter_idle1.wav",
	"npc/ministrider/hunter_idle2.wav",
	"npc/ministrider/hunter_idle3.wav"
};

