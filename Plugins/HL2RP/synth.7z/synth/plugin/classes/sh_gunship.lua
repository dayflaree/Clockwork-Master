local CLASS = Clockwork.class:New("Gunship");

CLASS.color = Color(200, 80, 80, 255);
CLASS.factions = {FACTION_SYNTH};
CLASS.isDefault = true;
CLASS.wagesName = "Supplies";
CLASS.description = "An enormous flying beast, with a rotor for a tail and a gun for a face.";
CLASS.defaultPhysDesc = "An enormous flying beast, with a rotor for a tail and a gun for a face.";
CLASS.code = "GSP";
CLASS.morph = "gunship";

CLASS_STRIDER = CLASS:Register();