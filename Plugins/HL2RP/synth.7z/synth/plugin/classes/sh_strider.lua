local CLASS = Clockwork.class:New("Strider");

CLASS.color = Color(200, 80, 80, 255);
CLASS.factions = {FACTION_SYNTH};
CLASS.isDefault = false;
CLASS.wagesName = "Supplies";
CLASS.description = "A towering being, with a small rotating gun on its head, and a larger cannon on its underside.";
CLASS.defaultPhysDesc = "A towering being, with a small rotating gun on its head, and a larger cannon on its underside.";
CLASS.code = "STR";
CLASS.morph = "strider";

CLASS_STRIDER = CLASS:Register();