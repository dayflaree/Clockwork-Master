local FACTION = Clockwork.faction:New("Synthetic")
FACTION.models = {
		male = {"models/Combine_Soldier.mdl"},
		female = {"models/Combine_Soldier.mdl"}
};

-- NPC Relations, where you can set NPC's that are supposed to be friendly with the faction.
FACTION.npcRelations = {
		["npc_zombie"] = D_HT,
		["npc_poisonzombie"] = D_HT,
		["npc_zombie_torso"] = D_HT,
		["npc_headcrab_black"] = D_HT,
		["npc_headcrab"] = D_HT,
		["npc_fastzombie_torso"] = D_HT,
		["npc_fastzombie"] = D_HT,
		["npc_headcrab_fast"] = D_HT,
		["npc_antlion"] = D_NU,
		["npc_antlionguard"] = D_NU,
		["npc_turret_floor"] = D_NU,
	    ["npc_combine_camera"] = D_NU,
	    ["npc_turret_ceiling"] = D_NU,
	    ["npc_rollermine"] = D_NU,
	    ["npc_helicopter"] = D_NU,
	    ["npc_combinegunship"] = D_NU,
	    ["npc_strider"] = D_NU
};

-- Decides if this is supposed to be a 'combine' faction.
FACTION.isCombineFaction = true;

-- N/A, Leave true.
FACTION.useFullName = true;

-- Sets it to be a default or not, if true you need to be assigned the whitelist, if false, it will be given to everyone.
FACTION.whitelist = true;

-- Determines if the faction character should spawn with a relocation coupon or not.
FACTION.relocationCoupon = false;

-- Switch to determine if the white list can access /datafile
FACTION.canUseDataFiles = true;

-- Removes hunger and thirst from the faction
FACTION.noNeeds = true;

-- If set to true, everyone can see the characters name, without the F2 function.
FACTION.recognise = true;

-- If set to true, Combine Visor will be enabled
FACTION.combineVisor = true;


--Disables character creation on main server
--FACTION.cannotCreateOnMain = true;

--Lists servers the whitelist can be created on.
FACTION.serverCharacterCreationWhitelist = {"canals", "outlands", "coast"};

-- The default radio channels this faction has access to. 
FACTION.listenChannels = {
	["cp_main"] = 1,
	["combine"] = 1,
	["overwatch"] = 1
};

-- Called when a player's name should be assigned for the faction.
function FACTION:GetName(player, character)
	local unitID = math.random(1, 999);

	return "C17:#-T.SYNTH-ERR-" .. Clockwork.kernel:ZeroNumberToDigits(unitID, 3);
end;

-- Called when a player's model should be assigned for the faction.
function FACTION:GetModel(player, character)
	return self.models.male[1];
end;

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (faction.name == FACTION_MPF) then
		Clockwork.player:SetName(player, string.gsub(player:QueryCharacter("name"), ".+(%d%d%d%d%d)", "C17:#-T.SYNTH-ERR-%1"), true);
	else
		Clockwork.player:SetName(player, self:GetName( player, player:GetCharacter() ), true);
	end;

	player:SetCharacterData("model", self.models.male[1], true);
end;

FACTION_SYNTH = FACTION:Register();
