
local PLUGIN = PLUGIN;

 -- Called when a player should show on the scoreboard.
function PLUGIN:PlayerShouldShowOnScoreboard(player)
	local clientFaction = Clockwork.Client:GetFaction();
	local playerFaction = player:GetFaction();
	
	if (playerFaction == clientFaction) then
		return;
	end;

	if (playerFaction == FACTION_HUNTER or playerFaction == FACTION_SYNTH) then
		return false;
	end;
end;

-- Called when a player's typing display position is needed.
function PLUGIN:GetPlayerTypingDisplayPosition(player)
	local faction = player:GetFaction();
	
	if (faction == FACTION_HUNTER) then
		return player:GetPos() + Vector(0, 0, 65);
	end;
end;


function PLUGIN:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	--If hunter, don't play default sound.
	if (player:GetFaction() == FACTION_HUNTER or player:GetFaction() == FACTION_SYNTH) then
		return true;
	end;
end;