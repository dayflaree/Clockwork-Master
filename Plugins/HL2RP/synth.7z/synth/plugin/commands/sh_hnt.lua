
local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Hnt");
COMMAND.tip = "Communicate with Combine forces around you";
COMMAND.text = "<string Message>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");
	
	if (text == "") then
		Clockwork.player:Notify(player, "You did not specify enough text!");
		return;
	end;
	
	if (player:GetFaction() != FACTION_HUNTER) then	
		Clockwork.player:Notify(player, "You are not a hunter");
		return;
	end

	local listeners = {};
	
	for k, v in pairs(_player.GetAll()) do
		if (v:GetFaction() != FACTION_HUNTER and v:GetFaction() != FACTION_OTA) then
			continue;
		end;

		listeners[#listeners + 1] = v;
	end;

	Clockwork.chatBox:Add(listeners, player, "ic", text);
	player:EmitSound("npc/ministrider/hunter_alert"..math.random(1, 3)..".wav", 75);
end;

COMMAND:Register();
