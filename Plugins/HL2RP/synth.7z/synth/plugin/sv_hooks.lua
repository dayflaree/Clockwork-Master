
local PLUGIN = PLUGIN;

-- Called when a player attempts to say something out-of-character.
function PLUGIN:PlayerCanSayOOC(player, text)
	local faction = player:GetFaction();

	if (faction == FACTION_HUNTER or faction == FACTION_SYNTH) then
		Clockwork.player:Notify(player, "Characters in your faction cannot use out-of-character discussion.");
		return false;
	end;
end;

-- Called when a player's death sound should be played.
function PLUGIN:PlayerPlayDeathSound(player, gender)
	if (player:GetFaction() == FACTION_HUNTER) then
        return "npc/ministrider/hunter_die2.wav";
	end;
end;

-- Called when a player's pain sound should be played.
function PLUGIN:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
	if(player:GetFaction() == FACTION_HUNTER)	then
	    return "npc/ministrider/hunter_pain"..math.random(2, 4)..".wav";	   
	end;
end;


-- Called when an entity takes damage.
function PLUGIN:EntityTakeDamage(entity, damageInfo)
	local player = Clockwork.entity:GetPlayer(entity);
	
	if (player) then
		if (player:GetFaction() == FACTION_HUNTER and damageInfo:IsDamageType(DMG_FALL)) then
			damageInfo:ScaleDamage(0);
		end;
	end;
end;

-- Called when a player's footstep sound should be played.
function PLUGIN:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	if (player:GetFaction() == FACTION_HUNTER) then	
	    player:EmitSound("npc/ministrider/ministrider_footstep"..math.random(1, 5)..".wav", 75);
		return true;
	end;	
end;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	if (player:GetFaction() == FACTION_HUNTER) then

		local bIsOnGround = player:IsOnGround();
		--If not on ground and not in observer, play jump sound.
		if (!bIsOnGround and player:Alive() and player:GetMoveType() == MOVETYPE_WALK and !player.hasJumped) then
			player:EmitSound("npc/ministrider/ministrider_footstep"..math.random(1, 5)..".wav", 120) --Sound Level 100, Pitch Precent 50.
			player.hasJumped = true;
		elseif(bIsOnGround and player.hasJumped) then
			player.hasJumped = false;
			player:EmitSound("npc/ministrider/ministrider_footstep"..math.random(1, 2)..".wav", 125);
			player:EmitSound("npc/ministrider/ministrider_footstep"..math.random(3, 4)..".wav", 30);
		end;
		
		if (!self.cwNextChatterEmit) then
			self.cwNextChatterEmit = curTime + math.random(5, 15);
		end;
		
		if (curTime >= self.cwNextChatterEmit and !player:IsNoClipping() and player:Alive()) then
			self.cwNextChatterEmit = nil;
			
			player:EmitSound(
				self.hunterIdleSounds[ math.random(1, #self.hunterIdleSounds) ], 60
			);
		end;

		infoTable.jumpPower = Clockwork.config:Get("jump_power"):Get() * 2;
		infoTable.runSpeed = Clockwork.config:Get("run_speed"):Get() * 3;
		
		--If going backwards, set running speed to normal again. (Clockwork halves it)
		if (player:KeyDown(IN_BACK)) then
			infoTable.runSpeed = infoTable.runSpeed * 2;
		end;
		
	end;
end;

-- Called when a player's character creation info should be adjusted.
function PLUGIN:PlayerAdjustCharacterCreationInfo(player, info, data)

	if (data.faction and data.faction == FACTION_HUNTER) then
		for k, v in pairs(data.attributes) do
			local attributeTable = Clockwork.attribute:FindByID(k);
			
			if (attributeTable and attributeTable.isOnCharScreen) then
				local uniqueID = attributeTable.uniqueID;
				local maximum = attributeTable.maximum;
				
				info.attributes[uniqueID].amount = maximum;
			end;
		end;
	end;
end;

-- Called when a player's character default weapons should be given.
function PLUGIN:PlayerGiveWeapons(player)
	if player:GetFaction() == FACTION_HUNTER then
		Clockwork.player:GiveSpawnWeapon(player, "cw_flachettegun");
	end;
end;