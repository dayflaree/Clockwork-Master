if SERVER then
	AddCSLuaFile("shared.lua")
end

if (CLIENT) then
	SWEP.Slot = 5;
	SWEP.SlotPos = 3;
	SWEP.DrawAmmo = true;
	SWEP.PrintName = "Flechette";
	SWEP.DrawCrosshair = false;
end

SWEP.Author			        = "Ekt0"
SWEP.Instructions           = "Left click to shoot\nRight click to bust doors.";
SWEP.AdminSpawnable         = false;
SWEP.Spawnable		        = true;
SWEP.ViewModel              = "models/weapons/c_smg1.mdl"
SWEP.WorldModel             = ""
SWEP.UseHands				= true;
SWEP.Primary.Automatic		= false;
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false;
SWEP.Secondary.Ammo			= "none"

SWEP.Slot					= 1
SWEP.SlotPos				= 2

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.DrawAmmo				= false
SWEP.AdminOnly				= true
SWEP.NeverRaised = true;

game.AddParticles( "particles/hunter_flechette.pcf" )
game.AddParticles( "particles/hunter_projectile.pcf" )

local ShootSound = Sound( "NPC_Hunter.FlechetteShoot" )

function SWEP:Initialize()

	self:SetHoldType( "smg" )

end

function SWEP:Reload()
end

function SWEP:PrimaryAttack()

	self:SetNextPrimaryFire( CurTime() + 0.1 )

	self:EmitSound( ShootSound )
	self:ShootEffects( self )
	self.Owner:SetAnimation( ACT_RANGE_ATTACK2 )
	
	if ( !SERVER ) then return end
	
	local Forward = self.Owner:EyeAngles():Forward()
	local Right = self.Owner:EyeAngles():Right()
	
	local ent = ents.Create( "hunter_flechette" )
	if ( IsValid( ent ) ) then
	
		ent:SetPos( self.Owner:GetShootPos() + Forward * 32 )
		ent:SetAngles( self.Owner:EyeAngles() )
		ent:Spawn()
		if(self.Owner:KeyDown(IN_RUN)) then
			ent:SetVelocity(Forward * (math.random(1800, 2000)) + Right * (math.random(-100, 100)))
		else
			ent:SetVelocity( Forward * 2000 )
		end;
		ent:SetOwner( self.Owner )

	end

end

function SWEP:ShouldDropOnDie()

	return false

end

function SWEP:SecondaryAttack()
	objct = self.Owner:GetEyeTraceNoCursor().Entity
	if objct != nil and objct:GetPos():Distance(self.Owner:GetPos()) < 200 and objct:GetClass() == "prop_door_rotating" then
		self:EmitSound( "npc/ministrider/hunter_prestrike1.wav" )
		
		timer.Simple( 1.5, function()
			if (SERVER) then
			Schema:BustDownDoor(self.Owner, objct, (objct:GetPos() - self.Owner:GetPos() ):GetNormal() * 30000)
			end
		end)
	end
end