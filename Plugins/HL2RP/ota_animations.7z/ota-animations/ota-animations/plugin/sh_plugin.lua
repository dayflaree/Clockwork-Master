local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.animation.stored.combineOverwatch["stand_fist_walk"] = "WalkUnarmed_all";
Clockwork.animation.stored.combineOverwatch["stand_smg_walk"] = "WalkEasy_all";
