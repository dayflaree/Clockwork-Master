
These sounds are released under discretion of Valve Corporation. Valve at any time as the original owners of these sound files can request me to remove/identify themselves in these files.
However, these files are also are created by TRURASCALZ and they request to be credited if used.