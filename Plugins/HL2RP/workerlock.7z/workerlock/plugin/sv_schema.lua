local PLUGIN = PLUGIN;

-- A function to load the worker locks.
function PLUGIN:LoadworkerLocks()
	local workerLocks = Clockwork.kernel:RestoreSchemaData( "plugins/workerlocks/"..game.GetMap() );
	
	for k, v in pairs(workerLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16)[1];
		
		if (IsValid(entity)) then
			local workerLock = self:ApplyworkerLock(entity);
			
			if (workerLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				workerLock:SetLocalAngles(v.angles);
				workerLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					workerLock:Unlock();
				else
					workerLock:Lock();
				end;
			end;
		end;
	end;
end;

-- A function to save the worker locks.
function PLUGIN:SaveworkerLocks()
	local workerLocks = {};
	
	for k, v in pairs( ents.FindByClass("cw_workerlock") ) do
		if (IsValid(v.entity)) then
			workerLocks[#workerLocks + 1] = {
				key = Clockwork.entity:QueryProperty(v, "key"),
				locked = v:IsLocked(),
				angles = v:GetLocalAngles(),
				position = v:GetLocalPos(),
				uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID"),
				doorPosition = v.entity:GetPos()
			};
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/workerlocks/"..game.GetMap(), workerLocks);
end;

-- A function to apply a worker lock.
function PLUGIN:ApplyworkerLock(entity, position, angles)
	local workerLock = ents.Create("cw_workerlock");
	
	workerLock:SetParent(entity);
	workerLock:SetDoor(entity);
	
	if (position) then
		if (type(position) == "table") then
			workerLock:SetLocalPos( Vector(-1.0313, 43.7188, -1.2258) );
			workerLock:SetPos( workerLock:GetPos() + (position.HitNormal * 4) );
		else
			workerLock:SetPos(position);
		end;
	end;
	
	if (angles) then
		workerLock:SetAngles(angles);
	end;
	
	workerLock:Spawn();
	
	if (IsValid(workerLock)) then
		return workerLock;
	end;
end;

-- A function to bust down a door.
function PLUGIN:BustDownDoor(player, door, force)
	door.bustedDown = true;
	
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	if (IsValid(door.workerLock)) then
		door.workerLock:Explode();
		door.workerLock:Remove();
	end;
	
	if (IsValid(door.breach)) then
		door.breach:BreachEntity();
	end;
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		if (!force) then
			if (IsValid(player)) then
				physicsObject:ApplyForceCenter( (door:GetPos() - player:GetPos() ):GetNormal() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	Clockwork.entity:Decay(fakeDoor, 300);
	
	Clockwork.kernel:CreateTimer("reset_door_"..door:EntIndex(), 300, 1, function()
		if (IsValid(door)) then
			door.bustedDown = nil;
			
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
		end;
	end);
end;