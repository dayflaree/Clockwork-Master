local PLUGIN = PLUGIN;


cflag = "J"; --Put the flag (can be multiple characters) of choice here. Requires restart to take effect.
vflag = "K"; --Flag for VC's.

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");

PLUGIN.randomNonCombineDisplayLines = {
	"Transmitting physical transition vector...",
	"Modulating external temperature levels...",
	"Parsing view ports and data arrays...",
	"Translating Anti-Union practicalities...",
	"Updating biosignal co-ordinates...",
	"Parsing Clockwork protocol messages...",
	"Downloading recent dictionaries...",
	"Pinging connection to network...",
	"Updating mainframe connection...",
	"Synchronizing locational data...",
	"Translating radio messages...",
	"Emptying outgoing pipes...",
	"Sensoring proximity...",
	"Pinging loopback...",
	"Idle connection...",
  "ERROR: 0x00019a IS A NULL ADDRESS!",
  "ERROR: MISMATCHED ENCRYPTION KEYS...",
  "Attempting Global database reconnection...",
  "Failed to re-connect to database at 0x0841AC0..."
};


Clockwork.flag:Add(cflag, "Combine Outfit Flag", "Access to Combine Overlay and Vo-coder beeps.");
Clockwork.flag:Add(vflag, "Combine VC's Flag", "Access to Combine Voice Commands.")
