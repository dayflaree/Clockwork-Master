
Clockwork.kernel:AddFile("sound/common/off1.mp3");
Clockwork.kernel:AddFile("sound/common/off2.mp3");
Clockwork.kernel:AddFile("sound/common/off3.mp3");
Clockwork.kernel:AddFile("sound/common/off4.mp3");
Clockwork.kernel:AddFile("sound/common/off5.mp3");
Clockwork.kernel:AddFile("sound/common/off6.mp3");
Clockwork.kernel:AddFile("sound/common/off7.mp3");
Clockwork.kernel:AddFile("sound/common/off8.mp3");
Clockwork.kernel:AddFile("sound/common/off9.mp3");
Clockwork.kernel:AddFile("sound/common/on1.mp3");
Clockwork.kernel:AddFile("sound/common/on2.mp3");
Clockwork.kernel:AddFile("sound/common/on3.mp3");
Clockwork.kernel:AddFile("sound/common/on4.mp3");
Clockwork.kernel:AddFile("sound/common/on5.mp3");
Clockwork.kernel:AddFile("sound/common/on6.mp3");
