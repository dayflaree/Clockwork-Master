local PLUGIN = PLUGIN;
local Clockwork = Clockwork;
local cflag = cflag;


-- A function to add a Combine display line.
function PLUGIN:AddNonCombineDisplayLine(text, color)
	if (Clockwork.player:HasFlags(Clockwork.Client, cflag)) then
		if (!self.combineDisplayLines) then
			self.combineDisplayLines = {};
		end;

		table.insert(self.combineDisplayLines, {"<:: "..text, CurTime() + 8, 5, color});
	end;
end;
