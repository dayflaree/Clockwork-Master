ENT.Type = "anim"
ENT.PrintName = "Ration Dispenser"
ENT.Author = "Chessnut"
ENT.Category = "HL2 RP"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.PhysgunDisable = true
ENT.PhysgunAllowAdmin = true

function ENT:SetupDataTables()
	self:NetworkVar("Float", 0, "DispColor")
	self:NetworkVar("String", 0, "Text")
	self:NetworkVar("Bool", 0, "Disabled")
end


