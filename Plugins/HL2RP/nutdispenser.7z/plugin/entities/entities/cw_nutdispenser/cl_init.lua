include("shared.lua")

local COLOR_RED = 1
local COLOR_ORANGE = 2
local COLOR_BLUE = 3
local COLOR_GREEN = 4

local colors = {
	[COLOR_RED] = Color(255, 50, 50),
	[COLOR_ORANGE] = Color(255, 80, 20),
	[COLOR_BLUE] = Color(50, 80, 230),
	[COLOR_GREEN] = Color(50, 240, 50)
}

local function LerpColor(tr, tg, tb, from, to)
	tg = tg || tr
	tb = tb || tr
	return Color(Lerp(tr, from.r, to.r),Lerp(tg, from.g, to.g),Lerp(tb, from.b, to.b))
end


local function FormatTime(time)
	local minutes = math.Truncate(time / 60)
	local seconds = time - (minutes * 60)
	local text = seconds .. "s"
	if minutes > 0 then
		local hours = math.Truncate(minutes / 60)
		minutes = minutes - (hours * 60)
		text = minutes .. "m " .. text
		if hours > 0 then
			text = hours .. "h " .. text
		end
	end
	return text
end

local function GetTextSize(text, font)
	surface.SetFont(font)
	local w, h = surface.GetTextSize(text)
	return w, h
end

function ENT:Draw()
	-- if not colors then return end

	local position, angles = self:GetPos(), self:GetAngles()

	angles:RotateAroundAxis(angles:Forward(), 90)
	angles:RotateAroundAxis(angles:Right(), 270)

	cam.Start3D2D(position + self:GetForward() * 7.6 + self:GetRight() * 8.8 + self:GetUp() * 3, angles, 0.1)
		render.PushFilterMin(TEXFILTER.NONE)
		render.PushFilterMag(TEXFILTER.NONE)

		surface.SetDrawColor(40, 40, 40)
		surface.DrawRect(0, 0, 86, 64)

		local text = self:GetText() or ""
		local w, h = GetTextSize(text, "Default")
		if w > 86 then
			local len = string.len(text)
			for i = 1, len do
				local text2 = string.sub(text, 0, len - i)
				local wide, _ = GetTextSize(text2 .. "...", "Default")
				if wide < 86 then
					text = text2 .. "..."
					break
				end
			end
		end

		draw.SimpleText((self:GetDisabled() and "OFF" or text), "Default", 43, 0, Color(255, 255, 255, math.abs(math.cos(RealTime() * 1.5) * 255)), 1, 0)

		local color = colors[self:GetDisabled() and COLOR_RED or self:GetDispColor()] or color_white

		surface.SetDrawColor(self.color or color)
		surface.DrawRect(4, 14, 78, 46)

		surface.SetDrawColor(60, 60, 60)
		surface.DrawOutlinedRect(4, 14, 78, 46)

		render.PopFilterMin()
		render.PopFilterMag()
	cam.End3D2D()
end

function ENT:Think()
	local color = colors[self:GetDisabled() and COLOR_RED or self:GetDispColor()] or color_white

	local vel = FrameTime() * 0.75
	self.color = LerpColor(vel, vel, vel, self.color or color, color)
end

surface.CreateFont( "NutDispenserLabel", {
	font = "Arial",
	size = 20,
	weight = 700,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

net.Receive("NutDispenserSelectID", function()
	local Dispenser = net.ReadEntity()
	local ItemTable = net.ReadTable()
	local HasUTC = false -- net.ReadBool()

	local RequestTable = {}
	for k, v in pairs(ItemTable) do
		local timeleft = ""
		if v[2] then
			timeleft = ((v[2] or 0) >= os.time()) and (FormatTime(v[2] - os.time()) .. " LEFT - ") or "CAN BE USED - "
		end

		RequestTable[timeleft .. (v[1] or "INVALID")] = function()
			if not IsValid(Dispenser) then return end

			if HasUTC and string.lower(LocalPlayer():GetCharacterData("customclass", "")) != string.lower("Union") then
				Derma_Query("¿Do you want to use the Union card?", "Use the Union card",
				"Yes", function()
					net.Start("SendNutDispenserInfo" .. Dispenser:EntIndex())
						net.WriteString("" .. k)
						net.WriteEntity(Dispenser)
						net.WriteBool(true)
					net.SendToServer()
				end,
				"No", function()
					net.Start("SendNutDispenserInfo" .. Dispenser:EntIndex())
						net.WriteString("" .. k)
						net.WriteEntity(Dispenser)
						net.WriteBool(false)
					net.SendToServer()
				end)
			else
				net.Start("SendNutDispenserInfo" .. Dispenser:EntIndex())
					net.WriteString("" .. k)
					net.WriteEntity(Dispenser)
					net.WriteBool(false)
				net.SendToServer()
			end
		end
	end

	local menuPanel = Clockwork.kernel:AddMenuFromData(nil, RequestTable)
	if (IsValid(menuPanel)) then
		menuPanel:SetPos(
			(ScrW() / 2) - (menuPanel:GetWide() / 2), (ScrH() / 2) - (menuPanel:GetTall() / 2)
		);
		Clockwork.kernel:SetTitledMenu(menuPanel, "SELECT THE CITIZEN ID CARD YOU ARE GOING TO USE");
		Clockwork.kernel:RegisterBackgroundBlur(menuPanel)
	end;
end)

net.Receive("NutDispenserUseUTCCard", function()
	local Dispenser = net.ReadEntity()
	Derma_Query("¿Do you want to use the Union card?", "Use the Union card",
	"Yes", function()
		net.Start("SendNutDispenserUTCCard" .. Dispenser:EntIndex())
			net.WriteBool(true)
		net.SendToServer()
	end,
	"No", function()
		net.Start("SendNutDispenserUTCCard" .. Dispenser:EntIndex())
			net.WriteBool(false)
		net.SendToServer()
	end)
end)
