include("shared.lua")

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")


-- CONFIG
local CombineAbleToToggleDispenser = false -- If set to false the Combine have rations, if set to true they just enable/disable the ration dispenser

local timeForNextRation = (0.75 * 60 * 60) -- 60 seconds, per 60 minutes per 0.75 hours, so 3/4 of an hour by default

local rationsByFactions = {
	-- TABLE STRUCTURE: [FACTION] = {RATIONS UID, RATIONS MODEL, HOW MUCH RATIONS, OPTIONAL: NEEDS IDCARD?}
	[FACTION_CSU] = {"high_grade_ration", "models/weapons/w_package.mdl", 1},
	[FACTION_CWU] = {"high_grade_ration", "models/weapons/w_package.mdl", 1},
	[FACTION_CMU] = {"high_grade_ration", "models/weapons/w_package.mdl", 1},
	[FACTION_VORTSLAVE] = {"biotic_ration", "models/weapons/w_package.mdl", 1},
	[FACTION_MPF] = {"metropolice_grade_ration", "models/weapons/w_package.mdl", 1}
}

local defaultRation = {"medium_grade_ration", "models/weapons/w_package.mdl", 1} -- {RATIONS UID, RATIONS MODEL, HOW MUCH RATIONS}
local loyalRation = {"high_grade_ration", "models/weapons/w_package.mdl", 1} -- {RATIONS UID, RATIONS MODEL, HOW MUCH RATIONS}
local verdictRation = {"low_grade_ration", "models/weapons/w_package.mdl", 1} -- {RATIONS UID, RATIONS MODEL, HOW MUCH RATIONS}

-- DONT TOUCH THIS
local COLOR_RED = 1
local COLOR_ORANGE = 2
local COLOR_BLUE = 3
local COLOR_GREEN = 4

local colors = {
	[COLOR_RED] = Color(255, 50, 50),
	[COLOR_ORANGE] = Color(255, 80, 20),
	[COLOR_BLUE] = Color(50, 80, 230),
	[COLOR_GREEN] = Color(50, 240, 50)
}

function ENT:SpawnFunction(client, trace)
	local entity = ents.Create("cw_nutdispenser")
	entity:SetPos(trace.HitPos)
	entity:SetAngles(trace.HitNormal:Angle())
	entity:Spawn()
	entity:Activate()

	return entity
end

function ENT:Initialize()
	self:SetModel("models/props_junk/gascan001a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetText("INSERT ID")
	self:DrawShadow(false)
	self:SetDispColor(COLOR_GREEN)
	self.canUse = true

	-- Use prop_dynamic so we can use entity:Fire("SetAnimation")
	self.dummy = ents.Create("prop_dynamic")
	self.dummy:SetModel("models/props_combine/combine_dispenser.mdl")
	self.dummy:SetPos(self:GetPos())
	self.dummy:SetAngles(self:GetAngles())
	self.dummy:SetParent(self)
	self.dummy:Spawn()
	self.dummy:Activate()

	self:DeleteOnRemove(self.dummy)

	local physObj = self:GetPhysicsObject()

	if (IsValid(physObj)) then
		physObj:EnableMotion(false)
		physObj:Sleep()
		physObj:SetMass(150)
	end

	self.IDEntered = nil
	util.AddNetworkString("NutDispenserSelectID")
	util.AddNetworkString("SendNutDispenserInfo" .. self:EntIndex())
	util.AddNetworkString("NutDispenserUseUTCCard")
	util.AddNetworkString("SendNutDispenserUTCCard" .. self:EntIndex())
	net.Receive("SendNutDispenserInfo" .. self:EntIndex(), function(len, ply)
		local ID = tonumber(net.ReadString())
		local Dispenser = net.ReadEntity()
		self.UseUTCCard = net.ReadBool()
		if not ID then return end
		if not IsValid(self) then return end
		if Dispenser != self then return end

		local inv = ply:GetInventory()
		local items = Clockwork.inventory:GetItemsByID(inv, "idcard") or {}
		table.Merge(items, Clockwork.inventory:GetItemsByID(inv, "cid_card") or {})
		table.Merge(items, Clockwork.inventory:GetItemsByID(inv, "cwu_card") or {})
		local cards = Clockwork.inventory:GetItemsByID(inv, "ration_card") or {}
		if not (items or cards) then return end
		if not (cards[ID] or items[ID]) then return end

		self.IDEntered = ID
		self:Use(ply, ply, SIMPLE_USE, 0)
	end)
	net.Receive("SendNutDispenserUTCCard" .. self:EntIndex(), function(len, ply)
		if not IsValid(self) then return end
		self.UseUTCCard = net.ReadBool()
		self:Use(ply, ply, SIMPLE_USE, 0)
	end)
end

-- Called when the entity's physics should be updated.
function ENT:PhysicsUpdate(physicsObject)
	if (not self:IsPlayerHolding() and not self:IsConstrained()) then
		physicsObject:SetVelocity( Vector(0, 0, 0) )
		physicsObject:Sleep()
	end
end

function ENT:setUseAllowed(state)
	self.canUse = state
end

function ENT:error(text)
	self:EmitSound("buttons/combine_button_locked.wav")
	self:SetText(text)
	self:SetDispColor(COLOR_RED)
	self:setUseAllowed(false)

	timer.Create("nut_DispenserError" .. self:EntIndex(), 1.5, 1, function()
		if (IsValid(self)) then
			self:SetText("INSERT ID")
			self:SetDispColor(COLOR_GREEN)

			timer.Simple(0.5, function()
				if (!IsValid(self)) then return end

				self:setUseAllowed(true)
			end)
		end
	end)
end

function ENT:createRation(ply, faction)
	local entity = ents.Create("prop_physics")
	entity:SetAngles(self:GetAngles())
	entity:SetModel(faction and (rationsByFactions[faction] and rationsByFactions[faction][2]) or defaultRation[2] or "models/weapons/w_package.mdl")
	entity:SetPos(self:GetPos())
	entity:Spawn()
	entity:SetNotSolid(true)
	entity:SetParent(self.dummy)
	entity:Fire("SetParentAttachment", "package_attachment")

	timer.Simple(1.2, function()

	local rationUniqueID = defaultRation[1]
	
		local loyaltyPoints = ply:GetSharedVar("lPoints");
		local verdictPoints = ply:GetSharedVar("vPoints");

		if (verdictPoints > 3) then
            rationUniqueID = verdictRation[1]
        elseif (loyaltyPoints >= 25 and verdictPoints <= 3) then
		   rationUniqueID = loyalRation[1]
		end
		local itemTable = Clockwork.item:CreateInstance(faction and (rationsByFactions[faction] and rationsByFactions[faction][1]) or rationUniqueID);
		if (IsValid(self) and IsValid(entity) and itemTable) then
			entity:Remove()
			Clockwork.entity:CreateItem(ply, itemTable, entity:GetPos(), entity:GetAngles())
			print (ply:GetSharedVar("vPoints"))
		end
	end)
end

function ENT:dispense(amount, ply, faction)
	if (amount < 1) then
		return
	end

	self:setUseAllowed(false)
	self:SetText("DISPENSING")
	self:EmitSound("ambient/machines/combine_terminal_idle4.wav")
	self:createRation(ply, faction)
	self.dummy:Fire("SetAnimation", "dispense_package", 0)

	timer.Simple(3.5, function()
		if (IsValid(self)) then
			if (amount > 1) then
				self:dispense(amount - 1, ply, faction)
			else
				self:SetText("LOADING")
				self:SetDispColor(COLOR_ORANGE)
				self:EmitSound("buttons/combine_button7.wav")

				timer.Simple(7, function()
					if (!IsValid(self)) then return end

					self:SetText("INSERT ID")
					self:SetDispColor(COLOR_GREEN)
					self:EmitSound("buttons/combine_button1.wav")

					timer.Simple(0.75, function()
						if (!IsValid(self)) then return end

						self:setUseAllowed(true)
					end)
				end)
			end
		end
	end)
end

local function FormatTime(time)
	local minutes = math.Truncate(time / 60)
	local seconds = time - (minutes * 60)
	local text = seconds .. "s"
	if minutes > 0 then
		local hours = math.Truncate(minutes / 60)
		minutes = minutes - (hours * 60)
		text = minutes .. "m " .. text
		if hours > 0 then
			text = hours .. "h " .. text
		end
	end
	return text
end

function ENT:Use(activator)
	local itemValue = (self.IDEntered) or 0
	self.IDEntered = nil
	-- local UseUTCCard = self.UseUTCCard
	-- self.UseUTCCard = nil

	if not (IsValid(activator) and activator:IsPlayer()) then
		return
	end

	if ((self.nextUse or 0) >= CurTime()) then
		return
	end
	if (!self.canUse) then
		return
	end

	local faction = activator:GetFaction()

	if Schema:PlayerIsCombine(activator) and CombineAbleToToggleDispenser then
		if activator:KeyDown(IN_SPEED) then
			local disabled = !self:GetDisabled()
			for k, v in pairs(ents.GetAll()) do
				if string.lower(v:GetClass()) == "cw_nutdispenser" then
					v:SetDisabled(disabled)
					v:EmitSound(v:GetDisabled() and "buttons/combine_button1.wav" or "buttons/combine_button2.wav")
				end
			end
		else
			self:SetDisabled(!self:GetDisabled())
		end
		self:EmitSound(self:GetDisabled() and "buttons/combine_button1.wav" or "buttons/combine_button2.wav")
		self.nextUse = CurTime() + 1
	else
		if (self:GetDisabled()) then
			return
		end

		if (rationsByFactions[activator:GetFaction()] and (rationsByFactions[activator:GetFaction()][4] == nil or rationsByFactions[activator:GetFaction()][4] == true))
		or ((not rationsByFactions[activator:GetFaction()]) and defaultRation[4] == nil or defaultRation[4] == false) then
			local inv = activator:GetInventory()
			local items = Clockwork.inventory:GetItemsByID(inv, "idcard") or {}
			table.Merge(items, Clockwork.inventory:GetItemsByID(inv, "cid_card") or {})
			table.Merge(items, Clockwork.inventory:GetItemsByID(inv, "cwu_card") or {})
			local cards = Clockwork.inventory:GetItemsByID(inv, "ration_card") or {}
			if table.Count(items) + table.Count(cards) > 1 and itemValue == 0 then
				local TableToSend = {}
				if items and table.Count(items) > 0 then
					for k, v in pairs(items) do
						TableToSend[k] = {v("name"), v:GetData("nextTime") or os.time()}
					end
				end
				if cards and table.Count(cards) > 0 then
					local number = 0
					for k, v in pairs(cards) do
						number = number + 1
						TableToSend[k] = {v.name .. " " .. number}
					end
				end
				net.Start("NutDispenserSelectID")
					net.WriteEntity(self)
					net.WriteTable(TableToSend)
					-- net.WriteBool(Clockwork.inventory:HasItemByID(inv, "union_card"))
				net.Send(activator)
				return
			-- elseif activator:HasItemByID("union_card") and UseUTCCard == nil and string.lower(activator:GetCharacterData("customclass", "")) != string.lower("Union") then
			-- 	net.Start("NutDispenserUseUTCCard")
			-- 		net.WriteEntity(self)
			-- 	net.Send(activator)
			-- 	return
			end
		end

		self:setUseAllowed(false)
		self:SetText("CHECKING")
		self:SetDispColor(COLOR_BLUE)
		self:EmitSound("ambient/machines/combine_terminal_idle2.wav")

		timer.Simple(1, function()
			if (!IsValid(self) or !IsValid(activator)) then return
				self:setUseAllowed(true)
			end

			local inv2 = activator:GetInventory()
			local items2 = Clockwork.inventory:GetItemsByID(inv2, "idcard") or {}
			table.Merge(items2, Clockwork.inventory:GetItemsByID(inv2, "cid_card") or {})
			table.Merge(items2, Clockwork.inventory:GetItemsByID(inv2, "cwu_card") or {})
			local cards2 = Clockwork.inventory:GetItemsByID(inv, "ration_card") or {}

			local item
			local IsCard = false
			if itemValue != 0 then
				if items2[itemValue] then
					item = items2[itemValue]
				elseif cards2[itemValue] then
					item = cards2[itemValue]
					IsCard = true
				end
			else
				if table.Count(items2) > 0 then
					for k, v in pairs(items2) do
						item = v
						IsCard = false
						break
					end
				else
					for k, v in pairs(cards2) do
						item = v
						IsCard = true
						break
					end
				end
			end

			local amount = faction and (rationsByFactions[faction] and rationsByFactions[faction][3]) or defaultRation[3]

			local ShouldDispense = true
			local TextToDisplay
													local loyaltyPoints = activator:GetSharedVar("lPoints");
													local verdictPoints = activator:GetSharedVar("vPoints");
			
			
				if (activator:HasItemByID("ration_token")) then
				local itemTable = activator:FindItemByID("ration_token");
				self:EmitSound("ambient/levels/labs/coinslot1.wav");
				TextToDisplay = "COUPON"
				activator:TakeItem(itemTable);
				elseif (activator:GetCharacterData("NextDispenser", os.time()) <= os.time()) then
					activator:SetCharacterData("NextDispenser", os.time() + timeForNextRation)
					TextToDisplay = "OKAY"
					if (verdictPoints > 3) then
                        TextToDisplay = "LOW GRADE"
                   elseif (loyaltyPoints >= 25 and verdictPoints <= 3) then
                        TextToDisplay = "HIGH GRADE"
					else
						TextToDisplay = "MED GRADE"
                    end;
					
					
				else
					ShouldDispense = false
					TextToDisplay = "WAIT " .. FormatTime(activator:GetCharacterData("NextDispenser", os.time()) - os.time())
				end
			

			if ShouldDispense then
				self:SetText(TextToDisplay)
				self:EmitSound("buttons/button14.wav", 100, 50)

				timer.Simple(1, function()
					if (IsValid(self)) then
						self:dispense(amount, activator, faction)
					end
				end)
			else
				self:error(TextToDisplay)
			end
		end)
	end
end
