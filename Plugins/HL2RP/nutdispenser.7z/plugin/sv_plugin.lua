local PLUGIN = PLUGIN;
	
-- A function to load the ration machines.
function PLUGIN:LoadNuttyDispensingMachines()
	local nutVend = Clockwork.kernel:RestoreSchemaData("plugins/nutdisp/"..game.GetMap());
	
	for k, v in pairs(nutVend) do
		local entity = ents.Create("cw_nutdispenser");
		entity:SetPos(v.pos);
		entity:SetAngles(v.angles);
		entity:Spawn();
		entity:Activate();
		local physObj = entity:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		end
	end;
end;

-- A function to save the ration machines.
function PLUGIN:SaveNuttyDispensingMachines()
	local nutVend = {};

	for k, v in pairs(ents.FindByClass("cw_nutdispenser")) do
		nutVend[#nutVend + 1] = {
			pos = v:GetPos(),
			angles = v:GetAngles(),
		}
	end;

	Clockwork.kernel:SaveSchemaData("plugins/nutdisp/"..game.GetMap(), nutVend);
end;