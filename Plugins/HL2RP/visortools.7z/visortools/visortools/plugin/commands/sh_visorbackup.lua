--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("VisorBackup");
COMMAND.tip = "Request immediate backup to all protection units.";
COMMAND.text = "<string Details>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.args = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		if (player:GetFaction() == FACTION_MPF or player:GetFaction() == FACTION_OTA) then
			local text = table.concat(arguments, " ");

			if (text == "") then
				local text = "N/A";
				
				return;
			end;
			
			Schema:AddCombineDisplayLine( ""..player:Name().." is requesting urgent assistance to their current location. DETAILS: "..text..".", Color(255, 10, 0, 255) );
			-- player:EmitSound("npc/overwatch/radiovoice/publicnoncompliance507.wav");
		    BroadcastLua("LocalPlayer():ConCommand('backup')")
	else
		Clockwork.player:Notify(player, "You are not a member of the combine!");
	end;
end;
end;

COMMAND:Register();