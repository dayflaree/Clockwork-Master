local PLUGIN = PLUGIN;

concommand.Add("backup", function(player)
	if (Schema:PlayerIsCombine(player)) then
	player:EmitSound("npc/overwatch/radiovoice/disturbingunity415.wav");
end;
end)

concommand.Add("notify", function(player)
	if (Schema:PlayerIsCombine(player)) then
	player:EmitSound("buttons/combine_button5.wav")
end;
end)

concommand.Add("green", function(player)
	if (Schema:PlayerIsCombine(player)) then
	player:EmitSound("npc/overwatch/radiovoice/sociostabilizationrestored.wav")
end;
end)

concommand.Add("yellow", function(player)
	if (Schema:PlayerIsCombine(player)) then
	player:EmitSound("npc/overwatch/radiovoice/yellow.wav")
end;
end)

concommand.Add("red", function(player)
	if (Schema:PlayerIsCombine(player)) then
	player:EmitSound("npc/overwatch/radiovoice/allunitsdeliverterminalverdict.wav")
end;
end)