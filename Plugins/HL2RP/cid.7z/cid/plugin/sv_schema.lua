local PLUGIN = PLUGIN;
local Schema = Schema;

if (Clockwork.config:Get("download_addon_cid"))
	then resource.AddWorkshop("282312812")
end;