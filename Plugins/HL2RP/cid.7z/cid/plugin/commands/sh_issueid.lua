local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("IssueID");
COMMAND.tip = "Issue a CID to the person your looking at.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local lookingPly = player:GetEyeTrace().Entity
	
	if lookingPly:IsPlayer() then
		local name = lookingPly:Name();
		local cid = lookingPly:GetCharacterData("citizenid");
		local id = lookingPly:GiveItem(Clockwork.item:CreateInstance("cid_card"));
		
		id:SetData("CardHolder", name);
		id:SetData("CIDNumber", cid);
		
		Clockwork.player:Notify(player, "A CID has been issued to the person you are looking at.");
	else
		Clockwork.player:Notify(player, "You must be looking at a valid player!");
	end;
	
end;

COMMAND:Register();