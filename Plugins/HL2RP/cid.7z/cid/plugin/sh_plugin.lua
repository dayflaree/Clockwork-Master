local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");

if (SERVER) then
	Clockwork.config:Add("download_addon_cid", true);
else
	Clockwork.config:AddToSystem("Download Addon", "download_addon_cid", "Whether or not the workshop addon for CID's will download automatically.", true);
end;