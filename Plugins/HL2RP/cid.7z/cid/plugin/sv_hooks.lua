local PLUGIN = PLUGIN;
local Schema = Schema;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (player:GetFaction() == FACTION_CITIZEN) and (player:GetCharacterData("issuedCard") != "true")then
		local name = player:Name();
		local cid = player:GetCharacterData("citizenid");
		local id = player:GiveItem(Clockwork.item:CreateInstance("cid_card"));
					
		id:SetData("CardHolder", name);
		id:SetData("CIDNumber", cid);
		player:SetCharacterData("issuedCard", "true");
	end;
end;