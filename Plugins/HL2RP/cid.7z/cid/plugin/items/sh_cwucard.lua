local PLUGIN = PLUGIN;

local ITEM = Clockwork.item:New();
ITEM.name = "Civil Worker's Identification Card";
ITEM.cost = 150;
ITEM.model = "models/dorado/tarjeta4.mdl";
ITEM.weight = 0;
ITEM.category = "Cards";
ITEM.uniqueID = "cwu_card";
ITEM.business = false;
ITEM.examineOveride = true;
ITEM.description = "A Identification Card with a picture, name and a CID number. \nThe card has a Union logo in the background.\nThis card is for Civil Worker's.";

-- Info stored in the card.
ITEM:AddData("CardHolder", "NO HOLDER", true);
ITEM:AddData("CIDNumber", "NO CID", true);

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

function ITEM:GetExamineText(player, itemEntity)
	return "Card Holder: "..self:GetData("CardHolder").."\nCID Number: #"..self:getData("CIDNumber");
end;

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		if (!self:IsInstance()) then return; end;
		
		local clientInfo = "";
		local cardholder = self:GetData("CardHolder");
		local cidnumber = self:GetData("CIDNumber");

		if (cardholder and cidnumber) then
			clientInfo = Clockwork.kernel:AddMarkupLine(clientInfo, "Card Holder: "..cardholder.."\nCID Number: #"..cidnumber);
		end;
		return (clientInfo != "" and clientInfo);
	end;
end;

ITEM:Register();