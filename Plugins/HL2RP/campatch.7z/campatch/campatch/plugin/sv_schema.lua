local PLUGIN = PLUGIN;
local Schema = Schema;

-- A function to save the NPCs.
function Schema:SaveNPCs()
	local npcs = {};
	
	for k, v in pairs( ents.FindByClass("npc_*") ) do
		local name = v:GetNetworkedString("cw_Name");
		local title = v:GetNetworkedString("cw_Title");
		
		if (name != "" and title != "") then
			if v:GetClass() != "npc_combine_camera" then
				local keyValues = table.LowerKeyNames( v:GetKeyValues() );
				
				npcs[#npcs + 1] = {
					spawnFlags = keyValues["spawnflags"],
					equipment = keyValues["additionequipment"],
					position = v:GetPos(),
					angles = v:GetAngles(),
					model = v:GetModel(),
					title = title,
					class = v:GetClass(),
					name = name
				};
			end;
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/npcs/"..game.GetMap(), npcs);
end;