-- Copyright Novabox.org 2015

local PLUGIN = PLUGIN;

local texture = Material("novabox/gui/datapadoverlay.png")
texture:SetFloat("$multiply", 2);
local bgtexture = Material("novabox/gui/datapadback.png")
local bigcolor = Color( 255, 255, 255, 75 )
local bigcolor1 = Color( 255, 255, 255, 75 )
local bigcolor2 = Color( 255, 255, 255, 75 )
local bigcolor3 = Color( 255, 0, 0, 75 )
local bigcolor4 = Color( 255, 255, 255, 75 )

surface.CreateFont("FrameDP", {
	font = "Couture",
	size = 30,
	weight = 500,
	antialias = true,
	shadow = false
} )

Clockwork.datastream:Hook("DrawDatapad", function(dataob)

FrameDP = vgui.Create( "DFrame" )
FrameDP:SetTitle( "DATAPAD" )
FrameDP:SetSize( 500, 800 )
FrameDP:Center()
FrameDP:MakePopup()
FrameDP:ShowCloseButton(false)
FrameDP:SetDeleteOnClose(true)
FrameDP:SetDraggable( false )
FrameDP.Paint = function( self, w, h )
	surface.SetDrawColor(255, 255, 255, 255);
	surface.SetMaterial(bgtexture);
    surface.DrawTexturedRect(0,0, w, h);
end
FrameDP.PaintOver = function( self, w, h )
	surface.SetDrawColor(255, 255, 255, 255);
	texture:SetFloat("$alpha", Lerp( 0.05, .75, 0.75 - math.random( 0, 0.035 ) ));
	surface.SetMaterial(texture);
    surface.DrawTexturedRect(0,0, w, h);
end

local Button = vgui.Create( "DButton", FrameDP )
local Button2 = vgui.Create( "DButton", FrameDP )
local Button3 = vgui.Create( "DButton", FrameDP )
local Button4 = vgui.Create( "DButton", FrameDP )
local Button5 = vgui.Create( "DButton", FrameDP )

Button4:SetText( "" )
Button4:SetPos( 480, 0 )
Button4:SetSize( 20, 20 )
Button4.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, bigcolor3 )
end

local y = FrameDP:GetTall()/2-250
local x = FrameDP:GetWide()/2-150
Button:SetFont("FrameDP")
Button:SetText( "VIEW OBJECTIVES" )
Button:SetTextColor( Color(0, 0, 0,255) )
Button:SetPos( x, y )
Button:SetSize( 300, 50 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, bigcolor )
end
Button.PaintOver = function( self, w, h )
	local flash = math.abs(math.sin(RealTime() * 3) * 150)
	surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
	
	for i = 1, 3 do
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end

local y = y + 100
Button2:SetFont("FrameDP")
Button2:SetText( "EDIT OBJECTIVES" )
Button2:SetTextColor( Color(0, 0, 0,255) )
Button2:SetPos( x, y )
Button2:SetSize( 300, 50 )
Button2.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, bigcolor1 )
end
Button2.PaintOver = function( self, w, h )
	local flash = math.abs(math.sin(RealTime() * 3) * 150)
	surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
	
	for i = 1, 3 do
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end

local y = y + 100
Button3:SetFont("FrameDP")
Button3:SetText( "CITIZEN DATA" )
Button3:SetTextColor( Color(0, 0, 0,255) )
Button3:SetPos( x, y )
Button3:SetSize( 300, 50 )
Button3.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, bigcolor2 )
end
Button3.PaintOver = function( self, w, h )
	local flash = math.abs(math.sin(RealTime() * 3) * 150)
	surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
	
	for i = 1, 3 do
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end
Button3.DoClick = function()
	Clockwork.option:PlaySound("click");

	Button:Remove()
	Button2:Remove()
	Button3:Remove()
	Button5:Remove()

	FrameDP:SetTitle( "DATAPAD: ENTER INFORMATION" )
	
	local y = FrameDP:GetTall()/2-275
	local x = FrameDP:GetWide()/2-150
	local enterlabel = vgui.Create( "DLabel", FrameDP )
	enterlabel:SetFont("FrameDP")
	enterlabel:SetText( "ENTER NAME OR CID:" )
	enterlabel:SetTextColor( Color(255, 255, 255 ,255) )
	enterlabel:SetPos( x, y )
	enterlabel:SetSize( 515, 50 )

	local y = y + 100
	local cidnametext = vgui.Create("DTextEntry", FrameDP)
	cidnametext:SetText("")
	cidnametext:SetPos( x, y )
	cidnametext:SetSize( 300, 50 )
	cidnametext.OnEnter = function(self)
		local target = Clockwork.player:FindByID( self:GetValue() );
		if (target) then
			LocalPlayer():ConCommand( "cwSay /dpcommandviewdata "..self:GetValue() )
			FrameDP:Close()
		else
			Clockwork.chatBox:Add(Clockwork.Client, nil, "notify", "<:: "..self:GetValue().." is not a valid person. ::>")
		end
	end
end

local y = y + 100
Button5:SetFont("FrameDP")
Button5:SetText( "VISOR" )
Button5:SetTextColor( Color(0, 0, 0,255) )
Button5:SetPos( x, y )
Button5:SetSize( 300, 50 )
Button5.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, bigcolor4 )
end
Button5.PaintOver = function( self, w, h )
	local flash = math.abs(math.sin(RealTime() * 3) * 150)
	surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
	
	for i = 1, 3 do
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end
Button5.DoClick = function()
	Clockwork.option:PlaySound("click");

	Button:Remove()
	Button2:Remove()
	Button3:Remove()
	Button5:Remove()

	FrameDP:SetTitle( "DATAPAD: VISOR" )
	
	local y = FrameDP:GetTall()/2-315
	local x = FrameDP:GetWide()/2-150
	local notifylabel = vgui.Create( "DLabel", FrameDP )
	notifylabel:SetFont("FrameDP")
	notifylabel:SetText( "NOTIFY:" )
	notifylabel:SetTextColor( Color(255, 255, 255 ,255) )
	notifylabel:SetPos( x, y )
	notifylabel:SetSize( 515, 50 )
	
	local y = y + 50
	local notifytext = vgui.Create("DTextEntry", FrameDP)
	notifytext:SetText("")
	notifytext:SetPos( x, y )
	notifytext:SetSize( 300, 50 )
	notifytext.OnEnter = function(self)
		LocalPlayer():ConCommand( "cwSay /visornotify "..self:GetValue() )
	end
	
	local y = y + 100
	local x = FrameDP:GetWide()/2-150
	local backuplabel = vgui.Create( "DLabel", FrameDP )
	backuplabel:SetFont("FrameDP")
	backuplabel:SetText( "BACKUP:" )
	backuplabel:SetTextColor( Color(255, 255, 255 ,255) )
	backuplabel:SetPos( x, y )
	backuplabel:SetSize( 515, 50 )
	
	local y = y + 50
	local x = FrameDP:GetWide()/2-150
	local backuptext = vgui.Create("DTextEntry", FrameDP)
	backuptext:SetText("")
	backuptext:SetPos( x, y )
	backuptext:SetSize( 300, 50 )
	backuptext.OnEnter = function(self)
		LocalPlayer():ConCommand( "cwSay /visorbackup "..self:GetValue() )
	end
	
	local y = y + 95
	local x = FrameDP:GetWide()/2-125
	local backuplabel = vgui.Create( "DLabel", FrameDP )
	backuplabel:SetFont("FrameDP")
	backuplabel:SetText( "SOCIO-STABILITY:" )
	backuplabel:SetTextColor( Color(255, 255, 255 ,255) )
	backuplabel:SetPos( x, y )
	backuplabel:SetSize( 520, 50 )
	
	local y = 442
	local x = FrameDP:GetWide()/2-100
	local greencolor = Color( 255, 255, 255, 75 )
	local greenlevel = vgui.Create( "DButton", FrameDP );
	greenlevel:SetText( "GREEN" );
	greenlevel:SetFont( "FrameDP" )
	greenlevel:SetTextColor( Color(0, 0, 0, 255) )
	greenlevel:SetPos( x, y )
	greenlevel:SetSize( 200, 50 )
	greenlevel.Paint = function()
		draw.RoundedBox( 0, 0, 0, 515, 50, greencolor )
	end
	greenlevel.PaintOver = function( self, w, h )
		local flash = math.abs(math.sin(RealTime() * 3) * 150)
		surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
		
		for i = 1, 3 do
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
	end
	greenlevel.OnCursorEntered = function()
		greencolor = Color( 0, 255, 0, 160 )
	end
	greenlevel.OnCursorExited = function()
		greencolor = Color( 255, 255, 255, 75 )
	end
	greenlevel.DoClick = function()
		Clockwork.option:PlaySound("click");
		LocalPlayer():ConCommand( "cwSay /visorstatus green" )
	end
	
	local y = y + 65
	local yellowcolor = Color( 255, 255, 255, 75 )
	local yellowlevel = vgui.Create( "DButton", FrameDP );
	yellowlevel:SetText( "YELLOW" );
	yellowlevel:SetFont( "FrameDP" )
	yellowlevel:SetTextColor( Color(0, 0, 0, 255) )
	yellowlevel:SetPos( x, y )
	yellowlevel:SetSize( 200, 50 )
	yellowlevel.Paint = function()
		draw.RoundedBox( 0, 0, 0, 515, 50, yellowcolor )
	end
	yellowlevel.PaintOver = function( self, w, h )
		local flash = math.abs(math.sin(RealTime() * 3) * 150)
		surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
		
		for i = 1, 3 do
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
	end
	yellowlevel.OnCursorEntered = function()
		yellowcolor = Color( 255, 255, 0, 160 )
	end
	yellowlevel.OnCursorExited = function()
		yellowcolor = Color( 255, 255, 255, 75 )
	end
	yellowlevel.DoClick = function()
		Clockwork.option:PlaySound("click");
		LocalPlayer():ConCommand( "cwSay /visorstatus yellow" )
	end
	
	local y = y + 65
	local redcolor = Color( 255, 255, 255, 75 )
	local redlevel = vgui.Create( "DButton", FrameDP );
	redlevel:SetText( "RED" );
	redlevel:SetFont( "FrameDP" )
	redlevel:SetTextColor( Color(0, 0, 0, 255) )
	redlevel:SetPos( x, y )
	redlevel:SetSize( 200, 50 )
	redlevel.Paint = function()
		draw.RoundedBox( 0, 0, 0, 515, 50, redcolor )
	end
	redlevel.PaintOver = function( self, w, h )
		local flash = math.abs(math.sin(RealTime() * 3) * 150)
		surface.SetDrawColor(40 + flash, 40 + flash, 40 + flash, 255)
		
		for i = 1, 3 do
			surface.DrawOutlinedRect( 0, 0, w, h )
		end
	end
	redlevel.OnCursorEntered = function()
		redcolor = Color( 255, 0, 0, 160 )
	end
	redlevel.OnCursorExited = function()
		redcolor = Color( 255, 255, 255, 75 )
	end
	redlevel.DoClick = function()
		Clockwork.option:PlaySound("click");
		LocalPlayer():ConCommand( "cwSay /visorstatus red" )
	end

end

Button.DoClick = function()
	FrameDP:Close()
	Clockwork.option:PlaySound("click");
	if (Schema:PlayerIsCombine(Clockwork.Client)) then
		PLUGIN:ViewObjDP(dataob)
	end
end

Button2.DoClick = function()
	FrameDP:Close()
	Clockwork.option:PlaySound("click");
	if (Schema:PlayerIsCombine(Clockwork.Client)) then
		PLUGIN:EditObjDP(dataob)
	end
end

Button4.DoClick = function()
	if (!Button5:IsValid()) then
	FrameDP:Close()
	LocalPlayer():ConCommand( "cwSay /datapad" )
	else
	FrameDP:Close()
	end
	Clockwork.option:PlaySound("click");
end

Button.OnCursorEntered = function()
	bigcolor = Color( 255, 255, 255, 160 )
	Clockwork.option:PlaySound("rollover");
end
Button.OnCursorExited = function()
	bigcolor = Color( 255, 255, 255, 75 )
end

Button2.OnCursorEntered = function()
	bigcolor1 = Color( 255, 255, 255, 160 )
	Clockwork.option:PlaySound("rollover");
end
Button2.OnCursorExited = function()
	bigcolor1 = Color( 255, 255, 255, 75 )
end

Button3.OnCursorEntered = function()
	bigcolor2 = Color( 255, 255, 255, 160 )
	Clockwork.option:PlaySound("rollover");
end
Button3.OnCursorExited = function()
	bigcolor2 = Color( 255, 255, 255, 75 )
end
Button5.OnCursorEntered = function()
	bigcolor4 = Color( 255, 255, 255, 160 )
	Clockwork.option:PlaySound("rollover");
end
Button5.OnCursorExited = function()
	bigcolor4 = Color( 255, 255, 255, 75 )
end
end)

function PLUGIN:ViewObjDP(data)
	if (newobjectives.objectivesPanel and newobjectives.objectivesPanel:IsValid()) then
		newobjectives.objectivesPanel:Close();
		newobjectives.objectivesPanel:Remove();
	end;
	
	newobjectives.objectivesPanel = vgui.Create("cwViewObjectives");
	newobjectives.objectivesPanel:Populate(data or "");
	newobjectives.objectivesPanel:MakePopup();
	
	gui.EnableScreenClicker(true);
end

function PLUGIN:EditObjDP(data)
	if (newobjectives.objectivesPanel and newobjectives.objectivesPanel:IsValid()) then
		newobjectives.objectivesPanel:Close();
		newobjectives.objectivesPanel:Remove();
	end;
	
	newobjectives.objectivesPanel = vgui.Create("cwEditObjectives");
	newobjectives.objectivesPanel:Populate(data or "");
	newobjectives.objectivesPanel:MakePopup();
	
	gui.EnableScreenClicker(true);
end