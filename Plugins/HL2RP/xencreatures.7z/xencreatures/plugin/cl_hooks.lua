
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

 -- Called when a player should show on the scoreboard.
function PLUGIN:PlayerShouldShowOnScoreboard(player)
	local clientFaction = Clockwork.Client:GetFaction();
	local playerFaction = player:GetFaction();
	
	if (playerFaction == clientFaction or clientFaction == FACTION_SRVADMIN) then
		return;
	end;

	if (playerFaction == FACTION_BULLSQUID) then
		return false;
	end;
end;
