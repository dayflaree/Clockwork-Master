local FACTION = Clockwork.faction:New("Bullsquid");

FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.noGas  = true;
FACTION.recognise = true;
FACTION.isXenCreature = true;
FACTION.serverCharacterCreationWhitelist = {"canals", "outlands", "coast"};

FACTION.models = {
	female = {
		"models/xenians/bullsquid.mdl",
	},
	male = {
		"models/xenians/bullsquid.mdl",
	};
};

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
--Empty function here for later usage
end;

FACTION_BULLSQUID = FACTION:Register();