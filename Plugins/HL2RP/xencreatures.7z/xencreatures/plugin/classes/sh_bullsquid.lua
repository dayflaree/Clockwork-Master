local CLASS = Clockwork.class:New("Bullsquid")

CLASS.color = Color(0, 255, 0, 255);
CLASS.wages = false;
CLASS.isDefault = true;
CLASS.factions = {FACTION_BULLSQUID};
CLASS.description = "A large weird looking Xenian creature."
CLASS.defaultPhysDesc = "A creature with two short, muscular legs and a thick tail that tapers to a point."

CLASS_BULLSQUID = CLASS:Register();