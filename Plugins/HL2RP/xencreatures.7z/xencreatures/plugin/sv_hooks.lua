
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when a player's death sound should be played.
function PLUGIN:PlayerPlayDeathSound(player, gender)
	if (player:GetFaction() == FACTION_BULLSQUID) then
        return "npc/bullsquid/die.wav";	
	end;
end;

-- Called when a player's pain sound should be played.
function PLUGIN:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
	if(player:GetFaction() == FACTION_BULLSQUID)	then
	    return "npc/bullsquid/tailswing"..math.random(1, 2)..".wav";	   
	end;
end;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	if (player:GetFaction() == FACTION_BULLSQUID) then
		infoTable.jumpPower = Clockwork.config:Get("jump_power"):Get() * 0.5;
		infoTable.runSpeed = Clockwork.config:Get("run_speed"):Get() * 0.8;
	end;
end;

-- Called when a player's character default weapons should be given.
function PLUGIN:PlayerGiveWeapons(player)      
	if (player:GetFaction() == FACTION_BULLSQUID) then
		Clockwork.player:GiveSpawnWeapon(player, "cw_acidspit");
	end;
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!lightSpawn) then
		if (player:GetFaction() == FACTION_BULLSQUID) then
			player:SetMaxHealth(200);
			player:SetMaxArmor(200);
			player:SetHealth(200);
			player:SetArmor(200);
		end;
	end;
end;