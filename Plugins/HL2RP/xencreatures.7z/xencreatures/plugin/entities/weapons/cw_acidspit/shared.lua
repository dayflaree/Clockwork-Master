if SERVER then
	AddCSLuaFile("shared.lua")
end

if (CLIENT) then
	SWEP.Slot = 5;
	SWEP.SlotPos = 3;
	SWEP.DrawAmmo = true;
	SWEP.PrintName = "Acid Spit";
	SWEP.DrawCrosshair = false;
end

SWEP.Author			        = "Zak"
SWEP.Instructions           = "Fucking C'thulu dogs, man!";
SWEP.AdminSpawnable         = false;
SWEP.Spawnable		        = true;
SWEP.HoldType				= "normal"
SWEP.ViewModel              = "models/weapons/c_smg1.mdl"
SWEP.WorldModel             = ""
SWEP.UseHands				= true;

SWEP.Primary.Automatic		= false;
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false;
SWEP.Secondary.Ammo			= "none"

SWEP.Slot					= 1
SWEP.SlotPos				= 2

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.DrawAmmo				= false
SWEP.AdminOnly				= true
SWEP.NeverRaised			= true;

game.AddParticles( "particles/antlion_worker.pcf" )

local ShootSound = "npc/bullsquid/goo_attack3.wav"

function SWEP:Initialize()
	self:SetHoldType( "normal" )
end

function SWEP:Reload()
end

function SWEP:PrimaryAttack()

	self:SetNextPrimaryFire( CurTime() + 1.5 )
	self:EmitSound( ShootSound )
	self:ShootEffects( self )
	
	if ( !SERVER ) then return end
	
	local Forward = self.Owner:EyeAngles():Forward()
	local Up = self.Owner:EyeAngles():Up()
	local Right = self.Owner:EyeAngles():Right()
	
	local ent = ents.Create( "grenade_spit" )
	if ( IsValid( ent ) ) then
		ent:SetPos( self.Owner:GetShootPos() + Forward * 32 )
		ent:SetAngles( self.Owner:EyeAngles() )
		ent:Spawn()
		if(self.Owner:KeyDown(IN_RUN)) then
			ent:SetVelocity(Forward * (math.random(3800, 4200)))
		else
			ent:SetVelocity( Forward * 4000 )
		end;
		ent:SetOwner( self.Owner )
	end;
end;

function SWEP:ShouldDropOnDie()
	return false
end

function SWEP:SecondaryAttack()

end