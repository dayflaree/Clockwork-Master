--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]


local ITEM = Clockwork.item:New("weapon_base");
ITEM.name = "Stunstick";
ITEM.cost = 125;
ITEM.model = "models/dpfilms/metropolice/props/hd_stunbaton.mdl";
ITEM.weight = 1.5;
ITEM.uniqueID = "cw_stunstick";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "A stunstick, It has no biosginal-- making it useable for you! <color='FF0000'>This item is illegal.</color>";
ITEM.classes = {CLASS_MPU, CLASS_MPR, CLASS_EMP};
ITEM.isAttachment = true;
ITEM.hasFlashlight = true;
ITEM.loweredOrigin = Vector(3, 0, -4);
ITEM.loweredAngles = Angle(0, 45, 0);
ITEM.attachmentBone = "Valvebiped.Bip01_Pelvis";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-2, 5, 4);


ITEM:Register();