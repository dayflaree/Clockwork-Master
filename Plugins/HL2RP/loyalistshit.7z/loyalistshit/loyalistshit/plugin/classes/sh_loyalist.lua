local CLASS = Clockwork.class:New("Loyalist");

CLASS.color = Color(0, 255, 200, 255);
CLASS.factions = {FACTION_LOYALIST};
CLASS.isDefault = true;
CLASS.wagesName = "Wages";
CLASS.description = "A citizen that is a loyalist.";
CLASS.defaultPhysDesc = "A citizen wearing a white shirt with a blue patch.";
	
CLASS_LOYALIST = CLASS:Register();