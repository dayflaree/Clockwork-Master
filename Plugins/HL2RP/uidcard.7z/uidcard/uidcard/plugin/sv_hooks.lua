local PLUGIN = PLUGIN;
function PLUGIN:PlayerCanUseDoor(player, door)
	if (player:GetSharedVar("tied") != 0 or (!Schema:PlayerIsCombine(player) and player:GetFaction() != FACTION_ADMIN)) then
		return false;
	else
		return true;
	end;
end;
function PLUGIN:GetPlayerDefaultInventory(player, character, inventory)
	if (Schema:PlayerIsCombine(player) and !player:HasItemByID("unit_id_card")) then
		player:GiveItem(Clockwork.item:CreateInstance("unit_id_card"), true);
	end;
end;