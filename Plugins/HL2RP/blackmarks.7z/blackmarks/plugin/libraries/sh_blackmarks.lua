--[[
	© 2014 TeslaCloud Studios LLC
	feel free to play around with that file however you'd like.
--]]

Clockwork.blackmarks = Clockwork.kernel:NewLibrary("BlackMarks");
Clockwork.blackmarks.stored = Clockwork.blackmarks.stored or {};

-- A function to add a blackmark.
function Clockwork.blackmarks:Register(id, data)
	if (!id) then return end;
	
	if (type(data) == "table") then
		self.stored[id] = data;
		self.stored[id].Name = data.Name;
		self.stored[id].Verdict = data.Verdict;
		self.stored[id].Blackmarks = data.Blackmarks;
		self.stored[id].uniqueID = data.uniqueID;
	else
		print("[Blackmarks::ERROR] ID '"..id.."' can't be registered! (table expected, got "..type(data)..")");
	end;
end;

-- A function to add a Blackmark tag.
function Clockwork.blackmarks:Add(id, name, verdict, blackmarks)
	local BM = {}
		BM.Name = name;
		BM.Verdict = verdict;
		BM.uniqueID = id;
		BM.Blackmarks = blackmarks;
	self:Register(id, BM);
end;

--[[===================================
	Register Blackmark tags here.
=======================================]]

Clockwork.blackmarks:Add("ACA-01", "ACA-01", "RE-EDUCATION", 3);
Clockwork.blackmarks:Add("ACA-02", "ACA-02", "DOUBLE RE-EDUCATION, ISOLATE FOR 10 MINUTES", 6);
Clockwork.blackmarks:Add("SE-01", "SE-01", "TRIPLE RE-EDUCATION, ISOLATE FOR 20 MINUTES", 10);
Clockwork.blackmarks:Add("SE-02", "SE-02", "4X RE-EDUCATION, ISOLATE FOR ONE HOUR", 15);
Clockwork.blackmarks:Add("CM-00", "CM-00", "ISOLATE FOR ONE HOUR", 30);
Clockwork.blackmarks:Add("SE-03", "SE-03", "PRIMARY SURGICAL ORGANS AND MEMORY REPLACEMENT", 30);
Clockwork.blackmarks:Add("SE-04", "SE-04", "PRIMARY SURGICAL ORGANS AND MEMORY REPLACEMENT", 30);
Clockwork.blackmarks:Add("MAV-00", "MAV-00", "AMPUTATION", 30);
Clockwork.blackmarks:Add("SE-05", "SE-05", "IMMEDIATE AMPUTATION", 30);

--[[==============
	Disregard code below, huehue.
=================]]

-- A function to check whether or not the specified Blackmark ID does exists.
function Clockwork.blackmarks:Exists(id)
	if (!self.stored[id]) then
		return false;
	else
		return true;
	end;
end;

-- A function to get Blackmark's name.
function Clockwork.blackmarks:GetName(id)
	if (Clockwork.blackmarks:Exists(id)) then
		return self.stored[id].Name;
	end;
end;

-- A function to get Blackmark's verdict.
function Clockwork.blackmarks:GetVerdict(id)
	if (Clockwork.blackmarks:Exists(id)) then
		return self.stored[id].Verdict;
	end;
end;

-- A function to get the amount of Blackmarks to issue with the specified Blackmark ID.
function Clockwork.blackmarks:GetAmt(id)
	if (Clockwork.blackmarks:Exists(id)) then
		return self.stored[id].Blackmarks;
	end;
end;

-- A function that's called on command run.
function Clockwork.blackmarks:CommandRun(player, cid, reason)
	if (cid and Clockwork.blackmarks:Exists(id)) then
		for k,v in pairs(player.GetAll()) do
			if (v:IsPlayer() and v:Alive()) then
				if ((v:GetCharacterData("citizenid") == cid) and (v:GetFaction() == FACTION_CITIZEN)) then
					target = v;
					
					for k, b in pairs(player.GetAll()) do
						if (Schema:PlayerIsCombine(b)) then
							if (b:Alive()) then							
								b:EmitSound("npc/combine_soldier/vo/on2.wav");
								Clockwork.chatBox:SendColored(b,
									Color(75, 150, 50),
									player:GetName().." radios in ''<:: Blackmark request for citizen #"..cid..", request code: '"..reason.."'."
								);
							end;
						end;
					end;
					
					for k, n in pairs(ents.FindInSphere(player:GetPos(), Clockwork.config:Get("talk_radius"):Get())) do
						if (IsValid(n) and n:IsPlayer() and n:Alive()) then
							if (!Schema:PlayerIsCombine(n)) then
								if (n:Alive()) then
									Clockwork.chatBox:SendColored(n,
										Color(255, 255, 175),
										player:GetName().." radios in ''<:: Blackmark request for citizen #"..cid..", request code: '"..reason.."'."
									);
								end;
							end;
						end;
					end;
					
					if (target:GetCharacterData("civ_blackmarks")<30) then
						target:SetCharacterData("civ_blackmarks", math.Clamp(target:GetCharacterData("civ_blackmarks") + Clockwork.blackmarks:GetAmt(reason), 0, 30));
						
						if ((target:GetCharacterData("civ_blackmarks") >= 30) and (target:GetCharacterData("civ_verdict") == "CITIZEN")) then
							target:SetCharacterData("civ_verdict", "ANTI-CITIZEN");
							Clockwork.chatBox:SendColored(nil,
								Color(175,0,0),
								"C17 Priority Dispatch :: 'Individual #"..target:GetCharacterData("citizenid")..", "..target:GetName()..", you are charged with capital malcompliance. Anti-citizen status approved.'"
							);
							
							BroadcastLua("LocalPlayer():EmitSound('npc/overwatch/cityvoice/f_capitalmalcompliance_spkr.wav')");
							Clockwork.hint:Send(target, "They... The combine. They are watching you. Good luck, mate...", 4, Color(175, 0, 0), true);
							target:SendLua("LocalPlayer():EmitSound('music/hl2_song29.mp3')");
							OW_Add_Order("high", "ANTI-CITIZEN", target:GetName().."-"..target:GetCharacterData("citizenid"), "LOCK, CAUTERIZE, STABILIZE", target:GetPos());
						end;						
					end;
					
					local newBMD = target:GetCharacterData("civ_blackmarks");
					
					timer.Simple(2, function()
						for k, m in pairs(player.GetAll()) do
							if (Schema:PlayerIsCombine(m)) then
								if (m:Alive()) then							
									m:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav");
									Clockwork.chatBox:SendColored(m, 
										Color(75, 150, 50), "Overwatch radios in: <:: Blackmark for citizen #"..cid.." has been approved. Citizen received ",
										Color(63, 127, 127), Clockwork.blackmarks:GetAmt(reason),
										Color(75, 150, 50), " blackmark, total",
										Color(63, 127, 127), newBMD.." out of 30",
										Color(75, 150, 50), "."
									);
									
									Clockwork.chatBox:SendColored(m,
										Color(75, 150, 50), "Overwatch radios in '' <:: Verdict for citizen #"..cid.." is: ",
										Color(63, 127, 127), Clockwork.blackmarks:GetVerdict(reason),
										Color(75, 150, 50), "."
									);
								end;
							end;
						end;
					end);
					
					--v:SetCharacterData("civ_blackmarks", bms+1);
				else
					Clockwork.player:Notify(player, "This citizen ID is not associated with a valid citizen!");
				end;
			else
				Clockwork.player:Notify(player, "This character is either dead or does not exists.");
			end;
		end;
	else
		Clockwork.player:Notify(player, "The Blackmark ID '"..reason.."' is not a valid reason!");
	end;
end;