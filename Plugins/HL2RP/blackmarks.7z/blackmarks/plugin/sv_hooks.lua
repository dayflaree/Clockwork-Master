local PLUGIN = PLUGIN;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (!data["civ_blackmarks"]) then
		data["civ_blackmarks"] = 0;
	end;
	if (!data["civ_verdict"]) then
		data["civ_verdict"] = "CITIZEN";	
	end;	
end;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	local faction = player:GetFaction();
	
	if (!player.nextAnnounce or CurTime() >= player.nextAnnounce) then
		if (player:Alive() and !player:IsRagdolled()) then
			if (faction == FACTION_CITIZEN) then	
				if (player:GetCharacterData("civ_verdict") == "ANTI-CITIZEN") then	
					Clockwork.chatBox:SendColored(nil, 
						Color(175,0,0), 
						"C17 Priority Dispatch :: 'Attention ground units. Anticitizen #"..player:GetCharacterData("citizenid").." - "..player:GetName().." reported in this community. Code: LOCK, CAUTERIZE, STABILIZE.'"
					);
					BroadcastLua("LocalPlayer():EmitSound('npc/overwatch/cityvoice/f_anticitizenreport_spkr.wav')");				
				end;
			end;
		end;
		player.nextAnnounce = CurTime() + 60;
	end;	
end;