--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("bmrequest");
COMMAND.tip = "Request a blackmark for citizen.";
COMMAND.text = "<string CID> <string REASON>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		Clockwork.blackmarks:CommandRun(player, arguments[1], arguments[2]);
	else
		Clockwork.player:Notify(player, "You are not a Combine Unit!");
	end;
end;

COMMAND:Register();