--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("relocrequest")
COMMAND.tip = "Запрос на изменение апартаментов гражданина."
COMMAND.text = "<string CID> <string LID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine) or combine:GetFaction() == FACTION_CWU) then
		for k, citizen in pairs(player.GetAll()) do
			if (citizen:GetCharacterData("citizenid") == arguments[1]) then
				if (citizen:IsCitizen()) then
					local stringCID = arguments[1]
					local stringLID = arguments[2]

					combine:EmitSound("npc/combine_soldier/vo/on2.wav")
					combine:CombineRequestSay("Запрашиваю переселение гражданина #"..stringCID.." в апартаменты "..stringLID..".")

					citizen:SetCharacterData("civ_lid", stringLID)			

					timer.Simple(2, function()
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Запрос о переселении гражданина #"..stringCID.." был подтвержден. Новые апартаменты для гражданина: "..stringLID..".")
					end)

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();