--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("r")
COMMAND.tip = "Отправить радиосообщение для сотрудников ГО."
COMMAND.text = "<string Text>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) or (combine:GetFaction() == FACTION_ADMIN) then
		local text = table.concat(arguments, " ")

		if (text == "") then
			Clockwork.player:Notify(combine, "Наберите текст!")

			return
		end

		combine:EmitSound("npc/combine_soldier/vo/on2.wav")
		combine:CombineRequestSay(text)
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();