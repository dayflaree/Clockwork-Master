local COMMAND = Clockwork.command:New("cwuSetFaction")
COMMAND.tip = "Запрос на изменение гражданской фракции гражданина."
COMMAND.text = "<string CID> <string factionname>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if combine:GetFaction() == FACTION_CWU then
		local stringCID = arguments[1]
		local stringFaction = tostring(arguments[2])

		for k, citizen in pairs(player.GetAll()) do
			if (citizen:GetCharacterData("citizenid") == arguments[1]) then
				if (citizen:IsCitizen()) then
					local newBMD = citizen:GetCharacterData("civ_faction")

					citizen:SetCharacterData("civ_faction", stringFaction)			
					combine:CombineRequestAnswer("Гражданская фракция гражданина #"..stringCID.." была изменена на"..tostring(stringFaction)..".")

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "You are not a CWU!")
	end
end

COMMAND:Register();