local COMMAND = Clockwork.command:New("Cid")
COMMAND.tip = "Запрос CID по ФИО гражданина."
COMMAND.text = "<string name>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (combine:IsCombine()) then
		local charName = string.lower(arguments[1])

		combine:CombineRequestSay("Центр, запрашиваю CID гражданина по имени "..string.upper(arguments[1])..".")

		for k, v in ipairs(_player.GetAll()) do
			if (v:HasInitialized()) then
				if (string.lower(v:Name()) == charName) then
					timer.Simple(2, function()
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("CID гражданина "..string.upper(arguments[1]).." - "..v:GetCharacterData("citizenid")..".")
					end)

					return
				else
					for k2, v2 in pairs(v:GetCharacters()) do
						if (string.lower(v2.name) == charName) then
							timer.Simple(2, function()
								combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
								combine:CombineRequestAnswer("CID гражданина "..string.upper(arguments[1]).." - "..v2.data["citizenid"] or "ERROR"..".")
							end)

							return
						end
					end
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();