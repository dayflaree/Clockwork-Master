--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("inforequest")
COMMAND.tip = "Запрос информации по CID."
COMMAND.text = "<string CID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) or combine:GetFaction() == FACTION_CWU then
		local CID = arguments[1]

		for k, v in pairs(player.GetAll()) do
			if (v:GetCharacterData("citizenid") == CID) then
				if (v:IsCitizen()) then

					combine:CombineRequestSay("Запрашиваю информацию о гражданине #"..CID..".")

					local civ_citizenid = v:GetCharacterData("citizenid")
					local civ_lid = v:GetCharacterData("civ_lid")
					local civ_reputation = v:GetCharacterData("civ_reputation")
					local civ_blackmarks = v:GetCharacterData("civ_blackmarks")
					local civ_verdict = v:GetCharacterData("civ_status")
					local civ_wp = v:GetCharacterData("civ_wp")
					local civ_faction = v:GetCharacterData("civ_faction")
					local wplevel = 0

					if (civ_wp >= 220) then
						wplevel = 10
					elseif (civ_wp >= 170) then
						wplevel = 9
					elseif (civ_wp >= 130) then
						wplevel = 8
					elseif (civ_wp >= 90) then
						wplevel = 7
					elseif (civ_wp >= 60) then
						wplevel = 6
					elseif (civ_wp >= 35) then
						wplevel = 5
					elseif (civ_wp >= 20) then
						wplevel = 4
					elseif (civ_wp >= 10) then
						wplevel = 3
					elseif (civ_wp >= 5) then
						wplevel = 2
					elseif (civ_wp >= 0) then
						wplevel = 1
					end

					timer.Simple(2, function()					
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Запрос информации о гражданине #"..CID.." был подтвержден.")
						combine:CombineRequestAnswer("Имя: "..v:GetName()..".")
						combine:CombineRequestAnswer("CID: "..civ_citizenid..".")
						combine:CombineRequestAnswer("Апартаменты: "..civ_lid..".")
						combine:CombineRequestAnswer("Очки лояльности: "..civ_reputation..".")
						combine:CombineRequestAnswer("Очки рабочего: "..civ_wp.." (Уровень: "..wplevel..").")
						combine:CombineRequestAnswer("Очки нарушения: "..civ_blackmarks..".")
						combine:CombineRequestAnswer("Гражданская фракция: "..civ_faction..".")
						combine:CombineRequestAnswer("Статус: "..civ_verdict..".")

						if (v:GetCharacterData("civ_jail_type") != "#N" and Schema:PlayerIsCombine(combine)) then
							combine:CombineRequestAnswer("Данный гражданин находится в заключении:")
							combine:CombineRequestAnswer("Причина задержания: "..v:GetCharacterData("civ_jail_type")..".")
							combine:CombineRequestAnswer("Срок (осталось): "..v:GetCharacterData("civ_jail_time").." минут(ы/а).")
						end
					end)

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО и не сотрудник ГСР!")
	end
end

COMMAND:Register();