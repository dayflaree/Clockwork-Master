--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]
local PLUGIN = PLUGIN

local COMMAND = Clockwork.command:New("apprequest")
COMMAND.tip = "Запрос списка жителей выбранного блока."
COMMAND.text = "<string LID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) then
		if (arguments[1]) then
			local LID = arguments[1]
			local location_civCount = 0
			local location_civTable = {}

			combine:CombineRequestSay("Запрашиваю список жителей апартаментов "..LID)

			for k,v in pairs(player.GetAll()) do
				if (v:IsPlayer() and v:Alive() and v:GetCharacterData("civ_lid") == LID) then
					location_civCount = location_civCount + 1
					table.insert(location_civTable, v)		
				end
			end

			timer.Simple(2, function()
				if (combine:Alive()) then	
					combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
					combine:CombineRequestAnswer("Запрос списка жителей апартаментов "..LID.." был подтвержден.")

					if (location_civCount >= 1) then
						for _k, _v in pairs(location_civTable) do
							combine:CombineRequestAnswer("#".._v:GetCharacterData("citizenid").." - ".._v:GetName()..".")
						end
					elseif (location_civCount == 0) then
						combine:CombineRequestAnswer("В апартаментах "..LID.." отсутствуют жители.")
					end
				end
			end)
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();