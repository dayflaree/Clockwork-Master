local PLUGIN = PLUGIN;

-- A function to load the Union locks.
function PLUGIN:LoadRebelLocks()
	local rebelLocks = Clockwork.kernel:RestoreSchemaData( "plugins/rebellocks/"..game.GetMap() );
	
	for k, v in pairs(rebelLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16)[1];
		
		if (IsValid(entity)) then
			local rebelLock = self:ApplyRebelLock(entity);
			
			if (rebelLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				rebelLock:SetLocalAngles(v.angles);
				rebelLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					rebelLock:Unlock();
				else
					rebelLock:Lock();
				end;
			end;
		end;
	end;
end;

-- A function to save the Union locks.
function PLUGIN:SaveRebelLocks()
	local rebelLocks = {};
	
	for k, v in pairs( ents.FindByClass("cw_rebellock") ) do
		if (IsValid(v.entity)) then
			rebelLocks[#rebelLocks + 1] = {
				key = Clockwork.entity:QueryProperty(v, "key"),
				locked = v:IsLocked(),
				angles = v:GetLocalAngles(),
				position = v:GetLocalPos(),
				uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID"),
				doorPosition = v.entity:GetPos()
			};
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/rebellocks/"..game.GetMap(), rebelLocks);
end;

-- A function to apply a Union lock.
function PLUGIN:ApplyRebelLock(entity, position, angles)
	local rebelLock = ents.Create("cw_rebellock");
	
	rebelLock:SetParent(entity);
	rebelLock:SetDoor(entity);
	
	if (position) then
		if (type(position) == "table") then
			rebelLock:SetLocalPos( Vector(-1.0313, 43.7188, -1.2258) );
			rebelLock:SetPos( rebelLock:GetPos() + (position.HitNormal * 4) );
		else
			rebelLock:SetPos(position);
		end;
	end;
	
	if (angles) then
		rebelLock:SetAngles(angles);
	end;
	
	rebelLock:Spawn();
	
	if (IsValid(rebelLock)) then
		return rebelLock;
	end;
end;

-- A function to bust down a door.
function PLUGIN:BustDownDoor(player, door, force)
	door.bustedDown = true;
	
	door:SetNotSolid(true);
	door:DrawShadow(false);
	door:SetNoDraw(true);
	door:EmitSound("physics/wood/wood_box_impact_hard3.wav");
	door:Fire("Unlock", "", 0);
	
	if (IsValid(door.rebelLock)) then
		door.rebelLock:Explode();
		door.rebelLock:Remove();
	end;
	
	if (IsValid(door.breach)) then
		door.breach:BreachEntity();
	end;
	
	local fakeDoor = ents.Create("prop_physics");
	
	fakeDoor:SetCollisionGroup(COLLISION_GROUP_WORLD);
	fakeDoor:SetAngles( door:GetAngles() );
	fakeDoor:SetModel( door:GetModel() );
	fakeDoor:SetSkin( door:GetSkin() );
	fakeDoor:SetPos( door:GetPos() );
	fakeDoor:Spawn();
	
	local physicsObject = fakeDoor:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		if (!force) then
			if (IsValid(player)) then
				physicsObject:ApplyForceCenter( (door:GetPos() - player:GetPos() ):GetNormal() * 10000 );
			end;
		else
			physicsObject:ApplyForceCenter(force);
		end;
	end;
	
	Clockwork.entity:Decay(fakeDoor, 300);
	
	Clockwork.kernel:CreateTimer("reset_door_"..door:EntIndex(), 300, 1, function()
		if (IsValid(door)) then
			door.bustedDown = nil;
			
			door:SetNotSolid(false);
			door:DrawShadow(true);
			door:SetNoDraw(false);
		end;
	end);
end;