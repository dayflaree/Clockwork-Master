local ITEM = Clockwork.item:New();
ITEM.name = "Gloves";
ITEM.model = "models/tnb/items/gloves.mdl";
ITEM.weight = 0.1;
ITEM.useText = "Wear";
ITEM.uniqueID = "gloves"
ITEM.category = "Clothing";
ITEM.description = "A pair of fingerless gloves. <color='2B62E3'>This item is legal.</color>";
ITEM.customFunctions = {"Remove"};
ITEM.access = "v";
ITEM.business = true; 
ITEM.spawnType = "misc";
ITEM.spawnValue = 10 
 
local bodyGroup = 3;
 

 -- Plus 5 clothing (warmth.)
 
-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
 
 
 
                        local target = player
                        local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                        local bodyGroupState = 0;
                        local model = target:GetModel();
               
                        if( bodyGroup < target:GetNumBodyGroups() )then
                                targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                                if( bodyGroupState == 0 )then
                                        targetBodyGroups[model][tostring(bodyGroup)] = nil;
                                else
                                        targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                                end;
                       
                                target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                                target:SetCharacterData("BodyGroups", targetBodyGroups);
								
								if ( player:GetCharacterData( "Gloves" ) ) then
									player:SetCharacterData("Clothing", math.Clamp( warmth - 5, 0, 20 ));
									player:SetCharacterData( "Gloves", false );
								end
                               
                        end;
return true
               
end;
 
 
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
 
        if (player:Alive() and !player:IsRagdolled()) then
                if (!self.CanPlayerWear or self:CanPlayerWear(player, itemEntity) != false) then
               
                local target = player
                local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                local bodyGroupState = 1;
 
                local model = target:GetModel();
               
                if( bodyGroup < target:GetNumBodyGroups() )then
                        targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                        if( bodyGroupState == 0 )then
                                targetBodyGroups[model][tostring(bodyGroup)] = nil;
                        else
                                targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                        end;
                       
                        target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                        target:SetCharacterData("BodyGroups", targetBodyGroups);
						
						if ( !player:GetCharacterData("Gloves") ) then
							player:SetCharacterData("Gloves", true);
						else
							Clockwork.player:Notify(player, "You are already wearing this!");
						end
               
                        return true;
 
                        end;
                end;
        end;
end;
 
if (SERVER) then
        function ITEM:OnCustomFunction(player, name)

                if (name == "Remove") then
               
                        local target = player
                        local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                        local bodyGroupState = 0;
                        local model = target:GetModel();
               
                        if( bodyGroup < target:GetNumBodyGroups() )then
                                targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                                if( bodyGroupState == 0 )then
                                        targetBodyGroups[model][tostring(bodyGroup)] = nil;
                                else
                                        targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                                end;
                       
                                target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                                target:SetCharacterData("BodyGroups", targetBodyGroups);
								
								if ( player:GetCharacterData("Gloves") ) then
									player:SetCharacterData("Gloves", false);
								end
                               
                        end;
                                               
end;
end;
end;
 
ITEM:Register();