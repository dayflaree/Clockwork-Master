local ITEM = Clockwork.item:New();
ITEM.name = "Grey Beanie";
ITEM.model = "models/tnb/items/beanie.mdl";
ITEM.weight = 0.1;
ITEM.addInvSpace = 0.5;
ITEM.useText = "Wear";
ITEM.uniqueID = "grey_beanie"
ITEM.category = "Clothing";
ITEM.description = "A knitted wool hat. <color='2B62E3'>This item is legal.</color>";
ITEM.customFunctions = {"Remove"};
ITEM.access = "v";
ITEM.business = true; 
ITEM.spawnType = "misc";
ITEM.spawnValue = 10  
 
local bodyGroup = 4;
 
 -- Plus 5 clothing (warmth.)

 
-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
 
 
                        local target = player
                        local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                        local bodyGroupState = 0;
                        local model = target:GetModel();
               
                        if( bodyGroup < target:GetNumBodyGroups() )then
                                targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                                if( bodyGroupState == 0 )then
                                        targetBodyGroups[model][tostring(bodyGroup)] = nil;
                                else
                                        targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                                end;
                       
                                target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                                target:SetCharacterData("BodyGroups", targetBodyGroups);
								
								if ( player:GetCharacterData( "Beanie" ) ) then
									player:SetCharacterData( "Beanie", false );
								end
                               
                        end;
return true
               
end;
 
 
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if !( player:GetCharacterData( "Beanie" ) ) then
        if (player:Alive() and !player:IsRagdolled()) then
                if (!self.CanPlayerWear or self:CanPlayerWear(player, itemEntity) != false) then
               
                local target = player
                local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                local bodyGroupState = 3;
 
                local model = target:GetModel();
               
                if( bodyGroup < target:GetNumBodyGroups() )then
                        targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                        if( bodyGroupState == 0 )then
                                targetBodyGroups[model][tostring(bodyGroup)] = nil;
                        else
                                targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                        end;
                       
                        target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                        target:SetCharacterData("BodyGroups", targetBodyGroups);				

						player:SetCharacterData( "Beanie", true );
               
                        return true;
 
                        end;
                end;
        end;
	else
		Clockwork.player:Notify(player, "You are already wearing a beanie! Take one off first!");
		return false;
	end
end;
 
if (SERVER) then
        function ITEM:OnCustomFunction(player, name)
		
                if (name == "Remove") then
               
                        local target = player
                        local targetBodyGroups = target:GetCharacterData("BodyGroups") or {};
                        local bodyGroupState = 0;
                        local model = target:GetModel();
               
                        if( bodyGroup < target:GetNumBodyGroups() )then
                                targetBodyGroups[model] = targetBodyGroups[model] or {};
                       
                                if( bodyGroupState == 0 )then
                                        targetBodyGroups[model][tostring(bodyGroup)] = nil;
                                else
                                        targetBodyGroups[model][tostring(bodyGroup)] = bodyGroupState;
                                end;
                       
                                target:SetBodygroup(bodyGroup, bodyGroupState);
                       
                                target:SetCharacterData("BodyGroups", targetBodyGroups);
								
								if ( player:GetCharacterData( "Beanie" ) ) then
									player:SetCharacterData( "Beanie", false );
								end
                               
                        end;
                                               
end;
end;
end;
 
ITEM:Register();