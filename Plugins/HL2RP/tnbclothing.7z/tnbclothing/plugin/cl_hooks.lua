-- Called to check if a player does recognise another player.
function PLUGIN:PlayerDoesRecognisePlayer(player, status, isAccurate, realValue)
	if (player:GetFaction() == FACTION_CITIZEN) then 
		if (player:GetBodygroup(4) = 1 or player:GetBodygroup(4) = 2) then
			return false
		end
	end
end;
