local PLUGIN = PLUGIN;

-- A function to play a sound over the radio.
function PLUGIN:PlayRadioSound(sound, frequency)
	for k, v in pairs(cwPlayer.GetAll()) do
		if (IsValid(v) and v:HasInitialized() and v:HasItemByID("handheld_radio") and v:GetCharacterData("frequency") == frequency) then
			v:EmitSound(sound or "");
		end;
	end;
end;