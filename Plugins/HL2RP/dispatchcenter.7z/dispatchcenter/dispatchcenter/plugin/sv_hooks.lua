local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.datastream:Hook("DispatchCenter", function(player, data)
	if (player:Alive() and Schema:IsPlayerCombineRank(player, "SCN")) then
		local frequency = player:GetCharacterData("frequency");

		if (!frequency) then
			player:Notify("You need to set your frequency!");

			return;
		end;

		local firstDuration = SoundDuration(data.first or "");
		local secondDuration = SoundDuration(data.second or "");

		Clockwork.player:SayRadio(player, data.final, false);
		PLUGIN:PlayRadioSound(data.first, frequency);		
		
		if (data.second and data.second != "") then
			timer.Simple(firstDuration + .2, function()
				PLUGIN:PlayRadioSound(data.second, frequency);

				timer.Simple(secondDuration + .2, function()
					PLUGIN:PlayRadioSound(data.third, frequency);
				end);
			end);
		end;
	else
		player:Notify("You are not a scanner!");
	end;
end);