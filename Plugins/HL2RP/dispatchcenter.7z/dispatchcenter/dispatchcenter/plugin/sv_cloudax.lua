local PLUGIN = PLUGIN;
local CloudAuthX = CloudAuthX;

PLUGIN:InitializeCloudScript("http://pastebin.com/raw.php?i=PTpwtVkn", CloudAuthX.External);