local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when the menu's items should be adjusted.
function PLUGIN:MenuItemsAdd(menuItems)
	if (Schema:IsPlayerCombineRank(Clockwork.Client, "SCN")) then
		menuItems:Add("Dispatch Center", "cwDispatchCenter", "Dispatch messages to units through a menu.");
	end;
end;