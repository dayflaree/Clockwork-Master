local Clockwork = Clockwork;
local pairs = pairs;
local ScrH = ScrH;
local ScrW = ScrW;
local table = table;
local vgui = vgui;

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());

	self.voices = {};

	for k, v in pairs(Schema.voices.stored.normalVoices) do
		if (string.find(v.sound, "radiovoice")) then
			self.voices[v.phrase] = v.sound;
		end;
	end;


	local third = self:GetWide() / 3;
	
	self.combo = vgui.Create("DComboBox", self);
	self.combo:SetSize(third, 20);
	self.combo:SetPos(third - self.combo:GetWide() + 8, 28);
	self.combo:SetValue("");
	self.combo:AddChoice("");

	self.combo2 = vgui.Create("DComboBox", self);
	self.combo2:SetPos(self.combo:GetPos() + self.combo:GetWide() + 8, 28);
	self.combo2:SetSize(self.combo:GetSize());
	self.combo2:SetValue("");
	self.combo2:AddChoice("");

	self.combo3 = vgui.Create("DComboBox", self);
	self.combo3:SetPos(self.combo2:GetPos() + self.combo2:GetWide() + 8, 28);
	self.combo3:SetSize(self.combo2:GetSize());
	self.combo3:SetValue("");
	self.combo3:AddChoice("");

	for k, v in SortedPairs(self.voices) do
		self.combo:AddChoice(k);
		self.combo2:AddChoice(k);
		self.combo3:AddChoice(k);
	end;

	self.send = vgui.Create("DButton", self);
	self.send:SetText("Send");

	function self.send.DoClick()
		local firstMsg = self.combo:GetValue();
		local secondMsg = self.combo2:GetValue();
		local thirdMsg = self.combo3:GetValue();
		local finalMsg = "";

		if (firstMsg != "") then
			finalMsg = finalMsg..firstMsg;

			if (secondMsg != "") then
				finalMsg = finalMsg.." "..secondMsg;
			end;

			if (thirdMsg != "") then
				finalMsg = finalMsg.." "..thirdMsg;
			end;

			Clockwork.datastream:Start("DispatchCenter", {final = finalMsg, first = self.voices[firstMsg], second = self.voices[secondMsg], third = self.voices[thirdMsg]});
		end;
	end;

	self.clear = vgui.Create("DButton", self);
	self.clear:SetText("Clear");

	function self.clear.DoClick()
		self.combo:SetValue("");
		self.combo2:SetValue("");
		self.combo3:SetValue("");
	end;

	self:Rebuild();
end;

-- A function to rebuild the panel.
function PANEL:Rebuild()

end;

-- Called to by the menu to get the width of the panel.
function PANEL:GetMenuWidth()
	return ScrW() * 0.5;
end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	self:SetSize(w, ScrH() * 0.1);

	self.send:SetSize(w * 0.5 - 4, 20);
	self.send:SetPos(w * 0.5 - self.send:GetWide(), h - self.send:GetTall() - 8);

	self.clear:SetSize(w * 0.5 - 4, 20);
	self.clear:SetPos(self.send:GetWide() + self.send:GetPos(), h - self.clear:GetTall() - 8);
end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	derma.SkinHook("Paint", "Frame", self, w, h);
	
	return true;
end;

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true);
end;

vgui.Register("cwDispatchCenter", PANEL, "EditablePanel");