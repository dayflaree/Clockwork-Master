
local PLUGIN = PLUGIN;

PLUGIN:AddGroup("Hunter", function(player)
	if (Clockwork.player:GetFactionTable(player).hunterVoices) then return true end;
end);

PLUGIN:Add("Hunter", "ANGRY1", "Ghrroughllllghrrr!", "npc/ministrider/hunter_angry1.wav", nil, 3.5238775510204081);
PLUGIN:Add("Hunter", "ANGRY2", "Hrrgghhhrrahhh!", "npc/ministrider/hunter_angry2.wav", nil, 1.85231292517006807);
PLUGIN:Add("Hunter", "ANGRY3", "Grrhough roughl!", "npc/ministrider/hunter_angry3.wav", nil, 1.85231292517006807);