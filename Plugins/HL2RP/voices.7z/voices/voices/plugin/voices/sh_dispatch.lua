
local PLUGIN = PLUGIN;

PLUGIN:AddGroup("Dispatch", function(player, class)
	if (class == "dispatch") then return true end;
end);

local function AddDispatch(command, phrase, sound, duration)
	PLUGIN:Add("Dispatch", command, phrase, sound, nil, duration);
end;

AddDispatch("404 ZONE", "Four-hundred-and-four zone", "npc/overwatch/radiovoice/404zone.wav", 1.2674829931972789);
AddDispatch("ACCOMPLICES", "Protection-teams, be advised: Accomplices operating in area", "npc/overwatch/radiovoice/accomplicesoperating.wav", 3.6792743764172338);
AddDispatch("ACTIVITY LEVEL 1", "You are charged with anti-civil activity level: ONE. Protection-unit prosecution code: DUTY; SWORD; OPERATE", "npc/overwatch/cityvoice/f_anticivil1_5_spkr.wav", 12.40530612244898);
AddDispatch("ANTI-CITIZEN", "Attention, ground-units: Anti-citizen reported in this community. Code: LOCK; CAUTERIZE; STABILIZE", "npc/overwatch/cityvoice/f_anticitizenreport_spkr.wav", 12.490566893424036);
AddDispatch("ANTI-CIVIL EVIDENCE", "Protection-team; alert: Evidence of anti-civil activity in this community. Code: ASSEMBLE; CLAMP; CONTAIN", "npc/overwatch/cityvoice/f_anticivilevidence_3_spkr.wav", 12.363900226757369);
AddDispatch("ASSUME POSITIONS", "Attention, please: All citizens in local residential block, assume your inspection-positions", "npc/overwatch/cityvoice/f_trainstation_assumepositions_spkr.wav", 9.2783219954648519);
AddDispatch("AUTONOMOUS", "Attention, all ground-protection teams; autonomous judgment is now in effect. Sentencing is now discretionary. Code, AMPUTATE; ZERO; CONFIRM", "npc/overwatch/cityvoice/f_protectionresponse_4_spkr.wav", 14.396462585034014);
AddDispatch("STATUS APPROVED", "Individual; you are charged with capital malcompliance. Anti-citizen status; APPROVED", "npc/overwatch/cityvoice/f_capitalmalcompliance_spkr.wav", 7.4295691609977323);
AddDispatch("CITIZEN RELOCATION", "Citizen notice: Failure to co-operate will result in permanent off-world relocation", "npc/overwatch/cityvoice/f_trainstation_offworldrelocation_spkr.wav", 8.9833106575963715);
AddDispatch("CONSPIRACY", "Citizen reminder: Inaction is conspiracy. Report counter-behavior to a Civil-Protection team immediately", "npc/overwatch/cityvoice/f_innactionisconspiracy_spkr.wav", 10.739682539682539);
AddDispatch("CONVICTED", "Individual; you are convicted of multi-anti-civil violations. Implict citizenship revoked. Status; MALIGNANT", "npc/overwatch/cityvoice/f_citizenshiprevoked_6_spkr.wav", 11.702811791383221);
AddDispatch("DEDUCTED", "Attention, occupants: Your block is now charged with permissive inactive coersion. Five ration-units deducted", "npc/overwatch/cityvoice/f_rationunitsdeduct_3_spkr.wav", 11.40671201814059);
AddDispatch("EVASION BEHAVIOR", "Attention, please; evasion behaviour consistent with malcompliant defendant. Ground protection-team, alert; code, ISOLATE; EXPUNGE; ADMINISTER", "npc/overwatch/cityvoice/f_evasionbehavior_2_spkr.wav", 18.518684807256236);
AddDispatch("INDIVIDUAL CHARGED WITH", "Individual; you are charged with socio-endangerment level: ONE. Protection-unit prosecution code, DUTY; SWORD; MIDNIGHT", "npc/overwatch/cityvoice/f_sociolevel1_4_spkr.wav", 14.692698412698412);
AddDispatch("INSPECTION", "Citizen notice; priority identification-check in-progress. Please assemble in your designated inspection positions", "npc/overwatch/cityvoice/f_trainstation_assemble_spkr.wav", 13.182267573696144);
AddDispatch("JUDGMENT", "Attention, all ground-protection teams; judgment waiver now in effect. Capital prosecution is discretionary", "npc/overwatch/cityvoice/f_protectionresponse_5_spkr.wav", 11.540408163265306);
AddDispatch("MISCOUNT DETECTED", "Attention, residents: Miscount detected in your block. Co-operation with your Civil Protection team permits full ration reward", "npc/overwatch/cityvoice/f_trainstation_cooperation_spkr.wav", 14.069750566893424);
AddDispatch("MISSION FAILURE", "Attention, ground-units: Mission-failure will result in permanent off-world assignment. Code-reminder: SACRIFICE; COAGULATE; CLAMP", "npc/overwatch/cityvoice/fprison_missionfailurereminder.wav", 13.313106575963719);
AddDispatch("OVERWATCH ACKNOWLEDGES", "Overwatch acknowledges critical exogen-breach. AirWatch augmentation-force dispatched and inbound. Hold for re-enforcement", "npc/overwatch/cityvoice/fprison_airwatchdispatched.wav", 13.426303854875284);
AddDispatch("POTENTIAL INFECTION", "Attention, residents: This blocks contains potential civil infection. INFORM; CO-OPERATE; ASSEMBLE", "npc/overwatch/cityvoice/f_trainstation_inform_spkr.wav", 11.569433106575964);
AddDispatch("SECTOR ASSIMILATION", "All autonomous units: accept mandatory sector assimilation. Co-ordinated constriction underway. Debride and cauterize. Entering Phase Nine: Enhanced Compliance. Deploy advisory control and oversight. Submit and be subsumed.", "vo/outland_05/canyon/over_vista.wav", 40);
AddDispatch("SECTOR SWEEP", "Ongoing sector sweep: biotics confirmed. Continue surface sector sweep. Remote compliance. Exterminate. Seek passive signature imprint. Mandate sublevel restrictions.", "vo/outland_01/intro/over_camp.wav", 28);
AddDispatch("STATUS EVASION", "Attention, protection-team; status evasion in progress in this community. RESPOND; ISOLATE; INQUIRE", "npc/overwatch/cityvoice/f_protectionresponse_1_spkr.wav", 10.55374149659864);
AddDispatch("UNIDENTIFIED", "Attention, please: Unidentified person of interest; confirm your civil status with local protection-team immediately", "npc/overwatch/cityvoice/f_confirmcivilstatus_1_spkr.wav", 11.098820861678005);
AddDispatch("UNREST PROCEDURE", "Attention, community: Unrest procedure code is now in effect. INNOCULATE; SHIELD; PACIFY. Code: PRESSURE; SWORD; STERILIZE", "npc/overwatch/cityvoice/f_unrestprocedure1_spkr.wav", 17.586666666666666);
AddDispatch("UNREST STRUCTURE", "Alert, community ground-protection units; local unrest structure detected. ASSEMBLE; ADMINISTER; PACIFY", "npc/overwatch/cityvoice/f_localunrest_spkr.wav", 12.30952380952381);
AddDispatch("VITAL ALERT", "Vital alert: Autonomous unit subsumed. Mandatory compliance with all tenets of advisorial assistance act. Threat level adjustment: PROBE, EXPUNGE.", "vo/outland_07/barn/over_barn.wav", 23);
AddDispatch("RESTRICTORS DISENGAGED", "Priority warning; perimeter restrictors disengaged, all stabilization delegates move to incursion hard-point immediately", "npc/overwatch/cityvoice/fprison_restrictorsdisengaged.wav", 11.30952380952381);