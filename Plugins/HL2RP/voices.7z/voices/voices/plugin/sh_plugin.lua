
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local stored = {};

-- A function to get the stored voices.
function PLUGIN:GetStored()
	return stored;
end;

-- A function to add a group
function PLUGIN:AddGroup(name, canSay)
	if (name and type(name) == "string" and canSay and type(canSay) == "function") then
		stored[name] = {voices = {}, canSay = canSay};
	end;
end;
         
-- A function to add a voice.
function PLUGIN:Add(group, command, phrase, sound, female, duration, keepCasing)
	if (stored[group]) then
		stored[group].voices[tostring(string.upper(command))] = {
			command = tostring(command),
			faction = faction,
			phrase = phrase,
			female = female,
			sound = sound,
			duration = duration or SoundDuration(sound),
			keepCasing = keepCasing
		};
	end;
end;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

for k, v in pairs(file.Find(Clockwork.kernel:GetSchemaFolder().."/plugins/voices/plugin/voices/*.lua", "LUA", "namedesc")) do
	Clockwork.kernel:IncludePrefixed(Clockwork.kernel:GetSchemaFolder().."/plugins/voices/plugin/voices/"..v);
end;

if (CLIENT) then
	local sortFunc = function(a, b) return a.command < b.command end;
	local sortedTable = {};
	for k, v in pairs(stored) do
		sortedTable[k] = {};
		for k1, v1 in pairs(v.voices) do
			sortedTable[k][#sortedTable[k] + 1] = v1;
		end;
		table.sort(sortedTable[k], sortFunc);
	end;

	for k, v in pairs(sortedTable) do
		Clockwork.directory:AddCategory(k, "Commands");
		for k1, v1 in pairs(v) do
			Clockwork.directory:AddCode(k, [[
				<div class="auraInfoTitle"><b>]]..string.upper(v1.command)..[[</div>
				<div class="auraInfoText">]]..v1.phrase..[[</div></br>
			]], true);
		end;
	end;
end;