
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local pairs = pairs;
local ipairs = ipairs;
local string = string;
local table = table;

PLUGIN.voiceClasses = {"ic", "yell", "whisper", "radio", "request", "radio_transmit", "dispatch", "radio_transmit", "radio_eavesdrop", "ptradio", "ptradio_eavesdrop"};
for i = 1, #PLUGIN.voiceClasses do
	PLUGIN.voiceClasses[PLUGIN.voiceClasses[i]] = true;
	PLUGIN.voiceClasses[i] = nil;
end;

local function fixMarkup(a, b)
	return a.." "..string.upper(b) 
end;

-- Called when chat box info should be adjusted.
function PLUGIN:ChatBoxAdjustInfo(info)
	if (self.voiceClasses[info.class]) then
		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
			local voiceTables = {};
			for k, v in pairs(self:GetStored()) do
				if (v.canSay(info.speaker, info.class)) then
					voiceTables[#voiceTables + 1] = v.voices;
				end;
			end;

			local textTable = string.Explode("; ?", info.text, true);
			local voiceList = {};

			for k, v in ipairs(textTable) do
				local bFound = false;
				local text = string.upper(v);
				for _, voiceTable in pairs(voiceTables) do
					if (voiceTable[text]) then
						bFound = true;

						local voice = voiceTable[text];
						local voiceListEntry = {
							global = false,
							volume = 90,
							sound = voice.sound,
							duration = voice.duration
						};

						if (voice.female and info.speaker:QueryCharacter("gender") == GENDER_FEMALE) then
							if (type(voice.female) == "string") then
								voiceListEntry.sound = voice.female;
							else
								voiceListEntry.sound = string.Replace(voice.sound, "/male", "/female");
							end;
						end;

						if (info.class == "request" or info.class == "radio" or info.class == "dispatch" or info.class == "radio_transmit" or info.class == "radio_eavesdrop") then
							voiceListEntry.global = true;
						elseif (info.class == "whisper") then
							voiceListEntry.volume = 80;
						elseif (info.class == "yell") then
							voiceListEntry.volume = 100;
						end;

						if (k == 1 or voice.keepCasing) then
							textTable[k] = voice.phrase;
						else
							textTable[k] = string.lower(voice.phrase);
						end;

						if (k != #textTable) then
							local endText = string.sub(voice.phrase, -1);
							if (endText == "!" or endText == "?") then
								textTable[k] = string.gsub(textTable[k], "[!?]$", ",");
							end;
						end;

						voiceList[#voiceList + 1] = voiceListEntry;

						break;
					end;
				end;

				if (bFound == false and k != #textTable) then
					textTable[k] = v.."; ";
				end;
			end;

			info.text = table.concat(textTable, " ");
			info.text = string.gsub(info.text, " ?([.?!]) (%l?)", fixMarkup);

			if (voiceList[1]) then
				info.voiceList = voiceList;
			end;
		end;
	end;
end;

function PLUGIN:ChatBoxMessageAdded(info)
	if (info.voiceList and info.voiceList[1]) then
		local delay = 0;
		for k, v in ipairs(info.voiceList) do
			if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
					
					local guy = info.speaker

					if (guy:GetGender() == GENDER_FEMALE and info.class != "dispatch") then
						pitch = math.random(105,112)
					elseif (guy:GetGender() == GENDER_MALE and info.class != "dispatch") then
						pitch = math.random(93,100)
					else
						pitch = 100
					end
				
				if (delay == 0) then
					info.speaker:EmitSound(v.sound, v.volume, pitch);
				else
					timer.Simple(delay, function() info.speaker:EmitSound(v.sound, v.volume, pitch) end);
				end;
			end;

			if (v.global) then
				if (delay == 0) then
					for k1, v1 in pairs(info.listeners) do
						if (v1 != info.speaker) then
							Clockwork.player:PlaySound(v1, v.sound, pitch);
						end;
					end;
				else
					timer.Simple(delay, function()
						for k1, v1 in pairs(info.listeners) do
							if (v1 != info.speaker) then
								Clockwork.player:PlaySound(v1, v.sound, pitch);
							end;
						end;
					end);
				end;
			end;

			delay = delay + v.duration + 0.01;
		end;
	end;
end;