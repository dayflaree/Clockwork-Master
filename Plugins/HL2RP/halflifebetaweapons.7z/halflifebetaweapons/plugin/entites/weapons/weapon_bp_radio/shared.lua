if SERVER then
	AddCSLuaFile ("shared.lua")
	SWEP.AutoSwitchTo		= true
	SWEP.AutoSwitchFrom		= false
else
	print ("run on client")
	SWEP.DrawCrosshair		= false
	SWEP.PrintName			= "Radio"
	SWEP.Category			= "HL2 Beta Sweps"
	SWEP.Slot 			= 5
	SWEP.SlotPos 			= 7
	SWEP.BounceWeaponIcon 		= false 
	SWEP.DrawWeaponInfoBox		= false
	SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/radio") 
	language.Add("weapon_bp_radio", "Radio")
	end

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true
SWEP.HoldType			= "normal"

SWEP.ViewModel			= "models/props_lab/citizenradio.mdl"
SWEP.BobScale			= 2
SWEP.SwayScale			= 2
SWEP.WorldModel			= "models/props_lab/citizenradio.mdl"

SWEP.Primary.ClipSize		= -1 
SWEP.Primary.DefaultClip	= -1 
SWEP.Primary.Automatic		= false 
SWEP.Primary.Ammo			= "none" 

SWEP.Secondary.ClipSize		= -1 
SWEP.Secondary.DefaultClip	= -1 
SWEP.Secondary.Automatic	= false 
SWEP.Secondary.Ammo			= "none"

--actual SWEP details
SWEP.ViewModelDefPos = Vector (-11.9885, -45.7463, -22.2584)
SWEP.ViewModelDefAng = Vector (-178.6234, 7.6472, 176.4833)

SWEP.MoveToPos = Vector (-15.2644, -44.5813, -24.8858)
SWEP.MoveToAng = Vector (-179.1521, 5.1085, 168.4864)

SWEP.Sound = Sound ("weapons/music.wav")

SWEP.Volume = 7
SWEP.Influence = 0

SWEP.LastSoundRelease = 0
SWEP.RestartDelay = 0
SWEP.RandomEffectsDelay = 0.2

function SWEP:PrimaryAttack() end
function SWEP:SecondaryAttack() end

function SWEP:GetViewModelPosition (pos, ang, inv, mul)
	local mul = 0
	if self.Weapon:GetNWBool ("on") then
		self.Volume = math.Clamp (self.Volume + FrameTime() * 3, 0, 1)
	else
		self.Volume = math.Clamp (self.Volume - FrameTime() * 3, 0, 1)
	end
	mul = self.Volume
	
	--this is always applied
	local DefPos = self.ViewModelDefPos
	local DefAng = self.ViewModelDefAng
	
	if DefAng then
		ang = ang * 1
		ang:RotateAroundAxis (ang:Right(), 		DefAng.x)
		ang:RotateAroundAxis (ang:Up(), 		DefAng.y)
		ang:RotateAroundAxis (ang:Forward(), 	DefAng.z)
	end

	if DefPos then
		local Right 	= ang:Right()
		local Up 		= ang:Up()
		local Forward 	= ang:Forward()
	
		pos = pos + DefPos.x * Right
		pos = pos + DefPos.y * Forward
		pos = pos + DefPos.z * Up
	end
	
	--and some more
	local AddPos = self.MoveToPos - self.ViewModelDefPos
	local AddAng = self.MoveToAng - self.ViewModelDefAng
	
	if AddAng then
		ang = ang * 1
		ang:RotateAroundAxis (ang:Right(), 		AddAng.x * mul)
		ang:RotateAroundAxis (ang:Up(), 		AddAng.y * mul)
		ang:RotateAroundAxis (ang:Forward(), 	AddAng.z * mul)
	end

	if AddPos then
		local Right 	= ang:Right()
		local Up 		= ang:Up()
		local Forward 	= ang:Forward()
	
		pos = pos + AddPos.x * Right * mul
		pos = pos + AddPos.y * Forward * mul
		pos = pos + AddPos.z * Up * mul
	end
	
	return pos, ang
end

SWEP.RandomEffects = {
	{function (npc,pl)
		npc:Fire ("ignite","120",0)
		npc:SetHealth (math.Clamp (npc:Health(), 5, 25))
		npc:AddEntityRelationship (pl,D_FR,99)
	end, 1},
	{function (npc)
		local explos = ents.Create ("env_Explosion")
		explos:SetPos (npc:GetPos() + Vector (0,0,4))
		explos:SetKeyValue ("iMagnitude", 200)
		explos:SetKeyValue ("iRadiusOverride", 50)
		explos:Spawn ()
		explos:Fire ("explode", "", 0)
		explos:Fire ("kill", "", 0.1)
	end, 0.1},
	{function (npc)
		
	end, 0.1},
}

function SWEP:Think ()
	if SERVER then
		self.LastFrame = self.LastFrame or CurTime()
		self.LastRandomEffects = self.LastRandomEffects or 0
		
		if self.Owner:KeyDown (IN_ATTACK) and self.LastSoundRelease + self.RestartDelay < CurTime() then
			if not self.SoundObject then
				self:CreateSound()
			end
			self.SoundObject:PlayEx(5, 100)
			
			self.Volume = math.Clamp (self.Volume + CurTime() - self.LastFrame, 0, 2)
			self.Influence = math.Clamp (self.Influence + (CurTime() - self.LastFrame) / 2, 0, 1)
			//self.SoundObject:ChangeVolume (self.Volume)
			
			self.SoundPlaying = true
		else
			if self.SoundObject and self.SoundPlaying then
				self.SoundObject:FadeOut (0.8)			
				self.SoundPlaying = false
				self.LastSoundRelease = CurTime()
				self.Volume = 0
				self.Influence = 0
			end
		end
		self.LastFrame = CurTime()
		self.Weapon:SetNWBool ("on", self.SoundPlaying)
		
		if self.Influence > 0.5 and self.LastRandomEffects + self.RandomEffectsDelay < CurTime() then
			--print ("influence: "..self.Influence)
			for _,npc in pairs (ents.FindInSphere (self.Owner:GetPos(), 768)) do
				if npc:IsNPC() and npc:Health() > 0 then
					print (tostring(npc))
					--we want only NPCs vaguely in view to be affected, so players can always see their torture victims. also, it's more loyal to the chaingun-esque original shown in video.
					local vec1 = ((npc:GetShootPos() or npc:GetPos()) - self.Owner:GetShootPos())//:Normalize()
					local vec2 = self.Owner:GetAimVector()
					local dot = vec1:DotProduct (vec2)
					//print (dot)
					if dot > 0.5 then --good enough for fov 90
						--apply random effects.
						local chanceMul = self.Influence * (768 - ((npc:GetShootPos() or npc:GetPos()) - self.Owner:GetShootPos()):Length()) / 1000
						print (chanceMul)
						for k,v in pairs (self.RandomEffects) do
							npc.effects = npc.effects or {}
							if math.random() < chanceMul * v[2] * dot and not npc.effects[k] then
								print ("effect "..k)
								v[1](npc,self.Owner)
								--npc.effects[k] = true
								done = true
							end
						end
					end
				end
			end
			self.LastRandomEffects = CurTime()
			print ("\n")
		end
	end
end

function SWEP:CreateSound ()
	self.SoundObject = CreateSound (self.Weapon, self.Sound)
	self.SoundObject:Play()
end

function SWEP:Holster() self:EndSound() return true end
function SWEP:OwnerChanged() self:EndSound() end

function SWEP:EndSound ()
	if self.SoundObject then
		self.SoundObject:Stop()
	end
end

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end