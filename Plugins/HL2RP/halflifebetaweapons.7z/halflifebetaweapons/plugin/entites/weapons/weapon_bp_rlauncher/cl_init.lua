include('shared.lua')
	language.Add("weapon_bp_rlauncher", "Leak Rocket Launcher")
	SWEP.PrintName		= "Rocket Launcher"
	SWEP.Slot		= 4
	SWEP.SlotPos		= 5
	SWEP.CSMuzzleFlashes    = true
	SWEP.ViewModelFOV	= 64
	SWEP.Drawammo 		= true
	SWEP.DrawCrosshair 	= true
	SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_launcher") 