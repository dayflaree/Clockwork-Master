if SERVER then

	AddCSLuaFile( "shared.lua" )
	
	SWEP.HoldType			= "fist"
	SWEP.Curtime			= "0.1"
	
end

if CLIENT then

language.Add("weapon_bp_manhack", "Manhack")

SWEP.PrintName = "Manhack"
SWEP.Category = "HL2 Beta Sweps"
SWEP.Slot = 0
SWEP.SlotPos = 4
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 64
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_manhack") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end
 
function SWEP:Reload()
end 
 
function SWEP:Think()
end

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
		return true
        end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_IDLE);
   return true
end

function SWEP:PrimaryAttack()
self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)

local trace = self.Owner:GetEyeTrace()

if trace.HitPos:Distance(self.Owner:GetShootPos()) <= 85 then
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0.3, 0.3, 0.3)
	bullet.Tracer = 0
	bullet.Force  = 1
	bullet.Damage = 4
self.Owner:FireBullets(bullet) 
self.Weapon:EmitSound( "npc/manhack/grind" .. math.random( 1,2,3,4,5 ) .. ".wav" )
else
end

end
 
function SWEP:Deploy()
return true;
end

function SWEP:Holster()
return true;
end

function SWEP:SecondaryAttack()
end

function SWEP:DoImpactEffect()
return true
end

 SWEP.HoldType			= "fist"
-------------------------------------------------------------------
SWEP.Spawnable      = true
SWEP.AdminSpawnable  = false
-----------------------------------------------
SWEP.ViewModel      = "models/weapons/v_M4nhack.mdl"
SWEP.WorldModel   = "models/manhack.mdl"
-----------------------------------------------
SWEP.Primary.Delay		= 0.7
SWEP.Primary.Recoil		= 0
SWEP.Primary.Damage		= 4
SWEP.Primary.NumShots		= -1		
SWEP.Primary.Cone		= 2
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic   	= true
SWEP.Primary.Ammo         	= "none" 
-------------------------------------------------