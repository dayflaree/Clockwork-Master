AddCSLuaFile( "init.lua" )
AddCSLuaFile( "shared.lua" )
include( "shared.lua" )

local ForceMultiplier = 0.015

hook.Add("EntityTakeDamage","BlobStickyDetonation",function(ent, dmginfo)

	local inflictor = dmginfo:GetInflictor()
	local attacker = dmginfo:GetAttacker()
	local amount	= dmginfo:GetDamage()
	if not inflictor.Explosive then return end
	
	if ent:IsNPC() or ent:IsPlayer() then
		-- Projectiles such as grenades don't do physical damage
		if not dmginfo:IsExplosionDamage() then
			dmginfo:SetDamage(0)
			return
		end
		
		-- Self damage reduction
		if attacker==ent and ent:IsPlayer() then
			if inflictor.OwnerDamage then
				dmginfo:SetDamage(dmginfo:GetDamage() * inflictor.OwnerDamage)
				dmginfo:SetDamageForce(dmginfo:GetDamageForce() * 2)
			else
				dmginfo:SetDamage(dmginfo:GetDamage() * 0.5)
				dmginfo:SetDamageForce(dmginfo:GetDamageForce() * 2)
			end
		end
		
		-- Overexaggerated explosion force
		ent:SetVelocity(ent:GetVelocity()+(dmginfo:GetDamageForce() * ForceMultiplier))
		
	end
end)