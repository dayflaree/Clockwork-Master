
if (SERVER) then
	AddCSLuaFile( "shared.lua" )
	SWEP.HoldType			= "pistol"
	SWEP.Weight		= 5
	SWEP.AutoSwitchTo	= true
	SWEP.AutoSwitchFrom	= true
end

if ( CLIENT ) then
SWEP.PrintName			= "Cubemap"
language.Add("weapon_bp_cubemap", "CUBEMAP")
SWEP.Slot = 5
SWEP.SlotPos = 2
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/cubemap") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end

SWEP.Category = "HL2 Beta Sweps" 

SWEP.Spawnable     			= true
SWEP.AdminSpawnable  		= false
 
SWEP.ViewModel		= "models/ShaderTest/envballs.mdl"
SWEP.WorldModel		= "models/weapons/w_pistol.mdl"

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Ammo = "none"
SWEP.Primary.Automatic		= true

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Ammo = false
SWEP.Secondary.Automatic = false

function SWEP:PrimaryAttack()
end

function SWEP:Holster()
self.Owner:SetFOV( 0, 0 )
return true
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()	
end

function SWEP:Initialize()
end