if SERVER then
AddCSLuaFile("shared.lua")
SWEP.Weight			= 5
SWEP.AutoSwitchTo		= true
SWEP.AutoSwitchFrom		= true
SWEP.HoldType		= "grenade"
end

if CLIENT then
language.Add("weapon_bp_hopwire", "Hopwire")

SWEP.Category 		= "HL2 Beta Sweps"
SWEP.PrintName = "Hopwire"
SWEP.Slot = 4
SWEP.SlotPos = 4
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false
SWEP.DrawWeaponInfoBox	= false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_hopwire") 
SWEP.BounceWeaponIcon = false 
end

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true


SWEP.ViewModel			= "models/weapons/v_hopwir3.mdl"
SWEP.WorldModel			= "models/weapons/w_hopwire.mdl"

game.AddAmmoType( { name = "bp_hopwire" } )
if ( CLIENT ) then language.Add( "bp_hopwire_ammo", "Hopwire Grenades" ) end

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= 5
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo		= "bp_hopwire"
SWEP.Primary.Delay			= 2

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"