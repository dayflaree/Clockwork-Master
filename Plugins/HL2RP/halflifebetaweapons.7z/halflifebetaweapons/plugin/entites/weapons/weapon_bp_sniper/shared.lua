if SERVER then
AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo		= true
	SWEP.AutoSwitchFrom		= true
	SWEP.HoldType			= "ar2"
end

if CLIENT then
language.Add("weapon_bp_sniper", "Sniper Rifle")

SWEP.Category			= "HL2 Beta Sweps"
SWEP.PrintName			= "Sniper Rifle"
SWEP.Slot				= 3
SWEP.SlotPos			= 4
SWEP.DrawAmmo			= true
SWEP.DrawCrosshair		= true
SWEP.ViewModelFOV		= 55
SWEP.ViewModelFlip		= false

SWEP.WepSelectIcon		= surface.GetTextureID("HUD/swepicons/weapon_sniper") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon	= false 
end
	
SWEP.ViewModel		= "models/rtb_weapons/v_sniper.mdl"
SWEP.WorldModel		= "models/rtb_weapons/w_sniper.mdl"
SWEP.HoldType		= "ar2"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= false

game.AddAmmoType( { name = "bp_sniper" } )
if ( CLIENT ) then language.Add( "bp_sniper_ammo", "Sniper Rounds" ) end

SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 3
SWEP.Primary.Automatic		= false
SWEP.Primary.Delay			= 0.5
SWEP.Primary.Ammo			= "xbowbolt"
SWEP.Primary.Force = 1000

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false

SWEP.Zoom = 0

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
   return true
end

function SWEP:Holster()
	self.Owner:SetFOV( 0, 0.25 )
	self.Owner:DrawViewModel(true)
	self:StopIdle()
	self.Owner:ConCommand("pp_mat_overlay \"\"");
	self.Zoom = 0

	return true
end

function SWEP:Reload()
	if self:DefaultReload( ACT_VM_RELOAD ) then
		self:Idle()
		self:EmitSound(Sound("weapons/1sniper/sniper_reload.wav")) 
		self.Owner:SetFOV( 0, .5 )
		self.Owner:DrawViewModel(true)
		self.Owner:ConCommand("pp_mat_overlay \"\"");
		self.Zoom = 0
			end
		end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then		
		self:Idle()
	end
end

function SWEP:PrimaryAttack()

	if ( !self:CanPrimaryAttack() ) then return end

		if (Zoom == 0 || self:Clip1() < 2 ) then
		self:ShootBullet( 150, 1, 0.0005 )
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
		self:EmitSound( Sound("weapons/1sniper/sniper_fire.wav") )
		self:TakePrimaryAmmo( 1 )
		self.Owner:ViewPunch( Angle( -8,math.random(-1,1),0 ) )
	else
        
		if (Zoom == 1 || self:Clip1() < 2 ) then
		self:ShootBullet( 150, 1, 0.0005 )
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
		self:EmitSound( Sound("weapons/1sniper/sniper_fire.wav") )
		self:TakePrimaryAmmo( 1 )
		self.Owner:ViewPunch( Angle( -8,math.random(-1,1),0 ) )
	else
	
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
		self:ShootBullet( 150, 1, 0.03 )
		self:EmitSound( Sound("weapons/1sniper/sniper_fire.wav") )
		self:TakePrimaryAmmo( 1 )
		self.Owner:ViewPunch( Angle( -8,math.random(-1,1),0 ) )
		end
	end
end

function SWEP:SecondaryAttack()

	if(self.Zoom == 0) then
		self.Owner:SetFOV( 25, .5 )
		self.Owner:DrawViewModel(false)
		self.Owner:ConCommand("pp_mat_overlay effects/scope02.vmt");
		self:EmitSound("Weapon_AR2.Special1")
			self.Zoom = 1
	else
		if(self.Zoom == 1) then
		self.Owner:SetFOV( 10, .5 )
		self.Owner:DrawViewModel(false)
		self.Owner:ConCommand("pp_mat_overlay effects/scope02.vmt");
		self:EmitSound("Weapon_AR2.Special1")
			self.Zoom = 2
	else
		self.Owner:SetFOV( 0, .5 )
		self.Owner:DrawViewModel(true)
		self.Owner:ConCommand("pp_mat_overlay \"\"");
		self:EmitSound("Weapon_AR2.Special2")
			self.Zoom = 0
	     end
       
       end

end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end