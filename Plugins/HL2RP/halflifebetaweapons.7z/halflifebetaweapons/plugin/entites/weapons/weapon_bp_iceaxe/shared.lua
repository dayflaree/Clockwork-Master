if SERVER then

	AddCSLuaFile( "shared.lua" )
	
end

if CLIENT then

SWEP.Category = "HL2 Beta Sweps"
SWEP.HoldType			= "melee"
language.Add("weapon_iceaxe", "Ice Axe")

SWEP.PrintName = "Ice Axe"
SWEP.Slot = 0
SWEP.SlotPos = 4
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_iceaxe") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end
 
function SWEP:Think() 
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then		
		self:Idle()
		end
	if ( self.Owner:KeyReleased( IN_ATTACK2 ) || ( !self.Owner:KeyDown( IN_ATTACK2 ) && self.Sound ) ) then		
		self:Idle()
		end
end

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)

util.PrecacheSound("")
end

function SWEP:PrimaryAttack()
self.Weapon:SetNextPrimaryFire(CurTime() + 0.3)
self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())

local trace = self.Owner:GetEyeTrace()

if trace.HitPos:Distance(self.Owner:GetShootPos()) <= 85 then
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
		self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0, 0, 0)
	bullet.Tracer = 0
	bullet.Force  = 1
	bullet.Damage = 12
self.Owner:FireBullets(bullet) 
self.Weapon:EmitSound("physics/flesh/flesh_impact_bullet" .. math.random( 1,2,3,4,5 ) .. ".wav")
else
                self.Weapon:EmitSound("weapons/1iceaxe/iceaxe_swing" .. math.random( 1,2 ) .. ".wav")
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
                self.Weapon:SendWeaponAnim(ACT_VM_MISSCENTER)
end

end
 
function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
	return true
end

function SWEP:Holster()
return true;
end

function SWEP:SecondaryAttack()
self.Weapon:SetNextSecondaryFire(CurTime() + 0.6)
self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())

local trace = self.Owner:GetEyeTrace()

if trace.HitPos:Distance(self.Owner:GetShootPos()) <= 85 then
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
                self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0, 0, 0)
	bullet.Tracer = 0
	bullet.Force  = 1
	bullet.Damage = 30
self.Owner:FireBullets(bullet) 
self.Weapon:EmitSound("physics/flesh/flesh_impact_bullet" .. math.random( 1,2,3,4,5 ) .. ".wav")
else
self.Weapon:EmitSound("weapons/1iceaxe/iceaxe_swing" .. math.random( 1,2 ) .. ".wav") 	
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
		self.Weapon:SendWeaponAnim(ACT_VM_MISSCENTER)
end

end
 
 function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end


-------------------------------------------------------------------
SWEP.Spawnable      = true
SWEP.AdminSpawnable  = false
-----------------------------------------------
SWEP.ViewModel      = "models/weapons/v_iceax3.mdl"
SWEP.WorldModel   = "models/weapons/w_iceaxe.mdl"
SWEP.HoldType			= "melee"
-----------------------------------------------
SWEP.Primary.Delay		= 0.4
SWEP.Primary.Recoil		= 0
SWEP.Primary.Damage		= 10
SWEP.Primary.NumShots		= 1		
SWEP.Primary.Cone		= 0
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic   	= true
SWEP.Primary.Ammo         	= "none" 
-------------------------------------------------
SWEP.Secondary.Delay			= 0.8
SWEP.Secondary.Recoil			= 0
SWEP.Secondary.Damage			= 20
SWEP.Secondary.NumShots			= 1
SWEP.Secondary.Cone			= 0
SWEP.Secondary.ClipSize			= -1
SWEP.Secondary.DefaultClip		= -1
SWEP.Secondary.Automatic   		= true
SWEP.Secondary.Ammo         		= "none"
-------------------------------------------------