if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )
	
	SWEP.HoldType			= "rpg"
	
end

if ( CLIENT ) then

	SWEP.PrintName			= "Missile Launcher"			
	SWEP.Category 			= "HL2 Beta Sweps"
	SWEP.Slot				= 4
	SWEP.SlotPos			= 7
	SWEP.ViewModelFOV		= 55
	SWEP.DrawWeaponInfoBox	= false
	SWEP.BounceWeaponIcon	= false 
	SWEP.WepSelectIcon		= surface.GetTextureID("HUD/swepicons/weapon_launcher") 

end
 
SWEP.SecondaryToggled = false
SWEP.Target = NULL
SWEP.TrackingTarget = true
SWEP.FireCooldown = 0

function SWEP:Initialize()
	if SERVER then
		self:SetWeaponHoldType(self.HoldType)
		return true
	end
	self.Owner:SetNWBool("JavSights", false)
	self.SecondaryToggled = false
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
		self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
		self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
		self:NextThink( CurTime() + self:SequenceDuration() )
		self:Idle()
   return true
end

function SWEP:DrawHUD()
	local targets = {}
	local sw = surface.ScreenWidth()
	local sh = surface.ScreenHeight()
	local tBoxX = sw / 3
	local tBoxY = sh / 2.5
	local tBoxW = sw / 3
	local tBoxH = sh / 5
	if self.Owner:GetNWBool("JavSights") then
		local FindUm = ents.GetAll()
		for k, v in pairs(FindUm) do
			if v:IsPlayer() or v:IsNPC() then
				if !(v == LocalPlayer()) then
					local targetTable = {}
					local tarpos = v:GetPos() + Vector(0,0,v:OBBMaxs().z * .5)
					local pos = tarpos:ToScreen()
					local dist = v:GetPos():Distance(LocalPlayer():GetShootPos())
					dist = math.Clamp(dist, 100, 50)
					surface.SetDrawColor(0,200,0,255)
					surface.DrawOutlinedRect( pos.x - dist / 2, pos.y - dist / 2, dist, dist)
					local res = math.Round(math.Dist(pos.x, pos.y, sw/2, sh/2))
					surface.SetTextColor(0,200,200,255)
					surface.SetFont("TargetIDSmall")
					local FontSize = surface.GetTextSize(tostring(res))
					surface.SetTextPos(pos.x - FontSize / 2, pos.y + dist / 2 + 5)
					surface.DrawText(tostring(res))
					if pos.x > tBoxX and pos.x < (tBoxX + tBoxW) then
						if pos.y < (tBoxY + tBoxH) and pos.y > tBoxY then
							surface.SetDrawColor(200,200,0,255)
							surface.DrawOutlinedRect( pos.x - dist / 2 - 1, pos.y - dist / 2 - 1, dist + 2, dist + 2)
							table.insert(targets, v)
							if #targets > 1 then
								for j, n in pairs(targets) do
									for l, o in pairs(targets) do
										local tarposn = n:GetPos() + Vector(0,0,n:OBBMaxs().z * .5)
										local posn = tarposn:ToScreen()
										local tarposo = o:GetPos() + Vector(0,0,o:OBBMaxs().z * .5)
										local poso = tarposo:ToScreen()
										local res1 = math.Dist(posn.x, posn.y, sw/2, sh/2)
										local res2 = math.Dist(poso.x, poso.y, sw/2, sh/2)
										if res1 < res2 then
											RunConsoleCommand("UpdateJavTarget", tostring(n:EntIndex()))
										end
									end
								end
							else
								RunConsoleCommand("UpdateJavTarget", tostring(targets[1]:EntIndex()))
							end
						end
					else
						if table.HasValue(targets, v) then
							table.remove(targets, v)
						end
					end
				end
			end
		end
		surface.SetDrawColor(255,255,255,255)
		surface.DrawOutlinedRect(tBoxX, tBoxY, tBoxW, tBoxH)
		surface.SetDrawColor(0,0,0,255)
		surface.DrawRect(0,0,sw,sh / 6)
		surface.DrawRect(0,sh - sh / 6,sw,sh / 6)
		surface.DrawRect(sw - sw / 6,0,sw / 6,sh)
		surface.DrawRect(0,0,sw / 6,sh)
	end
end

local function UpdateTarget( pl, cmd, args )
	local swep = pl:GetActiveWeapon();
	
	if( !swep || !swep:IsValid() )then return; end
	
	swep.TargetC = Entity( tonumber( args[1] ) );
end
concommand.Add( "UpdateJavTarget", UpdateTarget )
function SWEP:Holster()
	self.LockCount = 0
	self.TrackingTarget = false
	self.Target = NULL
	if #self.testTable > 0 then
		for i = #self.testTable, 1, -1  do
			table.remove(self.testTable, i)
		end
	end
	self.Owner:SetFOV(0,.3)
	self.SecondaryToggled = false
	self.Owner:SetNWBool("JavSights", false)
	if SERVER then
		self.Owner:DrawViewModel(true)
	end
	return true
end

function SWEP:Reload()
if ( self:Clip1() < self.Primary.ClipSize && self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	self.LockCount = 0
	self.TrackingTarget = false
	self.Target = NULL
	if #self.testTable > 0 then
		for i = #self.testTable, 1, -1  do
			table.remove(self.testTable, i)
		end
	end
	self.Owner:SetFOV(0,.3)
	self.SecondaryToggled = false
	self.Owner:SetNWBool("JavSights", false)
	self.Weapon:DefaultReload(ACT_VM_RELOAD)
	if SERVER then
		self.Owner:DrawViewModel(true)
		self:Idle()
		end
	end
end

SWEP.testTable = {}
SWEP.LockCount = 0
SWEP.TargetC = NULL

function SWEP:Think()
	if !(CurTime() > self.FireCooldown) then return end
	if self.Owner:KeyDown(IN_ATTACK) and self.SecondaryToggled then
		local trace = self.Owner:GetEyeTrace()

		if self.TargetC and self.TargetC:IsValid() then
			if self.TargetC:IsNPC() or self.TargetC:IsPlayer() then
				local initTrackTime = CurTime()
				if ((CurTime() + initTrackTime) % 1.5) == 0 then 
					self.Weapon:EmitSound(Sound("1launcher/check.wav"))
					table.insert(self.testTable, self.TargetC) 
					self.LockCount = self.LockCount + 1
					self.Owner:ChatPrint("Lock "..self.LockCount)
				end
				if self.LockCount >= 3 then 
					self.Target = self.TargetC
					for k, v in pairs(self.testTable) do 
						for j, n in pairs(self.testTable) do 
							if v == n then
								self.Weapon:EmitSound(Sound("1launcher/locked.wav"))
								self.FireCooldown = CurTime() + 3
								for i = #self.testTable, 1, -1  do
									table.remove(self.testTable, i)
								end
								self.LockCount = 0
								self.Owner:SetFOV(0,.25)
								self.SecondaryToggled = false
								self.Owner:SetNWBool("JavSights", false)
								self.Owner:DrawViewModel(true)
								if SERVER then
								if !(self.Weapon:Clip1() <= 0) then
									self.Weapon:SetNextPrimaryFire(CurTime() + 1)
									self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
									self.Owner:SetAnimation(PLAYER_ATTACK1)
									self:TakePrimaryAmmo(1)
									self.Weapon:DefaultReload(ACT_VM_RELOAD)
									self.Weapon:EmitSound("weapons/grenade_launcher1.wav")
	
									local pos, dir = self.Weapon:GetAttachment(1).Pos, self.Weapon:GetAttachment(1).Ang
									local effect = EffectData()
										effect:SetOrigin(pos)
										effect:SetAngles(dir)
										effect:SetEntity(self.Weapon)
										effect:SetAttachment(1)
									util.Effect("MuzzleEffect", effect) 
										
									self.Owner:ViewPunch(Angle(-10,0,0))
									
									local rocket = ents.Create("sent_bp_jrocket")
										rocket:SetPos(self.Owner:GetShootPos() + self.Owner:GetUp() * 15)
										rocket:SetAngles(Angle(-85,self.Owner:EyeAngles().y,self.Owner:EyeAngles().r))
										rocket:SetOwner(self.Owner)
										rocket:Spawn()
										rocket.Target = self.Target
									local phys = rocket:GetPhysicsObject()
									phys:ApplyForceCenter(self.Owner:GetAimVector() * 850)
								end
								end
							end 
						end 
					end 
				end
			end
		end
	else
		self.LockCount = 0
		self.TrackingTarget = false
		self.Target = NULL
		if #self.testTable > 0 then
			for i = #self.testTable, 1, -1  do
				table.remove(self.testTable, i)
			end
		end
	end
end

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
	self.Weapon:SetNextSecondaryFire(CurTime() + 1)
	if SERVER then
		if self.Owner:GetFOV() == 45 then
			self.Owner:SetFOV(0,.3)
			self.SecondaryToggled = false
			self.Owner:SetNWBool("JavSights", false)
			self.Owner:DrawViewModel(true)
			self:EmitSound("Weapon_AR2.Special2")
		else
			self.Owner:SetFOV(45,.3)
			self.SecondaryToggled = true
			self.Owner:SetNWBool("JavSights", true)
			self.Owner:DrawViewModel(false)
			self:EmitSound("Weapon_AR2.Special1")
		end
	end
end


function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end

SWEP.Spawnable      = true
SWEP.AdminSpawnable  = true

SWEP.ViewModel      = "models/weapons/v_mll.mdl"
SWEP.WorldModel   = "models/weapons/w_rocket_launcher.mdl"

SWEP.Primary.Delay			= 0.9
SWEP.Primary.Recoil			= 0
SWEP.Primary.Damage			= 15
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0
SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 1
SWEP.Primary.Automatic   	= true
SWEP.Primary.Ammo         	= "rpg_round"

SWEP.Secondary.Delay		= 0.9
SWEP.Secondary.Recoil		= 0
SWEP.Secondary.Damage		= 0
SWEP.Secondary.NumShots		= 1
SWEP.Secondary.Cone			= 0
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic   	= true
SWEP.Secondary.Ammo         = "none"