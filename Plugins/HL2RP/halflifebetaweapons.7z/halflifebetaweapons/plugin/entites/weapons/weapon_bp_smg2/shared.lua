
if SERVER then
AddCSLuaFile( "shared.lua" )
SWEP.HoldType		= "smg"
end

if CLIENT then
language.Add("weapon_bp_smg2", "SMG2")

SWEP.PrintName = "SMG2"
SWEP.Slot = 2
SWEP.SlotPos = 2
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/mp5k") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end
SWEP.Category 		= "HL2 Beta Sweps"
	
SWEP.ViewModel		= "models/weapons/smg2/v_5mg2.mdl"
SWEP.WorldModel		= "models/weapons/smg2/w_smg2.mdl"


SWEP.HoldType		= "smg"
SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

game.AddAmmoType( { name = "bp_medium" } )
if ( CLIENT ) then language.Add( "bp_medium_ammo", "Medium Rounds" ) end

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 100
SWEP.Primary.Automatic		= true
SWEP.Primary.Delay		= 0.2
SWEP.Primary.Ammo		= "SMG1"
SWEP.Primary.Recoil            = 1

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"

SWEP.FireMode = 0

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
	return true
end

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end
	

function SWEP:Holster()

	return true
end

function SWEP:Reload()
	if self:DefaultReload( ACT_VM_RELOAD ) then 
		self:EmitSound(Sound("weapons/smg1/smg1_reload.wav")) 
		self:Idle()
	end
end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then		
		self:Idle()
		end
end

function SWEP:PrimaryAttack()

	if ( !self:CanPrimaryAttack() ) then return end
	if ( self:Clip1() < 3 && self:Ammo1() > 0 && self.FireMode == 1 ) then
		self:Reload()
		return
	end

	if (self.FireMode == 0 || self:Clip1() < 3 ) then
		self:ShootBullet( 15, 1, 0.055 )
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.1 )
		self:EmitSound( Sound("weapons/1smg2/npc_smg2_fire1.wav") )
		self.Owner:ViewPunch( Angle( math.Rand(-0.3,-0.3) * self.Primary.Recoil, math.Rand(-0.3,0.3) *self.Primary.Recoil, math.Rand(-0.1,0.1) ) )
		self:TakePrimaryAmmo( 1 )
      else
		self:ShootBullet( 12, 1, 0.015 )
		timer.Create("FireBurstShot1" .. tostring(self.Owner),0.08,1, function() BurstFire(self,12,1,0.015) end)
		timer.Create("FireBurstShot2" .. tostring(self.Owner),0.16,1, function() BurstFire(self,12,1,0.015) end)
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
		self:EmitSound( Sound("weapons/1smg2/44k/smg2_fireburst1.wav") )
		self.Owner:ViewPunch( Angle( math.Rand(-0.3,-0.3) * self.Primary.Recoil, math.Rand(-0.3,0.3) *self.Primary.Recoil, math.Rand(-0.1,0.1) ) )
		self:TakePrimaryAmmo( 1 )
       end
	
end

function BurstFire( self, damage, number, accuracy)
	if ( !self:CanPrimaryAttack() ) then return end
	self:ShootBullet( damage, number, accuracy )
	self:TakePrimaryAmmo( 1 )
end

function SWEP:SecondaryAttack()	

	if(self.FireMode == 0) then
		self:EmitSound("weapons/1smg2/switch_burst.wav")
		self.FireMode = 1
	else
		self:EmitSound("weapons/1smg2/switch_single.wav")
		self.FireMode = 0
	end
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end