ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "Piercing RPG"
ENT.Author		= "Pac_187"
ENT.Contact		= ""
