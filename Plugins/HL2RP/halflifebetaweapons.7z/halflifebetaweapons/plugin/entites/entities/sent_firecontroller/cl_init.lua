

function ENT:Initialize()	

end


function ENT:Draw()
	return false
end


include('shared.lua')