
ENT.Type = "anim"