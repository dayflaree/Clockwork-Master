local PLUGIN = PLUGIN;

Clockwork.flag:Add("d", "HL2 Beta Weapons and Ammo", "Gives access to both the HL2 Beta weapons and Ammo.");
