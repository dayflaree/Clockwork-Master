--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "XM29 OICW";
	ITEM.cost = 1400;
	ITEM.model = "models/weapons/w_oicw.mdl";
	ITEM.weight = 5;
	ITEM.access = "d";
	ITEM.business = true;
	ITEM.uniqueID = "weapon_bp_oicw";
	ITEM.category = "Half Life 2 Beta Weapons";
	ITEM.description = "An assault rifle with a large scope, it's rather rusted and worn looking.";
	ITEM.hasFlashlight = true;
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-4, 5, -3);
ITEM:Register();