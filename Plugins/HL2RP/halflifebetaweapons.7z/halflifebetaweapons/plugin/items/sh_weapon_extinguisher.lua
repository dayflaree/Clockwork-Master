--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Fire Extinguisher";
	ITEM.cost = 800;
	ITEM.model = "models/weapons/w_fire_extinguisher.mdl";
	ITEM.weight = 5;
	ITEM.access = "d";
	ITEM.business = true;
	ITEM.uniqueID = "weapon_extinguisher";
	ITEM.category = "Half Life 2 Beta Weapons";
	ITEM.description = "A fire extinguisher, a giant red water/foam filled thing that extinguishes fire.";
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
ITEM:Register();