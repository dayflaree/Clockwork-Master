--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "I-Rifle";
	ITEM.cost = 800;
	ITEM.model = "models/weapons/w_Irifle.mdl";
	ITEM.weight = 5;
	ITEM.access = "d";
	ITEM.business = true;
	ITEM.uniqueID = "weapon_bp_irifle";
	ITEM.category = "Half Life 2 Beta Weapons";
	ITEM.description = "A combine manufactured flare gun, shoots flares and illuminates dark areas.";
	ITEM.hasFlashlight = true;
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-4, 5, -3);
ITEM:Register();