--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Rocket Launcher";
	ITEM.cost = 5000;
	ITEM.model = "models/Weapons/w_rocket_launcher.mdl";
	ITEM.weight = 5;
	ITEM.access = "d";
	ITEM.business = true;
	ITEM.uniqueID = "weapon_bp_rlauncher";
	ITEM.category = "Half Life 2 Beta Weapons";
	ITEM.description = "A large green rocket launcher, shoots RPG's which explode on contact with almost anything.";
	ITEM.hasFlashlight = true;
	ITEM.isAttachment = false;
ITEM:Register();