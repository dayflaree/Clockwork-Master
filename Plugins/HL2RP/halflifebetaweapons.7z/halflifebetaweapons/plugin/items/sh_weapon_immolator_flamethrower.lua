--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Flame-thrower";
	ITEM.cost = 2400;
	ITEM.model = "Models/weapons/w_immolator.mdl";
	ITEM.weight = 5;
	ITEM.access = "d";
	ITEM.business = true;
	ITEM.uniqueID = "weapon_bp_flamethrower";
	ITEM.category = "Half Life 2 Beta Weapons";
	ITEM.description = "A giant weapon of sorts with flame coming from the tip, looks like a flame-thrower. It werfs flammen.";
	ITEM.hasFlashlight = true;
	ITEM.isAttachment = false;
ITEM:Register();