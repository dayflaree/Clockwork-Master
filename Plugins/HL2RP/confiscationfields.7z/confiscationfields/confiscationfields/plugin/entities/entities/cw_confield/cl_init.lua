include('shared.lua') -- At this point the contents of shared.lua are ran on the client only.

