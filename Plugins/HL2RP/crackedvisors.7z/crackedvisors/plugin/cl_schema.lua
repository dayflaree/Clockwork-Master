local PLUGIN = PLUGIN;

Schema.combineOverlay = Material("effects/combine_binocoverlay");