local PLUGIN = PLUGIN;

Clockwork.kernel:AddDirectory("materials/crackedvisor/");