ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.PrintName = "Force Field";
ENT.Author = "Chessnut";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.PhysgunDisabled = true;