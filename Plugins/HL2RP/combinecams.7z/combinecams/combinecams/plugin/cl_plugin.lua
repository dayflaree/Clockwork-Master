local cwCombCams = cwCombCams;

cwCombCams.cameraOverlay = Material("effects/tvscreen_noise002a");