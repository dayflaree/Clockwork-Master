local PLUGIN = PLUGIN;

Clockwork.flag:Add("2", "MP Clothing", "Gives access to the Customizable MPF Uniform items.");
Clockwork.animation:AddCivilProtectionModel("models/metropolice/c08.mdl");
