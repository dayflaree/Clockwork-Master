--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Union for Betterment and Cooperation");

FACTION.noIDCard = true;
FACTION.canGetRations = true;
FACTION.canUseRationToken = true;

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "halfliferp/factions/cwu";
FACTION.models = {
        female = {
                "models/tnb/citizens/female_01.mdl",
				"models/tnb/citizens/female_02.mdl",
				"models/tnb/citizens/female_03.mdl",
				"models/tnb/citizens/female_04.mdl",
				"models/tnb/citizens/female_05.mdl",
				"models/tnb/citizens/female_06.mdl",
				"models/tnb/citizens/female_07.mdl",
				"models/tnb/citizens/female_08.mdl",
				"models/tnb/citizens/female_09.mdl",
				"models/tnb/citizens/female_10.mdl",
				"models/tnb/citizens/female_11.mdl"
        },
 
        male = {
                "models/tnb/citizens/male_01.mdl",
				"models/tnb/citizens/male_02.mdl",
				"models/tnb/citizens/male_03.mdl",
				"models/tnb/citizens/male_04.mdl",
				"models/tnb/citizens/male_05.mdl",
				"models/tnb/citizens/male_06.mdl",
				"models/tnb/citizens/male_07.mdl",
				"models/tnb/citizens/male_08.mdl",
				"models/tnb/citizens/male_09.mdl",
				"models/tnb/citizens/male_10.mdl",
				"models/tnb/citizens/male_12.mdl",
				"models/tnb/citizens/male_13.mdl",
				"models/tnb/citizens/male_14.mdl",
				"models/tnb/citizens/male_15.mdl",
				"models/tnb/citizens/male_16.mdl",
				"models/tnb/citizens/male_17.mdl",
				"models/tnb/citizens/male_18.mdl"
				
        }
}

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (faction.name != FACTION_CITIZEN) then
		return false;
	end;
end;

FACTION_UBC = FACTION:Register();