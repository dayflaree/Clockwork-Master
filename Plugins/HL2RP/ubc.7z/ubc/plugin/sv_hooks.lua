-- Called when CWU character is made.
function PLUGIN:GetPlayerDefaultInventory(player, character, inventory)
	if (character.faction == FACTION_UBC) then
 		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("union_card")
		);
 		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("tshirt_loyalist")
		);
	end
 end;
