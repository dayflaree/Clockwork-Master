local CLASS = Clockwork.class:New("Union for Betterment and Cooperation");

CLASS.color = Color(238, 180, 34, 255);
CLASS.factions = {FACTION_UBC};
CLASS.isDefault = true;
CLASS.wagesName = "Wages";
CLASS.description = "A citizen that's part of the UBC.";
CLASS.defaultPhysDesc = "A citizen with a white jumpsuit, and a UBC armband.";
	
CLASS_UBC = CLASS:Register();