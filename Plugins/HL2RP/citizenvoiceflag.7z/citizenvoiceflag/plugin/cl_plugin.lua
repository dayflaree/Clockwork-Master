local PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("Use citizen voice flag", "use_citizen_voice_flag", "Toggle the citizen voice flag.");
Clockwork.config:AddToSystem("Citizen voice flag", "citizen_voice_flag", "The flag that a citizen needs to use voice commands.");