local PLUGIN = PLUGIN;

Clockwork.kernel:AddDirectory("materials/overwatchvisor/");