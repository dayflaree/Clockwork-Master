
-----------------------------------------------------
--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("id_weapon_base");
        ITEM.name = "Bio-Locked Ice SMG";
        ITEM.cost = 850;
        ITEM.model = "models/weapons/w_75watt.mdl";
        ITEM.weight = 7;
		ITEM.access = "d";
        ITEM.business = false;
        ITEM.weaponClass = "sfw_blizzard";
		ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
		ITEM.uniqueID = "weapon_blizzard";
        ITEM.description = "A strange kind of icly glowing rifle.";
        ITEM.isAttachment = true;
        ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();