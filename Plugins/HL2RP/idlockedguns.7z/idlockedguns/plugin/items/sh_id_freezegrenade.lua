
-----------------------------------------------------
--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-locked Freeze Grenade";
	ITEM.cost = 25;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.model = "models/items/grenadeammo.mdl";
	ITEM.weight = 0.8;
	ITEM.uniqueID = "freeze_id_grenade";
	ITEM.weaponClass = "sfw_cryon";
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.business = false;
	ITEM.description = "A dirty tube of dust, is this supposed to be a grenade? yet it is cold to the touch";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();