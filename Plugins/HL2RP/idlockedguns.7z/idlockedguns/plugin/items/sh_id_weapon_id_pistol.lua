
-----------------------------------------------------
--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "ID Locked USP Match";
	ITEM.cost = 900;
	ITEM.batch = 1;
	ITEM.model = "models/weapons/w_pistol.mdl";
	ITEM.weight = 1;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.uniqueID = "weapon_idpistol";
	ITEM.weaponClass = "weapon_pistol";
	ITEM.business = true;
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.description = "A small pistol coated in a dull grey.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();