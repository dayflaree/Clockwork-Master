
-----------------------------------------------------
--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-Locked P08 Luger";
	ITEM.cost = 175;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.model = "models/weapons/w_luger_p08.mdl";
	ITEM.weight = 1;
	ITEM.access = "f";
	ITEM.business = false;
	ITEM.weaponClass = "m9k_luger";
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.uniqueID = "m9k_lug";
	ITEM.description = "A WWII German handgun, still has the Officers name engraved on it, and holds eight shots.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 0, -8);
ITEM:Register();