
-----------------------------------------------------
--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-Locked Remington 1858";
	ITEM.cost = 500;
	ITEM.model = "models/weapons/w_remington_1858.mdl";
	ITEM.weight = 2;
	ITEM.access = "f";
	ITEM.classes = {CLASS_EOW};
	ITEM.weaponClass = "m9k_remington1858";
	ITEM.uniqueID = "m9k_1858";
	ITEM.business = false;
	ITEM.description = "A Eliphalet Remington & Sons made revolver, produced in 1862-1875, Used by the Navy and Army at the time. Has a wooden maple grip.";
	ITEM.isAttachment = true;
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();