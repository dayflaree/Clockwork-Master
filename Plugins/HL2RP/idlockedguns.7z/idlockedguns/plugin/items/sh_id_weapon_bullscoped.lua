
-----------------------------------------------------
--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-Locked Raging Bull Scoped";
	ITEM.cost = 500;
	ITEM.model = "models/weapons/w_raging_bull_scoped.mdl";
	ITEM.weight = 2;
	ITEM.access = "f";
	ITEM.classes = {CLASS_EOW};
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.weaponClass = "m9k_scoped_taurus";
	ITEM.uniqueID = "m9k_scope";
	ITEM.business = false;
	ITEM.description = "A chrome hunting magnum, with a scope, made in Brazil.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, -90);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();