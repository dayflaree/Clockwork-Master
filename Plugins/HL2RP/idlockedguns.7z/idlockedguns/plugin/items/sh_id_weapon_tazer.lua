
-----------------------------------------------------
--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-Locked Tazer";
	ITEM.cost = 400;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.model = "models/weapons/w_plasma.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "f";
	ITEM.business = false;
	ITEM.weaponClass = "emp_tool";
	ITEM.uniqueID = "emp_tools";
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.description = "A pistol like object, with a cartrige that has two metal prongs in it.";
	ITEM.isAttachment = false;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 180);
	ITEM.attachmentOffsetVector = Vector(0, 0, -8);
ITEM:Register();