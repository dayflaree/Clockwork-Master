
-----------------------------------------------------
--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("id_weapon_base");
	ITEM.name = "Bio-Locked Flamethrower";
	ITEM.cost = 50000;
	ITEM.model = "models/weapons/w_physics.mdl";
	ITEM.weight = 7;
	ITEM.access = "f";
	ITEM.classes = {CLASS_EOW};
	ITEM.weaponClass = "swep_flamethrower_d2k";
	ITEM.uniqueID = "Flamethrower";
	ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.business = false;
	ITEM.description = "A large flamethrower.";
	ITEM.isAttachment = false;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, -90);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();