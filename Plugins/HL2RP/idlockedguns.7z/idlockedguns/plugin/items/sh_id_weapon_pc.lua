
-----------------------------------------------------
--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("id_weapon_base");
        ITEM.name = "Bio-Locked pole camera";
        ITEM.cost = 850;
        ITEM.model = "models/weapons/custom/w_polecam.mdl";
        ITEM.weight = 7;
		ITEM.access = "d";
        ITEM.business = false;
        ITEM.weaponClass = "weapon_polearm";
		ITEM.uniqueID = "weapon_pole";
        ITEM.description = "A strange kind camera device.";
        ITEM.isAttachment = false;
        ITEM.hasFlashlight = true;
		ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();