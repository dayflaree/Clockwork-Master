
-----------------------------------------------------
--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("id_weapon_base");
        ITEM.name = "Bio-Locked 1887 Winchester Shotgun";
        ITEM.cost = 1000;
        ITEM.model = "models/weapons/w_winchester_1887.mdl";
        ITEM.weight = 4;
		ITEM.access = "d";
        ITEM.business = false;
		ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
        ITEM.weaponClass = "m9k_1887winchester";
		ITEM.uniqueID = "m9k_1887";
        ITEM.description = "An old Shotgun developed in 1887.";
        ITEM.isAttachment = true;
        ITEM.hasFlashlight = true;
		ITEM.loweredOrigin = Vector(3, 0, -4);
		ITEM.loweredAngles = Angle(0, 90, 0);
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-4, 4, 4);
ITEM:Register();