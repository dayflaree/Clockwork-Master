
-----------------------------------------------------
--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("id_weapon_base");
        ITEM.name = "Bio-Locked G36C";
        ITEM.cost = 875;
        ITEM.model = "models/weapons/w_hk_g36c.mdl";
        ITEM.weight = 6;
		ITEM.access = "d";
        ITEM.business = false;
        ITEM.weaponClass = "m9k_g36";
		ITEM.uniqueID = "m9k_g36c";
        ITEM.description = "An H&K made assault rifle, it has tactical iron sights, and a collapsible stock.";
        ITEM.isAttachment = true;
		ITEM.useSound = "npc/roller/mine/rmine_blip1.wav";
        ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();