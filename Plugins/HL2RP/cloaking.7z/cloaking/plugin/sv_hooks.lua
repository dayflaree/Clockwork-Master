local PLUGIN = PLUGIN;

function PLUGIN:PlayerThink(player, curTime, infoTable)
	if ((player.IsGoneInvis == true) and (tonumber(player:GetVelocity():Length()) >= 15)) then
		player:SetMaterial("Models/effects/vol_light001");
		player:SetRenderMode(RENDERMODE_NORMAL);
	elseif ((player.IsGoneInvis == true) and (player:GetMaterial() == "Models/effects/vol_light001")) then
		if (tonumber(player:GetVelocity():Length()) < 15) then
			player:SetRenderMode(RENDERMODE_NONE);
		end;
	end;
end;

-- Called just after a player spawns.
function Schema:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!lightSpawn) then
		player.IsGoneInvis = false;
		player:SetRenderMode(RENDERMODE_NORMAL);
	end;
end;