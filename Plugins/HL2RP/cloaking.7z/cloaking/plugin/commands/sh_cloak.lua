local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Cloak");
COMMAND.tip = "Activate your Cloaking Device. (You probably don't have one.)";
COMMAND.text = "<none>";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if Schema:PlayerIsCombine(player) or player:IsSuperAdmin() then
		--local CloakSound = CreateSound(player, Sound("ambient/energy/electric_loop.wav"));
		if Schema:IsPlayerCombineRank(player, {"PHANTOM", "EOU", "SeC", "UCI", "CmD", "39547"}) or player:IsSuperAdmin() then
			if (!player.IsGoneInvis or player.IsGoneInvis == false) then
				player.normalMaterial = player:GetMaterial();
				player:EmitSound("npc/sniper/reload1.wav");
				player:SetMaterial("Models/effects/vol_light001");
				--CloakSound:Play();
				player:SetNoTarget(true);
				player.IsGoneInvis = true;
				Clockwork.player:Notify(player, "<:: Stealth Mode Activated.");
			else
				player:SetColor( Color(255, 255, 255, 255) );
				player:SetRenderMode( RENDERMODE_NORMAL );
				player:SetKeyValue( "renderfx", 0 );
				player:SetNoTarget(false);
				player.IsGoneInvis = false;
				player:SetMaterial(player.normalMaterial);
				player:EmitSound("AlyxEMP.Discharge");
				--CloakSound:Stop();
				Clockwork.player:Notify(player, "<:: Stealth Mode Deactivated.");
			end;
		else
			Clockwork.player:Notify(player, "You don't have a Stealth Suit!");
		end;
	else
		Clockwork.player:Notify(player, "You don't have a Stealth Suit!");
	end;
end;

COMMAND:Register();