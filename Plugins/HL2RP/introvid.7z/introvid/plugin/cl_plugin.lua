--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:Initialize()

end

function PLUGIN:LocalPlayerCreated()
	local quizCompleted = Clockwork.datastream.stored["QuizCompleted"];

	Clockwork.datastream:Hook("QuizCompleted", function(data)
		quizCompleted(data);

		if (!Clockwork.quiz:GetCompleted()) then
			local introPanel = vgui.Create("HTML");

			introPanel:SetPos(0, 0);
			introPanel:SetSize(ScrW(), ScrH());
			introPanel:SetVisible(true);
			introPanel:OpenURL("http://gmod.novabox.org/trailera/");
			introPanel:MakePopup();

			timer.Simple(180, function()
				if (IsValid(introPanel)) then
					introPanel:Remove();
				end;
			end);
		end;
	end);
end;