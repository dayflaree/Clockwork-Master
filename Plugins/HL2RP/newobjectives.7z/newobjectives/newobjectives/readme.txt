Before using, remove the following files from your HL2RP schema:
-> /commands/sh_viewobjectives.lua
-> /derma/cl_objectives.lua

To chance who can edit objectives, edit line 12 in the following file:
/plugin/commands/sh_editobjectives.lua