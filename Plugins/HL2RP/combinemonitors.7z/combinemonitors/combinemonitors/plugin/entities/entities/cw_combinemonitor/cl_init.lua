include("shared.lua");
ENT.RenderGroup         = RENDERGROUP_BOTH
-- Called when the entity should draw.
local overlayMaterial = Material("effects/combine_binocoverlay")
 
local MaterialTable = {
    --Material("halfliferp/banners/banner1.png");
    --Material("halfliferp/banners/banner2.png");
    Material("precinctone/menulogo.png");
    --Material("dev/dev_tvmonitor1a");
}

function ENT:DrawTranslucent()
    self:DrawModel()
 
    local position = self:GetPos()
    local angles = self:GetAngles()
    angles:RotateAroundAxis(angles:Up(), 90)
    angles:RotateAroundAxis(angles:Forward(), 90)
 
    local f, r, u = self:GetForward(), self:GetRight(), self:GetUp()
 
    cam.Start3D2D(position + f*53.80 + r*-(-45.5) + u*95.75, angles, 0.5)
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( Material("dev/dev_tvmonitor1a") )
        surface.DrawTexturedRect( 0, 0, 180, 380 )
    cam.End3D2D()
 
       cam.Start3D2D(position + f*53.85 + r*-(-45.5) + u*95.75, angles, 1)
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( overlayMaterial )
        surface.DrawTexturedRect( 0, 0, 90, 190 )
    cam.End3D2D()
end;

--[[function ENT:Initialize()
	self.Counter = 1
	timer.Create( "MaterialChanger1"..math.random(1,999), 10, 0, function()
		if self.Counter > 2 then
			self.Counter = 1
		else
			self.Counter = self.Counter + 1
		end
	end )
end;]]