-- Called when an MPF character is made.
function PLUGIN:GetPlayerDefaultInventory(player, character, inventory)
	if (character.faction == FACTION_MPF) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("standard_mask")
		    );
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("standard_uniform")
		    );
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("standard_coat")
		    );
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("standard_kevlar")
		    );
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("standard_belt")
		    );
        
	end;
 end;