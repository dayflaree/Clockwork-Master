local PLUGIN = PLUGIN;

Clockwork.flag:Add("1", "Clothing", "Gives access to the HL2TS2 clothing items.");
