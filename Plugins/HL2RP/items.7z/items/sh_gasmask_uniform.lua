
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Gasmask Uniform";
ITEM.uniqueID = "gasmask_uniform";
ITEM.actualWeight = 5;
ITEM.invSpace = 5;
ITEM.protection = 0.15;
ITEM.maxArmor = 100;
ITEM.hasGasmask = true;
ITEM.replacement = "models/lambdamovement_coat.mdl";
ITEM.description = "A black resistance uniform, it has a white lambda on the sleeve and has a gas mask with it.";
ITEM.repairItem = "kevlar";
ITEM.business = true;
ITEM.access = "m";
ITEM.cost = 1000;

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	if (player:GetGender() == GENDER_FEMALE) then
		return "models/lambdamovement_female.mdl";
	else
		return "models/lambdamovement.mdl";
	end;
end;

ITEM:Register();