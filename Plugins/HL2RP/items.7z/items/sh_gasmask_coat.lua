
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Gasmask Uniform, Coat";
ITEM.uniqueID = "coat_gasmask";
ITEM.actualWeight = 5;
ITEM.invSpace = 5;
ITEM.protection = 0.15;
ITEM.maxArmor = 100;
ITEM.hasGasmask = true;
ITEM.replacement = "models/lambdamovement_coat.mdl";
ITEM.description = "A black resistance uniform with a coat, it has a white lambda on the sleeve and comes with a mandatory gasmask.";
ITEM.repairItem = "kevlar";
ITEM.business = true;
ITEM.access = "m";
ITEM.cost = 1000;

ITEM:Register();