local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Hazmat Uniform";
ITEM.uniqueID = "hazmat_uniform";
ITEM.actualWeight = 4.5;
ITEM.invSpace = 4;
ITEM.protection = 0.10;
ITEM.maxArmor = 70;
ITEM.hasRebreather = true;
ITEM.replacement = "models/lambdamovement_coat.mdl";
ITEM.description = "A lightweight uniform with a large helmet and a grey, camouflaged pattern. It has a rebreather attached to the helmet.";
ITEM.repairItem = "armor_scraps";
ITEM.repairAmount = 35;
ITEM.business = false;
ITEM.access = "m";
ITEM.cost = 2000;

ITEM:AddData("Rarity", 2);

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	if (player:GetGender() == GENDER_FEMALE) then
		return "models/humans/airex/airex_female.mdl";
	else
		return "models/humans/airex/airex_male.mdl";
	end;
end;

ITEM:Register();