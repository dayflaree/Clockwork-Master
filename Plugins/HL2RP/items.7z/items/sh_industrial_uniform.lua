local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Industrial Uniform";
ITEM.uniqueID = "industrial_uniform";
ITEM.value = 0.05;
ITEM.isRare = true;
ITEM.actualWeight = 8;
ITEM.invSpace = 4;
ITEM.protection = 0.05;
ITEM.maxArmor = 45;
ITEM.hasGasmask = true;
ITEM.replacement = "models/citizen_17.mdl";
ITEM.description = "A heavy aproned uniform with rubber gloves and a gasmask.";
ITEM.repairItem = "scrap_cloth";
ITEM.business = true;
ITEM.access = "m";
ITEM.cost = 600;

ITEM:Register();