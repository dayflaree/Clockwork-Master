
local ITEM = Clockwork.item:New("armor_clothes_base_customizable");
ITEM.name = "Customizable Rebreather";
ITEM.uniqueID = "customizable_rebreather";
ITEM.hasRebreather = true;
ITEM.repairItem = "kevlar";
ITEM.repairAmount = 100;

Clockwork.item:Register(ITEM);