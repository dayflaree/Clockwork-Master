
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Medic Uniform";
ITEM.uniqueID = "medic_uniform";
ITEM.isRare = true;
ITEM.value = 0.01;
ITEM.actualWeight = 4;
ITEM.invSpace = 5;
ITEM.protection = 0.20;
ITEM.maxArmor = 100;
ITEM.group = "group03m";
ITEM.description = "A resistance uniform with a yellow symbol on the sleeve.";
ITEM.repairItem = "armor_scraps";
ITEM.business = true;
ITEM.access = "m";
ITEM.cost = 1000;

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	if (string.lower( player:GetModel() ) == "models/humans/group01/jasona.mdl") then
		return "models/humans/group03m/male_02.mdl";
	end;
end;

ITEM:Register();