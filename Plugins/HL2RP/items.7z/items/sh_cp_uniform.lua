local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Civil Protection Uniform";
ITEM.uniqueID = "civil_protection_uniform";
ITEM.actualWeight = 6;
ITEM.invSpace = 5;
ITEM.protection = 0.25;
ITEM.maxArmor = 100;
ITEM.hasGasmask = true;
ITEM.replacement = "models/dpfilms/metropolice/hl2beta_police.mdl";
ITEM.description = "A regular Civil Protection uniform with hidden trackers.";
ITEM.repairItem = "kevlar";

ITEM:Register();