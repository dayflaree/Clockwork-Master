--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Doctor Uniform";
ITEM.actualWeight = 3;
ITEM.invSpace = 2;
ITEM.protection = 0.01;
ITEM.maxArmor = 0;
ITEM.description = "A civil uniform with a medical insignia on the torso.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return "models/betacz/group03m/"..self:GetModelName(player);
end;

ITEM:Register();