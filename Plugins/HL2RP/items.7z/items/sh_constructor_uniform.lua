local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Constructor Uniform";
ITEM.value = 1;
ITEM.type = "misc";
ITEM.uniqueID = "constructor_uniform";
ITEM.actualWeight = 3;
ITEM.invSpace = 2;
ITEM.protection = 0.01;
ITEM.maxArmor = 0;
ITEM.description = "A constructor uniform with gloves and a blue heavy jacket.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return "models/betacz/group02/"..self:GetModelName(player);
end;

ITEM:Register();