
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "District Uniform";
ITEM.uniqueID = "district_uniform";
ITEM.type = "misc";
ITEM.value = 1;
ITEM.actualWeight = 3;
ITEM.invSpace = 2;
ITEM.protection = 0.01;
ITEM.maxArmor = 0;
ITEM.description = "A beige uniform inscribed with several City 17 symbols.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return "models/humans/orange1/"..self:GetModelName(player);
end;

ITEM:Register();