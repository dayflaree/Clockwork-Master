
local ITEM = Clockwork.item:New("filter_base");
ITEM.name = "Charcoal Filter";
ITEM.uniqueID = "charcoal_filter";
ITEM.model = "models/teebeutel/metro/objects/gasmask_filter.mdl";
ITEM.isRare = true; -- Used by itemspawner
ITEM.value = 0.1; -- Used by itemspawner
ITEM.weight = 0.5;
ITEM.business = true;
ITEM.maxFilterQuality = 1800; -- Maximum filter quality (also initial filter quality). By default 1fQ = 1s of filter time
ITEM.useText = "Screw On";
ITEM.access = "V";
ITEM.description = "A filter you can screw onto a gasmask.";
ITEM.refillItem = "charcoal"; -- Unique ID of the item used to refill the filter

Clockwork.item:Register(ITEM);
