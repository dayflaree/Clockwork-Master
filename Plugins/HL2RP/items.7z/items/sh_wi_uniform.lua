
local ITEM = Clockwork.item:New("armor_clothes_base");
ITEM.name = "Willard Industries Shirt";
ITEM.uniqueID = "wi_uniform";
ITEM.actualWeight = 3;
ITEM.invSpace = 2;
ITEM.protection = 0.01;
ITEM.maxArmor = 0;
ITEM.description = "A shirt with the City 17 inscription of the company, Willard Industries.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return "models/humans/office1/"..self:GetModelName(player);
end;

ITEM:Register();