Description:
===
Allows the unit to dispatch to a individual person. Currently only a few commands. A directory page in "Clockwork" tells you more and the Dispatch Arg to use.

Use:
===
/poi "Name of person" "Dispatch Arg"

Images:
===
![Directory Image](https://raw.githubusercontent.com/trurascalz/clockworkpluginimages/master/hl2rp/personaldispatch1.jpg)
![Example Output](https://raw.githubusercontent.com/trurascalz/clockworkpluginimages/master/hl2rp/personaldispatch2.jpg)
