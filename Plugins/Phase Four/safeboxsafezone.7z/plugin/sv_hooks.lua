local PLUGIN = PLUGIN;
local PhaseFour = PhaseFour;

-- Called when a player takes damage.
function PLUGIN:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	local curTime = CurTime();

	if (attacker:IsPlayer() and player:GetSharedVar("nextDC") < curTime) then
		attacker.nextDisconnect = curTime + 60;
	end;
end;
