local PLUGIN = PLUGIN;

local SAFE_COLOR = Color(0, 255, 0, 255); -- Green
local UNSAFE_COLOR = Color(255, 0, 0, 255); -- Red

function PLUGIN:PostDrawOpaqueRenderables(drawingDepth, drawingSkybox)
	if (!drawingSkybox) then
		local curTime = CurTime();
		local nextDC = Clockwork.Client:GetSharedVar("nextDC");
		local safeboxSafeZoneRadius = Clockwork.kernel:GetSharedVar("safeboxSafeZoneRadius");

		for k, v in pairs(ents.FindByClass("cw_safebox")) do
			local position = v:GetPos();
			local up = v:GetUp() * 20;

			cam.Start3D2D(position, Angle(0, 0, 0), 1);
				if (nextDC < curTime) then
					surface.DrawCircle(0, 0, safeboxSafeZoneRadius, SAFE_COLOR);
				else
					surface.DrawCircle(0, 0, safeboxSafeZoneRadius, UNSAFE_COLOR);
				end;
			cam.End3D2D()

			cam.Start3D2D(position + up, Angle(0, 0, 0), 1);
				if (nextDC < curTime) then
					surface.DrawCircle(0, 0, safeboxSafeZoneRadius, SAFE_COLOR);
				else
					surface.DrawCircle(0, 0, safeboxSafeZoneRadius, UNSAFE_COLOR);
				end;
			cam.End3D2D()
		end;
	end;
end;
