local COMMAND = Clockwork.command:New("SafeboxBeaconAdd");

COMMAND.tip = "Adds a beacon to target safebox.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local entity = player:GetEyeTraceNoCursor().Entity;

	if (entity:GetClass() == "cw_safebox") then
		Clockwork.plugin:Call("AttachBeacon", entity);
		Clockwork.plugin:Call("SaveSafeboxBeacons");
		Clockwork.player:Notify(player, "You have added a safebox beacon.");
	else
		Clockwork.player:Notify(player, "This is not a safebox!");
	end;
end;

COMMAND:Register();
