local PLUGIN = PLUGIN;

function PLUGIN:AttachBeacon(safebox)
	constraint.Rope(safebox, safebox, 0, 0, Vector(0, 0, 0), Vector(0, 0, 5000), 0, 0, 0, 50, "cable/redlaser", true);
end;

-- A function to load the safebox beacons.
function PLUGIN:LoadSafeboxBeacons()
	local beacons = Clockwork.kernel:RestoreSchemaData("plugins/safeboxbeacons/" .. game.GetMap()); -- Variable defined outside delay so it can be caught in memory.

	timer.Simple(5, function() -- Beacon loading is delayed so safeboxes can spawn in before attempting to attach.
		for k, v in pairs(beacons) do
			local entities = ents.FindInSphere(v.position, 5);

			for k2, v2 in pairs(entities) do
				local entity = entities[k2];

				if (IsValid(entity) and entity:GetClass() == "cw_safebox") then
					PLUGIN:AttachBeacon(entity);
					break; -- Stop loop once we've found a safebox to attach to.
				end;
			end;
		end;

		PLUGIN:SaveSafeboxBeacons(); -- Re-save beacons after load since their save data was lost (because of delay).
	end);
end;

-- A function to save the safebox beacons.
function PLUGIN:SaveSafeboxBeacons()
	local beacons = {};

	-- TODO assign the constraint an ID of some sort (upon creation) then have it check if the constraint matches said ID before saving it to reduce errors.

	-- Checks if constraint is made on itself with a rope, if so, saves it as a beacon.
	for k, v in pairs(ents.FindByClass("cw_safebox")) do
		local constraintEnt = constraint.Find(v, v, "Rope", 0, 0);

		if (IsValid(constraintEnt) and constraintEnt:GetClass() == "keyframe_rope") then
			beacons[#beacons + 1] = {
				position = v:GetPos()
			};
		end;
	end;

	Clockwork.kernel:SaveSchemaData("plugins/safeboxbeacons/" .. game.GetMap(), beacons);

	--TODO PhaseFour:SaveSafeboxCall(); -- Avoids inconsistencies, i.e. save safeboxes before saving beacons
end;
