local PLUGIN = PLUGIN;

-- Called when a player should take damage.
function PLUGIN:PlayerShouldTakeDamage(player, attacker, inflictor, damageInfo)
	if (player:GetSharedVar("nextDC") < CurTime()) then
		for k, v in pairs(ents.FindByClass("cw_safebox")) do -- Not very efficient
			if (player:GetPos():Distance(v:GetPos()) <= Clockwork.kernel:GetSharedVar("safeboxSafeZoneRadius")) then -- Localize that shared var
				return false;
			end;
		end;
	end;
end;
