local COMMAND = Clockwork.command:New("SafeboxBeaconRemove");

COMMAND.tip = "Removes beacon from target safebox.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local entity = player:GetEyeTraceNoCursor().Entity;

	if (entity:GetClass() == "cw_safebox") then
		local beaconRemoved = constraint.RemoveConstraints(entity, "Rope");

		if (beaconRemoved == true) then
			Clockwork.plugin:Call("SaveSafeboxBeacons");
			Clockwork.player:Notify(player, "You have removed target safebox's beacon.");
		else
			Clockwork.player:Notify(player, "No beacon to remove from target safebox.");
		end;
	else
		Clockwork.player:Notify(player, "This is not a safebox!");
	end;
end;

COMMAND:Register();
