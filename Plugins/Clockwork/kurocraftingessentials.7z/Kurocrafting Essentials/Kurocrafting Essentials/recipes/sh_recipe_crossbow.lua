local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Metal", 4)
RECIPE:RequireItemByName("Plastic")
RECIPE:RequireItemByName("Battery")
RECIPE:RequireItemByName("Cloth")
RECIPE:RequireItemByName("Scrap Electronics")
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireToolByName("Lever")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Strength", 2)
RECIPE:RequireAttributeByName("Dexterity", 2)

RECIPE:RewardItemByName("weapon_crossbow")
RECIPE:ProgressAttributeByName("Strength", 1)
RECIPE:ProgressAttributeByName("Dexterity", 1.5)

RECIPE:Register()