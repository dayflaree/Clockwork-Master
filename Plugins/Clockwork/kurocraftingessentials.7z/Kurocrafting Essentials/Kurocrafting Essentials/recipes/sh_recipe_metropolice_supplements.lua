local RECIPE = PLUGIN.recipe:New("cooking")

RECIPE:RequireItemByName("Citizen Supplements")
RECIPE:RequireItemByName("Smooth Breen's Water")
RECIPE:RequireItemByName("Paracetamol")
RECIPE:RequireEntityNearby("cw_stove")

RECIPE:RewardItemByName("Metropolice Supplements")

RECIPE:Register()