local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Gunpowder")
RECIPE:RequireItemByName("Bullet casings")
RECIPE:RequireItemByName("Metal pellets")
RECIPE:RequireAttributeByName("Dexterity")

RECIPE:RewardItemByName("Shotgun Shells")
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()