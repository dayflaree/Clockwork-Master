local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Health Vial")
RECIPE:RequireItemByName("Metal")
RECIPE:RequireAttributeByName("Medical")

RECIPE:RewardItemByName("Health Kit")
RECIPE:ProgressAttributeByName("Medical", 1.5)

RECIPE:Register()