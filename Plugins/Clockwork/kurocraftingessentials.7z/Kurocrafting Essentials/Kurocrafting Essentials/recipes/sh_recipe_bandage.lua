local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Cloth", 2)
RECIPE:RequireAttributeByName("Medical")

RECIPE:RewardItemByName("Bandage")
RECIPE:ProgressAttributeByName("Medical", 1)

RECIPE:Register()