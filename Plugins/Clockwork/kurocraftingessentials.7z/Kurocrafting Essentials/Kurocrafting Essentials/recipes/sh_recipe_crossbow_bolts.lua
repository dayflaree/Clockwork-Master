local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Metal", 4)
RECIPE:RequireAttributeByName("Strength")

RECIPE:RewardItemByName("Crossbow Bolts")
RECIPE:ProgressAttributeByName("Strength", 0.5)

RECIPE:Register()