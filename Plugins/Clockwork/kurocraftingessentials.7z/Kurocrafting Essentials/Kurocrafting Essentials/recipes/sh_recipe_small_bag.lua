local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Cloth", 4)

RECIPE:RewardItemByName("Small Bag")

RECIPE:Register()