local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Metal", 5)
RECIPE:RequireItemByName("Plastic", 3)
RECIPE:RequireItemByName("Pins", 2)
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireToolByName("Lever")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Dexterity", 3)

RECIPE:RewardItemByName("weapon_smg1")
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()