local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("High Grade Metal")
RECIPE:RequireItemByName("Metal", 4)
RECIPE:RequireItemByName("Plastic")
RECIPE:RequireItemByName("Pins")
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireToolByName("Lever")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Strength")
RECIPE:RequireAttributeByName("Dexterity", 2)

RECIPE:RewardItemByName("weapon_357")
RECIPE:ProgressAttributeByName("Strength", 0.5)
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()