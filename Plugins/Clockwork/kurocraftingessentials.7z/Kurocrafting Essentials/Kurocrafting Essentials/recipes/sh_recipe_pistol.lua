local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Metal", 4)
RECIPE:RequireItemByName("Plastic", 2)
RECIPE:RequireItemByName("Pins")
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireToolByName("Lever")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Dexterity")

RECIPE:RewardItemByName("weapon_pistol")
RECIPE:ProgressAttributeByName("Dexterity", 0.5)

RECIPE:Register()