local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("High Grade Metal", 7)
RECIPE:RequireItemByName("Plastic", 3)
RECIPE:RequireItemByName("Pins", 3)
RECIPE:RequireItemByName("Scrap Electronics", 2)
RECIPE:RequireItemByName("Battery")
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireToolByName("Lever")
RECIPE:RequireToolByName("Wrench")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Strength", 5)
RECIPE:RequireAttributeByName("Dexterity", 4)

RECIPE:RewardItemByName("weapon_ar2")
RECIPE:ProgressAttributeByName("Strength", 3)
RECIPE:ProgressAttributeByName("Dexterity", 2)

RECIPE:Register()