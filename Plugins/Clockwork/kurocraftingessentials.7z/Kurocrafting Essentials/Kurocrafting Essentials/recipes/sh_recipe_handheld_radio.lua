local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Scrap Electronics")
RECIPE:RequireItemByName("Battery")
RECIPE:RequireItemByName("Plastic", 4)
RECIPE:RequireItemByName("Screws")
RECIPE:RequireToolByName("Pliers")
RECIPE:RequireEntityNearby("cw_craftingtable")
RECIPE:RequireAttributeByName("Dexterity", 2)

RECIPE:RewardItemByName("Handheld Radio")
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()