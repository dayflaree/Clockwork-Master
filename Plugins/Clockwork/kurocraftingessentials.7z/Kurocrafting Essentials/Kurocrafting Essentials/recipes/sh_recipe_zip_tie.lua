local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Cloth", 2)
RECIPE:RequireItemByName("Metal")
RECIPE:RequireAttributeByName("Strength")

RECIPE:RewardItemByName("Zip Tie")

RECIPE:Register()