local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Gunpowder")
RECIPE:RequireItemByName("Bullet Casings")

RECIPE:RewardItemByName("9mm Pistol Bullets")

RECIPE:Register()