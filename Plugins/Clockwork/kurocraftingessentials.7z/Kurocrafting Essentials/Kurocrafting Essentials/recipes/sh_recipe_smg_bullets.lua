local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Gunpowder", 2)
RECIPE:RequireItemByName("Bullet casings", 2)
RECIPE:RequireAttributeByName("Dexterity")

RECIPE:RewardItemByName("SMG Bullets")
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()