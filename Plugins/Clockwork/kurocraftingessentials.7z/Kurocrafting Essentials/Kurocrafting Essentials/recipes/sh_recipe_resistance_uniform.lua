local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Cloth", 10)
RECIPE:RequireItemByName("Kevlar")
RECIPE:RequireItemByName("Spray Can")
RECIPE:RequireEntityNearby("cw_craftingtable")

RECIPE:RewardItemByName("Resistance Uniform")

RECIPE:Register()