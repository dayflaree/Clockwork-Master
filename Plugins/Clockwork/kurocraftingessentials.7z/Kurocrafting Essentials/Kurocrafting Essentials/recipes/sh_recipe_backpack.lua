local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Cloth", 7)

RECIPE:RewardItemByName("Backpack")

RECIPE:Register()