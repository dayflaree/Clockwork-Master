local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Gunpowder")
RECIPE:RequireItemByName("Bullet Casings")
RECIPE:RequireAttributeByName("Dexterity")

RECIPE:RewardItemByName(".357 Magnum Bullets")
RECIPE:ProgressAttributeByName("Dexterity", 1)

RECIPE:Register()