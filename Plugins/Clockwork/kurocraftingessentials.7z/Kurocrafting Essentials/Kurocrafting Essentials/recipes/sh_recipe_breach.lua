local RECIPE = PLUGIN.recipe:New("crafting")

RECIPE:RequireItemByName("Gunpowder")
RECIPE:RequireItemByName("Metal", 2)
RECIPE:RequireItemByName("Scrap Electronics")

RECIPE:RewardItemByName("Breach")

RECIPE:Register()