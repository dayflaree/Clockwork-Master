-- Last updated 28/01/2014 23:56 (UTC+01:00) --

KUROCRAFTING ESSENTIALS

Thanks for downloading the kurocrafting essentials plugin. This is a pack consisting of not only items and entities I felt were essential to Kurochi's crafting framework, but also some crafting recipes for HL2RP.
It's worth noting that none of the recipes have received any balancing, and are based purely on what I felt would be realistic. Feel free to tweak recipes to make them fit better for you.

If you encounter any bugs, flaws or other issues, please drop by my plugin collection at http://forums.cloudsixteen.com/index.php?topic=4968.15 and leave a message.
Alternatively, you can send me a PM through my Cloud16 forums profile at http://forums.cloudsixteen.com/index.php?action=profile;u=2989 and I'll try to have the issue(s) resolved as fast as possible!

REQUIREMENTS

Kurochi's Kurocrafting plugin (Tested on v.2.1.2). If you don't have it yet, it can be purchased at store.crosswaygames.com/index.php/
If you wish to use the recipes, the schema you'll have to be running is HL2RP, as that's what the recipes were made for.

INSTALLATION

PLUGIN: Put the kurocraftingessentials folder in garrysmod/garrysmod/gamemodes/clockwork/plugins.
RECIPES: Put the recipes folder in garrysmod/garrysmod/gamemodes/*schema name*/plugins/kurocrafting/plugin and merge the folders, if asked to do so, overwrite all existing files.