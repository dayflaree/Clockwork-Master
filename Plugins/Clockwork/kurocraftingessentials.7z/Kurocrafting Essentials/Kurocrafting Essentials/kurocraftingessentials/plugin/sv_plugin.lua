function PLUGIN:ClockworkInitPostEntity()
	self:LoadCraftingTables()
	self:LoadStoves()
end

function PLUGIN:PostSaveData()
	self:SaveCraftingTables()
	self:SaveStoves()
end

function PLUGIN:LoadCraftingTables()
	local CraftingTables = Clockwork.kernel:RestoreSchemaData( "plugins/CraftingTables/"..game.GetMap() )
	
	for k, v in pairs(CraftingTables) do
		local entity = ents.Create("cw_craftingtable")
		entity:SetAngles(v.angles)
		entity:SetPos(v.position)
		entity:Spawn()
		entity:Activate()
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles)
		end
	end
end

function PLUGIN:SaveCraftingTables()
	local CraftingTables = {}
	
	for k, v in pairs(ents.FindByClass("cw_craftingtable")) do
		CraftingTables[#CraftingTables + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos() - Vector(0, 0, v:OBBMaxs().z/2),
			uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID")
		}
	end
	
	Clockwork.kernel:SaveSchemaData("plugins/CraftingTables/"..game.GetMap(), CraftingTables)
end

function PLUGIN:LoadStoves()
	local Stoves = Clockwork.kernel:RestoreSchemaData( "plugins/Stoves/"..game.GetMap() )
	
	for k, v in pairs(Stoves) do
		local entity = ents.Create("cw_stove")
		entity:SetAngles(v.angles)
		entity:SetPos(v.position)
		entity:Spawn()
		entity:Activate()
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles)
		end
	end
end

function PLUGIN:SaveStoves()
	local Stoves = {}
	
	for k, v in pairs(ents.FindByClass("cw_stove")) do
		Stoves[#Stoves + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos() - Vector(0, 0, v:OBBMaxs().z),
			uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID")
		}
	end
	
	Clockwork.kernel:SaveSchemaData("plugins/Stoves/"..game.GetMap(), Stoves)
end