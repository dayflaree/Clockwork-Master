local ITEM = Clockwork.item:New()
ITEM.name = "Kevlar"
ITEM.model = "models/Gibs/helicopter_brokenpiece_02.mdl"
ITEM.weight = 0.3
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A chunk of kevlar, could come in handy."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()