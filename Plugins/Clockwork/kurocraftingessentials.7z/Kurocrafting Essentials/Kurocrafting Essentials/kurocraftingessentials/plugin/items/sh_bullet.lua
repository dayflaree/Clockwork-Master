local ITEM = Clockwork.item:New()
ITEM.name = "Bullets"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.3
ITEM.category = "Gunsmithing"
ITEM.business = false
ITEM.description = "A box with bullets themselves."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()