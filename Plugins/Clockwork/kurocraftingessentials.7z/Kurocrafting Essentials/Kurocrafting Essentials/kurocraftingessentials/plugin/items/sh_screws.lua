local ITEM = Clockwork.item:New()
ITEM.name = "Screws"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.2
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A box with some screws, useful for putting things together."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()