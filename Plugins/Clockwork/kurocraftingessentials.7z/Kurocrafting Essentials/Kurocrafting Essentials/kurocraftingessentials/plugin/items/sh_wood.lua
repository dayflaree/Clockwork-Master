local ITEM = Clockwork.item:New()
ITEM.name = "Wood"
ITEM.model = "models/Gibs/wood_gib01c.mdl"
ITEM.weight = 0.2
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A piece of broken wood."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()