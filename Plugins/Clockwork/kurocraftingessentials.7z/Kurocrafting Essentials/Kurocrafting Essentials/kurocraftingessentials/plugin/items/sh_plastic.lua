local ITEM = Clockwork.item:New()
ITEM.name = "Plastic"
ITEM.model = "models/props_c17/canisterchunk01d.mdl"
ITEM.weight = 0.05
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A small piece of plastic."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()