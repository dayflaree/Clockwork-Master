local ITEM = Clockwork.item:New()
ITEM.name = "Metal Pellets"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.4
ITEM.category = "Gunsmithing"
ITEM.business = false
ITEM.description = "A box filled with metal pellets, similar to ones used in shotgun ammunition."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()