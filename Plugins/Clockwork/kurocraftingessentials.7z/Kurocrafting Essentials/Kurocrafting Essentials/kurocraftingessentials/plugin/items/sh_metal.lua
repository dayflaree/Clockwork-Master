local ITEM = Clockwork.item:New()
ITEM.name = "Metal"
ITEM.model = "models/gibs/metal_gib2.mdl"
ITEM.weight = 0.3
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A piece of durable metal."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()