local ITEM = Clockwork.item:New()
ITEM.name = "Battery"
ITEM.model = "models/items/battery.mdl"
ITEM.weight = 0.3
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A modern, high capacity battery produced by the Combine."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()