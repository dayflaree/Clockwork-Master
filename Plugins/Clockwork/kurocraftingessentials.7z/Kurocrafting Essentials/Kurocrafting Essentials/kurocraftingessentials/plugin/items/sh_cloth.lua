local ITEM = Clockwork.item:New()
ITEM.name = "Cloth"
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl"
ITEM.weight = 0.02
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A few pieces of torn clothing, doesn't seem very useful."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()