local ITEM = Clockwork.item:New()
ITEM.name = "High Grade Metal"
ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.weight = 0.4
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A piece of high grade metal, often used by the Combine."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()