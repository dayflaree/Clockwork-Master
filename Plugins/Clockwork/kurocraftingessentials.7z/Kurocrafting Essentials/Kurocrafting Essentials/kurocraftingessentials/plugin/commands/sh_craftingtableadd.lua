local COMMAND = Clockwork.command:New("CraftingTableAdd")
COMMAND.tip = "Add a crafting table at your target position."
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "s"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor()
	if (!trace.Hit) then return end

	local shouldDissolve = Clockwork.kernel:ToBool(arguments[1])

	local CraftingTable = ents.Create("cw_craftingtable")
	local entity = CraftingTable:SpawnFunction(player, trace, "cw_craftingtable")
	CraftingTable:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a crafting table.")
	end
end

COMMAND:Register()