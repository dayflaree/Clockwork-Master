local COMMAND = Clockwork.command:New("StoveAdd")
COMMAND.tip = "Add a stove at your target position."
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "s"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor()
	if (!trace.Hit) then return end

	local shouldDissolve = Clockwork.kernel:ToBool(arguments[1])

	local Stove = ents.Create("cw_stove")
	local entity = Stove:SpawnFunction(player, trace, "cw_stove")
	Stove:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a stove.")
	end
end

COMMAND:Register()