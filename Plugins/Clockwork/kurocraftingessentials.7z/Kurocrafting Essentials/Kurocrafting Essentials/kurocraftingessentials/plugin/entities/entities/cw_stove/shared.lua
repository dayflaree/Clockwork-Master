ENT.Type = "anim"
ENT.Author = "Atebite"
ENT.PrintName = "Stove"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.UsableInVehicle = true
ENT.PhysgunDisabled = true