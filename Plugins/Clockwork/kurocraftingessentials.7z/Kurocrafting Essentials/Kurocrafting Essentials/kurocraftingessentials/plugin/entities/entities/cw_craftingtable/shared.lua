ENT.Type = "anim"
ENT.Author = "Atebite"
ENT.PrintName = "Crafting table"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.UsableInVehicle = true
ENT.PhysgunDisabled = true