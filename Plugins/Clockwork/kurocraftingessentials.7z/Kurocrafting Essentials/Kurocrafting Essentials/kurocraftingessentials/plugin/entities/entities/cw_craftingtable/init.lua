AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_wasteland/controlroom_desk001b.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetPos(self:GetPos() + Vector(0, 0, self:OBBMaxs().z/2))

	self.magnifyingGlass = ents.Create("prop_dynamic")
	self.magnifyingGlass:SetModel("models/props_c17/light_magnifyinglamp02.mdl")
	self.magnifyingGlass:SetSolid(SOLID_VPHYSICS)
	self.magnifyingGlass:SetPos(self:GetPos()+self:GetUp()*16.5+self:GetForward()*6+self:GetRight()*-20)
	self.magnifyingGlass:SetAngles(self:GetAngles())
	self.magnifyingGlass:SetParent(self)
	self.magnifyingGlass:Spawn()
end