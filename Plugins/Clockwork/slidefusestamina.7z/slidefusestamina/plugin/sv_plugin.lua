--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (Slidefuse LLC - Slidefuse.net)
--]]

Clockwork.config:Add("stam_drain_scale", 0.2, true);
Clockwork.config:Add("breathing_volume", 1, true);