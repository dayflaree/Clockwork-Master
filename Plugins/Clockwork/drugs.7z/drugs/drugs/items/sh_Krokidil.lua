--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Krokidil";
ITEM.cost = 150;
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
ITEM.weight = 0.5;
ITEM.access = "V";
ITEM.useText = "Inject";
ITEM.factions = {};
ITEM.category = "Drugs
ITEM.business = true;
ITEM.useSound = "weapons/knife/knife_hit1.wav";
ITEM.description = "It makes you hallucinate, but it eats your flesh. Better be careful with it.";
ITEM.customFunctions = {"Give"};

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetSharedVar("antidepressants", CurTime() + 600);
	player:SetHealth( math.Clamp( player:Health() + Schema:GetHealAmount(player, -1), 0, player:GetMaxHealth() ) );
	
	Clockwork.plugin:Call("PlayerHealed", player, player, self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (name == "Give") then
			Clockwork.player:RunClockworkCommand(player, "CharHeal", "health_vial");
		end;
	end;
end;

ITEM:Register();