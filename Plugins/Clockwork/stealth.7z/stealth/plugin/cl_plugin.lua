local PLUGIN = PLUGIN;

PLUGIN.heatwaveMaterial = Material("sprites/heatwave");
PLUGIN.heatwaveMaterial:SetFloat("$refractamount", 0);
PLUGIN.shinyMaterial = Material("models/shiny");