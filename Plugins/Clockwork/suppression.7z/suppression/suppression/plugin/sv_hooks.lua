function cwSuppression:EntityFireBullets(entity, data)
	if Clockwork.config:Get( "suppression_enabled" ):Get() then
		if IsValid( entity ) then
			if entity:IsPlayer() and entity:GetNWBool( "suppressed" ) then
				data.Spread = Vector( 0.1, 0.1 )
			end

			local bullet_trace = util.QuickTrace( data.Src, data.Dir )
			if !bullet_trace.Hit then return true end
			local bullet_hull_trace = util.TraceHull( { start = data.Src, endpos = bullet_trace.HitPos, mins = Vector( 0, 0, 0 ), maxs = Vector( 0, Clockwork.config:Get( "suppression_hull_size" ):Get()*10, Clockwork.config:Get( "suppression_hull_size" ):Get()*10 ), filter = { entity } } )

			if bullet_hull_trace.Hit then
				local entity = bullet_hull_trace.Entity
				if IsValid( entity ) and entity:IsPlayer() then
					if !entity.suppression_amt then
						entity.suppression_amt = 1
						entity.next_suppress_decay = CurTime() + Clockwork.config:Get( "suppression_cooldown" ):Get()
					end
					entity.suppression_amt = entity.suppression_amt + 1
				end
			end

			return true
		end
	end
end

function cwSuppression:PlayerThink(player, CT)
	if Clockwork.config:Get( "suppression_enabled" ):Get() then
		if !player.suppression_amt then
			player.suppression_amt = 0
		end

		if !player.next_suppress_decay then
			player.next_suppress_decay = 0
		end

		if player.suppression_amt > Clockwork.config:Get( "suppression_limit" ):Get() then
			player:SetNWBool( "suppressed", true )
		else
			player:SetNWBool( "suppressed", false )
		end

		if CT > player.next_suppress_decay and player.suppression_amt > 0 then
			player.next_suppress_decay = CT + Clockwork.config:Get( "suppression_cooldown" ):Get()
			player.suppression_amt = player.suppression_amt - 1
		end
	end
end