local blur_f, suppressed = 0, false

function cwSuppression:Think()
	if GetConVarNumber( "mat_motion_blur_enabled" ) ~= 1 then
		RunConsoleCommand( "mat_motion_blur_enabled", 1 )
	end

	suppressed = LocalPlayer():GetNWBool( "suppressed" )

	if suppressed then
		blur_f = math.Approach( blur_f, 1, FrameTime() * 2)
	else
		blur_f = math.Approach( blur_f, 0, FrameTime() * 2)
	end
end

local function cwSuppression_GetMotionBlurValues(h, v, f, r)
	f = f > 0 and f or 0.1 * blur_f
	return h, v, f, r
end

hook.Add( "GetMotionBlurValues", "cwSuppression_GetMotionBlurValues", cwSuppression_GetMotionBlurValues )