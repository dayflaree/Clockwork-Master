PLUGIN:SetGlobalAlias( "cwSuppression" )

Clockwork.kernel:IncludePrefixed( "cl_hooks.lua" )
Clockwork.kernel:IncludePrefixed( "sv_hooks.lua" )

if SERVER then
	Clockwork.config:Add( "suppression_enabled", true )
	Clockwork.config:Add( "suppression_limit", 10 )
	Clockwork.config:Add( "suppression_cooldown", 1 )
	Clockwork.config:Add( "suppression_hull_size", 3 )
end

if CLIENT then
	Clockwork.config:AddToSystem( "Enable suppression system", "suppression_enabled", "Whether or not the suppression system should be enabled.", true )
	Clockwork.config:AddToSystem( "Suppression limit", "suppression_limit", "How many bullets have to pass close to a player before they get suppressed.", 5, 100 )
	Clockwork.config:AddToSystem( "Suppression cooldown", "suppression_cooldown", "How many seconds there are between suppression amount decays.", 0.5, 30 )
	Clockwork.config:AddToSystem( "Suppression hull size", "suppression_hull_size", "(Advanced) The size of the hull trace accompanied by travelling bullets.", 3, 30 )
end