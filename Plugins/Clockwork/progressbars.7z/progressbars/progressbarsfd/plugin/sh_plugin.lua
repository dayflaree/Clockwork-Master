local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

Clockwork.option:SetKey("PBActions", {
		 tie = "You are tying someone.",
		 untie = "You are untying someone.",
});