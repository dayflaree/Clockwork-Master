local PLUGIN = PLUGIN;

function PLUGIN:GetPostProgressBarInfo()
	if (Clockwork.Client:Alive()) then
		local action, percentage = Clockwork.player:GetAction(Clockwork.Client, true);
		local actions = Clockwork.option:GetKey("PBActions");
		
		if (table.HasValue(table.GetKeys(actions), action )) then
			return {text = actions[action], percentage = percentage, flash = percentage > 75};
		end;
	end;
end;