function PLUGIN:Initialize()
	Clockwork.plugin:Remove("ClockworkLogoPlugin");
end;
