local PLUGIN = PLUGIN;

function Clockwork:PlayerCharacterUnloaded(player)
	RunConsoleCommand("chasecam", "0");
end;