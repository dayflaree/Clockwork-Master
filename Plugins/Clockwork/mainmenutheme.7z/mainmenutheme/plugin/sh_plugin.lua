local PLUGIN = PLUGIN;

--Change as you like.
Clockwork.option:SetKey("menu_music", "music/hl2_song19.mp3");