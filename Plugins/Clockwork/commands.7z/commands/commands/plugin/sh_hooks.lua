local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:ClockworkInitialized()
	-- Command access fixes.
	Clockwork.command:FindByID("SalesmanAdd").access = "s";
	Clockwork.command:FindByID("SalesmanEdit").access = "s";
	Clockwork.command:FindByID("SalesmanRemove").access = "s";
	Clockwork.command:FindByID("StaticPropAdd").access = "a";
	Clockwork.command:FindByID("AdvertAdd").access = "s";
	Clockwork.command:FindByID("DoorLock").access = "a";
	Clockwork.command:FindByID("DoorUnlock").access = "a";

	Clockwork.command:FindByID("CharSetModel").access = "a";
	Clockwork.command:FindByID("PlyWhitelist").access = "a";
	Clockwork.command:FindByID("PlyUnwhitelist").access = "a";

	Clockwork.command:FindByID("CharBan").access = "o";
	Clockwork.command:FindByID("CharUnban").access = "o";

	Clockwork.command:FindByID("AnimATW").access = "$";

	Clockwork.command:SetHidden("AnimATW", true);
end;