local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:PlayerAdjustRadioInfo(player, info)
	if (player:IsNoClipping() or (player:GetFaction() == FACTION_MPF and string.find(player:Name(), "SCN"))
		or Clockwork.player:GetFactionTable(player).noEavesdrop) then
		info.noEavesdrop = true;
	end;
end;

-- Called when a player's death sound should be played.
-- Using this hook since it's the only one that is called before DoPlayerDeath, which removes the player's ammo.
function PLUGIN:PlayerPlayDeathSound(player, gender)
	player:GetCharacter().savedAmmo = Clockwork.player:GetAmmo(player);
end;