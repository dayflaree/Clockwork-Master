local Clockwork = Clockwork;

PLUGIN.pgiFunc = function(self, player, arguments)
	local target = nil;	
	if (arguments[1]) then
		target = Clockwork.player:FindByID(arguments[1]);
	else
		target = Clockwork.entity:GetPlayer(player:GetEyeTraceNoCursor().Entity);
	end;
		
	if (target) then
		Clockwork.player:Notify(player, "Character Name: "..target:Name().."; Steam Name: "..target:SteamName().."; Steam ID: "..target:SteamID()..".");
		
		--Only show health & armor if they are using a name (and thus in observer)
		if (arguments[1]) then
			Clockwork.player:Notify(player, "Health: "..target:Health().."; Armor: "..target:Armor());
		end;
	else
		if (arguments[1]) then
			Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
		else
			Clockwork.player:Notify(player, "You are not looking at a valid character!");
		end;
	end;
end;

function PLUGIN:PlayerShouldSmoothSprint()
	return false;
end;

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");