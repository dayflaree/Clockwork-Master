local COMMAND = Clockwork.command:New("Forums");
COMMAND.tip = "Opens the nebulous forums in the steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Clockwork.datastream:Start(player, "OpenForumsURL", true);
end;

COMMAND:Register();

if (SERVER) then
	Clockwork.hint:Add("Forums", "Type /forums in chat to open the Night's Talon forums.");
else
	Clockwork.datastream:Hook("OpenForumsURL", function()
		gui.OpenURL("https://www.nightstalon.com/");
	end);
end;