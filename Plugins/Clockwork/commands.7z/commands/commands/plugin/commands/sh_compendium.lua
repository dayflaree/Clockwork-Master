local COMMAND = Clockwork.command:New("Compendium");
COMMAND.tip = "Opens a comprehensive advanced guide to roleplay in the Steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    Clockwork.datastream:Start(player, "OpenCompendiumURL", true);
end;

COMMAND:Register();

if (SERVER) then
    Clockwork.hint:Add("Compendium", "Type /compendium to bring up a comprehensive advanced guide to roleplay, written by various authors!");
else
    Clockwork.datastream:Hook("OpenCompendiumURL", function()
        gui.OpenURL("https://steamcommunity.com/sharedfiles/filedetails/?id=396304410");
    end);
end;
