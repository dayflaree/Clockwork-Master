local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("CopyGeneric");
COMMAND.tip = "Copy the data of a generic item.";
COMMAND.access = "s";
COMMAND.arguments = 0;

function COMMAND:OnRun(player, arguments)
	local item = player:GetEyeTrace().Entity;

	if (IsValid(item)) then
		if (item:GetClass() == "cw_item") then
			local itemTable = item:GetItemTable();
			local uid = itemTable("uniqueID");

			if (uid == "generic_consumable" or uid == "generic_item") then
				player.CopiedItem = table.Copy(itemTable);
				Clockwork.player:Notify(player, "Item successfully copied.");
			else
				Clockwork.player:Notify(player, "That is not a generic item!");
			end;
		else
			Clockwork.player:Notify(player, "That is not a valid item!");
		end;
	else
		Clockwork.player:Notify(player, "You are not aiming at anything!");
	end;
end;

COMMAND:Register();