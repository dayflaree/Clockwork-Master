local COMMAND = Clockwork.command:New("Content");
COMMAND.tip = "Opens the workshop collection in the steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Clockwork.datastream:Start(player, "OpenContentURL", "http://steamcommunity.com/workshop/filedetails/?id=" .. GetConVarString("host_workshop_collection"));
end;

if (CLIENT) then
	Clockwork.datastream:Hook("OpenContentURL", function(url)
		if (url) then
			gui.OpenURL(url);
		end;
	end);
end;

COMMAND:Register();