local COMMAND = Clockwork.command:New("RespawnStay");
COMMAND.tip = "Respawn a player, but keep them at their current position.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])

	if (target) then
		local position = target:GetPos();
		local angles = target:GetAngles();
		local eyeAngles = target:EyeAngles();

		target:Spawn()
		target:SetPos(position)
		target:SetAngles(angles)
		target:SetEyeAngles(eyeAngles)

		if (player != target) then
			Clockwork.player:Notify(player, "You have respawned "..target:Name()..".")
			Clockwork.player:Notify(target, player:Name().." has respawned you.")
		else
			Clockwork.player:Notify(player, "You have respawned yourself")
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!")
	end;
end;

COMMAND:Register();