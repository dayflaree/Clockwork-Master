local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("PlayLocalSound");
COMMAND.tip = "Plays a sound at your crosshair location. Random numbers can be done via <min, max> (<1, 4> = random from 1 to 4)";
COMMAND.text = "<string Path> [int Radius (def. 75)] [int Pitch (def. 100)] [int Volume (def. 100)]";
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 3;

function COMMAND:OnRun(player, arguments)
	local path 		= arguments[1];
	local level 	= tonumber(arguments[2]) or 75;
	local pitch 	= tonumber(arguments[3]) or 100;
	local volume 	= tonumber(arguments[4]) or 100;
	volume 			= volume / 100;

	if (!path or path == "") then
		Clockwork.player:Notify(player, "You did not specify a valid sound path!");
		return;
	end;

	path = path:gsub("<(%d+),%s*(%d+)>", function(min, max)
		return math.random(min, max);
	end);

	Clockwork.datastream:Start(nil, "PlayLocalSound", {path, player:GetEyeTraceNoCursor().HitPos, level, pitch, volume});
end;

COMMAND:Register();