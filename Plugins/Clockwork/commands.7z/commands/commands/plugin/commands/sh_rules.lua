local COMMAND = Clockwork.command:New("Rules");
COMMAND.tip = "Opens the server's rules in the steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Clockwork.datastream:Start(player, "OpenRulesURL", true);
end;

COMMAND:Register();

if (SERVER) then
	Clockwork.hint:Add("Rules", "Type /rules in chat to open the server's rules.");
else
	Clockwork.datastream:Hook("OpenRulesURL", function()
		gui.OpenURL("placeholder");
	end);
end;
