local PlUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Warn");
COMMAND.tip = "Warn a player.";
COMMAND.text = "<string Name> <string Reason>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local reason = table.concat(arguments, " ", 2);
	local sourceName = player:Name();

	if (!reason or reason == "") then
		reason = "an unspecified reason.";
	end;

	if (target) then
		if (target:IsAdmin() or target:IsUserGroup("operator")) then
			target = player;
			sourceName = "Toasty";
			reason = "Don't warn other staff members.";
		end;

		for k, v in pairs(_player.GetAll()) do
			if (v:IsAdmin() or v:IsUserGroup("operator")) then
				if (v == target) then
					continue;
				end;

				Clockwork.player:Notify(v, "[ADMIN] " .. sourceName .. " has warned " .. target:Name() .. " for: " .. reason);
			end;
		end;

		Clockwork.player:Notify(target, "[ADMIN] " .. sourceName .. " has warned you for: " .. reason)
		Clockwork.hint:Send(target, "[ADMIN] " .. sourceName .. " has warned you for: " .. reason, 10, Color(255, 0, 0, 255))
		target:ConCommand("play common/warned.wav")
	else
		Clockwork.player:Notify(player, arguments[1] .. " is not a valid player!");
	end;
end;

COMMAND:Register();