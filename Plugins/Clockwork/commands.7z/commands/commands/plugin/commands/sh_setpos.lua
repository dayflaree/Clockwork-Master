local COMMAND = Clockwork.command:New("SetPos");
COMMAND.tip = "Set your position using Source coordinates.";
COMMAND.text = "<x> <y> <z>";
COMMAND.arguments = 3;
COMMAND.access = "o";
COMMAND.flags = CMD_DEFAULT;

function COMMAND:OnRun(player, arguments)
	local x, y, z = tonumber(arguments[1]), tonumber(arguments[2]), tonumber(arguments[3]);
	x = math.Clamp(x, -16000, 16000);
	y = math.Clamp(y, -16000, 16000);
	z = math.Clamp(z, -16000, 16000);

	player:SetPos(Vector(x, y, z));

	Clockwork.player:Notify(player, "Your position has been set to: " .. x .. " " .. y .. " " .. z .. ".");
end;

COMMAND:Register();