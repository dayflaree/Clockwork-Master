local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharRefundAmmo");
COMMAND.tip = "Refunds ammo lost to a character at his last death, in the current session.";
COMMAND.text = "<string Name>"
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		targetChar = target:GetCharacter();
		if(targetChar) then
			if(targetChar.savedAmmo) then
				Clockwork.player:SetAmmo(target, targetChar.savedAmmo);
				targetChar.savedAmmo = nil;
				Clockwork.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." has refunded ammo to "..target:Name()..".");
				Clockwork.player:Notify(player, "You have refunded "..target:Name().."'s ammo.");
				Clockwork.player:Notify(target, "Your ammo has been refunded.");
			else 
				Clockwork.player:Notify(player, target:Name().." does not have any ammo to refund!");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not on a valid character!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();