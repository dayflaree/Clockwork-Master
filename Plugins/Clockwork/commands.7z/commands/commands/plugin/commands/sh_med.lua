local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("MeD");
COMMAND.tip = "Speak in third person to the person you are looking at.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");
	
	if (string.len(text) < 8) then
		Clockwork.player:Notify(player, "You did not specify enough text!");
		
		return;
	end;

	local target = player:GetEyeTraceNoCursor().Entity
	if (target and target:IsPlayer()) then
		Clockwork.chatBox:Add({target, player}, player, "med", text);
	else
		Clockwork.player:Notify(player, "You are not looking at a valid target!");
	end;
end;

COMMAND:Register();