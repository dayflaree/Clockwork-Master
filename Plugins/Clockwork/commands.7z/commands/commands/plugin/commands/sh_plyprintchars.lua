--[[-----------------
	Coded by Duck	aka autistic niger
-----------------]]--

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlyPrintChars");
COMMAND.tip = "Print all of a player's character names and ID's to your console.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	if (target) then
		player:PrintMessage(HUD_PRINTCONSOLE, "----- "..string.upper(target:Name()).."'s CHARACTERS -----");
		local characters = target:GetCharacters();
		for k, v in pairs(characters) do
			player:PrintMessage(HUD_PRINTCONSOLE, v.name.." - "..v.characterID);
		end;
		player:PrintMessage(HUD_PRINTCONSOLE, "----- END "..target:Name().."'s CHARACTERS -----");
		player:Notify("Printed to console.");
	else
		player:Notify(arguments[1].." is not a valid player!");
	end;
	-- wow!! epic code duck!!!
end;

COMMAND:Register();