local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("TextRemoveRadius");
COMMAND.tip = "Remove some text from a surface.";
COMMAND.text = "<int Radius>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos;
	local iRemoved = 0;
	local radius = 256;

	if (tonumber(arguments[1])) then
		radius = math.Clamp(tonumber(arguments[1]), 0, 1024);
	end;
	
	radius = radius * radius;

	for k, v in pairs(PLUGIN.storedList) do
		if (v.position:DistToSqr(position) <= radius) then
			Clockwork.datastream:Start(nil, "SurfaceTextRemove", v.position);
				PLUGIN.storedList[k] = nil;
			iRemoved = iRemoved + 1;
		end;
	end;
	
	if (iRemoved > 0) then
		if (iRemoved == 1) then
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." surface text.");
		else
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." surface texts.");
		end;
	else
		Clockwork.player:Notify(player, "There were no surface texts near this position.");
	end;
	
	PLUGIN:SaveSurfaceTexts();
end;

COMMAND:Register();