local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("GMRoll");
COMMAND.tip = "Roll a number between 0 and the specified number.";
COMMAND.text = "[number Range]";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local number = math.Clamp(math.Round(tonumber(arguments[1]) or 100), 0, 1000000000);
	local random = math.random(0, number);
	
	Clockwork.chatBox:Add(player, player, "gmroll", tostring(random), tostring(number));
	Clockwork.kernel:ServerLog(player:Name().." has gmrolled a "..random.." out of "..number..".");
end;

COMMAND:Register();