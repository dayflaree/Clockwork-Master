local COMMAND = Clockwork.command:New("Guide");
COMMAND.tip = "Opens a beginner's guide to Fallout Roleplay in the Steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    Clockwork.datastream:Start(player, "OpenGuideURL", true);
end;

COMMAND:Register();

if (SERVER) then
    Clockwork.hint:Add("Guide", "Type /guide to bring up a beginner's guide to FORP, written by Night's Talon community members!");
else
    Clockwork.datastream:Hook("OpenGuideURL", function()
        gui.OpenURL("placeholder");
    end);
end;