local COMMAND = Clockwork.command:New("Lore");
COMMAND.tip = "Opens Fallout Roleplay's lore in the Steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Clockwork.datastream:Start(player, "OpenLoreURL", true);
end;

COMMAND:Register();

if (SERVER) then
	Clockwork.hint:Add("Lore", "Type /lore to get a lovely page where you can read all about our Fallout Roleplay's lore!");
else
	Clockwork.datastream:Hook("OpenLoreURL", function()
		gui.OpenURL("placeholder");
	end);
end;
