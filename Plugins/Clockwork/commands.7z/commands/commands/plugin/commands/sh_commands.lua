local COMMAND = Clockwork.command:New("Commands");
COMMAND.tip = "Opens a guide on basic commands in the Steam browser.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    Clockwork.datastream:Start(player, "OpenCommandsURL", true);
end;

COMMAND:Register();

if (SERVER) then
    Clockwork.hint:Add("Commands", "Type /commands to bring up a guide on the basic commands, written by various authors!");
else
    Clockwork.datastream:Hook("OpenCommandsURL", function()
        gui.OpenURL("https://nebulous.cloud/threads/the-simple-guide-to-roleplay-commands.707/");
    end);
end;
