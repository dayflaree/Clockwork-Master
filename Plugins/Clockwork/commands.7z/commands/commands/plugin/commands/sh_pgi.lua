local COMMAND = Clockwork.command:New("PGI");
COMMAND.tip = "Gets a player's IC name, OOC name, steam ID, health & armor. Enter a name or look at the desired player";
COMMAND.text = "[string Name] [anything ShowHP/Armor]"
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.optionalArguments = 2;

-- Called when the command has been run.
COMMAND.OnRun = PLUGIN.pgiFunc;

COMMAND:Register();