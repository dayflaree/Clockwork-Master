local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharAttributeAdd");
COMMAND.tip = "Adds the given amount to the player's attribute.";
COMMAND.text = "[string Name] [string Attribute] [int Amount]"
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 3;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		local amount = tonumber(arguments[3]);
		if (amount and amount > 0) then
			local success, err = Clockwork.attributes:Update(target, arguments[2], amount);
			if (!success) then
				if (!err) then
					err = "Something went wrong!"
				end;
			    Clockwork.player:Notify(player, err);
			else
				Clockwork.player:Notify(player, "You have added "..amount.." to "..target:Name().."'s "..arguments[2]..".");
			end;
		else
			Clockwork.player:Notify(player, "You did not specify a valid amount!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();