local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlyForceChar");
COMMAND.tip = "Forces a player to use a character and prevents them from switching for the given time.";
COMMAND.text = "<string Name> <string CharName> [int Time] [bool Stay]";
COMMAND.access = "a";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		local charName = string.lower(arguments[2]);
		local characters = target:GetCharacters();
		local char = nil;

		for k, v in pairs(characters) do
			if (string.lower(v.name) == charName) then
				char = v;
				break;
			elseif (string.find(string.lower(v.name), charName)) then
				if (!char or string.len(char.name) > string.len(v.name)) then
					char = v;
				end;
			end;
		end;

		if (char) then
			local oldName = player:Name();
			
			local fault = Clockwork.plugin:Call("PlayerCanUseCharacter", player, character);
			
			-- Check if the player can use the character if not an SA or above
			if (!player:IsSuperAdmin() and fault != nil and fault != true) then
				local message = fault or "You cannot use this character!";
				Clockwork.player:Notify(player, "The target cannot use this character: \""..message.."\"");
				return;
			end;
			
			local pos = target:GetPos() + Vector(0, 0, 8);
			local angles = target:GetAngles();
			local eyeAngles = target:EyeAngles();

			if (!target:Alive()) then
				target:Spawn();		
			end;

			Clockwork.player:LoadCharacter(target, char.characterID, nil, nil, true);

			if (arguments[4] and
				((tonumber(arguments[4]) and tonumber(arguments[4]) != 0) or 
				arguments[4] == "true" or arguments[4] == true)) then

				target:SetPos(pos);
				target:SetAngles(angles)
				target:SetEyeAngles(eyeAngles)
			end;

			local time = tonumber(arguments[3]);		
			if (time) then
				player.noCharSwap = CurTime() + math.max(math.Round(time), 0);
			end;

			if (target != player) then
				if (Clockwork.config:Get("global_echo"):Get()) then
					Clockwork.player:NotifyAll(player:Name().." has forced "..oldName.." to use "..target:Name()..".");
				else
					Clockwork.player:Notify(player, "You have forced "..oldName.." to use "..target:Name()..".");
					Clockwork.player:Notify(target, player:Name().." has forced you to use "..target:Name()..".");
				end;
			else
				if (Clockwork.config:Get("global_echo"):Get()) then
					Clockwork.player:NotifyAll(oldName.." has forced themself to use "..player:Name()..".");
				else
					Clockwork.player:Notify(player, "You have forced yourself to use "..player:Name()..".");
				end;
			end;
		else
			Clockwork.player:Notify(player, target:Name().." does not have a character with name "..charName..".");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();