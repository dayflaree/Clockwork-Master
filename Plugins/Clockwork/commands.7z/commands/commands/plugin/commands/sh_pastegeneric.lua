local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("PasteGeneric");
COMMAND.tip = "Paste your copied generic item.";
COMMAND.access = "s";
COMMAND.arguments = 0;

function COMMAND:OnRun(player, arguments)
	if (!player.CopiedItem) then
		Clockwork.player:Notify(player, "You do not have any copied data!");
		return;
	end;

	local itemTable = Clockwork.item:CreateInstance(player.CopiedItem.uniqueID);
	local pos = player:GetEyeTraceNoCursor().HitPos;
	local normal = player:GetEyeTraceNoCursor().HitNormal;

	for k, v in pairs(itemTable.data) do
		itemTable:SetData(k, player.CopiedItem.data[k]);
	end;

	local item = Clockwork.entity:CreateItem(nil, itemTable, pos);

	Clockwork.entity:MakeFlushToGround(item, pos, normal);
	Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " pasted a " .. itemTable("name") .. " (" .. itemTable("uniqueID") .. ") " .. itemTable("itemID") .. ".");
end;

COMMAND:Register();