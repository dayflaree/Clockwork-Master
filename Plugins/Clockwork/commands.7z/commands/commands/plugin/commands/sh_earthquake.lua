local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("Earthquake");
COMMAND.tip = "Create an earthquake at your crosshair.";
COMMAND.text = "<int Radius> <int Duration> [int Amplitude] [int Frequency]";
COMMAND.access = "a";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 2;

function COMMAND:OnRun(player, arguments)
	local radius = tonumber(arguments[1]) or 400;
	local duration = tonumber(arguments[2]) or 1;
	local amp = tonumber(arguments[3]) or 5;
	local freq = tonumber(arguments[4]) or 5;

	util.ScreenShake(player:GetEyeTrace().HitPos, amp, freq, duration, radius);
end;

COMMAND:Register();