local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.chatBox:RegisterClass("localevent", nil, function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(200, 100, 50, 255), "* "..info.text);
end);

Clockwork.chatBox:RegisterClass("me", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	if (string.sub(info.text, 1, 1) == "'") then
		Clockwork.chatBox:Add(info.filtered, nil, color, "*** "..info.name..info.text);
	else
		Clockwork.chatBox:Add(info.filtered, nil, color, "*** "..info.name.." "..info.text);
	end;
end);

Clockwork.chatBox:RegisterClass("mec", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	if (string.sub(info.text, 1, 1) == "'") then
		Clockwork.chatBox:Add(info.filtered, nil, color, "* "..info.name..info.text);
	else
		Clockwork.chatBox:Add(info.filtered, nil, color, "* "..info.name.." "..info.text);
	end;
end);

Clockwork.chatBox:RegisterClass("mel", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	if (string.sub(info.text, 1, 1) == "'") then
		Clockwork.chatBox:Add(info.filtered, nil, color, "***** "..info.name..info.text);
	else
		Clockwork.chatBox:Add(info.filtered, nil, color, "***** "..info.name.." "..info.text);
	end;
end);

Clockwork.chatBox:RegisterClass("med", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	if (string.sub(info.text, 1, 1) == "'") then
		Clockwork.chatBox:Add(info.filtered, nil, color, "** "..info.name..info.text);
	else
		Clockwork.chatBox:Add(info.filtered, nil, color, "** "..info.name.." "..info.text);
	end;
end);

Clockwork.chatBox:RegisterClass("it", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	Clockwork.chatBox:Add(info.filtered, nil, color, "***' "..info.text);
end);

Clockwork.chatBox:RegisterClass("itc", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	Clockwork.chatBox:Add(info.filtered, nil, color, "*' "..info.text);
end);

Clockwork.chatBox:RegisterClass("itl", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	Clockwork.chatBox:Add(info.filtered, nil, color, "*****' "..info.text);
end);

Clockwork.chatBox:RegisterClass("itd", "ic", function(info)				
	local color;
	if (!info.focusedOn) then
		color = Color(255, 255, 150, 255);
	else
		color = Color(175, 255, 175, 255);
	end;
	
	Clockwork.chatBox:Add(info.filtered, nil, color, "**' "..info.text);
end);

Clockwork.chatBox:RegisterClass("gmroll", nil, function(info)				
	Clockwork.chatBox:Add(info.filtered, nil, Color(150, 75, 75, 255), "** You have gmrolled a "..info.text.." out of "..info.data[1]..".");
end);

Clockwork.chatBox:RegisterClass("dispchat", "ooc", function(info)
	local classIndex = info.speaker:Team();
	local classColor = cwTeam.GetColor(classIndex);
	Clockwork.chatBox:Add(info.filtered, nil, Color(255, 200, 50, 255), "@Dispatch ", classColor, info.name, Color(150, 200, 150, 255), ": "..info.text);
end);


Clockwork.datastream:Hook("PlayLocalSound", function(data)
	local path 		= data[1];
	local position 	= data[2];
	local level 	= tonumber(data[3]);
	local pitch 	= tonumber(data[4]);
	local volume 	= tonumber(data[5]);

	sound.Play(path, position, level, pitch, volume);
end);

function PLUGIN:DrawPhysgunBeam(player)
	if (player:GetNoDraw()) then
		return false;
	end;
end;