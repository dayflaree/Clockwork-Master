local Clockwork = Clockwork;

Clockwork.hint:Add("Forums", "Haven't registered yet? You should! Go to www.nightstalon.com or type /forums in chat.");
Clockwork.hint:Add("Rules", "Make sure you read the rules on www.nightstalon.com or type /rules in chat!");
Clockwork.hint:Add("Content", "Seeing errors? Type /content in chat to open the workshop collection.");