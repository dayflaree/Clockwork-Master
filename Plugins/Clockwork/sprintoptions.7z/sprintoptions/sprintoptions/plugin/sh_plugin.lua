local PLUGIN = PLUGIN;

if (CLIENT) then 

Clockwork.config:AddToSystem("Stamina Regen Scale", "stam_regen_scale", "Determines how fast stamina should regenerate.", 0, 10, 3);
Clockwork.config:AddToSystem("Disable Alt Run", "disable_alt_run", "Whether or not to disable alt-running.")

-- Called when a player presses a bind.
function PLUGIN:PlayerBindPress(player, bind)
	if (Clockwork.config:Get("disable_alt_run"):Get()) then
		if (string.find(bind:lower(), "+walk")) then
			if (!player:KeyDown(IN_SPEED)) then
				return true;
			end;
		end;
	end;
end;

else

Clockwork.config:Add("stam_regen_scale", 1, true);
Clockwork.config:Add("disable_alt_run", false, true);

function PLUGIN:ClockworkAddSharedVars()
-- Called at an interval while a player is connected.
function cwStamina:PlayerThink(player, curTime, infoTable)
	local regeneration = 0;
	local attribute = Clockwork.attributes:Fraction(player, ATB_STAMINA, 1, 0.25);
	local scale = Clockwork.config:Get("stam_drain_scale"):Get();
	local regen = Clockwork.config:Get("stam_regen_scale"):Get();
	local decrease = (scale + (scale - (math.min(player:Health(), 500) / 500))) / (scale + attribute);
	
	if (!player:IsNoClipping() and player:IsOnGround()
	and (infoTable.isRunning or infoTable.isJogging)) then
		player:SetCharacterData(
			"Stamina", math.Clamp(
				player:GetCharacterData("Stamina") - decrease, 0, 100
			)
		);
		
		if (player:GetCharacterData("Stamina") > 1) then
			if (infoTable.isRunning) then
				player:ProgressAttribute(ATB_STAMINA, 0.025, true);
			elseif (infoTable.isJogging) then
				player:ProgressAttribute(ATB_STAMINA, 0.0125, true);
			end;
		end;
	elseif (!infoTable.isRunning) then
		if (player:Crouching()) then
			regeneration = scale * regen;
		else
			regeneration = scale * (regen * 3);
		end;
	else
		regeneration = regen;
	end;

	if (regeneration > 0 and Clockwork.plugin:Call("PlayerShouldStaminaRegenerate", player)) then
		player:SetCharacterData(
			"Stamina", math.Clamp(
				player:GetCharacterData("Stamina") + regeneration, 0, 100
			)
		);
	end;
	
	local newRunSpeed = infoTable.runSpeed * 2;
	local diffRunSpeed = newRunSpeed - infoTable.walkSpeed;
	local maxRunSpeed = Clockwork.config:Get("run_speed"):Get();

	infoTable.runSpeed = math.Clamp(newRunSpeed - (diffRunSpeed - ((diffRunSpeed / 100) * player:GetCharacterData("Stamina"))), infoTable.walkSpeed, maxRunSpeed);
	
	if (infoTable.isJogging) then
		local walkSpeed = Clockwork.config:Get("walk_speed"):Get();
		local newWalkSpeed = walkSpeed * 1.75;
		local diffWalkSpeed = newWalkSpeed - walkSpeed;

		infoTable.walkSpeed = newWalkSpeed - (diffWalkSpeed - ((diffWalkSpeed / 100) * player:GetCharacterData("Stamina")));
		
		if (player:GetCharacterData("Stamina") < 1) then
			player:SetSharedVar("IsJogMode", false);
		end;
	end;
	
	local stamina = player:GetCharacterData("Stamina");
	
	if (stamina < 30 and Clockwork.event:CanRun("sounds", "breathing")) then
		bPlayerBreathSnd = true;
	end;
	
	if (!player.nextBreathingSound or curTime >= player.nextBreathingSound) then
		if (!Clockwork.player:IsNoClipping(player)) then
			player.nextBreathingSound = curTime + 1;
			
			if (bPlayerBreathSnd) then
				local volume = Clockwork.config:Get("breathing_volume"):Get() - stamina;

				Clockwork.player:StartSound(player, "LowStamina", "player/breathe1.wav", volume / 100);
			else
				Clockwork.player:StopSound(player, "LowStamina", 4);
			end;
		end;
	end;
end;
end;
end;