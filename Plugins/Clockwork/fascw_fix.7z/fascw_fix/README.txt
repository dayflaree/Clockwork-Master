Place this in your garrysmod/cfg folder.
This fix is for the holster system with firearms source clockwork plugin.
You can also edit anything else you'd like, including damage and other variables.
Enjoy.