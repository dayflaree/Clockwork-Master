local Clockwork = Clockwork;

local PLUGIN = PLUGIN;

-- A function to load the fields.
function PLUGIN:LoadFields()
	local fields = Clockwork.kernel:RestoreSchemaData("plugins/3dpanel/"..game.GetMap());
	
	for k, v in pairs(fields) do
		local entity = ents.Create("3dpanel");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		entity:Activate();
		entity:SpawnProps();

		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
	end;
end;

-- A function to save the fields.
function PLUGIN:SaveFields()
	local fields = {};
	
	for k, v in pairs(ents.FindByClass("3dpanel")) do
		local position = v:GetPos();
		local angles = v:GetAngles();

		fields[#fields + 1] = {
			position = position,
			angles = angles,
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/3dpanel/"..game.GetMap(), fields);
end;