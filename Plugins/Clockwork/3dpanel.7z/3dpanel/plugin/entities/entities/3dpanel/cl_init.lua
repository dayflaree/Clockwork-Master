include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:Initialize() 
	self.Map = vgui.Create("DHTML")
	self.Map:SetPos(0, 0)
	self.Map:SetSize(1900, 950)
	
	self.Map:SetVisible(true)
	
	self.Map:SetPaintedManually(true)

	local url = "http://gmod.novabox.org/rules"
	self.Map:OpenURL( url )
end

function ENT:OnRemove()
	timer.Destroy(self:EntIndex() .. "_map")
end

function ENT:Draw()
	self:DrawModel()
	
	local min, max = self:OBBMins(), self:OBBMaxs()
	local offset = max - min
	
	local pos = self:GetPos() + (self:GetUp() * (offset.z * 0.5)) + (self:GetRight() * (-offset.y / 2)) + (self:GetForward() * (offset.x / 2))
	local ang = self:GetAngles()
	
	ang:RotateAroundAxis(ang:Up(), -90)
	
	self.Map:SetPaintedManually(false)
	
	cam.Start3D2D(pos, ang, 0.2)
		self.Map:PaintManual()
	cam.End3D2D()
	
	self.Map:SetPaintedManually(true)
end