local Clockwork = Clockwork;

local PLUGIN = PLUGIN;

function PLUGIN:ApplySecurityLock(entity, position, angles)
	local securityLock = ents.Create("cw_securitylock");
	
	securityLock:SetParent(entity);
	securityLock:SetDoor(entity);
	
	if (position) then
		if (type(position) == "table") then
			securityLock:SetLocalPos( Vector(-1.0313, 43.7188, -1.2258) );
			securityLock:SetPos( securityLock:GetPos() + (position.HitNormal * 4) );
		else
			securityLock:SetPos(position);
		end;
	end;
	
	if (angles) then
		securityLock:SetAngles(angles);
	end;
	
	securityLock:Spawn();
	
	if (IsValid(securityLock)) then
		return securityLock;
	end;
end;

-- A function to load the fields.
function PLUGIN:LoadSecurity()
	local positions = {};
	local doorData = Clockwork.kernel:RestoreSchemaData("plugins/doorperms/"..game.GetMap());
	
	for k, v in pairs(ents.GetAll()) do
		if (IsValid(v)) then
			local position = v:GetPos();
			
			if (position) then
				positions[tostring(position)] = v;
			end;
		end;
	end;
	
	for k, v in pairs(doorData) do
		local entity = positions[tostring(v.position)];
		
		if (IsValid(entity) and !self.doorData[entity]) then
			if (Clockwork.entity:IsDoor(entity)) then
				self.doorData[entity] = v;
				entity.permTable = {Factions = v.Factions, Classes = v.Classes}
			end;
		end;
	end;
	
	local fields = Clockwork.kernel:RestoreSchemaData("plugins/ff/"..game.GetMap());
	
	for k, v in pairs(fields) do
		local entity = ents.Create("cw_forcefield");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		entity:Activate();
		entity:SpawnProps();
		entity.shouldissolve = v.dissolve;
		entity.policeOnly = v.policeOnly;
        entity:SetGateSolid(v.policeOnly);
        entity.permTable = v.permTable or {Factions = {}, Classes = {}};
		
		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
	end;
	
	local securityLocks = Clockwork.kernel:RestoreSchemaData( "plugins/sl/"..game.GetMap() );
	
	for k, v in pairs(securityLocks) do
		local entity = ents.FindInSphere(v.doorPosition, 16)[1];
		
		if (IsValid(entity)) then
			local securityLock = self:ApplySecurityLock(entity);
			
			if (securityLock) then
				securityLock.permTable = v.permTable or {Factions = {}, Classes = {}}
				Clockwork.player:GivePropertyOffline(v.key, v.uniqueID, entity);
				
				securityLock:SetLocalAngles(v.angles);
				securityLock:SetLocalPos(v.position);
				
				if (!v.locked) then
					securityLock:Unlock();
				else
					securityLock:Lock();
				end;
			end;
		end;
	end;
end;

-- A function to save the fields.
function PLUGIN:SaveSecurity()
	local doorData = {};
	
	for k, v in pairs(self.doorData) do
		doorData[#doorData + 1] = v;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/doorperms/"..game.GetMap(), doorData);
	
	local fields = {};
	
	for k, v in pairs(ents.FindByClass("cw_forcefield")) do
		local position = v:GetPos();
		local angles = v:GetAngles();
		local shouldDissolve = v.shouldDissolve;
		local policeOnly = v.policeOnly or false;
		local permTable = v.permTable or {Factions = {}, Classes = {}}
		fields[#fields + 1] = {
			position = position,
			angles = angles,
			dissolve = shouldDissolve,
			policeOnly = policeOnly,
			permTable = permTable
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/ff/"..game.GetMap(), fields);
	
	local securityLocks = {};
	
	for k, v in pairs( ents.FindByClass("cw_securitylock") ) do
		if (IsValid(v.entity)) then
			local permTable = v.permTable or {Factions = {}, Classes = {}}
			securityLocks[#securityLocks + 1] = {
				key = Clockwork.entity:QueryProperty(v, "key"),
				locked = v:IsLocked(),
				angles = v:GetLocalAngles(),
				position = v:GetLocalPos(),
				uniqueID = Clockwork.entity:QueryProperty(v, "uniqueID"),
				doorPosition = v.entity:GetPos(),
				permTable = permTable
			};
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/sl/"..game.GetMap(), securityLocks);
end;