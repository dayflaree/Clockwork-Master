Clockwork.datastream:Hook("PermissionsSet", function(data)
	Clockwork.permis = {}
	Clockwork.permis.entity = data.entity;
	Clockwork.permis.factions = data.Factions;
	Clockwork.permis.classes = data.Classes;
	
	Clockwork.permis.panel = vgui.Create("cwPermissions");
	Clockwork.permis.panel:MakePopup();
end);

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	if Clockwork.permis.entity:GetClass() == "cw_forcefield" then
		self:SetTitle("Forcefield");
	elseif Clockwork.permis.entity:GetClass() == "cw_securitylock" then
		self:SetTitle("Security Lock");
	else
		self:SetTitle("Door");
	end
	self:SetBackgroundBlur(true);
	self:SetDeleteOnClose(false);
	
	-- Called when the button is clicked.
	function self.btnClose.DoClick(button)
		CloseDermaMenus();
		self:Close(); self:Remove();
		
		Clockwork.datastream:Start("PermissionsSet", {
			entity = Clockwork.permis.entity,
			factions = Clockwork.permis.factions,
			classes = Clockwork.permis.classes
		});
		
		Clockwork.permis.entity = nil;
		Clockwork.permis.factions = nil;
		Clockwork.permis.classes = nil;
		
		gui.EnableScreenClicker(false);
	end;
	
	self.settingsPanel = vgui.Create("cwPanelList");
 	self.settingsPanel:SetPadding(2);
 	self.settingsPanel:SetSpacing(3);
 	self.settingsPanel:SizeToContents();
	self.settingsPanel:EnableVerticalScrollbar();
	
	self.settingsForm = vgui.Create("cwForm");
	self.settingsForm:SetPadding(4);
	self.settingsForm:SetName("Settings");
	self.settingsPanel:AddItem(self.settingsForm);
	
	self.factionsForm = vgui.Create("DForm");
	self.factionsForm:SetPadding(4);
	self.factionsForm:SetName("Factions");
	self.settingsForm:AddItem(self.factionsForm);
	self.factionsForm:Help("Leave these unchecked to allow all factions to buy and sell.");
	
	self.classesForm = vgui.Create("DForm");
	self.classesForm:SetPadding(4);
	self.classesForm:SetName("Classes");
	self.settingsForm:AddItem(self.classesForm);
	self.classesForm:Help("Leave these unchecked to allow all classes to buy and sell.");
	
	self.classBoxes = {};
	self.factionBoxes = {};
	
	for k, v in pairs(Clockwork.faction.stored) do
		self.factionBoxes[k] = self.factionsForm:CheckBox(v.name);
		self.factionBoxes[k].OnChange = function(checkBox)
			if (checkBox:GetChecked()) then
				Clockwork.permis.factions[k] = true;
			else
				Clockwork.permis.factions[k] = nil;
			end;
		end;
		
		if (Clockwork.permis.factions[k]) then
			self.factionBoxes[k]:SetValue(true);
		end;
	end;
	
	for k, v in pairs(Clockwork.class.stored) do
		self.classBoxes[k] = self.classesForm:CheckBox(v.name);
		self.classBoxes[k].OnChange = function(checkBox)
			if (checkBox:GetChecked()) then
				Clockwork.permis.classes[k] = true;
			else
				Clockwork.permis.classes[k] = nil;
			end;
		end;
		
		if (Clockwork.permis.classes[k]) then
			self.classBoxes[k]:SetValue(true);
		end;
	end;
	
	self.propertySheet = vgui.Create("DPropertySheet", self);
		self.propertySheet:SetPadding(4);
		self.propertySheet:AddSheet("Settings", self.settingsPanel, "icon16/tick.png", nil, nil, "View possible items for trading.");
		
	Clockwork.kernel:SetNoticePanel(self);
end;

-- Called each frame.
function PANEL:Think()
	self:SetSize(ScrW() * 0.5, ScrH() * 0.75);
	self:SetPos((ScrW() / 2) - (self:GetWide() / 2), (ScrH() / 2) - (self:GetTall() / 2));
end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	DFrame.PerformLayout(self);
	
	if (self.propertySheet) then
		self.propertySheet:StretchToParent(4, 28, 4, 4);
	end;
end;

vgui.Register("cwPermissions", PANEL, "DFrame");