local PLUGIN = PLUGIN;

PLUGIN:SetGlobalAlias("cwSecurity");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

function PLUGIN:CheckPermission(player, permTable)
	local numFactions = table.Count(permTable.Factions);
	local numClasses = table.Count(permTable.Classes);
	local ret = true;
	
	if (numFactions > 0) then
		if (!permTable.Factions[player:GetFaction()]) then
			ret = false;
		end;
	end;
	
	if (numClasses > 0) then
		if (!permTable.Classes[cwTeam.GetName(player:Team())]) then
			ret = false;
		end;
	end;
	
	return ret
end