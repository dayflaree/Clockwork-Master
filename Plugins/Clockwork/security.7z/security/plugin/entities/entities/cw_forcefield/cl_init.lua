include("shared.lua");

ENT.GateMaterial = Material( "effects/combineshield/comshieldwall" )
function ENT:Draw()

end

function ENT:DrawTranslucent()
    local color = Color(255,255,255,255)
	local direction = self:GetForward()
        render.SetMaterial( self.GateMaterial )

        
    if ( !self:GetIsLocked() ) then return end
    render.DrawQuadEasy( self:GetPos()+ self:GetUp() * 53.525 + self:GetRight() * 10,    --position of the rect
    direction,        --direction to face in
    180, 125,              --size of the rect
    Color( 255, 255, 255, 255 ),  --color
    self:GetAngles().r                    --rotate 90 degrees
    ) 
    render.DrawQuadEasy( self:GetPos()+ self:GetUp() * 53.525 + self:GetRight() * 10,    --position of the rect
    -direction,        --direction to face in
    180, 125,              --size of the rect
    Color( 255, 255, 255, 255 ),  --color
    self:GetAngles().r                      --rotate 90 degrees
    ) 
end