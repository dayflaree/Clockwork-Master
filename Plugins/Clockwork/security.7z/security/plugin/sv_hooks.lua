local Clockwork = Clockwork;

local PLUGIN = PLUGIN;
PLUGIN.doorData = {}
-- Called when OpenAura has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
    self:LoadSecurity();
end;

-- Called when data should be saved.
function PLUGIN:PostSaveData()
	self:SaveSecurity();
end;

function PLUGIN:PlayerCanUseDoor(player, door)
	if (door.permTable and (0 < table.Count(door.permTable.Factions) or 0 < table.Count(door.permTable.Classes))) then
		return self:CheckPermission(player, door.permTable)
	end;
end;

function PLUGIN:PlayerUse(player, entity)
	local overlayText = entity:GetNetworkedString("GModOverlayText");
	local curTime = CurTime();
	local faction = player:GetFaction();
	
	if (player:KeyDown(IN_SPEED) and Clockwork.entity:IsDoor(entity)) then
		if (!Schema:PlayerIsCombine(player) and player:GetFaction() != FACTION_ADMIN and IsValid(entity.combineLock)) then
			if (!player.nextCombineLock or curTime >= player.nextCombineLock) then
				entity.combineLock:ToggleWithChecks(player);
				
				player.nextCombineLock = curTime + 3;
			end;
			
			return false;
		end;
	end;
end;

Clockwork.datastream:Hook("PermissionsSet", function(player, data)
	if !player.cwEditingPerms then return end
	data.entity.permTable = {Factions = data.factions, Classes = data.classes}
	if Clockwork.entity:IsDoor(data.entity) then
		PLUGIN.doorData[data.entity] = {Factions = data.factions, Classes = data.classes, position = data.entity:GetPos()}
	end
	player.cwEditingPerms = false
end)