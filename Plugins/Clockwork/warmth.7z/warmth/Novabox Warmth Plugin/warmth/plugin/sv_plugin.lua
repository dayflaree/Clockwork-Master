--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.kernel:AddDirectory("materials/models/jake/");
Clockwork.kernel:AddDirectory("models/avoxgaming/mrp/jake/props/");
Clockwork.kernel:AddDirectory("sound/effects/iron_wall/gas_mask/");

Clockwork.config:Add("air_warmther", false);
Clockwork.config:Add("air_warmther_give_mask", false);
Clockwork.config:Add("air_warmther_warmthy_change_limit", 20);

local playerMeta = FindMetaTable("Player");

print("~~~LOADING WARMTH SV_PLUGIN.LUA~~~")

function PLUGIN:LoadWarmthAreas()
	local triggerzones = {
	"safezone_fotochange",
	"safezone_nexus",
	"safezone_rations",
	"safezone_terminalhotel",
	"safezone_hospital",
	"safezone_train",
	"safezone_factory1",
	"safezone_grotto",
	"safezone_constructionshop",
	"safezone_theater",
	"safezone_shop1",
	"safezone_baltic",
	"safezone_lolwebulbase",
	"safezone_oldapartments",
	"safezone_garage",
	"safezone_canalroom1",
	"safezone_canalroom2",
	"safezone_canalroom3",
	"safezone_quarry",
	"safezone_ubc",
	"safezone_shop2",
	"safezone_factory2",
	"safezone_roofcafe",
	"safezone_roofapartments",
	"safezone_shop3",
	"safezone_cpoutpost",
	"safezone_garbage",
	"safezone_diordna",
	"safezone_metropol",
	"safezone_uppercafe",
	"safezone_ship1",
	"safezone_ship2",
	"safezone_secretroom",
	"safezone_constructionapartments1",
	"safezone_constructionapartments2",
	"safezone_constructionapartments3",
	"safezone_elevator",
	"safezone_outlands1",
	"safezone_outlands2",
	"safezone_outlands3",
	"safezone_outlands4"
	}
	for _, ent in ipairs(ents.FindByClass( "trigger_multiple" )) do
		if table.HasValue(triggerzones, ent:GetName()) then
			local novaboxisepic = ents.Create("warmthzones");
			local entity = novaboxisepic:SpawnFunction(ent:OBBMins(), ent:OBBMaxs(), ent:GetPos(), ent:GetAngles())
			print("spawning safezone: "..ent:GetName())
			novaboxisepic:Remove()
		end;
	end;
end;

function PLUGIN:SetWarmAir(player, state)
	player.cwWarmAir = state;
	player:SetSharedVar("WarmAir", state);
end;