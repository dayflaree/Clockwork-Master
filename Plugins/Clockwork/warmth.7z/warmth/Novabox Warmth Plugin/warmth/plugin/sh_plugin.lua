--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("Warmth", true);
	playerVars:Bool("WarmAir", true);
	playerVars:Bool("Beanie", true);
	playerVars:Bool("Gloves", true);
	playerVars:Bool("Wintercoat", true);
end;
PLUGIN.airAreas = {};

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

PLUGIN:SetGlobalAlias( "Airwarmther" )

print("~~~LOADING WARMTH~~~")