--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]
local PLUGIN = PLUGIN;

print("~~~LOADING WARMTH SV_HOOKS.LUA~~~")

function PLUGIN:ClockworkInitPostEntity() self:LoadWarmthAreas(); end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	player.cwWarmAir = false;
	player:SetSharedVar("WarmAir", false); -- Set Safe Air to False
end;

function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar("Warmth", math.Round(player:GetCharacterData("Warmth")));
end;

function PLUGIN:PlayerSaveCharacterData(player, data)
	if (data["Warmth"]) then
		data["Warmth"] = data["Warmth"];
	end;
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("Warmth", 50);
	end;
end;

function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (!data["Warmth"]) then
		data["Warmth"] = 100;
	end;
end;

function PLUGIN:PlayerThink(player, curTime, infoTable)
	if (!IsValid(player) or !player:HasInitialized()) then
		return;
	end;
	
	local curTime = CurTime();
	
	if (Clockwork.player:IsNoClipping(player) or !Clockwork.config:Get("air_warmther"):Get()) then
		if (!player.cwWarmAir) then
			self:SetWarmAir(player, true);
		end;
		
		return;
	end;
	
	if (player.WarmAirUpdate and curTime < player.WarmAirUpdate) then
		return;
	end;
	
	self.WarmAirUpdate = curTime + 1;

	if (!Schema:PlayerIsCombine(player)) then
	
	if (player:GetFaction() == FACTION_CONSCRIPT) then return end
	if (player:GetFaction() == FACTION_BIRD) then return end
	if (player:GetFaction() == FACTION_VORT) then return end
	if (player:GetFaction() == FACTION_VORTSLAVE) then return end
	
	-- Player is not combine.
		local warmth = player:GetCharacterData("Warmth");	
	
		if (!player.cwWarmAir) then
			-- Call player is in the cold.
			Clockwork.plugin:Call("PlayerThinkInColdAir", player, warmth);
		else
			-- Restore warmth level.
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") + 0.02,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		end;
	end;
end;

function PLUGIN:PlayerThinkInColdAir(player, warmth)
	if (warmth <= 0) then
	-- Call if warmth has run out.
		if (!player.coldAirJoinTime) then
			player.coldAirJoinTime = CurTime();
		end;
		
		player.coldAirTime = math.Round(CurTime() - player.coldAirJoinTime);
		
		if (!player.nextColdAirTick or player.nextColdAirTick <= player.coldAirTime) then
			player.nextColdAirTick = player.coldAirTime + 1;
			
			if (player.coldAirTime == 20 or player.coldAirTime == 40 or player.coldAirTime == 60 or player.coldAirTime == 90 or player.coldAirTime == 110) then Clockwork.player:Notify(player, "You are freezing! Go inside or get some proper clothing on!"); end;
			if (player.coldAirTime == 120 ) then Clockwork.player:Notify(player, "You are now freezing to death! Go inside or get some proper clothing on!"); end;
			if (player.coldAirTime <= 120) then return; end;			

			player:SetCharacterData("Stamina",math.Clamp(player:GetCharacterData("Stamina") - 4,0,100));
			local stamina = player:GetCharacterData("Stamina");

			if (stamina < 10) then
				player:SetHealth(math.Clamp(player:Health() - 5,0,100));
				
				if (player:Health() < 1) then
					player:TakeDamage(20, player, player);
				end;
			end;
		end;
	else
		local beanie = player:GetCharacterData("Beanie");
		local gloves = player:GetCharacterData("Gloves");
		local coat = player:GetCharacterData("Wintercoat");
		
		-- 0
		if ( !gloves and !coat and !beanie ) then	
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.02,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 5
		elseif ( beanie and !gloves and !coat ) then	
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.01,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 5
		elseif ( gloves and !beanie and !coat ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.01,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 10
		elseif ( coat and !gloves and !beanie ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.005,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 10
		elseif ( beanie and gloves and !coat ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.005,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 15
		elseif ( beanie and coat and !gloves ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.0025,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 15
		elseif ( gloves and coat and !beanie ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") - 0.0025,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		-- 20
		elseif ( gloves and coat and beanie ) then
			player:SetCharacterData("Warmth", math.Clamp(player:GetCharacterData("Warmth") + 0.02,0,100));
			player.coldAirJoinTime = false;
			player.nextColdAirTick = false;
		end
	end
end;

function PLUGIN:PlayerShouldStaminaRegenerate(player)
	if (player.coldAirJoinTime) then
		return false;
	end;
end;

function PLUGIN:PlayerShouldHealthRegenerate(player)
	if (player.coldAirJoinTime) then
		return false;
	end;
end;