--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("(ExT) Airwarmther", "air_warmther", "Enable Air warmther.");

function PLUGIN:AddwarmAirEffect(duration)
	local curTime = CurTime();
	
	if (!duration or duration == 0) then
		duration = 1;
	end;
	
	self.warmAirEffect = {curTime + (duration * 2), duration * 2, true};
end;