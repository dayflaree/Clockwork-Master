AddCSLuaFile('cl_init.lua')

ENT.Type = "brush"
ENT.Spawnable = false -- Nope
ENT.AdminSpawnable = false -- We want to spawn and modify within lua only and not be controlled outside of the files.

-- Called when the entity is spawned.
function ENT:SpawnFunction(minb, maxb, pos, ang)
    local entity = ents.Create("warmthzones");
    entity:Spawn();
	entity:SetCollisionBoundsWS(minb, maxb)
	entity:SetPos(pos)
	print("Spawning in init")
end

-- Called when the entity inits.
function ENT:Initialize()
	self:SetSolid( SOLID_BBOX ) -- Not Solid
    self:SetTrigger(true) -- So self is editable with lua.
end

-- Called when the entity starts touching something.
function ENT:StartTouch( entity )
	
	if ( !entity:IsValid() ) then return end -- Check to make sure the entity is valid.
	
	if ( !entity:IsPlayer() ) then return end -- Check if a player
	
	Airwarmther:SetWarmAir(entity, true)
	
	print("Someone is entering the fucking thing")

end

-- Called when the entity stops touching something.
function ENT:EndTouch( entity )

	if ( !entity:IsValid() ) then return end -- Check to make sure the entity is valid.

	if ( !entity:IsPlayer() ) then return end -- Check if a player
	
	Airwarmther:SetWarmAir(entity, false)
	
end