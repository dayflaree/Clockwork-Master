function ENT.Draw()
	halo.Add({self}, Color(255,0,0), 5, 5, 2)
end