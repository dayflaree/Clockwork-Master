--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

print("~~~LOADING WARMTH CL_HOOKS.LUA~~~")

function Schema:PlayerAdjustMotionBlurs(motionBlurs)
	if (!Clockwork.kernel:IsScreenFadedBlack()) then
		local curTime = CurTime();
		
		if (self.warmAirEffect and self.warmAirEffect[3]) then
			local timeLeft = math.Clamp( self.warmAirEffect[1] - curTime, 0, self.warmAirEffect[2] );
			local incrementer = 1 / self.warmAirEffect[2];
			
			if (timeLeft > 0) then
				motionBlurs.blurTable["flash"] = 1 - (incrementer * timeLeft);
			end;
		end;
	end;
end;

function PLUGIN:RenderScreenspaceEffects()
	if (!Clockwork.kernel:IsScreenFadedBlack()) then
		local curTime = CurTime();
		
		if (self.warmAirEffect) then
			local timeLeft = math.Clamp( self.warmAirEffect[1] - curTime, 0, self.warmAirEffect[2] );
			local incrementer = 1 / self.warmAirEffect[2];
			
			if (timeLeft > 0) then
				modify = {};
				
				modify["$pp_colour_brightness"] = 0;
				modify["$pp_colour_contrast"] = 1 + (timeLeft * incrementer);
				modify["$pp_colour_colour"] = 1 - (incrementer * timeLeft);
				modify["$pp_colour_addr"] = incrementer * timeLeft;
				modify["$pp_colour_addg"] = incrementer * timeLeft;
				modify["$pp_colour_addb"] = incrementer * timeLeft;
				modify["$pp_colour_mulr"] = 1;
				modify["$pp_colour_mulg"] = 0;
				modify["$pp_colour_mulb"] = 0;
				
				DrawColorModify(modify);
				
				if (!self.warmAirEffect[3]) then
					DrawMotionBlur( 1 - (incrementer * timeLeft), incrementer * timeLeft, self.warmAirEffect[2] );
				end;
			end;
		end;
	end;
end;

function PLUGIN:GetBars(bars)
	local warmthy = Clockwork.Client:GetSharedVar("Warmth");
	
	if (!self.warmthy) then
		self.warmthy = warmthy;
	else
		self.warmthy = math.Approach(self.warmthy, warmthy, 1);
	end;
	
	bars:Add("Warmth", Color(255, 165, 10, 255), "Warmth: "..math.Round(self.warmthy).."/100", self.warmthy, 100, self.warmthy < 20);

end;