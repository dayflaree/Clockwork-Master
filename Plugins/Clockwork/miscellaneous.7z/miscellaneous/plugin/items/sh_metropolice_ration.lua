--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Metropolice Basic Ration";
ITEM.model = "models/weapons/w_packatm.mdl";
ITEM.weight = 2;
ITEM.useText = "Open";
ITEM.description = "A black and white packet, it contains a major amount of supplements.";
ITEM.spawnType = "weaponry";
ITEM.spawnValue = 2;
-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
	if (quickUse) then
		if (!player:CanHoldWeight(self.weight)) then
			Clockwork.player:Notify(player, "You do not have enough inventory space!");
			
			return false;
		end;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)

		Clockwork.player:GiveCash(player, 120, "ration packet");
		
		player:GiveItem(Clockwork.item:CreateInstance("metropolice_supplements"), true);
		
		Clockwork.plugin:Call("PlayerUseRation", player);
	end;


-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();