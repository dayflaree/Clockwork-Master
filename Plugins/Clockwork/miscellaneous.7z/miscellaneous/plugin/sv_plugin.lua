local PLUGIN = PLUGIN;

function PLUGIN:PlayerSpawnedNPC(player, npc)
  for k, v in pairs(_player.GetAll()) do
    if(string.find(v:Name(), "DISPATCH") or string.find(v:Name(), "[OOC]")) then
      npc:AddEntityRelationship(v, D_LI, 99);
    end
    if(player:GetFaction() == FACTION_MPF or player:GetFaction() == FACTION_OTA) then
      if(npc:GetName() == "npc_turret_floor" or npc:GetName() == "npc_turret_ceiling") then
        npc:AddEntityRelationship(player, D_LI, 99);
      end
    end
  end
end

function PLUGIN:PlayerCharacterLoaded(player)
  local combine = ents.FindByClass("npc_")
  if(string.find(player:Name(), "DISPATCH") or string.find(player:Name(), "[OOC]")) then
    for _, x in pairs (combine) do
      if !x:IsNPC() then return end
      if x:GetClass() != player:GetClass() then
        x:AddEntityRelationship(player, D_LI, 99);
      end
    end
  end
-- NEEDS TO BE REMOVED AT SOME POINT, OR BETTER YET WHEN WE HAVE A BETTER FIX.
-- print(player:GetFaction());
-- print(tostring(player:GetFaction()));
--   if(player:GetFaction() == FACTION_CITIZEN) then
--     print("AAAAAAAAAAAAAAAAAAAAAAAAAA");
--     player:SetSharedVar("Wages", 100);
--   elseif(player:GetFaction() == FACTION_MPF) then
--     player:SetSharedVar("Wages", 10);
--   end

  if(player:GetFaction() == FACTION_CITIZEN or player:GetFaction() == FACTION_MPF) then
    if(Clockwork.player:HasFlags(player, "vV")) then
      Clockwork.player:TakeFlags(player, "vV");
    end
  end

  if(player:GetFaction() == FACTION_MPF or player:GetFaction() == FACTION_OTA) then
    local turrets = ents.FindByClass("npc_turret_*");
    for k, v in pairs (turrets) do
      v:AddEntityRelationship(player, D_LI, 99);
    end
  end
end