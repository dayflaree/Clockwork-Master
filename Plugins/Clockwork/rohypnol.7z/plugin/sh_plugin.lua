local PLUGIN = PLUGIN;

Clockwork.flag:Add("q", "Drugs", "Access to drug items.");