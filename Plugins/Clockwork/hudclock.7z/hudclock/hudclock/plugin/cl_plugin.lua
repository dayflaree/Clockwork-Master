local PLUGIN = PLUGIN;

Clockwork.setting:AddCheckBox("Framework", "Enable HUD clock.", "cwHudClock", "Whether or not to enable the hud clock.");