local PLUGIN = PLUGIN;

function PLUGIN:ChatBoxAdjustInfo(info)
	if (info.class == "ooc") then
		if (Clockwork.player:HasFlags(info.speaker, "D")) then
			info.icon = "icon16/heart.png";
		elseif (Clockwork.player:HasFlags(info.speaker, "H")) then
			info.icon = "icon16/rainbow.png";	
		end;
	end;
end;