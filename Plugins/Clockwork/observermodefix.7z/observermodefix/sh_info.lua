--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Observer Flashlight Fix";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This simple plugin fixes the flashlight problem with observer-mode. Players will not see observers with their flashlights.";