--[[
	Product: "OpenAura".
--]]

local PLUGIN = PLUGIN;

PLUGIN.surfaceTexts = {};
openAura:IncludePrefixed("sh_coms.lua");
openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("cl_hooks.lua");