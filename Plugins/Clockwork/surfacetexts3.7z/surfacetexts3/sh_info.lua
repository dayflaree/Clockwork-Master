--[[
	Product: "OpenAura".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Surface Texts v3";
PLUGIN.author = "";
PLUGIN.description = "Allows three dimensional text to be placed on a surface.";