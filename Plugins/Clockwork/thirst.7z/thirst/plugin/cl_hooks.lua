--[[
	Name: cl_hooks.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

-- Called when the bars are needed.
function PLUGIN:GetBars(bars)
	local thirst = Clockwork.Client:GetSharedVar("sh_thirst");
	
	if(thirst)then
		if (!self.thirst) then
			self.thirst = thirst;
		else
			self.thirst = math.Approach(self.thirst, thirst, 1);
		end;
		
		bars:Add("thirst", Color(0, 225, 255, 255), "thirst", self.thirst, 100, self.thirst < 10);
	end;
end;