local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sh_plugin.lua");