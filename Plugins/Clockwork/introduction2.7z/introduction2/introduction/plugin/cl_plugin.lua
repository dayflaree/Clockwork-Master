local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- A function to perform the introduction.
function PLUGIN:PerformIntro()
	local introTextSmallFont = Clockwork.option:GetFont("intro_text_small");
	local colorWhite = Clockwork.option:GetColor("white");
	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local scrH = ScrH();
	local scrW = ScrW();
	local sound = Clockwork.config:Get("intro_sound"):Get();

	if (!self.soundObj and sound) then
		self.soundObj = CreateSound(Clockwork.Client, sound);
		self.soundObj:Play();

		self.button = vgui.Create("cwLabelButton");
		self.button:SetFont(smallTextFont);
		self.button:SetText("CONTINUE");
		self.button:SizeToContents();
		self.button:SetCallback(function()
			self:Stop();
		end);
		
		self.button:SetPos(scrW * .9, scrH - 50);
		self.button:SetMouseInputEnabled(true);

		if (Clockwork.character.panel) then
			Clockwork.character.panel:SetAlpha(0);
			Clockwork.MusicSound:Stop();
		end;

		--[[ 
			Hacky...I know...but I have no idea why the cursor keeps disappearing.
			Probably something to do with a panel, I guess.
		--]]

		gui.EnableScreenClicker(true);
		EnableScreenClicker = gui.EnableScreenClicker;
		
		function gui.EnableScreenClicker() end;
	end;

	self.pos = self.pos or scrH;
		draw.DrawText(self.realText, introTextSmallFont, (scrW * .2), self.pos - 1, colorWhite, TEXT_ALIGN_LEFT);
	self.pos = self.pos - .06;

	local scrW, scrH = ScrW(), ScrH();
	local width, height = surface.GetTextSize(self.realText);

	--[[
		Check to see if the text has finished scrolling.
	--]]

	if ((self.pos + height) < 0) then
		self:Stop();
	end;
end;

-- A function to wrap the text.
function PLUGIN:WrapText()
	local realText = "";

	self.text = string.Replace(self.text, "\n", "\r\n");

	for k, v in pairs(string.Explode(" ", self.text)) do
		local scrW, scrH = ScrW(), ScrH();
		local width = 0;

		for k2, v2 in pairs(string.Explode("\n", realText)) do
			width = surface.GetTextSize(v2);
		end;

		if (width <= (scrW * .6)) then
			if (realText == "") then
				realText = realText..v;
			else
				realText = realText.." "..v;
			end;
		else
			realText = realText.."\n"..v;
		end;
	end;

	self.realText = realText;
end;

-- A function to stop the intro.
function PLUGIN:Stop()
	self.pos = nil;
	self.ready = true;
	self.soundObj:FadeOut(4);
	self.soundObj = nil;
	self.button:Remove();
	self.button = nil;
	gui.EnableScreenClicker = EnableScreenClicker;
	EnableScreenClicker = nil;

	if (Clockwork.character.panel) then
		Clockwork.character.panel:SetAlpha(255);
	end;
end;