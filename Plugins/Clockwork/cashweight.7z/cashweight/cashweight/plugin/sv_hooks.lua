
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local cwConfig = Clockwork.config;
local cwConfigGet = Clockwork.config.Get;

local math = math;
local tonumber = tonumber;

function PLUGIN:PlayerThink(player, curTime, infoTable)
	if (player:GetCash() > 10000) then
		infoTable.inventoryWeight = math.max(0,
			infoTable.inventoryWeight - (player:GetCash() - 10000) * cwConfigGet(cwConfig, "cash_weight"):Get());
	end;
end;

local NAME_CASH = Clockwork.option:GetKey("name_cash");
local storageTakeCash = "StorageTake"..string.gsub(NAME_CASH, "%s", "");
local giveCash = "Give"..string.gsub(NAME_CASH, "%s", "");

function PLUGIN:PlayerCanUseCommand(player, commandTable, arguments)
	if (commandTable.name == storageTakeCash or commandTable.name == giveCash) then
		local cash = math.floor(tonumber(arguments[1]) or 0) + player:GetCash() - 10000;
		if (cash <= 0) then
			return;
		end;

		if (commandTable.name == storageTakeCash) then
			if (!player:CanHoldWeight(math.floor(tonumber(arguments[1] or 0)) * cwConfigGet(cwConfig, "cash_weight"):Get())) then
				return false;
			end;
		elseif (commandTable.name == giveCash) then
			local target = player:GetEyeTraceNoCursor().Entity;
			
			if(!target:IsPlayer()) then
				return;
			end;
			if (!target:CanHoldWeight(cash * cwConfigGet(cwConfig, "cash_weight"):Get())) then
				return false;
			end;
		end;
	end;
end;

function PLUGIN:EntityHandleMenuOption(player, entity, option, arguments)
	if (entity:GetClass() == "cw_cash" and arguments == "cwCashTake") then
		local cash = entity:GetAmount() + player:GetCash() - 10000;
		if (cash <= 0) then
			return;
		end;
		if (!player:CanHoldWeight(cash * cwConfigGet(cwConfig, "cash_weight"):Get())) then
			return true;
		end;
	end;
end;