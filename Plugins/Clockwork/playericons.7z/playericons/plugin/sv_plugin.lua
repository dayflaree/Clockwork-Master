local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:Initialize()
	Clockwork.config:Add("donator_flag", "D", true, true);

	-- Called when a player attempts to spawn a ragdoll.
	function GAMEMODE:PlayerSpawnRagdoll(player, model)
		if (!self.player:HasFlags(player, "r")) then return false; end;
		
		if (!player:Alive() or player:IsRagdolled()) then
			self.player:Notify(player, "You cannot do this action at the moment!");
			
			return false;
		else
			return true;
		end;
	end;
end