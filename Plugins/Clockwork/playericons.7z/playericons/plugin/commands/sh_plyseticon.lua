COMMAND = Clockwork.command:New("PlySetIcon");
COMMAND.tip = "Set a player's icon. Relevant to icon16/[name].png";
COMMAND.text = "<string Name> <string Icon Path>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] );
	local icon = arguments[2]
	
	if (target) then
		target:SetSharedVar("Icon", icon)
		Clockwork.player:NotifyAll(player:Name().." has set "..target:Name().."'s icon.");
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register()