--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:ChatBoxAdjustInfo(info)
	if (IsValid(info.speaker)) then
		if (Clockwork.player:HasFlags(info.speaker, "D")) then
			if (info.speaker:GetSharedVar("Icon") == nil) or (info.speaker:GetSharedVar("Icon") == "") then
				info.icon = "icon16/heart.png";
			else
				info.icon = "icon16/"..info.speaker:GetSharedVar("Icon")..".png"
			end
		end
	end
end;