Clockwork.thirdperson = Clockwork.kernel:NewLibrary("ThirdPerson");

if (CLIENT) then
	local old_pos = EyePos()
	local old_ang = EyeAngles()

	CreateClientConVar("3p_lerpval", 5, true, false)
	CreateClientConVar("3p_headbob", 5, true, false)

	function Clockwork.thirdperson.CalcView(player, pos, ang, fov)
		local data = {};

		if (player:GetNetworkedInt("thirdperson") == 1) then
			ang = LerpAngle(math.Clamp(GetConVarNumber("3p_lerpval")/100, 0, 0.1), old_ang, ang);

			local offset = Vector(0, 0, 0);
			offset.x = 40;
			offset.y = 20;
			offset.z = 0;

			local traceData = {};
			traceData.start = pos;
			traceData.endpos = traceData.start - ang:Forward() * offset.x;
			traceData.endpos = traceData.endpos + ang:Right() * offset.y;
			traceData.endpos = traceData.endpos + ang:Up() * offset.z + Vector(0, 0, 60);
			traceData.filter = player;

			local trace = util.TraceLine(traceData);
			pos = trace.HitPos;
			if trace.Fraction < 1.0 then
				pos = pos + trace.HitNormal * 5;
			end;

			if (player:GetVelocity():DotProduct(player:GetForward()) > 200) then
				if (player:KeyDown(IN_SPEED)) then
					pos = pos + player:GetForward() * 2;
					ang.pitch = ang.pitch + math.Clamp(GetConVarNumber("3p_headbob")/100, 0, 0.1) * math.sin(CurTime()*10);
					ang.roll = ang.roll + math.Clamp(GetConVarNumber("3p_headbob")/100, 0, 0.1) * math.sin(CurTime()*10);
				end;
			end;

			data.origin = LerpVector(math.Clamp(GetConVarNumber("3p_lerpval")/100, 0, 0.1), old_pos, pos);
			data.angles = ang;
		end;

		old_pos = data.origin or EyePos();
		old_ang = data.angles or EyeAngles();
		return data;
	end;
	hook.Add("CalcView", "Clockwork.thirdperson.CalcView", Clockwork.thirdperson.CalcView);

	function Clockwork.thirdperson.HUDShouldDraw(name)
		if (LocalPlayer():GetNetworkedInt("thirdperson") == 1) then
			if (name == "CHudCrosshair") then return false; end;
		end;
	end;
	hook.Add("HUDShouldDraw", "Clockwork.thirdperson.HUDShouldDraw", Clockwork.thirdperson.HUDShouldDraw);

	function Clockwork.thirdperson.HUDPaint()
		if (LocalPlayer():GetNetworkedInt("thirdperson") == 1) then
			local trace = LocalPlayer():GetEyeTraceNoCursor();
			if !trace.Hit then return; end;

			local screen_hitpos = trace.HitPos:ToScreen();

			draw.RoundedBox(1, screen_hitpos.x-3, screen_hitpos.y-3, 6, 6, Color(0,0,0,255));
			draw.RoundedBox(1, screen_hitpos.x-2, screen_hitpos.y-2, 4, 4, Color(255, 208, 64,255));

			surface.SetDrawColor(255, 208, 64);
			surface.DrawLine(screen_hitpos.x + 7, screen_hitpos.y, screen_hitpos.x + 12, screen_hitpos.y);
			surface.DrawLine(screen_hitpos.x - 7, screen_hitpos.y, screen_hitpos.x - 12, screen_hitpos.y);
			surface.DrawLine(screen_hitpos.x, screen_hitpos.y + 7, screen_hitpos.x, screen_hitpos.y + 12);
			surface.DrawLine(screen_hitpos.x, screen_hitpos.y - 7, screen_hitpos.x, screen_hitpos.y - 12);
		end;
	end;
	hook.Add("HUDPaint", "Clockwork.thirdperson.HUDPaint", Clockwork.thirdperson.HUDPaint);
else
	function Clockwork.thirdperson.Command(player, command, arguments)
		if !(arguments[1]) then
			if player:GetNetworkedInt("thirdperson") == 1 then
				Clockwork.thirdperson.Disable(player);
			else
				Clockwork.thirdperson.Enable(player);
			end;
		else
			if (arguments[1] == "1") then
				Clockwork.thirdperson.Enable(player);
			elseif (arguments[1] == "0") then
				Clockwork.thirdperson.Disable(player);
			end;
		end;
	end;
	concommand.Add("3person", Clockwork.thirdperson.Command)

	function Clockwork.thirdperson.Disable(player)
		if player:GetNetworkedInt("thirdperson") == 0 then
			return
		end
		player:SetNetworkedInt("thirdperson", 0)

		local entity = player:GetViewEntity()
		player:SetViewEntity(player)
		entity:Remove()
	end

	function Clockwork.thirdperson.Enable(player)
		if player:GetNetworkedInt("thirdperson") == 1 then
			return
		end
		player:SetNetworkedInt("thirdperson", 1)

		local entity = ents.Create("prop_dynamic")
		entity:SetModel("models/error.mdl")
		entity:SetColor(Color(0,0,0,0))
		entity:DrawShadow(false)
		entity:Spawn()
		entity:SetAngles(player:GetAngles())
		entity:SetMoveType(MOVETYPE_NONE)
		entity:SetParent(player)
		entity:SetPos(player:GetPos())
		entity:SetRenderMode(RENDERMODE_NONE)
		entity:SetSolid(SOLID_NONE)
		player:SetViewEntity(entity)
	end
end;