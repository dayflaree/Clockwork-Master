local PLUGIN = PLUGIN;

Clockwork.setting:AddCheckBox("Third person", "Enable third person view.", "cwThirdPerson", "Toggle the third person view.");
Clockwork.setting:AddNumberSlider("Third person", "Lerp value", "cwThirdPersonLerpVal", 1, 10, 0, "Smoothing amount for the third person view. (smaller amounts = more smoothing)")
Clockwork.setting:AddNumberSlider("Third person", "Headbob amount", "cwThirdPersonHeadbob", 0, 10, 0, "The amount of headbob.")