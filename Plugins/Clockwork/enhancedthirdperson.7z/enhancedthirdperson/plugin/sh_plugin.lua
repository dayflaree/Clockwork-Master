local PLUGIN = PLUGIN;
// this plugin was made by atebite for Aphelion HL2RP, contracted by Sheeplie. it's pretty good and better than whatever trash zak and zombine can shit out.
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");