local PLUGIN = PLUGIN;

function PLUGIN:Initialize()
	CW_CONVAR_THIRDPERSON = Clockwork.kernel:CreateClientConVar("cwThirdPerson", 0, false, true);
	CW_CONVAR_THIRDPERSON_LERPVAL = Clockwork.kernel:CreateClientConVar("cwThirdPersonLerpVal", 10, false, true);
	CW_CONVAR_THIRDPERSON_HEADBOB = Clockwork.kernel:CreateClientConVar("cwThirdPersonHeadbob", 0, false, true);
end;

function PLUGIN:ClockworkConVarChanged()
	if (CW_CONVAR_THIRDPERSON:GetInt() == 1) then
		RunConsoleCommand("3person", "1");
	else
		RunConsoleCommand("3person", "0");
	end;

	RunConsoleCommand("3p_lerpval", tostring(CW_CONVAR_THIRDPERSON_LERPVAL:GetInt()));
	RunConsoleCommand("3p_headbob", tostring(CW_CONVAR_THIRDPERSON_HEADBOB:GetInt()));
end;