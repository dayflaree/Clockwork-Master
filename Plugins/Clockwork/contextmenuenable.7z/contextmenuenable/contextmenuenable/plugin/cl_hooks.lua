-- Called when the context menu attempts to be opened.
function PLUGIN:ContextMenuOpen()
	if (Clockwork.config:Get("context_menu_always"):Get()) then
		return true;
	else
		if (self.kernel:IsUsingTool()) then
			return Clockwork.BaseClass:OnContextMenuOpen(Clockwork);
		else
			gui.EnableScreenClicker(true);
			return
		end;
	end;
end;

-- Called when the context menu is opened.
function PLUGIN:OnContextMenuOpen()
	if (Clockwork.config:Get("context_menu_always"):Get()) then
		return Clockwork.BaseClass:OnContextMenuOpen(Clockwork);
	end;
end;

-- Called when the context menu is closed.
function PLUGIN:OnContextMenuClose()
	if (Clockwork.config:Get("context_menu_always"):Get()) then
		return Clockwork.BaseClass:OnContextMenuClose(Clockwork);
	end;
end;