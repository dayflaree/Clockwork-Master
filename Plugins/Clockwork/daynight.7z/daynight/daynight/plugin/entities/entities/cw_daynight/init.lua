--[[
Name: "sv_autorun.lua".
Product: "prototype".
--]]

Clockwork.kernel:IncludePrefixed("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

local PLUGIN = PLUGIN;

-- Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/weapons/w_bugbait.mdl");
	self:SetSolid(SOLID_NONE);
	self:SetNoDraw(true);
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:PhysicsInit(SOLID_BBOX);
end;

-- Called when the entity is used.
function ENT:Use(activator, caller) end;

-- Called each frame.
function ENT:Think()
	local minute = Clockwork.time:GetMinute();
	
	if (Clockwork.config:Get("daynight_enabled"):Get()) then
		if (!PLUGIN.lastMinute or minute != PLUGIN.lastMinute) then
			PLUGIN:CalculateLight();
			PLUGIN.lastMinute = minute;
		end;
	end;
end;