--[[
Name: "cl_autorun.lua".
Product: "prototype".
--]]

include("shared.lua");