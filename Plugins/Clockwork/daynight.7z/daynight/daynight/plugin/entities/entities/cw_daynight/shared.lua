--[[
Name: "sh_autorun.lua".
Product: "prototype".
--]]

ENT.Type = "anim";
ENT.Base = "base_anim"
ENT.Author = "kuromeku";
ENT.PrintName = "Day/Night";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;