--[[
Name: "sv_hooks.lua".
Product: "prototype".
--]]

local PLUGIN = PLUGIN;

-- Called when the map has loaded all the entities.
function PLUGIN:InitPostEntity()
	if ( Clockwork.config:Get("daynight_enabled"):Get() ) then
		self.lightEnvironments = ents.FindByClass("light_environment");
		self.skyOverlays = ents.FindByName("skyoverlay*");
		self.suns = ents.FindByClass("env_sun");
		
		if (self.lightEnvironments) then
			for k, v in pairs(self.lightEnvironments) do
				v:Fire("FadeToPattern", string.char(LIGHT_LOW), 0);
				v:Activate();
			end;
		end;
		
		if (self.skyOverlays) then
			for k, v in pairs(self.skyOverlays) do
				v:Fire("Enable", "", 0); v:Fire("Color", "0 0 0", 0.01);
			end;
		end;
		
		if (self.suns) then
			for k, v in pairs(self.suns) do
				v:SetKeyValue("material", "sprites/light_glow02_add_noz.vmt");
				v:SetKeyValue("overlaymaterial", "sprites/light_glow02_add_noz.vmt");
			end;
		end;
		
		self:BuildLightTable();
	end;
end;

-- Called when an entity's key value is defined.
function PLUGIN:EntityKeyValue(entity, key, value)
	if ( Clockwork.config:Get("daynight_enabled"):Get() ) then
		if ( !string.find(entity:GetClass( ) , "light") ) then
			return;
		end;
		
		self.nightLights = self.nightLights or {};
		
		if (key == "nightlight") then
			self.nightLights[#self.nightLights + 1] = entity;
			
			entity:Fire("TurnOff", "", 0);
		end;
	end;
end;