local Clockwork = Clockwork

Clockwork.blueprints = Clockwork.kernel:NewLibrary("Blueprints");
Clockwork.blueprints.stored = {}



local CLASS_TABLE = {__index = CLASS_TABLE};
CLASS_TABLE.name = "Base Blueprint"
CLASS_TABLE.skin = 0
CLASS_TABLE.model = "models/error.mdl"
CLASS_TABLE.category = "Other"
CLASS_TABLE.description = "Description."
CLASS_TABLE.required = {}
CLASS_TABLE.recipe = {}
CLASS_TABLE.finish = {}

function CLASS_TABLE:GetRequiredItems()
	return self.required
end
function CLASS_TABLE:GetMaterials()
	return self.recipe
end
function CLASS_TABLE:GetResult()
	return self.finish
end
function CLASS_TABLE:__call(varName, failSafe)
	return (self[varName] != nil and self[varName] or failSafe)
end
function CLASS_TABLE:Register()
	return Clockwork.blueprints:Register(self)
end



function Clockwork.blueprints:GetAll()
	return self.stored
end
function Clockwork.blueprints:FindByID(identifier)
	if (identifier and identifier != 0 and type(identifier) != "boolean") then
		if (self.stored[identifier]) then
			return self.stored[identifier]
		end
		
		local lowerName = string.lower(identifier)
		local bpTable = nil
		
		for k, v in pairs(self.stored) do
			local Name = v("name")
			
			if (string.find(string.lower(Name), lowerName)
			and (!bpTable or string.utf8len(Name) < string.utf8len(bpTable("name")))) then
				bpTable = v
			end
		end
		
		return bpTable
	end
end
function Clockwork.blueprints:New()
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE)
	return object
end
function Clockwork.blueprints:Register(blueprint)
	blueprint.uniqueID = string.lower(string.gsub(blueprint.uniqueID or string.gsub(blueprint.name, "%s", "_"), "['%.]", ""))
	self.stored[blueprint.uniqueID] = blueprint

	if blueprint.model then
		util.PrecacheModel(blueprint.model)
		
		if SERVER then
			Clockwork.kernel:AddFile(blueprint.model)
		end
	end
end