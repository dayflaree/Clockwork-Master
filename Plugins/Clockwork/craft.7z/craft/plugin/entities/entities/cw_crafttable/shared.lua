DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "SchwarzKruppzo"
ENT.PrintName = "Craft Table"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false

function ENT:SetupDataTables()

end