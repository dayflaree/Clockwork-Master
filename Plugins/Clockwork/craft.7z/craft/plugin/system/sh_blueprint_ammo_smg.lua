local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "SMG Ammo";
BLUEPRINT.uniqueID = "blueprint_ammo_smg"
BLUEPRINT.model = "models/items/boxmrounds.mdl";
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "A container filled with bullets and 9mm printed on the side."
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 2},
	{"gunpowder", 3},
	{"refined_metal", 2}
}
BLUEPRINT.finish = {
	{"ammo_smg1", 1}
}
BLUEPRINT:Register();