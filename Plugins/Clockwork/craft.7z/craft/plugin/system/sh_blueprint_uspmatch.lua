local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "USP Match";
BLUEPRINT.uniqueID = "blueprint_uspmatch"
BLUEPRINT.model = "models/weapons/w_uspmatch.mdl";
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "A small pistol coated in a dull grey."
BLUEPRINT.required = { 
	{"screw_driver", 1} 
}
BLUEPRINT.recipe = {
	{"broken_usp_match", 1},
	{"reclaimed_metal", 2},
	{"box_of_screws", 1}
}
BLUEPRINT.finish = {
	{"sxbase_uspmatch", 1}
}
BLUEPRINT:Register();