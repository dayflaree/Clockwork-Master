local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Flashlight";
BLUEPRINT.uniqueID = "blueprint_flashlight"
BLUEPRINT.model = "models/lagmite/lagmite.mdl";
BLUEPRINT.category = "Разное"
BLUEPRINT.description = "A ceiling light, a button has been wired on to it."
BLUEPRINT.required = { 
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"plastic", 2},
	{"scrap_metal", 1},
	{"box_of_screws", 1},
	{"energy_cell", 1},
	{"scrap_electronics", 2},
}
BLUEPRINT.finish = {
	{"flashlight", 1}
}
BLUEPRINT:Register();