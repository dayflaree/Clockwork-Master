local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Boxed Bag";
BLUEPRINT.uniqueID = "blueprint_bag"
BLUEPRINT.model = "models/props_junk/cardboard_box004a.mdl";
BLUEPRINT.category = "Хранилища"
BLUEPRINT.description = "A brown box, open it to reveal its contents."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"cloth", 1},
	{"cables", 1}
}
BLUEPRINT.finish = {
	{"boxed_bag", 1}
}
BLUEPRINT:Register();