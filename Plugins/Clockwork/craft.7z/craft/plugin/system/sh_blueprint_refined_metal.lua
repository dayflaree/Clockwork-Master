local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Refined Metal";
BLUEPRINT.uniqueID = "blueprint_refined_metal"
BLUEPRINT.model = "models/gibs/metal_gib2.mdl";
BLUEPRINT.category = "Обработка металла"
BLUEPRINT.description = "A strong and clean piece of metal."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"reclaimed_metal", 3},
}
BLUEPRINT.finish = {
	{"refined_metal", 2}
}
BLUEPRINT:Register();