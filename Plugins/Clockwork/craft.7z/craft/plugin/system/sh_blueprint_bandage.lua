local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Bandage";
BLUEPRINT.uniqueID = "blueprint_bandage"
BLUEPRINT.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
BLUEPRINT.category = "Разное"
BLUEPRINT.description = "A bandage roll, there isn't much so use it wisely."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"cloth", 1}
}
BLUEPRINT.finish = {
	{"bandage", 1}
}
BLUEPRINT:Register();