local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Boxed Backpack";
BLUEPRINT.uniqueID = "blueprint_backpack"
BLUEPRINT.model = "models/props_junk/cardboard_box004a.mdl";
BLUEPRINT.category = "Хранилища"
BLUEPRINT.description = "A brown box, open it to reveal its contents."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"scrap_metal", 1},
	{"cloth", 2},
	{"cables", 3}
}
BLUEPRINT.finish = {
	{"boxed_backpack", 1}
}
BLUEPRINT:Register();