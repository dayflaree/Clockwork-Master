local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "MP7 Mk.2";
BLUEPRINT.uniqueID = "blueprint_mp7"
BLUEPRINT.model = "models/weapons/w_smg1.mdl";
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "A compact weapon coated in a dark grey, it has a convenient handle."
BLUEPRINT.required = { 
	{"screw_driver", 1} 
}
BLUEPRINT.recipe = {
	{"broken_mp7", 1},
	{"reclaimed_metal", 2},
	{"box_of_screws", 1}
}
BLUEPRINT.finish = {
	{"sxbase_mp7", 1}
}
BLUEPRINT:Register();