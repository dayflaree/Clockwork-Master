local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Handheld Radio";
BLUEPRINT.uniqueID = "blueprint_handheld_radio"
BLUEPRINT.model = "models/deadbodies/dead_male_civilian_radio.mdl";
BLUEPRINT.category = "Разное"
BLUEPRINT.description = "A shiny handheld radio with a frequency tuner."
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"refined_electronics", 1},
	{"refined_metal", 1},
	{"scrap_metal", 1},
	{"energy_cell", 1}
}
BLUEPRINT.finish = {
	{"handheld_radio", 1}
}
BLUEPRINT:Register();