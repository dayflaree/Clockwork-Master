local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Plastic";
BLUEPRINT.uniqueID = "blueprint_plastic"
BLUEPRINT.model = "models/props_debris/metal_panelshard01b.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A sheet of plastic."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_plastic_can", 5},
}
BLUEPRINT.finish = {
	{"plastic", 1}
}
BLUEPRINT:Register();