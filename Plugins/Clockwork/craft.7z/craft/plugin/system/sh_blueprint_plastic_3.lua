local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Plastic";
BLUEPRINT.uniqueID = "blueprint_plastic_3"
BLUEPRINT.model = "models/props_debris/metal_panelshard01b.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A sheet of plastic."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_jug", 4},
}
BLUEPRINT.finish = {
	{"plastic", 1}
}
BLUEPRINT:Register();
local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Plastic";
BLUEPRINT.uniqueID = "blueprint_plastic_4"
BLUEPRINT.model = "models/props_debris/metal_panelshard01b.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A sheet of plastic."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"ration_package", 4},
}
BLUEPRINT.finish = {
	{"plastic", 1}
}
BLUEPRINT:Register();