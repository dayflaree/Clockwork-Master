local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Reclaimed Metal";
BLUEPRINT.uniqueID = "blueprint_reclaimed_metal"
BLUEPRINT.model = "models/props_lab/pipesystem03a.mdl";
BLUEPRINT.category = "Обработка металла"
BLUEPRINT.description = "A sturdy and tough piece of metal."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"scrap_metal", 3},
}
BLUEPRINT.finish = {
	{"reclaimed_metal", 1}
}
BLUEPRINT:Register();