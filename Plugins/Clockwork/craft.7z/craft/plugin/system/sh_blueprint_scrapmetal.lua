local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Scrap Metal";
BLUEPRINT.uniqueID = "blueprint_scrapmetal"
BLUEPRINT.model = "models/props_debris/metal_panelchunk02d.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A bent and dirty piece of metal."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_can", 5},
}
BLUEPRINT.finish = {
	{"scrap_metal", 1}
}
BLUEPRINT:Register();

local BLUEPRINT = Clockwork.blueprints:New()
BLUEPRINT.name = "Scrap Metal";
BLUEPRINT.uniqueID = "blueprint_scrapmetal_3"
BLUEPRINT.model = "models/props_debris/metal_panelchunk02d.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A bent and dirty piece of metal."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"ration_package", 5},
}
BLUEPRINT.finish = {
	{"scrap_metal", 1}
}
BLUEPRINT:Register();