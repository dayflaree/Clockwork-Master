local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "9mm Pistol Bullets";
BLUEPRINT.uniqueID = "blueprint_ammo_pistol"
BLUEPRINT.model = "models/items/boxsrounds.mdl";
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "A container filled with bullets and 9mm printed on the side."
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 2},
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"ammo_pistol", 1}
}
BLUEPRINT:Register();