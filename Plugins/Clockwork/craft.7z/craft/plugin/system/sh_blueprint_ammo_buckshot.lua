local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Shotgun Shells";
BLUEPRINT.uniqueID = "blueprint_ammo_buckshot"
BLUEPRINT.model = "models/items/boxbuckshot.mdl";
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "A red box filled with shells."
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 1},
	{"scrap_metal", 1},
	{"plastic", 1}
}
BLUEPRINT.finish = {
	{"ammo_buckshot", 1}
}
BLUEPRINT:Register();