local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Zip Tie";
BLUEPRINT.uniqueID = "blueprint_zip_tie"
BLUEPRINT.model = "models/items/crossbowrounds.mdl";
BLUEPRINT.category = "Разное"
BLUEPRINT.description = "A self made zip tie."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"cables", 1},
}
BLUEPRINT.finish = {
	{"zip_tie", 1}
}
BLUEPRINT:Register();