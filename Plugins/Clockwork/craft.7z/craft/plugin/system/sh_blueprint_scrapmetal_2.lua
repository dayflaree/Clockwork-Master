local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Scrap Metal";
BLUEPRINT.uniqueID = "blueprint_scrapmetal_2"
BLUEPRINT.model = "models/props_debris/metal_panelchunk02d.mdl";
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "A bent and dirty piece of metal."
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_can", 1},
	{"empty_tin_can", 3},
}
BLUEPRINT.finish = {
	{"scrap_metal", 1}
}
BLUEPRINT:Register();