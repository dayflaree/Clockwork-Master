local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Crowbar";
BLUEPRINT.uniqueID = "blueprint_crowbar"
BLUEPRINT.model = "models/weapons/w_crowbar.mdl";
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "A worn red crowbar."
BLUEPRINT.required = { 
	{"screw_driver", 1},
	{"wrench", 1}
}
BLUEPRINT.recipe = {
	{"reclaimed_metal", 2},
	{"refined_metal", 2},
	{"box_of_screws", 2}
}
BLUEPRINT.finish = {
	{"sxbase_crowbar", 1}
}
BLUEPRINT:Register();