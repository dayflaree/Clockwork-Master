local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Breach";
BLUEPRINT.uniqueID = "blueprint_breach"
BLUEPRINT.model = "models/props_wasteland/prison_padlock001a.mdl";
BLUEPRINT.category = "Взрывчатка"
BLUEPRINT.description = "A small device which looks similiar to a padlock.."
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"gunpowder", 3},
	{"cables", 1},
	{"refined_electronics", 1},
	{"energy_cell", 1},
	{"cloth", 1},
}
BLUEPRINT.finish = {
	{"breach", 2}
}
BLUEPRINT:Register();