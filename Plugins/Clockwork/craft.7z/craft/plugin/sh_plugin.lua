local PLUGIN = PLUGIN

local langEn = Clockwork.lang:GetTable("en")
local langRu = Clockwork.lang:GetTable("ru")
langEn["#CATEGORY_Mat"] = "Materials"
langRu["#CATEGORY_Mat"] = "Материалы"
langEn["#CATEGORY_Tools"] = "Tools"
langRu["#CATEGORY_Tools"] = "Инструменты"


function PLUGIN:PlayerCanCraft( player, bpTable ) return true end
function PLUGIN:PlayerHasCraftMaterials( player, bpTable )
	local inventory = nil
	if CLIENT then 
		inventory = Clockwork.inventory:GetClient()
	else
		inventory = player:GetInventory()
	end

	if !bpTable then return false end

	local required = bpTable("required")
	local recipe = bpTable("recipe")
	local stored_recipe = {}

	if table.Count( recipe ) > 0 then
		for k, v in pairs( recipe ) do
			stored_recipe[#stored_recipe + 1] = { v[1], v[2] }
		end
	end
	if table.Count( required ) > 0 then
		for k, v in pairs( required ) do
			stored_recipe[#stored_recipe + 1] = { v[1], v[2] }
		end
	end

	local stored = {}
	for k, v in pairs( stored_recipe ) do
		for z, x in pairs( inventory ) do
			if z == v[1] then
				for z2, x2 in pairs( x ) do
					if !stored[z] then 
						stored[z] = 1
					else
						stored[z] = stored[z] + 1
					end
				end
			end
		end
	end

	if table.Count( stored ) == 0 then return false end

	local err = false
	local check = true
	while !err and check do
		for k, v in pairs( stored_recipe ) do
			for z, x in pairs( stored ) do
				if !stored[v[1]] then
					err = true
				else
					if stored[v[1]] < v[2] then
						err = true
					end
				end
			end
			if k == #stored_recipe then
				check = false
			end
		end
	end

	return !err
end

if SERVER then
	function PLUGIN:PlayerCraftItem( player, bpTable, entity )
		local inventory = player:GetInventory()
		if !bpTable then return false end

		local recipe = bpTable("recipe")
		local result = bpTable("finish")

		if table.Count( recipe ) > 0 then
			for k, v in pairs( recipe ) do
				for i = 1, v[2] do
					if !player:TakeItemByID( v[1] ) then
						return
					end
				end
			end
		end

		if table.Count( result ) > 0 then
			for k, v in pairs( result ) do
				for i = 1, v[2] do
					if !player:GiveItem( v[1] ) then
						if IsValid( entity ) then
							if entity.GetCraftPos then
								Clockwork.entity:CreateItem( nil, v[1], entity:GetCraftPos(), Angle( 0, 0, 0 ) )
							end
						end
					end
				end
			end
		end

		Clockwork.player:Notify( player, "Вы создали: " .. bpTable("name") )
	end


	function PLUGIN:SaveCraftTables()
		local craftT = {}
		for k, v in pairs( ents.FindByClass("cw_crafttable") ) do
			craftT[#craftT + 1] = {
				angles = v:GetAngles(),
				position = v:GetPos(),
			}
		end
		Clockwork.kernel:SaveSchemaData("plugins/craft/"..game.GetMap(), craftT)
	end
	function PLUGIN:LoadCraftTables()
		local craftT = Clockwork.kernel:RestoreSchemaData( "plugins/craft/"..game.GetMap() )
		for k, v in pairs(craftT) do
			local device = ents.Create("cw_crafttable")
				
			if device then
				device:SetPos(v.position)
				device:SetAngles(v.angles)
				device:Spawn()
				device:GetPhysicsObject():EnableMotion(false)
			end
		end
	end

	function PLUGIN:ClockworkInitPostEntity()
		self:LoadCraftTables()
	end
	function PLUGIN:PostSaveData()
		self:SaveCraftTables()
	end
end