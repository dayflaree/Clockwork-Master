local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("CraftItem")
COMMAND.tip = "Craft an blueprint."
COMMAND.text = "<string Blueprint UniqueID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local bpTable = Clockwork.blueprints:FindByID(arguments[1])
	
	if !bpTable then
		return false
	end

	if !player.activeCraftTable then
		Clockwork.player:Notify(player, "Вы не используете верстак!")
		return false
	elseif IsValid( player.activeCraftTable ) then
		if player:GetPos():Distance( player.activeCraftTable:GetPos() ) > 70 then
			Clockwork.player:Notify(player, "Вы не используете верстак!")
			return false
		end
	end
	
	bpTable = table.Copy( Clockwork.blueprints:FindByID(arguments[1]) )

	if player.cwNextCraftTime and CurTime() < player.cwNextCraftTime then
		return false
	end
	if !PLUGIN:PlayerCanCraft( player, bpTable ) then
		return false
	end

	if PLUGIN:PlayerHasCraftMaterials( player, bpTable ) then
		Clockwork.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." has crafted a "..bpTable("name")..".");

		if bpTable.OnCraft then
			bpTable:OnCraft( player, bpTable )
		end
		
		PLUGIN:PlayerCraftItem( player, bpTable, player.activeCraftTable )
		player.activeCraftTable:EmitSound("plats/elevator_stop.wav")
		player.cwNextCraftTime = CurTime() + 2
			
		Clockwork.datastream:Start( player, "CraftTime", player.cwNextCraftTime )
	else
		Clockwork.player:Notify(player, "У вас нет необходимых вещей!")
	end
end

COMMAND:Register()