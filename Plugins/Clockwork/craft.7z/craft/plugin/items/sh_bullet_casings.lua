local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_BCasings"] = "Bullet Casings";
langEn["#ITEM_BCasings_Desc"] = "A box with various bullet casings.";
langRu["#ITEM_BCasings"] = "Коробка гильз";
langRu["#ITEM_BCasings_Desc"] = "Коробка с различными гильзами для пуль.";

local ITEM = Clockwork.item:New();
ITEM.name = "Bullet Casings";
ITEM.PrintName = "#ITEM_BCasings"
ITEM.model = "models/items/ammobox.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_BCasings_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();