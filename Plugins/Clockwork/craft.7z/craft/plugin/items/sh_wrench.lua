local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CWrench"] = "Wrench";
langEn["#ITEM_CWrench_Desc"] = "A tool useful for tightening bolts.";
langRu["#ITEM_CWrench"] = "Гаечный ключ";
langRu["#ITEM_CWrench_Desc"] = "Простой гаечный ключ.";

local ITEM = Clockwork.item:New();
ITEM.name = "Wrench";
ITEM.PrintName = "#ITEM_CWrench"
ITEM.model = "models/props_c17/tools_wrench01a.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Tools";
ITEM.description = "#ITEM_CWrench_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();