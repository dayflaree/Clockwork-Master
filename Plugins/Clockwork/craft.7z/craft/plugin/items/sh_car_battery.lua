local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CCarBat"] = "Car Battery";
langEn["#ITEM_CCarBat_Desc"] = "A battery that used to be in a car.";
langRu["#ITEM_CCarBat"] = "Автомобильная батарея";
langRu["#ITEM_CCarBat_Desc"] = "Батарея, которая когда-то была в машине.";

local ITEM = Clockwork.item:New();
ITEM.name = "Car Battery";
ITEM.PrintName = "#ITEM_CCarBat"
ITEM.model = "models/items/car_battery01.mdl";
ITEM.weight = 0.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CCarBat_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();