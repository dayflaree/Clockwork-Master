local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CEnCell"] = "Energy Cell";
langEn["#ITEM_CEnCell_Desc"] = "A blue battery full of electricity.";
langRu["#ITEM_CEnCell"] = "Батарея";
langRu["#ITEM_CEnCell_Desc"] = "Синяя батарея, полная электричества.";

local ITEM = Clockwork.item:New();
ITEM.name = "Energy Cell";
ITEM.PrintName = "#ITEM_CEnCell"
ITEM.model = "models/items/battery.mdl";
ITEM.weight = 0.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CEnCell_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();