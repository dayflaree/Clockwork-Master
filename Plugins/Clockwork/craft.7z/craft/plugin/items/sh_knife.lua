local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CKnife"] = "Cutting Knife";
langEn["#ITEM_CKnife_Desc"] = "A knife that has a sharp edge.";
langRu["#ITEM_CKnife"] = "Нож";
langRu["#ITEM_CKnife_Desc"] = "Нож с острым лезвием.";

local ITEM = Clockwork.item:New();
ITEM.name = "Cutting Knife";
ITEM.PrintName = "#ITEM_CKnife"
ITEM.model = "models/weapons/w_knife_ct.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Tools";
ITEM.description = "#ITEM_CKnife_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();