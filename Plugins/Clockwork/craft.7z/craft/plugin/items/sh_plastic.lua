local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CPlastic"] = "Plastic";
langEn["#ITEM_CPlastic_Desc"] = "A sheet of plastic.";
langRu["#ITEM_CPlastic"] = "Пластик";
langRu["#ITEM_CPlastic_Desc"] = "Лист из пластика.";

local ITEM = Clockwork.item:New();
ITEM.name = "Plastic";
ITEM.PrintName = "#ITEM_CPlastic"
ITEM.model = "models/props_debris/metal_panelshard01b.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CPlastic_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();