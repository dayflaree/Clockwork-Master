local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CRElectro"] = "Refined Electronics";
langEn["#ITEM_CRElectro_Desc"] = "An item full of useful electrical parts.";
langRu["#ITEM_CRElectro"] = "Электроника";
langRu["#ITEM_CRElectro_Desc"] = "Предмет, полный полезных электрических деталей.";

local ITEM = Clockwork.item:New();
ITEM.name = "Refined Electronics";
ITEM.PrintName = "#ITEM_CRElectro"
ITEM.model = "models/props_lab/reciever01b.mdl";
ITEM.weight = 0.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CRElectro_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();