local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CBoScrew"] = "Box of Screws";
langEn["#ITEM_CBoScrew_Desc"] = "A small box full of various screws.";
langRu["#ITEM_CBoScrew"] = "Коробка болтов";
langRu["#ITEM_CBoScrew_Desc"] = "Маленькая коробка, полная различными болтами.";

local ITEM = Clockwork.item:New();

ITEM.name = "Box of Screws";
ITEM.PrintName = "#ITEM_CBoScrew"
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CBoScrew_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();