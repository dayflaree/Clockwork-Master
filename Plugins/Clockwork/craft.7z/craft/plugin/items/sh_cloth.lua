local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CCloth"] = "Cloth";
langEn["#ITEM_CCloth_Desc"] = "A torn fabric that's in a rough square shape.";
langRu["#ITEM_CCloth"] = "Лоскуты";
langRu["#ITEM_CCloth_Desc"] = "Разорванная ткань с грубой квадратной формой.";

local ITEM = Clockwork.item:New();
ITEM.name = "Cloth";
ITEM.PrintName = "#ITEM_CCloth"
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
ITEM.weight = 0.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CCloth_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();