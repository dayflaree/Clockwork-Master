local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_BUSP"] = "Broken USP Match";
langEn["#ITEM_BUSP_Desc"] = "A small pistol coated in a dull grey. It's broken.";
langRu["#ITEM_BUSP"] = "Сломанный USP Match";
langRu["#ITEM_BUSP_Desc"] = "Маленький пистолет, покрашенный в тускло-серый цвет. Он сломан.";

local ITEM = Clockwork.item:New();
ITEM.name = "Broken USP Match";
ITEM.PrintName = "#ITEM_BUSP"
ITEM.model = "models/weapons/w_uspmatch.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_BUSP_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();