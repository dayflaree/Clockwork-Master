local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_B357"] = "Broken .357 Magnum";
langEn["#ITEM_B357_Desc"] = "A small pistol, the coated silver is rusting away.";
langRu["#ITEM_B357"] = "Сломанный .357 Магнум";
langRu["#ITEM_B357_Desc"] = "Сломанный шестизарядный револьвер, покрытое серебро ржавеет.";

local ITEM = Clockwork.item:New();
ITEM.name = "Broken 357 Magnum";
ITEM.PrintName = "#ITEM_B357"
ITEM.model = "models/weapons/w_357.mdl";
ITEM.weight = 2;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_B357_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();