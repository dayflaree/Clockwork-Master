local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CRock"] = "Rock";
langEn["#ITEM_CRock_Desc"] = "A solid piece of stone that useful for hitting things.";
langRu["#ITEM_CRock"] = "Камень";
langRu["#ITEM_CRock_Desc"] = "Твердый кусок камня, который полезен для удара вещей.";

local ITEM = Clockwork.item:New();
ITEM.name = "Rock";
ITEM.PrintName = "#ITEM_CRock"
ITEM.model = "models/props_junk/rock001a.mdl";
ITEM.weight = 4;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CRock_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();