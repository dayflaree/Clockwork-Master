local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CScrewDriver"] = "Screwdriver";
langEn["#ITEM_CScrewDriver_Desc"] = "A tool useful for tightening screws.";
langRu["#ITEM_CScrewDriver"] = "Отвертка";
langRu["#ITEM_CScrewDriver_Desc"] = "Простая отвертка.";

local ITEM = Clockwork.item:New();
ITEM.name = "Screw Driver";
ITEM.PrintName = "#ITEM_CScrewDriver"
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
ITEM.weight = 0.6;
ITEM.category = "#CATEGORY_Tools";
ITEM.description = "#ITEM_CScrewDriver_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();