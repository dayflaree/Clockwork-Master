local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CRRMetal"] = "Refined Metal";
langEn["#ITEM_CRRMetal_Desc"] = "A strong and clean piece of metal.";
langRu["#ITEM_CRRMetal"] = "Переработанный металл";
langRu["#ITEM_CRRMetal_Desc"] = "Прочный и чистый кусок металла.";

local ITEM = Clockwork.item:New();
ITEM.name = "Refined Metal";
ITEM.PrintName = "#ITEM_CRRMetal"
ITEM.model = "models/gibs/metal_gib2.mdl";
ITEM.weight = 2;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CRRMetal_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();