local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_BCables"] = "Cables";
langEn["#ITEM_BCables_Desc"] = "A small bundle of various cables.";
langRu["#ITEM_BCables"] = "Кабели";
langRu["#ITEM_BCables_Desc"] = "Маленький моток различных кабелей.";

local ITEM = Clockwork.item:New();
ITEM.name = "Cables";
ITEM.PrintName = "#ITEM_BCables"
ITEM.model = "models/Items/CrossbowRounds.mdl";
ITEM.weight = 0.2;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_BCables_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
