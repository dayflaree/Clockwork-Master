local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_BMP7"] = "Broken MP7";
langEn["#ITEM_BMP7_Desc"] = "A compact weapon coated in a dark grey, it has a convenient handle. It's broken.";
langRu["#ITEM_BMP7"] = "Сломанный МП7";
langRu["#ITEM_BMP7_Desc"] = "Компактное оружие, покрашенное в темно-серый цвет. Имеется удобная ручка. Оружие сломано.";

local ITEM = Clockwork.item:New();
ITEM.name = "Broken MP7";
ITEM.PrintName = "#ITEM_BMP7"
ITEM.model = "models/weapons/w_smg1.mdl";
ITEM.weight = 2.5;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_BMP7_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();