local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CGunPowder"] = "Gunpowder";
langEn["#ITEM_CGunPowder_Desc"] = "A small box with a fine black powder.";
langRu["#ITEM_CGunPowder"] = "Порох";
langRu["#ITEM_CGunPowder_Desc"] = "Маленькая коробка с мелким черным порохом.";

local ITEM = Clockwork.item:New();
ITEM.name = "Gunpowder";
ITEM.PrintName = "#ITEM_CGunPowder"
ITEM.model = "models/props_lab/box01a.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CGunPowder_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();