local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CSElectro"] = "Scrap Electronics";
langEn["#ITEM_CSElectro_Desc"] = "An item full of mangled electrical parts.";
langRu["#ITEM_CSElectro"] = "Старая электроника";
langRu["#ITEM_CSElectro_Desc"] = "Предмет, полный сломанных электрических частей.";

local ITEM = Clockwork.item:New();
ITEM.name = "Scrap Electronics";
ITEM.PrintName = "#ITEM_CSElectro"
ITEM.model = "models/props_lab/reciever01d.mdl";
ITEM.weight = 0.4;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CSElectro_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();