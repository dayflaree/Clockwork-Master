local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CNewspaper"] = "Newspaper";
langEn["#ITEM_CNewspaper_Desc"] = "A worn out newspaper. Some words are still readable.";
langRu["#ITEM_CNewspaper"] = "Газета";
langRu["#ITEM_CNewspaper_Desc"] = "Грязная газета. Некоторые слова по-прежнему читаемы.";

local ITEM = Clockwork.item:New();
ITEM.name = "Newspaper";
ITEM.PrintName = "#ITEM_CNewspaper"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl";
ITEM.weight = 0.4;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CNewspaper_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();