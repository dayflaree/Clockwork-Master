local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CSMetal"] = "Scrap Metal";
langEn["#ITEM_CSMetal_Desc"] = "A bent and dirty piece of metal.";
langRu["#ITEM_CSMetal"] = "Металлолом";
langRu["#ITEM_CSMetal_Desc"] = "Изогнутый и грязный кусок металла.";

local ITEM = Clockwork.item:New();
ITEM.name = "Scrap Metal";
ITEM.PrintName = "#ITEM_CSMetal"
ITEM.model = "models/props_debris/metal_panelchunk02d.mdl";
ITEM.weight = 0.8;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CSMetal_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();