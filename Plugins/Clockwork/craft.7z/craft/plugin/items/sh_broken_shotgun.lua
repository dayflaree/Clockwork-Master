local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_BShotgun"] = "Broken Shotgun";
langEn["#ITEM_BShotgun_Desc"] = "A moderately sized weapon coated in a dull grey. It's broken.";
langRu["#ITEM_BShotgun"] = "Сломанный дробовик";
langRu["#ITEM_BShotgun_Desc"] = "Оружие умеренного размера, покрашенное в тускло-серый цвет. Оно сломано.";

local ITEM = Clockwork.item:New();
ITEM.name = "Broken Shotgun";
ITEM.PrintName = "#ITEM_BShotgun"
ITEM.model = "models/weapons/w_shotgun.mdl";
ITEM.weight = 4;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_BShotgun_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();