local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_Bottle"] = "Bottle";
langEn["#ITEM_Bottle_Desc"] = "A round glass bottle";
langRu["#ITEM_Bottle"] = "Бутылка";
langRu["#ITEM_Bottle_Desc"] = "Стеклянная бутылка.";

local ITEM = Clockwork.item:New();
ITEM.name = "Bottle";
ITEM.PrintName = "#ITEM_Bottle"
ITEM.model = "models/props_junk/GlassBottle01a.mdl";
ITEM.weight = 0.2;
ITEM.junkType = 0
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_Bottle_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
