local langEn = Clockwork.lang:GetTable("en");
local langRu = Clockwork.lang:GetTable("ru");
langEn["#ITEM_CRMetal"] = "Reclaimed Metal";
langEn["#ITEM_CRMetal_Desc"] = "A sturdy and tough piece of metal.";
langRu["#ITEM_CRMetal"] = "Восстановленный металл";
langRu["#ITEM_CRMetal_Desc"] = "Прочный и жесткий кусок металла.";

local ITEM = Clockwork.item:New();
ITEM.name = "Reclaimed Metal";
ITEM.PrintName = "#ITEM_CRMetal"
ITEM.model = "models/props_lab/pipesystem03a.mdl";
ITEM.weight = 1;
ITEM.category = "#CATEGORY_Mat";
ITEM.description = "#ITEM_CRMetal_Desc";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();