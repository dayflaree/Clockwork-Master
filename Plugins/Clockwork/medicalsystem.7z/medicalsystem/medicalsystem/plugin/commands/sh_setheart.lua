local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("charSetHeart");
COMMAND.tip = "Set a player's Heart Beat.";
COMMAND.text = "<string Name> <number Amount>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] )
	local amount = arguments[2];
	
	if (!amount) then
		amount = 100;
	end;
	
		if (target) then
			target:SetCharacterData( "heart", amount )
			if ( player != target )	then
				Clockwork.player:Notify(target, player:Name().." has set your heartbeat to "..amount.." BpM.");
				Clockwork.player:Notify(player, "You have set "..target:Name().."'s heartbeat to "..amount.." BpM.");
			else
				Clockwork.player:Notify(player, "You have set your own heartbeat to "..amount.." BpM.");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
		end;
end;

COMMAND:Register();