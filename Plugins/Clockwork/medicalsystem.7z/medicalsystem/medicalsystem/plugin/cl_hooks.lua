local PLUGIN = PLUGIN;

-- Called when the F1 Text is needed.
function PLUGIN:GetPlayerInfoText(playerInfoText)
	local heart = tonumber(Clockwork.Client:GetSharedVar("heart"));
	
	if (!self.heart) then
		self.heart = heart;
	else
		self.heart = math.Approach(self.heart, heart, 1);
	end;

	if (heart > -1) then
		playerInfoText:Add("HEART", "Heart Rate: "..self.heart.." BpM");
	end;
end;

-- Handles Bars
function PLUGIN:GetBars(bars)
	local blood = Clockwork.Client:GetSharedVar("blood");
	local oxygen = Clockwork.Client:GetSharedVar("oxygen");
	
	if (!self.blood) then
		self.blood = blood;
	else
		self.blood = math.Approach(self.blood, blood, 1);
	end;
	
	if (!self.oxygen) then
		self.oxygen = oxygen;
	else
		self.oxygen = math.Approach(self.oxygen, oxygen, 1);
	end;
	
	local bText,bColor = "Blood Level", Color(255,255,255,255);
	local o2Text, o2Color = "Oxygen Level", Color(255,255,255,255);
	
	if ( blood >= 95 ) then
		bColor = Color(225,0,0,255); -- Bright Red
	elseif( blood >= 80 ) then
		bColor = Color(200,0,0,255); -- Darker Red
	elseif( blood >= 70 ) then
		bColor = Color(180,0,0,255);
	elseif( blood >= 60 ) then
		bColor = Color(165,0,0,255);
	elseif( blood >= 50 ) then
		bColor = Color(155,0,0,255); -- Dark Red
	end;
	
	if ( oxygen >= 95  ) then
		o2Color = Color(0,0,255,255); -- Blue
	elseif( oxygen >= 80 ) then
		o2Color = Color(0,0,200,255); -- Dark Blue
	elseif( oxygen >= 70 ) then
		o2Color = Color(0,0,180,255); -- Dark Blue
	elseif( oxygen >= 60 ) then
		o2Color = Color(0,0,165,255);
	elseif( oxygen >= 50 ) then
		o2Color = Color(0,0,155,255);
	end;
	if (self.blood < 75) then
		Clockwork.bars:Add("BLOOD", bColor, bText, self.blood, 100, self.blood < 10);
	end;
	
	if (self.oxygen < 75) then
		Clockwork.bars:Add("OXYGEN", o2Color, o2Text, self.oxygen, 100, self.oxygen < 10);
	end;

end;

-- Called when the local player's colorify should be adjusted.
function PLUGIN:PlayerAdjustColorModify(colorModify)
	local blood = Clockwork.Client:GetSharedVar("blood");
	local frameTime = FrameTime();
	local interval = FrameTime() / 10;
	local curTime = CurTime();
	
	if (!self.colorModify) then
		self.colorModify = {
			brightness = colorModify["$pp_colour_brightness"],
			contrast = colorModify["$pp_colour_contrast"],
			color = colorModify["$pp_colour_colour"]
		};
	end;
	
	if (blood <= 20) then
		self.colorModify.brightness = math.Approach(self.colorModify.brightness, -0.08,interval);
		self.colorModify.contrast = math.Approach(self.colorModify.contrast, 0.65, interval);
		self.colorModify.color = math.Approach(self.colorModify.color, 0.24, interval);
	else
		self.colorModify.brightness = math.Approach(self.colorModify.brightness, colorModify["$pp_colour_brightness"], interval);
		self.colorModify.contrast = math.Approach(self.colorModify.contrast, colorModify["$pp_colour_contrast"], interval);
		self.colorModify.color = math.Approach(self.colorModify.color, colorModify["$pp_colour_colour"], interval);
	end;
	
	colorModify["$pp_colour_brightness"] = self.colorModify.brightness;
	colorModify["$pp_colour_contrast"] = self.colorModify.contrast;
	colorModify["$pp_colour_colour"] = self.colorModify.color;
end;