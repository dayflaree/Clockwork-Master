--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

if (SERVER) then
	AddCSLuaFile("shared.lua");
	
	SWEP.ActivityTranslate = {
		[ACT_HL2MP_GESTURE_RANGE_ATTACK] = ACT_HL2MP_GESTURE_RANGE_ATTACK_FIST,
		[ACT_HL2MP_GESTURE_RELOAD] = ACT_HL2MP_GESTURE_RELOAD_FIST,
		[ACT_HL2MP_WALK_CROUCH] = ACT_HL2MP_WALK_CROUCH_FIST,
		[ACT_HL2MP_IDLE_CROUCH] = ACT_HL2MP_IDLE_CROUCH_FIST,
		[ACT_RANGE_ATTACK1] = ACT_RANGE_ATTACK1,
		[ACT_HL2MP_IDLE] = ACT_HL2MP_IDLE_FIST,
		[ACT_HL2MP_WALK] = ACT_HL2MP_WALK_FIST,
		[ACT_HL2MP_JUMP] = ACT_HL2MP_JUMP_FIST,
		[ACT_HL2MP_RUN] = ACT_HL2MP_RUN_FIST
	};
end;

if (CLIENT) then
	SWEP.Slot = 5;
	SWEP.SlotPos = 2;
	SWEP.DrawAmmo = false;
	SWEP.PrintName = "Defibulator";
	SWEP.DrawCrosshair = true;
end

SWEP.Instructions = "Primary Fire: Apply an electric Shock to the Patient.";
SWEP.Contact = "";
SWEP.Purpose = "Restarting a heart.";
SWEP.Author	= "Arbiter";

SWEP.WorldModel = "models/weapons/w_fists_t.mdl";
SWEP.ViewModel = "models/weapons/v_punch.mdl";
SWEP.HoldType = "fist";

SWEP.AdminSpawnable = false;
SWEP.Spawnable = false;
  
SWEP.Primary.DefaultClip = 0;
SWEP.Primary.Automatic = true;
SWEP.Primary.ClipSize = -1;
SWEP.Primary.Damage = 1;
SWEP.Primary.Ammo = "";

SWEP.Secondary.DefaultClip = 0;
SWEP.Secondary.Automatic = false;
SWEP.Secondary.ClipSize = -1;
SWEP.Secondary.Ammo	= "";

SWEP.NoIronSightFovChange = true;
SWEP.NoIronSightAttack = true;
SWEP.LoweredAngles = Angle(60, 60, 60);
SWEP.IronSightPos = Vector(0, 0, 0);
SWEP.IronSightAng = Vector(0, 0, 0);
SWEP.NeverRaised = true;

-- Called when the SWEP is deployed.
function SWEP:Deploy()
	self:SendWeaponAnim(ACT_VM_DRAW);
end;

-- Called when the SWEP is holstered.
function SWEP:Holster(switchingTo)
	self:SendWeaponAnim(ACT_VM_HOLSTER);
	return true;
end;

-- Called when the player attempts to primary fire.
function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + 1);
	
	if (SERVER) then
		local action = Clockwork.player:GetAction(self.Owner);
		local trace = self.Owner:GetEyeTraceNoCursor();
		local player = Clockwork.entity:GetPlayer(trace.Entity);
		local activeWeapon = self.Owner:GetActiveWeapon();
		local itemTable = Clockwork.item:GetByWeapon(activeWeapon);
		local battery = itemTable:GetData("Battery");	
			
		if (self.Owner:GetPos():Distance(trace.HitPos) > 192
		or !IsValid(trace.Entity)) then
			return;
		end;
		
		if player then
			if player:Alive() then
				if ( battery != 0 ) then
					if player:GetSharedVar("cardiacArrest") == 1 then
						player:SetSharedVar("cardiacArrest", 0);
						player:SetCharacterData("heart", 45);
						self.Owner:EmitSound("npc/roller/mine/rmine_shockvehicle1.wav")
						itemTable:SetData("Battery", tonumber(battery) - 10);
						
						if battery <= 20 then
							self.Owner:EmitSound("npc/roller/mine/rmine_blip1.wav")
							Clockwork.player:Notify(self.Owner, "Alert, Battery charge reaching Critical Low.");
						end;
					else
						player:SetSharedVar("cardiacArrest", 1);
						self.Owner:EmitSound("npc/roller/mine/rmine_shockvehicle1.wav")
						itemTable:SetData("Battery", tonumber(battery) - 10);
						
						if battery <= 20 then
							self.Owner:EmitSound("npc/roller/mine/rmine_blip1.wav")
							Clockwork.player:Notify(self.Owner, "Alert, Battery charge reaching Critical Low.");
						end;
					end;
				else
					self.Owner:EmitSound("npc/roller/mine/rmine_tossed1.wav")
					Clockwork.player:Notify(self.Owner, "Warning! Battery Drained.");
				end;
			elseif !player:Alive() then
				if ( battery != 0 ) then
					local position = Clockwork.entity:GetPelvisPosition(trace.Entity);
					trace.Entity:Remove();
					player:Spawn();
					--[[
					player:SetPos(pos)
					player:SetAngles(angs)
					player:SetEyeAngles(eyeAngs)
					--]]
					player:SetCharacterData("heart", 45);
					player:SetCharacterData("oxygen", 25);
					self.Owner:EmitSound("npc/roller/mine/rmine_shockvehicle1.wav")
					Clockwork.datastream:Start(player, "Flahsed");
					Clockwork.player:SetSafePosition(player, position);
					itemTable:SetData("Battery", tonumber(battery) - 10);
							
					if battery <= 20 then
						self.Owner:EmitSound("npc/roller/mine/rmine_blip1.wav")
						Clockwork.player:Notify(self.Owner, "Alert, Battery charge reaching Critical Low.");
					end;
				else
					self.Owner:EmitSound("npc/roller/mine/rmine_tossed1.wav")
					Clockwork.player:Notify(self.Owner, "Warning! Battery Drained.");
				end;
			end;
		else
			self.Owner:EmitSound("npc/roller/mine/rmine_tossed1.wav")
			Clockwork.player:Notify(self.Owner, "This is not a valid Target!");
		end;
	end;
end;

-- Called when the player attempts to secondary fire.
function SWEP:SecondaryAttack() end;