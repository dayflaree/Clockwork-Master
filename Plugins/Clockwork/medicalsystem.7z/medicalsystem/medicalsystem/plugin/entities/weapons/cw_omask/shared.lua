--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

if (SERVER) then
	AddCSLuaFile("shared.lua");
	
	SWEP.ActivityTranslate = {
		[ACT_HL2MP_GESTURE_RANGE_ATTACK] = ACT_HL2MP_GESTURE_RANGE_ATTACK_FIST,
		[ACT_HL2MP_GESTURE_RELOAD] = ACT_HL2MP_GESTURE_RELOAD_FIST,
		[ACT_HL2MP_WALK_CROUCH] = ACT_HL2MP_WALK_CROUCH_FIST,
		[ACT_HL2MP_IDLE_CROUCH] = ACT_HL2MP_IDLE_CROUCH_FIST,
		[ACT_RANGE_ATTACK1] = ACT_RANGE_ATTACK1,
		[ACT_HL2MP_IDLE] = ACT_HL2MP_IDLE_FIST,
		[ACT_HL2MP_WALK] = ACT_HL2MP_WALK_FIST,
		[ACT_HL2MP_JUMP] = ACT_HL2MP_JUMP_FIST,
		[ACT_HL2MP_RUN] = ACT_HL2MP_RUN_FIST
	};
end;

if (CLIENT) then
	SWEP.Slot = 5;
	SWEP.SlotPos = 2;
	SWEP.DrawAmmo = false;
	SWEP.PrintName = "Oxygen Mask";
	SWEP.DrawCrosshair = true;
end

SWEP.Instructions = "Primary Fire: Force a burst of Oxygen into the Patient's lungs.";
SWEP.Contact = "";
SWEP.Purpose = "Giving Oxygen to those in need.";
SWEP.Author	= "Arbiter";

SWEP.WorldModel = "models/weapons/w_fists_t.mdl";
SWEP.ViewModel = "models/weapons/v_punch.mdl";
SWEP.HoldType = "fist";

SWEP.AdminSpawnable = false;
SWEP.Spawnable = false;
  
SWEP.Primary.DefaultClip = 0;
SWEP.Primary.Automatic = true;
SWEP.Primary.ClipSize = -1;
SWEP.Primary.Damage = 1;
SWEP.Primary.Ammo = "";

SWEP.Secondary.DefaultClip = 0;
SWEP.Secondary.Automatic = false;
SWEP.Secondary.ClipSize = -1;
SWEP.Secondary.Ammo	= "";

SWEP.NoIronSightFovChange = true;
SWEP.NoIronSightAttack = true;
SWEP.LoweredAngles = Angle(60, 60, 60);
SWEP.IronSightPos = Vector(0, 0, 0);
SWEP.IronSightAng = Vector(0, 0, 0);
SWEP.NeverRaised = true;

-- Called when the SWEP is deployed.
function SWEP:Deploy()
	self:SendWeaponAnim(ACT_VM_DRAW);
end;

-- Called when the SWEP is holstered.
function SWEP:Holster(switchingTo)
	self:SendWeaponAnim(ACT_VM_HOLSTER);
	return true;
end;

-- Called when the player attempts to primary fire.
function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + 1);
	
	if (SERVER) then
		local action = Clockwork.player:GetAction(self.Owner);
		local trace = self.Owner:GetEyeTraceNoCursor();
		local player = Clockwork.entity:GetPlayer(trace.Entity);
		local activeWeapon = self.Owner:GetActiveWeapon();
		local itemTable = Clockwork.item:GetByWeapon(activeWeapon);
		local battery = itemTable:GetData("oxygen");	
			
		if (self.Owner:GetPos():Distance(trace.HitPos) > 192
		or !IsValid(trace.Entity)) then
			return;
		end;
		
		if player then
			if player:Alive() then
				if ( battery != 0 ) then
					if ( player:GetCharacterData("oxygen") + 10 ) <= 100 then
						player:SetCharacterData("oxygen", player:GetCharacterData("oxygen") + 10);
						self.Owner:EmitSound("player/sprayer.wav")
						itemTable:SetData("oxygen", tonumber(battery) - 10);
						
						if battery <= 20 then
							self.Owner:EmitSound("npc/roller/mine/rmine_blip1.wav")
							Clockwork.player:Notify(self.Owner, "Alert, Oxygen charge reaching Critical Low.");
						end;
					end;
				else
					self.Owner:EmitSound("items/medshotno1.wav")
					Clockwork.player:Notify(self.Owner, "Warning! Oxygen Drained.");
				end;
			end;
		else
			self.Owner:EmitSound("npc/roller/mine/rmine_tossed1.wav")
			Clockwork.player:Notify(self.Owner, "This is not a valid Target!");
		end;
	end;
end;

-- Called when the player attempts to secondary fire.
function SWEP:SecondaryAttack() end;