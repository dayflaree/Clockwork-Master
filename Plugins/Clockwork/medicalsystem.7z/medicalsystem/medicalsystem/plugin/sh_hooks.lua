local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("heart", true);
	playerVars:Number("blood", true);
	playerVars:Number("oxygen", true);
	playerVars:Number("bleeding", true);
	playerVars:Number("cardiacArrest", true);
end;