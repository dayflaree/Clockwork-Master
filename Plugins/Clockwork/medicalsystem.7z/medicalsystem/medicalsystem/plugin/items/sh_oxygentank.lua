local ITEM = Clockwork.item:New();
ITEM.name = "Oxygen Tank";
ITEM.cost = 15;
ITEM.model = "models/props_junk/propane_tank001a.mdl";
ITEM.weight = 4;
ITEM.access = "m";
ITEM.useText = "Install";
ITEM.uniqueID = "o2_tank";
ITEM.business = true;
ITEM.category = "Misc";
ITEM.description = "A large oxygen tank with a nozzle designed to fit most Oxygen masks.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local weapon = player:GetActiveWeapon();
	
	if (IsValid(weapon)) then
		local mask = Clockwork.item:GetByWeapon(weapon);
		
		if (weapon:GetClass() == "cw_omask") then
			mask:SetData("oxygen", 100);
		else
			Clockwork.player:Notify(player, "This weapon Cannot hold a Oxygen Tank!");
			return false;
		end;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();