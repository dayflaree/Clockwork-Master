--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Blood Pack";
ITEM.cost = 10;
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
ITEM.weight = 0.5;
ITEM.access = "m";
ITEM.useText = "Apply";
ITEM.category = "Medical"
ITEM.useSound = "npc/barnacle/barnacle_tongue_pull1.wav"
ITEM.business = true;
ITEM.description = "An old rusted Syringe, preloaded with a large ammount of blood. \n It has a button on the side to inject, and seems good for one use only.";
ITEM.customFunctions = {"Give"};

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if player:GetSharedVar("bleeding") <= 90 then
		player:SetCharacterData("blood", player:GetSharedVar("blood") + 10);
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (name == "Give") then
		local trace = player:GetEyeTraceNoCursor();
		local target = Clockwork.entity:GetPlayer(trace.Entity);
			if (target) then
				if (target:GetSharedVar("blood") <= 90) then
					if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
						target:SetCharacterData("blood", target:GetSharedVar("blood") + 10);
						target:EmitSound("npc/barnacle/barnacle_tongue_pull1.wav");
						player:TakeItem(self);
					else
						Clockwork.player:Notify(player, "The player is too far away!");
					end;
				else
					Clockwork.player:Notify(player, "This player isn't bleeding!");
				end;
			else
				Clockwork.player:Notify(player, "This is not a Valid target!");
			end;
		end;
	end;
end;

ITEM:Register();