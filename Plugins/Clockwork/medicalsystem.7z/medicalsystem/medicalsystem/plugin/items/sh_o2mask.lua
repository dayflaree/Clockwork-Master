local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Oxygen Mask";
	ITEM.cost = 280;
	ITEM.batch = 1;
	ITEM.model = "models/Items/battery.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "m";
	ITEM.category = "Reusables";
	ITEM.uniqueID = "cw_omask";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "An Oxygen Mask, able to breath life into the dying.";

	ITEM:AddData("oxygen", 100, true);

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		if (!self:IsInstance()) then
			return;
		end;
		
		local clientSideInfo = "";
		local batteryCharge = self:GetData("oxygen");

		if (batteryCharge > 0) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Oxygen: "..batteryCharge.."%");
		else
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Warning! Tank Empty!");
		end;
		
		return (clientSideInfo != "" and clientSideInfo);
	end;
end;

ITEM:Register();