local ITEM = Clockwork.item:New();
ITEM.name = "Defibulator Battery";
ITEM.cost = 15;
ITEM.model = "models/Items/car_battery01.mdl";
ITEM.weight = 5;
ITEM.access = "m";
ITEM.useText = "Install";
ITEM.uniqueID = "defib_battery";
ITEM.business = true;
ITEM.category = "Electronics";
ITEM.description = "A small battery designed to fit most Defibulator Units.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local weapon = player:GetActiveWeapon();
	
	if (IsValid(weapon)) then
		local defib = Clockwork.item:GetByWeapon(weapon);
		
		if (weapon:GetClass() == "cw_defib") then
			defib:SetData("Battery", 100);
		else
			Clockwork.player:Notify(player, "This weapon Cannot hold a Battery!");
			return false;
		end;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();