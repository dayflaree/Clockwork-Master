local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Defibulator";
	ITEM.cost = 280;
	ITEM.batch = 1;
	ITEM.model = "models/Items/HealthKit.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "m";
	ITEM.category = "Reusables";
	ITEM.uniqueID = "cw_defib";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A pair of Shock paddles designed to restart a heart.";

	ITEM:AddData("Battery", 100, true);

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		if (!self:IsInstance()) then
			return;
		end;
		
		local clientSideInfo = "";
		local batteryCharge = self:GetData("Battery");

		if (batteryCharge > 0) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Battery Charge: "..batteryCharge.."%");
		else
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Battery Charge: Dead");
		end;
		
		return (clientSideInfo != "" and clientSideInfo);
	end;
end;

ITEM:Register();