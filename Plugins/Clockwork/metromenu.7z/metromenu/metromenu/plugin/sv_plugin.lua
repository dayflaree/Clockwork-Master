Clockwork.kernel:AddFile("materials/cwmetrorp/station_menu_2.png");
Clockwork.kernel:AddFile("materials/cwmetrorp/station_menu_0.png");
Clockwork.kernel:AddFile("sound/cwmetrorp/hover1.wav");