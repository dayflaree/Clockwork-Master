Install:

1.Put 'metromenu' folder in 'gamemodes/YOURSCHEMA/plugins'.
2.Put files from 'matrials' folder in your 'materials' folder.
3.Put files from 'sound' folder in your 'sound' folder.