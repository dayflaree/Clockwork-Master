local PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("Stash Space", "max_stash_space", "The maximum weight the stashes can hold.");