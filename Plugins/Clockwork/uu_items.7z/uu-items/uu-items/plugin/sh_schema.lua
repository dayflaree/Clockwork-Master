local PLUGIN = PLUGIN;

Clockwork.flag:Add("u", "Light Union", "Access to light union goods.");
Clockwork.flag:Add("U", "Heavy Union", "Access to heavy union goods.");