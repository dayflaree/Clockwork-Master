--[[
Name: "sv_auto.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

NEXUS:IncludePrefixed("sh_auto.lua");
