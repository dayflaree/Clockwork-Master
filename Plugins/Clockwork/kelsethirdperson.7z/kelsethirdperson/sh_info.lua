--[[
Name: "sh_info.lua".
Product: "eXperim3nt".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Thirdperson";
MOUNT.author = "Last.Exile redone to work with Nexus by Kelse";
MOUNT.description = "Allows Third Person.";