-- A bit different from cl_plugins, here we set the default value instead.
Clockwork.config:Add("jammer_range", 1024, true)