local Clockwork = Clockwork;

Clockwork.config:AddToSystem("Advertisement interval", "advert_interval", "How long it takes for advertisements to cycle.", 60);