if (SERVER) then
	AddCSLuaFile("shared.lua");
end

ENT.Type = "anim";
ENT.Author = "elec";
ENT.PrintName = "Security Camera";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;

function ENT:Initialize()
    if SERVER then
        self:SetModel("models/props/cs_assault/camera.mdl")
        self:DrawShadow(true);
        self:SetSolid(SOLID_VPHYSICS);
        self:PhysicsInit(SOLID_VPHYSICS);
        self:SetMoveType(MOVETYPE_VPHYSICS);
        //self:SetUseType(SIMPLE_USE);
        
        local physicsObject = self:GetPhysicsObject();
	
        if (IsValid(physicsObject)) then
            physicsObject:Wake();
            physicsObject:EnableMotion(true);
        end;
		self:SetDirection(Angle(0,0,0))
		self:SetFOV(45)
    end
    if CLIENT then
        //if ScrH() < 1024 then
            self.rt = GetRenderTarget("CAMRT"..self:EntIndex( ),512,512)
        //else
        //    self.rt = GetRenderTarget("CAMRT"..self:EntIndex( ),1024,1024)
        //end
        self.mat = CreateMaterial("CAMRT"..self:EntIndex( ), "UnlitGeneric", {})
        self.mat:SetTexture	( "$basetexture", self.rt )
		self.csEnt = ClientsideModel( "models/props/cs_assault/camera.mdl")
        self.csEnt.RenderOverride = function(self)
            local normal = Angle(25,25,0):Up()
            normal:Rotate(self:GetAngles())
            
            local oldEC = render.EnableClipping( true )
        	render.PushCustomClipPlane( normal, normal:Dot(self:GetPos()) )
        
        	self:DrawModel()
        
            render.PopCustomClipPlane()
        	render.EnableClipping( oldEC )
        end
    end
end;
function ENT:OnRemove()
	if CLIENT then
		self.csEnt:Remove()
	end
end

if SERVER then
ENT.turnSpeed = 0.1
ENT.curTurn = 0.1
function ENT:Think()
	if !self.targetDir or !self.targetDelta then return end
	self:SetDirection(LerpAngle(self.curTurn,self.targetDir,self.targetDir+self.targetDelta))
	self.curTurn = self.curTurn + self.turnSpeed*FrameTime()
	if self.curTurn >= 1 or self.curTurn <= 0 then
		self.turnSpeed = -self.turnSpeed
	end
	self:NextThink( CurTime() )
	return true
end

end
function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "Password" )
    self:NetworkVar( "String", 1, "CamName" )
    self:NetworkVar( "Bool", 0, "Disabled" )
    self:NetworkVar( "Bool", 1, "Muted" )
	self:NetworkVar( "Angle", 0, "Direction" )
	self:NetworkVar( "Float", 0, "FOV" )
end

function ENT:GetCamPos()
    //return self:GetPos()+self:GetForward()*15+self:GetRight()*-34.5+self:GetUp()*-7
	local offset = Vector(0.147090, 25.765303, -4.987739)
    offset:Rotate(self:GetAngles())
	return self:GetPos()+offset+self:GetDirection():Forward()*15
end

if CLIENT then

ENT.lastRefresh = CurTime()
ENT.refreshRate = 0.05

function ENT:GetCamDirection()
    //return ((self:GetPos()+self:GetForward()*16+self:GetRight()*-35+self:GetUp()*-7.3) - (self:GetPos()+self:GetForward()*15+self:GetRight()*-34.5+self:GetUp()*-6.7)):GetNormal()
	return self:GetDirection():Forward()
end

function ENT:Draw()
	if !IsValid(self.csEnt) then
		self.csEnt = ClientsideModel( "models/props/cs_assault/camera.mdl")
		self.csEnt.RenderOverride = function(self)
			local normal = Angle(25,25,0):Up()
			normal:Rotate(self:GetAngles())
			
			local oldEC = render.EnableClipping( true )
			render.PushCustomClipPlane( normal, normal:Dot(self:GetPos()) )
		
			self:DrawModel()
		
			render.PopCustomClipPlane()
			render.EnableClipping( oldEC )
		end
	end
    local normal = -Angle(25,25,0):Up()
    normal:Rotate(self:GetAngles())
    
    local oldEC = render.EnableClipping( true )
	render.PushCustomClipPlane( normal, normal:Dot(self:GetPos()) )

    self:DrawModel()

    render.PopCustomClipPlane()
	render.EnableClipping( oldEC )

    local aimAngle = Angle(-19,-31,12)
	local dirAngle = self:GetDirection()
    aimAngle:RotateAroundAxis(Vector(0,1,0),dirAngle.p)
	aimAngle:RotateAroundAxis(Vector(0,0,1),dirAngle.y)
    //ent = LocalPlayer():GetEyeTrace().Entity
    
    self.csEnt:SetAngles(aimAngle)
    

    local offset = Vector(0.147090, 25.765303, -4.987739)
    offset:Rotate(self:GetAngles())
    local noffset = Vector(0.147090, 25.765303, -4.987739)
    noffset:Rotate(self.csEnt:GetAngles())
    self.csEnt:SetPos(self:GetPos()+offset-noffset)
    
    render.SetColorMaterial()
    render.DrawSphere( self:GetPos()+offset, 2, 30, 30, Color( 0, 0, 0, 255 ) )
end
end