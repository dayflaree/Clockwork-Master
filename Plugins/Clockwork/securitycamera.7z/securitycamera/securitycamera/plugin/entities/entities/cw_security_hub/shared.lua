if (SERVER) then
	AddCSLuaFile("shared.lua");
end

ENT.Type = "anim";
ENT.Author = "elec";
ENT.PrintName = "Security Hub";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
function ENT:Initialize()
    if SERVER then
        self.disabled = {}
        self.muted = {}
        self:SetModel("models/props_combine/combine_intmonitor001.mdl")
        self:DrawShadow(true);
        self:SetSolid(SOLID_VPHYSICS);
        self:PhysicsInit(SOLID_VPHYSICS);
        self:SetMoveType(MOVETYPE_VPHYSICS);
        self:SetUseType(SIMPLE_USE);
        
        local physicsObject = self:GetPhysicsObject();
	
        if (IsValid(physicsObject)) then
            physicsObject:Wake();
            physicsObject:EnableMotion(true);
        end;
        
        self:SetLarge(0)
    else
        self:SetRenderBounds(-Vector(30,30,30),Vector(30,30,30))
		
		timer.Create("hubtick_"..self:EntIndex( ),(1/(CW_CONVAR_CAMERAFPS:GetFloat())),0,function()
			if !GLOBAL_CAM_CHANNEL[self:GetPassword()] or GLOBAL_CAM_CHANNEL[self:GetPassword()].ent == self or GLOBAL_CAM_CHANNEL[self:GetPassword()].time <= CurTime() then
			self:RenderCams()
			end
		end)
    end
end;
GLOBAL_CAM_CHANNEL = {}

function ENT:OnRemove()
	if CLIENT then
		timer.Destroy("hubtick_"..self:EntIndex( ))
	end
end
function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "Password" )
    self:NetworkVar( "Int", 0, "Large" )
end

if CLIENT then
ENT.rotate = 0
ENT.lasttime = 0
ENT.nextCam = 1
ENT.nextRender = 0

local	CamData = {}
CamData.x = 0
CamData.y = 0
//if ScrH() < 1024 then
CamData.w = 512
CamData.h = 512
//else
//CamData.w = 1024
//CamData.h = 1024
//end
CamData.drawhud = false
CamData.drawviewmodel = false
CamData.dopostprocess = false
CamData.drawmonitors = false
CamData.fov = 45

function ENT:RenderCams()
    if self.NextPostRender <= CurTime() then return end
    if self:GetPos():Distance(LocalPlayer():GetPos()) > CW_CONVAR_CAMERADISTANCE:GetFloat() then return end
    //if self.nextRender <= CurTime() then
        if self.nextCam > #self.cameraList then self.nextCam = 1 end
        local v = self.cameraList[self.nextCam]
        if !v then return end
        if v:GetDisabled() == true then return end
        CamData.angles	= v:GetDirection() //v:GetCamDirection():Angle()
        CamData.origin	= v:GetCamPos()
		CamData.fov = v:GetFOV()
        local OldRT	= render.GetRenderTarget()
        render.SetRenderTarget	( v.rt )
        render.ClearDepth	()
        render.RenderView	( CamData )
        render.SetRenderTarget	( OldRT )
        //self.nextRender = CurTime()
        self.nextCam = self.nextCam + 1
    //end
	GLOBAL_CAM_CHANNEL[self:GetPassword()] = {ent = self,time = CurTime()+1}
end

ENT.NextPostRender = CurTime()

surface.CreateFont( "CamNameSmall", {
	font = "Debug",
	size = 75,
	weight = 500,
	scanlines = 20,
	antialias = true,
	outline = true
} )

surface.CreateFont( "CamNameBig", {
	font = "Debug",
	size = 300,
	weight = 500,
	scanlines = 20,
	antialias = true,
	outline = true
} )

local function planeLineIntersect( lineStart, lineEnd, planeNormal, planePoint )
    local t = planeNormal:Dot( planePoint - lineStart ) / planeNormal:Dot( lineEnd - lineStart )
    return lineStart + t * ( lineEnd - lineStart )
end

function ENT:GetCursorPos(ply)
    if !ply then ply = LocalPlayer() end
    
    local angle2 = self.angle:Angle()
    angle2:RotateAroundAxis( self.normal, 90 )
    angle2 = angle2:Forward()
    
    local p = planeLineIntersect( ply:EyePos(), ply:EyePos() + ply:GetAimVector() * 16000, self.normal, self.origin )
    local offset = self.origin - p
    
    local x = Vector( offset.x * self.angle.x, offset.y * self.angle.y, offset.z * self.angle.z ):Length() / self.scale
    local y = Vector( offset.x * angle2.x, offset.y * angle2.y, offset.z * angle2.z ):Length() / self.scale
    
    local offset2 = (self.origin+self.angle*(self.screenSizeX*self.scale)-angle2*(self.screenSizeY*self.scale)) - p
    
    local x2 = Vector( offset2.x * self.angle.x, offset2.y * self.angle.y, offset2.z * self.angle.z ):Length() / self.scale
    local y2 = Vector( offset2.x * angle2.x, offset2.y * angle2.y, offset2.z * angle2.z ):Length() / self.scale
    
    if (x > self.screenSizeX || x2 > self.screenSizeX || y > self.screenSizeY || y2 > self.screenSizeY) then
        return -1, -1
    end
    
    return x, y
end

ENT.selectedGridX = -1
ENT.selectedGridY = -1
ENT.useDistance = 128

function ENT:DrawTranslucent()
    if self.NextPostRender <= CurTime() then 
        self.NextPostRender = CurTime() + 1 
        Clockwork.datastream:Start("CAMDRAW", {self:GetPassword()});
        self.cameraList = {}
        for k,v in pairs(ents.FindByClass("cw_security_cam")) do
            if v:GetPassword() == self:GetPassword() then 
                self.cameraList[#self.cameraList+1] = v
            end
        end
    end
    
    self:DrawModel()  
    
    if self:GetPos():Distance(LocalPlayer():GetPos()) > CW_CONVAR_CAMERADISTANCE:GetFloat() then return end
    
    local camList = {}
    for k,v in pairs(ents.FindByClass("cw_security_cam")) do
        if v:GetPassword() == self:GetPassword() then 
            camList[#camList+1] = {v.mat, v}
        end
    end
    
    local screenAngle = self:GetAngles()
    screenAngle:RotateAroundAxis(self:GetUp(),90)
    screenAngle:RotateAroundAxis(self:GetRight(),-90)
    
    self.origin = self:GetPos()+self:GetUp()*46+self:GetForward()*1.2+self:GetRight()*18.5
    self.scale = 0.01
    self.angle = screenAngle:Forward()
    
    self.normal = Angle( screenAngle.p, screenAngle.y, screenAngle.r )
    self.normal:RotateAroundAxis( screenAngle:Forward(), -90 )
    self.normal:RotateAroundAxis( screenAngle:Right(), 90 )
    self.normal = self.normal:Forward()
    self.screenSizeX = 3072
    self.screenSizeY = 3072

	cam.Start3D2D( self.origin, screenAngle, self.scale )
		surface.SetDrawColor(Color(0,0,0))
        surface.DrawRect( 0, 0, 3072, 3072 )
        surface.SetDrawColor(Color(255,255,255))
        
        if self:GetLarge() != 0 and camList[self:GetLarge()] then
            if camList[self:GetLarge()][2]:GetDisabled() == true then
                draw.SimpleText("DISABLED","CamNameBig",1536,1536,Color(0,255,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER  )
            else
                surface.SetMaterial(camList[self:GetLarge()][1])
                surface.DrawTexturedRect(0,0,3072,3072)
            end
            
            if camList[self:GetLarge()][2]:GetMuted() == true then
                draw.DrawText("MUTE","CamNameBig",50,50,Color(0,255,0),TEXT_ALIGN_LEFT )
            end
            
            draw.DrawText(camList[self:GetLarge()][2]:GetCamName(),"CamNameBig",100,2850,Color(0,255,0),TEXT_ALIGN_LEFT )
        else
            for i=1,9,1 do
                if camList[i] then
                    if camList[i][2]:GetDisabled() == true then
                        draw.SimpleText("DISABLED","CamNameSmall",math.fmod(i-1,3)*1024+512,math.floor((i-1)/3)*1024+512,Color(0,255,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER  )
                        
                    else
                        surface.SetMaterial(camList[i][1])
                        surface.DrawTexturedRect(math.fmod(i-1,3)*1024,math.floor((i-1)/3)*1024,1024,1024)
                    end
                    
                    if camList[i][2]:GetMuted() == true then
                        draw.DrawText("MUTE","CamNameSmall",math.fmod(i-1,3)*1024+50,math.floor((i-1)/3)*1024+50,Color(0,255,0),TEXT_ALIGN_LEFT )
                    end
                    
                    draw.DrawText(camList[i][2]:GetCamName(),"CamNameSmall",math.fmod(i-1,3)*1024+50,math.floor((i-1)/3)*1024+920,Color(0,255,0),TEXT_ALIGN_LEFT )
                end
            end
            
            if LocalPlayer():EyePos():Distance(self:GetPos()) < self.useDistance then
                local x,y = self:GetCursorPos()
                self.gridx, self.gridy = math.floor(x/1024), math.floor(y/1024)
                local selectedFeed = (self.gridx + 1)+(self.gridy*3)
                if camList[selectedFeed] then
                    self.gridcam = camList[selectedFeed][2]
                else
                    self.gridcam = nil
                end
                
                if self.gridx != -1 and self.gridy != -1 then
                    surface.SetDrawColor(Color(0,255,0))
                    surface.DrawRect( self.gridx*1024, self.gridy*1024, 1024, 16 )
                    surface.DrawRect( self.gridx*1024, self.gridy*1024, 16, 1024 )
                    surface.DrawRect( (self.gridx+1)*1024, (self.gridy+1)*1024, -1024, -16 )
                    surface.DrawRect( (self.gridx+1)*1024, (self.gridy+1)*1024, -16, -1024 )
                end
                
                if self.selectedGridX != -1 and self.selectedGridY != -1 then
                    surface.SetDrawColor(Color(255,0,0))
                    surface.DrawRect( self.selectedGridX*1024, self.selectedGridY*1024, 1024, 16 )
                    surface.DrawRect( self.selectedGridX*1024, self.selectedGridY*1024, 16, 1024 )
                    surface.DrawRect( (self.selectedGridX+1)*1024, (self.selectedGridY+1)*1024, -1024, -16 )
                    surface.DrawRect( (self.selectedGridX+1)*1024, (self.selectedGridY+1)*1024, -16, -1024 )
                end
            else
                self.gridx = -1
            end
        end
	cam.End3D2D()
    
    local screenAngle = self:GetAngles()
    screenAngle:RotateAroundAxis(self:GetUp(),90)
    screenAngle:RotateAroundAxis(self:GetRight(),-75)
    
    self.origin = self:GetPos()+self:GetUp()*15.3+self:GetForward()*1.2+self:GetRight()*18.5
    self.scale = 0.01
    self.angle = screenAngle:Forward()
    
    self.normal = Angle( screenAngle.p, screenAngle.y, screenAngle.r )
    self.normal:RotateAroundAxis( screenAngle:Forward(), -90 )
    self.normal:RotateAroundAxis( screenAngle:Right(), 90 )
    self.normal = self.normal:Forward()
    self.screenSizeX = 3072
    self.screenSizeY = 1024

	cam.Start3D2D( self.origin, screenAngle, 0.01 )
		surface.SetDrawColor(Color(0,0,0))
        surface.DrawRect( 0, 0, 3072, 1024 )
        
        local maxmin = "Maximize"
        local mute = "Mute"
        local disable = "Disable"
        
        if self:GetLarge() != 0 then
            maxmin = "Minimize"
        end
        
        if self.selectedGridCam then
            if self.selectedGridCam:GetDisabled() then
                disable = "Enable"
            end
            
            if self.selectedGridCam:GetMuted() then
                mute = "Unmute"
            end
        end
        draw.SimpleText(maxmin,"CamNameBig",512,512,Color(0,255,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER  )
        draw.SimpleText(mute,"CamNameBig",512+1024,512,Color(0,255,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER  )
        draw.SimpleText(disable,"CamNameBig",512+2048,512,Color(0,255,0),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER  )
        
        if LocalPlayer():EyePos():Distance(self:GetPos()) < self.useDistance then
            local x,y = self:GetCursorPos()
            self.toolbarx = math.floor(x/1024)
            
            if self.toolbarx != -1 then
                surface.SetDrawColor(Color(0,255,0))
                surface.DrawRect( self.toolbarx*1024, 0, 1024, 16 )
                surface.DrawRect( self.toolbarx*1024, 0, 16, 1024 )
                surface.DrawRect( (self.toolbarx+1)*1024, 1024, -1024, -16 )
                surface.DrawRect( (self.toolbarx+1)*1024, 1024, -16, -1024 )
            end
        else
            self.toolbarx = -1 
        end
    cam.End3D2D()
end

end