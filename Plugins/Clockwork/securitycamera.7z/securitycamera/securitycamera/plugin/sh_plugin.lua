local PLUGIN = PLUGIN;

if SERVER then

	function PLUGIN:ClockworkInitPostEntity()
		local entities = Clockwork.kernel:RestoreSchemaData( "plugins/security_camera/"..game.GetMap() );
		
		for k, v in pairs(entities) do
			local entity = ents.Create(v.class);
			entity:SetAngles(v.angles);
			entity:SetPos(v.position);
			entity:Spawn();
			entity:SetPassword(v.password);
			if v.large then
				entity:SetLarge(v.large);
			else
				entity:SetCamName(v.camname);
				entity:SetDisabled(v.disabled);
				entity:SetMuted(v.muted);
				entity:SetDirection(v.direction)
				entity:SetFOV(v.fov)
				entity.targetDir = v.targetDir
				entity.targetDelta = v.targetDelta
				entity.turnSpeed = v.turnSpeed
				entity.curTurn = v.curTurn
			end
			
			Clockwork.entity:MakeSafe(entity, true, true, true);
		end;
	end;

	function PLUGIN:PostSaveData()
		local entities = {};
		
		for k, v in pairs(ents.FindByClass("cw_security_hub")) do
			entities[#entities + 1] = {
				angles = v:GetAngles(),
				position = v:GetPos(),
				class = "cw_security_hub",
				password = v:GetPassword(),
				large = v:GetLarge()
			};
		end;
		
		for k, v in pairs(ents.FindByClass("cw_security_cam")) do
			entities[#entities + 1] = {
				angles = v:GetAngles(),
				position = v:GetPos(),
				class = "cw_security_cam",
				password = v:GetPassword(),
				camname = v:GetCamName(),
				disabled = v:GetDisabled(),
				muted = v:GetMuted(),
				direction = v:GetDirection(),
				fov = v:GetFOV(),
				targetDir = v.targetDir,
				targetDelta = v.targetDelta,
				turnSpeed = v.turnSpeed,
				curTurn = v.curTurn
			};
		end;
		
		Clockwork.kernel:SaveSchemaData("plugins/security_camera/"..game.GetMap(), entities);
	end;

	Clockwork.datastream:Hook("CAMDRAW", function(ply, data)
		local password = data[1]
		ply.cwCams = ply.cwCams or {}
		ply.cwCams[password] = CurTime() + 1.5
	end)

	Clockwork.datastream:Hook("HUBLARGE", function(ply, data)
		data[1]:SetLarge(data[2])
	end)

	Clockwork.datastream:Hook("HUBDISABLE", function(ply, data)
		data[1].disabled[data[2]] = data[3]

		for _,v in pairs(ents.FindByClass("cw_security_hub")) do
			if v:GetPassword() == data[2]:GetPassword() then
				if v.disabled[data[2]] then
					data[2]:SetDisabled(true)
					return
				end
			end
		end
		
		data[2]:SetDisabled(false)
	end)

	Clockwork.datastream:Hook("HUBMUTE", function(ply, data)
		data[1].muted[data[2]] = data[3]
		
		for _,v in pairs(ents.FindByClass("cw_security_hub")) do
			if v:GetPassword() == data[2]:GetPassword() then
				if v.muted[data[2]] then
					data[2]:SetMuted(true)
					return
				end
			end
		end
		
		data[2]:SetMuted(false)
	end)
	/*
	function PLUGIN:ChatBoxMessageAdded(info)
		if (info.class == "ic" or info.class == "me" or info.class == "yell" or info.class == "radio") then
			local eavesdroppers = {}
			for _,ply in pairs(_player.GetAll()) do
				ply.cwCams = ply.cwCams or {}
				for pass,time in pairs(ply.cwCams) do
					if time > CurTime() then
						for _,v in pairs(ents.FindByClass("cw_security_cam")) do
							if pass == v:GetPassword() and !v:GetMuted() then
								local maxdistance = Clockwork.config:Get("talk_radius"):Get() * 2
								if info.class == "yell" or info.class == "me" then
									maxdistance = Clockwork.config:Get("talk_radius"):Get() * 4
								end
								if info.speaker:EyePos():Distance(v:GetCamPos()) < maxdistance then
									local trace = util.TraceLine({
										start = info.speaker:EyePos(),
										endpos = v:GetCamPos(),
										filter = {info.speaker,v}
									})
									
									if !trace.Hit then
										eavesdroppers[#eavesdroppers+1] = {ply,v}
									end
								end
							end
						end
					end
				end
			end
			if (table.Count(eavesdroppers) > 0) then
				for _,v in pairs(eavesdroppers) do 
					Clockwork.chatBox:Add(v[1], info.speaker, info.class.."_camera", info.text, {cameraName = v[2]:GetCamName()});
				end
			end;
		end
	end*/
	function PLUGIN:SetupPlayerVisibility(ply)
		if ply.cwCams then
			for _,v in pairs(ents.FindByClass("cw_security_cam")) do
				for pass,time in pairs(ply.cwCams) do
					if time > CurTime() and pass == v:GetPassword() then
						AddOriginToPVS( v:GetCamPos() ) 
					end
				end
			end
		end
	end

end

if CLIENT then
local curFPS = 1
timer.Create("secCam_check",1,0,function()
	if curFPS != CW_CONVAR_CAMERAFPS:GetFloat() then
		curFPS = CW_CONVAR_CAMERAFPS:GetFloat()
		for k, v in pairs(ents.FindByClass("cw_security_hub")) do
			timer.Adjust("hubtick_"..v:EntIndex( ),(1/(CW_CONVAR_CAMERAFPS:GetFloat())),0)
		end
	end
end)
surface.CreateFont( "CamNameSmallHUD", {
	font = "Debug",
	size = ScreenScale(1),
	weight = 500,
	scanlines = 20,
	antialias = true,
	outline = true
} )

surface.CreateFont( "CamNameBigHUD", {
	font = "Debug",
	size = ScreenScale(30),
	weight = 500,
	scanlines = 20,
	antialias = true,
	outline = true
} )
/*
Clockwork.chatBox:RegisterClass("ic_camera", "ic", function(info)
    Clockwork.chatBox:Add(info.filtered, nil, Color(255, 255, 150, 255), "["..info.data.cameraName.."] "..info.name.." says \""..info.text.."\"");
end);

Clockwork.chatBox:RegisterClass("me_camera", "ic", function(info)
    if (string.sub(info.text, 1, 1) == "'") then
        Clockwork.chatBox:Add(info.filtered, nil, Color(255, 255, 150, 255), "["..info.cameraName.."]** "..info.name..info.text);
    else
        Clockwork.chatBox:Add(info.filtered, nil, Color(255, 255, 150, 255), "["..info.cameraName.."]** "..info.name.." "..info.text);
    end;
end);

Clockwork.chatBox:RegisterClass("yell_camera", "ic", function(info)
    Clockwork.chatBox:Add(info.filtered, nil, Color(255, 255, 150, 255), "["..info.cameraName.."] "..info.name.." yells \""..info.text.."\"");
end);

Clockwork.chatBox:RegisterClass("radio_camera", "ic", function(info)
    Clockwork.chatBox:Add(info.filtered, nil, Color(255, 255, 150, 255), "["..info.cameraName.."] "..info.name.." radios in \""..info.text.."\"");
end);*/
/*
function PLUGIN:HUDPaint()
    for k,v in pairs(ents.FindByClass("cw_security_hub")) do
        v:PostRender()
    end
end*/

function PLUGIN:KeyPress(ply,key)
    if ( key == IN_USE ) then
        local hubs = {}
        for _,v in pairs(ents.FindByClass("cw_security_hub")) do
            if v.NextPostRender > CurTime() and (v.gridx != -1 or v.toolbarx != -1) then
                hubs[#hubs+1] = v
            end
        end
        
        if #hubs == 0 then return end
        
        local selected = hubs[1]
        if #hubs > 1 then  
            local distance = hubs[1]:GetPos():Distance(ply:EyePos())
            for _,v in pairs(hubs) do
                local checked_distance = v:GetPos():Distance(ply:EyePos())
                if checked_distance < distance then
                    distance = checked_distance
                    selected = v
                end
            end
        end
        if !selected.nextE then selected.nextE = CurTime() + 0.01 end
        if selected.nextE > CurTime() then return end
        selected.nextE = CurTime() + 0.01
        
        
        if selected.gridx != -1 then
            if selected.selectedGridX == selected.gridx and selected.selectedGridY == selected.gridy then
                selected.selectedGridX = -1
                selected.selectedGridY = -1
                selected.selectedGridCam = nil
            else
                selected.selectedGridX = selected.gridx
                selected.selectedGridY = selected.gridy
                selected.selectedGridCam = selected.gridcam
            end
        elseif selected.toolbarx != -1 then
            if selected.toolbarx == 0 then
                if selected:GetLarge() == 0 and selected.selectedGridX != -1 and IsValid(selected.selectedGridCam) then
                    local selectedFeed = (selected.selectedGridX + 1)+(selected.selectedGridY*3)
                    Clockwork.datastream:Start("HUBLARGE", {selected, selectedFeed});
                else
                    Clockwork.datastream:Start("HUBLARGE", {selected, 0});
                end
            elseif selected.toolbarx == 1 and selected.selectedGridX != -1 and IsValid(selected.selectedGridCam) then
                if selected.selectedGridCam:GetMuted() then
                    Clockwork.datastream:Start("HUBMUTE", {selected, selected.selectedGridCam, false});
                else
                    Clockwork.datastream:Start("HUBMUTE", {selected, selected.selectedGridCam, true});
                end
            elseif selected.toolbarx == 2 and selected.selectedGridX != -1 and IsValid(selected.selectedGridCam) then
                if selected.selectedGridCam:GetDisabled() then
                    Clockwork.datastream:Start("HUBDISABLE", {selected, selected.selectedGridCam, false});
                else
                    Clockwork.datastream:Start("HUBDISABLE", {selected, selected.selectedGridCam, true});
                end
            end
        end
    end 
end

Clockwork.setting:AddNumberSlider("Security Camera", "Camera FPS (Lower this when you lag):", "cwCameraFPS", 1, 30, 0, "Camera FPS");
Clockwork.setting:AddNumberSlider("Security Camera", "Camera Draw Distance (Lower this when you lag in places you shouldn't):", "cwCameraDistance", 0, 1024, 2, "Camera Draw Distance");

function PLUGIN:Initialize()
	CW_CONVAR_CAMERAFPS = Clockwork.kernel:CreateClientConVar("cwCameraFPS", 10, false, true);
    CW_CONVAR_CAMERADISTANCE = Clockwork.kernel:CreateClientConVar("cwCameraDistance", 256, false, true);
end;
end

local function searchCamera(name,pass)
    for k,v in pairs(ents.FindByClass("cw_security_cam")) do
        if v:GetPassword() == pass and v:GetCamName() == name then 
            return v
        end
    end
end

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CamSetDir");
COMMAND.tip = "Point the camera at the location you're pointing.";
COMMAND.text = "<string Name> <string Channel>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local camera = searchCamera(arguments[1],arguments[2])
    if !IsValid(camera) then Clockwork.player:Notify(player, "This camera does not exist!"); return end 
    local targetPos = player:GetEyeTrace().HitPos
    camera:SetDirection((targetPos-camera:GetCamPos()):Angle())
end;

COMMAND:Register();

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CamSetFOV");
COMMAND.tip = "Adjust the Camera's FOV.";
COMMAND.text = "<string Name> <string Channel> <float FOV>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 3;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local camera = searchCamera(arguments[1],arguments[2])
    if !IsValid(camera) then Clockwork.player:Notify(player, "This camera does not exist!"); return end 
    local fov = tonumber(arguments[3])
    if !fov then Clockwork.player:Notify(player, "Please provide a correct FOV!"); return end 
    camera:SetFOV(fov)
end;

COMMAND:Register();

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CamSetMove");
COMMAND.tip = "Make the camera turn inbetween Dir and Move.";
COMMAND.text = "<string Name> <string Channel> <float turnSpeed>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 3;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local camera = searchCamera(arguments[1],arguments[2])
    if !IsValid(camera) then Clockwork.player:Notify(player, "This camera does not exist!"); return end 
    local speed = tonumber(arguments[3])
    if !speed then Clockwork.player:Notify(player, "Please provide a correct turn speed!"); return end 
    local targetPos = player:GetEyeTrace().HitPos
    local targetAngle = (targetPos-camera:GetCamPos()):Angle()
    camera.turnSpeed = speed
    camera.targetDir = camera:GetDirection()
    camera.targetDelta = targetAngle-camera:GetDirection()
end;

COMMAND:Register();
