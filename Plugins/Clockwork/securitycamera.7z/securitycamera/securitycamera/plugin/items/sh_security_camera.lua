local ITEM = Clockwork.item:New();
ITEM.name = "Security Camera";
ITEM.model = "models/props/cs_assault/camera.mdl";
ITEM.weight = 1;
ITEM.business = false;
ITEM.description = "Assembly kit for a security camera.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local trace = player:GetEyeTraceNoCursor();
	
	if (trace.HitPos:Distance( player:GetShootPos() ) <= 192) then

        Clockwork.dermaRequest:RequestString(player,"Name", "What would you like to set the security camera name to?", "", function(text)
            Clockwork.dermaRequest:RequestString(player,"Password", "What would you like to set the security camera password to?", "", function(text2)
            
            local counter = 0
            for k,v in pairs(ents.FindByClass("cw_security_cam")) do
                if v:GetPassword() == text2 then counter = counter + 1 end
            end
            if counter >= 9 then 
                Clockwork.player:Notify(player, "You can't have more than 9 cameras using the same password!");
                return false 
            end
            local entity = ents.Create("cw_security_cam");
            
            entity:SetPos(trace.HitPos + trace.HitNormal * 20);
            entity:Spawn();
            
            entity:SetCamName(text)
            entity:SetPassword(text2)

            
            end)
        end)

	else
		Clockwork.player:Notify(player, "You cannot create a security camera that far away!");
		
		return false;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();