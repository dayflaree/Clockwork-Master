local ITEM = Clockwork.item:New();
ITEM.name = "Security Hub";
ITEM.model = "models/props_combine/combine_intmonitor001.mdl";
ITEM.weight = 1;
ITEM.business = false;
ITEM.description = "Assembly kit for a security hub.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local trace = player:GetEyeTraceNoCursor();
	
	if (trace.HitPos:Distance( player:GetShootPos() ) <= 192) then

        Clockwork.dermaRequest:RequestString(player,"Password", "What would you like to set the security hub password to?", "", function(text)
            local entity = ents.Create("cw_security_hub");
            
            entity:SetPos(trace.HitPos + trace.HitNormal * 20);
            entity:Spawn();
            
            entity:SetPassword(text)
            

        end)
 
	else
		Clockwork.player:Notify(player, "You cannot create a security hub that far away!");
		
		return false;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();