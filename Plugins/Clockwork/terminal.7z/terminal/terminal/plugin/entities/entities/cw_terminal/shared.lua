
ENT.Type = "anim";
ENT.Author = "Thermadyle and Blt950";
ENT.PrintName = "Terminal";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.UsableInVehicle = true;
ENT.PhysgunDisabled = true;