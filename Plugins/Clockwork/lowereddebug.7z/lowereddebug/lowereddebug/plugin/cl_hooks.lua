--[[ 
    � 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html
--]]

local PLUGIN = PLUGIN;

function PLUGIN:Initialize()
	CW_CONVAR_VMPITCH = Clockwork.kernel:CreateClientConVar("cwVMPitch", 0, true, true);
	CW_CONVAR_VMROLL = Clockwork.kernel:CreateClientConVar("cwVMRoll", 0, true, true);
	CW_CONVAR_VMYAW = Clockwork.kernel:CreateClientConVar("cwVMYaw", 0, true, true);

	CW_CONVAR_ENABLEVMDEBUG = Clockwork.kernel:CreateClientConVar("cwEnableVMDebug", 0, true, true);
end;

function PLUGIN:GetWeaponLoweredViewInfo(itemTable, weapon, viewInfo)
	if (GetConVarNumber("cwEnableVMDebug") == 1) then
		viewInfo.angles = Angle(GetConVarNumber("cwVMPitch"), GetConVarNumber("cwVMYaw"), GetConVarNumber("cwVMRoll"));
	end;
end;