--[[ 
    � 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html
--]]

local PLUGIN = PLUGIN;

if (!PLUGIN.settingsAdded) then
	Clockwork.setting:AddCheckBox("Debug Viewmodel", "Use Viewmodel Debug", "cwEnableVMDebug", "Whether or not to use the convars to adjust viewmodel.");

	Clockwork.setting:AddNumberSlider("Debug Viewmodel", "1) Pitch:", "cwVMPitch", -100, 100, 2, "The pitch of the viewmodel.");
	Clockwork.setting:AddNumberSlider("Debug Viewmodel", "2) Yaw:", "cwVMYaw", -100, 100, 2, "The yaw of the viewmodel.");
	Clockwork.setting:AddNumberSlider("Debug Viewmodel", "3) Roll:", "cwVMRoll", -100, 100, 2, "The roll of the viewmodel.");

	PLUGIN.settingsAdded = true;
end;