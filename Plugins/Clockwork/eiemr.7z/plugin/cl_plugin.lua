local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:AddToSystem("[EIEMR] Hide Plugin Center MenuItem", "menuitem_hide_plugincenter", "Hides the Plugin Center MenuItem in Tab Navigation.", 0, 1, 0);
Clockwork.config:AddToSystem("[EIEMR] Hide Community MenuItem", "menuitem_hide_community", "Hides the Plugin Center MenuItem in Tab Navigation.", 0, 1, 0);
Clockwork.config:AddToSystem("[EIEMR] Skip Clockwork Intro", "skip_clockwork_intro", "Skips the Clockwork Introduction upon client join..", 0, 1, 0);