--[[
	Name: sh_auto.lua.
	Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sv_hooks.lua");