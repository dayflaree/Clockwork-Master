--[[
	Name: sh_info.lua.
	Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Class Doors";
PLUGIN.author = "";
PLUGIN.description = "Allows you to easily add doors that can only be opened by specific classes.";