Clockwork.config:AddToSystem("Context Menu Always", "context_menu_always", "Whether or not you can use the context menu without using your toolgun.");
