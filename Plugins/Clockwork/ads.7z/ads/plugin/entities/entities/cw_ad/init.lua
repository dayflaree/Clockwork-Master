AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

local PLUGIN = PLUGIN;

function ENT:SpawnFunction(player, trace, mode)
    if (!trace.Hit) then return; end;

    local entity = ents.Create("cw_ad");
    entity:Spawn();
    entity:Activate();
    entity:SetPos( trace.HitPos + trace.HitNormal * 32 + Vector(0, 0, 53) );
    entity:SetAngles( Angle(0, 0, 0) );
	entity.mode = mode;
	Clockwork.datastream:Start(player, "ad_data", mode)
	
	PLUGIN:SaveAds()

    return entity;
end;

function ENT:Initialize()
	self:SetModel("models/props/novabox/9by16ad.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()
	if phys:IsValid() then
		phys:Wake()
	end
end