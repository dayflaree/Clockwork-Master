include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

Clockwork.datastream:Hook("ad_data", function(data)
	dehmode = data
end)

function ENT:Initialize() 
	self.Map = vgui.Create("DHTML")
	self.Map:SetPos(0, 0)
	self.Map:SetSize(525, 1100)
	
	self.Map:SetVisible(true)
	
	self.Map:SetPaintedManually(true)
	
	local url = "http://gmod.novabox.org/ads/scroll/"
	self.Map:OpenURL( url )
end

function ENT:OnRemove()
	timer.Destroy(self:EntIndex() .. "_map")
end

function ENT:Draw()
	self:DrawModel()
	
	local min, max = self:OBBMins(), self:OBBMaxs()
	local offset = max - min
	
	local pos = self:GetPos() + (self:GetUp() * (offset.z * 0.5)) + (self:GetRight() * (-offset.y + 58)) + (self:GetForward() * (offset.x / 2.3))
	local ang = self:GetAngles() - Angle( 90, 0, 90 )
	
	ang:RotateAroundAxis(ang:Up(), -90)
	
	self.Map:SetPaintedManually(false)
	
	cam.Start3D2D(pos, ang, 0.2)
		self.Map:PaintManual()
	cam.End3D2D()
	
	self.Map:SetPaintedManually(true)
end