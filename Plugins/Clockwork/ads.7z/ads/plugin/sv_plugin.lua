local Clockwork = Clockwork;

local PLUGIN = PLUGIN;

-- A function to load the fields.
function PLUGIN:LoadAds()
	local fields = Clockwork.kernel:RestoreSchemaData("plugins/ads/"..game.GetMap());
	
	for k, v in pairs(fields) do
	
		Clockwork.datastream:Start("ad_data", v.mode)
		local entity = ents.Create("cw_ad");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		entity:Activate();
		entity.mode = v.mode;

		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
		
	end;
end;

-- A function to save the fields.
function PLUGIN:SaveAds()
	local fields = {};
	
	for k, v in pairs(ents.FindByClass("cw_ad")) do
		local position = v:GetPos();
		local angles = v:GetAngles();
		local mode = v.mode

		fields[#fields + 1] = {
			position = position,
			angles = angles,
			mode = mode
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/ads/"..game.GetMap(), fields);
end;