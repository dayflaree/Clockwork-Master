local COMMAND = Clockwork.command:New("createad");

COMMAND.tip = "Adds an ad relevant to the URL http://gmod.novabox.org/ads/, for example, /createadd banana would create an ad with http://gmod.novabox.org/ads/banana";
COMMAND.text = "<String/Num Ad>";
COMMAND.arguments = 1;
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	if (!trace.Hit) then return end
	local mode = arguments[1]

	local whychessnut = ents.Create("cw_ad");
	local entity = whychessnut:SpawnFunction(player, trace, mode)
	whychessnut:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added an the ad #"..mode..".");
	end;
end;

COMMAND:Register()