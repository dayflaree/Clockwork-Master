--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin.
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Medic Citizen Uniform";
ITEM.weight = 3;
ITEM.business = true;
ITEM.access = "T";
ITEM.protection = 0.6;
ITEM.description = "Shiny uniform of medic citizen.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return  "models/betacz/group03m/"..self:GetModelName(player);
end;

ITEM:Register();