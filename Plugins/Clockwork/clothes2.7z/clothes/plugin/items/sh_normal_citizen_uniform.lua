--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin.
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Normal Citizen Uniform";
ITEM.weight = 3;
ITEM.business = true;
ITEM.access = "T";
ITEM.protection = 0.3;
ITEM.description = "A little dirty uniform, which is usually given to the citizens with 0 LP.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return  "models/betacz/group02/"..self:GetModelName(player);
end;

ITEM:Register();