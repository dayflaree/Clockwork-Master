--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin.
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Chemical-resist Suit";
ITEM.weight = 3;
ITEM.business = true;
ITEM.access = "T";
ITEM.protection = 0.6;
ITEM.hasFlashlight = true;
ITEM.description = "Green suit with included gasmask and a flashlight.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return  "models/player/citizen_17.mdl";
end;

ITEM:Register();