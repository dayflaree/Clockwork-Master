--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin.
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Airex Male Uniform";
ITEM.weight = 3;
ITEM.business = true;
ITEM.access = "T";
ITEM.protection = 1;
ITEM.description = "Black male uniform with included gasmask.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	return  "models/player/airex_male.mdl";
end;

ITEM:Register();