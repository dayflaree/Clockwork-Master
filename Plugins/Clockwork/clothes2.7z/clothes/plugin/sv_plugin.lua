--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin. It IS free forever (or at least before the moment, when I'll decide to sell it.)
--]]

Clockwork.kernel:AddDirectory("materials/models/betacz/Female/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Female/Group01/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Female/Group02/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Female/Group03/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Female/Group03m/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Male/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Male/Group01/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Male/Group02/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Male/Group03/");
Clockwork.kernel:AddDirectory("materials/models/betacz/Male/Group03m/");
Clockwork.kernel:AddDirectory("models/betacz/Group01/");
Clockwork.kernel:AddDirectory("models/betacz/Group02/");
Clockwork.kernel:AddDirectory("models/betacz/Group03/");
Clockwork.kernel:AddDirectory("models/betacz/Group03m/");
Clockwork.kernel:AddDirectory("models/Humans/factory/");
Clockwork.kernel:AddDirectory("models/humans/apsci01/");