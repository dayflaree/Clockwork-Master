--[[
	� 2013 TheGarry =D.
	Feel free to use or share this plugin.
    Do not sell this plugin.
--]]

--Clockwork.animation:AddCombineOverwatchModel("models/iron_wall/combine_super_soldier.mdl");

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");