local PLUGIN = PLUGIN;

-- Called when the bars are needed.
function PLUGIN:GetBars(bars)
	local oxygen = Clockwork.Client:GetSharedVar("oxygen");
	
	if (oxygen < 100) then
		bars:Add("OXYGEN", Color(0, 216, 216, 255), "Oxygen", oxygen, 100, oxygen > 25, 1);
	end;
end;