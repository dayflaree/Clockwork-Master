local PLUGIN = PLUGIN;

surface.CreateFont( "ArialBig", {
font = "Arial",
size = 25,
weight = 500,
blursize = 0,
scanlines = 0,
antialias = true,
underline = false,
italic = false,
strikeout = false,
symbol = false,
rotary = false,
shadow = false,
additive = false,
outline = false
})

surface.CreateFont( "ArialNormal", {
font = "Arial",
size = 20,
weight = 500,
blursize = 0,
scanlines = 0,
antialias = true,
underline = false,
italic = false,
strikeout = false,
symbol = false,
rotary = false,
shadow = false,
additive = false,
outline = false
})

surface.CreateFont( "ArialSmall", {
font = "Arial",
size = 17,
weight = 500,
blursize = 0,
scanlines = 0,
antialias = true,
underline = false,
italic = false,
strikeout = false,
symbol = false,
rotary = false,
shadow = false,
additive = false,
outline = false
})

function oxygenhud()
local client = LocalPlayer()
local tankIcon = Material("catiwis/oxygen/tank.png")
local fullIcon = Material("catiwis/oxygen/full.png")
local threeQuarterIcon = Material("catiwis/oxygen/threequarter.png")
local halfIcon = Material("catiwis/oxygen/half.png")
local quarterIcon = Material("catiwis/oxygen/quarter.png")
local tankOxy = Clockwork.Client:GetSharedVar("tankoxygen")
local hasTank = Clockwork.Client:GetSharedVar("hastank")


	if (client:Alive() and hasTank == 1) then
		surface.SetMaterial(tankIcon)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(ScrW() - 100,ScrH() - 700,60,130)
		if (tankOxy >= 75) then
			surface.SetMaterial(fullIcon)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(ScrW() - 100,ScrH() - 700,60,130)
		elseif (tankOxy >= 50 and tankOxy < 75) then
			surface.SetMaterial(threeQuarterIcon)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(ScrW() - 100,ScrH() - 700,60,130)
		elseif (tankOxy >= 25 and tankOxy < 50) then
			surface.SetMaterial(halfIcon)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(ScrW() - 100,ScrH() - 700,60,130)
		elseif (tankOxy > 0 and tankOxy < 25) then
			surface.SetMaterial(quarterIcon)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(ScrW() - 100,ScrH() - 700,60,130)
		end
		
		draw.SimpleText( "O", "ArialBig", ScrW() - 65,ScrH() - 660, Color(255,255,255,255),2,0)
		draw.SimpleText( "2", "ArialSmall", ScrW() - 56,ScrH() - 653, Color(255,255,255,255),2,0)
		draw.SimpleText( tankOxy.."%", "ArialNormal", ScrW() - 51,ScrH() - 630, Color(255,255,255,255),2,0)
	end
end
hook.Add("HUDPaint", "oxygenhud", oxygenhud)