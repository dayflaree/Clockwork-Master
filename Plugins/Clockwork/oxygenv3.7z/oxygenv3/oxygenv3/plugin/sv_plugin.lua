
local PLUGIN = PLUGIN;

-- A function to load the air compressors.
function PLUGIN:LoadCompressors()
	local compressors = Clockwork.kernel:RestoreSchemaData("plugins/oxygen/"..game.GetMap());
	
	for k, v in pairs(compressors) do
		local entity = ents.Create("cw_compressor");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();

		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
	end;
end;

-- A function to save the air compressors.
function PLUGIN:SaveCompressors()
	local compressors = {};
	
	for k, v in pairs(ents.FindByClass("cw_compressor")) do
		local position = v:GetPos();
		local angles = v:GetAngles();

		compressors[#compressors + 1] = {
			position = position,
			angles = angles,
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/oxygen/"..game.GetMap(), compressors);
end;