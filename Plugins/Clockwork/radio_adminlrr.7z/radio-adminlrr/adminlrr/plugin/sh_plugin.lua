
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.flag:Add("M", "MOBCOMM", "Access to the /lrr command.");

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");