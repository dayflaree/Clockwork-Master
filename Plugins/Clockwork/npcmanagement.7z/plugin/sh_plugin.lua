PLUGIN:SetGlobalAlias("cwS7NPCManagement");

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

cwS7NPCManagement.npcSpawnpoints = {};
cwS7NPCManagement.npcNoSpawnpoints = {};

// This plugin was made by alyousha35 for Sigma 7 Phase Four. It's unfinished/broken, but serves as a good base for a P4 PVE system.