--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local COMMAND = Clockwork.command:New("NPCSafeZoneAdd");
COMMAND.tip = "Add an NPC nospawn point at your target position. DO NOT USE UNLESS YOU KNOW EXACTLY HOW THIS WORKS!";
COMMAND.text = "<string npctype>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)

    cwS7NPCManagement.npcNoSpawnpoints = cwS7NPCManagement.npcNoSpawnpoints or {};
    cwS7NPCManagement.npcNoSpawnpoints[#cwS7NPCManagement.npcNoSpawnpoints + 1] = {position = player:GetEyeTraceNoCursor().HitPos};
    cwS7NPCManagement:SaveNPCNoSpawnpoints();
    
    Clockwork.player:Notify(player, "You have added an npc safe spot.");
end;

COMMAND:Register();