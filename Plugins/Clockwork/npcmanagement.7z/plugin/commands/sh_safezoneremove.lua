--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local COMMAND = Clockwork.command:New("NPCSafeZoneRemove");
COMMAND.tip = "Remove NPC nospawn points at your target position.";
COMMAND.text = "<string npc type>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	

    if (cwS7NPCManagement.npcNoSpawnpoints) then
        local position = player:GetEyeTraceNoCursor().HitPos;
        local removed = 0;
        
        for k, v in pairs(cwS7NPCManagement.npcNoSpawnpoints) do
            if (v.position:Distance(position) <= 256) then
                cwS7NPCManagement.npcNoSpawnpoints[k] = nil;
                
                removed = removed + 1;
            end;
        end;
        
        if (removed > 0) then
            if (removed == 1) then
                Clockwork.player:Notify(player, "You have removed a nospawn npc point.");
            else
                Clockwork.player:Notify(player, "You have removed "..removed.." npc nospawn points.");
            end;
        else
            Clockwork.player:Notify(player, "There were no npc nospawn points near this position.");
        end;
    else
        Clockwork.player:Notify(player, "There are no nospawn points.");
    end;
    
    cwS7NPCManagement:SaveNPCNoSpawnpoints();
end;

COMMAND:Register();