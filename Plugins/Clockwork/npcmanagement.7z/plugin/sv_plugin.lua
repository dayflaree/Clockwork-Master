cwS7NPCManagement.HoboModels = {
	"models/Humans/Group02/Female_02.mdl",
    "models/Humans/Group02/Female_04.mdl",
    "models/Humans/Group02/Female_07.mdl",
    "models/Humans/Group02/male_02.mdl",
    "models/Humans/Group02/Male_04.mdl",
    "models/Humans/Group02/male_06.mdl",
    "models/Humans/Group02/male_08.mdl"
};


-- A function to load the npc spawn zones.
function cwS7NPCManagement:LoadNPCSpawnpoints()
	cwS7NPCManagement.npcSpawnpoints =  Clockwork.kernel:RestoreSchemaData("plugins/mobspawnpoints/"..game.GetMap());
end;

-- A function to save the npc spawn zones.
function cwS7NPCManagement:SaveNPCSpawnpoints()
	local npcspawnpoints = {};
	
	for k, v in pairs(cwS7NPCManagement.npcSpawnpoints) do
		npcspawnpoints[#npcspawnpoints + 1] = {
            position = v.position,
            npctype = v.npctype,
            rotate = v.rotate
        };
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/mobspawnpoints/"..game.GetMap(), npcnospawnpoints);
    cwS7NPCManagement:RespawnNPCs()
end;

-- A function to load the npc nospawn zones.
function cwS7NPCManagement:LoadNPCNoSpawnpoints()
	cwS7NPCManagement.npcNoSpawnpoints =  Clockwork.kernel:RestoreSchemaData("plugins/npcnospawnpoints/"..game.GetMap());
end;

-- A function to save the npc nospawn zones.
function cwS7NPCManagement:SaveNPCNoSpawnpoints()
	local npcnospawnpoints = {};
	
	for k, v in pairs(cwS7NPCManagement.npcNoSpawnpoints) do
		npcnospawnpoints[#npcnospawnpoints + 1] = {
            position = v.position
        };
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/npcnospawnpoints/"..game.GetMap(), npcnospawnpoints);
    cwS7NPCManagement:RespawnNPCs()
end;

-- A function to respawn NPCs.
function cwS7NPCManagement:RespawnNPCs()
	for k, v in pairs(cwS7NPCManagement.npcSpawnpoints) do
        if !cwS7NPCManagement:IsNPCLimit() then
            if v.npctype == "hobo" then
                local npcspawn = ents.Create("npc_citizen");
                local health = 75;
                npcspawn:SetModel( cwS7NPCManagement.HoboModels[ math.random(1, #cwS7NPCManagement.HoboModels) ] );
                npcspawn:SetPos(v.position);
                npcspawn:SetKeyValue("spawnflags", SF_NPC_ALWAYSTHINK + SF_NPC_START_EFFICIENT);
                npcspawn:SetHealth(health);
                npcspawn.baddie = true;
                npcspawn.cash = health;
                npcspawn.currentspawned = v.currentspawned;
                npcspawn:Spawn();
                npcspawn:Activate();
                local chance = math.random(1,100);
                if chance >= 90 then
                    npcspawn:Give( "swep_ai_glock" );
                    npcspawn.cash = math.random(200,500)
                else
                    npcspawn:Give( "weapon_crowbar" );
                end;
            end;
        end;
	end;
end;

function cwS7NPCManagement:NPCSay(npc, text, yell)
    local name = (v:GetNetworkedString("cw_Name") or ("NPC"));
    local radius = (Clockwork.config:Get("talk_radius"):Get() * 2);
    if (yell) then
        local radius = (Clockwork.config:Get("talk_radius"):Get() * 4);
    end;
	local listeners = {};
    local say = name.." says:"..text
	
	for k, v in pairs(cwPlayer.GetAll()) do
		if (v:HasInitialized()) then
			if (position:Distance(v:GetPos()) <= radius) then
				listeners[#listeners + 1] = v;
			end;
		end;
	end;
	
	Clockwork.player:Notify(listeners, say);
end;

function cwS7NPCManagement:NPCReplyRadio(npc, text, yell)
    for k, v in pairs(ents.FindByClass("npc_*")) do
        if (v.police) and (v != npc) then
            cwS7NPCManagement:NPCSay(v, text, yell)
        end;
    end;
end;

function cwS7NPCManagement:IsNPCLimit()
    local amount = 0;
    for k, v in pairs(ents.FindByClass("npc_*")) do
        amount = amount + 1;
    end;
    if amount >= 30 then
        return true
    else
        return false
    end
end;

function cwS7NPCManagement:SetRelations() 
    for k, f in pairs(ents.FindByClass("npc_*")) do
        if (f.currentspawned) then
            for k, p in pairs(player.GetAll()) do
                if IsValid(f) and IsValid(p) then
                    f:AddEntityRelationship(p, D_HT)
                end
            end
        end
	end
end;

-- Called when a player dies.
function cwS7NPCManagement:PlayerDeath(player, inflictor, attacker, damageInfo)
    if player.fugitive and attacker:IsNPC() and attacker.police then
        cwS7NPCManagement:NPCSay(attacker, "Suspect "..player:Name().." has been neutralized.", false)
        cwS7NPCManagement:NPCReplyRadio(attacker, "Copy that.", false)
    end;
	player.fugitive = false;
end;
        

function cwS7NPCManagement:OnNPCKilled(npc, attacker, inflictor)
    if npc.cash then
        local entity = Clockwork.entity:CreateCash(nil, npc.cash, npc:GetPos());
		if (IsValid(entity)) then
            entity.DroppedByNPC = true;
        end;
    end;
end;
        