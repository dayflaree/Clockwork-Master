function cwS7NPCManagement:ClockworkInitPostEntity()
    self:LoadNPCSpawnpoints()
    self:LoadNPCNoSpawnpoints()
end;

-- Called just after data should be saved.
function cwS7NPCManagement:PostSaveData()
    self:LoadNPCSpawnpoints()
    self:LoadNPCNoSpawnpoints()
end;