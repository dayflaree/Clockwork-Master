MsgN("Loaded Clockwork Toolguns v1.03 by Tru")
MsgN("Added: Minor Edits, Color to text")
MsgN("http://forums.cloudsixteen.com/index.php?topic=4383")