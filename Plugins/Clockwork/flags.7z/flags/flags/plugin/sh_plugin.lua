PLUGIN.userGroups = {};
PLUGIN.userGroups["founder"] = "petrcCn";
PLUGIN.userGroups["superadmin"] = "petrcCn";
PLUGIN.userGroups["admin"] = "petrc";
PLUGIN.userGroups["operator"] = "petrc";
PLUGIN.resetList = "";

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");