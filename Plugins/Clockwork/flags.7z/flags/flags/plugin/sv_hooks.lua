local PLUGIN = PLUGIN;

-- Called when Clockwork has initialized.
function PLUGIN:ClockworkInitialized()
	for k, v in pairs(self.userGroups) do
		for i = 1, #v do
			local flag = string.sub(v, i, i);

			if (!string.find(self.resetList, flag)) then
				self.resetList = self.resetList..flag;
			end;
		end;
	end;
end;

-- Called when a player's character has initialized.
function PLUGIN:PlayerCharacterInitialized(player)
	local flagList = Clockwork.config:Get("default_flags"):Get();
	local flags = player:GetFlags();
	local userGroup = player:GetUserGroup();

	if (self.userGroups[userGroup]) then
		flagList = flagList..self.userGroups[userGroup];
	end;

	Clockwork.player:TakeFlags(player, self.resetList);
	Clockwork.player:GiveFlags(player, flagList);
end;