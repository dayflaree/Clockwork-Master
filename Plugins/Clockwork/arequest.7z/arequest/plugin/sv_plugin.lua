

Clockwork.config:Add("ar_request_interval", 10);
