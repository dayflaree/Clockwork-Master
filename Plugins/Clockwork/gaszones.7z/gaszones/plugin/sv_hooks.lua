
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;
local CurTime = CurTime;

PLUGIN.notifyTicks = 3;

local math = math;

function PLUGIN.OnGasTick(player, id, gasScale)
	if (gasScale > 0) then
		if (player.gasNotified != 0 and player.gasNotified < PLUGIN.notifyTicks) then
			player.gasNotified = player.gasNotified + 1;
			return;
		elseif (player.gasNotified == PLUGIN.notifyTicks) then
			if (player:GetFilterQuality() == 0) then
				Clockwork.player:Notify(player, "You begin to choke on the gas. Going in here definitely wasn't a good idea.");
			end;
			player.gasNotified = player.gasNotified + 1;
		end;

		local playerGasDamageScale = 1;
		local filterQuality = player:GetFilterQuality();
		if (filterQuality > 0) then
			local filterDecrease = gasScale * PLUGIN.gasTickTime * Clockwork.config:Get("gas_filter_scale"):Get();
			if (filterQuality > filterDecrease) then
				player:UpdateFilterQuality(-filterDecrease);
				playerGasDamageScale = 0;
			else
				player:SetFilterQuality(0);
				-- Scale protection received based on how much was still left
				playerGasDamageScale = math.Clamp(1 - (filterQuality / filterDecrease), 0, 1);
				Clockwork.player:Notify(player, "Your gasmask's filter has run out!");
			end;
		end;

		if (playerGasDamageScale > 0) then
			local damage = playerGasDamageScale * gasScale * PLUGIN.gasTickTime * Clockwork.config:Get("gas_damage"):Get();
			player:SetHealth(math.max(player:Health() - damage, 0));

			if (player:Health() == 0) then
				Clockwork.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." was killed by gas.");
				player:Kill();
			end;
		end;
	end;
end;

function PLUGIN.OnGasChange(player, id, oldScale, newScale)
	if (newScale > 0 and (!player.gasNotified or player.gasNotified == 0)) then
		player.gasNotified = 1;
		if (player:GetFilterQuality() > 0) then
			Clockwork.player:Notify(player, "You can faintly smell toxic gas through your mask.");
		else
			Clockwork.player:Notify(player, "You can smell some odd toxic gas. Maybe you shouldn't go in here.");
		end;
	elseif (newScale == 0 and player.gasNotified != 0) then
		player.gasNotified = 0;
		Clockwork.player:Notify(player, "The smell of gas fades away as you leave its source behind.");
	end;
end;