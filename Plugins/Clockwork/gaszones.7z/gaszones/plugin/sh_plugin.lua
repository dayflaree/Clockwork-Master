
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

if (SERVER) then
	PLUGIN.gasTickTime = 2;
else
	PLUGIN.gasTickTime = 1;
end;

-- Change this to true to make zone checks run clientside.
-- This may improve performance if there are a lot of players/zones by lowering cpu load
-- (note that it may also lower performance due to increased networking)
PLUGIN.clientside = false;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");

function PLUGIN:RegisterZones()
	Schema:RegisterZone("GasZone", "Gas Zone", PLUGIN.gasTickTime,
		{bUseExclusionAreas = true, bZoneScale = true, bIsClientSide = PLUGIN.clientside,
		bShared = PLUGIN.clientside, bSharedVar = false, bPlayerOnly = false,
		funcOnTick = PLUGIN.OnGasTick, funcOnChange = PLUGIN.OnGasChange, funcShouldCheck = PLUGIN.ShouldCheckGas,
		areaColor = Color(255, 0, 0), exclusionColor = Color(0, 255, 0)});
end;

function PLUGIN.ShouldCheckGas(player, id)
	return (player:Alive() and !Clockwork.player:GetFactionTable(player).noGas);
end;