
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:Add("gas_damage", 5); -- The amount of gas gained every second
Clockwork.config:Add("gas_filter_scale", 1) -- How fast filters drain, 1 = 30 minutes

Clockwork.hint:Add("Gas", "Some areas contain a lethal gas! Better watch out where you go.");
Clockwork.hint:Add("Gasmask", "A gasmask with a filter will keep the gas out.");