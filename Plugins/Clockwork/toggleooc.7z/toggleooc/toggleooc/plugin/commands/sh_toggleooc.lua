
-----------------------------------------------------
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("ToggleOOC");
COMMAND.tip = "Toggle whether or not OOC chat is enabled.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local ooc = Clockwork.config:Get("ooc_enabled");

	if (ooc:Get()) then
		ooc:Set(false);
		Clockwork.player:NotifyAll(player:Name().." has disabled OOC chat.");
	else
		ooc:Set(true);
		Clockwork.player:NotifyAll(player:Name().." has enabled OOC chat.");
	end;
end;

COMMAND:Register();