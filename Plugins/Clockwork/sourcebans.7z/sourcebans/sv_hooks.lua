--[[
Name: "sv_hooks.lua".
Author: Snazzy.
--]]

local PLUGIN = PLUGIN;
