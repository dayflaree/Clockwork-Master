--[[
Name: "sh_info.lua".
Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "SourceBans for openAura";
PLUGIN.author = "";
PLUGIN.description = "A global ban system for all your servers.";