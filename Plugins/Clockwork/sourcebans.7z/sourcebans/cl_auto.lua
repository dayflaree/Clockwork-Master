--[[
Name: "cl_auto.lua".
Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_auto.lua");