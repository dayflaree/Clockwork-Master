--[[
Name: "sh_auto.lua".
Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

openAura:IncludePrefixed("sh_coms.lua");
openAura:IncludePrefixed("sv_hooks.lua");