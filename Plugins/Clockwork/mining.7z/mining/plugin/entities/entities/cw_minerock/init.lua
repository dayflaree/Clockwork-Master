AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

function ENT:SpawnFunction(player, trace)
    if (!trace.Hit) then return; end;

    local entity = ents.Create("cw_minerock");
    entity:Spawn();
    entity:Activate();
    entity:SetPos( trace.HitPos + trace.HitNormal * 32 + Vector(0, 0, 53) );
    entity:SetAngles( Angle(0, 0, 0) );

    return entity;
end;

function ENT:Initialize()
	local modelrock = math.random( 1, 3 )
	if ( modelrock == 1 ) then
		self:SetModel("models/props_canal/rock_riverbed02a.mdl")
	elseif ( modelrock == 2 ) then
		self:SetModel("models/props_canal/rock_riverbed02b.mdl")
	elseif ( modelrock == 3 ) then
		self:SetModel("models/props_canal/rock_riverbed02c.mdl")
	end
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetMaxHealth( 5 )
	self:SetHealth( 5 )
	local phys = self:GetPhysicsObject()
	if phys:IsValid() then
		phys:Wake()
	end
end

function ENT:OnTakeDamage()
	if self:IsValid() then
		self:SetHealth( self:Health() - 1 )
		if (self:Health() <= 0) then
			local phys = self:GetPhysicsObject()
			phys:EnableCollisions( false )
			if ( math.random( 1, 2 ) == 1 ) then
				Clockwork.entity:CreateItem(nil, Clockwork.item:CreateInstance("rock"), self:GetPos());
			else
				Clockwork.entity:CreateItem(nil, Clockwork.item:CreateInstance("crude_ore"), self:GetPos());
			end
			CreateSound(self.Entity, "physics/concrete/concrete_break2.wav"):Play()
			CreateSound(self.Entity, "physics/concrete/concrete_break1.wav"):Play()
			CreateSound(self.Entity, "ambient/materials/rock5.wav"):Play()
			self:Remove()
		end
	end
end