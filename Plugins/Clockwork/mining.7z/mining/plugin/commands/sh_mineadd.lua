local COMMAND = Clockwork.command:New("miningrockadd");

COMMAND.tip = "Adds a mining rock add your crosshair.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	if (!trace.Hit) then return end

	local whychessnut = ents.Create("cw_minerock");
	local entity = whychessnut:SpawnFunction(player, trace)
	whychessnut:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a mining rock.");
	end;
end;

COMMAND:Register()