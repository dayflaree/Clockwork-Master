local ITEM = Clockwork.item:New();
ITEM.name = "Crude Ore";
ITEM.uniqueID = "crude_ore";
ITEM.model = "models/props_debris/concrete_spawnchunk001d.mdl";
ITEM.weight = 3;
ITEM.category = "Crafting Resource";
ITEM.business = false;
ITEM.description = "A heavy rock with veins of ore running through it. <color='2B62E3'>This item is legal.</color>";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_pipes/GutterMetal01a");
end;

ITEM:Register();