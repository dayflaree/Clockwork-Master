local ITEM = Clockwork.item:New();
ITEM.name = "Rock";
ITEM.uniqueID = "rock";
ITEM.model = "models/props_debris/concrete_spawnchunk001b.mdl";
ITEM.weight = 1;
ITEM.category = "Crafting Resource";
ITEM.business = false;
ITEM.description = "A chunk of rock from a boulder. Absolutely worthless. <color='2B62E3'>This item is legal.</color>";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();