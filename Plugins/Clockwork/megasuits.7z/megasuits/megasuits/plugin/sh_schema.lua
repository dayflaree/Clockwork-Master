local PLUGIN = PLUGIN;

Clockwork.flag:Add("U", "Mega Suits", "Access to full uniforms on the Business Menu");
