local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Worker Uniform";
ITEM.model = "models/props_c17/TrapPropeller_Engine.mdl";
ITEM.cost = 400;
ITEM.weight = 2;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.3;
ITEM.replacement = "models/humans/group03m/male_116.mdl";
ITEM.description = "A stained welding uniform. It comes with a mask, a utility vest and a messenger bag.";

ITEM:Register();
