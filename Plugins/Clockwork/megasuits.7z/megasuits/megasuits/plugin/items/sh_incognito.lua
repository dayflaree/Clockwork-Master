local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Incognito Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 2000;
ITEM.weight = 5;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.1;
ITEM.replacement = "models/barnes/refugee/male_100.mdl";
ITEM.description = "The case is brown and dusty. Must only be worn by the true invisible; the true master of stealth and espionage.";

ITEM:Register();
