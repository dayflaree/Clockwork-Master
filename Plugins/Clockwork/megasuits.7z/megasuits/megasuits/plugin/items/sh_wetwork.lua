local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Wetwork Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 1000;
ITEM.weight = 7;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 2;
ITEM.replacement = "models/barnes/refugee/male_79.mdl";
ITEM.description = "A combat suit used by special forces of the resistance.";

ITEM:Register();
