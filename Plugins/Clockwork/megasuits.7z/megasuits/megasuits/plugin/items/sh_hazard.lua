local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Hazard Uniform";
ITEM.model = "models/props_c17/SuitCase_Passenger_Physics.mdl";
ITEM.cost = 500;
ITEM.weight = 5;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.5;
ITEM.replacement = "models/humans/group03/male_118.mdl";
ITEM.description = "A lambda-modded OTA uniform, complete with a SWAT helmet and gas mask.";

ITEM:Register();
