local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Juggernaut Uniform";
ITEM.model = "models/Combine_Helicopter/helicopter_bomb01.mdl";
ITEM.cost = 2000;
ITEM.weight = 8;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 1;
ITEM.replacement = "models/humans/group03/reno.mdl";
ITEM.description = "A grey bulk suit. It includes a ceramic plate carrier, armoured shoulder and knee pads, and a repurposed MPF mask.";

ITEM:Register();
