local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Pilot Uniform";
ITEM.model = "models/props_junk/cardboard_box002b.mdl";
ITEM.cost = 1000;
ITEM.weight = 3;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.3;
ITEM.replacement = "models/humans/group03m/male_hc.mdl";
ITEM.description = "A bulky pilot suit. It includes a visor with a heads-up display, an arm PDA, and a trenchcoat.";

ITEM:Register();
