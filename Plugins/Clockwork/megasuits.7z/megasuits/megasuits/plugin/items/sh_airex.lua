local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Air Exchange Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 100;
ITEM.weight = 5;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0;
ITEM.replacement = "models/humans/airex/airex_male.mdl";
ITEM.description = "A cititzen uniform distributed to those who live in harsh conditions. It includes a gas mask, a canteen, and winter wear.";

ITEM:Register();
