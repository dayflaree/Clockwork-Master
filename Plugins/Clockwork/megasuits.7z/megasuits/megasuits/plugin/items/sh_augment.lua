local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Augmentation Kit";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 10,000;
ITEM.weight = 10;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 9;
ITEM.replacement = "models/rexlee9000.mdl";
ITEM.description = "A suspicious black case carrying some sort of uniform, a headset, and a stimpack. Injecting it would suddenly produce painful bodily changes.";

ITEM:Register();
