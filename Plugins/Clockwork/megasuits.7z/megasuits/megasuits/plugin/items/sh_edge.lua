local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Undercover Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 900;
ITEM.weight = 5;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 1;
ITEM.replacement = "models/humans/group03/male_79.mdl";
ITEM.description = "A plain high-ranking MPF suit with a trench coat wrapped around it.";

ITEM:Register();
