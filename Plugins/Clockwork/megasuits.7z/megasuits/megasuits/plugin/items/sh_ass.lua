local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Assasin Suit";
ITEM.model = "models/Combine_Helicopter/helicopter_bomb01.mdl";
ITEM.cost = 5000;
ITEM.weight = 1;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.5;
ITEM.replacement = "models/thespectator/atsushi8.mdl";
ITEM.description = "A skin-tight movement suit meant for female wearers. Designed for stealth and light footing. Wearing by males is inadvisable.";

ITEM:Register();
