local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Ghillie Suit";
ITEM.model = "models/props_c17/SuitCase_Passenger_Physics.mdl";
ITEM.cost = 100;
ITEM.weight = 0.3;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 0.1;
ITEM.replacement = "models/humans/group03/suit_gh.mdl";
ITEM.description = "A green sweater/pants combination woven with hanging burlap sacks, meant to conceal the wearer with flora.";

ITEM:Register();
