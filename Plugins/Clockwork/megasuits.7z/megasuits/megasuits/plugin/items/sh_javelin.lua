local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Javelin Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 3000;
ITEM.weight = 10;
ITEM.business = true;
ITEM.access = "U";
ITEM.useText = "Wear";
ITEM.category = "Uniforms";
ITEM.protection = 5;
ITEM.replacement = "models/javelin_unit.mdl";
ITEM.description = "A jet black metropolice suit that is very mysterious, much like it's origins.";

ITEM:Register();
