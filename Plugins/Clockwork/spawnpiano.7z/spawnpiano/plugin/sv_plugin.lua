local PLUGIN = PLUGIN;

	
	local spawnData = {	
		[ "gmt_instrument_piano" ] = {	
			[ "rp_industrial17_beta9" ] = {
			
				{ Vector( 5508.812500, 5440.843750, 336.656250 ), Angle( 0, 0, 0 ) }
				
			},
			[ "gm_construct" ] = {
			
				{ Vector( 797.343750, 74.625000, -142.468750 ), Angle( 0, 0, 0 ) }
				
			}
		}
	}

	local function SpawnEntities( pl )
		if not pl or pl:IsAdmin() then
			for class, _ in pairs( spawnData ) do
				for _, panel in pairs( ents.FindByClass( class ) ) do					
					panel:Remove()
				end
			end

			timer.Simple( 1, function()				
				for class, maps in pairs( spawnData ) do
					local spawns = maps[ game.GetMap() ]
					if spawns then
						for _, data in pairs( spawns ) do
							local ent = ents.Create( class )
							
							if (IsValid(ent)) then
								ent:SetPos( data[1] )
								ent:SetAngles( data[2] )
								ent:Spawn()
							end
						end
					end
				end
			end )
		end
	end
	hook.Add( "InitPostEntity", "pianos_spawn", SpawnEntities )
	concommand.Add( "reload_pianos", SpawnEntities )
