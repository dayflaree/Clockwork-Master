--[[
	Name: cl_hooks.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;
