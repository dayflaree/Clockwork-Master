local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PMOOC");
COMMAND.tip = "Send a private message to a player using his steam name.";
COMMAND.text = "<string Steam Name> <string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(ply, arguments)
	local target = nil;
	
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized() and (v:SteamID() == arguments[1] or v:UniqueID() == arguments[1]
		or string.find(string.lower(v:SteamName()), string.lower(arguments[1]), 1, true))) then
			target = v;
		end;
	end;
	
	if (target) then
		local voicemail = target:GetCharacterData("Voicemail");
		
		if (voicemail and voicemail != "") then
			Clockwork.chatBox:Add(ply, target, "pm", voicemail);
		else
			Clockwork.chatBox:Add({ply, target}, ply, "pm", table.concat(arguments, " ", 2));
		end;
	else
		Clockwork.player:Notify(ply, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();