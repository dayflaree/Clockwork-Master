
ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "Gr4Ss";
ENT.PrintName = "Cache";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.PhysgunDisabled = true;