
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local game = game;
local math = math;

Clockwork.config:Add("max_cache_weight", 15, true); -- The maximum amount of weight that can be stored in a cache

-- A function to save the storage.
function PLUGIN:SaveCaches()
	local caches = {};
	
	for k, cache in pairs(self.caches) do
		if (!IsValid(cache)) then
			self.caches[k] = nil;
			continue;
		end;
		
		caches[#caches + 1] = {
			position = cache:GetPos(),
			angles = cache:GetAngles(),
			name = cache:GetNetworkedString("Name"),
			model = cache:GetModel()
		};
	end;

	Clockwork.kernel:SaveSchemaData("plugins/caches/"..game.GetMap(), caches);
end;

-- A function to load the storage.
function PLUGIN:LoadCaches()
	self.caches = {};
	
	local caches = Clockwork.kernel:RestoreSchemaData("plugins/caches/"..game.GetMap());
	
	for k, v in pairs(caches) do
		local cache = ents.Create("cw_cache");
		cache:SetAngles(v.angles);
		cache:SetPos(v.position);
		cache:Spawn();
		cache:GetPhysicsObject():EnableMotion(false);
		
		cache:SetCacheModel(v.model);
		cache:SetNetworkedString("Name", v.name);
		
		self.caches[#self.caches + 1] = cache;
	end;
end;

-- Returns if the player is a donator (that can use a cache).
function PLUGIN:PlayerIsDonator(player)
	return player.cwDonation != nil;
end;

-- Returns if a player's cache is not empty.
function PLUGIN:PlayerCacheNotEmpty(player)
	return player:GetCharacterData("CacheItems") != nil or player:GetCharacterData("CacheCash") != nil;
end;

-- Returns if the player can interact with a cache.
function PLUGIN:PlayerCanUseCache(player)
	local factionTable = Clockwork.player:GetFactionTable(player);
	return self:PlayerIsDonator(player) or self:PlayerCacheNotEmpty(player) or factionTable.canUseCache;
end;

-- Returns the maximum weight a cache should hold.
function PLUGIN:GetPlayerCacheWeight(player)
	local weight = 1;
	if (self:PlayerIsDonator(player)) then
		weight = math.max(Clockwork.config:Get("max_cache_weight"):Get(), weight);
	end;

	local factionTable = Clockwork.player:GetFactionTable(player);
	if (factionTable.canUseCache) then
		weight = math.max(factionTable.cacheWeight or 15, weight);
	end;

	return weight;
end;

-- Returns if a cache should be one sided.
function PLUGIN:GetIsPlayerCacheOneSided(player)
	local factionTable = Clockwork.player:GetFactionTable(player);
	return !self:PlayerIsDonator(player) and !factionTable.canUseCache;
end;


function PLUGIN.OnGiveCacheCash(target, storageTable, cash)
	target:SetCharacterData("CacheCash", storageTable.cash);
end;


function PLUGIN.OnTakeCacheCash(target, storageTable, cash)
	if (storageTable.cash > 0) then
		target:SetCharacterData("CacheCash", storageTable.cash);
	else
		target:SetCharacterData("CacheCash", nil);
	end;

	if (!PLUGIN:PlayerIsDonator(target) and !PLUGIN:PlayerCacheNotEmpty(target)) then
		return true;
	end;
end;


function PLUGIN.OnGiveCacheItem(target, storageTable, itemTable, player)
	player = player or target;

	if (player:GetCharacterData("clothes") == itemTable.index) then
		if (!player:HasItemByID(itemTable.index)) then
			player:SetCharacterData("clothes", nil);
			
			if (itemTable.OnChangeClothes) then
				itemTable:OnChangeClothes(player, false);
			end;
		end;
	end;

	target:SetCharacterData("CacheItems", storageTable.inventory);
end;


function PLUGIN.OnTakeCacheItem(target, storageTable, itemTable)
	if (table.Count(storageTable.inventory[itemTable("uniqueID")]) == 0) then
		storageTable.inventory[itemTable("uniqueID")] = nil;
	end;
	
	if (table.Count(storageTable.inventory) > 0) then
		target:SetCharacterData("CacheItems", storageTable.inventory);
	else
		target:SetCharacterData("CacheItems", nil);
	end;

	if (!PLUGIN:PlayerCanUseCache(target)) then
		return true;
	end;
end;

function PLUGIN.OnCacheClose(target, storageTable, entity)
	if (!IsValid(target)) then
		return;
	end;

	if (!PLUGIN:PlayerCacheNotEmpty(target)) then
		target:SetCharacterData("CacheName", nil);
		target:SetSharedVar("CacheName", "");
	end;

	target:SetSharedVar("CanUseCache", PLUGIN:PlayerCanUseCache(target));
end;