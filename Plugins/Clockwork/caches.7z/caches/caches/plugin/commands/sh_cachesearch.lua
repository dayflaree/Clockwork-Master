
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CacheSearch");
COMMAND.tip = "Searches a character's cache.";
COMMAND.text = "[string Name]"
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		if (!PLUGIN:PlayerCanUseCache(player)) then
			Clockwork.player:Notify(player, target:Name().." cannot use a cache.");
			return;
		end;

		local entity = ents.FindByClass("cw_cache")[1];
		if (!entity) then
			Clockwork.player:Notify(player, "There are no caches spawned!");
			return;
		end;

		local cash = target:GetCharacterData("CacheCash", 0);
		local inventory = target:GetCharacterData("CacheItems", {});
		local weight = PLUGIN:GetPlayerCacheWeight(target);
		local isOneSided = PLUGIN:GetIsPlayerCacheOneSided(target);
	
		Clockwork.storage:Open(player, {
			name = target:Name().."'s Cache",
			entity = entity,
			weight = weight,
			isOneSided = isOneSided,
			cash = cash,
			inventory = inventory,
			OnGiveCash = function(player, storageTable, cash)
				return PLUGIN.OnGiveCacheCash(target, storageTable, cash);
			end,
			
			OnTakeCash = function(player, storageTable, cash)
				return PLUGIN.OnTakeCacheCash(target, storageTable, cash);
			end,

			OnGiveItem = function(player, storageTable, itemTable)
				return PLUGIN.OnGiveCacheItem(target, storageTable, itemTable, player);
			end,

			OnTakeItem = function(player, storageTable, itemTable)
				return PLUGIN.OnTakeCacheItem(target, storageTable, itemTable);
			end,

			OnClose = function(player, storageTable, entity)
				PLUGIN.OnCacheClose(target, storageTable, entity)
			end
		});
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();