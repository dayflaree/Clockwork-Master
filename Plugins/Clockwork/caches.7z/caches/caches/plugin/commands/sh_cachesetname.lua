
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CacheSetName");
COMMAND.tip = "Set a cache's name.";
COMMAND.text = "[string Name]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	
	if (IsValid(trace.Entity) and trace.Entity:GetClass() == "cw_cache") then
		local cache = trace.Entity;
		local name = arguments[1];
		local oldName = cache:GetNetworkedString("Name");
		cache:SetNetworkedString("Name", name);

		for k, v in pairs(_player.GetAll()) do
			if (v:HasInitialized()) then
				local cacheName = player:GetCharacterData("CacheName");
				if (cacheName and cacheName == oldName) then
					player:SetCharacterData("CacheName", nil);
					player:SetSharedVar("CacheName", nil);
				end;
			end;
		end;

		Clockwork.player:Notify(player, "You have set this cache's name to '"..name.."'.");
	else
		Clockwork.player:Notify(player, "This is not a valid cache!");
	end;
end;

COMMAND:Register();