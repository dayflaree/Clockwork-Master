
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CacheAdd");
COMMAND.tip = "Add a cache at your target position.";
COMMAND.text = "[string Model] [string Name]"
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	
	local angles = player:EyeAngles();
	angles.pitch = 0;
	angles.roll = 0;
	angles.yaw = angles.yaw + 180;
	
	local cache = ents.Create("cw_cache");
	cache:SetAngles(angles);
	cache:SetPos(trace.HitPos);
	cache:Spawn();
	
	cache:SetModel(arguments[1]);
	cache:SetNetworkedString("Name", table.concat(arguments, " ", 2));

	cache:GetPhysicsObject():EnableMotion(false);
	Clockwork.entity:MakeFlushToGround(cache, trace.HitPos, trace.HitNormal);
	
	PLUGIN.caches[#PLUGIN.caches + 1] = cache;
	PLUGIN:SaveCaches();
	
	Clockwork.player:Notify(player, "You have added a cache named '"..arguments[2].."'.");
end;

COMMAND:Register();