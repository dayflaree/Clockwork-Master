
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CacheSetModel");
COMMAND.tip = "Set a cache's model.";
COMMAND.text = "[string Model]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	
	if (IsValid(trace.Entity) and trace.Entity:GetClass() == "cw_cache") then
		for k, cache in pairs(PLUGIN.caches) do
			if (cache == trace.Entity) then
				cache:SetCacheModel(arguments[1]);
				PLUGIN:SaveCaches();
			end;
		end;
	else
		Clockwork.player:Notify(player, "This is not a valid cache!");
	end;
end;

COMMAND:Register();