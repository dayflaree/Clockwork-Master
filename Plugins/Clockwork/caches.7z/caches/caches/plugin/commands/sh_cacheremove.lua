
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CacheRemove");
COMMAND.tip = "Remove caches at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	
	if (IsValid(trace.Entity) and trace.Entity:GetClass() == "cw_cache") then
		for k, cache in pairs(PLUGIN.caches) do
			if (cache == trace.Entity) then
				if (IsValid(cache)) then
					local name = cache:GetNetworkedString("Name");

					for k, v in pairs(_player.GetAll()) do
						if (v:HasInitialized()) then
							local cacheName = player:GetCharacterData("CacheName");
							if (cacheName and cacheName == name) then
								player:SetCharacterData("CacheName", nil);
								player:SetSharedVar("CacheName", nil);
							end;
						end;
					end;
					
					cache:Remove();

					PLUGIN.caches[k] = nil;
					PLUGIN:SaveCaches();
				
				Clockwork.player:Notify(player, "You have removed '"..name.."'.");
				end;
			end;
		end;
	else
		Clockwork.player:Notify(player, "That is not a valid cache!");
	end;
end;

COMMAND:Register();