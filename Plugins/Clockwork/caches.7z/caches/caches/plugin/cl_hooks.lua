
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when an entity's target ID HUD should be painted.
function PLUGIN:HUDPaintEntityTargetID(entity, info)
	local colorTargetID = Clockwork.option:GetColor("target_id");
	local colorWhite = Clockwork.option:GetColor("white");
	
	if (entity:GetClass() == "cw_cache") then
		if (entity:GetNetworkedString("Name") != "") then
			info.y = Clockwork.kernel:DrawInfo(entity:GetNetworkedString("Name"), info.x, info.y, colorTargetID, info.alpha);
		else
			info.y = Clockwork.kernel:DrawInfo("Cache", info.x, info.y, colorTargetID, info.alpha);
		end;
			
		if (Clockwork.Client:GetSharedVar("CanUseCache") == true) then
			local cacheName = Clockwork.Client:GetSharedVar("CacheName");
			if (cacheName == "" or cacheName == entity:GetNetworkedString("Name")) then
				info.y = Clockwork.kernel:DrawInfo("You can open it.", info.x, info.y, colorWhite, info.alpha);
			else
				info.y = Clockwork.kernel:DrawInfo("You are already using the "..cacheName..",", info.x, info.y, colorWhite, info.alpha);
				info.y = Clockwork.kernel:DrawInfo("Empty that cache first if you want to use this one.", info.x, info.y, colorWhite, info.alpha);
			end;
		else
			info.y = Clockwork.kernel:DrawInfo("You need to be a Gold Member to use this.", info.x, info.y, colorWhite, info.alpha);
		end;
	end;
end;

-- Called when an entity's menu options are needed.
function PLUGIN:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "cw_cache" and Clockwork.Client:GetSharedVar("CanUseCache")) then
		local cacheName = Clockwork.Client:GetSharedVar("CacheName");
		if (cacheName == "" or cacheName == entity:GetNetworkedString("Name")) then
			options["Open"] = "cwCacheOpen";
		end;
	end;
end;

-- Called when the local player's storage is rebuilt.
function PLUGIN:PlayerStorageRebuilt(panel, categories)
	if (panel.storageType == "Cache") then
		local entity = Clockwork.storage:GetEntity();
		
		if (IsValid(entity) and entity.cwMessage) then
			local messageForm = vgui.Create("DForm", panel);
			local helpText = messageForm:Help(entity.cwMessage);
				messageForm:SetPadding(5);
				messageForm:SetName("Message");
				helpText:SetFont("Default");
			panel:AddItem(messageForm);
		end;
	end;
end;