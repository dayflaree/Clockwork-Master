
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	self:LoadCaches();
end;

-- Called just after data should be saved.
function PLUGIN:PostSaveData()
	self:SaveCaches();
end;

-- Called when a player attempts to breach an entity.
function PLUGIN:PlayerCanBreachEntity(player, entity)
	if (entity:GetClass() == "cw_cache") then
		return false;
	end;
end;

-- Called when an entity attempts to be auto-removed.
function PLUGIN:EntityCanAutoRemove(entity)
	if (entity:GetClass() == "cw_cache") then
		return false;
	end;
end;

function PLUGIN:PlayerSaveCharacterData(player, data)
	if (data["CacheItems"]) then
		data["CacheItems"] = Clockwork.inventory:ToSaveable(data["CacheItems"]);
	end;
end;

function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (data["CacheItems"]) then
		data["CacheItems"] = Clockwork.inventory:ToLoadable(data["CacheItems"]);
	
		if (table.Count(data["CacheItems"]) == 0) then
			data["CacheItems"] = nil;
		end;
	end;

	if (data["CacheCash"] and data["CacheCash"] == 0) then
		data["CacheCash"] = nil;
	end;
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (firstSpawn) then
		player:SetSharedVar("CanUseCache", self:PlayerCanUseCache(player));

		local cacheName = player:GetCharacterData("CacheName");
		if (cacheName) then
			local cacheFound = false;
			for k, v in pairs(self.caches) do
				if (v:GetNetworkedString("Name") == cacheName) then
					cacheFound = true;
					break;
				end;
			end;

			if (!cacheFound) then
				player:SetCharacterData("CacheName", nil);
			end;
		end;

		player:SetSharedVar("CacheName", player:GetCharacterData("CacheName", ""));
	end;
end;

-- Called when an entity's menu option should be handled.
function PLUGIN:EntityHandleMenuOption(player, entity, option, arguments)
	local class = entity:GetClass();
	
	if (entity:GetClass() == "cw_cache" and arguments == "cwCacheOpen") then
		local cacheName = player:GetCharacterData("CacheName");
		local name = entity:GetNetworkedString("Name");
		if (!cacheName or cacheName == name) then
			if (self:PlayerCanUseCache(player)) then
				Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name().." has opened the '"..name.."' cache.");

				if (!cacheName) then
					player:SetCharacterData("CacheName", name);
					player:SetSharedVar("CacheName", name);
				end;

				local cash = player:GetCharacterData("CacheCash", 0);
				local inventory = player:GetCharacterData("CacheItems", {});
				local weight = self:GetPlayerCacheWeight(player);
				local isOneSided = self:GetIsPlayerCacheOneSided(player);
		
				Clockwork.storage:Open(player, {
					name = name,
					weight = weight,
					entity = entity,
					distance = 192,
					cash = cash,
					inventory = inventory,
					isOneSided = isOneSided,
					OnGiveCash = self.OnGiveCacheCash,
					OnTakeCash = self.OnTakeCacheCash,
					OnGiveItem = self.OnGiveCacheItem,
					OnTakeItem = self.OnTakeCacheItem,
					OnClose = self.OnCacheClose
				});
			else
				Clockwork.player:Notify(player, "You must be a Gold Member to use a cache.");
			end;
		else
			Clockwork.player:Notify(player, "You still have another cache in use.");
		end;
	end;
end;
