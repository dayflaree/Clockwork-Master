
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("CanUseCache", true);
	playerVars:String("CacheName", true);
end;