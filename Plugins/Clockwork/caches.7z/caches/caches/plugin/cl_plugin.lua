
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:AddToSystem("Maximum cache weight", "max_cache_weight", "The maximum weight caches can hold.", 0, 300);

Clockwork.datastream:Hook("StorageMessage", function(data)
	local entity = data.entity;
	local message = data.message;
	
	if (IsValid(entity)) then
		entity.cwMessage = message;
	end;
end);