--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Pre-War Beer";
ITEM.cost = 5;
ITEM.model = "models/props_junk/garbage_glassbottle001a.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Drink";
ITEM.category = "Liquor";
ITEM.business = true;
ITEM.description = "A large glass bottle labelled 'Beer'.";

function ITEM:OnUse(player, itemEntity)
	player:SetShaRedVar("antidepressants", CurTime() + 600);
	
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();