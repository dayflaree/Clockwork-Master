--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Pre-War White Wine";
ITEM.cost = 15;
ITEM.model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.weight = 1;
ITEM.useText = "Drink";
ITEM.category = "Liquor";
ITEM.business = true;
ITEM.description = "A bottle labelled 'White Wine'.";

function ITEM:OnUse(player, itemEntity)
	player:SetSharedVar("antidepressants", CurTime() + 600);
	
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();