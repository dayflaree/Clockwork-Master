--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Pre-War Applejack";
ITEM.cost = 10;
ITEM.model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Drink";
ITEM.category = "Liquor";
ITEM.business = true;
ITEM.description = "A brown bottle labelled 'Applejack'.";

function ITEM:OnUse(player, itemEntity)
	player:SetShaRedVar("antidepressants", CurTime() + 600);
	
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();