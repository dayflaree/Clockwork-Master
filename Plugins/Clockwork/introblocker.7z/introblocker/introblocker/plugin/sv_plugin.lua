local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local DatastreamStart = Clockwork.datastream.Start;

function Clockwork.datastream:Start(player, name, data)

	if (name != "WebIntroduction") then
		return DatastreamStart(self, player, name, data);
	end;
end;