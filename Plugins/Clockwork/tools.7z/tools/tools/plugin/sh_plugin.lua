local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitialized()
	local toolGun = weapons.GetStored("gmod_tool");

	for k, v in pairs(self.tool:GetAll()) do
		toolGun.Tool[v.Mode] = v;
	end;
end;

for k, v in pairs(file.Find(Clockwork.kernel:GetSchemaFolder().."/plugins/tools/plugin/tools/*.lua", "LUA", "namedesc")) do
	Clockwork.kernel:IncludePrefixed(Clockwork.kernel:GetSchemaFolder().."/plugins/tools/plugin/tools/"..v);
end;