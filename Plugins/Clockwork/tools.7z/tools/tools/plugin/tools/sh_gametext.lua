local PLUGIN = PLUGIN;
local TOOL = PLUGIN.tool:New();

TOOL.Category = "Render"
TOOL.Name = "Game Text"
TOOL.UniqueID = "game_text";
TOOL.Mode = "game_text";

TOOL.ClientConVar["displaytype"] = "0" -- 0 = once, 1 = once per person, 2 = multiple
TOOL.ClientConVar["effect"] = "0" -- 0 = fade, 1 = scan
TOOL.ClientConVar["global"] = "0"
TOOL.ClientConVar["r1"] = "255"
TOOL.ClientConVar["g1"] = "255"
TOOL.ClientConVar["b1"] = "255"
TOOL.ClientConVar["r2"] = "255"
TOOL.ClientConVar["g2"] = "255"
TOOL.ClientConVar["b2"] = "255"
TOOL.ClientConVar["x"] = "-1"
TOOL.ClientConVar["y"] = "-1"
TOOL.ClientConVar["fadein"] = "0.15"
TOOL.ClientConVar["fadeout"] = "1.5"
TOOL.ClientConVar["holdtime"] = "1.5"
TOOL.ClientConVar["fxtime"] = "1"
TOOL.ClientConVar["message"] = ""

cleanup.Register("game_texts");

function TOOL:LeftClick(trace)
	if (!IsValid(trace.Entity)) then return false; end;
	if (trace.Entity:IsPlayer()) then return false; end;
	if (CLIENT) then return true; end;

	local entity = trace.Entity;

	if (entity:MapCreationID() != -1) then
		return false;
	end;

	local effect = self:GetClientNumber("effect", 0);
	local bGlobal = tobool(self:GetClientNumber("global", 0));

	if (effect != 0 and effect != 2) then
		effect = 0;
	end;

	local trigger = ents.Create("gametext_trigger");
	trigger:SetPos(entity:GetPos());
	trigger:SetAngles(entity:GetAngles());
	trigger:Spawn();

	trigger:SetModel(entity:GetModel());

	SafeRemoveEntity(entity);

	trigger:SetTriggerType(math.Clamp(self:GetClientNumber("displaytype"), 0, 2));

	trigger:PhysicsInit(SOLID_VPHYSICS);
	trigger:SetNotSolid(true);
	trigger:SetTrigger(true);

	if (IsValid(trigger:GetPhysicsObject())) then
		trigger:GetPhysicsObject():EnableMotion(false);
	end;

	local color1 = Format("%s %s %s", self:GetClientNumber("r1"), self:GetClientNumber("g1"), self:GetClientNumber("b1"));
	local color2 = Format("%s %s %s", self:GetClientNumber("r2"), self:GetClientNumber("g2"), self:GetClientNumber("b2"));

	trigger.gameText:SetKeyValue("x", self:GetClientNumber("x"));
	trigger.gameText:SetKeyValue("y", self:GetClientNumber("y"));
	trigger.gameText:SetKeyValue("effect", effect);
	trigger.gameText:SetKeyValue("color", color1);
	trigger.gameText:SetKeyValue("color2", color2);
	trigger.gameText:SetKeyValue("spawnflags", bGlobal and "1" or "");
	trigger.gameText:SetKeyValue("fadein", self:GetClientNumber("fadein"));
	trigger.gameText:SetKeyValue("fadeout", self:GetClientNumber("fadeout"));
	trigger.gameText:SetKeyValue("holdtime", self:GetClientNumber("holdtime"));
	trigger.gameText:SetKeyValue("fxtime", self:GetClientNumber("fxtime"));
	trigger.gameText:SetKeyValue("message", self:GetClientInfo("message"):gsub("\\n", "\n"));

	undo.Create("Game Text: " .. self:GetClientInfo("message"));
		undo.AddEntity(trigger);
		undo.SetPlayer(self:GetOwner());
		undo.SetCustomUndoText("Undone GameText: '" .. self:GetClientInfo("message") .. "'");
	undo.Finish();

	self:GetOwner():AddCount("game_texts", trigger);
	self:GetOwner():AddCleanup("game_texts", trigger);

	return true;
end;

function TOOL:RightClick(trace)
	return false;
end;

function TOOL:Think()
end

function TOOL.BuildCPanel(CPanel)
	CPanel:AddControl("Header", {
		Description = "#tool.game_text.desc"
	})

	CPanel:AddControl("Checkbox", {Label = "Display message for everyone?", Command = "game_text_global"})

	CPanel:AddControl("ComboBox", {
		MenuButton = 0,
		Label = "Effect Type",
		Options = {
			["Fade In, Fade Out"] = {game_text_effect = "0"},
			["Scan In, Fade Out"] = {game_text_effect = "2"}
		}
	});

	CPanel:AddControl("ComboBox", {
		MenuButton = 0,
		Label = "Display Type",
		Options = {
			["Trigger Once"] = {game_text_displaytype = "0"},
			["Trigger Once Per Person"] = {game_text_displaytype = "1"},
			["Always Trigger"] = {game_text_displaytype = "2"}
		}
	});

	CPanel:AddControl("TextBox", {
		Label = "Message:",
		Command = "game_text_message"
	});

	CPanel:AddControl("Slider", {
		Label = "Screen X",
		Command = "game_text_x",
		Type = "Float",
		Min = 0,
		Max = 1,
		Value = 0.5
	});

	CPanel:AddControl("Slider", {
		Label = "Screen Y",
		Command = "game_text_y",
		Type = "Float",
		Min = 0,
		Max = 1,
		Value = 0.5
	});

	CPanel:AddControl("Slider", {
		Label = "Fade-in Time",
		Command = "game_text_fadein",
		Type = "Float",
		Min = 0,
		Max = 5,
		Value = 0.15
	});

	CPanel:AddControl("Slider", {
		Label = "Hold Time",
		Command = "game_text_holdtime",
		Type = "Float",
		Min = 0,
		Max = 5,
		Value = 1
	});

	CPanel:AddControl("Slider", {
		Label = "Fade-out Time",
		Command = "game_text_fadeout",
		Type = "Float",
		Min = 0,
		Max = 5,
		Value = 1
	});

	CPanel:AddControl("Slider", {
		Label = "ScanFX Time",
		Command = "game_text_fxtime",
		Type = "Float",
		Min = 0,
		Max = 5,
		Value = 0.15
	});

	CPanel:AddControl("Color", {
		Label = "Main Color",
		Red = "game_text_r1",
		Green = "game_text_g1",
		Blue = "game_text_b1"
	});

	CPanel:AddControl("Color", {
		Label = "Scan Color (only if Effect Type is set to 'Scan')",
		Red = "game_text_r2",
		Green = "game_text_g2",
		Blue = "game_text_b2"
	});
end;

if (CLIENT) then
	language.Add("tool.game_text.name", "Game Text");
	language.Add("tool.game_text.0", "Left click to transform a prop into a game_text trigger.");
	language.Add("tool.game_text.desc", "Displays text on the player's screen when triggered.");

	language.Add("Cleaned_game_texts", "Cleaned up all Game Texts");
	language.Add("Cleanup_game_texts", "Game Texts");
end;

TOOL:Register();