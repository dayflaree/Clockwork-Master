if (SERVER) then
	AddCSLuaFile();
end;

local BaseClass = baseclass.Get("base_entity");

ENT.PrintName		= "Game Text Trigger"
ENT.Category		= "Other"
ENT.Spawnable		= false
ENT.AdminOnly		= false
ENT.Model			= Model("models/hunter/blocks/cube1x1x1.mdl");
ENT.RenderGroup 	= RENDERGROUP_BOTH;

AccessorFunc(ENT, "m_iTriggerType", "TriggerType", FORCE_NUMBER);

local TRIGGER_ONCE = 0;
local TRIGGER_UNIQUE = 1;
local TRIGGER_MULTIPLE = 2;

if (SERVER) then

	function ENT:Initialize()
		self:SetModel(self.Model);
		self:SetSolid(SOLID_VPHYSICS);
		self:PhysicsInit(SOLID_VPHYSICS);

		local phys = self:GetPhysicsObject();

		if (IsValid(phys)) then
			phys:EnableMotion(false);
		end;

		self.gameText = ents.Create("game_text");
		self.gameText:SetParent(self);
		self.gameText:Spawn();

		self:SetNoDraw(true);
		self:SetTrigger(true);
		self:SetNotSolid(true);

		self.users = {};
	end;

	function ENT:StartTouch(entity)
		if (entity:IsPlayer()) then
			if (self:GetTriggerType() == TRIGGER_ONCE) then
				self.gameText:Input("Display", entity, entity);
				SafeRemoveEntity(self);
			elseif (self:GetTriggerType() == TRIGGER_UNIQUE) then
				if (!self.users[entity:SteamID()]) then
					self.users[entity:SteamID()] = true;

					self.gameText:Input("Display", entity, entity);
				end;
			elseif (self:GetTriggerType() == TRIGGER_MULTIPLE) then
				if ((entity.nextGameText or 0) < CurTime()) then
					local displayTime = self.gameText:GetSaveTable().holdtime + self.gameText:GetSaveTable().fadeout;

					if (self.gameText:GetSaveTable().effect == 2) then
						displayTime = displayTime + (self.gameText:GetSaveTable().fadein * string.len(self.gameText:GetSaveTable().message));
					else
						displayTime = displayTime + self.gameText:GetSaveTable().fadein;
					end;

					entity.nextGameText = CurTime() + displayTime;

					self.gameText:Input("Display", entity, entity);
				end;
			end;
		end;
	end;

elseif (CLIENT) then

	function ENT:Initialize()
		self:SetSolid(SOLID_VPHYSICS);
	end;

	function ENT:Draw()
		self:DrawModel();
	end;
end;