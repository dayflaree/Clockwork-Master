local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.kernel:IncludePrefixed("sv_footsteps.lua");
Clockwork.kernel:IncludePrefixed("sv_breathe.lua");
Clockwork.kernel:IncludePrefixed("cl_footsteps.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

game.AddParticles( "particles/steampuff.pcf" )

function PLUGIN:Initialize()
end;
