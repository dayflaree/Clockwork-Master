local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

util.AddNetworkString("add_footstep")
util.AddNetworkString("clear_footsteps")

print("loading sv footsteps")

function PLUGIN:CanSeeFootsteps(ply)
	return true
end

function PLUGIN:PlayerFootstep(ply, pos, foot, sound, volume, filter)
	if string.find( string.lower( sound ), "snow" ) then
		net.Start("add_footstep")
		net.WriteEntity(ply)
		net.WriteVector(pos)
		net.WriteAngle(ply:GetAimVector():Angle())
		net.WriteBit( foot )
		net.Broadcast()
	end
end

function PLUGIN:ClearAllFootsteps()
	net.Start("clear_footsteps")
	net.Broadcast()
end