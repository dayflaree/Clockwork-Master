local PLUGIN = PLUGIN;
local Clockwork = Clockwork;
PrecacheParticleSystem( "steam_jet_50_steam" )

-- Add some cinematic "breath fog" from the player's mouth.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local ply = player
	-- Create a timer that changes the time it takes for it to loop at the end after running the code.
	ply.nextbreathe = CurTime() + math.Rand( 3, 10 )
end

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	-- 4 = PATTACH_POINT_FOLLOW
	local ply = player
	if ( ply.nextbreathe < CurTime() ) then
		if !(player.cwSafeAir) then
			local particle = ents.Create("info_particle_system")    
			  particle:SetKeyValue("start_active","1")       
			  particle:SetKeyValue("effect_name","steam_jet_50_steam")
			particle:Spawn()     
			particle:Activate()  
			particle:SetMoveType( MOVETYPE_NONE )
			particle:SetParent( ply, ply:LookupAttachment( "eyes" ) )
			particle:SetLocalPos( Vector( 1.5, 0, -2 ) )
			particle:SetAngles( ply:EyeAngles() )
			particle:Fire( "Kill", "Kill", 1 )
		end
		ply.nextbreathe = CurTime() + math.Rand( 3, 10 )
	end
end