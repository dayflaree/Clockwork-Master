local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.setting:AddCheckBox("Framework", "Enable footsteps in the snow.", "novabox_enable_footstep", "Whether or not to enable footsteps in the snow.");