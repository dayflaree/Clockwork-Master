local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

PLUGIN.FootstepMaxLifeTime = CreateClientConVar( "mu_footstep_maxlifetime", 30, true, true )
PLUGIN.FootstepShow = CreateClientConVar( "novabox_enable_footstep", 1, true, true )

local FootSteps = {}
if FootStepsG then
	FootSteps = FootStepsG
end
FootStepsG = FootSteps

function PLUGIN:FootStepsInit()
	
end

--local footMat = Material( "novabox/footprint_snow" )
local leftftMat = Material( "novabox/left_footprint" )
local rightftMat = Material( "novabox/right_footprint" )
-- local CircleMat = Material( "Decals/burn02a" )
local maxDistance = 600 ^ 2

function PLUGIN:PreDrawTranslucentRenderables()
	cam.Start3D(EyePos(), EyeAngles())
	local pos = EyePos()
	local lifeTime = math.Clamp(PLUGIN.FootstepMaxLifeTime:GetInt(), 0, 30)
	for k, footstep in pairs(FootSteps) do
		if footstep.curtime + lifeTime > CurTime() then
			if (footstep.pos - EyePos()):LengthSqr() < maxDistance then
				render.SetMaterial( footstep.foot )
				render.DrawQuadEasy( footstep.pos + footstep.normal * 0.5, footstep.normal, 10, 20, footstep.col, footstep.angle )
			end
		else
			FootSteps[k] = nil
		end
	end
	cam.End3D()
end

function PLUGIN:AddFootstep(ply, pos, ang, foot) 
	ang.p = 0
	ang.r = 0
	local fpos = pos
	if ply.LastFoot then
		fpos = fpos + ang:Right() * 5
	else
		fpos = fpos + ang:Right() * -5
	end
	ply.LastFoot = !ply.LastFoot

	local trace = {}
	trace.start = fpos
	trace.endpos = trace.start + Vector(0,0,-10)
	trace.filter = ply
	local tr = util.TraceLine(trace)

	if tr.Hit then

		local tbl = {}
		tbl.pos = tr.HitPos
		tbl.plypos = fpos
		-- left is 0 right is 1
		if ( foot == 0 ) then
			tbl.foot = leftftMat
		else
			tbl.foot = rightftMat
		end
		tbl.curtime = CurTime()
		tbl.angle = ang.y
		tbl.normal = tr.HitNormal
		local computelight = render.ComputeLighting( tr.HitPos, tr.HitNormal )
		local dynamiclight = render.ComputeDynamicLighting( tr.HitPos, tr.HitNormal )
		local ambient = render.GetAmbientLightColor()
		local color1 = ( computelight[1] + ambient[1] ) / 2
		local color2 = ( computelight[2] + ambient[2] ) / 2
		local color3 = ( computelight[3] + ambient[3] ) / 2
		tbl.col = Color( color1 * 255, color2 * 255, color3 * 255 )
		table.insert(FootSteps, tbl)
	end
end

function PLUGIN:FootStepsFootstep(ply, pos, foot, sound, volume, filter)

	if !PLUGIN:CanSeeFootsteps() then return end

	PLUGIN:AddFootstep(ply, pos, ply:GetAimVector():Angle(), foot)
end

function PLUGIN:CanSeeFootsteps()
	if ( PLUGIN.FootstepShow:GetInt() == 1 ) then
		return true;
	else
		return false;
	end
end

function PLUGIN:ClearFootsteps()
	table.Empty(FootSteps)
end

net.Receive("add_footstep", function ()
	local ply = net.ReadEntity()
	local pos = net.ReadVector()
	local ang = net.ReadAngle()
	local foot = net.ReadBit()

	if !IsValid(ply) then return end

	if !PLUGIN:CanSeeFootsteps() then return end

	PLUGIN:AddFootstep(ply, pos, ang, foot)
end)