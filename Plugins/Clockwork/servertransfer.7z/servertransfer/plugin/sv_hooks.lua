local PLUGIN = PLUGIN

--[[elec if you're reading this, don't beat me up]]
function PLUGIN:PlayerCanUseCharacter(player, character)
	local currentserver = game.GetIPAddress()
	
	if currentserver == "149.56.106.44:27015" then
		if character.data["outlands"] == true then
			return "Your character is in the outlands, and must be transferred to the city to be used!"
		end
	elseif currentserver == "192.99.242.120:27015" then
		if character.data["outlands"] == false then
			return "Your character is in the city, and must be transferred to the outland to be used!"
		end
	end
end

--gonna try to use if not
function PLUGIN:PlayerCharacterLoaded(player)
	local currentserver = game.GetIPAddress()
	if currentserver == "149.56.106.44:27015" then
		player:SetCharacterData("outlands", false)
	elseif currentserver == "192.99.242.120:27015" then
		player:SetCharacterData("outlands", true)
	end
end