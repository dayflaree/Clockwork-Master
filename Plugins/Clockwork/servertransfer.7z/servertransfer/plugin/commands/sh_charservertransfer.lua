local COMMAND = Clockwork.command:New("CharServerTransfer")
COMMAND.tip = "Transfer a Character to the Other Server, 1 is wipe, 0 is no wipe."
COMMAND.text = "<string Name> <bool Wipe>"
COMMAND.access = "o"
COMMAND.arguments = 2



-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local currentserver = game.GetIPAddress()
	local target = Clockwork.player:FindByID(arguments[1])
	local wipetrue = Clockwork.kernel:ToBool(arguments[2])

	if wipetrue then
		Clockwork.player:SetFlags(target, "b")
		Clockwork.datastream:Start(target, "InvClear", true)
		Clockwork.player:SaveCharacter(target)
	end
	
	if game:GetIPAddress() == "192.99.242.120:27015" then
		Clockwork.player:NotifyAll(player:Name() .. " has transferred " .. target:Name() .. " to City Roleplay.")
		target:SetCharacterData("outlands", false)
		Clockwork.player:SaveCharacter(target)
		target:SendLua( 'LocalPlayer():ConCommand( \"connect 149.56.106.44\" )' )
	elseif game:GetIPAddress() == "149.56.106.44:27015" then
		Clockwork.player:NotifyAll(player:Name() .. " has transferred " .. target:Name() .. " to Outlands Roleplay.")
		target:SetCharacterData("outlands", true)
		Clockwork.player:SaveCharacter(target)--save character so outlands updates..

		target:SendLua( 'LocalPlayer():ConCommand( \"connect 192.99.242.120\" )' )
	end	
end
COMMAND:Register()