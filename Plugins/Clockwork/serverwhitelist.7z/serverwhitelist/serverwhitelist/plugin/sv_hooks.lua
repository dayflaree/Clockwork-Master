local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	self.whitelist = Clockwork.kernel:RestoreSchemaData("whitelist");
end;

-- Called just after data should be saved.
function PLUGIN:PostSaveData()
	Clockwork.kernel:SaveSchemaData("whitelist", self.whitelist);
end;

-- Called when a player attempts to connect to the server.
function PLUGIN:CheckPassword(steamID)
	steamID = util.SteamIDFrom64(steamID);

	if (!self:Whitelisted(steamID)) then
		return false, "You are not whitelisted to join the server!";
	end;
end;
