local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Whitelist");
COMMAND.tip = "Whitelist a SteamID to join the server.";
COMMAND.text = "<string SteamID>";
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local steamID = arguments[1];

	if (!string.find(steamID, "STEAM_(%d+):(%d+):(%d+)")) then
		return player:Notify(steamID.." is not a valid SteamID!");
	end;

	if (PLUGIN:Whitelisted(steamID)) then
		return player:Notify(steamID.." is already whitelisted!");
	end;

	PLUGIN.whitelist[steamID] = true;
	player:Notify(steamID.." is now whitelisted to join the server.");
end;

COMMAND:Register();
