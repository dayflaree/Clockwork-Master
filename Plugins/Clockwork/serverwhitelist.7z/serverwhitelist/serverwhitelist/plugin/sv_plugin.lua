local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- A function to check if a SteamID is whitelisted.
function PLUGIN:Whitelisted(steamID)
	return self.whitelist[steamID] != nil or steamID == Clockwork.config:Get("owner_steamid"):Get();
end;
