ENT.Type = "anim"  
ENT.Base = "base_gmodentity"  
ENT.PrintName		= "GlowStick White"
ENT.Author			= "Patrick Hunt"
ENT.Information		= ""
ENT.Category		= "GlowSticks"

ENT.Spawnable			= true
ENT.AdminSpawnable		= true