ENT.Type			= "anim"  
ENT.Base			= "base_gmodentity"  
ENT.PrintName		= "Glowstick Green"
ENT.Author			= ""
ENT.Information		= ""
ENT.Category		= "CW Glowsticks"

ENT.Spawnable		= true
ENT.AdminSpawnable	= true