AddCSLuaFile()

SWEP.Base = "wpn"


SWEP.Author            = "Hds46"
SWEP.Contact = "Workshop"
SWEP.Instructions  = "Left Click - Put grenades on a walls/Put rope on a walls."
SWEP.PrintName      = "Tripwire Grenade"
SWEP.Purpose 		= "Make traps."
SWEP.Spawnable            = true
SWEP.AdminOnly             = false
SWEP.Category = "Other"

SWEP.Slot = 5
SWEP.SlotPos = 100
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

SWEP.WireMine = {}
SWEP.WireMine.CSModel = "models/weapons/w_grenade.mdl"
SWEP.WireMine.CSModelAngle = Angle(10,0,-37)
SWEP.WireMine.CSModelPosition = Vector(4,-2.8,-5)
SWEP.WireMine.CSModel2 = "models/thrusters/jetpack.mdl"
SWEP.WireMine.CSModelAngle2 = Angle(10,0,-37)
SWEP.WireMine.CSModelPosition2 = Vector(2.8,-3.5,-1)
SWEP.WireMine.CSWorldMdl = "models/weapons/w_grenade.mdl"
SWEP.WireMine.CSWorldModelAngle = Angle(10,60,160)
SWEP.WireMine.CSWorldModelPosition = Vector(0,5.5,3.5)
SWEP.WireMine.CSWorldMdl2 = "models/thrusters/jetpack.mdl"
SWEP.WireMine.CSWorldModelAngle2 = Angle(20,0,180)
SWEP.WireMine.CSWorldModelPosition2 = Vector(2,3.6,0.7)
SWEP.WireMine.AttachDistance = 100
SWEP.WireMine.PlayerDistance = 900
SWEP.WireMine.Delay = 3
SWEP.WireMine.TakeAmmo = 1

SWEP.ViewModel = "models/weapons/c_grenade.mdl"
SWEP.WorldModel = "models/weapons/w_grenade.mdl"
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Grenade"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.IconLetter  = "x"
SWEP.WepSelectIcon      = Material("tripwire_img.png")
SWEP.BounceWeaponIcon   = false

if CLIENT then
	local AmmoDisplay = {}
	
	function SWEP:CustomAmmoDisplay()

		AmmoDisplay.Draw = true
		AmmoDisplay.PrimaryClip = self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() )
		
		return AmmoDisplay

    end
	
	function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )
	
	-- Set us up the texture
	surface.SetDrawColor( 255, 255, 255, alpha )
	surface.SetMaterial( self.WepSelectIcon )
	
	-- Lets get a sin wave to make it bounce
	local fsin = 0
	
	if ( self.BounceWeaponIcon == true ) then
		fsin = math.sin( CurTime() * 10 ) * 5
	end
	
	-- Borders
	y = y + 10
	x = x + 10
	wide = wide - 20
	
	-- Draw that mother
	surface.DrawTexturedRect( x + (fsin), y - (fsin),  wide-fsin*2 , ( wide / 2 ) + (fsin) )
	
	-- Draw weapon info box
	self:PrintWeaponInfo( x + wide + 20, y + tall * 0.95, alpha )
end
end

function SWEP:Initialize()
util.PrecacheModel( "models/weapons/c_grenade.mdl" )
util.PrecacheModel( "models/weapons/w_grenade.mdl" )
self:SetWeaponHoldType( "slam" )
self:SetNWBool("Rope",false)
self:SetNWEntity("NadeGrenade",NULL)
self:SetNWBool("CSModelHide",false)
self.Refresh = false
self.HasAmmo = true
end

function SWEP:OnReload()
end

function SWEP:DoThing()
if !(self.Weapon:GetNextPrimaryFire() < CurTime()) then
self.CanHolster = false
else
self.CanHolster = true
end
if !(self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) then
self:SetNWBool("CSModelHide",true)
end
if self:GetNWBool("Rope")==true and !IsValid(self:GetNWEntity("NadeGrenade")) then
if (self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) then
self:SetNWEntity("NadeGrenade",NULL)
self:SetNWBool("Rope",false)
self.Owner:DrawViewModel(true)
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self:SetNWBool("CSModelHide",false)
else
self.Owner:DrawViewModel(false)
self:SetNWBool("Rope",false)
self:SetNWEntity("NadeGrenade",NULL)
self:SetNWBool("CSModelHide",false)
end
end
if (self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) and self:GetNWBool("Rope")==false and !self.HasAmmo then
self.Owner:DrawViewModel(true)
self.HasAmmo = true
self.Weapon:SetNextPrimaryFire( CurTime() + self.WireMine.Delay/4 )
self.Weapon:SetNextSecondaryFire( CurTime() + self.WireMine.Delay/4 )
self:SetNWEntity("NadeGrenade",NULL)
self:SetNWBool("Rope",false)
self.Owner:DrawViewModel(true)
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self.Owner:GetViewModel():SetPlaybackRate( 3.5 )
self:SetNWBool("CSModelHide",false)
end
if !(self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) and self:GetNWBool("Rope")==false then
self.HasAmmo = false
timer.Remove("GiveGrenade" .. self.Weapon:EntIndex())
timer.Remove("back_grenade" .. self.Owner:EntIndex())
end
if SERVER and IsValid(self:GetNWEntity("NadeGrenade")) and self:GetNWBool("Rope")==true then
local trace = {}
trace.start = self:GetNWEntity("NadeGrenade"):GetPos()
trace.endpos = self.Owner:GetShootPos()
trace.filter = {self:GetNWEntity("NadeGrenade"),self:GetNWEntity("NadeGrenade").ChildModel,self:GetNWEntity("NadeGrenade").ChildModel2}
local traceworld = util.TraceLine(trace)
if (traceworld.Hit and traceworld.Entity != self.Owner) or trace.start:Distance(self.Owner:GetShootPos()) > self.WireMine.PlayerDistance then
self:SetNWBool("Rope",false)

if IsValid(self:GetNWEntity("NadeGrenade")) then
self:GetNWEntity("NadeGrenade"):SetNWBool("AllowGrab",true)
self:SetNWEntity("NadeGrenade",NULL)
end
self:EmitSound("Weapon_Crossbow.BoltHitWorld")
self.Weapon:SetNextPrimaryFire( CurTime() + self.WireMine.Delay/2 )
self.Weapon:SetNextSecondaryFire( CurTime() + self.WireMine.Delay/2 )
self.Refresh = true
self.Owner:DrawViewModel(false)
timer.Create("back_grenade" .. self.Owner:EntIndex(),self.WireMine.Delay/1.8,1,function()
if IsValid(self.Weapon) and IsValid(self.Owner) then
self.Refresh = false
self.Owner:DrawViewModel(true)
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self.Owner:GetViewModel():SetPlaybackRate( 3.5 )
self:SetNWBool("CSModelHide",false)
end
end)
end
end
end

function SWEP:ViewModelDrawn()
if SERVER then return end
if self:GetNWBool("CSModelHide")==false then
self.Owner:GetViewModel():ManipulateBoneScale(self.Owner:GetViewModel():LookupBone("ValveBiped.Grenade_body"),Vector(1,1,1))
self.Owner:GetViewModel():ManipulateBoneScale(self.Owner:GetViewModel():LookupBone("ValveBiped.Pin"),Vector(1,1,1))
else
self.Owner:GetViewModel():ManipulateBoneScale(self.Owner:GetViewModel():LookupBone("ValveBiped.Grenade_body"),Vector(0,0,0))
self.Owner:GetViewModel():ManipulateBoneScale(self.Owner:GetViewModel():LookupBone("ValveBiped.Pin"),Vector(0,0,0))
end
if !IsValid(self.CSModelGet) then
-- CSModel
local CSModelSinth = ClientsideModel(self.WireMine.CSModel,RENDER_GROUP_VIEW_MODEL_OPAQUE)
CSModelSinth:SetParent(self)
CSModelSinth:SetSequence(1)
CSModelSinth:SetNoDraw(true)
self.CSModelGet = CSModelSinth
else
local CSModelAng = self.WireMine.CSModelAngle
local CSModelPos = self.WireMine.CSModelPosition
local ViewModelPos = self.Owner:GetViewModel():GetBoneMatrix(self.Owner:GetViewModel():LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation()
local ang = self.Owner:GetViewModel():GetAngles()
local up = ang:Up()
local right = ang:Right()
local forward = ang:Forward()
local worthposition = ViewModelPos + ang:Forward() * CSModelPos.x + ang:Right() * CSModelPos.y + ang:Up() * CSModelPos.z
if CSModelAng then
ang:RotateAroundAxis (ang:Right(),         CSModelAng.x)
ang:RotateAroundAxis (ang:Up(),         CSModelAng.y)
ang:RotateAroundAxis (ang:Forward(),     CSModelAng.z)
end
self.CSModelGet:SetPos(worthposition)
self.CSModelGet:SetAngles(ang)
render.SetColorModulation(1, 1, 1)
render.SetBlend(1)
if self:GetNWBool("CSModelHide")==false then
self.CSModelGet:DrawModel()
end
render.SetBlend(1)
render.SetColorModulation(1, 1, 1)
end
if !IsValid(self.CSModelGet2) then
-- CSModel 2
local CSModelSinth = ClientsideModel(self.WireMine.CSModel2,RENDER_GROUP_VIEW_MODEL_OPAQUE)
CSModelSinth:SetParent(self)
CSModelSinth:SetSequence(1)
CSModelSinth:SetNoDraw(true)
self.CSModelGet2 = CSModelSinth
else
local CSModelAng = self.WireMine.CSModelAngle2
local CSModelPos = self.WireMine.CSModelPosition2
local ViewModelPos = self.Owner:GetViewModel():GetBoneMatrix(self.Owner:GetViewModel():LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation()
local ang = self.Owner:GetViewModel():GetAngles()
local up = ang:Up()
local right = ang:Right()
local forward = ang:Forward()
local worthposition = ViewModelPos + ang:Forward() * CSModelPos.x + ang:Right() * CSModelPos.y + ang:Up() * CSModelPos.z
if CSModelAng then
ang:RotateAroundAxis (ang:Right(),         CSModelAng.x)
ang:RotateAroundAxis (ang:Up(),         CSModelAng.y)
ang:RotateAroundAxis (ang:Forward(),     CSModelAng.z)
end
self.CSModelGet2:SetPos(worthposition)
self.CSModelGet2:SetAngles(ang)
self.CSModelGet2:SetModelScale(0.35,0)
self.CSModelGet2:SetMaterial("models/weapons/v_grenade/grenade body")
render.SetColorModulation(1, 1, 1)
render.SetBlend(1)
if self:GetNWBool("CSModelHide")==false then
self.CSModelGet2:DrawModel()
end
render.SetBlend(1)
render.SetColorModulation(1, 1, 1)
end
end

function SWEP:DrawWorldModel()
    if SERVER then return end
    if !IsValid(self.CSWorldModel) then
	local inticworldmodel = ClientsideModel(self.WireMine.CSWorldMdl)
	inticworldmodel:SetPos(self:GetPos())
	inticworldmodel:SetAngles(self:GetAngles())
	inticworldmodel:SetParent(self)
	inticworldmodel:SetNoDraw(true)
	self.CSWorldModel = inticworldmodel
	else
	local pos
	local ang
	if IsValid(self.Owner) then
	pos, ang = self.Owner:GetBoneMatrix(self.Owner:LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation(), self.Owner:GetBoneMatrix(self.Owner:LookupBone("ValveBiped.Bip01_R_Hand")):GetAngles()
	
	local CSWModelAng = self.WireMine.CSWorldModelAngle
    local CSWModelPos = self.WireMine.CSWorldModelPosition
		
	pos = pos + ang:Forward() * CSWModelPos.x + ang:Right() * CSWModelPos.y + ang:Up() * CSWModelPos.z
	ang:RotateAroundAxis(ang:Up()		, CSWModelAng.y)
	ang:RotateAroundAxis(ang:Right()	, CSWModelAng.p)
	ang:RotateAroundAxis(ang:Forward()	, CSWModelAng.r)
	
	self.CSWorldModel:SetPos(pos)
	self.CSWorldModel:SetAngles(ang)
	self.CSWorldModel:SetModelScale(0.95,0)
	if self:GetNWBool("CSModelHide")==false then
	self.CSWorldModel:DrawModel()
	self:DrawModel()
	end
	else
	self:DrawModel()
	end
	end
	if !IsValid(self.CSWorldModel2) then
	local inticworldmodel = ClientsideModel(self.WireMine.CSWorldMdl2)
	inticworldmodel:SetPos(self:GetPos())
	inticworldmodel:SetAngles(self:GetAngles())
	inticworldmodel:SetParent(self)
	inticworldmodel:SetNoDraw(true)
	self.CSWorldModel2 = inticworldmodel
	else
	local pos
	local ang
	if IsValid(self.Owner) then
	pos, ang = self.Owner:GetBoneMatrix(self.Owner:LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation(), self.Owner:GetBoneMatrix(self.Owner:LookupBone("ValveBiped.Bip01_R_Hand")):GetAngles()
	
	local CSWModelAng = self.WireMine.CSWorldModelAngle2
    local CSWModelPos = self.WireMine.CSWorldModelPosition2
		
	pos = pos + ang:Forward() * CSWModelPos.x + ang:Right() * CSWModelPos.y + ang:Up() * CSWModelPos.z
	ang:RotateAroundAxis(ang:Up()		, CSWModelAng.y)
	ang:RotateAroundAxis(ang:Right()	, CSWModelAng.p)
	ang:RotateAroundAxis(ang:Forward()	, CSWModelAng.r)
	
	self.CSWorldModel2:SetPos(pos)
	self.CSWorldModel2:SetAngles(ang)
	self.CSWorldModel2:SetModelScale(0.40,0)
	self.CSWorldModel2:SetMaterial("models/weapons/v_grenade/grenade body")
	if self:GetNWBool("CSModelHide")==false then
	self.CSWorldModel2:DrawModel()
	self:DrawModel()
	end
	else
	self:DrawModel()
	end
	end
end

function SWEP:FuncDeploy()
if !(self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) and !self:GetNWBool("Rope")==true then  
self.Owner:DrawViewModel(false)
else
self.Owner:DrawViewModel(true)
self.Weapon:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration()/2)
local effect = EffectData()
effect:SetEntity(self.Weapon)
if CLIENT and self.Owner == LocalPlayer() then
util.Effect("rope_draw", effect)
end
end
return true
end

function SWEP:FuncHolster()
if self.CanHolster == true then
if CLIENT and self.Owner == LocalPlayer() then
self.Owner:GetViewModel():ManipulateBoneScale(39,Vector(1,1,1))
self.Owner:GetViewModel():ManipulateBoneScale(40,Vector(1,1,1))
if IsValid(self.CSModelGet) then
self.CSModelGet:Remove()
end
if IsValid(self.CSModelGet2) then
self.CSModelGet2:Remove()
end
if IsValid(self.CSWorldModel) then
self.CSWorldModel:Remove()
end
if IsValid(self.CSWorldModel2) then
self.CSWorldModel2:Remove()
end
end
end
end

function SWEP:IsWall(ang)
if ang.pitch > 0 or ang.pitch < 0 then return false end
return true
end

function SWEP:Attack1()

    if !(self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) and !self:GetNWBool("Rope")==true then return end
	
	quicktrace = self.Owner:GetEyeTrace()
    
	if !(!quicktrace.Entity:IsNPC() and !quicktrace.Entity:IsPlayer() and !quicktrace.HitSky and quicktrace.HitPos:Distance(self.Owner:GetShootPos()) <= self.WireMine.AttachDistance) then return end
	if quicktrace.HitWorld then
	local quickang = quicktrace.HitNormal:Angle()
	if !self:IsWall(quickang) then return end
	end
	self.Weapon:EmitSound("weapons/slam/throw.wav" )
	self.Weapon:SendWeaponAnim( ACT_VM_THROW )
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	if self:GetNWBool("Rope")==false then 
	self.Weapon:SetNextPrimaryFire( CurTime() + self.WireMine.Delay )
	self.Weapon:SetNextSecondaryFire( CurTime() + self.WireMine.Delay )
	local Ang = quicktrace.HitNormal:Angle()
	Ang.pitch = Ang.pitch
	Ang.roll = Ang.roll + 20
	local Ang2 = quicktrace.HitNormal:Angle()
	Ang2.pitch = Ang2.pitch
	Ang2.roll = Ang2.roll + 20
	local Ang3 = quicktrace.HitNormal:Angle()
	Ang3.pitch = Ang3.pitch
	Ang3.roll = Ang3.roll + 20
	if SERVER then
	local NadeGrenade = ents.Create( "ent_wiremine" )
	NadeGrenade:SetPos( quicktrace.HitPos + self.Owner:GetForward()*-1.5 )
	NadeGrenade:SetAngles( Ang )
	NadeGrenade:Spawn()
	NadeGrenade:Activate()
	if !quicktrace.HitWorld and IsValid(quicktrace.Entity) then
	NadeGrenade:SetParent(quicktrace.Entity)
	NadeGrenade.StartRestrict = quicktrace.Entity
	end
	NadeGrenade.Thrower = self.Owner
	self:SetNWEntity("NadeGrenade",NadeGrenade)
	NadeGrenade.ChildModel = ents.Create("prop_physics")
	NadeGrenade.ChildModel:SetModel("models/items/grenadeammo.mdl")
	NadeGrenade.ChildModel:SetPos( quicktrace.HitPos + self.Owner:GetForward()*-1.5 + NadeGrenade:GetRight()*4 )
	NadeGrenade.ChildModel:SetAngles( Ang2 )
	NadeGrenade.ChildModel:Spawn()
	NadeGrenade.ChildModel:SetParent(NadeGrenade)
	NadeGrenade.ChildModel.IsChildNade = true
	NadeGrenade.ChildModel:SetNotSolid( true )
	NadeGrenade.ChildModel2 = ents.Create("prop_physics")
	NadeGrenade.ChildModel2:SetModel("models/thrusters/jetpack.mdl")
	NadeGrenade.ChildModel2:SetMaterial("models/weapons/v_grenade/grenade body")
	NadeGrenade.ChildModel2:SetPos( quicktrace.HitPos + self.Owner:GetForward()*-1.5 + NadeGrenade:GetRight()*2 )
	NadeGrenade.ChildModel2:SetAngles( Ang3 )
	NadeGrenade.ChildModel2:Spawn()
	NadeGrenade.ChildModel2:SetParent(NadeGrenade)
	NadeGrenade.ChildModel2:SetModelScale(0.44,0)
	NadeGrenade.ChildModel2.IsChildNade = true
	NadeGrenade.ChildModel2:SetNotSolid( true )
	local phys = NadeGrenade.ChildModel:GetPhysicsObject()
	if ( IsValid( phys ) ) then
    phys:Wake()
    phys:AddGameFlag( FVPHYSICS_NO_IMPACT_DMG )
    phys:AddGameFlag( FVPHYSICS_NO_NPC_IMPACT_DMG )
    phys:EnableMotion(false)
	end
	local phys = NadeGrenade.ChildModel2:GetPhysicsObject()
	if ( IsValid( phys ) ) then
    phys:Wake()
    phys:AddGameFlag( FVPHYSICS_NO_IMPACT_DMG )
    phys:AddGameFlag( FVPHYSICS_NO_NPC_IMPACT_DMG )
    phys:EnableMotion(false)
	end
	--self.Owner:RemoveAmmo(self.WireMine.TakeAmmo,self.Weapon:GetPrimaryAmmoType())
	end
	self:SetNWBool("CSModelHide",true)
	timer.Create("GiveRope" .. self.Weapon:EntIndex(),self.WireMine.Delay/1.5,1,function()
	if IsValid(self.Weapon) and IsValid(self.Owner) then
	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
	self:SetNWBool("Rope",true)
	end
	end)
	else
	self.Weapon:SetNextPrimaryFire( CurTime() + 1.7 )
	self.Weapon:SetNextSecondaryFire( CurTime() + 1.7 )
	self:GetNWEntity("NadeGrenade"):Mark(self.Owner:GetEyeTrace())
	self:SetNWBool("Rope",false)
	if IsValid(self:GetNWEntity("NadeGrenade")) then
	self:SetNWEntity("NadeGrenade",NULL)
	end
	timer.Create("GiveGrenade" .. self.Weapon:EntIndex(),self.WireMine.Delay/2.2,1,function()
	self.Owner:RemoveAmmo(self.WireMine.TakeAmmo,self.Weapon:GetPrimaryAmmoType())
	if IsValid(self.Weapon) and IsValid(self.Owner) then
	if !(self.Owner:GetAmmoCount( self.Weapon:GetPrimaryAmmoType() ) >= self.WireMine.TakeAmmo) then  
	self.Owner:DrawViewModel(false)
	else
	self.Owner:DrawViewModel(true)
	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
	self.Owner:GetViewModel():SetPlaybackRate( 3.5 )
	self:SetNWBool("CSModelHide",false)
	end
	end
	end)
	end
end

function SWEP:Attack2()
end

if CLIENT then

local mat = Material( "cable/cable" )

local EFFECT={}

function EFFECT:Init(data)
self.WeaponEnt = data:GetEntity()
self.Gmoder = self.WeaponEnt:GetOwner()
end

function EFFECT:Think()
if IsValid(self.WeaponEnt) and IsValid(self.Gmoder) and self.Gmoder:Alive() and IsValid(self.Gmoder:GetActiveWeapon()) and self.Gmoder:GetActiveWeapon()==self.WeaponEnt and self.WeaponEnt:GetNWBool("Rope") == true and IsValid(self.WeaponEnt:GetNWEntity("NadeGrenade")) then
local pos = self.Gmoder:GetViewModel():GetBoneMatrix(self.Gmoder:GetViewModel():LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation()
self:SetRenderBoundsWS( self.WeaponEnt:GetNWEntity("NadeGrenade"):GetPos(), pos, Vector()*10 )
end
return true
end

function EFFECT:Render( )
if IsValid(self.WeaponEnt) and self.WeaponEnt:GetNWBool("Rope") == true and IsValid(self.Gmoder) and self.Gmoder:Alive() and IsValid(self.Gmoder:GetActiveWeapon()) and self.Gmoder:GetActiveWeapon()==self.WeaponEnt and !self.Gmoder:InVehicle() and IsValid(self.WeaponEnt:GetNWEntity("NadeGrenade")) then
local pos

local TexOffset = CurTime() * 0.5
if GetViewEntity() == LocalPlayer() then
pos = self.Gmoder:GetViewModel():GetBoneMatrix(self.Gmoder:GetViewModel():LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation()
render.SetMaterial( mat )
render.DrawBeam( self.WeaponEnt:GetNWEntity("NadeGrenade"):GetPos(), pos, 1, 1, 5, Color( 255, 255, 255, 255 ) )
else
if self.Gmoder:GetBoneMatrix(self.Gmoder:LookupBone("ValveBiped.Bip01_R_Hand")) != nil then
pos = self.Gmoder:GetBoneMatrix(self.Gmoder:LookupBone("ValveBiped.Bip01_R_Hand")):GetTranslation()
render.SetMaterial( mat )
render.DrawBeam( self.WeaponEnt:GetNWEntity("NadeGrenade"):GetPos(), pos, 1, 1, 5, Color( 255, 255, 255, 255 ) )
end
end
end
end

effects.Register(EFFECT, "rope_draw", true)

end