include("shared.lua")
AddCSLuaFile("cl_init.lua")