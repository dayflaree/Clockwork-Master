AddCSLuaFile( )

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Tripwire Grenade"
ENT.Spawnable = false
ENT.Author = "Hds46"
// ENT.Category = "Other"
ENT.Rendergroup = RENDERGROUP_BOTH

----------Tripwire ENT Configurations-----------
ENT.BlastDamage = 80
ENT.BlastRadius = 160
ENT.GrabTime = 0
ENT.DefaultTime = 0
---------------------------------------------

/*--------------------------------------------
function ENT:SpawnFunction( ply, tr )
    local ent = ents.Create( ClassName )
    ent:SetPos( tr.HitPos + Vector(0,0,20) )
    ent:Spawn( )
    
    return ent
end
--------------------------------------------*/

function ENT:Initialize( )
    if SERVER then
	self.Entity:SetModel("models/items/grenadeammo.mdl")
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )
	self.Entity:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER )
    local phys = self:GetPhysicsObject()
	if ( IsValid( phys ) ) then
    phys:Wake()
    phys:AddGameFlag( FVPHYSICS_NO_IMPACT_DMG )
    phys:AddGameFlag( FVPHYSICS_NO_NPC_IMPACT_DMG )
    phys:EnableMotion(false)
	end
	end
	self:SetNWInt("Defused",0)
	self:SetNWBool("Activated",false)
	self:SetNWBool("AllowGrab",false)
end

function ENT:PhysicsCollide(data, physobj)
	if (data.Speed > 80 and data.DeltaTime > 0.2) then
		self.Entity:EmitSound("physics/metal/metal_grenade_impact_hard" .. math.random( 1, 3 ) .. ".wav",math.random(55,70))
	end
end

if CLIENT then
killicon.AddFont( "ent_wiremine", "HL2MPTypeDeath", "4", Color( 255, 93, 0, 255 ) )
function ENT:Draw()
self.Entity:DrawModel()
end

surface.CreateFont( "DefuseFont",
{
	font = "Roboto Bk",
	size = 20,
	weight = 1000
})

local function RecvMyUmsg( data )
local client = data:ReadEntity()
local float_msg = data:ReadFloat()
local default_time = data:ReadFloat()
if IsValid(client) then
client.DefTime = default_time
end
if IsValid(client) and client.DProgress == nil then
client.DProgress = vgui.Create( "DProgress" )
client.DProgress:SetPos( ScrW() / 2.5, ScrH() / 1.5 )
client.DProgress:SetSize( 400, 40 )
client.DProgress:SetFraction( 0 )
client.DProgress:SetVisible(true)
client.DLabel = vgui.Create( "DLabel", Panel )
client.DLabel:SetPos( ScrW() / 2, ScrH() / 1.6 )
client.DLabel:SetFont( "DefuseFont" )
client.DLabel:SetText( "Defusing..." )
client.DLabel:SizeToContents()
client.DLabel:SetTextColor( Color( 255, 255, 255, 255 ) )
client.DLabel:SetVisible(true)
elseif IsValid(client) and client.DProgress != nil then
client.DProgress:SetFraction( float_msg/100 )
client.DProgress:SetVisible(true)
client.DLabel:SetVisible(true)
end
if float_msg < 100 then
client.DLabel:SetText( "Defusing..." )
client.DLabel:SetPos( ScrW() / 2, ScrH() / 1.6 )
else
client.DLabel:SetText( "Done!" )
client.DLabel:SetPos( ScrW() / 1.98, ScrH() / 1.6 )
end
end
usermessage.Hook( "PlyDefuse", RecvMyUmsg )

function HideBar()
if LocalPlayer().DProgress != nil and LocalPlayer().DefTime < CurTime() then
LocalPlayer().DProgress:SetVisible(false)
LocalPlayer().DLabel:SetVisible(false)
end
end
hook.Add("Think", "HideBar", HideBar)
end



function ENT:Mark(pos)
if CLIENT then return end
local dist = (self.Entity:GetPos() - pos.HitPos):Length()
local normal
local ent
if pos.Entity:IsWorld() then
normal = pos.HitPos
ent = pos.Entity
self.Hit = normal
else
self.Info = ents.Create("prop_physics")
self.Info:SetModel("models/items/grenadeammo.mdl")
self.Info:SetPos(pos.HitPos)
self.Info:Spawn()
self.Info:Activate()
self.Info:SetNoDraw(true)
self.Info:SetCollisionGroup(20)
self.Info:SetNotSolid( true )
self.Info:SetParent(pos.Entity)
self:DeleteOnRemove( self.Info )
normal = self.Info:GetPos():GetNormal()
ent = self.Info
end
self.ExNormal = pos.HitPos - self.Entity:GetPos()
self.ExDis = 0.5
self.Rope = constraint.Rope( self.Entity, ent, 0, 0, self.Entity:GetPos():GetNormal(), normal, dist, 2, 0, 1, "cable/cable", true )
self.RestrictEnt = pos.Entity
timer.Simple(0.5,function()
if IsValid(self.Entity) then
self:SetNWBool("Activated",true)
self:SetNWBool("AllowGrab",true)
self.Position = ent
end
end)
end

function ENT:OnTakeDamage( dmginfo )
self:TakePhysicsDamage( dmginfo ) 
end

function ENT:Use(activator)
if self:GetNWBool("AllowGrab") == true and self.GrabTime < CurTime() then
self.GrabTime = CurTime() + 0.05
self.DefaultTime = CurTime() + 0.5
self:SetNWInt("Defused",self:GetNWInt("Defused") + 2)
if SERVER then
umsg.Start( "PlyDefuse", activator )
umsg.Entity( activator )
umsg.Float( self:GetNWInt("Defused") )
umsg.Float( self.DefaultTime )
umsg.End()
end
if self:GetNWInt("Defused") == 100 then
--activator:GiveAmmo(2,"Grenade")
self:Remove()
end
end
end

function ENT:Explode()
if SERVER then
local expefffect = ents.Create("env_explosion")
expefffect:SetPos(self.Entity:GetPos())
expefffect:Spawn()
expefffect:SetKeyValue( "iMagnitude", 0 )
expefffect:SetKeyValue( "iRadiusOverride", 0 )  
expefffect:Fire( "Explode", 0, 0 )
util.ScreenShake(self.Entity:GetPos(), 100, 10, 5, 356)
util.BlastDamage(self.Entity, self.Thrower, self.Entity:GetPos()+self.ExNormal*self.ExDis, self.BlastRadius, self.BlastDamage)
self.Entity:Remove()
end
end

function ENT:OnRemove()
end

function ENT:Think()
if SERVER then
self.Entity:NextThink( CurTime() + 0.01 )
end
if SERVER and self.DefaultTime < CurTime() then
self:SetNWInt("Defused",0)
end

if SERVER and self:GetNWBool("Activated") == true and self.Position != nil then
local trace = {}
trace.start = self.Entity:GetPos()
if self.Position:IsWorld() then
trace.endpos = self.Hit
else
trace.endpos = self.Position:GetPos()
end
trace.filter = {self.Entity,self.ChildModel,self.ChildModel2,self.RestrictEnt,self.StartRestrict,nil,nil}
local traceworld = util.TraceLine(trace)
if traceworld.HitNonWorld then
if IsValid(self.Rope) then
self.Rope:Remove()
end
self.Entity:EmitSound("NPC_CombineMine.OpenHooks")
self:SetNWBool("Activated",false)
timer.Simple(0.4,function()
if IsValid(self.Entity) then
self:Explode()
self:SetNWBool("AllowGrab",false)
end
end)
end
end
return true
end