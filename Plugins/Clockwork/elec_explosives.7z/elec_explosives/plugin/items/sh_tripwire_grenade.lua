--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Tripwire Grenade";
	ITEM.cost = 100;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.model = "models/items/grenadeammo.mdl";
	ITEM.weight = 1.5;
	ITEM.uniqueID = "wpn_wiremine";
	ITEM.business = true;
	ITEM.description = "Two dirty tube of dust, connected to each other with some sort of mechanism.";
	ITEM.isAttachment = false;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();