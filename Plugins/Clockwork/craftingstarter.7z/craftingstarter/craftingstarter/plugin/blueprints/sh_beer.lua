local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Category Name";
BLUEPRINT.description = "A blueprint for testing crafting";
BLUEPRINT.model = "models/props_junk/garbage_glassbottle003a.mdl";
BLUEPRINT.name = "Beer";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	--"beer"
	--{1, "beer"}
	--{"beer", 1}
	--["beer"] = 1 -- RECOMMENDED WAY
};

BLUEPRINT.takeItems = {
	--"beer"
	--{1, "beer"}
	--{"beer", 1}
	--["beer"] = 1 -- RECOMMENDED WAY
};

BLUEPRINT.giveItems = {
	--"beer"
	--{1, "beer"}
	--{"beer", 1}
	--["beer"] = 1 -- RECOMMENDED WAY
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
	
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
	
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
	
end;

BLUEPRINT:Register();