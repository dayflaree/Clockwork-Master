An example blueprint is in /craftingstarter/plugin/blueprints/ named sh_beer.lua.

---

The following parts all use the same styles of coding.

Example 1:
BLUEPRINT.itemRequirements: Items the player needs to have in order to craft the blueprint.
BLUEPRINT.takeItems: Items taken from the player upon crafting.
BLUEPRINT.giveItems: Items given to the player upon crafting.

---

Here are the different styles (uncomment the style of your preference), where X is the part 
you're working in (refer to Example 1).

Example 2:
BLUEPRINT.X = {
	--"beer"
	--{1, "beer"}
	--{"beer", 1}
	--["beer"] = 1 -- RECOMMENDED WAY
};

---

IMPORTANT NOTE: To have multiple requirements, items to take, or items to give, separate new 
entries with commas (all except the last).

Example 3:
BLUEPRINT.itemRequirements = {
	"beer",
	{2, "grenade"},
	{"soda", 3},
	["pistol"] = 2
};

---

Refer to Example 2.

"beer": Applies to only ONE beer item at all times.

{1, "beer"}: Applies to the number of beer items of your choice. In this case, one. The first 
element is a number (amount), the second element is a string (the item's ID).

{"beer", 1}: Applies to the number of beer items of your choice. In this case, one. The first 
element is a string (the item's ID), the second element is a number (amount).

RECOMMENDED WAY:
["beer"] = 1: Applies to the number of beer items of your choice. In this case, 
one. The first part is a string surrounded by square brackets (the item's ID), the second part 
is an equals sign then a number (amount).

It could also be written like this, but this is only for one item:
BLUEPRINT.X = "beer";

---

Refer to Example 3.

The example requires the player to have one beer, two grenades, three sodas, and two pistols in
order to craft with the blueprint (although, this doesn't necessarily mean the items required
will be taken/given).

---

There are 3 extra methods, each invoked at different times while crafting. They are the following:
BLUEPRINT:OnCraft(player): Called before a blueprint is crafted with (BEFORE any cash/items are 
taken/given).

BLUEPRINT:PostCraft(player): Called after a blueprint is crafted with (AFTER cash/items are 
taken/given).

BLUEPRINT:FailedCraft(player): Called when a blueprint has failed to craft with (e.g. missing item 
requirements or not enough cash).

---

There are also a few extra parts that may be useful. They are the following:

BLUEPRINT.takeCash: This is the amount of cash taken from a player and acts as a requirement. If the
player is missing the amount defined here, they won't be able to craft with the blueprint.

BLUEPRINT.giveCash: This is the amount of cash given to a player and does NOT act as a requirement (same
as how BLUEPRINT.giveItems doesn't act as a requirement).

BLUEPRINT.category: Which category the blueprint will be located under.

BLUEPRINT.description: Description a user can read when hovering their mouse over the blueprint.

BLUEPRINT.model: What model the blueprint will appear as on the crafting menu.

BLUEPRINT.name: The name of the blueprint that will show at the top of the blueprint when hovering over
it in the crafting menu. Note: The name also acts as its unique ID, however it will be in all lowercase 
and all spaces will be substituted with underscores (_).





















