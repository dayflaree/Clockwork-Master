--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:Add("distortion_error", 32, true);
Clockwork.config:Add("distortion_minimum", 2048, true);
Clockwork.config:Add("distortion_maximum", 12288, true);