--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;
local RunConsoleCommand = RunConsoleCommand;
local pairs = pairs;
local ScrH = ScrH;
local ScrW = ScrW;
local table = table;
local vgui = vgui;
local math = math;

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local scrH = ScrH();
	local scrW = ScrW();

	self.createTime = SysTime();
	
	self:SetPos(0, 0);
	self:SetSize(scrW, scrH);
	self:SetPaintBackground(false);
	self:SetMouseInputEnabled(true);
	self:SetKeyboardInputEnabled(true);
	
	self.panelList = vgui.Create("cwPanelList", self);
 	self.panelList:SetPadding(2);
 	self.panelList:SetSpacing(3);
 	self.panelList:SizeToContents();
	self.panelList:EnableVerticalScrollbar( true )
	
	self.disconnectButton = vgui.Create("cwLabelButton", self);
	self.disconnectButton:SetFont(smallTextFont);
	self.disconnectButton:SetText("DISCONNECT");
	self.disconnectButton:FadeIn(0.5);
	self.disconnectButton:SetCallback(function(panel)
		RunConsoleCommand("disconnect");
	end);
	self.disconnectButton:SizeToContents();
	self.disconnectButton:SetMouseInputEnabled(true);
	self.disconnectButton:SetPos((scrW * 0.2) - (self.disconnectButton:GetWide() / 2), scrH * 0.9);
		
	self.continueButton = vgui.Create("cwLabelButton", self);
	self.continueButton:SetFont(smallTextFont);
	self.continueButton:SetText("CONTINUE");
	self.continueButton:FadeIn(0.5);
	self.continueButton:SetCallback(function(panel)
		Clockwork.datastream:Start("QuizCompleted", true);
	end);
	self.continueButton:SizeToContents();
	self.continueButton:SetMouseInputEnabled(true);
	self.continueButton:SetPos((scrW * 0.8) - (self.continueButton:GetWide() / 2), scrH * 0.9);
end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	Clockwork.kernel:RegisterBackgroundBlur(self, self.createTime);
	
	derma.SkinHook("Paint", "Panel", self);
	
	return true;
end;

-- A function to populate the panel.
function PANEL:Populate()
	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local quizQuestions = Clockwork.quiz:GetQuestions();
	local questions = {};
	local scrH = ScrH();
	local scrW = ScrW();
	
	self.helpForm = vgui.Create("DForm");
	self.helpForm:SetName("Help");
	self.helpForm:SetPadding(4);
	
	local label = vgui.Create("cwInfoText", self);
		label:SetText("Check out these guides for help to complete the quiz.");
		label:SetInfoColor("blue");
	self.panelList:AddItem(label);
	self.panelList:AddItem(self.helpForm);
	
	local helpButton = vgui.Create( "DButton", self.helpForm )
	helpButton:SetText( "Beginners guide" )
	helpButton:SetPos( 10, 25 )
	helpButton:SetSize( 160, 20 )
	helpButton.DoClick = function ()
		gui.OpenURL("http://steamcommunity.com/sharedfiles/filedetails/?id=121164336")
	end
	self.panelList:AddItem(self.helpForm);
	
	local helpButton2 = vgui.Create( "DButton", self.helpForm )
	helpButton2:SetText( "Visit our forums" )
	helpButton2:SetPos( 175, 25 )
	helpButton2:SetSize( 160, 20 )
	helpButton2.DoClick = function ()
		gui.OpenURL("http://gmod.novabox.org/forums/")
	end
	self.panelList:AddItem(self.helpForm);
	
	local helpButton3 = vgui.Create( "DButton", self.helpForm )
	helpButton3:SetText( "Check out all our guides" )
	helpButton3:SetPos( 340, 25 )
	helpButton3:SetSize( 160, 20 )
	helpButton3.DoClick = function ()
		gui.OpenURL("http://gmod.novabox.org/forums/forums/guides.31/")
	end
	self.panelList:AddItem(self.helpForm);
	
	self.questionsForm = vgui.Create("DForm");
	self.questionsForm:SetName(Clockwork.quiz:GetName());
	self.questionsForm:SetPadding(4);
	
	//self.panelList:Clear(true);
	
	local label = vgui.Create("cwInfoText", self);
		label:SetText("If any answers are incorrect, you may be kicked from the server.");
		label:SetInfoColor("orange");
	self.panelList:AddItem(label);

	self.panelList:AddItem(self.questionsForm);
	
	/*local label = vgui.Create("cwInfoText", self);
		label:SetText("Check out the guide buttons at the bottom.");
		label:SetInfoColor("blue");
	self.panelList:AddItem(label);
	self.panelList:AddItem(self.questionsForm);
	
		local helpButton = vgui.Create( "DButton", self.questionsForm )
	helpButton:SetText( "Click to read beginners guide" )
	helpButton:SetPos( 20, 20 )
	helpButton:SetSize( 160, 20 )
	helpButton.DoClick = function ()
		gui.OpenURL("http://steamcommunity.com/sharedfiles/filedetails/?id=121164336")
	end
	self.panelList:AddItem(self.questionsForm);
	
	local helpButton2 = vgui.Create( "DButton", self.questionsForm )
	helpButton2:SetText( "Visit our forums" )
	helpButton2:SetPos( 200, 20 )
	helpButton2:SetSize( 160, 20 )
	helpButton2.DoClick = function ()
		gui.OpenURL("http://gmod.novabox.org/forums")
	end
	self.panelList:AddItem(self.questionsForm);
	
	local helpButton3 = vgui.Create( "DButton", self.questionsForm )
	helpButton3:SetText( "Check out all our guides" )
	helpButton3:SetPos( 400, 20 )
	helpButton3:SetSize( 160, 20 )
	helpButton3.DoClick = function ()
		gui.OpenURL("http://gmod.novabox.org/forums/forums/guides.31/")
	end
	self.panelList:AddItem(self.questionsForm); */
	
	for k, v in pairs(quizQuestions) do
		questions[k] = {k, v};
	end;
	
	table.sort(questions, function(a, b)
		return a[2].question < b[2].question;
	end);
	
	for k, v in pairs(questions) do
		local panel = vgui.Create("DComboBox", self.questionsForm);
		local question = vgui.Create("DLabel", self.questionsForm);
		local key = v[1];
			
		self.questionsForm:AddItem(question);
			
		question:SetText(v[2].question);
		question:SetDark(true);
		question:SizeToContents();
			
		-- Called when an option is selected.
		function panel:OnSelect(index, value, data)
			Clockwork.datastream:Start("QuizAnswer", {key, index});
		end;
			
		for k2, v2 in pairs(v[2].possibleAnswers) do
			panel:AddChoice(v2);
		end;
		
		self.questionsForm:AddItem(panel);
	end;

end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	local scrW = ScrW();
	local scrH = ScrH();
	
	self.panelList:SetSize(scrW * 0.5, math.min(self.panelList.pnlCanvas:GetTall() + 32, ScrH() * 0.75));
	self.panelList:SetPos((scrW / 2) - (self.panelList:GetWide() / 2), (scrH / 2) - (self.panelList:GetTall() / 2));
	
	derma.SkinHook("Layout", "Panel", self);
end;

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true);
end;

vgui.Register("cwQuiz", PANEL, "DPanel");