local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");

function PLUGIN:Initialize()
	-- A function to get the quiz kick Callback.
	function Clockwork.quiz:GetKickCallback()
		if (self.kickCallback) then
			return self.kickCallback;
		else
			return function(player, correctAnswers)
				player:Kick("You got too many questions wrong! Check out guides at Novabox.org for help");
			end;
		end;
	end;
end;
