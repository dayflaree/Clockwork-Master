
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:PlayerDeathThink(player)
	local osTime = os.time();
	if (!player:HasInitialized() or player:GetCharacterData("CharTempBanned", osTime) > osTime) then
		return true;
	end;
end;

-- Called when a player attempts to use a character.
function Clockwork:PlayerCanUseCharacter(player, character)
	if (character.data["CharTempBanned"] and character.data["CharTempBanned"] > os.time()) then
		return character.name.." is temporarily banned and cannot be used!";
	end;
end;

-- Called when a player's character table should be adjusted.
function Clockwork:PlayerAdjustCharacterScreenInfo(player, character, info)
	if (character.data["CharTempBanned"] and character.data["CharTempBanned"] > os.time()) then
		info.banned = true;
		local hours = math.Round((os.time() - character.data["CharTempBanned"]) / 3600, 2);
		info.details = "This character is banned for "..hours.." more hours.";
	end;
end;