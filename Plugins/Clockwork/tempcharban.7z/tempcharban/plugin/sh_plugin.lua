
local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");