
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharUnTempBan");
COMMAND.tip = "Unban a character from being used.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	for k, v in pairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			if (v:Name():lower() == arguments[1]:lower()) then
				Clockwork.player:NotifyAll(player:Name().." unbanned the character '"..v:Name().."'.");
				v:SetCharacterData("CharTempBanned", nil);
				v:SetSharedVar("CharBanned", false);
				
				return;
			else
				for k2, v2 in pairs(v:GetCharacters()) do
					if (v2.name:lower() == arguments[1]:lower()) then
						Clockwork.player:NotifyAll(player:Name().." unbanned the character '"..v2.name.."'.");
						
						v2.data["CharTempBanned"] = nil;
						
						return;
					end;
				end;
			end;
		end;
	end;
	
	Clockwork.player:Notify(player, "Couldn't find the character '"..arguments[1].."', is the owner of it online and on a character?");
end;

COMMAND:Register();