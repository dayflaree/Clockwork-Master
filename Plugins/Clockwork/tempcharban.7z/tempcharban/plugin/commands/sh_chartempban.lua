
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharTempBan");
COMMAND.tip = "Temporarily ban a character from being used.";
COMMAND.text = "<string Name> <string Minutes>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		if (!Clockwork.player:IsProtected(target)) then
			local time = tonumber(arguments[2]);
			if (time and time > 0) then
				target:SetCharacterData("CharTempBanned", os.time() + 60 * time);
				target:SaveCharacter();
				target:SetSharedVar("CharBanned", true);
				local hours = math.Round(time / 60, 2);
				Clockwork.player:NotifyAll(player:Name().." banned the character '"..target:Name().."' for "..hours.." hours.");
				
				target:KillSilent();
			else
				Clockwork.player:Notify(player, arguments[2].." is not a valid time.");
			end;
		else
			Clockwork.player:Notify(player, target:Name().." is protected!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

COMMAND:Register();