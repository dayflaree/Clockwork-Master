local PLUGIN = PLUGIN

util.Include("sv_plugin.lua")

PLUGIN.hotkeyItems = {}

function PLUGIN:CreateHotkeySpawnIcon(itemTable)
	local spawnIcon = cw.core:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self))
	
	-- A function to set the spawn icon's item table.
	spawnIcon.SetItemTable = function(spawnIcon, itemTable)
		spawnIcon.itemTable = itemTable
	end
	
	-- A function to set the spawn icon's hotkey data.
	spawnIcon.SetHotkeyData = function(spawnIcon, hotkeyData)
		spawnIcon.hotkeyData = hotkeyData
	end
	
	-- Called when the spawn icon's menu is opened.
	spawnIcon.OpenMenu = function(spawnIcon)
		cw.core:HandleItemSpawnIconRightClick(spawnIcon.itemTable, spawnIcon);
	end
	
	-- Called when the spawn icon is clicked.
	spawnIcon.DoClick = function(spawnIcon)
		HIDE_HOTKEY_OPTION = true;
		cw.core:HandleItemSpawnIconClick(spawnIcon.itemTable, spawnIcon, function(itemMenu)
			itemMenu:AddOption("Unhotkey", function()
				self:RemoveHotkey(spawnIcon.itemTable);
			end)
		end)
		HIDE_HOTKEY_OPTION = nil;
	end
	
	local model, skin = item.GetIconInfo(itemTable)
		spawnIcon:SetModel(model, skin)
		spawnIcon:SetSize(32, 32)
	return spawnIcon
end

function PLUGIN:Tick()
	if (!IsValid(cw.client) or !cw.client:HasInitialized()
	or type(self.hotkeyItems) != "table") then
		return
	end
	
	local bRemovedOne = false
	local inventory = cw.inventory:GetClient()
	local x = 24
	local y = ScrH() - 56
	
	for k, v in pairs(self.hotkeyItems) do
		local itemTable = cw.inventory:FindItemByName(
			inventory, v.uniqueID, v.name
		)
		
		if (itemTable) then
			if (!IsValid(v.panel)) then
				v.panel = self:CreateHotkeySpawnIcon(itemTable);
			end
			
			if (!cw.client:Alive() or cw.client:IsRagdolled()) then
				v.panel:SetVisible(false)
			else
				v.panel:SetVisible(true)
			end
			
			v.panel:SetHotkeyData(v);
			v.panel:SetItemTable(itemTable);
			v.panel:SetColor(itemTable.color);
			v.panel:SetModel(item.GetIconInfo(itemTable));
			v.panel:SetMarkupToolTip(item.GetMarkupToolTip(itemTable));
			v.panel:SetPos(x, y); x = x + 40
		else
			table.remove(self.hotkeyItems, k)
			bRemovedOne = true
			
			if (IsValid(v.panel)) then
				v.panel:Remove()
			end
		end
	end
	
	if (bRemovedOne) then
		self:SaveHotkeys()
	end
end

function PLUGIN:HUDPaint()
	local colorWhite = cw.option:GetColor("white")
	local curTime = CurTime()
	
	if (cw.client:HasInitialized()) then
		local x = 16
		local y = ScrH() - 64
		
		--draw.RoundedBox(4, x, y, 408, 48, Color(0, 0, 0, 100))
		cw.core:DrawTexturedGradientBox(4, x, y, 408, 48, Color(0, 0, 0, 150), 255)
		
		for i = 0, 9 do
			local hotkeyData = self.hotkeyItems[i + 1]
			local boxX = x + (40 * i) + 8
			local boxY = y + 8
			
			if (hotkeyData) then
				local itemsList = cw.inventory:FindItemsByName(
					cw.inventory:GetClient(), hotkeyData.uniqueID,
					hotkeyData.name
				);
				
				cw.core:OverrideMainFont("DermaDefault");
					cw.core:DrawInfo(
						tostring(#itemsList), boxX + 16, boxY - 28, colorWhite, 255
					);
				cw.core:OverrideMainFont(false)
			end
			
			--draw.RoundedBox(4, boxX, boxY, 32, 32, Color(255, 255, 255, 50))
			cw.core:DrawTexturedGradientBox(4, boxX, boxY, 32, 32, Color(200, 200, 200, 50), 255)

			cw.core:OverrideMainFont("DermaDefault");
			cw.core:DrawSimpleText("Hold c to click on a hotkey slot. You can use the inventory menu to add hotkeys.", x + 12, y + 42, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, false, 1)
		end
	end
end

function PLUGIN:PlayerAdjustItemMenu(itemTable, menuPanel, itemFunctions)
	if (#self.hotkeyItems < 10 and !HIDE_HOTKEY_OPTION) then
		for k, v in pairs(self.hotkeyItems) do
			if (v.uniqueID == itemTable.uniqueID
			and v.name == itemTable.name) then
				return
			end
		end
		
		menuPanel:AddOption("Hotkey", function()
			Clockwork.datastream:Start("wnigger", itemTable);
		end)
	end
end