local PLUGIN = PLUGIN

local itemTable = itemTable

--[[-- A function to load the hotkeys.
function PLUGIN:PlayerCharacterInitialized(player)
	if (self.hotkeyItems) then
		for k, v in pairs(self.hotkeyItems) do
			v.panel:Remove()
		end
	end
	
	self.hotkeyFile = "hotkeys/"..player:GetCharacterKey()
	self.hotkeyItems = cw.core:RestoreSchemaData(self.hotkeyFile)
end--]]