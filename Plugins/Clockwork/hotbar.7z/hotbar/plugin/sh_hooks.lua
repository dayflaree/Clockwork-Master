local PLUGIN = PLUGIN

if (SERVER) then
	-- A function to load the hotkeys.
	function PLUGIN:PlayerCharacterInitialized(player)
		if (self.hotkeyItems) then
			for k, v in pairs(self.hotkeyItems) do
				v.panel:Remove()
			end
		end
		
		self.hotkeyFile = "hotkeys/"..player:GetCharacterKey()
		self.hotkeyItems = cw.core:RestoreSchemaData(self.hotkeyFile)
	end

	-- A function to save the hotkeys.
	function PLUGIN:SaveHotkeys()
		local hotkeyItems = {}
			for k, v in pairs(self.hotkeyItems) do
				table.insert(hotkeyItems, {uniqueID = v.uniqueID, name = v.name})
			end
		cw.core:SaveSchemaData("hotkeys/"..self.hotkeyFile, hotkeyItems)
	end

	-- A function to add a new hotkey.
	function PLUGIN:AddHotkey(itemTable)
		if (#self.hotkeyItems < 10) then
			table.insert(self.hotkeyItems, {
				uniqueID = itemTable.uniqueID, name = itemTable.name
			})
			
			self:SaveHotkeys()
		end
	end
	-- A function to remove a hotkey.
	function PLUGIN:RemoveHotkey(itemTable)
		for k, v in pairs(self.hotkeyItems) do
			if (v.uniqueID == itemTable.uniqueID) and (v.name == itemTable.name) then
				table.remove(self.hotkeyItems, k)
				v.panel:Remove()
			end
		end
		
		self:SaveHotkeys()
	end
	
	Clockwork.datastream:Hook("wnigger", function(player, data)
		PLUGIN:AddHotkey(data)
	end);
end;