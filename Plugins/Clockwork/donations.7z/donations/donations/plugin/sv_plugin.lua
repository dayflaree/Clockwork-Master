
local PLUGIN = PLUGIN;

PLUGIN.API = "https://lemonpunch.net/staff/index.php/api";
PLUGIN.reset = "";
PLUGIN.userGroups = {
	["founder"] = "petrcCHn",
	["superadmin"] = "petrcCHn",
	["admin"] = "petrc",
	["operator"] = "pc"	
};
PLUGIN.donatorRanks = {
	["cw:gold"] = "petrHD",
	["cw:silver"] = "petD"
};
