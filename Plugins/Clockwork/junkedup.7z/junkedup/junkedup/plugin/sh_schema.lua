local PLUGIN = PLUGIN;

Clockwork.flag:Add("k", "Access to the Junk menu", "Ability to have access to all junk items.");
Clockwork.flag:Add("K", "Access to the Food Junk", "This includes Necrotic Meat ect.");