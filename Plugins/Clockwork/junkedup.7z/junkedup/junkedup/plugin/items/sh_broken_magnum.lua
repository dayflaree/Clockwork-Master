--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken 357. Magnum";
ITEM.cost = 35;
ITEM.model = "models/weapons/w_357.mdl";
ITEM.weight = 1.5;
ITEM.access = "v";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A old rusted magnum, won't seem to work.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
