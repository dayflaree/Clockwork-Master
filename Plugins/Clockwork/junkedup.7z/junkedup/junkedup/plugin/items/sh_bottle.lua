local ITEM = Clockwork.item:New();

ITEM.name = "Bottle";
ITEM.cost = 35;
ITEM.model = "models/props_junk/GlassBottle01a.mdl";
ITEM.weight = 0.2;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A round glass bottle";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
