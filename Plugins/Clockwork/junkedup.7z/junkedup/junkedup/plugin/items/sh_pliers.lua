--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Pliers";
ITEM.cost = 50;
ITEM.model = "models/props_c17/tools_pliers01a.mdl";
ITEM.weight = 0.9;
ITEM.access = "v";
ITEM.batch = 1;
ITEM.category = "Tools";
ITEM.business = true;
ITEM.description = "A heavy set of pliers.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
