local ITEM = Clockwork.item:New();

ITEM.name = "Gunpowder";
ITEM.cost = 45;
ITEM.model = "models/props_lab/box01a.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Gunsmithing";
ITEM.business = true;
ITEM.description = "A small box with a fine black powder.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();