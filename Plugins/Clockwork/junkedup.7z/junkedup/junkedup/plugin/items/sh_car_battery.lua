local ITEM = Clockwork.item:New();

ITEM.name = "Car Battery";
ITEM.cost = 75;
ITEM.model = "models/items/car_battery01.mdl";
ITEM.weight = 0.5;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A battery that used to be in a car.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();