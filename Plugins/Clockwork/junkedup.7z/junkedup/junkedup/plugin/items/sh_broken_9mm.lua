--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken 9MM Pistol";
ITEM.cost = 15;
ITEM.model = "models/weapons/w_pistol.mdl";
ITEM.weight = 0.7;
ITEM.access = "v";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A dusty colted pistol, It won't fire.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
