local ITEM = Clockwork.item:New();

ITEM.name = "Cables";
ITEM.cost = 45;
ITEM.model = "models/Items/CrossbowRounds.mdl";
ITEM.weight = 0.2;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A small bundle of various cables";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
