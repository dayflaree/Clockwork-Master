--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken plank";
ITEM.cost = 15;
ITEM.model = "models/props_wasteland/cafeteria_bench001a_chunk04.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A large pointy broken plank.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
