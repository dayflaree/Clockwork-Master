--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Lock";
ITEM.cost = 15;
ITEM.model = "models/props_wasteland/prison_padlock001a.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A heavy lock, could use it to set a digit on the lockers.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
