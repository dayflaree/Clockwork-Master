--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Lampshade";
ITEM.cost = 15;
ITEM.model = "models/props_c17/lampshade001a.mdl";
ITEM.weight = 0.6;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A lampshade which has been removed from a lamp.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
