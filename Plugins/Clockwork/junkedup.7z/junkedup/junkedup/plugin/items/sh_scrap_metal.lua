local ITEM = Clockwork.item:New();

ITEM.name = "Scrap Metal";
ITEM.cost = 35;
ITEM.model = "models/props_debris/metal_panelchunk02d.mdl";
ITEM.weight = 0.8;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A bent and dirty piece of metal.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();