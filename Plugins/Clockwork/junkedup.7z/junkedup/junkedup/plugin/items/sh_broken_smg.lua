--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken Submachine gun";
ITEM.cost = 60;
ITEM.model = "models/weapons/w_smg1.mdl";
ITEM.weight = 1.8;
ITEM.access = "v";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A Submachine missing some parts, unable to fire any bullets";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
