local ITEM = Clockwork.item:New();

ITEM.name = "Rock";
ITEM.cost = 25;
ITEM.model = "models/props_junk/rock001a.mdl";
ITEM.weight = 2;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A solid piece of stone that useful for hitting things.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();