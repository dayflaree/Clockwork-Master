--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Glass piece";
ITEM.cost = 25;
ITEM.model = "models/props_junk/garbage_glassbottle003a_chunk01.mdl";
ITEM.weight = 0.6;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "A sharp piece of broken glass, could use it as a shiv.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
