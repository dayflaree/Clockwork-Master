local ITEM = Clockwork.item:New();

ITEM.name = "Bullet Casings";
ITEM.cost = 35;
ITEM.model = "models/items/ammobox.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Gunsmithing";
ITEM.business = true;
ITEM.description = "A box with various bullet casings.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();