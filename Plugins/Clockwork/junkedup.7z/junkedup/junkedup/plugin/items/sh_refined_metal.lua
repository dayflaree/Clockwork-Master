local ITEM = Clockwork.item:New();

ITEM.name = "Refined Metal";
ITEM.cost = 65;
ITEM.model = "models/gibs/metal_gib2.mdl";
ITEM.weight = 2;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A strong and clean piece of metal.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();