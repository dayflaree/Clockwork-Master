local ITEM = Clockwork.item:New();

ITEM.name = "Scrap Electronics";
ITEM.cost = 35;
ITEM.model = "models/props_lab/reciever01d.mdl";
ITEM.weight = 0.4;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Scrap";
ITEM.business = true;
ITEM.description = "An item full of mangled electrical parts.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();