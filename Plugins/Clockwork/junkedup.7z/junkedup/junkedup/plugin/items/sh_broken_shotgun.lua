--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken Shotgun";
ITEM.cost = 50;
ITEM.model = "models/weapons/w_shotgun.mdl";
ITEM.weight = 2;
ITEM.access = "v";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A light shotgun, It'd be rusted to hell";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
