--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Lever";
ITEM.cost = 35;
ITEM.model = "models/props_wasteland/prison_throwswitchlever001.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Tools";
ITEM.business = true;
ITEM.description = "A broken lever. Could be used as a hammer.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
