local ITEM = Clockwork.item:New();

ITEM.name = "Box of Screws";
ITEM.cost = 35;
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 0.5;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A small box full of various screws.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();