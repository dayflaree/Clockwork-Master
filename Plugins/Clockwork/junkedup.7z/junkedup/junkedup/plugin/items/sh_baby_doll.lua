--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Baby Doll";
ITEM.cost = 35;
ITEM.model = "models/props_c17/doll01.mdl";
ITEM.weight = 2.5;
ITEM.access = "K";
ITEM.batch = 1;
ITEM.useText = "Feast";
ITEM.category = "Edibles";
ITEM.business = true;
ITEM.description = "A doll... with real flesh?";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 9, 0, player:GetMaxHealth() ) );
	Clockwork.player:NotifyAll(player:Name().." has resorted to cannibalism and ate a baby!")
	player:BoostAttribute(self.name, ATB_STAMINA, 1, 220);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();