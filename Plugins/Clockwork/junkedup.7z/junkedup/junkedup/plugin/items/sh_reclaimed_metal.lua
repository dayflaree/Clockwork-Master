local ITEM = Clockwork.item:New();

ITEM.name = "Reclaimed Metal";
ITEM.cost = 47;
ITEM.model = "models/props_lab/pipesystem03a.mdl";
ITEM.weight = 1;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Materials";
ITEM.business = true;
ITEM.description = "A sturdy and tough piece of metal.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();