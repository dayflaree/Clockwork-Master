--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Skull";
ITEM.cost = 10;
ITEM.model = "models/Gibs/HGIBS.mdl";
ITEM.weight = 0.2;
ITEM.access = "k";
ITEM.batch = 1;
ITEM.category = "Bone";
ITEM.business = true;
ITEM.description = "A Skull, from a human body.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
