--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("UseAlterEgo");
COMMAND.tip = "Use one of your alter egos!.";
COMMAND.text = "<int slot>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local ego_list = player:GetCharacterData("alterego", {})
    local currentEgo = player:GetCharacterData("currentego", 0)
    ego_list[currentEgo] = {
        name = player:Name(),
        model = player:GetModel(),
        faction = player:GetFaction(),
        customclass = player:GetCharacterData("customclass", false),
        desc = player:GetCharacterData("PhysDesc", "")
    }
    player:SetCharacterData("alterego", ego_list)
    
    if (ego_list[tonumber(arguments[1])]) then
        local ego = ego_list[tonumber(arguments[1])]
        player:SetCharacterData("Model", ego.model, true);
		player:SetModel(ego.model);
        if (Clockwork.faction.stored[ego.faction]) then
            player:SetSharedVar("Faction", Clockwork.faction.stored[ego.faction].index);
        end;
        player:SetCharacterData("Faction", ego.faction, true);
        Clockwork.class:AssignToDefault(player)
        Clockwork.player:SetName(player,ego.name)
        if ego.customclass then
            player:SetCharacterData( "customclass", ego.customclass );
        else
            player:SetCharacterData( "customclass", nil );
        end
        
        if ego.desc then
            player:SetCharacterData( "PhysDesc", ego.desc );
        end
        player:SetCharacterData("currentego", tonumber(arguments[1]))
        player:SetSharedVar("currentego", tonumber(arguments[1]))
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid slot!");
	end;
end;

COMMAND:Register();