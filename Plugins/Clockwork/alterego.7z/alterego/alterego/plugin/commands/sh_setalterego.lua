--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("SetAlterEgo");
COMMAND.tip = "Set one of the target's alter egos!.";
COMMAND.text = "<string target> <int slot>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] )
	
	if (target) then
		local ego_list = target:GetCharacterData("alterego", {})
        local ego = {}
        Clockwork.dermaRequest:RequestString(player,"Name", "What would you like to set the name to?", "", function(text)
            ego.name = text;
            Clockwork.dermaRequest:RequestString(player,"Model", "What would you like to set the model to?", "", function(text)
                ego.model = text;
				Clockwork.dermaRequest:RequestString(player,"Description", "What would you like to set the description to?", "", function(text)
					ego.desc = text;
					Clockwork.dermaRequest:RequestString(player,"Faction", "What would you like to set the faction to?", "", function(text)
						local factionTable = Clockwork.faction:FindByID(text);
                    
						if (factionTable) then
							ego.faction = factionTable.name
							ego_list[tonumber(arguments[2])] = ego
							target:SetCharacterData("alterego", ego_list)
							Clockwork.player:Notify(player, target:Name() .. "'s ego slot "..arguments[2].." set to (Name: "..ego.name.." Model: "..ego.model.." Description: "..ego.desc.." Faction: "..ego.faction..")");
						else
							Clockwork.player:Notify(player, text.." is not a valid faction!");
						end;
					end)
                end)
            end)
        end)
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;

end;

COMMAND:Register();