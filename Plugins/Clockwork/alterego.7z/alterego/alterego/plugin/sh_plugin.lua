local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("currentego");
end;