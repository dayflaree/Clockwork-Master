
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:Add("kill_on_max_needs", false);
Clockwork.config:Add("hunger_hours", 6);
Clockwork.config:Add("thirst_hours", 4);
Clockwork.config:Add("needs_tick_time", 4);