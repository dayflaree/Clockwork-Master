--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Admin Chat";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This adds a simple chat for admins, they can type /a before their chat to make it admin-only.";