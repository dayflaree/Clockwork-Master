--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "MP9 SD";
	ITEM.cost = 700;
	ITEM.model = "models/weapons/w_bnt_mp9.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "pspak_mp9";
	ITEM.description = "A compact 9mm sub machine gun. It has a silencer fitted on the end of it's threaded barrel, with a retractable stock to go with it. Subsonic ammo must be used for full stealth capability.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();