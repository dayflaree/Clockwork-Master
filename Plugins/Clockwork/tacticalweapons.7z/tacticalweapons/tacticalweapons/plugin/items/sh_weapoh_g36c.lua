--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "German Weapons Case";
	ITEM.cost = 700;
	ITEM.model = "models/props/CS_militia/footlocker01_closed.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "pspak_hk_g36c";
	ITEM.description = "A brown scuffed case. It is heavy, and bears German law enforcement markings on it's side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();