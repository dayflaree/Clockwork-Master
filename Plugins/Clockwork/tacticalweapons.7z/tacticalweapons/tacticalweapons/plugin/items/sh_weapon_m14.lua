--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Jackal's Rifle";
	ITEM.cost = 700;
	ITEM.model = "models/weapons/w_rifl_m14_m.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "pspak_m14";
	ITEM.description = "A green M14 marksman rifle. It's modifications for stealth and weight make it one-of-a-kind; 'JACKAL' is included in it's trademarks.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();