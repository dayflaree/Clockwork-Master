--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "CZ75";
	ITEM.cost = 100;
	ITEM.model = "models/weapons/w_pist_cz75.mdl";
	ITEM.weight = 2;
	ITEM.access = "v";
	ITEM.uniqueID = "pspak_cz_75";
	ITEM.business = false;
	ITEM.description = "A small black 9mm pistol. It has crylic brandings, making it evident that it is a Russian pistol.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();