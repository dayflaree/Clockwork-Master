--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "MSBS Radon";
	ITEM.cost = 700;
	ITEM.model = "models/weapons/w_rifl_msbs.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "pspak_msbs_radon";
	ITEM.description = "A Polish experimental rifle with CTRG camouflage and an attached flashlight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();