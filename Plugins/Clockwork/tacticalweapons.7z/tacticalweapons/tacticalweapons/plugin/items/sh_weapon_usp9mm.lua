--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Heckler and Koch USP-MATCH Ghost Edition";
	ITEM.cost = 100;
	ITEM.model = "models/weapons/w_usp_mtch.mdl";
	ITEM.weight = 2;
	ITEM.access = "v";
	ITEM.uniqueID = "pspak_hk_usp_match";
	ITEM.business = false;
	ITEM.description = "A chunky black USP variant. It has a modded magazine release, ambidextrous action, and a muzzle break fitted. This pistol is optmized for competitive shooting, although this one includes a SILENCERCO suppressor.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();