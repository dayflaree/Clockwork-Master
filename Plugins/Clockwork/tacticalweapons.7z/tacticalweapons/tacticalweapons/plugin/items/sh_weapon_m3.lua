--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Benelli M3";
	ITEM.cost = 800;
	ITEM.model = "models/weapons/w_hnk1_m3super90.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "pspak_benli_m3";
	ITEM.description = "A stock Italian-made shotgun commonly used by law enforcement around the world. It has a rubberised pump and grip.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();