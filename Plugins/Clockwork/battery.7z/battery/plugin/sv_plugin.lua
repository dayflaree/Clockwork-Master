--[[
	Name: sv_auto.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sh_auto.lua");

-- A function to get whether a player has a flashlight.
function PLUGIN:PlayerHasFlashlight(player)
	local weapon = player:GetActiveWeapon();
	
	if ( IsValid(weapon) ) then
		local itemTable = Clockwork.item:GetWeapon(weapon);
		
		if ( weapon:GetClass() == "cw_flashlight" or (itemTable and itemTable.hasFlashlight) ) then
			return true;
		end;
	end;
end;