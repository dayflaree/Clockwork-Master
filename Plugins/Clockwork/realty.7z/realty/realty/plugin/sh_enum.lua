--[[
	© 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (vladimir@sigalkin.ru).
--]]

REQUES_STATE_NONE = 0;
REQUES_STATE_SENDED = 1;
