--[[
	© 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (vladimir@sigalkin.ru).
--]]

Clockwork.config:AddToSystem("(ExT) Realty - Offer time", "realty_invite_time", "Time before next offer.", 0, 300);
Clockwork.config:AddToSystem("(ExT) Realty - Max amount of property.", "realty_max_count", "Max amount of property.", 0, 100);
Clockwork.config:AddToSystem("(ExT) Realty - Interval between taxes.", "realty_taxes_rate", "Interval between taxes.", 0, 259200);