--[[
	� 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (vladimir@sigalkin.ru).
--]]

ENT.Type = "anim";
ENT.Base = "base_anim";
ENT.Author = "ExT";
ENT.PrintName = "Realtyman";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
