--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.config:AddToSystem("(ExT) Hunger tick", "hunger_tick", "How quickly begins hunger.");
Clockwork.config:AddToSystem("(ExT) Hunger default filling", "hunger_default_filling", "How much will be added to hunger, when you eat some food.");