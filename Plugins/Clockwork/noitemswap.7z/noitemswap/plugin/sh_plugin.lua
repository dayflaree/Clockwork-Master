Clockwork.kernel:IncludePrefixed("cl_plugin.lua");

if SERVER then
	function Clockwork:PlayerCanGiveToStorage(player, storageTable, itemTable)
		itemTable.cwPropertyTab = itemTable.cwPropertyTab or {}
		itemTable.cwPropertyTab.key = player:GetCharacterKey()
		itemTable.cwPropertyTab.uniqueID = player:UniqueID()
		return true
	end

	function Clockwork:PlayerCanTakeFromStorage(player, storageTable, itemTable)
		if itemTable.cwPropertyTab then
			if self.entity:BelongsToAnotherCharacter(player, itemTable) then
				self.player:Notify(player, "You cannot take an item you have stored on another character!")
				self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has attempted to take an item stored by another character (item swap).")

				return false
			else
				itemTable.cwPropertyTab = nil
			end
		end

		return true
	end
end

--[[
if SERVER then
    function PLUGIN:ClockworkInitialized()
        Clockwork.config:Get("recognise_system"):Set(true,game.GetMap(),true)
    end
    
    function PLUGIN:ShowTeam(player)
        local target = player:GetEyeTraceNoCursor().Entity
        if target then
            if target:IsPlayer() then
                Clockwork.dermaRequest:RequestString(player, "Recognise", "By which name do you want to recognise this person?", "", function(name)
                    self:Recognise(player,target,name)
                end)
                return true
            end
        end
    end
    
    function PLUGIN:DoesRecognise(player,target)
        if Clockwork.player:HasFlags(player, "S") then return target:Name() end
        if player == target then return target:Name() end
        if Schema.PlayerIsCombine then
            if Schema:PlayerIsCombine(target) then return target:Name() end
        end
        if target:GetFaction() == FACTION_ADMIN then return target:Name() end
        
        recog_data = player:GetCharacterData("recog_data", {})
        
        local key = tostring(target:GetCharacterKey()).."_"..(target:GetSharedVar("currentego") or 0)
        
        if recog_data[key] then 
            return recog_data[key]
        elseif Clockwork.player:DoesRecognise(player, target) then
            return target:Name()
        else
            return false
        end
    end
    
    function PLUGIN:Recognise(player,target,name)
        recog_data = player:GetCharacterData("recog_data", {})
        local key = tostring(target:GetCharacterKey()).."_"..(target:GetSharedVar("currentego") or 0)
        
        recog_data[key] = name
        player:SetCharacterData("recog_data", recog_data)
        Clockwork.datastream:Start(player, "recog_data",recog_data)
    end
    
    function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
        Clockwork.datastream:Start(player, "recog_data", player:GetCharacterData("recog_data", {}))
    end
else
    Clockwork.datastream:Hook("recog_data", function(data)
        PLUGIN.data = data
    end)

    function PLUGIN:DoesRecognise(target)
        if Clockwork.player:HasFlags(LocalPlayer(), "S") then return target:Name() end
        if LocalPlayer() == target then return target:Name() end
        if Schema.PlayerIsCombine then
            if Schema:PlayerIsCombine(target) then return target:Name() end
        end
        if target:GetFaction() == FACTION_ADMIN then return target:Name() end
        
        if !self.data then return false end
        
        local key = tostring(Clockwork.player:GetCharacterKey(target)).."_"..(target:GetSharedVar("currentego") or 0)
        
        if self.data[key] then 
            return self.data[key]
        elseif Clockwork.player:DoesRecognise(target) then
            return target:Name()
        else
            return false
        end
    end
    
    function PLUGIN:PlayerDoesRecognisePlayer( player, status, isAccurate, realValue)
        if !self.data then return end
        
        local key = tostring(Clockwork.player:GetCharacterKey(player)).."_"..(player:GetSharedVar("currentego") or 0)
        
        if self.data[key] then 
            return true
        end
    end
    
    function PLUGIN:GetTargetPlayerName(target)
        local name = self:DoesRecognise(target)
        if name then
            return name
        end
    end
    
    function PLUGIN:ChatBoxAdjustInfo(info)
        if (IsValid(info.speaker)) then
            if info.class == "ooc" then
                info.name = info.speaker:SteamName()
            elseif info.class == "pm" or info.class == "looc" then
                local name = self:DoesRecognise(info.speaker)
                if name then
                    info.name = name .. " ("..info.speaker:SteamName()..")"
                else
                    local physDesc = Clockwork.player:GetPhysDesc(info.speaker);
                    
                    if (string.len(physDesc) > 32) then
                        info.name = string.sub(physDesc, 1, 32).."..." .. " ("..info.speaker:SteamName()..")";
                    else
                        info.name = physDesc .. " ("..info.speaker:SteamName()..")";
                    end;
                end
            else
                local name = self:DoesRecognise(info.speaker)
                if name then
                    info.name = name
                else
                    local physDesc = Clockwork.player:GetPhysDesc(info.speaker);
                    
                    if (string.len(physDesc) > 32) then
                        info.name = string.sub(physDesc, 1, 32).."...";
                    else
                        info.name = physDesc;
                    end;
                end
            end;
        end
    end;

    function PLUGIN:ScoreboardAdjustPlayerInfo(info)
        local player = info.player
        local name = self:DoesRecognise(player)
        local physDesc = Clockwork.player:GetPhysDesc(player);
        
        if (name) then
            info.name = name
            
            info.text = physDesc
        else
            info.name = player:SteamName();
            
            info.text = "You do not recognise the character.";
        end;
    end
    
    function PLUGIN:GetAdminESPInfo(info)
        for k, v in pairs(cwPlayer.GetAll()) do
            if (v:HasInitialized()) then
                local physBone = v:LookupBone("ValveBiped.Bip01_Head1");
                local bonePosition = nil;
                
                if (physBone) then
                    bonePosition = v:GetBonePosition(physBone);
                end
                    
                if (string.find(v:GetModel(), "vortigaunt")) then
                    bonePosition = v:GetBonePosition(v:LookupBone("ValveBiped.Head"));
                end;
                    
                local position = nil;
                    
                if (bonePosition) then
                    position = bonePosition + Vector(0, 0, 16);
                else
                    position = v:GetPos() + Vector(0, 0, 80);
                end;
                
                info[#info + 1] = {
                    position = position,
                    color = cwTeam.GetColor(v:Team()),
                    text = v:Name().." ("..v:SteamName()..")("..v:Health().."/"..v:GetMaxHealth()..")"
                };
            end;
        end;
        
        return true
    end;
end
--]]