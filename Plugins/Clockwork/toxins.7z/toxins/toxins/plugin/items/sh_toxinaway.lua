local ITEM = Clockwork.item:New();
ITEM.name = "Toxin Away";
ITEM.uniqueID = "radaway";
ITEM.cost = 35;
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Drink";
ITEM.category = "Medical";
ITEM.access = "T";
ITEM.business = true;
ITEM.description = "A small bottle with a skull and two bones crossing it, labeled with Toxin Away.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData( "radiation", math.Clamp(player:GetCharacterData("radiation") - 40, 0, 100) );
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);