local PLUGIN = PLUGIN;

function PLUGIN:GetPlayerInfoText(playerInfoText)
	local rads = Clockwork.Client:GetSharedVar("radiation");
	if (rads) then
		playerInfoText:Add("RAD", "Toxin Level: "..rads);
	end;
end;

-- Called when the bars are needed.
function PLUGIN:GetBars(bars)
	local radiation = Clockwork.Client:GetSharedVar("radiation");
	
	if (!self.radiation) then
		self.radiation = radiation;
	else
		self.radiation = math.Approach(self.radiation, radiation, 1);
	end;
	
	if (self.radiation > 1) then
		bars:Add("RADIATION", Color( 29, 0, 36, 100), "Toxins", self.radiation, 100, self.radiation > 25, 1);
	end;
end;