ClockworkKodeRedeemer
=====================
A donation script for clockwork

# No support will be given if you have **not read** the instructions and IPN guide.

# Note:
## If you have a random mysql port number you must modify the mysql connection script see example 1, second part in http://php.net/manual/en/mysqli.quickstart.connections.php
