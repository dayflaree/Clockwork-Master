Hello pal, thanks for downloading this plugin.

This is basically implementation of features, that could be in Clockwork but were not added.

Plugins included:
Apply v3.0
Crafting
Upgraded Trash

WARNING! This plugin is incompatible with:
RJ's Junk or any other Junk plugin.
RJ's Crafting or any other Crafting plugin.

ToDo List:
Clockwork Redesign in Modern Style.
Better "C" Menu.
Weapon Stats.
Better hit system.
Better attributes.
Real-time IC chat messages.
Better Graphics mod.