--[[
	© 2013 TeslaCloud Studios Ltd.
	Do not edit or re-distribute this code without Author's permission.
	(thegarry@teslacloud.net)
	
	As this plugin has many authors - I will be the main one.
	Use it and have fun.
--]]

PLUGIN = PLUGIN
local startTime = os.clock()

print("[CW2] Plugin initialization started...")

Clockwork.kernel:IncludePrefixed("cl_plugin.lua")
Clockwork.kernel:IncludePrefixed("sv_plugin.lua")
Clockwork.kernel:IncludePrefixed("sh_configs.lua")

print("[CW2] Plugin took "..math.Round(os.clock() - startTime, 3).. " second(s) to initialize.")