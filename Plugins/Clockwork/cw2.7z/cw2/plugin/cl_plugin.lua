--[[
	© 2013 TeslaCloud Studios Ltd.
	Do not edit or re-distribute this code without Author's permission.
	(thegarry@teslacloud.net)
	
	As this plugin has many authors - I will be the main one.
	Use it and have fun.
--]]

PLUGIN = PLUGIN

Clockwork.config:AddToSystem("[CW2] Enable Apply Plugin", "apply_enabled", "Load Apply Plugin?")