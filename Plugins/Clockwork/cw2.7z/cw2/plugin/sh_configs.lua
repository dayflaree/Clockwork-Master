--[[
	© 2013 TeslaCloud Studios Ltd.
	Do not edit or re-distribute this code without Author's permission.
	(thegarry@teslacloud.net)
	
	As this plugin has many authors - I will be the main one.
	Use it and have fun.
--]]

PLUGIN = PLUGIN
CW2 = CW2 or {}

--[[ Configs Rulez ]]--

CW2.devmode           = 1 -- Enable Developer mode that basically just prints notes in console.
CW2.menucolor         = Color(