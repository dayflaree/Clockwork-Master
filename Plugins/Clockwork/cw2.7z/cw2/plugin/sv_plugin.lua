--[[
	� 2013 TeslaCloud Studios Ltd.
	Do not edit or re-distribute this code without Author's permission.
	(thegarry@teslacloud.net)
	
	As this plugin has many authors - I will be the main one.
	Use it and have fun.
--]]

PLUGIN = PLUGIN

Clockwork.config:Add("apply_enabled", true)

if ( CW2.devmode == 1 ) then
	print("[CW 2} Initializing Cloud Systems...")
end

--A function to receive Apply Plugin Code from Cloud and Run it.
function PLUGIN:GetCloudPlugin(pluginName)
	if ( Clockwork.config:Get(pluginName.."_enabled") == 1 ) then
		timer.Simple( 0, function()

			local startTime = SysTime();
			local hostRequest = "http://auth.teslacloud.net/thegarry/" ..pluginName.. ".lua"
	
			http.Fetch( hostRequest, function( code, size, ... )
				if ( CW2.devmode == 1 ) then
					print( "[" ..pluginName.. "] Received code from cloud [" ..size.. " bytes] in " .. ( SysTime() - startTime ) .. " seconds." );
				end
			
				CompileString(code, pluginName)()
			end)
		end)
	end
end

PLUGIN:GetCloudPlugin("apply")