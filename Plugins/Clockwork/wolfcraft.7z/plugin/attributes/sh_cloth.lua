--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = Clockwork.attribute:New()
	ATTRIBUTE.name = "Ткачество"
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "cloth"
	ATTRIBUTE.description = "Определяет, как хорошо Вы создаете изделия из ткани."
	ATTRIBUTE.isOnCharScreen = false
	ATTRIBUTE.category = "Навыки"
ATB_CLOTH = Clockwork.attribute:Register(ATTRIBUTE);