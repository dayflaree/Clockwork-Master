--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = Clockwork.attribute:New()
	ATTRIBUTE.name = "Ремонт"
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "rem"
	ATTRIBUTE.description = "Определяет, как хорошо Вы создаете и ремонтируете оружие или экипировку."
	ATTRIBUTE.isOnCharScreen = false
	ATTRIBUTE.category = "Навыки"
ATB_REPAIR = Clockwork.attribute:Register(ATTRIBUTE);