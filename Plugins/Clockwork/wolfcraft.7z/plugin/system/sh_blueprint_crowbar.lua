local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Монтировка"
BLUEPRINT.uniqueID = "blueprint_crowbar"
BLUEPRINT.model = "models/weapons/w_crowbar.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Заточить концы арматурины и загнуть."
BLUEPRINT.reqatt = {
	{"rem", 20}
}
BLUEPRINT.updatt = {
	{"rem", 20}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"refined_metal", 2},
}
BLUEPRINT.finish = {
	{"weapon_crowbar", 1}
}
BLUEPRINT:Register();