local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Древесный уголь"
BLUEPRINT.uniqueID = "blueprint_charcoal"
BLUEPRINT.model = "models/gibs/furniture_gibs/furnituredrawer002a_gib03.mdl"
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "Закинув в печь немного деревянных обломков, можно получить какой-никакой уголь."
BLUEPRINT.craftplace = "cw_craft_furnace"
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"wooden_parts", 3},
}
BLUEPRINT.finish = {
	{"charcoal", 1}
}
BLUEPRINT:Register();