local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Патроны .357 Магнум"
BLUEPRINT.uniqueID = "blueprint_ammo_357"
BLUEPRINT.model = "models/items/357ammo.mdl"
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "Коробка патронов калибра .357 Магнум."
BLUEPRINT.craftplace = "cw_craft_bullet"
BLUEPRINT.reqatt = {
	{"rem", 40}
}
BLUEPRINT.updatt = {
	{"rem", 20}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 2},
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"ammo_357", 1}
}
BLUEPRINT:Register();