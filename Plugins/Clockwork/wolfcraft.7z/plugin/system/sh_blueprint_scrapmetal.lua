local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Металлолом"
BLUEPRINT.uniqueID = "blueprint_scrapmetal"
BLUEPRINT.model = "models/props_debris/metal_panelchunk02d.mdl"
BLUEPRINT.category = "Переработка мусора"
BLUEPRINT.description = "Переплавить банки в металлолом."
BLUEPRINT.craftplace = "cw_craft_furnace"
BLUEPRINT.reqatt = {}
BLUEPRINT.updatt = {
	{"rem", 7}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_soda_can", 5},
	{"charcoal", 1}
}
BLUEPRINT.finish = {
	{"scrap_metal", 1}
}
BLUEPRINT:Register();