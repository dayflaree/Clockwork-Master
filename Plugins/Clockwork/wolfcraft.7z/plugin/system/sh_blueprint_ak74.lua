local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "AK-74"
BLUEPRINT.uniqueID = "blueprint_ak74"
BLUEPRINT.model = "models/weapons/w_ak74.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Починить автомат, заменив некоторые детали."
BLUEPRINT.craftplace = "cw_crafttable"

BLUEPRINT.recipe = {
	{"box_of_bolts", 1}
}
BLUEPRINT.finish = {
	{"box_of_bolts", 100}
	}
BLUEPRINT:Register();