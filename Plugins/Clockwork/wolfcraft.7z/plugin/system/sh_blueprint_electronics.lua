local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Электрозапчасти"
BLUEPRINT.uniqueID = "blueprint_electronics"
BLUEPRINT.model = "models/props_lab/reciever01d.mdl"
BLUEPRINT.category = "Материалы"
BLUEPRINT.description = "Из этого мусора можно выудить пару ценных элементов."
BLUEPRINT.reqatt = {}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"scrap_electronics", 2}
}
BLUEPRINT.finish = {
	{"refined_electronics", 1}
}
BLUEPRINT:Register();