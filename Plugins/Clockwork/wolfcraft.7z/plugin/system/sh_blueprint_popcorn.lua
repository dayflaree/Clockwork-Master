local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Попкорн"
BLUEPRINT.uniqueID = "blueprint_popcorn"
BLUEPRINT.model = "models/bioshockinfinite/topcorn_bag.mdl"
BLUEPRINT.category = "Еда"
BLUEPRINT.description = "Зерна кукурузы следует хорошенько прогреть."
BLUEPRINT.craftplace = "cw_craft_cook"
BLUEPRINT.reqatt = {
	{"cook", 10}
}
BLUEPRINT.updatt = {
	{"cook", 10}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"corn", 2},
	{"empty_carton", 3}
}
BLUEPRINT.finish = {
	{"popcorn", 3}
}
BLUEPRINT:Register();