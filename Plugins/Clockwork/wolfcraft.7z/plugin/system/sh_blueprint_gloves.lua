local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Перчатки"
BLUEPRINT.uniqueID = "blueprint_gloves"
BLUEPRINT.model = "models/tnb/items/gloves.mdl"
BLUEPRINT.category = "Одежда"
BLUEPRINT.description = "Сшить из ткани пару перчаток."
BLUEPRINT.required = {}
BLUEPRINT.updatt = {
	{"cloth", 15}
}
BLUEPRINT.recipe = {
	{"cloth", 1},
}
BLUEPRINT.finish = {
	{"gloves", 1}
}
BLUEPRINT:Register();