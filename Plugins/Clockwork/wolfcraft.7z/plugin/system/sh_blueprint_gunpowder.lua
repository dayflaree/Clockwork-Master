local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Порох"
BLUEPRINT.uniqueID = "blueprint_gunpowder"
BLUEPRINT.model = "models/props_lab/box01a.mdl"
BLUEPRINT.category = "Вещества"
BLUEPRINT.description = "Черный порошок."
BLUEPRINT.craftplace = "cw_craft_chem"
BLUEPRINT.required = {}
BLUEPRINT.updatt = {
	{"chem", 15}
}
BLUEPRINT.recipe = {
	{"selitra", 2},
	{"charcoal", 1},
	{"sulphur", 1},
}
BLUEPRINT.finish = {
	{"gunpowder", 3}
}
BLUEPRINT:Register();