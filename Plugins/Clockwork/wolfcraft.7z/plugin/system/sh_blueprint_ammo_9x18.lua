local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Патроны 9х18мм"
BLUEPRINT.uniqueID = "blueprint_ammo_9x18"
BLUEPRINT.model = "models/items/boxsrounds.mdl"
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "Коробка патронов калибра 9х18мм."
BLUEPRINT.craftplace = "cw_craft_bullet"
BLUEPRINT.reqatt = {
	{"rem", 25}
}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 1},
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"ammo_9x19", 1}
}
BLUEPRINT:Register();