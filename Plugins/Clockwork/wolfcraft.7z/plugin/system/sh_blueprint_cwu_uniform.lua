local BLUEPRINT = Clockwork.blueprints:New()

BLUEPRINT.name = "Рубашка ГСР"
BLUEPRINT.uniqueID = "blueprint_cwu_uniform"
BLUEPRINT.model = "models/tnb/items/shirt_citizen1.mdl"
BLUEPRINT.category = "Одежда"
BLUEPRINT.description = "Сшить из ткани белую рубашку."
BLUEPRINT.required = {}
BLUEPRINT.updatt = {
	{"cloth", 45}
}
BLUEPRINT.reqatt = {
	{"cloth", 20}
}
BLUEPRINT.recipe = {
	{"cloth", 5},
}
BLUEPRINT.finish = {
	{"cwu_uniform", 1}
}
BLUEPRINT:Register();