DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "AleXXX_007"
ENT.PrintName = "Оружейная мастерская"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false
ENT.IsCraft = true

ENT.Model = "models/mosi/fallout4/furniture/workstations/armorworkbench.mdl"
ENT.Category = "HL2RP: Мастерские"

function ENT:SetupDataTables()

end