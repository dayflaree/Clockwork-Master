DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "SchwarzKruppzo"
ENT.PrintName = "Верстак"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false
ENT.IsCraft = true

ENT.Model = "models/props_wasteland/controlroom_desk001b.mdl"
ENT.Category = "HL2RP: Мастерские"

function ENT:SetupDataTables()

end