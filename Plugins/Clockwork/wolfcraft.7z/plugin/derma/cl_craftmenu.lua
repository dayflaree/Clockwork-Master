local Clockwork = Clockwork;
local pairs = pairs;
local table = table;
local vgui = vgui;
local math = math;
local PLUGIN = PLUGIN

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());

	self.info = vgui.Create("cwInfoText", self);
	self.info:Dock( TOP )
	self.info:DockMargin( 4, 4, 4, 4 )
	self.info:SetInfoColor(Clockwork.option:GetColor("target_id"))

	self.panelList = vgui.Create("cwPanelList", self)
 	self.panelList:SetPadding(8)
 	self.panelList:SetSpacing(4)
 	self.panelList:StretchToParent( 4, 38, 4, 38 )
 	self.panelList:HideBackground()

	self.closeButton = vgui.Create("cwInfoText", self)
	self.closeButton:SetText("Закрыть меню");
    self.closeButton:Dock( BOTTOM )
    self.closeButton:SetButton(true);
    self.closeButton:SetInfoColor("red")
    self.closeButton:DockMargin( 4, 4, 4, 4 )
	self.closeButton:SetShowIcon(false)
	self.closeButton.DoClick = function(button)
	
	Clockwork.datastream:Start( "CraftCloseMenu" )
		self:Remove()
	end;
	
	timer.Simple(0, function()
		self:Rebuild();
		self.info:SetText("Крафт меню")
	end);
end;

-- A function to rebuild the panel.
function PANEL:Rebuild()
	self.panelList:Clear();

	local categories = {};
	local blueprints = {};

	for k, v in pairs(Clockwork.blueprints:GetAll()) do
		if (v.craftplace == self.class and LocalPlayer():CanSeeCraft(v)) then
		local blueprintCategory = v("category");
		blueprints[blueprintCategory] = blueprints[blueprintCategory] or {};
		blueprints[blueprintCategory][#blueprints[blueprintCategory] + 1] = v;
	end
	end;

	for k, v in pairs(blueprints) do
		categories[#categories + 1] = {
			blueprints = v,
			category = k
		}
	end;

	table.sort(categories, function(a, b)
		return a.category < b.category;
	end);


	for k, v in pairs(categories) do
		local categoryForm = vgui.Create("cwBasicForm", self);
		categoryForm:SetPadding(8);
		categoryForm:SetSpacing(8);
		categoryForm:SetAutoSize(true);
		categoryForm:SetText(v.category, nil, "basic_form_highlight")

		local categoryList = vgui.Create("DPanelList", categoryForm);
			categoryList:EnableHorizontal(true);
			categoryList:SetAutoSize(true);
			categoryList:SetPadding(4);
			categoryList:SetSpacing(4);
		categoryForm:AddItem(categoryList);

		table.sort(v.blueprints, function(a, b)
			return a("name") < b("name")
		end)

		for k2, v2 in pairs(v.blueprints) do
			self.bpData = {
				bpTable = v2
			}

			categoryList:AddItem(vgui.Create("cwCraftBlueprint", self));
		end

		self.panelList:AddItem(categoryForm)
	end

	self.panelList:InvalidateLayout(true)
end;

-- Called when the panel is selected.
function PANEL:OnSelected() self:Rebuild(); end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h) end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	DERMA_SLICED_BG:Draw(0, 0, w, h, 8, COLOR_WHITE);
	--draw.RoundedBox(0, 0, 0, w, h, Clockwork.option:GetColor("panel_background"));
	return true;
end;

vgui.Register("cwCraft", PANEL, "EditablePanel");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local bpData = self:GetParent().bpData;
	self:SetSize(48, 48);
	self.bpTable = bpData.bpTable;

	local model, skin = self.bpTable("model"), self.bpTable("skin")
	self.spawnIcon = Clockwork.kernel:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self));

	if (Clockwork.CraftCooldown and CurTime() < Clockwork.CraftCooldown) then
		self.spawnIcon:SetCooldown(Clockwork.CraftCooldown);
	end

	function self.spawnIcon.DoClick(spawnIcon)
		Clockwork.datastream:Start(
			"CraftItem", self.bpTable("uniqueID")
		)
	end;

	self.spawnIcon:SetModel(model, skin)
	self.spawnIcon:SetToolTip("")
	self.spawnIcon:SetSize(48, 48)
end;

-- Called each frame.
function PANEL:Think()
	if (!self.nextUpdateMarkup) then
		self.nextUpdateMarkup = 0;
	end;

	if (CurTime() < self.nextUpdateMarkup) then
		return;
	end;

	local informationColor = Clockwork.option:GetColor("information")

	local markupObject = Clockwork.theme:GetMarkupObject()
	markupObject:Title(self.bpTable("name"))
	markupObject:Add(self.bpTable("description"))
	--markupObject:Title("Категория")
	--markupObject:Add(self.bpTable("category"))

	if table.Count( self.bpTable("reqatt") ) > 0 then
		markupObject:Title("Навык")
		for k, v in pairs(self.bpTable["reqatt"]) do
			if (v[2] > 0) then
				markupObject:Add(Clockwork.attribute:FindByID(v[1]).name .. " = " .. v[2])
			end
		end
	end

	if table.Count( self.bpTable("recipe") ) > 0 then
		markupObject:Title("Материалы")
		for k, v in pairs( self.bpTable("recipe") ) do
			local itemTable = Clockwork.item:GetAll()[v[1]]
			if itemTable then
				markupObject:Add( v[2] .. " x " .. itemTable("name") )
			end
		end
	end

	if table.Count( self.bpTable("required") ) > 0 then
		markupObject:Title("Инструменты")
		for k, v in pairs( self.bpTable("required") ) do
			local itemTable = Clockwork.item:GetAll()[v[1]]
			if itemTable then
				markupObject:Add( v[2] .. " x " .. itemTable("name") )
			end
		end
	end

	self.spawnIcon:SetMarkupToolTip(markupObject:GetText())
	self.spawnIcon:SetColor(self.bpTable("color"))

	self.nextUpdateMarkup = CurTime() + 1
end;

vgui.Register("cwCraftBlueprint", PANEL, "DPanel")