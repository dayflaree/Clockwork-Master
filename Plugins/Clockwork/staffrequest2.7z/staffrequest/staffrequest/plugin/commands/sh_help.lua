local COMMAND = Clockwork.command:New("Help");
COMMAND.tip = "Request help from staff.";
COMMAND.arguments = 0;
function COMMAND:OnRun(player, arguments)
	local listeners = {}
	local staffonline = false
	rndNo = math.random(0, 10)
	for k, v in pairs(_player.GetAll()) do
		if (Clockwork.player:IsAdmin(v)) then
			staffonline = true
			table.insert(listeners, v)
			v:SetCharacterData("StaffRequest"..rndNo, player:Name());
		end;
	end;
	if(staffonline == true) then
		Clockwork.chatBox:SendColored(listeners, Color(255, 0, 0), "[Help request]", Color(255, 125, 125), player:Name(), " is requesting help. ID: "..rndNo)
		Clockwork.chatBox:SendColored(listeners, Color(255, 125, 125), "Type /accept (ID) to accept the request.")
	else
		Clockwork.player:Notify(player, "Unfortunately there are no staff members online right now.")
	end
end
COMMAND:Register()