local COMMAND = Clockwork.command:New("StaffData");
COMMAND.tip = "Get a staff member's request data.";
COMMAND.arguments = 1;
COMMAND.text = "<string Name>";
COMMAND.access = "s"
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	if(target) then
		if (target:GetCharacterData("RequestsSolved") == "" or target:GetCharacterData("RequestsSolved") == nil) then
			target:SetCharacterData("RequestsSolved", 0)
		end
		if (target:GetCharacterData("RequestsAccepted") == "" or target:GetCharacterData("RequestsAccepted") == nil) then
			target:SetCharacterData("RequestsAccepted", 0)
		end
		Clockwork.player:Notify(player, target:Name().."'s request data.")
		Clockwork.player:Notify(player, "Requests accepted: "..target:GetCharacterData("RequestsAccepted"));
		Clockwork.player:Notify(player, "Requests solved: "..target:GetCharacterData("RequestsSolved"));
	else
		Clockwork.player:Notify(player, "Invalid target.")
	end
end
COMMAND:Register()