local COMMAND = Clockwork.command:New("Accept");
COMMAND.tip = "Accept a help request.";
COMMAND.arguments = 1;
COMMAND.text = "<integer Number>"
COMMAND.access = "o"
function COMMAND:OnRun(player, arguments)
	local target = player:GetCharacterData("StaffRequest"..arguments[1]);
	target = Clockwork.player:FindByID(target);
	if(target) then
		if(player:GetCharacterData("RequestDealtWith") != true) then
			Clockwork.player:Notify(player, "You have accepted this request!")
			player:SetCharacterData("PreRequestPos", player:GetPos())
			Clockwork.player:SetSafePosition(player, target:GetPos());
			for k, v in pairs(_player.GetAll()) do
				if (Clockwork.player:IsAdmin(v) and v != player) then
					table.insert(listeners, v)
					v:SetCharacterData("RequestDealtWith", true);
				end;
			end;
			Clockwork.chatBox:SendColored(listeners, Color(255, 0, 0), "[Staff]", Color(255, 125, 125), player:Name(), " has accepted the request.")
			if (player:GetCharacterData("RequestsAccepted") == "" or player:GetCharacterData("RequestsAccepted") == nil) then
				player:SetCharacterData("RequestsAccepted", 1)
			else
				player:SetCharacterData("RequestsAccepted", player:GetCharacterData("RequestsAccepted") + 1)
			end;
			player:SetCharacterData("SolvedPending", true)
		else
			Clockwork.player:Notify(player, "Another member of staff has already accepted the request.")
		end;
	else
		Clockwork.player:Notify(player, "Invalid request.")
	end;
end
COMMAND:Register()