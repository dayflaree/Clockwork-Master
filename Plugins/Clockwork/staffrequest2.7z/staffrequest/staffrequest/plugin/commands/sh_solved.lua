local COMMAND = Clockwork.command:New("Solved");
COMMAND.tip = "Use when you have solved a help request.";
COMMAND.arguments = 1;
COMMAND.text = "<integer Number>"
COMMAND.access = "o"
function COMMAND:OnRun(player, arguments)
	local target = player:GetCharacterData("StaffRequest"..arguments[1]);
	target = Clockwork.player:FindByID(target);
	if(target) then
		if(player:GetCharacterData("SolvedPending") == true) then
			Clockwork.player:Notify(player, "Temporarily marked as solved, awaiting user approval.")
			Clockwork.player:Notify(target, player:Name().." has attempted to mark this request as solved.")
			Clockwork.player:Notify(target, "Type /solvedaccept to accept this.")
			target:SetCharacterData("SolvedAcceptStaff", player:Name())
			target:SetCharacterData("SolvedAcceptPending", true)
		else
			Clockwork.player:Notify(player, "You have no request to solve.")
		end;
	else
		Clockwork.player:Notify(player, "Invalid request.")
	end;
end
COMMAND:Register()