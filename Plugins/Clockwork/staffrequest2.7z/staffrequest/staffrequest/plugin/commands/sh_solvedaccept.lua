local COMMAND = Clockwork.command:New("SolvedAccept");
COMMAND.tip = "Use when you have solved a help request.";
COMMAND.arguments = 0;
function COMMAND:OnRun(player, arguments)
	if(player:GetCharacterData("SolvedAcceptPending") == true) then
		player:SetCharacterData("SolvedAcceptPending", false)
		player:SetCharacterData("SolvedPending", false)
		SolvedStaff = player:GetCharacterData("SolvedAcceptStaff")
		SolvedStaff = Clockwork.player:FindByID(SolvedStaff)
		if (SolvedStaff:GetCharacterData("RequestsSolved") == "" or SolvedStaff:GetCharacterData("RequestsSolved") == nil) then
			SolvedStaff:SetCharacterData("RequestsSolved", 1)
		else
			SolvedStaff:SetCharacterData("RequestsSolved", SolvedStaff:GetCharacterData("RequestsSolved") + 1)
		end;
		Clockwork.player:Notify(player, "This request is now marked as solved.")
		Clockwork.player:Notify(SolvedStaff, "This request is now marked as solved.")
		Clockwork.player:SetSafePosition(player, player:GetCharacterData("PreRequestPos"));
	else
		Clockwork.player:Notify(player, "You have no solved request to accept.")
	end;
end
COMMAND:Register()