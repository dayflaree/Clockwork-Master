local PLUGIN = PLUGIN;

PLUGIN.openedCrates = {};

Clockwork.datastream:Hook("LootOpened", function(crateIndex)
	local crate = Entity(crateIndex);

	-- If the crate exists, add it to our list.
	if (IsValid(crate)) then
		PLUGIN.openedCrates[crate] = true;
	end;
end);

function PLUGIN:PreDrawHalos()
	if (!Clockwork.Client or !IsValid(Clockwork.Client)) then return; end;

	for k, v in pairs(ents.GetAll()) do
		if (v:GetClass():sub(1, 5) == "loot_" and !self.openedCrates[v]) then
			local dist = math.Remap(400 - Clockwork.Client:GetPos():Distance(v:GetPos()), 400, 0, 255, 0);
			local alpha = math.Clamp(dist, 0, 255);

			if (alpha > 0) then
				halo.Add({v}, Color(255, 228, 57, alpha), 1, 1, 2, true, false);
			end;
		end;
	end;
end;