local PLUGIN = PLUGIN;

-- Larger the weight, the less valuable the items. This is only taken into account when doing non-strict loot.

PLUGIN.categories = {
	common = {
		weight = 10,
		items = {
			"cables",
			"empty_box",
			"empty_bag",
			"wallet",
			"empty_bottle",
			"empty_soda_can",
			"empty_tin_can",
			"handh_radio_broken",
			"handh_radio_powerless",
			"junk_board",
			"junk_pallet",
			"scrap_metal",
			"small_battery",

		}
	},

	uncommon = {
		weight = 9,
		items = {
			"purification_tabs",
			"bandage",
			"apple",
			"bleach",
			"coca_cola",
			"cooked_noodles",
			"bigblackbbq",
			"cinnamoncrunch",
			"egg",
			"granola_bar",
			"scrap_box_s"
		}
	},

	unique = {
		weight = 8,
		items = {
			"kevlar_civilian",
			"veg_tikka",
			"mountain_dew",
			"scrap_box_m",
			"penicillin",
			"shovel",
			"pipe",
			"wrench",
			"rolling_pin",
			"flare",
			"preserved_food",
			"red_bull",
			"weed"
		}
	},

	rare = {
		weight = 7,
		items = {
			"kevlar_press",
			"civ_fak",
			"9x19mm",
			"45_acp",
			"12_gauge_buckshot",
			"357_magnum",
			"morphine_syringe",
			"huntingknife",
			"carvingknife",
			"m7bayonet",
			"coltcommando",
			"mre_military",
			"zip_tie"
		}
	}
};