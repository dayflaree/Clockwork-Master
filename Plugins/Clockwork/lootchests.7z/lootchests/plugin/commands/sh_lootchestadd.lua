local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("LootChestAdd");
COMMAND.tip = "Adds a loot chest. Valid types are: unique, same, single, empty, and empty_single. If strict is enabled, will only give items from set category.";
COMMAND.text = "<string Type> <string Category> <int Amount> [bool Strict] [string Model]";
COMMAND.access = "s";
COMMAND.arguments = 3;
COMMAND.optionalArguments = 2;

function COMMAND:OnRun(player, arguments)
	local pos = player:GetEyeTrace().HitPos;
	local crateType = arguments[1]:lower();
	local category = arguments[2]:lower();
	local lootAmount = tonumber(arguments[3]);
	local bStrict = tobool(arguments[4]) or false;

	if (crateType == "unique" or crateType == "same" or crateType == "single" or crateType == "empty" or crateType == "empty_single") then
		local crate = ents.Create("loot_" .. crateType);

		crate:SetPos(pos);
		crate:SetAngles(Angle(0, player:EyeAngles().y, 0));
		crate:Spawn();

		if (bStrict) then
			crate:SetStrict(bStrict);
		end;

		crate.lootAmount = lootAmount;
		crate.lootCategory = category;

		if (arguments[5]) then
			crate:SetModel(arguments[5]:lower());
			crate:PhysicsInit(SOLID_VPHYSICS);
		end;
	else
		Clockwork.player:Notify(player, "Invalid loot chest type specified, aborting!");
	end;
end;

COMMAND:Register();