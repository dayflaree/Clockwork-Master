local PLUGIN = PLUGIN;
local COMMAND = Clockwork.command:New("LootChestEdit");
COMMAND.tip = "Specify a list of item IDs, separated by a space, for a loot chest to give out on top of its random loot. Type 0 or false to remove.";
COMMAND.access = "s";
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	local crate = player:GetEyeTrace().Entity;

	if (IsValid(crate)) then
		if (crate:GetClass():sub(1, 5) == "loot_") then
			if (arguments[1] == "0" or arguments[1] == "false") then
				crate.guaranteedItems = {};
				crate:SetGuaranteed(false);
				Clockwork.player:Notify(player, "You have removed any additional content from this crate.");
			else
				crate:SetGuaranteed(true);
				crate.guaranteedItems = {};

				Clockwork.player:Notify(player, "You have edited this loot crates additional contents.");

				for k, v in pairs(arguments) do
					local data = string.Explode(":", v);

					table.insert(crate.guaranteedItems, {uniqueID = data[1], count = data[2] or 1});
				end;
			end;
		end;
	end;
end;

COMMAND:Register();