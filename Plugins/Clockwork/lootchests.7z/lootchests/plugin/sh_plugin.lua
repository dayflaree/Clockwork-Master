local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sh_loottable.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");