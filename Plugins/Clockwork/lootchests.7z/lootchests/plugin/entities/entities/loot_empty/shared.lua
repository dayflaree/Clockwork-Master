if (SERVER) then
	AddCSLuaFile();
end;

local PLUGIN = PLUGIN;

local BaseClass = baseclass.Get("base_entity");

ENT.PrintName		= "Empty Loot Chest";
ENT.Category		= "Loot";
ENT.Spawnable		= true;
ENT.AdminOnly		= true;
ENT.Model			= Model("models/warz/items/lockbox.mdl");
ENT.RenderGroup 	= RENDERGROUP_BOTH;

AccessorFunc(ENT, "m_bGuaranteed", "Guaranteed", FORCE_BOOL);

if (SERVER) then

	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return; end;

		local entity = ents.Create(class);
		entity:SetPos(trace.HitPos + trace.HitNormal * 1.5);
		entity:Spawn();

		return entity;
	end;

	function ENT:Initialize()
		self:SetModel(self.Model);
		self:SetSolid(SOLID_VPHYSICS);
		self:PhysicsInit(SOLID_VPHYSICS);
		self:SetUseType(SIMPLE_USE);
		self:SetRenderMode(RENDERMODE_TRANSALPHA);

		self.users = {};
		self.storedLoot = {};
		self.lootCategory = "misc";
		self.lootAmount = 3;

		local phys = self:GetPhysicsObject();

		if (IsValid(phys)) then
			phys:Wake();
		end;
	end;

	function ENT:Use(activator, caller, type, value)
		if (IsValid(activator)) then
			if (!self.users[activator:SteamID()]) then
				-- If we are supposed to guarantee certain items, then give them.
				if (self:GetGuaranteed()) then
					self.users[activator:SteamID()] = true;
					Clockwork.datastream:Start(activator, "LootOpened", self:EntIndex());

					self:EmitSound("ui/unbox.wav");

					Clockwork.player:Notify(activator, "You have discovered a loot chest! Its contents have been added to your inventory.");

					for k, itemData in pairs(self.guaranteedItems) do
						for i = 1, itemData.count do
							local itemInstance = Clockwork.item:CreateInstance(itemData.uniqueID);

							if (itemInstance) then
								activator:GiveItem(itemInstance, true);
							end;
						end;
					end;
				end;
			end;
		end;
	end;

elseif (CLIENT) then

	function ENT:Initialize()
		self:SetRenderMode(RENDERMODE_TRANSALPHA);
		self:SetSolid(SOLID_VPHYSICS);
	end;

	function ENT:Draw()
		self:DrawModel();
	end;

	function ENT:OnRemove()
		PLUGIN.openedCrates[self] = nil;
	end;
end;