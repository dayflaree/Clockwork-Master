if (SERVER) then
	AddCSLuaFile();
end;

local PLUGIN = PLUGIN;

local BaseClass = baseclass.Get("base_entity");

ENT.PrintName		= "Unique Loot Chest";
ENT.Category		= "Loot";
ENT.Spawnable		= true;
ENT.AdminOnly		= true;
ENT.Model			= Model("models/warz/items/lockbox.mdl");
ENT.RenderGroup 	= RENDERGROUP_BOTH;

AccessorFunc(ENT, "m_bStrict", "Strict", FORCE_BOOL);
AccessorFunc(ENT, "m_bGuaranteed", "Guaranteed", FORCE_BOOL);

if (SERVER) then

	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return; end;

		local entity = ents.Create(class);
		entity:SetPos(trace.HitPos + trace.HitNormal * 1.5);
		entity:Spawn();

		return entity;
	end;

	function ENT:Initialize()
		self:SetModel(self.Model);
		self:SetSolid(SOLID_VPHYSICS);
		self:PhysicsInit(SOLID_VPHYSICS);
		self:SetUseType(SIMPLE_USE);
		self:SetRenderMode(RENDERMODE_TRANSALPHA);

		self.users = {};
		self.lootCategory = "misc";
		self.lootAmount = 3;

		local phys = self:GetPhysicsObject();

		if (IsValid(phys)) then
			phys:Wake();
		end;
	end;

	function ENT:Use(activator, caller, type, value)
		if (IsValid(activator)) then
			if (!self.users[activator:SteamID()]) then
				self.users[activator:SteamID()] = true;
				Clockwork.datastream:Start(activator, "LootOpened", self:EntIndex());

				self:EmitSound("ui/unbox.wav");

				Clockwork.player:Notify(activator, "You have discovered a loot chest! Its contents have been added to your inventory.");

				-- If we're only allowed to pick from our set category, then do so. Otherwise, give one item guaranteed to be from our selection pool, with a chance to give something else.
				if (self:GetStrict()) then
					for i = 1, self.lootAmount do
						local randomItemID = table.Random(PLUGIN.categories[self.lootCategory].items);

						if (Clockwork.item.stored[randomItemID]) then
							local itemInstance = Clockwork.item:CreateInstance(randomItemID);

							activator:GiveItem(itemInstance, true);
						end;
					end;
				else
					-- Give one item from our set table.
					local randomItemID = table.Random(PLUGIN.categories[self.lootCategory].items);

					if (Clockwork.item.stored[randomItemID]) then
						local itemInstance = Clockwork.item:CreateInstance(randomItemID);

						activator:GiveItem(itemInstance, true);
					end;

					-- If the amount of loot to be given is not just one item...
					if (self.lootAmount - 1 >= 1) then
						-- For all the remaining items, make them random
						for i = 1, math.max(self.lootAmount - 1, 1) do
							local randomItemCategory = table.Random(PLUGIN.categories);

							while (randomItemCategory.weight < PLUGIN.categories[self.lootCategory].weight) do
								randomItemCategory = table.Random(PLUGIN.categories);
							end;

							local randomItemID = table.Random(randomItemCategory.items);

							if (Clockwork.item.stored[randomItemID]) then
								local itemInstance = Clockwork.item:CreateInstance(randomItemID);

								activator:GiveItem(itemInstance, true);
							end;
						end;
					end;
				end;

				-- If we are supposed to guarantee certain items, then give them.
				if (self:GetGuaranteed()) then
					for k, itemData in pairs(self.guaranteedItems) do
						for i = 1, itemData.count do
							local itemInstance = Clockwork.item:CreateInstance(itemData.uniqueID);

							if (itemInstance) then
								activator:GiveItem(itemInstance, true);
							end;
						end;
					end;
				end;
			end;
		end;
	end;

elseif (CLIENT) then

	function ENT:Initialize()
		self:SetRenderMode(RENDERMODE_TRANSALPHA);
		self:SetSolid(SOLID_VPHYSICS);
	end;

	function ENT:OnRemove()
		PLUGIN.openedCrates[self] = nil;
	end;

	function ENT:Draw()
		self:DrawModel();
	end;
end;