local COMMAND = Clockwork.command:New("ToggleNV");
COMMAND.tip = "Activate your night vision goggles.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local itemTable = player:FindItemByID("nightvision_device");
    local wearsNV = false
    if (itemTable) then
        wearsNV = itemTable:GetData("Equip")
    end
    
    if (wearsNV) then
        Clockwork.datastream:Start(player, "NVToggle", {});
    else
        Clockwork.player:Notify(player, "You do not have night vision goggles!");
    end 
end;

COMMAND:Register();

if SERVER then
    concommand.Add("nv_toggle",function(player)
        local itemTable = player:FindItemByID("nightvision_device");
        local wearsNV = false
        if (itemTable) then
            wearsNV = itemTable:GetData("Equip")
        end
        
        Clockwork.datastream:Start(player, "NVToggle", {});
    end)
end