local COMMAND = Clockwork.command:New("SwitchNV");
COMMAND.tip = "Switch your visions mode.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
    local itemTable = player:FindItemByID("nightvision_device");
    local wearsNV = false
    if (itemTable) then
        wearsNV = itemTable:GetData("Equip")
    end
    
    if (wearsNV) then
		Clockwork.datastream:Start(player, "NVSwitch", {});
	else
		Clockwork.player:Notify(player, "You do not have night vision goggles to switch modes on!");
	end;
end;

COMMAND:Register();

if SERVER then
    concommand.Add("nv_switchmode",function(player)
        Clockwork.datastream:Start(player, "NVSwitch", {});
    end)
end