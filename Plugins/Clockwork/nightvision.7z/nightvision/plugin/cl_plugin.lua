local PLUGIN = PLUGIN;

Clockwork.datastream:Hook("NVSwitch", function(data)
	if GetConVarNumber("nv_type") == 1 then
		RunConsoleCommand("nv_type",2)
	else
		RunConsoleCommand("nv_type",1)
	end
end);

Clockwork.datastream:Hook("NVShutDown", function(data)
	NV_ShutDown()
end);

Clockwork.datastream:Hook("NVToggle", function(data)
	NV_ToggleNightVision()
end);

local NV_Status = false
local NV_Vector = 0
local NV_TimeToVector = 0
local NV_ToneMapTime = 0

CreateClientConVar("nv_toggspeed", 0.09, true, false)
CreateClientConVar("nv_illum_area", 2048, true, false)
CreateClientConVar("nv_illum_bright", 0.2, true, false)
CreateClientConVar("nv_aim_status", 0, true, false)
CreateClientConVar("nv_aim_range", 200, true, false)

CreateClientConVar("nv_etisd_sensitivity_range", 200, true, false)
CreateClientConVar("nv_etisd_status", 0, true, false)

CreateClientConVar("nv_id_sens_darkness", 0.25, true, false)
CreateClientConVar("nv_id_status", 0, true, false)
CreateClientConVar("nv_id_reaction_time", 1, true, false)

CreateClientConVar("nv_isib_sensitivity", 5, true, false)
CreateClientConVar("nv_isib_status", 0, true, false)

CreateClientConVar("nv_fx_blur_status", 0, true, false)
CreateClientConVar("nv_fx_distort_status", 1, true, false)
CreateClientConVar("nv_fx_colormod_status", 1, true, false)
CreateClientConVar("nv_fx_blur_intensity", 1, true, false)
CreateClientConVar("nv_fx_goggle_overlay_status", 0, true, false)
CreateClientConVar("nv_fx_tonemap_status", 1, true, false)
CreateClientConVar("nv_fx_tonemap_delayed", 0, true, false)
CreateClientConVar("nv_fx_tonemap_quality", 1, true, false)
CreateClientConVar("nv_fx_goggle_status", 0, true, false)
CreateClientConVar("nv_type", 1, true, false)
local IsBrighter = false
local IsMade = false
local ply, Brightness, IlluminationArea, ISIBSensitivity, dlight, tr, trace

local Color_Brightness		= 0.8
local Color_Contrast 		= 1.1
local Color_AddGreen		= -0.35
local Color_MultiplyGreen 	= 0.028

local C_B = -0.32

Bloom_Darken = 0.75
Bloom_Multiply = 1

local AlphaAdd_Alpha 			= 1
local AlphaAdd_Passes			= 1

local matNightVision = Material("effects/nightvision")
matNightVision:SetFloat( "$alpha", AlphaAdd_Alpha )

local Color_Tab = 
{
	[ "$pp_colour_addr" ] 		= -1,
	[ "$pp_colour_addg" ] 		= Color_AddGreen,
	[ "$pp_colour_addb" ] 		= -1,
	[ "$pp_colour_brightness" ] = Color_Brightness,
	[ "$pp_colour_contrast" ]	= Color_Contrast,
	[ "$pp_colour_colour" ] 	= 0,
	[ "$pp_colour_mulr" ] 		= 0,
	[ "$pp_colour_mulg" ] 		= Color_MultiplyGreen,
	[ "$pp_colour_mulb" ] 		= 0
}

local Clr_FLIR = 
{
	[ "$pp_colour_addr" ] 		= 0,
	[ "$pp_colour_addg" ] 		= 0,
	[ "$pp_colour_addb" ] 		= 0,
	[ "$pp_colour_brightness" ] = -0.32,
	[ "$pp_colour_contrast" ]	= 2.11,
	[ "$pp_colour_colour" ] 	= 0,
	[ "$pp_colour_mulr" ] 		= 0,
	[ "$pp_colour_mulg" ] 		= 0,
	[ "$pp_colour_mulb" ] 		= 0
}

local Clr_FLIR_Ents = 
{
	[ "$pp_colour_addr" ] 		= 0,
	[ "$pp_colour_addg" ] 		= 0,
	[ "$pp_colour_addb" ] 		= 0,
	[ "$pp_colour_brightness" ] = 0.5,
	[ "$pp_colour_contrast" ]	= 1,
	[ "$pp_colour_colour" ] 	= 0,
	[ "$pp_colour_mulr" ] 		= 0,
	[ "$pp_colour_mulg" ] 		= 0,
	[ "$pp_colour_mulb" ] 		= 0
}

local CurScale = 0
local sndOn = Sound( "items/nvg_on.wav" )
local sndOff = Sound( "items/nvg_off.wav" )
local sndLoop = Sound("nvscript/nv_loop.wav")

local BloomStrength = 0
local TonemapDelay = 0
local OverlayTexture = surface.GetTextureID("effects/nv_overlaytex.vmt")

local function NV_FX()
	ply = LocalPlayer()
	if ply:Alive() and NV_Status == true then
		CurScale = Lerp(FrameTime() * (30 * GetConVarNumber("nv_toggspeed")), CurScale, 1)
		
		if GetConVarNumber("nv_type") <= 1 then
			if GetConVarNumber("nv_fx_colormod_status") > 0 then
				Color_Tab[ "$pp_colour_brightness" ] = CurScale * Color_Brightness
				Color_Tab[ "$pp_colour_contrast" ] = CurScale * Color_Contrast
				
				DrawColorModify( Color_Tab )
			end
			
			local BlurIntensity = GetConVarNumber("nv_fx_blur_intensity")
			
			if GetConVarNumber("nv_fx_blur_status") > 0 then
				DrawMotionBlur(0.05 * BlurIntensity, 0.2 * BlurIntensity, 0.023 * BlurIntensity) -- fucking bitchy drawmotionblur wants me to do it like this
			end
			
			if GetConVarNumber("nv_fx_distort_status") > 0 then
				DrawMaterialOverlay("models/shadertest/shader3.vmt", 0.0001)
			end
			
			if GetConVarNumber("nv_fx_goggle_status") > 0 then
				DrawMaterialOverlay("models/props_c17/fisheyelens.vmt", -0.03)
			end
			
			if GetConVarNumber("nv_fx_tonemap_status") > 0 then
				
				if BloomStrength > 0.3 then -- If we're looking into somewhere bright
					Bloom_Multiply = Lerp(0.1, Bloom_Multiply, 3 * BloomStrength) -- RAPE OUR EYES, WOO
					Bloom_Darken = Lerp(0.1, Bloom_Darken, 0)
				else
					Bloom_Multiply = Lerp(0.025, Bloom_Multiply, 1.25 * BloomStrength)
					Bloom_Darken = Lerp(0.025, Bloom_Darken, 0.75)
				end
				
				DrawBloom(Bloom_Darken, Bloom_Multiply, 9, 9, 1, 1, 1, 1, 1)
			end
		else
			if GetConVarNumber("nv_fx_colormod_status") > 0 then
				Color_Tab["$pp_colour_brightness"] = C_B - C_B
				DrawColorModify(Clr_FLIR)
			end
		end
		
		for i=1,AlphaAdd_Passes do
			render.UpdateScreenEffectTexture()
			render.SetMaterial( matNightVision )
			render.DrawScreenQuad()
		end
		
	elseif not ply:Alive() then
		surface.PlaySound( sndOff )
		NV_Status = false
		hook.Remove("RenderScreenspaceEffects", "NV_Render")
		hook.Remove("Think", "NV_DLight")
	end
end

Test = 0

local function NV_DLIGHT()
	ply = LocalPlayer()
	
	Brightness = GetConVarNumber("nv_illum_bright")
	IlluminationArea = GetConVarNumber("nv_illum_area")
	ISIBSensitivity = GetConVarNumber("nv_isib_sensitivity")

	if ply:Alive() and NV_Status == true then		
		dlight = DynamicLight(ply:EntIndex())
		
		if ( dlight ) then
			if GetConVarNumber("nv_aim_status") > 0 then
			
				tr = {}
				tr.start = ply:EyePos()
				tr.endpos = tr.start + ply:EyeAngles():Forward() * GetConVarNumber("nv_aim_range")
				tr.filter = ply
				
				trace = util.TraceLine(tr)
				
				if not trace.Hit then
				
					if CurTime() > NV_TimeToVector then
						NV_Vector = math.Clamp(NV_Vector + 1, 0, 20)
						NV_TimeToVector = CurTime() + 0.005
					end
					
					dlight.Pos = trace.HitPos + Vector(0, 0, NV_Vector)
				else
				
					if CurTime() > NV_TimeToVector then
						NV_Vector = math.Clamp(NV_Vector - 1, 0, 20)
						NV_TimeToVector = CurTime() + 0.005
					end
					
					dlight.Pos = trace.HitPos + Vector(0, 0, NV_Vector)
				end
				
			else
				dlight.Pos = ply:GetShootPos()
			end
			
			dlight.r = 125 * Brightness
			dlight.g = 255 * Brightness
			dlight.b = 125 * Brightness
			dlight.Brightness = 1
			
			if GetConVarNumber("nv_isib_status") < 1 then
				dlight.Size = IlluminationArea * CurScale
				dlight.Decay = IlluminationArea * CurScale
			else
				dlight.Size = math.Clamp((IlluminationArea * CurScale) / (render.GetLightColor(ply:EyePos()):Length() * ISIBSensitivity), 0, IlluminationArea)
				dlight.Decay = math.Clamp((IlluminationArea * CurScale) / (render.GetLightColor(ply:EyePos()):Length() * ISIBSensitivity), 0, IlluminationArea)
			end
			
			dlight.DieTime = CurTime() + 0.1
		end
	end
end

function NV_ToggleNightVision()
	if NV_Status == true then
		NV_Status = false
		
		surface.PlaySound( sndOff )
		hook.Remove("RenderScreenspaceEffects", "NV_Render")
		hook.Remove("Think", "NV_DLight")
	else
		NV_Status = true
		
		CurScale = 0.2
		surface.PlaySound( sndOn )
		hook.Add("RenderScreenspaceEffects", "NV_Render", NV_FX)
		hook.Add("Think", "NV_DLight", NV_DLIGHT)
	end
end

function NV_ShutDown()
    NV_Status = false
    
    surface.PlaySound( sndOff )
    hook.Remove("RenderScreenspaceEffects", "NV_Render")
    hook.Remove("Think", "NV_DLight")
end
//concommand.Add("nv_togg", NV_ToggleNightVision)

hook.Add( "PostDrawOpaqueRenderables", "FLIRFX", function()	
	if GetConVarNumber("nv_type") < 2 or not NV_Status then
		return
	end
	
	render.ClearStencil()
	render.SetStencilEnable(true)
    
	render.SetStencilTestMask(1)
	render.SetStencilWriteMask(1)
        
	render.SetStencilFailOperation(STENCILOPERATION_KEEP)
	render.SetStencilZFailOperation(STENCILOPERATION_KEEP)
	render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
	render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
	render.SetStencilReferenceValue(1)
			
	render.SuppressEngineLighting(true)
	
	for _, ent in pairs(ents.GetAll()) do
		if ent:IsNPC() or ent:IsPlayer() then
			if not ent:IsEffectActive(EF_NODRAW) then -- since there is no proper way to check if the NPC is dead, we just check if the NPC has a nodraw effect on him
				render.SuppressEngineLighting(true)
				ent:DrawModel()
				render.SuppressEngineLighting(false)
			end
		elseif ent:GetClass() == "class C_ClientRagdoll" then
			if not ent.Int then
				ent.Int = 1
			else
				ent.Int = math.Clamp(ent.Int - FrameTime() * 0.015, 0, 1)
			end
			
			render.SetColorModulation(ent.Int, ent.Int, ent.Int)
				render.SuppressEngineLighting(true)
					ent:DrawModel()
				render.SuppressEngineLighting(false)
			render.SetColorModulation(1, 1, 1)
		end
	end
	
	render.SuppressEngineLighting(false)
	 
	render.SetStencilReferenceValue(2)
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilReferenceValue(1)
	DrawColorModify(Clr_FLIR_Ents)

	render.SetStencilEnable( false )
end )

local function NV_ResetEverything()

	-- Effects
	RunConsoleCommand("nv_fx_blur_status", "1")
	RunConsoleCommand("nv_fx_distort_status", "1")
	RunConsoleCommand("nv_fx_colormod_status", "1")
	RunConsoleCommand("nv_fx_goggle_overlay_status", "1")
	RunConsoleCommand("nv_fx_goggle_status", "0")
	RunConsoleCommand("nv_fx_tonemap_status", "0")
	RunConsoleCommand("nv_fx_tonemap_delayed", "1")
	RunConsoleCommand("nv_fx_tonemap_quality", "2")
	RunConsoleCommand("nv_fx_blur_intensity", "1.0")
	
	-- Various features/etc
	RunConsoleCommand("nv_id_status", "0")
	RunConsoleCommand("nv_id_sens_darkness", "0.25")
	RunConsoleCommand("nv_id_reaction_time", "1")
	RunConsoleCommand("nv_etisd_status", "0")
	RunConsoleCommand("nv_etisd_sensitivity_range", "200")
	RunConsoleCommand("nv_isib_status", "0")
	RunConsoleCommand("nv_isib_sensitivity", "5")
	
	if NV_Status == true then
		surface.PlaySound( sndOff )
		NV_Status = false
	end
	
	hook.Remove("RenderScreenspaceEffects", "NV_Render")
	hook.Remove("Think", "Think")
	RunConsoleCommand("nv_toggspeed", "0.2")
	RunConsoleCommand("nv_illum_area", "512")
	RunConsoleCommand("nv_illum_bright", "1")
	RunConsoleCommand("nv_aim_status", "1")
	RunConsoleCommand("nv_aim_range", "200")
	RunConsoleCommand("nv_type", "1")
	LocalPlayer():ChatPrint([[Everything has been reset to defaults:

-/ FX \-
Blur - ON
Blur Intensity - 1.0
Distort - ON
Green Overlay - ON
Goggle Overlay - ON
Goggle Effect - OFF
Tonemap Effect - OFF
Tonemap Quality - MEDIUM
Delayed Tonemap Tracing - ON

-/ Features \-
Illumination-Detection - OFF
Eye Trace Illumination-Sensitive Detection - OFF
Illumination-Smart Intensity Balancing - OFF
ID Darkness sensitivity - 0.25
ID Reaction Time - 1 second
ETISD sensitivity Range - 200
ISIB sensitivity - 5.00

-/ Miscellaneous \-
Illuminated Area - 512 units
Illumination Brightness - 100%
Toggle Speed -  20%
AIM - ON
AIM range - 200
Vision Type - Night Vision]])
end

concommand.Add("nv_reset_everything", NV_ResetEverything)

local eyePos, eyeAng, eyeAngFwd, EyeAngRight, TonemapQuality, trtone, tracetone

local function NV_MonitorIllumination()
	ply = LocalPlayer()
	if !ply:GetSharedVar( "NVOn" ) == 1 then
		NV_Status = false
	end
	if ply:Alive() then
		tr = {}
		tr.start = ply:EyePos()
		tr.endpos = tr.start + ply:EyeAngles():Forward() * GetConVarNumber("nv_etisd_sensitivity_range")
		tr.filter = ply
		trace = util.TraceLine(tr)
		
		if GetConVarNumber("nv_id_status") > 0 then
			if IsBrighter == false then
				if render.GetLightColor(ply:EyePos()):Length() < GetConVarNumber("nv_id_sens_darkness") then
					if IsMade == false then
						timer.Create("MonitorIllumTimer", GetConVarNumber("nv_id_reaction_time"), 1, function()
								if render.GetLightColor(ply:EyePos()):Length() < GetConVarNumber("nv_id_sens_darkness") then -- Check again, because the timer activates in 1 second and we need to be sure if we're still in a shady spot
									if NV_Status == false then
										RunConsoleCommand("nv_togg")
									end
								else
									if NV_Status == true then
										RunConsoleCommand("nv_togg")
									end
								end
								
							IsMade = false
						end)
						
						IsMade = true
					end
				else
					timer.Start("MonitorIllumMeter")
				end
			end
			
			if GetConVarNumber("nv_etisd_status") > 0 then
				if render.GetLightColor(trace.HitPos):Length() > GetConVarNumber("nv_id_sens_darkness") then -- If we're looking from darkness into somewhere bright
					if IsBrighter == false then
						if NV_Status == true then
							RunConsoleCommand("nv_togg") -- turn off our night vision
						end
						IsBrighter = true
						timer.Stop("MonitorIllumTimer")
					else
						timer.Start("MonitorIllumTimer")
					end
				else
					IsBrighter = false
				end
			end
		end
	end
	
	if GetConVarNumber("nv_fx_tonemap_status") >= 0 then
		if GetConVarNumber("nv_fx_tonemap_delayed") then
			if TonemapDelay > CurTime() then
				return
			else
				TonemapDelay = CurTime() + 0.1
			end
		end
	
		BloomStrength = 0
	
		eyePos = ply:EyePos()
		eyeAng = ply:EyeAngles()
		eyeAngFwd = eyeAng:Forward()
		eyeAngRight = eyeAng:Right()
	
		TonemapQuality = GetConVarNumber("nv_fx_tonemap_quality")
		
		trtone = {}
		tracetone = nil
	
		if TonemapQuality == 2 then
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
		elseif TonemapQuality == 3 then
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
		
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)

			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 200 + eyeAngRight * 200
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 200 + eyeAngRight * -200
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
		else
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length()
		end
		
		BloomStrength = math.Clamp(BloomStrength, 0, 1)
	end
end

hook.Add("Think", "NV_MonitorIllumination", NV_MonitorIllumination)

local function NV_HUDPaint()
	ply = LocalPlayer()
	
	if ply:Alive() then
		if NV_Status then
			if GetConVarNumber("nv_fx_goggle_overlay_status") > 0 then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetTexture(OverlayTexture)
				surface.DrawTexturedRect(-1, -1, ScrW() + 1, ScrH() + 1)
			end
		end
	end
end

hook.Add("HUDPaint", "NV_HUDPaint", NV_HUDPaint)