/*--------------------------------------------------------------------------\
| THIS ENTIRE PLUGIN IS CREATED BY VIOMI                                    |
| PLEASE DO NOT COPY OR SELL ANY CODE IN HERE WITHOUT PERMISSION FROM VIOMI |
\--------------------------------------------------------------------------*/

local PLUGIN = PLUGIN;

function PLUGIN:PostPlayerSpawn(ply, lightSpawn, changeClass, firstSpawn)
	local oldhands = ply:GetHands()
	if ( IsValid( oldhands ) ) then oldhands:Remove() end

	local hands = ents.Create( "gmod_hands" )
	if ( IsValid( hands ) ) then
		ply:SetHands( hands )
		hands:SetOwner( ply )
		
		-- Which hands should we use?
		local cl_playermodel = player_manager.TranslateToPlayerModelName(ply:GetModel())
		local combinehands   = "models/weapons/c_arms_combine.mdl"
		local mpfv5hands     = "models/dpfilms/weapons/v_arms_metropolice.mdl"
		local faction        = ply:GetFaction();
		if util.IsValidModel(mpfv5hands) then combinehands = mpfv5hands end --Checks if the mpf hands model exist, otherwise it'll just use the default combine hands.
		
		local info = player_manager.TranslatePlayerHands( cl_playermodel )
		if ( info ) then
			hands:SetModel( Schema:IsCombineFaction(faction) and combinehands or info.model ) --Checks if their combine, otherwise just use the model gmod gives us.
			hands:SetSkin( info.skin )
			hands:SetBodyGroups( info.body )
		end

		-- Attach them to the viewmodel
		local vm = ply:GetViewModel( 0 )
		hands:AttachToViewmodel( vm )

		vm:DeleteOnRemove( hands )
		ply:DeleteOnRemove( hands )

		hands:Spawn()
	end
end