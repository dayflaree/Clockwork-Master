Clockwork.kernel:AddFile("materials/effects/gasmask_screen_1.vtf");
Clockwork.kernel:AddFile("materials/effects/gasmask_screen_2.vtf");
Clockwork.kernel:AddFile("materials/effects/gasmask_screen_3.vtf");
Clockwork.kernel:AddFile("materials/effects/gasmask_screen_4.vtf");