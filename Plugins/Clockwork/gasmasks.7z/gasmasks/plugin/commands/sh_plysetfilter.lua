local COMMAND = Clockwork.command:New("plySetFilter");
COMMAND.tip = "Set a player's filter quality.";
COMMAND.text = "<string Name> <number Amount> ||250 IS DEFAULT, 0 IS NO FILTER||";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] )
	local amount = arguments[2];
	
	if (!amount) then
		amount = 100;
	end;
	
		if (target) then
			target:SetCharacterData( "filterQuality", amount )
			if ( player != target )	then
				Clockwork.player:Notify(target, player:Name().." has set your filter quality to "..amount..".");
				Clockwork.player:Notify(player, "You have set "..target:Name().."'s filter quality to "..amount..".");
			else
				Clockwork.player:Notify(player, "You have set your own filter quality to "..amount..".");
			end;
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
		end;
end;

COMMAND:Register();