--[[
Name: "sh_gasmaskfilter_charcoal.lua".
Product: "Fleshlight".
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Charcoal Filter";
ITEM.cost = 50;
ITEM.value = 0.20;
ITEM.model = "models/teebeutel/metro/objects/gasmask_filter.mdl";
ITEM.batch = 5;
ITEM.weight = 0.50;
ITEM.access = "v", "i";
ITEM.useText = "Screw On";
ITEM.business = true;
ITEM.useSound = "npc/barnacle/barnacle_crunch2.wav";
ITEM.category = "Consumables";
ITEM.description = "Filters poisonous gasses to a breathable level.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if ( player:GetSharedVar("wearingRespirator") ) then
		player:SetCharacterData("filterQuality", 250);
		player:SetSharedVar( "filterQuality", 250 );
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();
