local PLUGIN = PLUGIN;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
end;

local nextBreathe;

-- Called each tick.
function PLUGIN:Tick()
	if ( self.dt ) then
		if ( self.dt < CurTime() ) then return; end;
	end;
	
	local curTime = CurTime();
	if(!nextBreathe or curTime >= nextBreathe) then
	
	
	for k, v in pairs( player.GetAll() ) do
		if (v:GetSharedVar("wearingRespirator")) then
			if (v:Alive()) then
				local sound;
				local quality = v:GetSharedVar("filterQuality");
				
				if(quality) then
					if(quality >= 100) then
						sound = "";
					elseif(quality >= 60) then
						sound = "";
					else
						sound = "";
					end;
				end;
				
				v:EmitSound(sound, 50, 100);
			end;
		end;
	end;
	nextBreathe = curTime + 40000
end;
	self.dt = CurTime() + 40000;
end;

-- Called when a player's character data should be saved.
function PLUGIN:PlayerSaveCharacterData(player, data)
	if ( data["filterQuality"] ) then
		data["filterQuality"] = math.Round( data["filterQuality"] );
	end;
end;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["filterQuality"] = data["filterQuality"] or 0;
end;

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("filterQuality", 0);
	end;
end;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "filterQuality", math.Round( player:GetCharacterData("filterQuality") ) );
end;
