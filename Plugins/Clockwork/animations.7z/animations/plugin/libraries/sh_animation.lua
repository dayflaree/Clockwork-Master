Clockwork.animation:AddCombineOverwatchModel("models/combine_soldier_prisonguard.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/combine_super_soldier.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/combine_soldier.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/city8_overwatch.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/city8_ow_elite.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/city8_overwatch_elite.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/bloocobalt/combine/combine_s.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/bloocobalt/combine/combine_e.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/npcs/ranger_armour_bad.mdl"); -- for zak <3
Clockwork.animation:AddCombineOverwatchModel("models/npcs/halo3elitescythebad.mdl"); -- key


Clockwork.animation:AddCivilProtectionModel("models/police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/retrocop.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hl2beta_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/arctic_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/resistance_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/urban_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/backpackcp/policeoutlands.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/civil_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/policetrench.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/female_police.mdl");