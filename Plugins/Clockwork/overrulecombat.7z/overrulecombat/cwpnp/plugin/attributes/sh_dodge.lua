--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Dodge";
	ATTRIBUTE.maximum = 10;
	ATTRIBUTE.uniqueID = "dge";
	ATTRIBUTE.description = "Affects how difficult you are to hit with melee/firearm attacks";
	ATTRIBUTE.isOnCharScreen = true;
ATB_DODGE = Clockwork.attribute:Register(ATTRIBUTE);

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Dodge");
COMMAND.tip = "Rolls 1d10 + your Dodge stat.";

-- Called when the command has been run.
function COMMAND:OnRun(player)

	local number = 10;
	local attribute = Clockwork.attributes:Fraction(player, ATB_DODGE, 10);
	local cyberware = Clockwork.attributes:Fraction(player, ATB_CDODGE, 10)
	Clockwork.chatBox:AddInRadius(player, "roll", "has rolled "..math.ceil(math.random(1, number)*0.75 + (attribute*0.75) + (cyberware*0.75)) .." for Dodging.",
		player:GetPos(), Clockwork.config:Get("talk_radius"):Get() * 2);
end;

COMMAND:Register();