--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Sneak");
COMMAND.tip = "Rolls 1d10 + your Reflexes stat. +25% boost. This command is used when you have the drop on somebody and are initiating combat, this is used in place of a regular Reflexes roll.";

-- Called when the command has been run.
function COMMAND:OnRun(player)
	local number = 10;
	local attribute = Clockwork.attributes:Fraction(player, ATB_REFLEXES, 10);
	local cyberware = Clockwork.attributes:Fraction(player, ATB_CREFLEXES, 10)
	Clockwork.chatBox:AddInRadius(player, "roll", "has rolled "..math.ceil((math.random(1, number) + attribute + cyberware)*1.25) .." for Sneak attack. ",
		player:GetPos(), Clockwork.config:Get("talk_radius"):Get() * 2);
end;

COMMAND:Register();