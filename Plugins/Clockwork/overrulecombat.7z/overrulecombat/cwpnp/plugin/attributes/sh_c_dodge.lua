--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Cyber Dodge";
	ATTRIBUTE.maximum = 10;
	ATTRIBUTE.uniqueID = "cdge";
	ATTRIBUTE.description = "Used for cyberware stat bonuses";
	ATTRIBUTE.isOnCharScreen = false;
ATB_CDODGE = Clockwork.attribute:Register(ATTRIBUTE);
