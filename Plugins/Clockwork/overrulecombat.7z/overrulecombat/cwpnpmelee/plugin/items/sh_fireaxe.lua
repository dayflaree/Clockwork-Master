--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Fireaxe";
ITEM.cost = 250;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Destroying [4]] [Two-Handed] [Non-Concealable] [Illegal] A long, heavy axe with a red head at the top. Requires two hands to use.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();