--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Rebar";
ITEM.cost = 25;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Bruising [1]] [One-Handed] [Concealable] [C-4] A good piece of rebar..";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();