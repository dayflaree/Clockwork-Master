--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Pickaxe";
ITEM.cost = 30;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "Not just for mining rock.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();