--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Beatstick";
ITEM.cost = 25;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Bruising [1]] [One-Handed] [Concealable] [C-4] It's a stick. It's made of an assortment of items taped together & you beat people with it.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();