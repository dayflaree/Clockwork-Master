--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Katana";
ITEM.cost = 200;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Crippling [3]] [Two-Handed] [Non-Concealable] [C-1] A standard, slender, & curved katana.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();