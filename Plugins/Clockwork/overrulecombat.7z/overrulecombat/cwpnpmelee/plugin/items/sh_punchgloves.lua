--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Punchgloves";
ITEM.cost = 25;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Bruising [1]] [One-Handed] [Concealable] [C-2] A pair of gloves, comfortably plated with metal under the material for hard and heavy hits.[Uses Brawling]";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();