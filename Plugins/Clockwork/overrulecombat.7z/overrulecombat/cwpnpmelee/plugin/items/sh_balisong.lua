--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Balisong";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding[2]] [One-Handed] [Concealable] [C-1] Known as 'Butterfly Knife' by most, this fancy weapon is both elegant and hard to master.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();