--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Longsword";
ITEM.cost = 250;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Destoying [4]] [Two-Handed] [Non-Concealable] [Illegal] The shortsword's bigger brother. Requires two hands to use.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();