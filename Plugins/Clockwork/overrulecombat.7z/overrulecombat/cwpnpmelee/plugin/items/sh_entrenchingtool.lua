--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Soviet MPL-50M Entrenching Tool";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding [2]] [One-Handed] [Non-Concealable] [C-2] A metal folding shovel with a superfine ceramic edge.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();