DEFINE_BASECLASS("base_gmodentity");

ENT.Type			= "anim";

ENT.PrintName		= "Beige Seat";
ENT.Author			= "RJ";

ENT.Spawnable		= false;
ENT.AdminSpawnable	= false;