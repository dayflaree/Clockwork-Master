DEFINE_BASECLASS("base_gmodentity");

ENT.Type			= "anim";

ENT.PrintName		= "Stool";
ENT.Author			= "RJ";

ENT.Spawnable		= false;
ENT.AdminSpawnable	= false;