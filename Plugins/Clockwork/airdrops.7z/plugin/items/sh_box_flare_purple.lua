local ITEM = Clockwork.item:New();
ITEM.name = "Box of Purple Flares";
ITEM.model = "models/props_junk/box_flares.mdl";
ITEM.weight = 1;
ITEM.cost = 300;
ITEM.access = "y";
ITEM.business = false;
ITEM.description = "An orange box, marked with the 'FLAMMABLE' symbol on the side. Inside are some purple emergency flares.";
ITEM.category = "Flares";

function ITEM:OnUse(player)
	if (!player:HasWeapon("weapon_flare_purple")) then
		player:Give("weapon_flare_purple");
	end;

	player:GiveAmmo(5, "flare_purple", true);
end;

ITEM:Register();