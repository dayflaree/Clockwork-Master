local ITEM = Clockwork.item:New();
ITEM.name = "Ammo Flare";
ITEM.model = "models/props_junk/flare.mdl";
ITEM.weight = 0.2;
ITEM.cost = 300;
ITEM.access = "y";
ITEM.business = false;
ITEM.description = "A single red flare with some military markings on it. It probably signals something.";
ITEM.category = "Flares";

function ITEM:OnUse(player)
	player:GiveAmmo(1, "flare_red", true);

	if (!player:HasWeapon("weapon_flare_red")) then
		player:Give("weapon_flare_red");
	end;
end;

ITEM:Register();