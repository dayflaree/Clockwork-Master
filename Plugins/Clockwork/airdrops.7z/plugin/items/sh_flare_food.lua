local ITEM = Clockwork.item:New();
ITEM.name = "Misc Flare";
ITEM.model = "models/props_junk/flare.mdl";
ITEM.weight = 0.2;
ITEM.cost = 300;
ITEM.access = "y";
ITEM.business = false;
ITEM.description = "A single green flare with some military markings on it. It probably signals something.";
ITEM.category = "Flares";

function ITEM:OnUse(player)
	player:GiveAmmo(1, "flare_food", true);

	if (!player:HasWeapon("weapon_flare_food")) then
		player:Give("weapon_flare_food");
	end;
end;

ITEM:Register();