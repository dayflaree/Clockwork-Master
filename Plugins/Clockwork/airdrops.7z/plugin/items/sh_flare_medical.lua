local ITEM = Clockwork.item:New();
ITEM.name = "Medical Flare";
ITEM.model = "models/props_junk/flare.mdl";
ITEM.weight = 0.2;
ITEM.cost = 300;
ITEM.access = "y";
ITEM.business = false;
ITEM.description = "A single purple flare with some military markings on it. It probably signals something.";
ITEM.category = "Flares";

function ITEM:OnUse(player)
	player:GiveAmmo(1, "flare_medical", true);

	if (!player:HasWeapon("weapon_flare_medical")) then
		player:Give("weapon_flare_medical");
	end;
end;

ITEM:Register();