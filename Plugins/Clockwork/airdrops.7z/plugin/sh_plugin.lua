local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sh_ammo.lua");

if (CLIENT) then
	Clockwork.datastream:Hook("ChopperSound", function(pos)
		sound.Play("ambient/machines/heli_pass1.wav", pos, 125);
	end);
end;