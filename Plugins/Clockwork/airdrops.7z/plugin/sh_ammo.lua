local PLUGIN = PLUGIN;

local function AddAmmo(uniqueID, name)
	game.AddAmmoType({
		name = uniqueID,
		dmgtype = DMG_GENERIC,
	});

	if (CLIENT) then
		language.Add(uniqueID .. "_ammo", name);
	end;
end;

AddAmmo("flare_red", "Red Flare");
AddAmmo("flare_green", "Green Flare");
AddAmmo("flare_blue", "Blue Flare");
AddAmmo("flare_purple", "Purple Flare");
AddAmmo("flare_ammo", "Ammo Flare");
AddAmmo("flare_food", "Food Flare");
AddAmmo("flare_misc", "Misc Flare");
AddAmmo("flare_medical", "Medical Flare");