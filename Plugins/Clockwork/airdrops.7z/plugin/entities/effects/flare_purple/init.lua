if (SERVER) then
	AddCSLuaFile();
end;

function EFFECT:Init(fx)
	self.emitter = ParticleEmitter(fx:GetEntity():GetPos());
	self.ent = fx:GetEntity();
	self.dieTime = CurTime() + (fx:GetEntity().flareLifeTime or 20);
end;

function EFFECT:Think()
	if (IsValid(self.ent) and (self.dieTime or 0) > CurTime()) then
		local dlight = DynamicLight(self.ent:EntIndex());

		if (dlight) then
			dlight.pos = self.ent:WorldSpaceCenter();
			dlight.r = 177;
			dlight.g = 60;
			dlight.b = 255;
			dlight.brightness = 1.8;
			dlight.Decay = 800;
			dlight.Size = 600;
			dlight.style = 6;
			dlight.DieTime = CurTime() + 1;
		end;

		local particle = self.emitter:Add("particle/smokesprites_0001", self.ent:WorldSpaceCenter() + self.ent:GetUp() * 6);
		particle:SetDieTime(3.5);
		particle:SetGravity(vector_up * 30 + VectorRand() * 8);
		particle:SetColor(255, 255, 255);
		particle:SetAirResistance(40);
		particle:SetStartAlpha(80);
		particle:SetRoll(math.random(0, 360));
		particle:SetRollDelta(math.random(-0.5, 0.5));
		particle:SetStartSize(8);
		particle:SetEndSize(30);
		particle:SetVelocity(self.ent:GetUp() * 80 + VectorRand() * 12);
		particle:SetVelocityScale(true);
		particle:SetLighting(false);

		return true;
	else
		self.emitter:Finish();
		return false;
	end;
end;

function EFFECT:Render()
end