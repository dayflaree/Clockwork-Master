local PLUGIN = PLUGIN;

if (SERVER) then
	AddCSLuaFile();
end;

local BaseClass = baseclass.Get("base_entity");

ENT.PrintName		= "Flare (Medical)";
ENT.Category		= "Flares";
ENT.Spawnable		= true;
ENT.AdminOnly		= true;
ENT.Model			= Model("models/props_junk/flare.mdl");
ENT.RenderGroup 	= RENDERGROUP_BOTH;
ENT.flareLifeTime	= 20;
ENT.entLifeTime		= 60;
ENT.supplyType		= "medical";
ENT.itemCount		= {3, 6};

if (SERVER) then

	function ENT:SpawnFunction(player, trace, class)
		if (!trace.Hit) then return; end;
		local entity = ents.Create(class);

		entity:SetPos(trace.HitPos + trace.HitNormal * 1.5);
		entity:Spawn();

		return entity;
	end;

	function ENT:Initialize()
		self:SetModel(self.Model);
		self:SetSolid(SOLID_VPHYSICS);
		self:PhysicsInit(SOLID_VPHYSICS);
		self:SetCollisionGroup(COLLISION_GROUP_WEAPON);
		self:SetSkin(1);

		local phys = self:GetPhysicsObject();

		if (IsValid(phys)) then
			phys:Wake();
		end;

		local itemCount = istable(self.itemCount) and math.random(self.itemCount[1], self.itemCount[2]) or self.itemCount;

		timer.Create("flares_dropTimer" .. self:EntIndex(), 10, 1, function()
			if (IsValid(self)) then
				PLUGIN:CreateAirdrop(self:GetPos() + Vector(0, 0, 10), self.supplyType, itemCount);
			end;
		end);

		SafeRemoveEntityDelayed(self, self.entLifeTime);
	end;

	function ENT:OnRemove()
		timer.Remove("flares_dropTimer" .. self:EntIndex());
	end;

elseif (CLIENT) then
	local mat = Material("sprites/light_ignorez");

	function ENT:Initialize()
		self:SetSolid(SOLID_VPHYSICS);
		self.dieTime = CurTime() + self.flareLifeTime;

		self.PixVis = util.GetPixelVisibleHandle();

		local ef = EffectData();
		ef:SetEntity(self);

		util.Effect("flare_purple", ef);

		self.burnSound = CreateSound(self, "Weapon_FlareGun.Burn");
		self.burnSound:PlayEx(0, 70);
		self.burnSound:ChangeVolume(1, 1);
		self.burnSound:ChangePitch(100, 2);
	end;

	function ENT:Think()
		if ((self.dieTime or 0) < CurTime() and !self.bFading) then
			self.bFading = true;
			self.burnSound:FadeOut(2)
			self.burnSound:ChangePitch(70, 1.5);
		end;
	end;

	function ENT:OnRemove()
		if (self.burnSound) then
			self.burnSound:Stop();
		end;
	end;

	function ENT:Draw()
		self:DrawModel();
	end;

	function ENT:DrawTranslucent()
		if ((self.dieTime or 0) > CurTime()) then
			local visible = util.PixelVisible(self:GetPos() + self:GetUp() * 6, 10, self.PixVis);
			local alpha = 255 * visible;

			if (!visible or visible < 0.1) then return; end;

			local randSize = math.random(20, 30);

			render.SetMaterial(mat);
			render.DrawSprite(self:GetPos() + self:GetUp() * 6, randSize, randSize, Color(167, 100, 255, alpha));
			render.DrawSprite(self:GetPos() + self:GetUp() * 6, randSize, randSize, Color(167, 100, 255, alpha));
			render.DrawSprite(self:GetPos() + self:GetUp() * 6, randSize, randSize, Color(167, 100, 255, alpha));
		end;
	end;
end;