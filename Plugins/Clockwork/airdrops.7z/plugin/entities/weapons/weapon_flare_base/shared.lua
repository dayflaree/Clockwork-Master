local PLUGIN = PLUGIN;

if (SERVER) then
	AddCSLuaFile()
end

if (CLIENT) then
	SWEP.Slot = 0
	SWEP.SlotPos = 5
	SWEP.DrawAmmo = false
	SWEP.PrintName = "Base Flare"
	SWEP.DrawCrosshair = true
end

SWEP.Instructions = ""
SWEP.Purpose = ""
SWEP.Contact = ""
SWEP.Author = "Zombine"
SWEP.WorldModel = "models/props_junk/flare.mdl"
SWEP.ViewModel = "models/weapons/v_punch.mdl"
SWEP.Category = "Flares"
SWEP.flareID = "flare_red";
SWEP.HoldType = nil
SWEP.AdminOnly = false
SWEP.Spawnable = false
SWEP.Primary.NeverRaised = true
SWEP.Primary.Automatic = false
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0;
SWEP.Primary.Ammo = SWEP.flareID
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.Ammo = SWEP.flareID
SWEP.NoIronSightFovChange = true
SWEP.NoIronSightAttack = true
SWEP.LoweredAngles = Angle(60, 60, 60)
SWEP.IronSightPos = Vector(0, 0, 0)
SWEP.IronSightAng = Vector(0, 0, 0)
SWEP.NeverRaised = true

AccessorFunc(SWEP, "m_eHeldFlare", "HeldFlare");

function SWEP:Holster(switchingTo)
	if (SERVER) then
		if (IsValid(self:GetHeldFlare())) then
			self:DropFlare();
			self:SetHeldFlare(nil);
		end;
	end;

	return true;
end

function SWEP:Initialize()

end

function SWEP:DrawWorldModel()
	if (IsValid(self.Owner)) then
		return false;
	else
		self:DrawModel();
	end;
end;

function SWEP:CanPrimaryAttack()
	return true;
end;

function SWEP:PreDrawViewModel()
	--render.MaterialOverride(Material("engine/writez"));
end;

function SWEP:PostDrawViewModel()
	--render.MaterialOverride(nil);
end;

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + 1.5);

	if (SERVER) then
		if (IsValid(self:GetHeldFlare())) then
			timer.Remove("flareWep_dropTimer" .. self:EntIndex());

			local flare = self:GetHeldFlare();

			flare:SetParent(nil);
			flare:PhysicsInit(SOLID_VPHYSICS);
			flare:GetPhysicsObject():Wake();
			flare:SetOwner(self.Owner);

			flare:SetPos(self.Owner:EyePos() + self.Owner:EyeAngles():Right() * 8 + self.Owner:EyeAngles():Forward() * 18);

			local vecThrow = self.Owner:GetVelocity();
			vecThrow = vecThrow + self.Owner:EyeAngles():Forward() * 1200;

			flare:GetPhysicsObject():SetVelocity(vecThrow);
			flare:GetPhysicsObject():ApplyForceOffset(self.Owner:EyeAngles():Forward() * 5 + VectorRand() * 2, flare:WorldSpaceCenter() + flare:GetUp() * 6);
			self:SetHeldFlare(nil);
		elseif (self:Ammo1() >= 1) then
			local flare = ents.Create(self.flareID);
			flare:SetOwner(self.Owner);

			flare:SetPos(self.Owner:EyePos() + self.Owner:EyeAngles():Right() * 8 + self.Owner:EyeAngles():Forward() * 18);
			flare:Spawn();

			local vecThrow = self.Owner:GetVelocity();
			vecThrow = vecThrow + self.Owner:EyeAngles():Forward() * 1200;

			flare:GetPhysicsObject():SetVelocity(vecThrow);
			flare:GetPhysicsObject():ApplyForceOffset(self.Owner:EyeAngles():Forward() * 5 + VectorRand() * 2, flare:WorldSpaceCenter() + flare:GetUp() * 6);

			self:TakePrimaryAmmo(1);
		end;

		if (self:Ammo1() < 1) then
			self.Owner:StripWeapon("weapon_" .. self.flareID);
		end;
	end;
end;

function SWEP:SecondaryAttack()
	self:SetNextSecondaryFire(CurTime() + 1.5);

	if (SERVER) then
		if (IsValid(self:GetHeldFlare())) then
			timer.Remove("flareWep_dropTimer" .. self:EntIndex());

			local flare = self:GetHeldFlare();

			flare:SetParent(nil);
			flare:PhysicsInit(SOLID_VPHYSICS);
			flare:GetPhysicsObject():Wake();
			flare:SetOwner(self.Owner);

			if (self.Owner:Crouching()) then
				local groundTrace = util.TraceLine({
					start = self.Owner:GetPos() + Vector(0, 0, 1),
					endpos = self.Owner:GetPos() - Vector(0, 0, 16),
					filter = self.Owner,
					mask = MASK_PLAYERSOLID
				});

				local vecDir = Angle(0, self.Owner:EyeAngles().y, 0):Forward();

				if (groundTrace.Fraction != 0) then
					local tangent = vecDir:Cross(groundTrace.HitNormal);
					vecDir = groundTrace.HitNormal:Cross(tangent);
				end;

				local vecSrc = self.Owner:GetPos() + vecDir * 18 + Vector(0, 0, 2.5);
				local vecThrow = self.Owner:GetVelocity();
				vecThrow = vecThrow + vecDir * 700;

				flare:SetAngles(Angle(0, self.Owner:EyeAngles().y, 90));
				flare:SetPos(vecSrc);
				flare:GetPhysicsObject():SetVelocity(vecThrow);
			else
				flare:SetPos(self.Owner:EyePos() + self.Owner:EyeAngles():Right() * 8 + self.Owner:EyeAngles():Forward() * 18 - Vector(0, 0, 8));

				local vecThrow = self.Owner:GetVelocity();
				vecThrow = vecThrow + self.Owner:EyeAngles():Forward() * 350 + Vector(0, 0, 50);

				flare:GetPhysicsObject():SetVelocity(vecThrow);
				flare:GetPhysicsObject():ApplyForceOffset(Vector(0, 0, 2), flare:WorldSpaceCenter() - flare:GetUp() * 6);
			end;

			self:SetHeldFlare(nil);
		elseif (self:Ammo1() >= 1) then
			local flare = ents.Create(self.flareID);
			flare:SetOwner(self.Owner);
			flare:Spawn();

			if (self.Owner:Crouching()) then
				local groundTrace = util.TraceLine({
					start = self.Owner:GetPos() + Vector(0, 0, 1),
					endpos = self.Owner:GetPos() - Vector(0, 0, 16),
					filter = self.Owner,
					mask = MASK_PLAYERSOLID
				});

				local vecDir = Angle(0, self.Owner:EyeAngles().y, 0):Forward();

				if (groundTrace.Fraction != 0) then
					local tangent = vecDir:Cross(groundTrace.HitNormal);
					vecDir = groundTrace.HitNormal:Cross(tangent);
				end;

				local vecSrc = self.Owner:GetPos() + vecDir * 18 + Vector(0, 0, 2.5);
				local vecThrow = self.Owner:GetVelocity();
				vecThrow = vecThrow + vecDir * 700;

				flare:SetAngles(Angle(0, self.Owner:EyeAngles().y, 90));
				flare:SetPos(vecSrc);
				flare:GetPhysicsObject():SetVelocity(vecThrow);
			else
				flare:SetPos(self.Owner:EyePos() + self.Owner:EyeAngles():Right() * 8 + self.Owner:EyeAngles():Forward() * 18 - Vector(0, 0, 8));

				local vecThrow = self.Owner:GetVelocity();
				vecThrow = vecThrow + self.Owner:EyeAngles():Forward() * 350 + Vector(0, 0, 50);

				flare:GetPhysicsObject():SetVelocity(vecThrow);
				flare:GetPhysicsObject():ApplyForceOffset(Vector(0, 0, 2), flare:WorldSpaceCenter() - flare:GetUp() * 6);
			end;

			self:TakePrimaryAmmo(1);
		end;

		if (self:Ammo1() < 1) then
			self.Owner:StripWeapon("weapon_" .. self.flareID);
		end;
	end;
end;

function SWEP:DropFlare()
	if (IsValid(self:GetHeldFlare())) then
		local flare = self:GetHeldFlare();

		flare:SetParent(nil);
		flare:PhysicsInit(SOLID_VPHYSICS);
		flare:GetPhysicsObject():Wake();
		flare:SetOwner(self.Owner);

		self:SetHeldFlare(nil);

		timer.Remove("flareWep_dropTimer" .. self:EntIndex());

		if (self:Ammo1() < 1) then
			self.Owner:StripWeapon("weapon_" .. self.flareID);
		end;
	end;
end;

function SWEP:Reload()
	if ((self.nextReload or 0) < CurTime()) then
		self.nextReload = CurTime() + 1.5;
	else
		return;
	end;

	if (SERVER) then
		if (IsValid(self:GetHeldFlare())) then
			self:DropFlare();
		elseif (self:Ammo1() >= 1) then
			local flare = ents.Create(self.flareID);
			local flareTime = flare.flareLifeTime or 20;

			flare:Spawn();
			flare:SetParent(self.Owner);
			flare:Fire("SetParentAttachment", "anim_attachment_RH");
			self:SetHeldFlare(flare);

			timer.Create("flareWep_dropTimer" .. self:EntIndex(), flareTime, 1, function()
				if (IsValid(self) and IsValid(self:GetHeldFlare())) then
					if (self:GetHeldFlare() != flare) then return; end;

					self:DropFlare();
				end;
			end);

			self:TakePrimaryAmmo(1);
		end;
	end;
end;

function SWEP:OnRemove()
	timer.Remove("flareWep_dropTimer" .. self:EntIndex());
end;