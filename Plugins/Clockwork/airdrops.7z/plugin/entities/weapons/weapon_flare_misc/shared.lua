if (SERVER) then
	AddCSLuaFile();
end;

if (CLIENT) then
	SWEP.Slot = 0;
	SWEP.SlotPos = 5;
	SWEP.DrawAmmo = false;
	SWEP.PrintName = "Misc Flare";
	SWEP.DrawCrosshair = true;
	SWEP.Category = "Flares";
end

SWEP.Spawnable = true;
SWEP.Base = "weapon_flare_base";
SWEP.flareID = "flare_misc";
SWEP.Primary.Ammo = SWEP.flareID