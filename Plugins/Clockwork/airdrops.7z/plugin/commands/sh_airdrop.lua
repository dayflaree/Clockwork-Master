local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("AirDrop");
COMMAND.tip = "Initiate an airdrop at your cursor's position.";
COMMAND.text = "<string Supply Type> <int Item Count>";
COMMAND.access = "a";
COMMAND.arguments = 2;

function COMMAND:OnRun(player, arguments)
	if (!arguments[1] or arguments[1] == "") then
		Clockwork.player:Notify(player, "You did not specify the supply type!");
		return;
	end;

	local supplyType = string.lower(arguments[1]);
	local itemCount = tonumber(arguments[2] or 4);

	if (!PLUGIN.supplyTypes[supplyType]) then
		Clockwork.player:Notify(player, "That is not a valid supply type!");
		return;
	end;

	local crate = PLUGIN:CreateAirdrop(player:GetEyeTrace().HitPos, supplyType, itemCount);

	if (!crate) then
		Clockwork.player:Notify(player, "You cannot place an airdrop here! The sky above must be clear!");
		return;
	end;
end;

COMMAND:Register();