local PLUGIN = PLUGIN;

PLUGIN.supplyTypes = {
	ammo = {
		"357_magnum",
		"44-40_winchester",
		"45_acp",
		"762x39mm",
		"762x51mm",
		"9x19mm"
	},

	medical = {
		"antibiotics",
		"bandage",
		"disinfectant",
		"hemostat",
		"medkit",
		"morphine_syringe",
		"penicillin"
	},

	human = {
		"human_ration",
		"water_clean"
	},

	clothes = {
		"bandit_brown",
		"bandit_black",
		"scavenger_red",
		"scavenger_black"
	},

	misc = {
		"scavenger_red",
		"scavenger_black",
		"triedge",
		"cw_shovel",
		"cw_sledgehammer",
		"kukri",
		"pipe",
		"luger",
		"huntingknife",
		"coltcommando",
		"cw_baseballbat",
		"beretta",
		"medkit",
		"bandage",
		"cw_climbingkit",
		"bp_pistol_low",
		"bp_rechamber_low",
		"armor_scraps",
		"45_acp",
		"9x19mm",
		"wallet",
		"12_gauge_buckshot"
	}
}

function PLUGIN:CreateAirdrop(landingPos, supplyType, itemCount)
	if (!self.supplyTypes[supplyType]) then return false; end;

	local skyTrace = util.TraceLine({
		start = landingPos + Vector(0, 0, 5),
		endpos = landingPos + Vector(0, 0, 12000)
	});

	if (skyTrace.Hit and !skyTrace.HitSky) then return false; end;

	Clockwork.datastream:Start(nil, "ChopperSound", skyTrace.HitPos);

	local crate = ents.Create("prop_physics");
	crate:SetModel("models/items/item_item_crate.mdl");
	crate:SetPos(skyTrace.HitPos - Vector(0, 0, 40));
	crate:SetAngles(Angle(0, AngleRand().y, 0));
	crate:Spawn();
	crate:GetPhysicsObject():SetMass(1);
	crate.falling = true;

	local parachute = ents.Create("prop_physics");
	parachute:SetModel("models/jessev92/bf2/parachute.mdl");
	parachute:SetPos(crate:GetPos() - crate:GetUp() * 40);
	parachute:SetAngles(crate:GetAngles());
	parachute:Spawn();
	parachute:GetPhysicsObject():SetMass(0.1);
	parachute:SetNotSolid(true);

	crate:DeleteOnRemove(parachute);

	constraint.Weld(parachute, crate, 0, 0, 0, true, true);

	if (!crate.cwInventory) then
		crate.cwInventory = {};
	end;

	for i = 1, itemCount do
		local randomID = table.Random(self.supplyTypes[supplyType]);
		local randomInstance = Clockwork.item:CreateInstance(randomID);

		Clockwork.inventory:AddInstance(crate.cwInventory, randomInstance);
	end;

	crate:AddCallback("PhysicsCollide", function(self, data)
		if (IsValid(parachute) and self.falling) then
			local downTrace = util.TraceLine({
				start = self:GetPos() + Vector(0, 0, 10),
				endpos = self:GetPos() - Vector(0, 0, 40),
				filter = {self, parachute}
			});

			if (downTrace.Hit and downTrace.Fraction < 1) then
				self.falling = false;

				timer.Simple(0.1, function()
					if (!IsValid(self) and !IsValid(parachute)) then return; end;

					local hitAng = downTrace.HitNormal:Angle();
					local grounded = ents.Create("prop_physics");

					hitAng:RotateAroundAxis(downTrace.HitNormal:Angle():Right(), -90);

					local diff = math.AngleDifference(parachute:GetAngles().y, hitAng.y);

					hitAng:RotateAroundAxis(downTrace.HitNormal, diff - 90);

					grounded:SetModel("models/jessev92/codmw2/parachute_ground_skins.mdl");
					grounded:SetAngles(hitAng);
					grounded:SetSkin(1);
					grounded:SetPos(downTrace.HitPos + grounded:GetRight() * 80 + grounded:GetForward() * 15);
					grounded:SetModelScale(0.5, 0);
					grounded:SetOwner(self);
					grounded:Spawn();
					grounded:SetNotSolid(true);
					grounded:GetPhysicsObject():EnableMotion(false);

					self:EmitSound("npc/combine_soldier/zipline_hitground" .. math.random(1, 2) .. ".wav");

					SafeRemoveEntityDelayed(grounded, 30);
					SafeRemoveEntity(parachute);
				end);
			end;
		end;
	end);

	return crate;
end;