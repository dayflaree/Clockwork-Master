local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Kevlar Vest with Bag";
	ITEM.model = "models/tnb/items/shirt_rebelbag.mdl";
	ITEM.weight = 3;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 9
	ITEM.description = "A plain green shirt with a vest that contains six pouches and a bag.";
	ITEM.customFunctions = {"Remove"};
	ITEM.addInvSpace = 3.5;
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();