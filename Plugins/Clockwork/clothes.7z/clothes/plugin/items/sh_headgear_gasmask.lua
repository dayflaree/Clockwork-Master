local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Gasmask";
	ITEM.model = "models/tnb/items/gasmask.mdl";
	ITEM.skin = 3;
	ITEM.weight = 0.8;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 4
	ITEM.bodyGroupVal = 2
	ITEM.description = "An old rubber GP-5 Gasmask, has an uncomfortable fit for the big heads, better to use this if needed.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();