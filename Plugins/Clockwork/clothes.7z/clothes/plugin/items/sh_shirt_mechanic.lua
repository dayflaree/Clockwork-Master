local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Black T-Shirt";
	ITEM.model = "models/tnb/items/shirt_citizen2.mdl";
	ITEM.skin = 3;
	ITEM.weight = 0.5
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 7
	ITEM.description = "A black t-shirt.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();