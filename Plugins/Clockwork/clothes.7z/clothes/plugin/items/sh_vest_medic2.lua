local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Grey Shirt & Medic Vest";
	ITEM.model = "models/tnb/items/shirt_rebel1.mdl";
	ITEM.skin = 1;
	ITEM.weight = 2.5;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 11
	ITEM.description = "A plain grey shirt with a medic vest that contains six pouches.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();