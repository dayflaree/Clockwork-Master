local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Overwatch Power Vest";
	ITEM.model = "models/tnb/items/shirt_rebeloverwatch.mdl";
	ITEM.skin = 1;
	ITEM.weight = 15;
	ITEM.useText = "Assemble";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 13
	ITEM.description = "A chestplate of overwatch power armor, without the indentity confirmation, the suit is locked to various abilities, and without support with the hydralics, it is indeed a very heavy suit.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();