local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Grey Beanie";
	ITEM.model = "models/tnb/items/beanie.mdl";
	ITEM.weight = 0.2;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 4
	ITEM.bodyGroupVal = 3
	ITEM.description = "A knitted wool toque.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();