local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "MOLLE Vest";
	ITEM.model = "models/tnb/items/shirt_rebel_molle.mdl";
	ITEM.weight = 8;
	ITEM.skin = 1;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 15
	ITEM.description = "A uniform shirt combined with a police vest, it is rather heavy.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
	
ITEM:Register();