local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Bandana";
	ITEM.model = "models/tnb/items/facewrap.mdl";
	ITEM.weight = 0.2;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 4
	ITEM.bodyGroupVal = 1
	ITEM.description = "A linen cloth tied in a knot, used primarily for concealing the wearers face.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();