local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "CWU Shirt";
	ITEM.model = "models/tnb/items/shirt_citizen1.mdl";
	ITEM.skin = 2;
	ITEM.weight = 0.5
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 2
	ITEM.description = "A comfortable white shirt issued to all CWU members.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();