local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Shirt with MPF Vest";
	ITEM.model = "models/tnb/items/shirt_rebelmetrocop.mdl";
	ITEM.weight = 2.5;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 14
	ITEM.description = "A plain blue shirt with a police vest that contains six pouches.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();