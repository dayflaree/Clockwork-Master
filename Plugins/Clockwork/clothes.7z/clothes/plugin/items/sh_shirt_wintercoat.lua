local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Winter Coat";
	ITEM.model = "models/tnb/items/wintercoat.mdl";
	ITEM.weight = 2
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 16
	ITEM.description = "A brown pre-war winter coat.";
	ITEM.customFunctions = {"Remove"};
	ITEM.addInvSpace = 6.5;
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();