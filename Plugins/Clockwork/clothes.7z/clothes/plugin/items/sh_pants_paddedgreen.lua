local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Padded Green Jeans";
	ITEM.model = "models/tnb/items/pants_rebel.mdl";
	ITEM.weight = 1.5;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 2
	ITEM.bodyGroupVal = 4
	ITEM.description = "A pair of jeans that are reinforced with kevlar pads, take caution and avoid wearing this from the public authoritary eye.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();