local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Black Sweater";
	ITEM.model = "models/tnb/items/shirt_citizen1.mdl";
	ITEM.skin = 3;
	ITEM.weight = 0.5
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 6
	ITEM.description = "An old pre-war sweater that contains a few spare pockets.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();