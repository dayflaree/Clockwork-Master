local ITEM = Clockwork.item:New("bodygroup_base")
	ITEM.name = "Jogging Pants";
	ITEM.model = "models/tnb/items/pants_citizen.mdl";
	ITEM.skin = 3;
	ITEM.weight = 0.5;
	ITEM.useText = "Wear";
	ITEM.bodyGroup = 2
	ITEM.bodyGroupVal = 3
	ITEM.description = "A pair of pre-war jogging pants.";
	ITEM.customFunctions = {"Remove"};
	
	if (SERVER) then
		function ITEM:OnCustomFunction(player)
			if (self:HasPlayerEquipped(player) and self.bodyGroup != -1) then
				player:SetBodygroupClothes(self, true)
			end
		end;
	end;
		
ITEM:Register();