local PLUGIN = PLUGIN;

vStaffRequests = {};
