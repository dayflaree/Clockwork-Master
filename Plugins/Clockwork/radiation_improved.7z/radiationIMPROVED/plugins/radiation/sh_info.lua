--[[
	Name: sh_info.lua.
	Author: Snazzy.
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Radiation";
PLUGIN.author = "Spencer Sharkey.";
PLUGIN.description = "Allows to mark areas that contain certain levels of radiation.";