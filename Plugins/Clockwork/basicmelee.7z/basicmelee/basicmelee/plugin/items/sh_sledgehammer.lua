--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Sledgehammer";
	ITEM.cost = 15;
	ITEM.model = "models/weapons/w_sledgehammer.mdl";
	ITEM.weight = 1.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_sledgehammer";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "Hammer time!";
	ITEM.value = 0.7;
	ITEM.spawncategory = 7;
ITEM:Register();