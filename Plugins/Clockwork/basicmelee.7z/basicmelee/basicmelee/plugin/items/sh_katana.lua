--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Katana";
	ITEM.cost = 1000;
	ITEM.model = "models/weapons/w_katana.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_katana";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A deadly looking katana. You can probably not wear this as a side weapon.";
	ITEM.value = 0.9;
	ITEM.spawncategory = 7;
ITEM:Register();