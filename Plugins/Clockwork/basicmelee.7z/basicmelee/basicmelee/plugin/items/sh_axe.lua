--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Axe";
	ITEM.cost = 15;
	ITEM.model = "models/weapons/w_axe.mdl";
	ITEM.weight = 1;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_axe";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A rusty axe. Probably not that sharp anymore.";
	ITEM.value = 0.3;
	ITEM.spawncategory = 7;
ITEM:Register();