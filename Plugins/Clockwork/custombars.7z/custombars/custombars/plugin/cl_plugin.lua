--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

local BAR_TEXTURE 	= Material("tesrp/gui/healthbar.png"); -- Separate bar for health.
															-- If you don't have another 
															-- material, just use the same one as BAR2_TEXTURE
															
local BAR2_TEXTURE 	= Material("tesrp/gui/bar.png"); -- Texture for every other bar

-- Called just after a bar is drawn.
function PLUGIN.module:PostDrawBar(barInfo)
	surface.SetDrawColor(barInfo.color.r, barInfo.color.g, barInfo.color.b, barInfo.color.a);
	surface.SetMaterial(BAR2_TEXTURE);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.progressWidth, barInfo.height);
	surface.SetDrawColor(255, 255, 255, 255);
	surface.SetMaterial(BAR_TEXTURE);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.width, barInfo.height);
end;