Clockwork.config:Add("disable_npc_drops", false, true);
