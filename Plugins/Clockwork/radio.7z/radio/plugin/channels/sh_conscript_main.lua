
local CHANNEL = Clockwork.radio:New();
CHANNEL.name = "Conscript";
CHANNEL.uniqueID = "conscript_main";
CHANNEL.subChannels = 1;
CHANNEL.global = false;
CHANNEL.defaultPriority = 7;

CHANNEL.color = Color(0, 200, 0);


CHANNEL:Register();