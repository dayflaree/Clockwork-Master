--[[
local CHANNEL = Clockwork.radio:New();
CHANNEL.name = "squadtestglobal";
CHANNEL.uniqueID = "squad_global_squad";
CHANNEL.subChannels = 1;
CHANNEL.global = true;
CHANNEL.defaultPriority = 8;
CHANNEL.targetChannels = {["mi_squad"] = "all"}

CHANNEL:Register();]]