
local CHANNEL = Clockwork.radio:New();
CHANNEL.name = "test";
CHANNEL.uniqueID = "freq_test";
CHANNEL.subChannels = 1;
CHANNEL.global = false;
CHANNEL.defaultPriority = 5;

CHANNEL:Register();