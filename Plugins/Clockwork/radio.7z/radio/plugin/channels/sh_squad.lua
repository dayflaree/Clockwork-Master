--[[
local CHANNEL = Clockwork.radio:New();
CHANNEL.name = "squadtest";
CHANNEL.uniqueID = "squad_test";
CHANNEL.subChannels = 9;
CHANNEL.global = false;
CHANNEL.defaultPriority = 10;

CHANNEL:Register();]]