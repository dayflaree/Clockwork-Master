
local CHANNEL = Clockwork.radio:New();
CHANNEL.name = "Hunter test";
CHANNEL.uniqueID = "public";
CHANNEL.subChannels = 1;
CHANNEL.global = false;
CHANNEL.defaultPriority = 7;

CHANNEL.color = Color(0, 200, 0);


CHANNEL:Register();