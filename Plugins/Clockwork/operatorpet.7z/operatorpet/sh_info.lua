--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Operator Pet Flags";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This plugin allows operators and above to give 'pet' flags with a simple command.";