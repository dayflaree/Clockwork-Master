local PLUGIN = PLUGIN

surface.CreateFont("HTextEntryFont", {
	font = "Arial",
	extended = true,
	size = 16,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

local PANEL = {}
function PANEL:Init()
	local w = math.max(ScrH() / 4, 768)
	local h = math.max(ScrH() / 1, 768)

	self:SetSize(w, h)	
	self:MakePopup()
	self:Center()
	self:SetTitle(L("ITEM_Paper"))

	self.controls = vgui.Create("DScrollPanel", self)
	self.controls:Dock(BOTTOM)

	self.list = vgui.Create("DIconLayout", self.controls)
	self.list:Dock(TOP)
	self.list:DockMargin(0, 0, 0, 5)
	self.list:SetSpaceX(0)
	self.list:SetSpaceY(0)

	self.title = self:Add("DLabel")
	self.title:SetText(L("PAPERGUI_Title"))
	self.title:SizeToContents()
	self.title:Dock(TOP)
	self.title:DockMargin(1, 0, 0, 5)

	self.titletext = self:Add("DTextEntry")
	self.titletext:SetValue("Безымянный")
	self.titletext:Dock(TOP)

	self.content = self:Add("DLabel")
	self.content:SetText(L("PAPERGUI_Content"))
	self.content:SizeToContents()
	self.content:Dock(TOP)
	self.content:DockMargin(1, 5, 0, 5)


	self.contents = vgui.Create("DTextEntry", self)
	self.contents:DockMargin(0, 0, 0, 4)
	self.contents:Dock(FILL)
	self.contents:SetFont("HTextEntryFont")
	self.contents:SetText("")
	self.contents:SetMultiline(true)
	self.contents:SetDrawLanguageID(false)
	self.contents:SetVerticalScrollbarEnabled(true)

	function self.contents:SetRealValue(text)
		self:SetValue(text)
		self:SetCaretPos(string.utf8len(text))
	end

	function self.contents:Think()
		local text = self:GetValue();
		
		if string.utf8len(text) > MAX_PAPER_CHARACTERS then
			self:SetRealValue(string.utf8sub(text, 0, MAX_PAPER_CHARACTERS))
			
			surface.PlaySound("common/talk.wav")
		end
	end
	

	surface.SetFont("Default")
	for k, v in ipairs(bureaucracy.BBCodes) do
		local x, y = surface.GetTextSize(v.id)
		local formatbtn = self.list:Add("DButton")
		formatbtn:SetTooltip(L(v.hint))
		formatbtn:SetText(v.id)
		formatbtn:SetSize(x + 10, 24)
		formatbtn.DoClick = function(s)
			local text = self.contents:GetValue()
			local caretPos = self.contents:GetCaretPos()
			local before = string.utf8sub(text, 1, caretPos)
			local after = string.utf8sub(text, caretPos + 1)

			self.contents:SetValue(before .. v.format .. after)
		end
	end
	
	self.canpickup = self.controls:Add("DCheckBoxLabel")
	self.canpickup:SetText(L("PAPERGUI_AdminRestrict"))
	self.canpickup:Dock(TOP)

	self.sizetext = self.controls:Add("DLabel")
	self.sizetext:Dock(TOP)
	self.sizetext:SetText("")
	self.sizetext.Think = function(s)
		local text = self.contents:GetText()
		//text = string.gsub(text, "%[.*%](.*)%[%/.*%]","%1")

		s:SetText(L("PAPERGUI_Size", string.utf8len(text), MAX_PAPER_CHARACTERS))
	end

	self.confirm = self.controls:Add("DButton")
	self.confirm:Dock(TOP)
	self.confirm:SetText(L("PAPERGUI_Ok"))
	self.confirm.DoClick = function(this)
		local text = self.contents:GetText()
		Clockwork.datastream:Start("bb_SendWrite", {text, self.titletext:GetValue(), self.canpickup:GetChecked()})
		self:Close()
	end
	self.controls:SizeToContents()
end
function PANEL:Think()
	local h = self.controls:GetCanvas():GetTall()
	if self.controls:GetTall() != h then
		self.controls:SetTall(h)
	end
end
function PANEL:OnClose()
	Clockwork.datastream:Start("bb_Closed")
end
vgui.Register("BB_NoteWrite", PANEL, "DFrame")


PANEL = {}
function PANEL:Init()
	self.btnMinim:SetVisible(false)
	self.btnMaxim:SetVisible(false)

	local w = math.max(ScrH() / 4, 768)
	local h = math.max(ScrH() / 1, 768)
		
	self:SetSize(w, h)	
	self:MakePopup()
	self:Center()
	self:SetTitle("Лист бумаги")

	self.controls = self:Add("DPanel")
	self.controls:Dock(FILL)
	self.controls:SetTall(30)

	local HTML = self:Add("DHTML")
	function HTML.Paint( HTML, w, h ) end
	self.contents = HTML

	self.contents:Dock(FILL)
	self.contents:InvalidateLayout(true)
	self.contents:RequestFocus()
	self.contents:AddFunction( "gmodinterface", "Write", function(id)
		if id != "END" then
			id = tonumber(id)
		end

		self.messageBox = Derma_StringRequest("Поле для ввода", "Введите текст", "", function(text)
			Clockwork.datastream:Start("bb_SendEdit", {id, text})
		end, nil, "ПРИМЕНИТЬ", "ОТМЕНА")
	end)

	self.controls.Paint = function(this, w, h) end
end
function PANEL:Load(data)
	self.contents:SetHTML([[<!DOCTYPE html>
	<html content="text/html; charset=UTF-8">
	<head>
	<style type="text/css">
		html {
			margin: 0;
			padding: 0;
			background-color: #FFF;
		}
		body {
			margin: 0;
			padding: 0;
			font-family: sans-serif;
		}
		span {
			display: inline-block;
		}
		div {
			display: inline-block;
		}
		div.content {
			display: block;
			width: calc(100% - 20px);
			height: 100%;
			font-size: 12px;
			text-align: left;
			margin: 20px 20px 20px 20px;
			word-break: break-all;
		}
		.big {
			font-size: 16px;
		}
		.small {
			font-size: 10px;
		}
		.large {
			font-size: 20px;
		}
		.red {
			color: rgb(255,40,40);
		}
		.green {
			color: rgb(40,255,40);
		}
		.blue {
			color: rgb(40,40,255);
		}
		.sign {
			font-style: italic;
			font-size: 90%;
			font-family: "Trebuchet MS", monospace;
		}
		.textarea {
			display: inline-block;
			font-size: 12px;
			word-break: break-all;
			min-width: 32px;
			min-height: 100%;
			vertical-align:top;
			text-decoration: underline;
		}
	</style>
	</head>
	<div id="entry" class="content">
	]]..data..[[
	</div>
	<body>
	</html>]])
end
function PANEL:Paint(w, h)
	surface.SetDrawColor(80, 80, 80, 225)
	surface.DrawRect(0, 0, w, 24)
end
function PANEL:OnClose()
	Clockwork.datastream:Start("bb_Closed")
end
vgui.Register("BB_NoteEdit", PANEL, "DFrame")


Clockwork.datastream:Hook("bb_OpenWriteEditor", function(data)
	if BB_WRITE_EDITOR then BB_WRITE_EDITOR:Remove() BB_WRITE_EDITOR = nil end

	BB_WRITE_EDITOR = vgui.Create("BB_NoteWrite")
end)
Clockwork.datastream:Hook("bb_OpenEditEditor", function()
	if BB_EDIT_EDITOR then BB_EDIT_EDITOR:Remove() BB_EDIT_EDITOR = nil end

	BB_EDIT_EDITOR = vgui.Create("BB_NoteEdit")
	BB_EDIT_EDITOR:Load("LOADING DATA...<br>PLEASE WAIT!")
end)
Clockwork.datastream:Hook("bb_LoadEditData", function(data)
	local editData = data[1]
	local title = data[2]

	if BB_EDIT_EDITOR then
		BB_EDIT_EDITOR:Load(editData)
		BB_EDIT_EDITOR:SetTitle(title)
	end
end)
Clockwork.datastream:Hook("bb_Error", function(data)
	if BB_EDIT_EDITOR then
		local errorText = "Unknown error."

		if data == 1 then
			errorText = ""
		elseif data == 2 then
			errorText = ""
		end

		Derma_Message("Error", errorText, "ОК")
	end
end)
Clockwork.datastream:Hook("bb_Update", function(data)
	if BB_EDIT_EDITOR then
		BB_EDIT_EDITOR:Load(data)
	end
end)

