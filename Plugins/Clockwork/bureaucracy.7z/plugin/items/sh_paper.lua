local ITEM = Clockwork.item:New();
ITEM.name = "Лист бумаги";
ITEM.cost = 0;
ITEM.model = "models/props_c17/paper01.mdl";
ITEM.useText = "ITEM_PaperUse"
ITEM.category = "Прочее";
ITEM.useSound = false
ITEM.weight = 0.025;
ITEM.access = "";
ITEM.business = true;
ITEM.description = "";

ITEM:AddData("CanWrite", true, true)
ITEM:AddData("CanPickup", true, true)
ITEM:AddData("PaperTitle", "Unnamed", true)

if CLIENT then
	function ITEM:GetClientSideDescription()
		local desc = self.description
		local canwrite = self:GetData("CanWrite")
		if !canwrite then
			desc = L("ITEM_PaperDesc2", self:GetData("PaperTitle"))
		else
			desc = "Чистый блокнот с большим количеством листов."
		end
		
		return (desc != "" and desc)
	end
end

function ITEM:OnUse(player, itemEntity)
	if !bureaucracy:CanPlayerEdit(self.itemID, player) then 
		Clockwork.player:Notify(player, {"ITEM_PaperError"});
		return false
	end
	if self:GetData("CanWrite") then
		player.bb_writing_itemid = self.itemID
		Clockwork.datastream:Start(player, "bb_OpenWriteEditor", {})
	else
		player.bb_writing_itemid = self.itemID
		bureaucracy:SendPaper(self, player)
	end
	return false;
end

function ITEM:OnDrop(player, position) end;

if SERVER then
	function ITEM:OnInstantiated()
		local papers = Clockwork.kernel:RestoreSchemaData("plugins/bureaucracy/"..game.GetMap())
		for k, v in pairs(papers) do
			if self("itemID") == tonumber(v.i) then
				local decoded = ""
				local text = Clockwork.kernel:RestoreSchemaData("plugins/bureaucracy/t_"..v.i..game.GetMap())
				if text and text[1] then
					text = string.Explode(" ", text[1].t)
					for k, v in pairs(text) do
						decoded = decoded .. string.char(string.format("%i", "0x"..v))
					end
				else
					decoded = "ERROR"
				end

				local paper = {
					Text = decoded,
					ItemID = v.i,
					Writer = v.w,
					Fields = v.f,
					Freespace = v.s,
				}

				bureaucracy:UpdateInfoLinks(paper)

				self.PaperObjectData = paper
			end
		end
	end;
	function ITEM:CanPickup(ply, use)
		if !use then
			if self.PaperObjectData then
				if self.PaperObjectData.Writer then
					if ply:SteamID() != self.PaperObjectData.Writer then
						return self:GetData("CanPickup")
					end
				else
					return true
				end
			else
				return true
			end
		end
		return true
	end
end

ITEM:Register();