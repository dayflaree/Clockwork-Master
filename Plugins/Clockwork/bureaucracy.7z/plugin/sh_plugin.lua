local PLUGIN = PLUGIN
PLUGIN:SetGlobalAlias("bureaucracy")

MAX_PAPER_CHARACTERS = 10000
BB_ERROR_SPACE = 1
BB_ERROR_FIELDS = 2

bureaucracy.BBCodes = {
	[1] = {
		id = "[b]",
		hint = "PAPERFORMAT_B",
		find = {"[b]", "[/b]"},
		replace = {"<b>", "</b>"},
		format = "[b][/b]"
	},
	[2] = {
		id = "[i]",
		hint = "PAPERFORMAT_I",
		find = {"[i]", "[/i]"},
		replace = {"<i>", "</i>"},
		format = "[i][/i]"
	},
	[3] = {
		id = "[u]",
		hint = "PAPERFORMAT_U",
		find = {"[u]", "[/u]"},
		replace = {"<u>", "</u>"},
		format = "[u][/u]"
	},
	[4] = {
		id = "[large]",
		hint = "PAPERFORMAT_Large",
		find = {"[large]", "[/large]"},
		replace = {"<font size=\"4\">", "</font>"},
		format = "[large][/large]"
	},
	[5] = {
		id = "[big]",
		hint = "PAPERFORMAT_Big",
		find = {"[big]", "[/big]"},
		replace = {"<font size=\"3\">", "</font>"},
		format = "[big][/big]"
	},
	[6] = {
		id = "[small]",
		hint = "PAPERFORMAT_Small",
		find = {"[small]", "[/small]"},
		replace = {"<font size=\"1\">", "</font>"},
		format = "[small][/small]"
	},
	[7] = {
		id = "[center]",
		hint = "PAPERFORMAT_Center",
		find = {"[center]", "[/center]"},
		replace = {"<center>", "</center>"},
		format = "[center][/center]"
	},
	[8] = {
		id = "[right]",
		hint = "PAPERFORMAT_Right",
		find = {"[right]", "[/right]"},
		replace = {"<right>", "</right>"},
		format = "[right][/right]"
	},
	[9] = {
		id = "[list]",
		hint = "PAPERFORMAT_List",
		find = {"[list]", "[/list]"},
		replace = {"<ul type=\"square\">", "</ul>"},
		format = "[list][/list]"
	},
	[10] = {
		id = "[*]",
		hint = "PAPERFORMAT_ListEntry",
		find = {"[*]"},
		replace = {"<li>"},
		format = "[*]"
	},
	[11] = {
		id = "[hr]",
		hint = "PAPERFORMAT_HR",
		find = {"[hr]"},
		replace = {"<hr>"},
		format = "[hr]"
	},
	[12] = {
		id = "[br]",
		hint = "PAPERFORMAT_BR",
		find = {"[br]"},	
		replace = {"<br>"},
		format = "[br]"
	},
	[13] = {
		id = "[blue]",
		hint = "PAPERFORMAT_Blue",
		find = {"[blue]", "[/blue]"},
		replace = {"<font color=\"0000FF\">", "</font>"},
		format = "[blue][/blue]"
	},
	[14] = {
		id = "[red]",
		hint = "PAPERFORMAT_Red",
		find = {"[red]", "[/red]"},
		replace = {"<font color=\"FF0000\">", "</font>"},
		format = "[red][/red]"
	},
	[15] = {
		id = "[green]",
		hint = "PAPERFORMAT_Green",
		find = {"[green]", "[/green]"},
		replace = {"<font color=\"00FF00\">", "</font>"},
		format = "[green][/green]"
	},
	[16] = {
		id = "[editorbr]",
		hint = "PAPERFORMAT_EditorBR",
		find = {"[editorbr]"},
		replace = {""},
		format = "[editorbr]"
	},
	[17] = {
		id = "[sign]",
		hint = "PAPERFORMAT_Sign",
		find = false,
		replace = false,
		format = "[sign]"
	},
	[18] = {
		id = "[field]",
		hint = "PAPERFORMAT_Field",
		find = {"[field]"},	
		replace = {"<span class=\"paper_field\"></span>"},
		format = "[field]"
	},
	[19] = {
		id = "[date]",
		hint = "PAPERFORMAT_Date",
		find = false,	
		replace = false,
		format = "[date]"
	},
	[20] = {
		id = "[time]",
		hint = "PAPERFORMAT_Time",
		find = false,	
		replace = false,
		format = "[time]"
	}
}

Clockwork.kernel:IncludePrefixed("sv_plugin.lua")
Clockwork.kernel:IncludePrefixed("cl_plugin.lua")

