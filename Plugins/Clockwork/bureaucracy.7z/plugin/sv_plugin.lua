local PLUGIN = PLUGIN
bureaucracy.PaperData = bureaucracy.PaperData or {}

function bureaucracy:PostSaveData()
	local papers = {}
	
	for k, v in pairs(Clockwork.item.instances) do
		local itemPaper = v.PaperObjectData
		if itemPaper then
			papers[#papers + 1] = {
				i = k,
				w = itemPaper.Writer,
				f = itemPaper.Fields,
				s = itemPaper.Freespace
			}

			local encodedStr = ""
			local encoded = {string.byte(itemPaper.Text, 1, #itemPaper.Text)}
			for k, v in pairs(encoded) do
				encodedStr = encodedStr .. (k != 1 and " " or "") .. string.format("%X", v)
			end

			local savetable = {
				[1] = {
					t = encodedStr
				}
			}

			Clockwork.kernel:SaveSchemaData("plugins/bureaucracy/t_"..k..game.GetMap(), savetable)
		end
	end
	
	Clockwork.kernel:SaveSchemaData("plugins/bureaucracy/"..game.GetMap(), papers)
end

function bureaucracy:CanPlayerEdit(itemID, ply)
	local item = Clockwork.item:FindInstance(itemID)
	if item then
		local hasFields = false
		if item.PaperObjectData then
			hasFields = (item.PaperObjectData.Fields != 0)
		end
		if hasFields then
			for k, v in pairs(player.GetAll()) do
				if v == ply then continue end
				if v.bb_writing_itemid == itemID then
					return false
				end
			end
		end
		return true
	end	
end

function bureaucracy:SendPaper(item, player)
	if !item then return end
	if !IsValid(player) then return end
	if player.bb_writing_itemid != item.itemID then return end

	local paperObject = item.PaperObjectData
	if paperObject then
		if paperObject then
			local formattedText = paperObject.HTMLText
			if formattedText then
				Clockwork.datastream:Start(player, "bb_OpenEditEditor")
				Clockwork.datastream:Start(player, "bb_LoadEditData", {formattedText, item:GetData("PaperTitle")})
			end
		end
	end
end

function bureaucracy:Parse(player, paper, textcode)
	if #textcode == 0 then
		return
	end

	local minute = Clockwork.kernel:ZeroNumberToDigits(Clockwork.time:GetMinute(), 2);
	local hour = Clockwork.kernel:ZeroNumberToDigits(Clockwork.time:GetHour(), 2);
	local dateString = Clockwork.kernel:GetSharedVar("Date")
	local timeString = hour .. ":" .. minute

	textcode = string.Replace(textcode, "\n", "<br>")
	textcode = string.Replace(textcode, "[sign]", "<span class=\"sign\">"..player:GetName().."</span>")
	textcode = string.Replace(textcode, "[time]", timeString)
	textcode = string.Replace(textcode, "[date]", dateString)

	for bbcode, tbl in ipairs(self.BBCodes) do
		if tbl.find and tbl.replace then
			if tbl.find[1] and tbl.replace[1] then
				textcode = string.Replace(textcode, tbl.find[1], tbl.replace[1])
			end
			if tbl.find[2] and tbl.replace[2] then
				textcode = string.Replace(textcode, tbl.find[2], tbl.replace[2])
			end
		end
	end

	local laststart = 1
	while true do
		local i = string.find(textcode, "<span class%=%ppaper_field%p>", laststart) or 0

		if (i == 0) then
			break
		end

		laststart = i + 1
		paper.Fields = paper.Fields + 1
	end

	return textcode
end

function bureaucracy:AddToFields(paper, id, text, links)
	local locid = 0
	local laststart = 1
	local textindex = 1

	while true do
		local istart = 0
		istart = string.find(links and paper.HTMLText or paper.Text, "<span class%=%ppaper_field%p>", laststart)
		
		if (istart == 0) then
			return
		end

		laststart = istart + 1
		locid = locid + 1

		if (locid == id) then
			local iend = 1
			iend = string.find(links and paper.HTMLText or paper.Text, "<%/span>", istart)

			textindex = iend 
			break
		end
	end

	local before = string.sub(links and paper.HTMLText or paper.Text, 1, textindex - 1)
	local after = string.sub(links and paper.HTMLText or paper.Text, textindex)

	if links then
		paper.HTMLText = before .. text .. after
	else
		paper.Text = before .. text .. after
		bureaucracy:UpdateInfoLinks(paper)
	end
end

function bureaucracy:UpdateInfoLinks(paper)
	paper.HTMLText = paper.Text

	for i = 1, paper.Fields do
		self:AddToFields(paper, i, "<font face=\"sans-serif\"><a href=\"#\" onclick=\"gmodinterface.Write("..i.."); return false;\">написать</a></font>", true)
	end

--	paper.HTMLText = paper.HTMLText .. "<br><font face=\"sans-serif\"><a href=\"#\" onclick=\"gmodinterface.Write('END'); return false;\">написать</a></font>"
end

function bureaucracy:UpdateSpace(paper, htmlText)
	if htmlText then
		local text = htmlText
		//text = string.gsub(text,"<.*>(.*)<%/.*>","%1")

		paper.Freespace = paper.Freespace - #text
	end
end

Clockwork.datastream:Hook("bb_SendWrite", function(client, data)
	local editData = data[1]
	local title = data[2]
	local pickup = data[3]

	if !client.bb_writing_itemid then return end
	local item = Clockwork.item:FindInstance(client.bb_writing_itemid)

	if !item then return end
	if !item:GetData("CanWrite") then return end
	if !bureaucracy:CanPlayerEdit(client.bb_writing_itemid, client) then return end

	item:SetData("CanWrite", false)
	item:SetData("CanPickup", !pickup)
	item:SetData("PaperTitle", title)

	local paperData = {}
	paperData.ItemID = client.bb_writing_itemid
	paperData.Writer = client:SteamID()
	paperData.Fields = 0
	paperData.Freespace = MAX_PAPER_CHARACTERS
	paperData.Text = ""	
	paperData.HTMLText = ""

	if item.PaperObjectData then
		paperData = item.PaperObjectData
	end

	if paperData.Freespace <= 0 then
		Clockwork.datastream:Start(client, "bb_Error", BB_ERROR_SPACE)
		return
	end

	local lastFields = paperData.Fields
	editData = bureaucracy:Parse(client, paperData, editData)

	if paperData.Fields > 50 then
		Clockwork.datastream:Start(client, "bb_Error", BB_ERROR_FIELDS)
		paperData.Fields = lastFields
		return
	end

	paperData.Text = paperData.Text .. editData
	bureaucracy:UpdateInfoLinks(paperData)
	bureaucracy:UpdateSpace(paperData, editData)

	item.PaperObjectData = paperData
	client.bb_writing_itemid = nil
end)
Clockwork.datastream:Hook("bb_SendEdit", function(client, data)
	local id = data[1]
	local text = data[2]

	if !client.bb_writing_itemid then return end
	local item = Clockwork.item:FindInstance(client.bb_writing_itemid)

	if !item then return end
	if item:GetData("CanWrite") then return end
	if !item.PaperObjectData then return end

	local paperData = item.PaperObjectData

	if paperData.Freespace <= 0 then
		Clockwork.datastream:Start(client, "bb_Error", BB_ERROR_SPACE)
		return
	end

	local lastFields = paperData.Fields
	text = bureaucracy:Parse(client, paperData, text)

	if paperData.Fields > 50 then
		Clockwork.datastream:Start(client, "bb_Error", BB_ERROR_FIELDS)
		paperData.Fields = lastFields
		return
	end

	if id != "END" then
		bureaucracy:AddToFields(paperData, tonumber(id), text)
	else
--		paperData.Text = paperData.Text .. text
--		bureaucracy:UpdateInfoLinks(paperData)
	end

	bureaucracy:UpdateSpace(paperData, text)

	item.PaperObjectData = paperData

	local updatePlayers = {}
	for k, v in pairs(player.GetAll()) do
		if v.bb_writing_itemid == client.bb_writing_itemid then
			table.insert(updatePlayers, v)
		end
	end

	Clockwork.datastream:Start(updatePlayers, "bb_Update", paperData.HTMLText)
end)
Clockwork.datastream:Hook("bb_Closed", function(client)
	if !client.bb_writing_itemid then return end
	client.bb_writing_itemid = nil
end)
