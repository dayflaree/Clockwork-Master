--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Bottle";
ITEM.value = 0.10;
ITEM.cost = 8;
ITEM.model = "models/props_junk/garbage_glassbottle002a.mdl";
ITEM.weight = 0.5;
ITEM.access = "j";
ITEM.category = "Junk";
ITEM.business = true;
ITEM.description = "An empty bottle.";

function ITEM:OnDrop(player, position) end;

ITEM:Register();