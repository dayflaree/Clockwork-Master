--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Hammer";
ITEM.model = "models/weapons/w_sledgehammer.mdl";
ITEM.weight = 2.5;
ITEM.category = "Junk";
ITEM.business = false;
ITEM.description = "A metal hammer.";

function ITEM:OnDrop(player, position) end;

ITEM:Register();