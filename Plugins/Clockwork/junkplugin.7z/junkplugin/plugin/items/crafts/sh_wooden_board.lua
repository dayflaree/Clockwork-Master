--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Wooden Board";
ITEM.value = 0.10;
ITEM.model = "models/props_debris/wood_board06a.mdl";
ITEM.weight = 1;
ITEM.category = "Junk";
ITEM.business = false;
ITEM.description = "A wooden board.";

function ITEM:OnDrop(player, position) end;

ITEM:Register();