--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Piece of Metal";
ITEM.value = 0.10;
ITEM.model = "models/gibs/metal_gib2.mdl";
ITEM.weight = 1;
ITEM.category = "Junk";
ITEM.business = false;
ITEM.description = "A small piece of metal.";

function ITEM:OnDrop(player, position) end;

ITEM:Register();