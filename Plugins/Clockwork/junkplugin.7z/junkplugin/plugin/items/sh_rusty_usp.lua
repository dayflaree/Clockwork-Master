--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Rusty USP";
ITEM.value = 0.01;
ITEM.cost = 8;
ITEM.model = "models/Weapons/W_pistol.mdl";
ITEM.weight = 0.5;
ITEM.access = "J";
ITEM.category = "Junk";
ITEM.business = true;
ITEM.description = "A rusted Heckler and Koch USP-Match.";

function ITEM:OnDrop(player, position) end;

ITEM:Register();