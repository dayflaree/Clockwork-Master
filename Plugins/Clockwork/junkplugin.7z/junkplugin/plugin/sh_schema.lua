local PLUGIN = PLUGIN;

Clockwork.flag:Add("j", "Light Junk", "Access to light junk goods.");
Clockwork.flag:Add("J", "Heavy Junk", "Access to heavy junk goods.");