local PLUGIN = PLUGIN;

Clockwork.config:Add("hide_business", false, true);