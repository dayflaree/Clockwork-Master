--[[
Name: "sh_info.lua".
Product: "OpenAura".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Fun Cmds";
PLUGIN.author = "Snazzy.";
PLUGIN.description = "Allows ravetime, faggot alerter etc.";