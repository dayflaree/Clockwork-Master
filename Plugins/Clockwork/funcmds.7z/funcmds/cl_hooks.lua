--[[
Name: "cl_hooks.lua".
Product: "OpenAura".
--]]

local PLUGIN = PLUGIN;