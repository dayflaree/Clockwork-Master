--[[
Name: "sh_info.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Storage";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds containers where players can store items.";