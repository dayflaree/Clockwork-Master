local PLUGIN = PLUGIN;

if (SERVER) then
	function Clockwork:PlayerCanGiveToStorage(player, storageTable, itemTable)
		itemTable.cwPropertyTab = itemTable.cwPropertyTab or {}
		itemTable.cwPropertyTab.key = player:GetCharacterKey()
		itemTable.cwPropertyTab.uniqueID = player:UniqueID()
		return true
	end

	function Clockwork:PlayerCanTakeFromStorage(player, storageTable, itemTable)
		if itemTable.cwPropertyTab then
			if self.entity:BelongsToAnotherCharacter(player, itemTable) then
				self.player:Notify(player, "You cannot take an item you have stored on another character!")
				self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has attempted to take an item stored by another character (item swap).")

				return false
			else
				itemTable.cwPropertyTab = nil
			end
		end

		return true
	end
end