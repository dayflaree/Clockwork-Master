function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("JPDisable", true)
end