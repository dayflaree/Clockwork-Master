function PLUGIN:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	local curTime = CurTime();
	local dicerole = math.random(1, 10)
	if player.cwIsJetpacking then
		if dicerole >= 5 then
			if attacker:IsPlayer() then
			attacker:Notify("You've disabled your targets jetpack for 10 seconds.")
		else
			print("NPC")
			end
			nxtjp = curTime + 10
			if !timer.Exists("JP"..player:SteamID()) then
			player:Notify("Your jetpack has been shot disabled! You can't fly for 10 seconds.")
			Schema:SpawnTearGas(player:GetPos())
			player:SetSharedVar("JPDisable", true)
			player.wasJetpacking = false
			timer.Create("JP"..player:SteamID(), 10, 1, function()
				player:SetSharedVar("JPDisable", false)
				end)
			end
		end
	end
end


--I unfortunately had to override the schema move function for this to work, if you're reading this and have any insights on to how I can do it without, let me know.
function PhaseFour:Move(player, moveData)
	local isJetpacking = false;
	local isOnGround = player:IsOnGround() or (player:GetGroundEntity() == game.GetWorld());
	local clothesItem = player:GetClothesItem();
	local curTime = CurTime();

	if (player:Alive() and !player:IsRagdolled() and clothesItem
	and player:GetCharacterData("fuel") > 5) and player:GetSharedVar("JPDisable") == false then
		if (clothesItem("hasJetpack")) then
			local currentVelocity = moveData:GetVelocity();
			local isHoldingSprint = player:KeyDown(IN_SPEED);
			local isHoldingJump = player:KeyDown(IN_JUMP);
			
			if (isHoldingJump and isHoldingSprint) then
				local speed = Clockwork.attributes:Fraction(player, ATB_AERODYNAMICS, 256, 128);
				
				if (!isOnGround) then
					moveData:SetVelocity(player:GetAimVector() * (384 + speed));
					player.wasJetpacking = true;
					
					if (!player.cwNextUpdateAero or curTime >= player.cwNextUpdateAero) then
						player.cwNextUpdateAero = curTime + 1;
						player:ProgressAttribute(ATB_AERODYNAMICS, 0.5, true);
					end;
					
					isJetpacking = true;
				end;
			elseif (isHoldingJump and player.wasJetpacking) then
				if (!isOnGround) then
					moveData:SetVelocity(Vector(currentVelocity.x, currentVelocity.y, 0));
					isJetpacking = true;
				end;
			end;
		end;
	end;
	
	player.cwIsJetpacking = isJetpacking;
	player:SetSharedVar("jetpack", player.cwIsJetpacking);
	
	if (isOnGround) then
		player.wasJetpacking = false;
	end;
end;
