local PLUGIN = PLUGIN;

-- Called when a player attempts to use a tool.
function PLUGIN:CanTool(player, trace, tool) 		
	if (Clockwork.blacklist:IsBlacklisted(tool) and !player:IsAdmin() and !player:IsUserGroup("operator")) then
		player:Notify("Sorry! You must at least be an operator to use that tool!")
		return false;
	end;
end;