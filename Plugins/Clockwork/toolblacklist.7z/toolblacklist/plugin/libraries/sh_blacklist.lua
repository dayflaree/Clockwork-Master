local Clockwork = Clockwork;

Clockwork.blacklist = Clockwork.kernel:NewLibrary("Blacklist");
Clockwork.blacklist.stored = {};

-- A function to blacklist a tool.
function Clockwork.blacklist:Add(tool)
	if (type(tool) != "string") then return end;
	
	self.stored[#self.stored + 1] = string.lower(tool);
end;

-- A function to check if a tool is blacklisted.
function Clockwork.blacklist:IsBlacklisted(tool)
	return table.HasValue(self.stored, string.lower(tool));
end;

Clockwork.blacklist:Add("dynamite");
Clockwork.blacklist:Add("thruster");
Clockwork.blacklist:Add("balloons");
Clockwork.blacklist:Add("gmod_balloon");
Clockwork.blacklist:Add("balloon");
Clockwork.blacklist:Add("turret");
Clockwork.blacklist:Add("rtcamera");
Clockwork.blacklist:Add("wheel");
Clockwork.blacklist:Add("#tool.env_headcrabcanister");
Clockwork.blacklist:Add("env_headcrabcanister");
Clockwork.blacklist:Add("Headcrab Canister");
Clockwork.blacklist:Add("headcrabcanister");
Clockwork.blacklist:Add("#tool.item_ammo_crate");
Clockwork.blacklist:Add("Constraints");
Clockwork.blacklist:Add("#tool.item_item_crate");
Clockwork.blacklist:Add("#tool.prop_door");
Clockwork.blacklist:Add("#tool.prop_thumper");
Clockwork.blacklist:Add("paint");
Clockwork.blacklist:Add("Witcher Gates");
Clockwork.blacklist:Add("witchergate");
Clockwork.blacklist:Add("npctool_notarget");
Clockwork.blacklist:Add("npctool_spawner");
Clockwork.blacklist:Add("npctool_health");
Clockwork.blacklist:Add("npctool_controller");
Clockwork.blacklist:Add("npctool_relationships");
Clockwork.blacklist:Add("advanced_duplicator");

Clockwork.blacklist:Add("ladder");