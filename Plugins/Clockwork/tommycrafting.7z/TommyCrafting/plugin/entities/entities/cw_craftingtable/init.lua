AddCSLuaFile("shared.lua");
AddCSLuaFile("cl_init.lua");

include("shared.lua");

local dissolver;

function ENT:Initialize()
	self:SetModel("models/props_wasteland/kitchen_counter001d.mdl");
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetMoveType(MOVETYPE_VPHYSICS);

	self:SetSolid(SOLID_VPHYSICS);
    self:SetUseType(SIMPLE_USE)
end;

function ENT:SpawnFunction(player, trace)
    if (!trace.Hit) then return; end;

    local entity = ents.Create("cw_craftingtable");
    entity:Spawn();
    entity:Activate();
    entity:SetPos( trace.HitPos + trace.HitNormal * 32 + Vector(0, 0, 53) );
    entity:SetAngles( Angle(180, 0, 90) );

    return entity;
end;