local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_pistolammo';
MIXTURE.Name = '9mm Pistol Bullets';
MIXTURE.Requires = {["Metal Piece"] = 2, ["Plastic Piece"] = 1};
MIXTURE.Produces = '9mm Pistol Bullets';
MIXTURE.Produces_Text = 'A container filled with bullets and 9mm printed on the side.';
MIXTURE.RequiredEntity = "Forge"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);