local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_fixpistol';
MIXTURE.Name = 'Pistol';
MIXTURE.Requires = {["Rusty Pistol"] = 1, ["Weapon Repair Kit"] = 1, ["Electrical Parts"] = 1};
MIXTURE.Produces = 'USP Pistol';
MIXTURE.Produces_Text = 'A basic pistol crafted finely, a very nice item.';
MIXTURE.RequiredEntity = "Crafting Table"

MIXTURE.HasFlags = "j"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);