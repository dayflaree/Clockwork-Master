local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_notepad';
MIXTURE.Name = 'Notepad';
MIXTURE.Requires = {["Paper"] = 1, ["Wood Board"] = 1};
MIXTURE.Produces = 'Notepad';
MIXTURE.Produces_Text = 'A new notepad, made from scratch.';


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);