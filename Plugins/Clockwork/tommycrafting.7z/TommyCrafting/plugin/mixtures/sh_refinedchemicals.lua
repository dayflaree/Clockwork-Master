local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_refinedchemicals';
MIXTURE.Name = 'Refined Chemicals';
MIXTURE.Requires = {["Dangerous Chemicals"] = 1, ["Electrical Parts"] = 1, ["Gas Can"] = 1};
MIXTURE.Produces = 'Refined Chemicals';
MIXTURE.Produces_Text = 'Refined Chemicals, in a stable state.';
MIXTURE.RequiredEntity = "Forge"

MIXTURE.HasFlags = "J"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);