local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_bandage';
MIXTURE.Name = 'Bandage';
MIXTURE.Requires = {["Cloth Piece"] = 2};
MIXTURE.Produces = 'Bandage';
MIXTURE.Produces_Text = 'A bandage fasioned out of a peice of cloth.';


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);