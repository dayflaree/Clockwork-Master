local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_biolock';
MIXTURE.Name = 'Biolock';
MIXTURE.Requires = {["Electrical Parts"] = 3, ["Metal Piece"] = 2};
MIXTURE.Produces = 'Biolock';
MIXTURE.Produces_Text = 'A biolocked to lock the weapon for MPF use.';
MIXTURE.RequiredEntity = "Crafting Table"

MIXTURE.HasFlags = "j"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);