local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_ziptie';
MIXTURE.Name = 'Zip Tie';
MIXTURE.Requires = {["Plastic Piece"] = 3};
MIXTURE.Produces = 'Zip Tie';
MIXTURE.Produces_Text = 'A man made plastic zip-tie.';
MIXTURE.RequiredEntity = "Forge"


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);