local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_chloroform';
MIXTURE.Name = 'Chloroform';
MIXTURE.Requires = {["Refined Chemicals"] = 1, ["Plastic Piece"] = 1};
MIXTURE.Produces = 'Chloroform';
MIXTURE.Produces_Text = 'A bottle of chloroform.';


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);