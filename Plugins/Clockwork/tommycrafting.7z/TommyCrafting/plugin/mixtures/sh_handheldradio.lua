local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_handradio';
MIXTURE.Name = 'Handheld Radio';
MIXTURE.Requires = {["Electrical Parts"] = 2, ["Metal Piece"] = 2};
MIXTURE.Produces = 'Handheld Radio';
MIXTURE.Produces_Text = 'A handheld radio with a frequency tuner';
MIXTURE.RequiredEntity = "Crafting Table"


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);