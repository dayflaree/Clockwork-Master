--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Pistol-X";
	ITEM.cost = 100;
	ITEM.model = "models/kf2_weps_3p/wep_m_pistol/kf2_m_pistol.mdl";
	ITEM.weight = 3.5;
	ITEM.access = "V";
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.uniqueID = "kf2_m_pist";
	ITEM.spawnValue = 1;
	ITEM.spawnType = "misc";
	ITEM.description = "A small, grey-white pistol with a experimental sight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.isAlwaysRaised = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();