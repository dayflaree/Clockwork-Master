--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "AA-12";
	ITEM.cost = 300;
	ITEM.model = "models/kf2_weps_3p/wep_aa12/kf2_aa12.mdl";
	ITEM.weight = 6;
	ITEM.classes = {CLASS_EOW};
	ITEM.uniqueID = "kf2_aa12";
	ITEM.business = true;
	ITEM.spawnValue = 2;
	ITEM.spawnType = "misc";
	ITEM.description = "A drum shotgun.";
	ITEM.isAttachment = true;
	ITEM.isAlwaysRaised = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-4, 4, 4);
ITEM:Register();