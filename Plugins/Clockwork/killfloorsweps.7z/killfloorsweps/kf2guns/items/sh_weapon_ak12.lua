--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "AK-12";
	ITEM.cost = 200;
	ITEM.model = "models/kf2_weps_3p/wep_ak12/kf2_ak12.mdl";
	ITEM.weight = 3;
	ITEM.access = "V";
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.uniqueID = "kf2_ak12";
	ITEM.spawnValue = 1;
	ITEM.spawnType = "misc";
	ITEM.description = "An assault rifle weapon coated in black, it has a convenient handle, and sight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.isAlwaysRaised = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();