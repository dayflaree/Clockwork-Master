--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "SCAR-H";
	ITEM.cost = 200;
	ITEM.model = "models/kf2_weps_3p/wep_scarh/kf2_scarh.mdl";
	ITEM.weight = 3;
	ITEM.access = "V";
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.uniqueID = "kf2_scarh";
	ITEM.spawnValue = 1;
	ITEM.spawnType = "misc";
	ITEM.description = "A compact weapon coated in tan, it has a convenient handle, and scope.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.isAlwaysRaised = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();