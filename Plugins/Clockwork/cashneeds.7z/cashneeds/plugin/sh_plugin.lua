local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("sh_hunger", NWTYPE_NUMBER, true);
	playerVars:Number("sh_thirst", NWTYPE_NUMBER, true);
end

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");