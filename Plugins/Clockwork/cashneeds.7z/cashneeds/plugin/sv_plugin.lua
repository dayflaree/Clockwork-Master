--[[
	Name: sv_auto.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;