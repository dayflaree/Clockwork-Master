--[[
	Name: sv_hooks.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	if ( player:Alive() ) then

		if ( player:GetCharacterData("hunger") <= 0 ) then
		
			if !player.nextHurty or curTime >= player.nextHurty then
				player:SetHealth(math.Clamp(player:Health() - 1.5, 0, 100));
				player.nextHurty = curTime + 2
				player:EmitSound("player/pl_pain"..math.random(5, 7)..".wav")
				if (player:Health() <= 0) then
					player:Kill();
				
				end;
			end;
		end;
		
		if ( player:GetCharacterData("thirst") <= 0 ) then
		
			if !player.nextHurty or curTime >= player.nextHurty then
				player:SetHealth(math.Clamp(player:Health() - 1.8, 0, 100));
				player.nextHurty = curTime + 2
				player:EmitSound("player/pl_pain"..math.random(5, 7)..".wav")
				if (player:Health() <= 0) then
					player:Kill();
				
				end;
			end;
		end;

		elseif(!player._nexthunger or player._nexthunger < CurTime())then
			player._nexthunger = CurTime() + 90;
			player:SetCharacterData("hunger", player:GetCharacterData("hunger") - 1);
		
		elseif(!player._nextthirst or player._nextthirst < CurTime())then
			player._nextthirst = CurTime() + 90;
			player:SetCharacterData("thirst", player:GetCharacterData("thirst") - 1);
		
		end;
		
		if (!player:IsNoClipping() and player:IsOnGround() and (infoTable.isRunning or infoTable.isJogging)) then
			player:SetCharacterData("hunger", player:GetCharacterData("hunger") - 0.025);

		end
		
		if (!player:IsNoClipping() and player:IsOnGround() and (infoTable.isRunning or infoTable.isJogging)) then
			player:SetCharacterData("thirst", player:GetCharacterData("thirst") - 0.05);

		end
	end;

-- Called when a player's character data should be saved.
function PLUGIN:PlayerSaveCharacterData(player, data)
	if ( data["hunger"] ) then
		data["hunger"] = math.Round( data["hunger"] );
	end;
	if ( data["thirst"] ) then
		data["thirst"] = math.Round( data["thirst"] );
	end;
end;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["hunger"] = data["hunger"] or 100;
	data["thirst"] = data["thirst"] or 100;
end;

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("hunger", 100);
		player:SetCharacterData("thirst", 100);
	end;
end;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "sh_hunger", math.Round( player:GetCharacterData("hunger") ) );
	player:SetSharedVar( "sh_thirst", math.Round( player:GetCharacterData("thirst") ) );
end