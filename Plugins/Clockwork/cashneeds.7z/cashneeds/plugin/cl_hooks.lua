--[[
	Name: cl_hooks.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

-- Called when the bars are needed.
function PLUGIN:GetBars(bars)
	local hunger = Clockwork.Client:GetSharedVar("sh_hunger");
	local thirst = Clockwork.Client:GetSharedVar("sh_thirst");
	
	if (!self.hunger) then
		self.hunger = thirst;
	else
		self.hunger = math.Approach(self.hunger, hunger, 1);
	end;
		
	if (!self.thirst) then
		self.thirst = thirst;
	else
		self.thirst = math.Approach(self.thirst, thirst, 1);
	end;
	if (self.hunger > 0) then
	bars:Add("HUNGER", Color(255, 225, 200, 255), "HUNGER", self.hunger, 100, self.hunger < 10);
	end;
	
	if (self.thirst > 0) then
	bars:Add("THIRST", Color(200, 225, 255, 255), "THIRST", self.thirst, 100, self.thirst < 10);
	end;
end;