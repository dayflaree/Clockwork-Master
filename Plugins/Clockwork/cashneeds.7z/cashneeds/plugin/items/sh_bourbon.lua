--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Bourbon";
ITEM.cost = 0;
ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl";
ITEM.weight = 1.2;
ITEM.useText = "Drink";
ITEM.category = "Alcohol";
ITEM.description = "A rather large bottle with a the damp label 'Bourbon'.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (Clockwork.player:GetAction(player) != "die") then
		player:SetCharacterData( "thirst", math.Clamp(player:GetCharacterData("thirst") + 25, 0, 100) );
	end;
end;

function ITEM:OnUse(player, itemEntity)
	player:SetSharedVar("antidepressants", CurTime() + 600);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();