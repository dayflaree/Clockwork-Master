local ITEM = Clockwork.item:New();
ITEM.name = "Bobby Pin";
ITEM.cost = 25;
ITEM.category = "Tools";
ITEM.batch = 1;
ITEM.model = "models/Gibs/wood_gib01c.mdl";
ITEM.weight = .5;
ITEM.access = "v";
ITEM.uniqueID = "b_pin";
ITEM.business = true;
ITEM.description = "An old bobby pin.. Maybe it could fit into a lock?";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();