local PLUGIN = PLUGIN;
local math = math;
 
local randomSounds = {
    "ambient/alarms/train_horn_distant1.wav",
    "ambient/atmosphere/city_skypass1.wav",
    "ambient/atmosphere/city_truckpass1.wav",
    "ambient/creatures/flies1.wav",
    "ambient/creatures/rats1.wav",
    "ambient/creatures/rats2.wav",
    "ambient/levels/streetwar/gunship_distant1.wav",
    "ambient/levels/streetwar/gunship_distant2.wav",
    "ambient/levels/streetwar/heli_distant1.wav",
    "ambient/levels/streetwar/strider_distant1.wav",
    "ambient/machines/heli_pass1.wav",
    "ambient/machines/heli_pass2.wav",
    "ambient/machines/heli_pass_distant1.wav",
    "ambient/machines/heli_pass_quick1.wav",
    "ambient/machines/heli_pass_quick2.wav",
    "ambient/machines/train_rumble.wav",
    "ambient/machines/truck_pass_distant1.wav",
    "ambient/machines/truck_pass_distant2.wav",
    "ambient/machines/truck_pass_distant3.wav",
    "ambient/machines/truck_pass_overhead1.wav",
    "ambient/materials/creak5.wav",
    "npc/metropolice/vo/localcptreportstatus.wav",
    "npc/metropolice/vo/loyaltycheckfailure.wav",
    "npc/metropolice/vo/malcompliant10107my1020.wav",
    "npc/metropolice/vo/movingtohardpoint.wav",
    "npc/metropolice/vo/positiontocontain.wav",
    "npc/metropolice/vo/possible10-103alerttagunits.wav",
    "npc/metropolice/vo/possible404here.wav",
    "npc/metropolice/vo/possible647erequestairwatch.wav"
};
 
-- A function to emit a random sound
function PLUGIN:EmitRandomChatter(player)
    --[[
   
    -- Alternative sound emitter. Lowers the emitter's receiving sound but doesn't follow the player.
    for k,v in ipairs( _player.GetAll() ) do
        if (Schema:PlayerIsCombine(v)) then
            local pos = v:GetBonePosition(10)
            sound.Play( randomSounds[ math.random(1, #randomSounds) ], pos, 300, 100, 0.4 )
        end;
    end;
    ]]--

  
        pitch = math.random(95,105)
        volume = math.random(0.1,1)
   
    local randomSound = randomSounds[math.random(1, #randomSounds)];
    player:EmitSound(randomSound, 65, pitch, volume);
end;
 
function PLUGIN:PlayerThink(player, curTime)
    if ((player.nextChatterEmit or 0) < curTime) then
        if (player:GetFaction() == FACTION_CITIZEN and !player:IsNoClipping() and player:Alive()) then
            player.nextChatterEmit = curTime + math.random(10, 60);
            PLUGIN:EmitRandomChatter(player);
        else
            player.nextChatterEmit = curTime + 90;
        end;
    end;
end;