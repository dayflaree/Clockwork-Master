--[[
Name: "sh_info.lua".
Product: "Novus Two".
--]]

local MOUNT = MOUNT;

MOUNT.name = "Vehicles";
MOUNT.author = "kuropixel";
MOUNT.description = "Adds faction vehicles to the schema.";