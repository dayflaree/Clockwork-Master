--[[
	Originally made by SlideFuse
	Re-Writen and ported by TheGarry =D
--]]

PLUGIN = PLUGIN


function PLUGIN:PlayerDeath(player, inflictor, attacker, damageInfo)

	local ragdoll = player:GetRagdollEntity()
	if (IsValid(ragdoll)) then
		local playerInv = player:GetInventory()
		local corpseInv = {}
		ragdoll.inventory = {}
		ragdoll.cash = player:GetCash()
		
		for k, v in pairs(playerInv) do
			local itemTable = Clockwork.item:CreateInstance(v.item, v.itemID, v.data)
			if (itemTable) then
				if (player:UpdateInventory(k, -v, true, true)) then
					ragdoll.inventory[k] = v
				end;
			end;
		end;
		
		player:SetCharacterData("cash", 0, true);
		player:SaveCharacter();
	end
end


function PLUGIN:EntityHandleMenuOption(player, entity, option, arguments)
	if (entity:GetClass() == "prop_ragdoll" and arguments == "cw_loot") then
		if (!entity.inventory or !entity.cash) then
			return
		end
		player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
		
	    Clockwork.storage:Open(player, {
	    	name = 'Dead Corpse',
		    weight = 24,
		    entity = entity,
		    distance = 192,
	    	cash = cash,
	    	inventory = inventory,
	    	OnGiveCash = function(player, storageTable, cash)
	    		storageTable.entity.cwCash = storageTable.cash;
	    	end,
	    	OnTakeCash = function(player, storageTable, cash)
		    	storageTable.entity.cwCash = storageTable.cash;
		    end
	    });
	end
end