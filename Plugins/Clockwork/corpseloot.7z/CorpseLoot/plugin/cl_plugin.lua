--[[
	Originally made by SlideFuse
	Re-Writen and ported by TheGarry =D
--]]

PLUGIN = PLUGIN

function PLUGIN:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "prop_ragdoll") then
		options["Loot"] = "cw_loot";
	end
end