local PLUGIN = PLUGIN;

function PLUGIN:PlayerAdjustHeadbobInfo(info)
    if (input.IsMouseDown( MOUSE_RIGHT ) && Clockwork.player:GetWeaponRaised(LocalPlayer())) then
        info.speed = 0
        info.yaw = 0
        info.roll = 0
    end
end;