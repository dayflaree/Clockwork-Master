local PLUGIN = PLUGIN;

    -- Called when the chat box info should be adjusted.
    function PLUGIN:ChatBoxAdjustInfo(info)
            local speaker = info.speaker;
     
            if (info.class != "ooc" or !IsValid(info.speaker)) then return; end;
     
            if (speaker:IsSuperAdmin()) then
                    info.icon = "icon16/application_osx_terminal.png";
            elseif (speaker:IsAdmin()) then
                    info.icon = "icon16/wrench.png";
            elseif (speaker:IsUserGroup("operator")) then
                    info.icon = "icon16/wrench_orange.png";
            end;
    end;