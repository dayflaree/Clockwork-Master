local PLUGIN = PLUGIN;

-- Called when a player attempts to earn wages cash.
function PLUGIN:PlayerCanEarnWagesCash(player, cash)
	if (player:GetCash() >= 750 and Schema:PlayerIsCombine(player)) then
		return false;
	end;
end;

/*
-- Called when a player's cash has been updated.
function PLUGIN:PlayerCashUpdated(player, amount, reason, bNoMsg)
	if (player:GetCash() + amount > 750 and Schema:PlayerIsCombine(player)) then
		Clockwork.player:GiveCash(player, -player:GetCash() + 750, nil, true);
	end;
end;*/

-- Called when a player attempts to earn wages cash.
function PLUGIN:PlayerCanEarnWagesCash(player, cash)
	if (player:GetCash() >= 750 and player:GetFaction() == FACTION_CONSCRIPTS) then
		return false;
	end;
end;

/*
-- Called when a player's cash has been updated.
function PLUGIN:PlayerCashUpdated(player, amount, reason, bNoMsg)
	if (player:GetCash() + amount > 750 and player:GetFaction() == FACTION_CONSCRIPTS) then
		Clockwork.player:GiveCash(player, -player:GetCash() + 750, nil, true);
	end;
end;*/