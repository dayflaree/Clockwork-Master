--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	PLUGIN.builderPanel = self
	self:SetTitle("Timeline")

	self:SetSize(ScrW(), ScrH()/3)
	self:SetPos(0, ScrH()-ScrH()/3)

	self:MakePopup()
	
	self.tree = vgui.Create("DTree", self)
	self.tree:SetSize(320, self:GetTall()-24)
	self.tree:SetPos(0, 24)

	Clockwork.datastream:Start("sfRequestBones", true)
end;

function PANEL:SetupBoneTree()
	self.tree:Clear()
	self.tree.panels = {}

	for k, v in pairs(PLUGIN:GetBones()) do
		self.tree:AddNode(LocalPlayer():GetBoneName(v))
	end
end

vgui.Register("sfAnimBuilder", PANEL, "DFrame");

Clockwork.datastream:Hook("sfSendBones", function(data)
	PLUGIN.playerBones = data
	PLUGIN.builderPanel:SetupBoneTree()
end)

