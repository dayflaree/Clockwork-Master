--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

Clockwork.datastream:Hook("sfAnim_BuildStart", function(data)
	print("[SF] Starting Animation Builder")
	PLUGIN.building = true
	PLUGIN.buildPanel = vgui.Create("sfAnimBuilder")
end)

function PLUGIN:GetBones()
	local player = LocalPlayer()
	local boneTable = {}
	for i = 0, player:GetBoneCount()-1 do
		local name = player:GetBoneName(i)
		//if (player:GetBoneParent(i) <= 0) then continue end
		if (!player:BoneHasFlag(i, BONE_USED_BY_VERTEX_LOD0)) then continue end
		if (string.find(player:GetBoneName(i), "Finger")) then continue end
		table.insert(boneTable, i)
	end
	return boneTable
end