--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Red Dot";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This plugin will show a red dot at your viewpoint at close ranges. Helpful for picking up objects if the crosshair is off";