local COMMAND = Clockwork.command:New("KickDoor");
COMMAND.tip = "Attempt to kick in the door you are looking at.";
COMMAND.flags = CMD_DEFAULT;

	local blockedDoors = {
		
		[ "rp_city45_2013" ] = {
			
			438,
			439,
			440,
			441,
			1493,
			1494,
			1308,
			1309,
			1321,
			1322,
			1499,
			1500,
			
		}
		
	}
	
	local whitelist = {
		
		"Metropolice Force",
		"Overwatch Transhuman Arm"
	
	}
	
	function COMMAND:OnRun( pl )
		
		if not table.HasValue( whitelist, pl:GetFaction() ) then
			
			Clockwork.player:Notify( pl, "You are too weak to kick this door in!" );
			return
			
		end
		
		if not pl._isKickingDoor then
			
			local ent = pl:GetEyeTraceNoCursor().Entity
			if IsValid( ent ) and ent:GetClass() == "prop_door_rotating" then
			
				local dist = ent:GetPos():Distance( pl:GetPos() )
				if dist > 45 and dist < 80 then
					
					local blocked = blockedDoors[ game.GetMap() ]
					if not blocked or not table.HasValue( blocked, ent:EntIndex() ) then
					
						umsg.Start( "door_kick" )
						umsg.Entity( pl )
						umsg.Entity( ent )
						umsg.Angle( pl:GetAngles() )
						umsg.End()
						
						pl:Freeze( true )
						pl._isKickingDoor = true
						
						timer.Simple( 0.5, function()
				
							if IsValid( ent ) then
								
								if math.random( 1, 4 ) == 1 then
								
									local door = ents.Create( "prop_physics" )
									door:SetPos( ent:GetPos() )
									door:SetAngles( ent:GetAngles() )
									door:SetModel( ent:GetModel() )
									door:SetSkin( ent:GetSkin() )
									door:Spawn()
									door:GetPhysicsObject():SetVelocity( ( door:GetPos() - pl:GetPos() ) * 8 )
									
									door:EmitSound( string.format( "physics/wood/wood_plank_break%d.wav", math.random( 1, 4 ) ) )
									
									ent:SetNoDraw( true )
									ent:SetNotSolid( true )
									
									timer.Simple( 30, function()
										
										if IsValid( ent ) then
										
											ent:SetNoDraw( false )
											ent:SetNotSolid( false )
										
										end
										
										if IsValid( door ) then door:Remove() end
										
									end )
								
								end
								
							end
							
							timer.Simple( 0.9, function() 
							
								if IsValid( pl ) then
							
									pl:Freeze( false ) 
									pl._isKickingDoor = false 
								
								end
								
							end )
							
						end )
					
					else
						
						Clockwork.player:Notify( pl, "This door can not be kicked in!" );
						
					end
				
				end
			
			end
		
		end
		
	end
	
COMMAND:Register();