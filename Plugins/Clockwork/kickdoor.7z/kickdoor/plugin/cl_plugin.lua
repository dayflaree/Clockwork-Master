local PLUGIN = PLUGIN;

local function ReceiveDoorKick( msg )
			
	local pl = msg:ReadEntity()
	local door = msg:ReadEntity()
	local ang = msg:ReadAngle()
	
	if IsValid( pl ) then
	
		if IsValid( pl._kickDoorAnimObj ) then pl._kickDoorAnimObj:Remove() end
		
		local animObj = ents.CreateClientProp()
		animObj:SetModel( pl:GetModel() )
		animObj:SetPos( pl:GetPos() )
		animObj:SetAngles( ang )
		animObj:Spawn()
		
		local sequence = animObj:LookupSequence( "adoorkick" )
		animObj:SetSequence( sequence )
		
		pl._kickDoorAnimObj = animObj
		pl._kickAnimStartTime = CurTime()
		
		pl:SetNoDraw( true )
		pl:DrawViewModel( false )
	
	end
	
end
usermessage.Hook( "door_kick", ReceiveDoorKick )

local function KickDoorAnimationUpdate()
	
	for _, pl in pairs( player.GetAll() ) do
		
		if IsValid( pl._kickDoorAnimObj ) then
			
			local deltaTime = CurTime() - pl._kickAnimStartTime
			if deltaTime < 1.4 then
			
				pl._kickDoorAnimObj:SetCycle( deltaTime / 3 )
			
			else
				
				pl:SetNoDraw( false )
				pl:DrawViewModel( true )
				pl._kickDoorAnimObj:Remove()
				
			end
			
		end
		
	end
	
end
hook.Add( "Think", "door_kick_animation", KickDoorAnimationUpdate )

-- To prevent the 'legs' to show up when you kick
local function DrawLocalPlayer()
	
	return IsValid( LocalPlayer()._kickDoorAnimObj )
	
end
hook.Add( "ShouldDrawLocalPlayer", "door_kick_localplayer", DrawLocalPlayer )

local function KickView( pl, pos, ang )
	
	if IsValid( pl._kickDoorAnimObj ) then
		
		local origin = pos + pl:GetAngles():Forward() * -64
		local angles = ( pos - origin ):Angle()
		
		local view = {
			
			[ "origin" ] = origin,
			[ "angles" ] = angles
			
		}
		
		return view
		
	end
	
end
hook.Add( "CalcView", "doorkick_view", KickView )