--[[
	Name: sh_coms.lua.
	Author: Euphe.
--]]
local PLUGIN = PLUGIN;


-- A command to call a character


COMMAND = openAura.command:New();
COMMAND.tip = "Call another character.";
COMMAND.text = "<string ID> <string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callid");
	
	if (playerCallerID and playerCallerID != "") then
		local eavesdroppers = {};
		local talkRadius = openAura.config:Get("talk_radius"):Get();
		local listeners = {};
		local position = player:GetShootPos();
		local callerID = string.gsub(arguments[1], "%s%p", "");
		local text = table.concat(arguments, " ", 2);
		
		if (playerCallerID != callerID) then
			for k, v in ipairs( _player.GetAll() ) do
				if ( v:HasInitialized() and v:Alive() ) then
					if (v:GetCharacterData("callid") == callerID) then
						listeners[#listeners + 1] = v;
					elseif (v:GetShootPos():Distance(position) <= talkRadius) then
						if (player != v) then
							eavesdroppers[#eavesdroppers + 1] = v;
						end;
					end;
				end;
			end;
			
			if (#listeners > 0) then
				listeners[#listeners + 1] = player;
				
				openAura.chatBox:Add( listeners, player, "call", text, {id = playerCallerID} );
			
				if (#eavesdroppers > 0) then
					openAura.chatBox:Add(eavesdroppers, player, "call_eavesdrop", text);
				end;
			else
				openAura.player:Notify(player, "The number you dialled could not be found!");
			end;
		else
			openAura.player:Notify(player, "You cannot call your own number!");
		end;
	else
		openAura.player:Notify(player, "You have not set a cell phone number!");
	end;
end;

openAura.command:Register(COMMAND, "Call");



-- A command to find out your number

COMMAND = openAura.command:New();
COMMAND.tip = "Find out your number.";
COMMAND.text = "<string ID> <string Text>";

function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callid");
		
		if playerCallerID then
			openAura.player:Notify(player, "Your cell phone number is ".. tostring(playerCallerID).."!");
		end	
end;

openAura.command:Register(COMMAND, "Number");

-- A command to reset your number.

COMMAND = openAura.command:New();
COMMAND.tip = "Reset your phone number.";
COMMAND.text = "<string ID> <string Text>";

function COMMAND:OnRun(player, arguments)
local callnumber = tostring(8) .. tostring(math.random(7,9)) .. tostring(math.random(6,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) 
		player:SetCharacterData("callid", tonumber(callnumber));
		openAura.player:Notify(player, "Your phone number is ".. player:GetCharacterData("callid")..", use the /number command if you forget it.");
end;

openAura.command:Register(COMMAND, "resetnumber");

-- 911

COMMAND = openAura.command:New();
COMMAND.tip = "Send a message out to all police.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callid");
	
	if (playerCallerID and playerCallerID != "") then
		local curTime = CurTime();
		
		if (!player.nextSend911 or curTime >= player.nextSend911) then
			local eavesdroppers = {};
			local talkRadius = openAura.config:Get("talk_radius"):Get();
			local listeners = {};
			local position = player:GetShootPos();
			
			for k, v in ipairs( _player.GetAll() ) do
				if (v:Team() == CLASS_POLICE or v:Team() == CLASS_MIL or v:Team() == CLASS_BLACK or player == v) then //nmodify what classes should get 911 messages
					listeners[#listeners + 1] = v;
				elseif (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			end;
			
			player.nextSend911 = curTime + 30;
			
			if (#listeners > 0) then
				openAura.player:Notify("The line is busy, or there is nobody to take the call!");
				
				openAura.chatBox:Add( listeners, player, "911", arguments[1], {id = playerCallerID} );
				
				if (#eavesdroppers > 0) then
					openAura.chatBox:Add( eavesdroppers, player, "911_eavesdrop", arguments[1] );
				end;
			end;
		else
			openAura.player:Notify(player, "You can not call 911 for another "..math.Round( math.ceil(player.nextSend911 - curTime) ).." second(s)!");
		end;
	else
		openAura.player:Notify(player, "You have not set a cell phone number!");
	end;
end;

openAura.command:Register(COMMAND, "911");


COMMAND = openAura.command:New();
COMMAND.tip = "Send a message out to all secretaries.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playerCallerID = player:GetCharacterData("callid");
	
	if (playerCallerID and playerCallerID != "") then
		local curTime = CurTime();
		
		if (!player.nextSend912 or curTime >= player.nextSend912) then
			local eavesdroppers = {};
			local talkRadius = openAura.config:Get("talk_radius"):Get();
			local listeners = {};
			local position = player:GetShootPos();
			
			for k, v in ipairs( _player.GetAll() ) do
				if (v:Team() == CLASS_SECRETARY or player == v) then
					listeners[#listeners + 1] = v;
				elseif (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			end;
			
			player.nextSend912 = curTime + 30;
			
			if (#listeners > 0) then
				openAura.player:Notify("The line is busy, or there is nobody to take the call!");
				
				openAura.chatBox:Add( listeners, player, "912", arguments[1], {id = playerCallerID} );
				
				if (#eavesdroppers > 0) then
					openAura.chatBox:Add( eavesdroppers, player, "912_eavesdrop", arguments[1] );
				end;
			end;
		else
			openAura.player:Notify(player, "You can not call 912 for another "..math.Round( math.ceil(player.nextSend912 - curTime) ).." second(s)!");
		end;
	else
		openAura.player:Notify(player, "You have not set a cell phone number!");
	end;
end;

openAura.command:Register(COMMAND, "912");

COMMAND = openAura.command:New();
COMMAND.tip = "Speak to other members of your class using a headset.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local eavesdroppers = {};
	local talkRadius = openAura.config:Get("talk_radius"):Get();
	local listeners = {};
	local position = player:GetShootPos();
	local class = openAura.class:Get( player:Team() );
	
	if (class and class.headsetGroup) then
		for k, v in ipairs( _player.GetAll() ) do
			local targetClass = openAura.class:Get( v:Team() );
			
			if (!targetClass or targetClass.headsetGroup != class.headsetGroup) then
				if (v:GetShootPos():Distance(position) <= talkRadius) then
					eavesdroppers[#eavesdroppers + 1] = v;
				end;
			else
				listeners[#listeners + 1] = v;
			end;
		end;
		
		if (#eavesdroppers > 0) then
			openAura.chatBox:Add( eavesdroppers, player, "headset_eavesdrop", arguments[1] );
		end;
		
		if (#listeners > 0) then
			openAura.chatBox:Add( listeners, player, "headset", arguments[1] );
		end;
	else
		openAura.player:Notify(player, "Your class does not have a headset!");
	end;
end;

openAura.command:Register(COMMAND, "Headset");