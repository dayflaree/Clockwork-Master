PLUGIN = PLUGIN


PLUGIN:SetGlobalAlias("spawnItem");
