ClockworkWebViewer
==================

A modern and simple web application for communities to allow their players to view and search characters
along with check bans and information


Edit, globalconfig.php for your database settings

New Features:

Admin Commands

Only Superadmins may edit things such as bans,players,characters.

Edit own characters

Only edit Physical Description.

