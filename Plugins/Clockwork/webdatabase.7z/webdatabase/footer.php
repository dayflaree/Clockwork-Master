      <div class="footer">
        <p><center>&copy; <?php echo "<a href='$website'>$site</a>" ?> | <a href="credits.php">Credits</a> | <a href="http://steampowered.com">Powered By Steam</a> </p></center>
      </div>