local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Coffee Pot";
	ITEM.worth = 7;
	ITEM.model = "models/clutter/coffeepot.mdl";
	ITEM.weight = 0.8
	ITEM.description = "A coffee pot! Now you finally can drink your favourite coffee";
ITEM:Register();