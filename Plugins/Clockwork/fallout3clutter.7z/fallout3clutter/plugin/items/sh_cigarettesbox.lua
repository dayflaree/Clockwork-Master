local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Cigarette pack";
	ITEM.worth = 4;
	ITEM.model = "models/clutter/cigarettepack.mdl";
	ITEM.weight = 0.1
	ITEM.description = "A small cigarette pack someone might want these";
ITEM:Register();