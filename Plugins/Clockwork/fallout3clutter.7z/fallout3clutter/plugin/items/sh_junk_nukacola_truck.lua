local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Nuka Cola Truck";
	ITEM.worth = 13;
	ITEM.model = "models/clutter/nukatruck.mdl";
	ITEM.weight = 1.2
	ITEM.description = "An Nuka Cola Truck! These are pretty rare and worth some caps for sure";
ITEM:Register();