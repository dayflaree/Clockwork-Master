local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Abraxo";
	ITEM.model = "models/clutter/abraxo.mdl";
	ITEM.plural = "Abraxos";
	ITEM.worth = 1;
	ITEM.weight = 0.1;
	ITEM.description = "Abraxo and your day is clean";
ITEM:Register();