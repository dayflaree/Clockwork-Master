local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Plate";
	ITEM.worth = 2;
	ITEM.model = "models/clutter/plate.mdl";
	ITEM.weight = 0.3
	ITEM.description = "A ceramic plate for food old food still sticks on it";
ITEM:Register();