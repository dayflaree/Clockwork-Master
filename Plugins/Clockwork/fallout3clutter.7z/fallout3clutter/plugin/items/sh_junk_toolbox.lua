local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Toolbox";
	ITEM.worth = 10;
	ITEM.model = "models/clutter/toolbox.mdl";
	ITEM.weight = 5
	ITEM.description = "A heavy toolbox filled with stuff";
ITEM:Register();