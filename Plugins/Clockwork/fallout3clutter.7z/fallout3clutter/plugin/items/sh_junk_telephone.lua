local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Broken Telephone";
	ITEM.worth = 3;
	ITEM.model = "models/clutter/telephone.mdl";
	ITEM.weight = 0.7
	ITEM.description = "An broken telephone probably not working";
ITEM:Register();