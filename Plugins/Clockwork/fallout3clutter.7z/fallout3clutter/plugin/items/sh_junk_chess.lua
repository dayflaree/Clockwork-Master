local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Chessboard";
	ITEM.worth = 7;
	ITEM.model = "models/clutter/chessboard.mdl";
	ITEM.weight = 0.7
	ITEM.description = "Its an old chessboard! If you know how to play you can play or simply sell it";
ITEM:Register();