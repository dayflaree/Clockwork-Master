local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Lawnmower";
	ITEM.worth = 15;
	ITEM.model = "models/clutter/lawnmower.mdl";
	ITEM.weight = 7
	ITEM.description = "Pretty heavy but full of iron and circuits i bet it sells good";
ITEM:Register();