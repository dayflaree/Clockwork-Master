local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Terpentine";
	ITEM.worth = 5;
	ITEM.model = "models/clutter/turpentine.mdl";
	ITEM.weight = 0.5
	ITEM.description = "Still smells and seems ok maybe you can sell it";
ITEM:Register();