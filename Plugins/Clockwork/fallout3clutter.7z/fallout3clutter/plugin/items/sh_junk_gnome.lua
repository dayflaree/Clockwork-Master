local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Gardengnome";
	ITEM.worth = 9;
	ITEM.model = "models/clutter/gardengnome.mdl";
	ITEM.weight = 2
	ITEM.description = "Its a gardengnome someone maybe wants this on his lawn";
ITEM:Register();