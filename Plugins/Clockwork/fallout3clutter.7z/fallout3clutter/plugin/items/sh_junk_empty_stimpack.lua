local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Empty Stimpack";
	ITEM.worth = 1;
	ITEM.model = "models/clutter/stimpack.mdl";
	ITEM.weight = 0.1
	ITEM.description = "An empty stimpack sadly not much worth";
ITEM:Register();