DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "RJ";
ENT.PrintName = "Safebox";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;