local PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("max_safebox_weight", "The maximum weight a player's safebox can hold.");