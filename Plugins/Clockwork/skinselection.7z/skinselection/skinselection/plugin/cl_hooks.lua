local PLUGIN = PLUGIN;

function PLUGIN:GetCustomCharacterOptions(character, options)
	local entity = ents.CreateClientProp("models/error.mdl");
		entity:SetAngles(Angle(0, 0, 0));
		entity:SetPos(Vector(0, 0, 0));
		entity:SetModel(character.model);
		entity:Spawn();
		entity:Activate();
	entity:PhysicsInit(SOLID_VPHYSICS);

	local skinCount = entity:SkinCount();

	entity:Remove();

	if (skinCount > 1) then
		options["Select Skin"] = {};

		for i = 1, skinCount do
			options["Select Skin"]["Skin "..i] = function()
				Clockwork.datastream:Start("SelectSkin", {character.characterID, i});
			end;
		end;
	end;
end;