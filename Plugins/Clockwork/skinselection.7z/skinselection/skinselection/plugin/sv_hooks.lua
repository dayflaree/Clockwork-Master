local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called just after a player has spawned.
function PLUGIN:PostPlayerSpawn(player)
	player:SetSkin(player:GetCharacterData("Skin") or 0);
end;

-- Called when a player's model should be set.
function PLUGIN:PlayerSetModel(player)
	player:SetCharacterData("Skin", 0);
end;

Clockwork.datastream:Hook("SelectSkin", function(player, data)
	local bSuccess, fault = Clockwork.player:UseCharacter(player, data[1]);
				
	if (!bSuccess) then
		return Clockwork.player:SetCreateFault(player, fault);
	end;

	player:SetSkin(data[2]);
	player:SetCharacterData("Skin", data[2]);
	player:Notify("Skin "..data[2].." is now your default skin.");
end);