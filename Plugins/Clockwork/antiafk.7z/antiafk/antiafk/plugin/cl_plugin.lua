local Clockwork = Clockwork;
Clockwork.config:AddToSystem("AFK Time", "afk_time", "The amount of seconds it takes for someone to be flagged as AFK.", 1, 300, 0);