local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:Add("afk_time", 900);

local afkTime = Clockwork.config:Get("afk_time")

function PLUGIN:PlayerThink(player, curTime)
	local aimVector = tostring(player:GetAimVector());
	local posVector = tostring(player:GetPos());

	if (!player.nextCheckAFK or
		(player.lastAimVector != aimVector and player.lastPos != posVector)) then
		player.nextCheckAFK = curTime + afkTime:Get();
		player.lastAimVector = aimVector;
		player.lastPosVector = posVector;
	end;
	
	if (curTime >= player.nextCheckAFK and !player.isAFK) then
		player.isAFK = curTime;
		player:SetSharedVar("IsAFK", true);
	elseif (curTime < player.nextCheckAFK and player.isAFK) then
		player.isAFK = nil;
		player:SetSharedVar("IsAFK", false);
	end;
end;

--[[function PLUGIN:PlayerCanEarnWagesCash(player, cash)
	if (player.isAFK) then
		return false;
	end;
end;]]

function PLUGIN:DoPlayerNeeds(player)
	if (player.isAFK) then
		return false;
	end;
end;