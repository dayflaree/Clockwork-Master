local PLUGIN = PLUGIN;
function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("IsAFK");
end;