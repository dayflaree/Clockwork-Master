--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local PLUGIN = PLUGIN

function PLUGIN:Initialize()
    if (!file.Exists("gamemodes/cwhl2rp/plugins/crafting/plugin.ini", "MOD")) then
   	    ErrorNoHalt("[Crafting System] No file conflicts found! \n");
	else
	    ErrorNoHalt("[Crafting System] You have better crafting system installed! Remove this one! \n");
	end;
end;

--[[
There was supposed to be saving/loading code of Workbenches, but there's not :D
--]]

CloudAuthX.External("MFf2pzuZHY+b9Jhh8nUC43GTFUPqF2RDOxoPCfex/BAuewYE8ucccQ4lM8IYswSQ4UursBYeDXd7qPH/mWn/9VncTg0+r4XoaCFLCUWdhBjY1qhCmZ80a84HkyRtOuEC4abKOTRzJocnh0ehvHkmLpSpiUVE+czgPW4nyi5z2comU/7F+g3Ou1Am1zvbwh5GjCE8pPOu/cq7Y0Pik25/2oey8ctYOP5r6UQk7PapXnqyXo37vksHacKMTzkBVO/ZToT11nwPcLfD57MsWfCMPqrHEkW+Ykp60iage4a8Nv4U3YLR8PuDMRuUzSCraTLZv7uz6RwPySSrTDFUBNZ1Zmc2k+01+CEW1Me78cIsmwdiel6qFnW1BFeyxugu8ukcfeU2QzckZFhT/hvMx71rJdLK2ICFECW/6W54RERULFdjbU6KDYQqAK4710+wwwt5jMWgzWPzuz1FmXv3FDyq5+e4WSlwNDTkX2dGW0OUw/Y4oJ1tkzg/ir3QI6qbTEIaWmvsP7LAnxHJnpW+eNIlcexsrySaRoTYPqR7uRJstBb8ALCMjtDOuXescCwejaMG9h/UBY31yD6fCFONONxVSuIen5HIb0bf+bmw4pW2m4IIjGc9RyAQGSKV4AKi3mN5dgQVDGASP4PJwep47ie9PO2N2xW8mUaGghfx+wbJlF1kTXnRt53uxiMW4Sy9QLYeTwpMO8mfL4/w2xn6vORwonPh2cbOTApUOtfsxR93DfCWwb4z5rg7mBi0IlLrgk++LP9e6mCLziC5gDiaBa57BS6oJUN77Sl5e23J1quKN5WFo2p9J9d00DFW0TJMbF4amwaAH1DBgtm8yp3AU6FaT0pNqQKXH66+dxEwGGq1Shw1mKwTLgcHzcgUnzNcS36Psp1ktieW2cTbIKz18Et49Go0o8Lp5iD4q9+aigFM/kitO+D+xNf2ti+hwjbBDlU/v/b0mMLCFXHvO+OnUPIQzVAxE/gjVSfTI64rGh1A753+F10zU5zLhQaVo2rQeo13EmjN/uuge5TL6D0IKhAHSC8qj5Wj41P6ZTWZx9HoQDRaWq/aXMM+2lrYqVsmh1Ty+LZ56ld9cnTr1koTtyZ82mKYlNft1ItMGOJIHUfAxFpwm6NY2Xk+5E29ZNPZNLG/rSujzpPj0MTPpILLZRV1F6blKPV8KlOwGr4uzLoXO58=");