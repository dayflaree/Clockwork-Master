--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ITEM = Clockwork.item:New()
ITEM.name = "Electronic Waste"
ITEM.model = "models/props_lab/reciever01c.mdl"
ITEM.weight = 1
ITEM.category = "Crafting Materials"
ITEM.uniqueID = "electronicwaste"
ITEM.business = false
ITEM.description = "Some burnt electronic scrap. Looks like something of this is still working."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register()