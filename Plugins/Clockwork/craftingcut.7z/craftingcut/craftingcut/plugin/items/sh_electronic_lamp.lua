--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ITEM = Clockwork.item:New()
ITEM.name = "Lamp"
ITEM.model = "models/props_wasteland/prison_lamp001c.mdl"
ITEM.weight = 1
ITEM.category = "Crafting Materials"
ITEM.uniqueID = "lamp"
ITEM.business = false
ITEM.description = "A lamp cleverly stolen from the ceiling."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register()