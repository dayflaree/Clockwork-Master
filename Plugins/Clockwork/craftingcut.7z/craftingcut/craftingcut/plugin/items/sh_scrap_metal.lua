--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Metal"
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl"
ITEM.weight = 0.5
ITEM.category = "Crafting Materials"
ITEM.uniqueID = "scrapmetal"
ITEM.business = false
ITEM.description = "Some rusty metal."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register()