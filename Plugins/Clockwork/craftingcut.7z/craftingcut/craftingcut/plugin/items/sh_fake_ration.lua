--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ITEM = Clockwork.item:New()
ITEM.name = "Rаtion"
ITEM.model = "models/weapons/w_package.mdl"
ITEM.weight = 2
ITEM.category = "Crafting Materials"
ITEM.business = false
ITEM.uniqueID = "fakeration"
ITEM.description = "A purple container, what goodies have they given you this time?";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register()