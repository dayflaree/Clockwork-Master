--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ITEM = Clockwork.item:New();
ITEM.name = "Blueprint - Fake Ration";
ITEM.cost = 0;
ITEM.model = "models/props_c17/paper01.mdl";
ITEM.weight = 0.5;
ITEM.access = "M";
ITEM.useText = "Craft";
ITEM.business = true;
ITEM.uniqueID = "blueprintexample";
ITEM.category = "Blueprints";
ITEM.description = "Materials Needed: 1x Lamp, 1x Scrap Metal, 1x Electronic Waste.";
 
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity) -- Do not change

player:GetInventory(player) -- Do not change
    local attribute = Clockwork.attributes:Get(player, ATB_CRAFT); -- Do not change
	local itemOne = player:FindItemByID("lamp"); --First Item
	local itemTwo = player:FindItemByID("electronicwaste"); --First Item
	local itemThree = player:FindItemByID("scrapmetal"); --First Item
	
    if (player:HasItemByID("lamp") and player:HasItemByID("electronicwaste") and player:HasItemByID("scrapmetal")) then -- ID of the part(s).
        player:TakeItem(itemOne); -- Take this item if craft is successfull. If you want to take more than one item, just copy-paste this line several times
        player:TakeItem(itemTwo);
        player:TakeItem(itemThree);
        player:GiveItem(Clockwork.item:CreateInstance("fakeration")); -- Give this item if craft is successfull
        player:GiveItem(Clockwork.item:CreateInstance("blueprintexample"));
        player:EmitSound("ambient/machines/combine_terminal_idle1.wav"); -- Play this sound
		   Clockwork.player:Notify(player, "Craft Successful!"); -- Print this text on the screen
	    player:BoostAttribute(self.name, ATB_CRAFT, 10);
    else
        Clockwork.player:Notify(player, "You don't have some parts!"); -- Do not change
        player:GiveItem(Clockwork.item:CreateInstance("blueprintexample"));
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
 
ITEM:Register(); -- Do not change