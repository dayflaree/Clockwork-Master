--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

local ATTRIBUTE = Clockwork.attribute:New()
    ATTRIBUTE.name = "Crafting"
    ATTRIBUTE.maximum = 75
    ATTRIBUTE.uniqueID = "cra"
    ATTRIBUTE.description = "Depends on how good you can craft basic craft recipes."
	ATTRIBUTE.isOnCharScreen = true;
ATB_CRAFT = Clockwork.attribute:Register(ATTRIBUTE)