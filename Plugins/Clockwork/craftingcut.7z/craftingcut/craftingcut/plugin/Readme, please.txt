THIS IS CUT VERSION OF THE PLUGIN, MANY FEATURES WERE REMOVED.

First of all - thanks for buying my plugin!
(If you didn't buy it - then buy it or uninstall it. Respect my work!..    ...or die :<)

This plugin requires my Trash plugin to function properly. Because many of theese
empty cans are used in crafting blueprints. RJ's or other plugin will NOT work.
This plugin is not yet compatible with Union Items by RJ, but I have some plans to add compatibility.

There are about 100 blueprints, and even more items for crafts. They all were made from scratch by me.
I spent many days thinking about them and implementing them.

But the developing started even further ago:
At 13 March or 2013!

So, now we have:
Crafting System with attributes and workbenches, with lots of blueprints and items to craft.

Hope you like it!

THIS IS CUT VERSION OF THE PLUGIN, MANY FEATURES WERE REMOVED.