--[[
    (C) 2014 TheGarry =D
    Do not edit, share or re-distribute this file without my permission.
	
	If any changes will be noticed - your license WILL be terminated.
]]--

PLUGIN = PLUGIN

function PLUGIN:Initialize()
    if (!file.Exists("gamemodes/cwhl2rp/plugins/craftingcut/plugin/sv_plugin.lua", "MOD")) then
       	ErrorNoHalt("[Crafting System] The plugin is missing sv_plugin.lua! It will not function without it!\n");
	end;
end;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua")