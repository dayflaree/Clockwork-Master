--[[
	© 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local COMMAND = Clockwork.command:New("AnimCitizenFem");
COMMAND.tip = "Animations for female.";
COMMAND.text = "<string Anim>";
COMMAND.arguments = 1;
COMMAND.animTable = {
	["LineIdle01"] = 0,
	["LineIdle02"] = 0,
	["LineIdle03"] = 0,
	["canals_arlene_pourgas"] = 0,
	["d2_coast03_PostBattle_Idle02"] = 0,
	["cower_Idle"] = 0,

	["base_cit_medic_postanim"] = 0,
	["canals_mary_postidle"] = 0,
	["canals_mary_preidle"] = 0,
	["checkmalepost"] = 0,
	["d1_town05_Jacobs_Heal"] = 0,
	["Sit_Ground"] = 0,
	["plazaidle4"] = 0,

	["cheer1"] = 2,
	["Wave_close"] = 3,
	["Wave"] = 3,
	["stopwomanpre"] = 0,
	["d1_t01_Clutch_Chainlink_Idle"] = 0,
};
COMMAND.animTableTrace = {
	["Lying_Down"] = 0,
	["d1_town05_Wounded_Idle_1"] = 0,
};
COMMAND.animTableWall = {
	["d2_coast03_PostBattle_Idle01"] = 0,
	["d1_t03_Tenements_Look_Out_Window_Idle"] = 0,
	["Lean_Left"] = 2,
	["Lean_Back"] = 1,
	["plazaidle1"] = 1,
};

if (CLIENT) then
	Clockwork.quickmenu:AddCommand("Idle", "Animations for female characters", COMMAND.name, {
		{"Cross the hands", "LineIdle01"},
		{"Take another hand", "LineIdle02"},
		{"Fold hands, hold onto the chin", "LineIdle03"},
		{"Stressed", "canals_arlene_pourgas"},
		{"Shortness of breath", "d2_coast03_PostBattle_Idle02"},
	});
	Clockwork.quickmenu:AddCommand("Near the wall", "Animations for female characters", COMMAND.name, {
		{"Shortness of breath, hand on the wall", "d2_coast03_PostBattle_Idle01"},
		{"Look in the window", "d1_t03_Tenements_Look_Out_Window_Idle"},
		{"Lean left", "Lean_Left"},
		{"Lean back", "Lean_Back"},
		{"Lean back, hand behind the back", "plazaidle1"},
	});
	Clockwork.quickmenu:AddCommand("Sit", "Animations for female characters", COMMAND.name, {
		{"On the knee", "base_cit_medic_postanim"},
		{"On the knees", "canals_mary_postidle"},
		{"On the knees, hunched", "canals_mary_preidle"},
		{"Examine an item", "checkmalepost"},
		{"Examine the floor", "d1_town05_Jacobs_Heal"},
		{"On the floor", "Sit_Ground"},
		{"Near the wall", "plazaidle4"},
	});
	Clockwork.quickmenu:AddCommand("Lie", "Animations for female characters", COMMAND.name, {
		{"On the back, quietly", "Lying_Down"},
		{"On the back, injury", "d1_town05_Wounded_Idle_1"},
	});
	Clockwork.quickmenu:AddCommand("Other", "Animations for female characters", COMMAND.name, {
		{"Jump for joy", "cheer1"},
		{"Call someone", "Wave_close"},
		{"Call someone, wave", "Wave"},
		{"Cover", "stopwomanpre"},
		{"Put hands in front", "d1_t01_Clutch_Chainlink_Idle"},
	});
end;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local curTime = CurTime();

	if (player:Alive() and !player:IsRagdolled() and !player:IsNoClipping()) then
		if (!player.cwNextStance or curTime >= player.cwNextStance) then
			player.cwNextStance = curTime + 2;

			local modelClass = Clockwork.animation:GetModelClass(player:GetModel());

			if (modelClass == "femaleHuman" or modelClass == "femaleHuman") then
				local forcedAnimation = player:GetForcedAnimation();
				
				if (forcedAnimation) then
					cwEmoteAnims:MakePlayerExitStance(player);
				else
					local anim = arguments[1];
					local forward = player:GetForward();
					
					if (COMMAND.animTable[anim]) then
						player:SetSharedVar("StancePos", player:GetPos());
						player:SetSharedVar("StanceAng", player:GetAngles());
						
						player:SetForcedAnimation(anim, COMMAND.animTable[anim]);
					elseif (COMMAND.animTableTrace[anim]) then
						local tr = util.TraceLine({
							start = player:GetPos() + Vector(0, 0, 16) + forward*35,
							endpos = player:GetPos() + Vector(0, 0, 16) - forward*35,
							filter = player
						});
						
						if (tr.Hit) then
							Clockwork.player:Notify(player, "You don't have enough space!");
						else
							player:SetSharedVar("StancePos", player:GetPos());
							player:SetSharedVar("StanceAng", player:GetAngles());
							
							player:SetForcedAnimation(anim, 0);
						end;
					elseif (COMMAND.animTableWall[anim]) then
						local trendpos = forward*20;
						
						if (COMMAND.animTableWall[anim] == 1) then
							trendpos = forward*-20;
						elseif (COMMAND.animTableWall[anim] == 2) then
							trendpos = player:GetRight()*-20;
						end
						
						local tr = util.TraceLine({
							start = player:EyePos(),
							endpos = player:EyePos() + trendpos,
							filter = player
						});
						
						if (tr.Hit) then
							player:SetEyeAngles(tr.HitNormal:Angle() + Angle(0, 180, 0));
							player:SetSharedVar("StancePos", player:GetPos());
							player:SetSharedVar("StanceAng", player:GetAngles());
							
							player:SetForcedAnimation(anim, 0);
						else
							if (COMMAND.animTableWall[anim] == 1) then
								Clockwork.player:Notify(player, "You should stand with your back to the wall!");
							elseif (COMMAND.animTableWall[anim] == 2) then
								Clockwork.player:Notify(player, "You must stand left side to the wall!");
							else
								Clockwork.player:Notify(player, "You must face the wall!");
							end
						end;
					else
						Clockwork.player:Notify(player, "This animation doesn't exist!");
					end;
				end;
			else
				Clockwork.player:Notify(player, "Your model does not support this animation!");
			end;
		else
			Clockwork.player:Notify(player, "You can not perform another animation!");
		end;
	else
		Clockwork.player:Notify(player, "You can not do it now!");
	end;
end;

COMMAND:Register();