--[[
	© 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local COMMAND = Clockwork.command:New("AnimCp");
COMMAND.tip = "Animations for Civil Protection.";
COMMAND.text = "<string Anim>";
COMMAND.arguments = 1;
COMMAND.animTable = {
	["stopwomanpre"] = 0,
	["adoorknock"] = 0,
	
	["harassfront2"] = 2,
	["motionleft"] = 2,
	["motionright"] = 2,
	["plazathreat1"] = 5,
	["plazathreat2"] = 5,
	["shootflare"] = 2,
	["Spreadwall"] = 4,
};
COMMAND.animTableWall = {
	["Idle_Baton"] = 0,
};

if (CLIENT) then
	Clockwork.quickmenu:AddCommand("Idle", "Animations for Civil Protection", COMMAND.name, {
		{"Intensely", "stopwomanpre"},
		{"Knock", "adoorknock"},
	});
	Clockwork.quickmenu:AddCommand("Near the wall", "Animations for Civil Protection", COMMAND.name, {
		{"Lean on the wall", "Idle_Baton"},
	});
	Clockwork.quickmenu:AddCommand("Other", "Animations for Civil Protection", COMMAND.name, {
		{"Deny", "harassfront2"},
		{"Motion left", "motionleft"},
		{"Motion right", "motionright"},
		{"Rub a stunbaton", "plazathreat1"},
		{"Knock the baton", "plazathreat2"},
		{"Aim at the top", "shootflare"},
		{"Search the person", "Spreadwall"},
	});
end;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local curTime = CurTime();

	if (player:Alive() and !player:IsRagdolled() and !player:IsNoClipping()) then
		if (!player.cwNextStance or curTime >= player.cwNextStance) then
			player.cwNextStance = curTime + 2;

			local modelClass = Clockwork.animation:GetModelClass(player:GetModel());

			if (modelClass == "civilProtection") then
				local forcedAnimation = player:GetForcedAnimation();
				
				if (forcedAnimation) then
					cwEmoteAnims:MakePlayerExitStance(player);
				else
					local anim = arguments[1];
					local forward = player:GetForward();
					
					if (COMMAND.animTable[anim]) then
						player:SetSharedVar("StancePos", player:GetPos());
						player:SetSharedVar("StanceAng", player:GetAngles());
						
						player:SetForcedAnimation(anim, COMMAND.animTable[anim]);
					elseif (COMMAND.animTableWall[anim]) then
						local tr = util.TraceLine({
							start = player:EyePos(),
							endpos = player:EyePos() + forward*-20,
							filter = player
						});
						
						if (tr.Hit) then
							player:SetEyeAngles(tr.HitNormal:Angle() + Angle(0, 180, 0));
							player:SetSharedVar("StancePos", player:GetPos());
							player:SetSharedVar("StanceAng", player:GetAngles());
							
							player:SetForcedAnimation(anim, 0);
						else
							Clockwork.player:Notify(player, "You must face the wall!");
						end;
					else
						Clockwork.player:Notify(player, "This animation doesn't exist!");
					end;
				end;
			else
				Clockwork.player:Notify(player, "Your model does not support this animation!");
			end;
		else
			Clockwork.player:Notify(player, "You can not perform another animation!");
		end;
	else
		Clockwork.player:Notify(player, "You can not do it now!");
	end;
end;

COMMAND:Register();