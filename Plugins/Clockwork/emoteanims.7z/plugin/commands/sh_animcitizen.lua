--[[
	© 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local COMMAND = Clockwork.command:New("AnimCitizen");
COMMAND.tip = "Anims for man.";
COMMAND.text = "<string Anim>";
COMMAND.arguments = 1;
COMMAND.animTable = {
	["d1_t01_BreakRoom_WatchBreen"] = 0,
	["d1_t02_Playground_Cit1_Arms_Crossed"] = 0,
	["LineIdle04"] = 0,
	["d1_t02_Playground_Cit2_Pockets"] = 0,
	["scaredidle"] = 0,
	["d2_coast03_PostBattle_Idle02"] = 0,

	["lookoutidle"] = 0,
	["d1_town05_Daniels_Kneel_Idle"] = 0,
	["Sit_Ground"] = 0,
	["plazaidle4"] = 0,

	["cheer2"] = 3,
	["Wave_close"] = 3,
	["Wave"] = 3,
	["luggageidle"] = 0,
};
COMMAND.animTableTrace = {
	["arrestidle"] = 0,
	["d1_town05_Winston_Down"] = 0,
	["Lying_Down"] = 0,
	["d1_town05_Wounded_Idle_1"] = 0,
	["sniper_victim_pre"] = 0,
	["d2_coast11_Tobias"] = 0,
};
COMMAND.animTableWall = {
	["d2_coast03_PostBattle_Idle01"] = 0,
	["d1_t03_Tenements_Look_Out_Window_Idle"] = 0,
	["doorBracer_Closed"] = 0,
	["Lean_Left"] = 2,
	["Lean_Back"] = 1,
	["plazaidle1"] = 1,
};

if (CLIENT) then
	Clockwork.quickmenu:AddCommand("Idle", "Animations for male characters", COMMAND.name, {
		{"Cross hands", "d1_t01_BreakRoom_WatchBreen"},
		{"Cross hands, hunched", "d1_t02_Playground_Cit1_Arms_Crossed"},
		{"Hands in pockets", "LineIdle04"},
		{"Hands in pockets, hunched", "d1_t02_Playground_Cit2_Pockets"},
		{"Stressed", "scaredidle"},
		{"Shortness of breath", "d2_coast03_PostBattle_Idle02"},
	});
	Clockwork.quickmenu:AddCommand("Near the wall", "Animations for male characters", COMMAND.name, {
		{"Shortness of breath, hand on the wall", "d2_coast03_PostBattle_Idle01"},
		{"Look in the window", "d1_t03_Tenements_Look_Out_Window_Idle"},
		{"Lean against the wall", "doorBracer_Closed"},
		{"Lean left", "Lean_Left"},
		{"Lean back", "Lean_Back"},
		{"Lean back, hands behind back", "plazaidle1"},
	});
	Clockwork.quickmenu:AddCommand("Sit", "Animations for male characters", COMMAND.name, {
		{"Looking around", "lookoutidle"},
		{"Inspect the floor", "d1_town05_Daniels_Kneel_Idle"},
		{"On the floor", "Sit_Ground"},
		{"Near the wall", "plazaidle4"},
	});
	Clockwork.quickmenu:AddCommand("Lie", "Animations for male characters", COMMAND.name, {
		{"On stomach, hands behind head", "arrestidle"},
		{"On the back, injury", "d1_town05_Winston_Down"},
		{"On the back, relaxed", "Lying_Down"},
		{"On the side, injury", "d1_town05_Wounded_Idle_1"},
		{"On the side", "sniper_victim_pre"},
		{"Sexy", "d2_coast11_Tobias"},
	});
	Clockwork.quickmenu:AddCommand("Other", "Animations for male characters", COMMAND.name, {
		{"Cheer", "cheer2"},
		{"Call someone", "Wave_close"},
		{"Call someone, wave", "Wave"},
		{"Put hands in front", "luggageidle"},
	});
end;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local curTime = CurTime();

	if (player:Alive() and !player:IsRagdolled() and !player:IsNoClipping()) then
		if (!player.cwNextStance or curTime >= player.cwNextStance) then
			player.cwNextStance = curTime + 2;

			local modelClass = Clockwork.animation:GetModelClass(player:GetModel());

			if (modelClass == "maleHuman") then
				local forcedAnimation = player:GetForcedAnimation();
				
				if (forcedAnimation) then
					cwEmoteAnims:MakePlayerExitStance(player);
				else
					local anim = arguments[1];
					local forward = player:GetForward();
					
					if (COMMAND.animTable[anim]) then
						player:SetSharedVar("StancePos", player:GetPos());
						player:SetSharedVar("StanceAng", player:GetAngles());
						
						player:SetForcedAnimation(anim, COMMAND.animTable[anim]);
					elseif (COMMAND.animTableTrace[anim]) then
						local tr = util.TraceLine({
							start = player:GetPos() + Vector(0, 0, 16) + forward*35,
							endpos = player:GetPos() + Vector(0, 0, 16) - forward*35,
							filter = player
						});
						
						if (tr.Hit) then
							Clockwork.player:Notify(player, "You don't have enough space!");
						else
							player:SetSharedVar("StancePos", player:GetPos());
							player:SetSharedVar("StanceAng", player:GetAngles());
							
							player:SetForcedAnimation(anim, 0);
						end;
					elseif (COMMAND.animTableWall[anim]) then
						local trendpos = forward*20;
						
						if (COMMAND.animTableWall[anim] == 1) then
							trendpos = forward*-20;
						elseif (COMMAND.animTableWall[anim] == 2) then
							trendpos = player:GetRight()*-20;
						end
						
						local tr = util.TraceLine({
							start = player:EyePos(),
							endpos = player:EyePos() + trendpos,
							filter = player
						});
						
						if (tr.Hit) then
							player:SetEyeAngles(tr.HitNormal:Angle() + Angle(0, 180, 0));
							player:SetSharedVar("StancePos", player:GetPos());
							player:SetSharedVar("StanceAng", player:GetAngles());
							
							player:SetForcedAnimation(anim, 0);
						else
							if (COMMAND.animTableWall[anim] == 1) then
								Clockwork.player:Notify(player, "You must stand with your back to the wall!");
							elseif (COMMAND.animTableWall[anim] == 2) then
								Clockwork.player:Notify(player, "You must stand left side to the wall!");
							else
								Clockwork.player:Notify(player, "You must face the wall!");
							end
						end;
					else
						Clockwork.player:Notify(player, "This animation doesn't exist!");
					end;
				end;
			else
				Clockwork.player:Notify(player, "Your model does not support this animation!");
			end;
		else
			Clockwork.player:Notify(player, "You can not perform another animation!");
		end;
	else
		Clockwork.player:Notify(player, "You can not do it now!");
	end;
end;

COMMAND:Register();