-- Speed Configuration, Change these only.
-- Run Speeds
local AddOTARunSpeed = 120; -- Changes OTA max running speed.
local AddMPFRunSpeed = 60; -- Changes MPF max running speed.
-- Walk Speeds
local AddOTAWalkSpeed = 60; -- Changes OTA max walking speed.
local AddMPFWalkSpeed = 20; -- Changes MPF max walking speed.
-- Bonus Jump Height
local AddOTAJumpHeight = 40; -- Changes OTA max jump height.
local AddMPFJumpHeight = 10; -- Changes MPF max jump height.
-- Bonus Inventory Weight
local AddOTAInvWeight = 16; -- Changes OTA max inventory weight.
local AddMPFInvWeight = 8; -- Changes MPF max inventory weight.

-- Do not Modify This
-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
-- Sets run/walk/jump for all factions required
	if(player:GetFaction() == FACTION_MPF) then
	infoTable.inventoryWeight = infoTable.inventoryWeight + Clockwork.attributes:Fraction(player, ATB_STRENGTH, 12, 6) + AddMPFInvWeight;
	infoTable.jumpPower = infoTable.jumpPower + Clockwork.attributes:Fraction(player, ATB_ACROBATICS, 100, 50) + AddMPFJumpHeight;
	infoTable.runSpeed = infoTable.runSpeed + Clockwork.attributes:Fraction(player, ATB_AGILITY, 50, 25) + AddMPFRunSpeed;
	infoTable.walkSpeed = infoTable.walkSpeed + AddMPFWalkSpeed;
	elseif(player:GetFaction() == FACTION_OTA) then
	infoTable.inventoryWeight = infoTable.inventoryWeight + Clockwork.attributes:Fraction(player, ATB_STRENGTH, 12, 6) + AddOTAInvWeight;
	infoTable.jumpPower = infoTable.jumpPower + Clockwork.attributes:Fraction(player, ATB_ACROBATICS, 100, 50) + AddOTAJumpHeight;
	infoTable.runSpeed = infoTable.runSpeed + Clockwork.attributes:Fraction(player, ATB_AGILITY, 50, 25) + AddOTARunSpeed;
	infoTable.walkSpeed = infoTable.walkSpeed + AddOTAWalkSpeed;
	end;
end;