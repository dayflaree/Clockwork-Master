
local Clockwork = Clockwork;

Clockwork.config:Add("stealth_boy_max_time", 7200, true); -- Sets the maximum amount of time someone can use a stealth boy