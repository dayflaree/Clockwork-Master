-Replace the default mapscene plugin with this one, be sure to back up the default plugin before doing so. 

-This is a work in progress, but it still looks good so be sure to check back for updates.