local PLUGIN = PLUGIN;
 
hook.Add("InitPostEntity", "DeleteRebel", function()
	for k,v in pairs(ents.GetAll()) do
		if v:GetName() == "rebel_evidence" or v:GetName() == "vendingmachines" then
			SafeRemoveEntity(v)
		end
	end
end)