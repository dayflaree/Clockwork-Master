<?php
///////////////////
//    Global     //
// Configuration //
///////////////////
//    Database   //
// Configuration //
///////////////////

$address = "localhost";
$user = "root";
$pass = "";
$database = "ollw_tc52757054702351740647406";
$characters ="characters";
$players = "players";
$gamemodecode = "cwhl2rp";

///////////Website////////
$site = "My website name here";
$url = "http://mywebsiteurlhere.com";
//////////////Flags//////////
$flags = "pet";
///////////////////////
// END GLOBAL CONFIG //
///////////////////////


// Created 6/11/12 at 4:16PM
// Pulbic Version

// Template: 

/*
include('globalconfig.php');
$con = mysql_connect($address,$user,$pass);
if (!$con)
  {
  die('ERROR! Unable to connect: ' . mysql_error());
  }

mysql_select_db($database, $con);
*/
?>