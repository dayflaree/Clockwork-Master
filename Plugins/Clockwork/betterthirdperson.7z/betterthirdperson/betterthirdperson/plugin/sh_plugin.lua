local PLUGIN = PLUGIN;

PLUGIN.upMax = 10;
PLUGIN.backMax = 60;
PLUGIN.sideMax = 25;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("InThirdPerson", true);
end;

CreateClientConVar("thirdperson_up", "0", true, false)
CreateClientConVar("thirdperson_back", "0", true, false)
CreateClientConVar("thirdperson_right", "0", true, false)
CreateClientConVar("thirdperson_crouchheight", "0", true, false)

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");

