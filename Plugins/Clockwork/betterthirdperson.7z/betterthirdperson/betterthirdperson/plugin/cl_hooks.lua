local PLUGIN = PLUGIN;
PLUGIN.cam = {};
PLUGIN.zoomed = false;
PLUGIN.punchScale = 1;

PLUGIN.cam.LeftPos = {};
PLUGIN.cam.CenterPos = {};
PLUGIN.cam.FocusPos = {};
PLUGIN.cam.RightPos = {};

-- Do not touch these
PLUGIN.cam.CenterPos.l, PLUGIN.cam.FocusPos.l = 0.05, 0.025;
PLUGIN.cam.Punch = Angle(0, 0, 0);
PLUGIN.cam.TargetFov = 0;

PLUGIN.cam.Pos = Vector(0, 0, 0);
PLUGIN.cam.Ang = Angle(0, 0, 0);
PLUGIN.cam.Fov = 0;
PLUGIN.Blocked = false;

Clockwork.setting:AddCheckBox("Enable third person view.", "Enabled.", "cwThirdPerson", "Enable third person view.");
Clockwork.setting:AddNumberSlider("Enable third person view.", "Height from above.", "thirdperson_up", 0, PLUGIN.upMax, 1, "Height from above.");
Clockwork.setting:AddNumberSlider("Enable third person view.", "From right.", "thirdperson_right", 0, PLUGIN.sideMax, 1, "From right.");
Clockwork.setting:AddNumberSlider("Enable third person view.", "From back.", "thirdperson_back", 0, PLUGIN.backMax, 1, "From back.");
Clockwork.setting:AddNumberSlider("Enable third person view.", "Height while crouching.", "thirdperson_crouchheight", 0, PLUGIN.upMax, 1, "Height while crouching.");

do
	local playerMeta = FindMetaTable("Player");
	playerMeta.ClockworkSetEyeAngles = playerMeta.ClockworkSetEyeAngles or playerMeta.SetEyeAngles

	function playerMeta:SetEyeAngles(angles, bInCam)
		if (self:GetSharedVar("InThirdPerson")) then
			if (bInCam) then
				return self.ClockworkSetEyeAngles(self, angles);
			else
				angles.x = angles.x - (Clockwork.Client:EyeAngles().x - PLUGIN.cam.Ang.x);
				angles.y = angles.y - (Clockwork.Client:EyeAngles().y - PLUGIN.cam.Ang.y);
				PLUGIN.cam.Ang = angles;
			end;
		else
			return self.ClockworkSetEyeAngles(self, angles);
		end;
	end;
end;

Clockwork.datastream:Hook("SetEyeAngles", function(angle)
	Clockwork.Client:SetEyeAngles(angle);
end);

Clockwork.datastream:Hook("ViewPunch", function(angle)
	PLUGIN.cam.Punch = punch;
end);

function PLUGIN:Think()
	if (IsValid(Clockwork.Client)) then
		self.cam.Punch = Clockwork.Client:GetViewPunchAngles();
	end;
end;

do
	local CrosshairBlocked = false;

	function PLUGIN:HUDPaint()
		if (IsValid(Clockwork.Client) and !PLUGIN.Blocked) then
			if (Clockwork.Client:Alive() and Clockwork.Client:GetSharedVar("InThirdPerson")) then
				if (CrosshairBlocked) then
					surface.SetDrawColor(255, 0, 0, 100);
				else
					surface.SetDrawColor(255, 255, 255, 100);
				end;

				surface.DrawRect(ScrW() / 2 - 2, ScrH() / 2 - 2, 4, 4);
			end;
		end;
	end;

	function PLUGIN:CalcView(player, pos, ang, fov, znear, zfar)
		if (!IsValid(player) or !player:Alive()) then
			self.cam.Ang = Clockwork.Client:EyeAngles();
			return;
		end;

		if (!player:GetSharedVar("InThirdPerson") or player:GetSharedVar("KickingDoor") or Clockwork.Client:GetMoveType() == MOVETYPE_NOCLIP or player:IsRagdolled()) then
			self.cam.Ang = Clockwork.Client:EyeAngles();
			return;
		end;

		local up 		= math.Clamp(GetConVarNumber("thirdperson_up"), 0, PLUGIN.upMax);
		local back		= math.Clamp(GetConVarNumber("thirdperson_back"), 0, PLUGIN.backMax);
		local offset 	= math.Clamp(GetConVarNumber("thirdperson_right"), -PLUGIN.sideMax, PLUGIN.sideMax);
		local crouchup 	= math.Clamp(GetConVarNumber("thirdperson_crouchheight"), 0, 20);

		self.cam.LeftPos.x, self.cam.CenterPos.x, self.cam.FocusPos.x, self.cam.RightPos.x = back / 3, back, back / 3, back / 3; -- Forward and back
		self.cam.LeftPos.y, self.cam.CenterPos.y, self.cam.FocusPos.y, self.cam.RightPos.y = offset, offset, offset, 32; -- Left and right
		self.cam.LeftPos.z, self.cam.CenterPos.z, self.cam.FocusPos.z, self.cam.RightPos.z = up, up, up, up; -- Up and down
		self.cam.FocusPos.crouch = crouchup == 0 and up or crouchup; -- Offset while crouched

		self.cam.TargetFov = self.zoomed and 70 or 0;

		if (player:KeyDown(IN_SPEED)) then
			if (player:KeyDown(IN_FORWARD) or player:KeyDown(IN_BACK) or player:KeyDown(IN_MOVELEFT) or player:KeyDown(IN_MOVERIGHT)) then
				self.cam.TargetFov = fov + 5;
			end;
		end;

		if (player:KeyDown(IN_DUCK)) then
			self.cam.Pos.z = Lerp(FrameTime() * 5, self.cam.Pos.z, self.cam.FocusPos.crouch);
		else
			self.cam.Pos.z = Lerp(FrameTime() * 5, self.cam.Pos.z, self.cam.CenterPos.z);
		end;

		self.cam.Fov = Lerp(FrameTime() * 7, self.cam.Fov, self.cam.TargetFov == 0 and fov or self.cam.TargetFov);
		self.cam.Pos.x = Lerp(self.cam.CenterPos.l, self.cam.Pos.x, self.cam.CenterPos.x);
		self.cam.Pos.y = Lerp(self.cam.CenterPos.l, self.cam.Pos.y, self.cam.CenterPos.y);

		local offset = pos - (self.cam.Ang:Forward() * self.cam.Pos.x) + (self.cam.Ang:Right() * self.cam.Pos.y) + (self.cam.Ang:Up() * self.cam.Pos.z);

		-- Move camera to point of collision if necessary
		local collisionTrace = util.TraceHull({
			start = player:EyePos() - self.cam.Ang:Forward() * 4,
			endpos = offset,
			mins = Vector(-4, -4, -4),
			maxs = Vector(4, 4, 4),
			filter = function(ent) if (ent == player or ent:GetOwner() == player or ent:GetClass() == "cw_forcefield") then return false; else return true; end; end;
		});

		if (collisionTrace.Hit) then
			offset = collisionTrace.HitPos;

			if (collisionTrace.HitPos:Distance(player:EyePos()) <= 15) then
				self.Blocked = true;
			else
				self.Blocked = false;
			end;
		else
			self.Blocked = false;
		end;

		if (self.Blocked) then return; end;

		-- From camera pos to aim pos
		local camTrace = util.TraceLine({
			start = offset + (self.cam.Ang:Forward() * back * 1.2),
			endpos = offset + (self.cam.Ang:Forward() * 32768),
			filter = function(ent) if (ent == player or ent:GetOwner() == player or ent:GetClass() == "cw_forcefield") then return false else return true end end,
			mask = MASK_OPAQUE
		});

		local entTrace = util.TraceLine({
			start = offset + (self.cam.Ang:Forward() * back * 1.2),
			endpos = offset + (self.cam.Ang:Forward() * 32768),
			filter = function(ent) if (ent == player or ent:GetOwner() == player or ent:GetClass() == "cw_forcefield") then return false else return true end end,
			mask = MASK_SHOT
		});


		local finalPos = IsValid(entTrace.Entity) and entTrace.HitPos or camTrace.HitPos

		local clearTrace = util.TraceLine({
			start = Clockwork.Client:EyePos(),
			endpos = finalPos,
			mask = MASK_SHOT,
			filter = function(ent) if (ent == Clockwork.Client or ent:GetOwner() == Clockwork.Client or ent:GetClass() == "cw_forcefield") then return false else return true end end
		});

		if (clearTrace.Fraction <= 0.9) then
			CrosshairBlocked = true;
		else
			CrosshairBlocked = false;
		end;

		player:SetEyeAngles((finalPos - player:EyePos()):Angle(), true);

		local angles = self.cam.Ang + (self.cam.Punch * self.punchScale);
		local camera = {};

		camera.origin = offset;
		camera.angles = angles;
		camera.fov = self.cam.Fov;
		camera.drawviewer = true;
		player.CamPos = offset;
		player.CamAng = angles;

		return camera;
	end;
end;

function PLUGIN:Initialize()
	CW_CONVAR_THIRDPERSON = Clockwork.kernel:CreateClientConVar("cwThirdPerson", 0, false, true);
end;

function PLUGIN:ClockworkConVarChanged()
	if (CW_CONVAR_THIRDPERSON:GetInt() == 1) then
		RunConsoleCommand("chasecam", "1")
	else
		RunConsoleCommand("chasecam", "0")
	end
end

function PLUGIN:ClockworkConfigChanged(key, data, previousValue, newValue) 
	if (key == "thirdperson_punch_scale" and newValue) then
		self.punchScale = newValue;
	end;
end;

function PLUGIN:ClockworkConfigInitialized(key, value)
	if ("thirdperson_punch_scale" == key and value) then
		self.punchScale = value;
	end;
end;

function PLUGIN:InputMouseApply(cmd, x, y, ang)
	if (!IsValid(Clockwork.Client)) then
		return;
	end;

	if (!Clockwork.Client:GetSharedVar("InThirdPerson") or Clockwork.Client:GetMoveType() == MOVETYPE_NOCLIP) then
		return;
	end;

	if (IsValid(Clockwork.Client:GetActiveWeapon())) then
		if (Clockwork.Client:GetActiveWeapon():GetClass() == "weapon_physgun" and Clockwork.Client:KeyDown(IN_USE)) then
			return false;
		end;
	end;

	self.cam.Ang.p = math.Clamp(math.NormalizeAngle(self.cam.Ang.p + y / 50), -90, 90);
	self.cam.Ang.y = math.NormalizeAngle(self.cam.Ang.y - (x / 50));

	if (!PLUGIN.Blocked) then
		return true;
	end;
end;

function PLUGIN:CreateMove(cmd)
	if (!IsValid(Clockwork.Client) or PLUGIN.Blocked) then
		return false;
	end;

	if (!Clockwork.Client:GetSharedVar("InThirdPerson") or Clockwork.Client:GetMoveType() == MOVETYPE_NOCLIP) then
		return false;
	end;

	local desiredYaw = self.cam.Ang.y;
	local currentYaw = Clockwork.Client:EyeAngles().y;
	local offsetYaw = desiredYaw - currentYaw;
	local correctedYaw = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0);
	local mvLength = correctedYaw:Length();


	correctedYaw = correctedYaw:Angle().y;
	correctedYaw = Angle(0, correctedYaw - offsetYaw, 0);
	correctedYaw = correctedYaw:Forward();
	cmd:SetForwardMove(correctedYaw.x * mvLength);
	cmd:SetSideMove(correctedYaw.y * mvLength);

	return true;
end;