local function ChaseCommand(player, command, arguments)
	if not arguments[1] then
		player:SetSharedVar("InThirdPerson", !player:GetSharedVar("InThirdPerson"))
	elseif arguments[1] == "1" or arguments[1] == "0" then
		player:SetSharedVar("InThirdPerson", arguments[1] == "1" and true or false)
	end
end
concommand.Add("chasecam", ChaseCommand)