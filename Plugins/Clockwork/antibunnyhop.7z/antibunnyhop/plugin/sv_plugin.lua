local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.datastream:Hook("PlayerJump", function(player)
	player:SetCharacterData("Stamina", math.Clamp(player:GetCharacterData("Stamina") - 15, 0, 100));
end);