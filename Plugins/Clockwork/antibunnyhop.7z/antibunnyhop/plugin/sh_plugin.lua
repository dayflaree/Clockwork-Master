local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua")

-- Called when the player presses a bind.
function PLUGIN:PlayerBindPress(player, bind, bPressed)
	if (bPressed and string.find(bind:lower(), "+jump") and IsValid(player) and player:Alive() and player:HasInitialized() and player:GetMoveType() == MOVETYPE_WALK and player:OnGround()) then
		if (player:GetSharedVar("Stamina") < 15) then
			return true;
		end;

		Clockwork.datastream:Start("PlayerJump");
	end;
end;