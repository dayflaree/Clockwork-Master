local Clockwork = Clockwork;
local PLUGIN = PLUGIN;
Clockwork.config:ShareKey("workshop_id");
if (SERVER) then
	Clockwork.config:Add("workshop_id", "", true);
	function PLUGIN:ClockworkConfigChanged(key, data, previousValue, newValue)
		if (key == "workshop_id") then
			Clockwork.player:NotifyAll("The download has been changed. Type /ViewDownload to view the new download.");
		end;
	end;
else
	Clockwork.config:AddToSystem("Workshop ID", "workshop_id", "The Workshop ID of an addon to be used by the /ViewDownload command.");

	Clockwork.datastream:Hook("ViewDownload", function()
		local workshopID = Clockwork.config:Get("workshop_id"):Get();

		steamworks.ViewFile(tostring(workshopID));
	end);
end;