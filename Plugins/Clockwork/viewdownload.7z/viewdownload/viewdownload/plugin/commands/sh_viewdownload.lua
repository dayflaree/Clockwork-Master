local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("ViewDownload");
COMMAND.tip = "View the download page of a workshop addon set by an administrator. You must have the Steam overlay enabled.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Clockwork.datastream:Start(player, "ViewDownload");
end;

COMMAND:Register();