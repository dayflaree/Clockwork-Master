local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when the client initializes.
function PLUGIN:Initialize()
	CW_CONVAR_TEXTCOLORR = Clockwork.kernel:CreateClientConVar("cwTextColorR", 255, true, true);
	CW_CONVAR_TEXTCOLORG = Clockwork.kernel:CreateClientConVar("cwTextColorG", 200, true, true);
	CW_CONVAR_TEXTCOLORB = Clockwork.kernel:CreateClientConVar("cwTextColorB", 0, true, true);
	CW_CONVAR_TEXTCOLORA = Clockwork.kernel:CreateClientConVar("cwTextColorA", 255, true, true);
	CW_CONVAR_BACKCOLORR = Clockwork.kernel:CreateClientConVar("cwBackColorR", 40, true, true);
	CW_CONVAR_BACKCOLORG = Clockwork.kernel:CreateClientConVar("cwBackColorG", 40, true, true);
	CW_CONVAR_BACKCOLORB = Clockwork.kernel:CreateClientConVar("cwBackColorB", 40, true, true);
	CW_CONVAR_BACKCOLORA = Clockwork.kernel:CreateClientConVar("cwBackColorA", 255, true, true);
	CW_CONVAR_TABX = Clockwork.kernel:CreateClientConVar("cwTabPosX", 56, true, true);
	CW_CONVAR_TABY = Clockwork.kernel:CreateClientConVar("cwTabPosY", 112, true, true);
	CW_CONVAR_FADEPANEL = Clockwork.kernel:CreateClientConVar("cwFadePanels", 1, true, true);
	CW_CONVAR_CHARSTRING = Clockwork.kernel:CreateClientConVar("cwCharString", "CHARACTERS", true, true);
	CW_CONVAR_CLOSESTRING = Clockwork.kernel:CreateClientConVar("cwCloseString", "CLOSE MENU", true, true);
	CW_CONVAR_MATERIAL = Clockwork.kernel:CreateClientConVar("cwMaterial", "hunter/myplastic", true, true);
	CW_CONVAR_BACKX = Clockwork.kernel:CreateClientConVar("cwBackX", 61, true, true);
	CW_CONVAR_BACKY = Clockwork.kernel:CreateClientConVar("cwBackY", 109, true, true);
	CW_CONVAR_BACKW = Clockwork.kernel:CreateClientConVar("cwBackW", 321, true, true);
	CW_CONVAR_BACKH = Clockwork.kernel:CreateClientConVar("cwBackH", 109, true, true);
	CW_CONVAR_SHOWMATERIAL = Clockwork.kernel:CreateClientConVar("cwShowMaterial", 0, true, true);
	CW_CONVAR_SHOWGRADIENT = Clockwork.kernel:CreateClientConVar("cwShowGradient", 1, true, true);
end;

-- Called when a Clockwork ConVar has changed.
function PLUGIN:ClockworkConVarChanged(name, previousValue, newValue)
	Clockwork.option:SetColor("information", Color(GetConVarNumber("cwTextColorR"), GetConVarNumber("cwTextColorG"), GetConVarNumber("cwTextColorB"), GetConVarNumber("cwTextColorA")));
end;