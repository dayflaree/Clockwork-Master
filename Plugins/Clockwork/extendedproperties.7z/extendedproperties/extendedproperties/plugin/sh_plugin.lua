local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitialized()
	self:AddProperties();
end;

-- keep people from picking up static props
function PLUGIN:PhysgunPickup(player, entity)
	if (entity:GetNWBool("Static", false)) then
		return false;
	end;
end;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("MaxHP");
	playerVars:Number("MaxAP");
end;

do
	local dissolveLookup = {
		"Default Vaporize",
		"Heavy Vaporize",
		"Light Vaporize",
		"Core Vaporize"
	};

	function PLUGIN:AddProperties()
		properties.List["drive"] = nil;

		properties.List["persist"].MenuLabel = "Static";

		properties.List["persist_end"].MenuLabel = "Unstatic";

		properties.List["persist"].Filter = function(self, ent, player)
			if (ent:IsPlayer()) then return false; end;
			if (!Clockwork.player:HasFlags(player, "s")) then return false; end;
			if (!Clockwork.entity:IsPhysicsEntity(ent)) then return false; end;

			return !ent:GetNWBool("Static", false);
		end;

		properties.List["persist"].Receive = function(self, length, player)
			local ent = net.ReadEntity();

			if (!IsValid(ent)) then return; end;
			if (!self:Filter(ent, player)) then return; end;

			ent:SetNWBool("Static", true);
			cwStaticProps.staticProps[#cwStaticProps.staticProps + 1] = ent;
			cwStaticProps:SaveStaticProps();
		end;

		properties.List["persist_end"].Filter = function(self, ent, player)
			if (ent:IsPlayer()) then return false; end;
			if (!Clockwork.player:HasFlags(player, "s")) then return false; end;
			if (!Clockwork.entity:IsPhysicsEntity(ent)) then return false; end;

			return ent:GetNWBool("Static", false);
		end;

		properties.List["persist_end"].Receive = function(self, length, player)
			local ent = net.ReadEntity();

			if (!IsValid(ent)) then return; end;
			if (!self:Filter(ent, player)) then return; end;

			if (Clockwork.entity:IsPhysicsEntity(ent)) then
				for k, v in pairs(cwStaticProps.staticProps) do
					if (ent == v) then
						cwStaticProps.staticProps[k] = nil;
						ent:SetNWBool("Static", false);
						cwStaticProps:SaveStaticProps();

						return;
					end;
				end;
			end;
		end;

		properties.Add("chartransfer", {
			MenuLabel = "Faction Transfer",
			Order = 8,
			MenuIcon = "icon16/group.png",
			PrependSpacer = true,

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "a")) then return false; end;

				return true;
			end,

			Action = function(self, ent)
				-- this is empty because I want it to be
			end,

			Request = function(self, ent, factionName)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteString(factionName);
				self:MsgEnd();
			end,

			-- copied this from the chartransfer command
			Transfer = function(self, player, ent, faction)
				local name = ent:Name();

				if (!Clockwork.faction.stored[faction]) then
					Clockwork.player:Notify(player, faction .. " is not a valid faction!");
					return;
				end;

				if (!Clockwork.faction.stored[faction].whitelist or Clockwork.player:IsWhitelisted(ent, faction)) then
					local targetFaction = ent:GetFaction();

					if (targetFaction == faction) then
						Clockwork.player:Notify(player, ent:Name() .. " is already the " .. faction .. " faction!");
						return;
					end;

					if (!Clockwork.faction:IsGenderValid(faction, ent:GetGender())) then
						Clockwork.player:Notify(player, ent:Name() .. " is not the correct gender for the " .. faction .. " faction!");
						return;
					end;

					if (!Clockwork.faction.stored[faction].OnTransferred) then
						Clockwork.player:Notify(player, ent:Name() .. " cannot be transferred to the " .. faction .. " faction!");
						return;
					end;

					local bSuccess, fault = Clockwork.faction.stored[faction]:OnTransferred(ent, Clockwork.faction.stored[targetFaction], nil);

					if (bSuccess != false) then
						ent:SetCharacterData("Faction", faction, true);

						Clockwork.player:LoadCharacter(ent, Clockwork.player:GetCharacterID(ent));
						Clockwork.player:NotifyAll(player:Name() .. " has transferred " .. name .. " to the " .. faction .. " faction.");
					else
						Clockwork.player:Notify(player, fault or ent:Name() .. " could not be transferred to the " .. faction .. " faction!");
					end;
				else
					Clockwork.player:Notify(player, ent:Name() .. " is not on the " .. faction .. " whitelist!");
				end;
			end,

			MenuOpen = function(self, option, ent, trace)
				local subMenu = option:AddSubMenu();

				for k, v in SortedPairs(Clockwork.faction.stored) do
					local option = subMenu:AddOption(k, function()
						self:Request(ent, k);
					end);

					option:SetChecked(ent:GetFaction() == k);
				end;
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();
				local faction = net.ReadString();

				if (!self:Filter(ent, player)) then return; end;

				self:Transfer(player, ent, faction);

				Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " used the 'Faction Transfer' option on " .. ent:Name() .. ".");
			end
		});

		properties.Add("respawnstay", {
			MenuLabel = "Respawn in Place",
			MenuIcon = "icon16/arrow_down.png",
			Order = 7,

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "o")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "a") and !Clockwork.player:HasFlags(player, "a")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "s") and !Clockwork.player:HasFlags(player, "s")) then return false; end;

				return ent:Alive();
			end,

			Action = function(self, ent)
				self:MsgStart();
				net.WriteEntity(ent);
				self:MsgEnd();
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();

				if (!self:Filter(ent, player)) then return; end;

				local storedPos = ent:GetPos();
				local storedAng = ent:GetAngles();
				local storedEye = ent:EyeAngles();

				ent:Spawn();
				ent:SetPos(storedPos);
				ent:SetAngles(storedAng);
				ent:SetEyeAngles(storedEye);
			end
		});

		properties.Add("plyremove", {
			MenuLabel = "Remove",
			Order = 6,
			MenuIcon = "icon16/delete.png",

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "a")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "s") and !Clockwork.player:HasFlags(player, "s")) then return false; end;

				return ent:Alive();
			end,

			Action = function(self, ent)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteUInt(4, 8);
				self:MsgEnd();
			end,

			Dissolve = function(self, ent, dissolveType)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteUInt(dissolveType, 8);
				self:MsgEnd();
			end,

			MenuOpen = function(self, option, ent, trace)
				local subMenu = option:AddSubMenu();

				local option = subMenu:AddOption("Remover Tool", function()
					self:Action(ent);
				end);

				option:SetIcon("icon16/delete.png");

				for i = 1, 4 do
					local option = subMenu:AddOption(dissolveLookup[i], function()
						self:Dissolve(ent, i - 1);
					end);

					option:SetIcon("icon16/lightning.png");
				end;
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();
				local dissolveType = net.ReadUInt(8);

				if (!self:Filter(ent, player)) then return; end;

				if (dissolveType == 4) then
					ent:SetNoDraw(true);
					ent:SetNotSolid(true);

					local effect = EffectData();

					effect:SetEntity(ent);
					util.Effect("entity_remove", effect, true, true);

					timer.Simple(0.5, function()
						ent:KillSilent();
					end);
					Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " removed " .. ent:Name() .. ".");
				else
					Clockwork.entity:Dissolve(ent, dissolveType);
					Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " vaporized " .. ent:Name() .. ".");
				end;
			end
		});

		properties.Add("setarmor", {
			MenuLabel = "Set Armor",
			MenuIcon = "icon16/shield.png",
			Order = 5,

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "o")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "a") and !Clockwork.player:HasFlags(player, "a")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "s") and !Clockwork.player:HasFlags(player, "s")) then return false; end;

				return ent:Alive();
			end,

			Action = function(self, ent)
				-- behold, it's empty, but perhaps it shouldn't be?
			end,

			ArmorSet = function(self, ent, amount)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteUInt(amount, 8);
				self:MsgEnd();
			end,

			MenuOpen = function(self, option, ent, trace)
				local subMenu = option:AddSubMenu();
				local maxArmor = ent:GetMaxArmor();

				if (maxArmor) then
					for i = maxArmor or 100, 0, (math.floor(-maxArmor or 25) / 4) do
						subMenu:AddOption(tostring(i), function()
							self:ArmorSet(ent, i);
						end);
					end;
				else
					for i = 100, 0, -25 do
						subMenu:AddOption(tostring(i), function()
							self:ArmorSet(ent, i);
						end);
					end;
				end;
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();
				local amount = net.ReadUInt(8);

				if (!self:Filter(ent, player)) then return; end;

				ent:SetArmor(amount);
				Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " set " .. ent:Name() .. "'s armor to " .. amount .. ".");
			end
		});

		properties.Add("sethealth", {
			MenuLabel = "Set Health",
			MenuIcon = "icon16/heart.png",
			Order = 4,

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "o")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "a") and !Clockwork.player:HasFlags(player, "a")) then return false; end;
				if (Clockwork.player:HasFlags(ent, "s") and !Clockwork.player:HasFlags(player, "s")) then return false; end;

				return ent:Alive();
			end,

			Action = function(self, ent)

			end,

			HealthSet = function(self, ent, amount)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteUInt(amount, 8);
				self:MsgEnd();
			end,

			MenuOpen = function(self, option, ent, trace)
				local subMenu = option:AddSubMenu();

				for i = ent:GetMaxHealth(), 0, math.floor(-ent:GetMaxHealth() / 4) do
					subMenu:AddOption(tostring(i), function()
						self:HealthSet(ent, i);
					end);
				end;
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity()
				local amount = net.ReadUInt(8)

				if (!self:Filter(ent, player)) then return; end;

				ent:SetHealth(amount);
				Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name() .. " set " .. ent:Name() .. "'s health to " .. amount .. ".");
			end
		});

		properties.Add("playerskin", {
			MenuLabel = "Set Skin",
			Order = 3,
			MenuIcon = "icon16/picture_edit.png",

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "a")) then return false; end;
				if (!ent:SkinCount()) then return false; end;

				return ent:SkinCount() > 1;
			end,

			MenuOpen = function(self, option, ent, tr)
				local subMenu = option:AddSubMenu();
				local num = ent:SkinCount();

				for i = 0, num - 1 do
					local option = subMenu:AddOption("Skin " .. i, function()
						self:SkinSet(ent, i)
					end);

					if (ent:GetSkin() == i) then
						option:SetChecked(true);
					end;
				end;
			end,

			Action = function(self, ent)
				-- what a surprise, empty too!
			end,

			SkinSet = function(self, ent, id)
				self:MsgStart();
				net.WriteEntity(ent);
				net.WriteUInt(id, 8);
				self:MsgEnd();
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();
				local skinid = net.ReadUInt(8);
				local model = ent:GetModel();
				local targetSkins = ent:GetCharacterData("skins") or {};

				if (!self:Filter(ent, player)) then return; end;

				targetSkins[model] = skinid;

				ent:SetSkin(skinid);
				ent:SetCharacterData("skins", targetSkins);
			end
		})

		properties.Add("playerbodygroup", {
			MenuLabel = "Body Groups",
			MenuIcon = "icon16/link_edit.png",
			Order = 2,

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "a")) then return false; end;

				local options = ent:GetBodyGroups();
				if (!options) then return false; end;

				for k, v in pairs(options) do
					if (v.num > 1) then return true; end;
				end;

				return false;
			end,

			Action = function(self, ent)
				-- take a guess
			end,

			SetBodyGroup = function(self, ent, body, id)
				self:MsgStart()
					net.WriteEntity(ent)
					net.WriteUInt(body, 8)
					net.WriteUInt(id, 8);
				self:MsgEnd();
			end,

			-- stolen from gmod github
			MenuOpen = function(self, option, ent, trace)
				local options = ent:GetBodyGroups();
				local subMenu = option:AddSubMenu();

				for k, v in pairs(options) do
					if (v.num <= 1) then continue; end;

					if (v.num == 2) then
						local current = ent:GetBodygroup(v.id);
						local opposite = 1;

						if (current == opposite) then
							opposite = 0;
						end;

						local option = subMenu:AddOption(v.name, function()
							self:SetBodyGroup(ent, v.id, opposite);
						end);

						if (current == 1) then
							option:SetChecked(true);
						end;
					else
						local groups = subMenu:AddSubMenu(v.name);

						for i = 1, v.num do
							local modelname = "model #" .. i;

							if (v.submodels and type(v.submodels[i - 1]) == "string" and v.submodels[i - 1] ~= "") then
								modelname = v.submodels[i - 1];
							end;

							local option = groups:AddOption(modelname, function()
								self:SetBodyGroup(ent, v.id, i - 1);
							end);

							if (ent:GetBodygroup(v.id) == i - 1) then
								option:SetChecked(true);
							end;
						end;
					end;
				end;
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();
				local group = net.ReadUInt(8);
				local id = net.ReadUInt(8);
				local model = ent:GetModel();
				local targetBodyGroups = ent:GetCharacterData("bodygroups") or {};

				if (!self:Filter(ent, player)) then return; end;

				targetBodyGroups[model] = targetBodyGroups[model] or {};
				targetBodyGroups[model][tostring(group)] = id;

				ent:SetCharacterData("bodygroups", targetBodyGroups);
				ent:SetBodygroup(group, id);
			end
		});

		properties.Add("getinfo", {
			MenuLabel = "Get Information",
			Order = 1,
			MenuIcon = "icon16/information.png",

			Filter = function(self, ent, player)
				if (!IsValid(ent)) then return false; end;
				if (!ent:IsPlayer()) then return false; end;
				if (!Clockwork.player:HasFlags(player, "o")) then return false; end;

				return true;
			end,

			Action = function(self, ent)
				self:MsgStart();
				net.WriteEntity(ent);
				self:MsgEnd();
			end,

			Receive = function(self, length, player)
				local ent = net.ReadEntity();

				if (!self:Filter(ent, player)) then return; end;

				Clockwork.player:Notify(player, "Character Name: " .. ent:Name() .. " | Steam Name: " .. ent:SteamName() .. " | Steam ID: " .. ent:SteamID() .. ".");
				Clockwork.player:Notify(player, "Health: " .. ent:Health() .. " | Armor: " .. ent:Armor());
				Clockwork.player:Notify(player, "Premium Status: " .. (ent:IsSubscriber() and "ACTIVE" or "INACTIVE"));
			end
		});
	end;
end;