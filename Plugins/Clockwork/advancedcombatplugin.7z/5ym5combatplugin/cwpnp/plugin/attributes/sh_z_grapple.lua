--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Grapple");
COMMAND.tip = "Rolls 1d10 + your Melee stat. Used to grab a target, preventing them from running and allowing more powerful strikes";

-- Called when the command has been run.
function COMMAND:OnRun(player)
	local number = 10;
	local attribute = Clockwork.attributes:Fraction(player, ATB_MELEE, 10);
	local cyberware = Clockwork.attributes:Fraction(player, ATB_CMELEE, 10)
	Clockwork.chatBox:AddInRadius(player, "roll", "has rolled "..math.random(1, number) + attribute + cyberware .." for Grapple ",
		player:GetPos(), Clockwork.config:Get("talk_radius"):Get() * 2);
end;

COMMAND:Register();