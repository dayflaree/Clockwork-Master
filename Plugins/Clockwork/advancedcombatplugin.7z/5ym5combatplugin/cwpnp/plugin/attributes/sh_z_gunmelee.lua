--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("GunBash");
COMMAND.tip = "Rolls 1d10 + 75% Melee + 25% Firearms. Used for all manner of attacks using your gun as a melee weapon, swinging, bashing, etc.";

-- Called when the command has been run.
function COMMAND:OnRun(player)

				bParts = {}
                bParts[1] = "Skull"
                bParts[2] = "Head Glance"
                bParts[3] = "Eye"
                bParts[4] = "Nose"
                bParts[5] = "Mouth"
                bParts[6] = "Neck Flesh"
                bParts[7] = "Neck"
                bParts[8] = "Larynx"
                bParts[9] = "Neck Spine"
                bParts[10] = "Base of Neck"
                bParts[11] = "Left Shoulder"
                bParts[12] = "Right Shoulder"
                bParts[13] = "Left Shoulder Socket"
                bParts[14] = "Right Shoulder Socket"
                bParts[15] = "Left Shoulder Glance"
                bParts[16] = "Right Shoulder Glance"
                bParts[17] = "Left Upper Arm Bone"
                bParts[18] = "Right Upper Arm Bone"
                bParts[19] = "Left Upper Arm Flesh"
                bParts[20] = "Right Upper Arm Flesh"
                bParts[21] = "Left Arm Glance"
                bParts[22] = "Right Arm Glance"
                bParts[23] = "Left Elbow"
                bParts[24] = "Right Elbow"
                bParts[25] = "Left Forearm Flesh"
                bParts[26] = "Right Forearm Flesh"
                bParts[27] = "Left Forearm Bone"
                bParts[28] = "Right Forearm Bone"
                bParts[29] = "Left Hand"
                bParts[30] = "Right Hand"
                bParts[31] = "Left Scapula"
                bParts[32] = "Right Scapula"
                bParts[33] = "Heart"
                bParts[34] = "Left Lung"
                bParts[35] = "Right Lung"
                bParts[36] = "Upper Chest Spine"
                bParts[37] = "Lower Chest Spine"
                bParts[38] = "Abdomen Spine"
                bParts[39] = "Left Upper Chest Rib"
                bParts[40] = "Right Upper Chest Rib"
                bParts[41] = "Left Lower Chest Rib"
                bParts[42] = "Right Lower Chest Rib"
                bParts[43] = "Liver"
                bParts[44] = "Kidney"
                bParts[45] = "Stomach"
                bParts[46] = "Spleen"
                bParts[47] = "Large Intestine"
                bParts[48] = "Small Intestine"
                bParts[49] = "Left Pelvis"
                bParts[50] = "Center Pelvis"
                bParts[51] = "Right Pelvis"
                bParts[52] = "Torso Glance"
                bParts[53] = "Left Hip"
                bParts[54] = "Right Hip"
                bParts[55] = "Left Hip Socket"
                bParts[56] = "Right Hip Socket"
                bParts[57] = "Left Upper Leg Flesh"
                bParts[58] = "Right Upper Leg Flesh"
                bParts[59] = "Left Upper Leg Femur"
                bParts[60] = "Right Upper Leg Femur"
                bParts[61] = "Left Leg Glance"
                bParts[62] = "Right Leg Glance"
                bParts[63] = "Left Knee"
                bParts[64] = "Right Knee"
                bParts[65] = "Left Shin Flesh"
                bParts[66] = "Right Shin Flesh"
                bParts[67] = "Left Tibia"
                bParts[68] = "Right Tibia"
                bParts[69] = "Left Ankle"
                bParts[70] = "Right Ankle"
                bParts[71] = "Left Foot"
                bParts[72] = "Right Foot"

				
	local number = 10;
	local attribute = Clockwork.attributes:Fraction(player, ATB_MELEE, 10)*0.75;
	local attribute1 = Clockwork.attributes:Fraction(player, ATB_FIREARMS, 10)*0.25;
	local cyberware = Clockwork.attributes:Fraction(player, ATB_CMELEE, 10)*0.75;
	local cyberware1 = Clockwork.attributes:Fraction(player, ATB_CFIREARMS, 10)*0.25;
	Clockwork.chatBox:AddInRadius(player, "roll", "has rolled ".. math.ceil(math.random(1, number) + attribute + attribute1 + cyberware + cyberware1) .." for Gun Bash at " .. bParts[math.random(1, 72)],
		player:GetPos(), Clockwork.config:Get("talk_radius"):Get() * 2);
end;

COMMAND:Register();