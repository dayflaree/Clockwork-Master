--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Reflexes";
	ATTRIBUTE.maximum = 10;
	ATTRIBUTE.uniqueID = "ref";
	ATTRIBUTE.description = "Affects how fast you can react (Who gets the first attack of a fight)";
	ATTRIBUTE.isOnCharScreen = true;
ATB_REFLEXES = Clockwork.attribute:Register(ATTRIBUTE);

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Reflexes");
COMMAND.tip = "Rolls 1d10 + your Reflexes stat.";

-- Called when the command has been run.
function COMMAND:OnRun(player)

	local number = 10;
	local attribute = Clockwork.attributes:Fraction(player, ATB_REFLEXES, 10);
	local cyberware = Clockwork.attributes:Fraction(player, ATB_CREFLEXES, 10)
	Clockwork.chatBox:AddInRadius(player, "roll", "has rolled "..math.random(1, number) + attribute + cyberware .." for Reflexes.",
		player:GetPos(), Clockwork.config:Get("talk_radius"):Get() * 2);
end;

COMMAND:Register();