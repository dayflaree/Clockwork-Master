--[[
	Created by 5ym5, please make it better and invite me to your server ;) 
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Cyber Reflexes";
	ATTRIBUTE.maximum = 10;
	ATTRIBUTE.uniqueID = "cref";
	ATTRIBUTE.description = "Used for cyberware stat bonuses";
	ATTRIBUTE.isOnCharScreen = false;
ATB_CREFLEXES = Clockwork.attribute:Register(ATTRIBUTE);
