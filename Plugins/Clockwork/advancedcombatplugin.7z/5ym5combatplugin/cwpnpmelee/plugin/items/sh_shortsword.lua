--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Shortsword";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding [2]] [One-Handed] [Non-Concealable] [C-1] A short sword. Any more description needed?";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();