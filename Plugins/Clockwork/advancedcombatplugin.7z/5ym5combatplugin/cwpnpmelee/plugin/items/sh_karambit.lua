--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Karambit";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding [2]] [One-Handed] [Concealable] [C-1] A claw-shaped knife with a finger ring at the bottom.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();