--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Shillelagh";
ITEM.cost = 200;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Crippling [3]] [Two-Handed] [Non-Concealable] [C-2] A slender metal object with a firm knot at the top. Looks like it'd hurt if you hit someone with it.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();