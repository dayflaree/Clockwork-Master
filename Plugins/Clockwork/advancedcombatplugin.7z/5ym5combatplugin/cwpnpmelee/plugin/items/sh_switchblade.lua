--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Switchblade";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding [2]] [One-Handed] [Concealable] [C-1] A gentleman's knife, sleek and dangerous with a lightning fast spring.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();