--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Ice Pick";
ITEM.cost = 75;
ITEM.model = "models/weapons/w_extreme_ratio.mdl";
ITEM.weight = 0.2;
ITEM.category = "Melee";
ITEM.business = false;
ITEM.description = "[Wounding [2]] [One-Handed] [Non-Concealable] [C-4] Climb a glacier & defend yourself on the harsh streets.";
 -- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
ITEM:Register();