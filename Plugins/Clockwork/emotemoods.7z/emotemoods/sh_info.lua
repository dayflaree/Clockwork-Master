--[[
	� 2012 Slidefuse LLC
	This plugin is released under the MIT license. Do whatever!
--]]

local PLUGIN = PLUGIN

PLUGIN.name = "Emote Moods"
PLUGIN.author = "Spencer Sharkey"
PLUGIN.description = "With this plugin, characters can set their mood to a preset from predefined values."