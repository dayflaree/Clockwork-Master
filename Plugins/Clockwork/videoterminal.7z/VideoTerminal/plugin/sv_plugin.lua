--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

PLUGIN.cameraList = {};

function PLUGIN:SaveVideoTerminal()
	local videoterminals = {};
	
	for k, v in pairs(ents.FindByClass("cw_videoterminal")) do
		videoterminals[#videoterminals + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos(),
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/videoterminals/"..game.GetMap(), videoterminals);
end;

function PLUGIN:LoadVideoTerminal()
	local videoterminals = Clockwork.kernel:RestoreSchemaData("plugins/videoterminals/"..game.GetMap());
	
	for k, v in pairs(videoterminals) do
		local entity = ents.Create("cw_videoterminal");
		
		entity:SetPos(v.position);
		entity:Spawn();
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles);
		end;
	end;
end;

function PLUGIN:GetCameraData( id )
	for k,v in pairs(self.cameraList) do
		if (v.id == id) then
			return v;
		end;
	end;
	
	return false;
end;

function PLUGIN:EnterInVideoTerminal( player, id )
	local fault = Clockwork.plugin:Call("CanEnterInVideoTerminal", player);
	
	if (fault and id) then
		local camera = self:GetCameraData( id );

		if (camera) then
			player:SetSharedVar("inVideo", 1);
			player:SetSharedVar("CameraID", camera.id);
			player:SetSharedVar("CameraName", camera.name);
			player:SetViewEntity( camera.entity );
			player:SetMoveType(MOVETYPE_NONE);
			Clockwork.datastream:Start( player, "CamHide",  true );
		end;
	else
		Clockwork.player:Notify(player, "You cannot use this camera!");
	end;
end;

function PLUGIN:LeaveVideoTerminal( player )
	local fault = Clockwork.plugin:Call("CanLeaveVideoTerminal", player);
	
	if (fault) then
		player:SetSharedVar("inVideo", 0);
		player:SetSharedVar("CameraID", 0);
		player:SetSharedVar("CameraName", "#ERROR#");
		player:SetViewEntity( player );
		player:SetMoveType(MOVETYPE_WALK);
		Clockwork.datastream:Start( player, "CamHide", false );
	end;
end;
