--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:GetProgressBarInfo()
	local action, percentage = Clockwork.player:GetAction(Clockwork.Client, true);

	if (!Clockwork.Client:IsRagdolled()) then
		if (action == "cam_connecting") then
			return {text = "Connectig.", percentage = percentage, flash = percentage < 10};
		end;
	end;
end;

function PLUGIN:PlayerCanSeeBars( class )
	if (class == "top") then
		if (Clockwork.Client:GetSharedVar("inVideo") != 0 ) then
			return false;
		end;
	end;
end;

function PLUGIN:GetScreenTextInfo()
	if (Clockwork.Client:GetSharedVar("inVideo") != 0 ) then
		local blackFadeAlpha = Clockwork.kernel:GetBlackFadeAlpha();
		local text = Clockwork.Client:GetSharedVar("CameraName");
		
		return {
			alpha = 255 - blackFadeAlpha,
			title = text
		};
	end;
end;

Clockwork.datastream:Hook("CamList", function(data)

	options = {};
	for k,v in pairs(data) do
		options[v.name] = function() Clockwork.datastream:Start("CamShow", v.id) end;
	end;
	
	options["Exit"] = "none";
	
	local menuPanel = Clockwork.kernel:AddMenuFromData(nil, options);
	
	Clockwork.kernel:RegisterBackgroundBlur(menuPanel, SysTime());
	Clockwork.kernel:SetTitledMenu(menuPanel, "VIDEO TERMINAL");
	
	menuPanel:Open();
end);

Clockwork.datastream:Hook("CamHide", function(data)
	for k,v in pairs( ents.GetAll() ) do
		if v:IsNPC() then
			local class = v:GetClass();
			
			if (class == "npc_combine_camera") then
				v:SetNoDraw( data);
			end;
		end;
	end;
end);
