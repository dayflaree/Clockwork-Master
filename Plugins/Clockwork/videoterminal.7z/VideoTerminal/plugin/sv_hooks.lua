--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitPostEntity()
	self:LoadVideoTerminal();
end;

function PLUGIN:PostSaveData()
	self:SaveVideoTerminal();
end;


function PLUGIN:PlayerCanUseVideoTerminal(player, terminal)
	if (!player:Alive() or player:IsRagdolled() or player:GetSharedVar("tied") != 0) then
		return false;
	end;
	
	return true;
end;

function PLUGIN:PlayerUseVideoTerminal(player, terminal)
	Clockwork.datastream:Start( player, "CamList", self.cameraList );
end;

function PLUGIN:CanEnterInVideoTerminal( player )
	if (!player:Alive() or player:IsRagdolled() or player:GetSharedVar("tied") != 0 or player:GetSharedVar("inVideo") == 1) then
		return false;
	end;
	
	return true;
end;

function PLUGIN:PlayerCharacterLoaded(player)
	player:SetSharedVar("inVideo", 0);
	player:SetSharedVar("CameraID", 0);
	player:SetSharedVar("CameraName", "#ERROR#");
end;

function PLUGIN:PlayerCanSwitchCharacter(player, character)
	if (player:GetSharedVar("inVideo") != 0) then
		return false;
	end;
end;

function PLUGIN:CanLeaveVideoTerminal( player)
	if (player:GetSharedVar("inVideo") != 0) then
		return true;
	end;
	
	return false;
end;

function PLUGIN:Tick()
	for k,v in pairs( ents.GetAll() ) do
		if v:IsNPC() then
			local class = v:GetClass();
			
			if (class == "npc_combine_camera" and !v.videoCamera) then
				v.videoCamera = ents.Create( "cw_videocamera" );
				v.videoCamera:SetCameraParent(v);
				v.videoCamera:Spawn();
				v.videoCamera:SetColor(255, 255, 255, 0) 
				
				table.insert(self.cameraList,{
					entity = v.videoCamera,
					id = table.Count(self.cameraList) + 1,
					name = "Camera #"..tostring(table.Count(self.cameraList) + 1)
				});
				
			end;
		end;
	end;
end;

function PLUGIN:KeyRelease(player, key)
	if (key == IN_USE) then
		if (player:GetSharedVar("inVideo") != 0) then
			self:LeaveVideoTerminal( player );
		end;
	end;
end;

function PLUGIN:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	self:LeaveVideoTerminal( player );
end;


Clockwork.datastream:Hook("CamShow", function(player, data)
	Clockwork.player:SetAction(player, "cam_connecting", 1);
	Clockwork.player:EntityConditionTimer(player, player:GetEyeTraceNoCursor().Entity, player:GetEyeTraceNoCursor().Entity, 1, 192, function()
		return player:Alive() and !player:IsRagdolled() and player:GetSharedVar("tied") == 0 and Clockwork.plugin:Call("PlayerCanUseVideoTerminal", player, self);
	end, function(success)
		if (success) then
			Clockwork.plugin:Call("EnterInVideoTerminal", player, data);
		end;
		
		Clockwork.player:SetAction(player, "cam_connecting", false);
	end);
end);