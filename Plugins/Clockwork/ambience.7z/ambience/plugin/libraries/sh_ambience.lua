--[[ 
	This library was created by NightAngel for use by developers and server owners.
	
	Do NOT redistribute or try to claim this work as your own. 
	If you see someone doing so, please notify me at http://steamcommunity.com/id/NA1455/.
--]]

local Clockwork = Clockwork;

Ambience = Clockwork.kernel:NewLibrary("Ambience");

if (CLIENT) then

Ambience.stored = {};

--[[ Debugging concommands below, uncomment these for development/testing purposes only.

-- A concommand for debugging purposes.
concommand.Add( "ambdebug", function()
	print("**------AMBIENCE DEBUG INFO------**");
	print("Current Mood: "..Ambience:GetMood(Clockwork.Client));
	print(Ambience:GetRandom(Ambience:GetMood(Clockwork.Client)));

	if (!Ambience:GetSongs() or #Ambience:GetSongs() <= 2) then
		print("There are not enough songs for the plugin to function!");
	else
		print("There are enough songs for the plugin to function.");
	end;

	print("--Song Table--");
	PrintTable(Ambience:GetSongs());
	print("**----------------------------**");
end )

-- A concommand to manually switch the client's mood for debug purposes.
concommand.Add("ambsetmood", function(ply, cmd, args, argStr)
	print(args[1]);
	Ambience:SetMood(Clockwork.Client, args[1]);
	print("Ambience Mood set to "..args[1].."!");
end)

--]]

-- A function to register a song.
function Ambience:Register(songType, songString)
	table.insert(self.stored, {songType, songString});
end;

--[[ How to add songs for use with this library.

Simply add the sound to the sounds folder in your server/addon's directory, then use Ambience:Register(moodString, songString) in a
CLIENTSIDE SCRIPT like the examples below. "default" is the default mood that a player is in, and you need -at least- two songs in a 
mood for the library to function properly.

Ambience:Register("default", "exampleRP/music/benny_hill_theme.mp3");
Ambience:Register("default", "exampleRP/music/illuminati.mp3");
Ambience:Register("combat", "exampleRP/music/shit_going_down.mp3");
Ambience:Register("combat", "exampleRP/music/you_should_get_it_by_now.mp3");

--]]

-- Called when a calm song should be played.
Clockwork.datastream:Hook("StartSong", function(data)
	if (!Ambience:GetSongs() or #Ambience:GetSongs() <= 2) then return false end;
	Ambience:StartSong(Ambience:GetRandom(Ambience:GetMood(Clockwork.Client)));
end);

-- A function to get the song table.
function Ambience:GetSongs()
	return self.stored;
end;

-- A function to find all of a certain type.
function Ambience:FindType(songType)
	local songTable = {};
	for k, v in ipairs(self:GetSongs()) do
		if (v[1] == songType) then
			songTable[#songTable+1] = v[2];
		end;
	end;
	
	return songTable;
end;

-- A function to get a random song of a certain type.
function Ambience:GetRandom(songType)
	local songTable = self:FindType(songType);

	for k, v in ipairs(songTable) do
		if (v == self.lastSongString) then
			table.remove(songTable, k);
		end;
	end;

	local newSong = songTable[math.random(1,#songTable)];

	self.lastSongString = newSong;

	return newSong;
end;

-- A function to transition between songs.
function Ambience:StartSong(song)
	if (CW_CONVAR_MUSIC:GetInt() == 1) then
		if (self.currentSong) then
			self.lastSong = self.currentSong;
			self.currentSong = nil;
			self.lastSong:FadeOut(3);
			timer.Simple(4, function()
				self.lastSong:Stop();
			end);
		end;

		self.currentSong = CreateSound(Clockwork.Client, song);
		self.currentSong:PlayEx(0, 100);
		self.currentSong:ChangeVolume(CW_CONVAR_MUSICVOLUME:GetFloat(), 3);

		self.songDuration = CurTime() + math.random(SoundDuration(song) * 0.90, SoundDuration(song) - 3);
	end;	
end;

end;

-- A function to get a player's mood.
function Ambience:GetMood(player)
	local mood = player:GetNWString("AmbMood");

	if (mood == "") then
		mood = "default";
	end;

	return mood;
end;

-- A function to set a player's mood.
function Ambience:SetMood(player, mood)
	if (!Ambience:GetSongs() or #Ambience:GetSongs() <= 2) then return false end;

	local songCheck = Ambience:FindType(mood);

	if (!songCheck or #songCheck < 2) then
		return print("The desired mood has less than two songs, mood was not changed for player: "..player:Name())
	end;	

	player:SetNWString("AmbMood", mood);

	if (CLIENT) then
		return self:StartSong(self:GetRandom(self:GetMood(Clockwork.Client)));
	else
		return Clockwork.datastream:Start(player, "StartSong");
	end;
end;