--[[ 
	This library was created by NightAngel for use by developers and server owners.
	
	Do NOT redistribute or try to claim this work as your own. 
	If you see someone doing so, please notify me at http://steamcommunity.com/id/NA1455/.
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

--Called when a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (firstSpawn) then
		Clockwork.datastream:Start(player, "StartSong")
	end;
end;