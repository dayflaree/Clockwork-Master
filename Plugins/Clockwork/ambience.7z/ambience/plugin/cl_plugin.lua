--[[ 
	This library was created by NightAngel for use by developers and server owners.
	
	Do NOT redistribute or try to claim this work as your own. 
	If you see someone doing so, please notify me at http://steamcommunity.com/id/NA1455/.
--]]

local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

Clockwork.setting:AddCheckBox("Music", "Enable background music.", "cwMusicOn", "Whether or not to play background music.");
Clockwork.setting:AddNumberSlider("Music", "Music Volume:", "cwMusicVolume", 0, 1, 2, "The volume to play background music at.");

--[[
Ambience:Register("calm", "tesrp/music/tesv_dawn.mp3");
Ambience:Register("calm", "tesrp/music/tesv_solitude.mp3");
Ambience:Register("calm", "tesrp/music/tesv_whiteriver.mp3");
Ambience:Register("calm", "tesrp/music/tesv_distanthorizons.mp3");
Ambience:Register("indoor", "tesrp/music/tesv_banneredmare.mp3");
--]]