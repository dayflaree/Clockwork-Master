--[[ 
	This library was created by NightAngel for use by developers and server owners.
	
	Do NOT redistribute or try to claim this work as your own. 
	If you see someone doing so, please notify me at http://steamcommunity.com/id/NA1455/.
--]]

local Clockwork = Clockwork;

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");