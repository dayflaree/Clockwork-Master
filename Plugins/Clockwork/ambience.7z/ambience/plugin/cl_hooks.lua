--[[ 
	This library was created by NightAngel for use by developers and server owners.
	
	Do NOT redistribute or try to claim this work as your own. 
	If you see someone doing so, please notify me at http://steamcommunity.com/id/NA1455/.
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Called when the client initializes.
function PLUGIN:Initialize()
	CW_CONVAR_MUSIC = Clockwork.kernel:CreateClientConVar("cwMusicOn", 1, true, true);
	CW_CONVAR_MUSICVOLUME = Clockwork.kernel:CreateClientConVar("cwMusicVolume", 0.3, true, true);
end;

--Called every think.
function PLUGIN:Think()
	if (Clockwork.kernel:IsChoosingCharacter()) then
		if (Ambience.currentSong) then
			if (Ambience.currentSong:IsPlaying()) then
				Ambience.currentSong:Stop();
			end
		end;
	else
		if (Ambience.songDuration) then
			if (Ambience.songDuration < CurTime()) then
				Ambience:StartSong(Ambience:GetRandom(Ambience:GetMood(Clockwork.Client)));
			end;
		end;
	end;
end;

-- Called when a ConVar has changed.
function PLUGIN:ClockworkConVarChanged()
	if (CW_CONVAR_MUSIC:GetInt() == 1) then
		if (Ambience.currentSong) then
			if (Ambience.currentSong:IsPlaying()) then
				Ambience.currentSong:ChangeVolume(CW_CONVAR_MUSICVOLUME:GetFloat(),1)
			end;
		else
			Ambience:StartSong(Ambience:GetRandom(Ambience:GetMood(Clockwork.Client)))
		end;
	else
		if (Ambience.currentSong) then
			Ambience.currentSong:Stop()
		end;
	end;
end;