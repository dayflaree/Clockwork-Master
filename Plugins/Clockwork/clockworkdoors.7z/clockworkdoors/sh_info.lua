--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Clockwork Doors";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "Adds a pretty gradient behind the doors like they do in that Clockwork thing.";