--[[
	Slidefuse LLC Made This. http://slidefuse.com
	Have fun with your crap openAura
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Override OOC";
PLUGIN.author = "Spencer Sharkey";
PLUGIN.description = "This simple plugin makes sure OOC is enabled for everyone, all the time.";