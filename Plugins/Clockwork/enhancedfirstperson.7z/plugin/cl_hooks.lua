local PLUGIN = PLUGIN;
local Clockwork = Clockwork;
Clockwork.kernel = Clockwork.kernel;

-- Called when the client initializes.
function PLUGIN:Initialize()
	LocalPlayer():ConCommand( "cwHeadBobScale 0" )
end;