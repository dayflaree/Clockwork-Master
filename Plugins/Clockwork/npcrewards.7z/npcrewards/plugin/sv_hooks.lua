--[[
	Made by Tyler with <3

	For support go to: http://steamcommunity.com.id/roobicks-coob
	or email me at: tyler.j.georgiadis@gmail.com
--]]

local PLUGIN = PLUGIN;

NPCS = { -- by default all the alien NPCs are set
	npc_zombie,
	npc_fastzombie,
	npc_poisonzombie,
	npc_headcrab_black,
	npc_antlion,
	npc_antlionguard,
	npc_barnacle,
	npc_headcrab_fast,
	npc_fastzombie_torso,
	npc_headcrab,
	npc_zombie_torso,
	-- Get NPC names by navigating to the NPC in the spawn menu, rightclicking and pressing "Copy to Clipboard".
	-- Unlike models, NPCs do not print a filepath, so don't worry.
};
REWARDS = {
	--[[ Insert item names here.
		Use the file name of the item without sh_. 
		This NEEDS to be a string.]]
};

Clockwork.config:AddToSystem("Give Cash Reward", "npckills_give_cash", "Weather or not to allow players to receive immediate cash rewards for killing NPCs.", 0, 1, 0);
Clockwork.config:AddToSystem("Cash Reward Minimum", "npckills_cash_minimum", "The minimum amount of cash a player can receive upon killing NPCs.", 0, 1024);
Clockwork.config:AddToSystem("Cash Reward Maximum", "npckills_cash_maximum", "The maximum amount of cash a player can receive upon killing NPCs,", 0, 1024);

function PLUGIN:OnNPCKilled(npc, attacker, inflictor)

	-- For debugging purposes, because I can.
	attacker:PrintMessage(HUD_PRINTCONSOLE, "Debug: NPC Kill Rewards Initialized");

	-- Get the config values:
	local giveCashReward = Clockwork.config:Get("npckills_give_cash"):GetBool();
	local cashMinimum = Clockwork.config:Get("npckills_cash_minimum"):GetNumber();
	local cashMaximum = Clockwork.config:Get("npckills_cash_maximum"):GetNumber();

	-- Take a random reward:
	local reward = REWARDS[ math.random( #REWARDS ) ];
	local itemSpawn = Clockwork.item:CreateInstance(tostring(reward));

	
	if attacker:IsPlayer() and npc in NPCS then
		local npcPos = npc:GetPos();
		itemSpawn:SetPos(npcPos);
		itemSpawn:Spawn();

		if giveCashReward then
			local cashReward = math.random(cashMinimum, cashMaximum);
			Clockwork.player:GiveCash(attacker, cashReward);
			Clockwork.player:Notify(attacker, "You were given "..cashReward.." "..string.lower(NAME_CASH).." for killing "..npc..".");
			attacker:PrintMessage(HUD_PRINTCONSOLE, "Debug: "..cashReward.." given to "..attacker.." for killing "..npc..".");
		else
		    attacker:PrintMessage(HUD_PRINTCONSOLE, "Debug: No cash given due to set user config.");
		end
	end
end