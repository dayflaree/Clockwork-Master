--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("AddNPC");

COMMAND.tip = "Add an NPC to the table.";
COMMAND.text = "<string NPC Name>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.access = "s"
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	-- Clockwork.player:NotifyAll(table.concat(arguments, " "));
	Clockwork.player:Notify(player, "Added "..arguments[1].." to the NPC table.")
	table.insert(NPCS, arguments[1])
end;

COMMAND:Register();