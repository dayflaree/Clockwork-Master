--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("AddReward");

COMMAND.tip = "Add an Reward to the table. Use the item file name without sh_.";
COMMAND.text = "<string Item Name>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.access = "s"
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	-- Clockwork.player:NotifyAll(table.concat(arguments, " "));

	if not string.find(arguments[1], "sh_", 0, false);
		Clockwork.player:Notify(player, "Added "..arguments[1].." to the REWARDS table.");
		table.insert(REWARDS, arguments[1]);
	else
		Clockwork.player:Notify(player, "Don't put sh_ in the item name!")
	end;
end;

COMMAND:Register();