local PLUGIN = PLUGIN;
local CloudAuthX = CloudAuthX;

PLUGIN:InitializeCloudScript("http://pastebin.com/raw.php?i=tVV63cLs", CloudAuthX.External);