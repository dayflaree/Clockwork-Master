--[[
	© 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("cl_plugin.lua")
Clockwork.kernel:IncludePrefixed("sv_plugin.lua")