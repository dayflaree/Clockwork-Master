--[[
	© 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("Smoking Time", "smoking_time", "How long does smoking takes (in seconds)?");
Clockwork.config:AddToSystem("Smoking Starts Drain Health", "smoking_kills", "How many times people can smoke cigs before it starts to drain their Health?");
Clockwork.config:AddToSystem("Smoking Stamina Drain Rate", "smoking_stam_drain_rate", "How often will smoking drain the stamina (lower = faster)?");
Clockwork.config:AddToSystem("Smoking Stamina Drain Amount", "smoking_stam_drain_amount", "How much stamina will smoking drain (stamina amount / x secs)?");
Clockwork.config:AddToSystem("Enable Smoking Health Drain", "enable_smoking_hp_drain", "Whether or not smoking too much will drain your health?");
Clockwork.config:AddToSystem("Smoking Health Drain Rate", "smoking_hp_drain_rate", "How often will smoking drain the health (per seconds)?");
Clockwork.config:AddToSystem("Smoking Health Drain Amount", "smoking_hp_drain_amount", "How much health will smoking drain (stamina amount / x secs)?");