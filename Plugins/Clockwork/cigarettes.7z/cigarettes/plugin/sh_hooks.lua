--[[
	© 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

local PLUGIN = PLUGIN;

local function GetClientSideInfo(itemTable)
	local quantity = itemTable:GetData("Quantity");
	local clientSideInfo = "";
	
	clientSideInfo = Clockwork.kernel:AddMarkupLine(
		clientSideInfo, "Quantity: "..quantity, Color(255,255,255,255)
	);
	
	return (clientSideInfo != "" and clientSideInfo);
end;

-- Copy-Pasta ;D
-- I know I could make it one function, but... Nevermind.
local function GetClientSideInfoPipe(itemTable)
	local tobacco = itemTable:GetData("Tobacco");
	local clientSideInfo = "";
	
	clientSideInfo = Clockwork.kernel:AddMarkupLine(
		clientSideInfo, "Tobacco: "..tobacco.."%", Color(255,255,255,255)
	);
	
	return (clientSideInfo != "" and clientSideInfo);
end;

-- Called when a Clockwork item has initialized.
-- I know this code is awfully written, but yeah, don't blame me for that. At least it works smooth 'nuff.
function cwCigarettes:ClockworkItemInitialized(itemTable)
	if (Clockwork.item:FindByID("cig_pack") == itemTable) then
		if (itemTable.GetClientSideInfo) then
			itemTable.OldGetClientSideInfo = itemTable.GetClientSideInfo;
			itemTable.NewGetClientSideInfo = GetClientSideInfo;
			itemTable.GetClientSideInfo = function(itemTable)
				local existingText = itemTable:OldGetClientSideInfo();
				local additionText = itemTable:NewGetClientSideInfo() or "";
				local totalText = (existingText and existingText.."\n" or "")..additionText;
				
				return (totalText != "" and totalText);
			end;
		else
			itemTable.GetClientSideInfo = GetClientSideInfo;
		end;
		
		itemTable:AddData("Quantity", 10, true);
	elseif (Clockwork.item:FindByID("cig_pipe") == itemTable) then
		if (itemTable.GetClientSideInfo) then
			itemTable.OldGetClientSideInfo = itemTable.GetClientSideInfoPipe;
			itemTable.NewGetClientSideInfo = GetClientSideInfoPipe;
			itemTable.GetClientSideInfoPipe = function(itemTable)
				local existingText = itemTable:OldGetClientSideInfo();
				local additionText = itemTable:NewGetClientSideInfo() or "";
				local totalText = (existingText and existingText.."\n" or "")..additionText;
				
				return (totalText != "" and totalText);
			end;
		else
			itemTable.GetClientSideInfoPipe = GetClientSideInfoPipe;
		end;
		
		itemTable:AddData("Tobacco", 100, true);
	end;
end;