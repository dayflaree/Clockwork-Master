--[[
	� 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

Clockwork.config:Add("smoking_time", 15);
Clockwork.config:Add("smoking_kills", 3); -- :D
Clockwork.config:Add("enable_smoking_hp_drain", true, true);
Clockwork.config:Add("smoking_stam_drain_rate", 3);
Clockwork.config:Add("smoking_stam_drain_amount", 4);
Clockwork.config:Add("smoking_hp_drain_rate", 3);
Clockwork.config:Add("smoking_hp_drain_amount", 1);