--[[
	� 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Smoked Cigarette";
ITEM.weight = 0.02;
ITEM.model = "models/avoxgaming/mrp/jake/props/gasmask.mdl";
ITEM.business = true;
ITEM.access = "V";
ITEM.uniqueID = "cig_pipe_smoked";
ITEM.description = "A short paper pipe with one of it's ends burnt.";
ITEM.category = "Cigarettes";

function ITEM:OnDrop(player, position)
	return true;
end;

ITEM:Register();