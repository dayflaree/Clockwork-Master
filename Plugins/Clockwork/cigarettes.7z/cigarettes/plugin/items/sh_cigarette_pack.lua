--[[
	� 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Cigarettes Pack";
ITEM.weight = 0.2;
ITEM.cost = 500; -- make it expensive, we don't want all these shitizens to smoke.
ITEM.model = "models/avoxgaming/mrp/jake/props/gasmask.mdl";
ITEM.business = true;
ITEM.access = "V";
ITEM.uniqueID = "cig_pack";
ITEM.description = "A small box filled with cigarettes.";
ITEM.useText = "Open";
ITEM.category = "Cigarettes";

-- Called when item is used.
function ITEM:OnUse(player, itemEntity)
	if (player:Alive() and !player:IsRagdolled()) then
		local quantity = ITEM:GetData("Quantity");
		
		-- I'm kinda proud for that one.
		if (quantity > 0) then
			player:GiveItem(Clockwork.item:CreateInstance("cig_pipe"))
			Clockwork.player:Notify(player, "You took out one cigarette.");
			
			if (SERVER) then
				ITEM:SetData("Quantity", quantity - 1, 0));
			end;
			
			return false; -- we don't want the item to disappear.
		else
			player:GiveItem(Clockwork.item:CreateInstance("cig_pack_empty"));
			Clockwork.player:Notify(player, "This cigarettes pack is empty!");
			
			-- not returning anything, we want the item to disappear.
		end;
	end;
		
	Clockwork.player:Notify(player, "You can't do that right now!");
	return false; -- we don't want it to disappear in case of error either.
end;

-- Called when item is dropped.
function ITEM:OnDrop(player, position)
	return true;
end;

ITEM:Register();