--[[
	� 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Cigarette";
ITEM.weight = 0.02;
ITEM.model = "models/avoxgaming/mrp/jake/props/gasmask.mdl";
ITEM.business = true;
ITEM.access = "V";
ITEM.uniqueID = "cig_pipe";
ITEM.description = "A long paper pipe filled with tabacco, light it from the right end.";
ITEM.useText = "Smoke";
ITEM.category = "Cigarettes";
ITEM.isAttachment = true;
ITEM.attachmentBone = "ValveBiped.Bip01_Head1";
ITEM.attachmentOffsetAngles = Angle(-90, -84.71, 0);
ITEM.attachmentOffsetVector = Vector(0, 7.5, -64);

function ITEM:AdjustAttachmentOffsetInfo(player, entity, info)
	if ( string.find(player:GetModel(), "female") ) then
		info.offsetVector = Vector(0, 7.5, -65);
	elseif (string.find(player:GetModel(), "male_01")) then
		info.offsetVector = Vector(0, 7.9, -64);
	elseif (string.find(player:GetModel(), "male_03")) then
		info.offsetVector = Vector(0, 7.9, -64);
	elseif (string.find(player:GetModel(), "male_05")) then
		info.offsetVector = Vector(0, 6.9, -64);
	elseif (string.find(player:GetModel(), "male_06")) then
		info.offsetVector = Vector(0, 8.5, -64);
	elseif (string.find(player:GetModel(), "male_07")) then
		info.offsetVector = Vector(0, 6.9, -64);
	end;
end;

function ITEM:OnUse(player, itemEntity)
	if (!Schema:PlayerIsCombine(player)) then
		if (player:HasItemByID("cig_lighter")) then
			if (player:Alive() and !player:IsRagdolled()) then
				player:SetCharacterData("smoking", true);
				
				timer.Create("smoking_stam", Clockwork.config:Get("smoking_stam_drain_rate"):Get(), 5, function()
					player:SetCharacterData("Stamina", player:GetCharacterData("Stamina") - Clockwork.config:Get("smoking_stam_drain_amount"):Get());
				end;
				
				Clockwork.player:Notify(player, "You are now smoking. To take a cigarette out of your mouth - unequip it.");
			
				return true;
			end;
		else
			Clockwork.player:Notify(player, "You need a lighter in order to smoke that cigarette!");
			
			return false;
		end;
		
		Clockwork.player:Notify(player, "You can't do that right now!");
	else
		Clockwork.player:Notify(player, "Combine units can't smoke cigarettes!");
	end;
	
	return false;
end;

function ITEM:GetAttachmentVisible(player, entity)
	if (player:GetCharacterData("smoking")) then
		return true;
	end;
end;

function ITEM:HasPlayerEquipped(player, arguments)
	if (!player:GetCharacterData("smoking") then
		player:SetCharacterData("smoking", true);
	end;
	
	return true;
end;

function ITEM:OnDrop(player, position)
	if (player:GetCharacterData("smoking")) then
		Clockwork.player:Notify(player, "You can't drop the cigarette while you're smoking it!");
		
		return false;
	end;
	
	return true;
end;

function ITEM:OnPlayerUnequipped(player, arguments)
	if (player:Alive() and !player:IsRagdolled()) then
		if (player:GetCharacterData("smoking")) then
			timer.Destroy("smoking_stam");
			player:SetCharacterData("smoking", false);
		
			player:TakeItem(Clockwork.item:CreateInstance("cig_pipe"));
			player:GiveItem(Clockwork.item:CreateInstance("cig_pipe_smoked"));
		else
			Clockwork.player:Notify(player, "[ERROR] Internal error, something went really wrong. Try reconnecting.");
		end;
	end;
end;

ITEM:Register();