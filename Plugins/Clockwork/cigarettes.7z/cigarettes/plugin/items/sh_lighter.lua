--[[
	� 2014 TeslaCloud Studios (TheGarry =D).
	Licensed for LemonPunch.
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Lighter";
ITEM.weight = 0.1;
ITEM.model = "models/avoxgaming/mrp/jake/props/gasmask.mdl";
ITEM.business = true;
ITEM.access = "V";
ITEM.uniqueID = "cig_lighter";
ITEM.description = "A small metal lighter, usually used to smoke cigarettes.";
ITEM.category = "Cigarettes";

-- Called when item is dropped.
function ITEM:OnDrop(player, position)
	return true;
end;

ITEM:Register();