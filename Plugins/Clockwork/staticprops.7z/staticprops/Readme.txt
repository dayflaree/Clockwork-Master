This lets you static Entities, anything BUT CARS and bigger entities. Radios won't save the music. Mostly for chairs.

Edited by Snazzy/Halokiller38.