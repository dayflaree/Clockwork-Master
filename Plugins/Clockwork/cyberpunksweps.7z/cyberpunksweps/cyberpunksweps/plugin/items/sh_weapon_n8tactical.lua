--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "N8 Tactical Edition";
	ITEM.cost = 150;
	ITEM.model = "models/cyberpunk/weapons/w_pistol_mod2.mdl";
	ITEM.weight = 3;
	ITEM.access = "v";
	ITEM.uniqueID = "cyberpunk_pistolt";
	ITEM.business = false;
	ITEM.description = "A chunky silver scuffed pistol. It has an extended magazine and a holographic reflex sight.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();