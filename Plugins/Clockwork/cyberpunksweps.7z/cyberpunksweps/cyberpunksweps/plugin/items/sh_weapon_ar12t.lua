--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "AR12 Special Forces Edition";
	ITEM.cost = 800;
	ITEM.model = "models/cyberpunk/weapons/w_rifle_mod1.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "cyberpunk_riflet";
	ITEM.description = "A compact bull-pup rifle. It is clad with a reflex sight, foregrip+flashlight, stubby silencer, and HUD magnifier for maximum situational awareness.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();