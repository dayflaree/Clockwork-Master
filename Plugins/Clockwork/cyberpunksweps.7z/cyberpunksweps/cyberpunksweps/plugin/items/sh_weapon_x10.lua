--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "X10";
	ITEM.cost = 300;
	ITEM.model = "models/cyberpunk/weapons/w_revolver_mod4.mdl";
	ITEM.weight = 5;
	ITEM.access = "v";
	ITEM.uniqueID = "cyberpunk_revolvertttt";
	ITEM.business = true;
	ITEM.description = "A custom, heavy revolver with a large magazine size, and unconventional iron sight, and long heatsink.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();