--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "AR12 Tactical Edition";
	ITEM.cost = 900;
	ITEM.model = "models/cyberpunk/weapons/w_rifle_mod2.mdl";
	ITEM.weight = 7;
	ITEM.uniqueID = "cyberpunk_riflett";
	ITEM.description = "A heavily modified AR12. It has a mounted heartbeat sensor, HUD clad reflex sight, and a blue laser ANPQ device.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();