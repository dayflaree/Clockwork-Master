--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

local PANEL = {};

function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());
	
	self.playerList = vgui.Create("cwPanelList", self);
 	self.playerList:SetPadding(2);
 	self.playerList:SetSpacing(2);
	self.playerList:EnableVerticalScrollbar();
	
	Clockwork.playermanager.panel = self;
	Clockwork.playermanager.panel:Rebuild();
end;

function PANEL:GetMenuWidth()
	return ScrW() * 0.6;
end;

function PANEL:PlayerPanelFill(data)
	self.playerList:Clear();
	
	local label = vgui.Create("cwInfoText", self);
		label:SetText("To view an players options, click on its spawn icon.");
		label:SetInfoColor("blue");
	self.playerList:AddItem(label);

	local userGroups = {};
	local players = {}

	for k,v in pairs(data) do
		players[v.userGroup] = players[v.userGroup] or {};
		players[v.userGroup][#players[v.userGroup] + 1] = v;
	end;
	
	for k, v in pairs(players) do
		userGroups[#userGroups + 1] = {
			players = v,
			userGroups = k
		};
	end;
	
	table.sort(userGroups, function(a, b)
		return a.userGroups < b.userGroups;
	end);
	
	if(#userGroups > 0) then
		for k, v in ipairs(userGroups) do
			local collapsibleCategory = Clockwork.kernel:CreateCustomCategoryPanel(v.userGroups, self.playerList);
				collapsibleCategory:SetCookieName("player_"..v.userGroups);
			self.playerList:AddItem(collapsibleCategory);
			
			local playerList = vgui.Create("DPanelList", collapsibleCategory);
				playerList:EnableHorizontal(true);
				playerList:SetAutoSize(true);
				playerList:SetPadding(4);
				playerList:SetSpacing(4);
			collapsibleCategory:SetContents(playerList);
			
			for k2, v2 in ipairs(v.players) do
				local cwplayer = v2;
				
				self.cwplayer = cwplayer;
				playerList:AddItem(
					vgui.Create("cwPlayerItem", self)
				);
			end;
		
		end;
	end;
end;

function PANEL:IsButtonVisible()
	if (Clockwork.Client:IsSuperAdmin()) then
		return true;
	end;
end;

function PANEL:Rebuild()
	self.playerList:Clear();

	local label = vgui.Create("cwInfoText", self);
		label:SetText("Loading...");
		label:SetInfoColor("blue");
	self.playerList:AddItem(label);
	Clockwork.datastream:Start("cwPlayerManagerGetPlayers", true);
	
	self.playerList:InvalidateLayout(true);
end;

function PANEL:OnMenuOpened()
	if (Clockwork.menu:IsPanelActive(self)) then
		self:Rebuild();
	end;
end;

function PANEL:OnSelected() self:Rebuild(); end;

function PANEL:PerformLayout(w, h)
	self:SetSize(w, ScrH() * 0.75);
	self.playerList:StretchToParent(4, 4, 4, 4);
end;

function PANEL:Paint(w, h)
	derma.SkinHook("Paint", "Frame", self, w, h);
	
	return true;
end;

function PANEL:Think()
	self:InvalidateLayout(true);
end;

vgui.Register("cwPlayerManager", PANEL, "EditablePanel");

local PANEL = {};

function PANEL:Init()
	local cwplayer = self:GetParent().cwplayer;
	self:SetSize(40, 40);
	self.name = cwplayer.steamName;
	self.cwplayer = cwplayer;
	self.spawnIcon = Clockwork.kernel:CreateCustomSpawnIcon(self);
	
	if (self.cwplayer) then
		self.spawnIcon.OpenMenu = function(spawnIcon)
			PLUGIN:PressPlayerIcon(self.cwplayer);
		end;
	end;

	self.spawnIcon:SetModel("models/humans/group01/male_0"..math.random(1, 9)..".mdl");
	self.spawnIcon:SetSize(40, 40);
end;

function PANEL:Think()
	local informationColor = Clockwork.option:GetColor("information");

	local name = Clockwork.kernel:MarkupTextWithColor("["..self.name.."]", informationColor);
	local markupToolTip = name.."\n Steam ID: "..self.cwplayer.steamID;
	local markupToolTip = markupToolTip.."\n Time Joined: "..os.date("%c", self.cwplayer.timeJoined);
	local markupToolTip = markupToolTip.."\n Last Played: "..os.date("%c", self.cwplayer.lastPlayed);
	local markupToolTip = markupToolTip.."\n IP Address: "..self.cwplayer.iPAddress;
	
	self.spawnIcon:SetMarkupToolTip(markupToolTip);
end;

vgui.Register("cwPlayerItem", PANEL, "DPanel");