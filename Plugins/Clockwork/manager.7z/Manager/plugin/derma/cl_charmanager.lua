--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

local PANEL = {};

function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());
	
	self.charList = vgui.Create("cwPanelList", self);
 	self.charList:SetPadding(2);
 	self.charList:SetSpacing(2);
	self.charList:EnableVerticalScrollbar();
	
	Clockwork.charmanager.panel = self;
	Clockwork.charmanager.panel:Rebuild();
end;

function PANEL:GetMenuWidth()
	return ScrW() * 0.6;
end;

function PANEL:CharPanelFill(data)
	self.charList:Clear();
	
	local label = vgui.Create("cwInfoText", self);
		label:SetText("To view an chars options, click on its spawn icon.");
		label:SetInfoColor("blue");
	self.charList:AddItem(label);

	local players = {};
	local chars = {}

	for k,v in pairs(data) do
		chars[v.steamName] = chars[v.steamName] or {};
		chars[v.steamName][#chars[v.steamName] + 1] = v;
	end;
	
	for k, v in pairs(chars) do
		players[#players + 1] = {
			chars = v,
			players = k
		};
	end;
	
	table.sort(players, function(a, b)
		return a.players < b.players;
	end);
	
	if(#players > 0) then
		for k, v in ipairs(players) do
			local collapsibleCategory = Clockwork.kernel:CreateCustomCategoryPanel(v.players, self.charList);
				collapsibleCategory:SetCookieName("player_"..v.players);
			self.charList:AddItem(collapsibleCategory);
			
			local playerList = vgui.Create("DPanelList", collapsibleCategory);
				playerList:EnableHorizontal(true);
				playerList:SetAutoSize(true);
				playerList:SetPadding(4);
				playerList:SetSpacing(4);
			collapsibleCategory:SetContents(playerList);
			
			for k2, v2 in ipairs(v.chars) do
				local char = v2;
				
				self.char = char;
				playerList:AddItem(
					vgui.Create("cwCharItem", self)
				);
			end;
		
		end;
	end;
end;

function PANEL:IsButtonVisible()
	if (Clockwork.Client:IsSuperAdmin()) then
		return true;
	end;
end;

function PANEL:Rebuild()
	self.charList:Clear();

	local label = vgui.Create("cwInfoText", self);
		label:SetText("Loading...");
		label:SetInfoColor("blue");
	self.charList:AddItem(label);
	Clockwork.datastream:Start("cwCharManagerGetChars", true);
	
	self.charList:InvalidateLayout(true);
end;

function PANEL:OnMenuOpened()
	if (Clockwork.menu:IsPanelActive(self)) then
		self:Rebuild();
	end;
end;

function PANEL:OnSelected() self:Rebuild(); end;

function PANEL:PerformLayout(w, h)
	self:SetSize(w, ScrH() * 0.75);
	self.charList:StretchToParent(4, 4, 4, 4);
end;

function PANEL:Paint(w, h)
	derma.SkinHook("Paint", "Frame", self, w, h);
	
	return true;
end;

function PANEL:Think()
	self:InvalidateLayout(true);
end;

vgui.Register("cwCharManager", PANEL, "EditablePanel");

local PANEL = {};

function PANEL:Init()
	local char = self:GetParent().char;
	self:SetSize(40, 40);
	self.name = char.name;
	self.char = char;
	self.spawnIcon = Clockwork.kernel:CreateCustomSpawnIcon(self);
	
	if (self.char) then
		self.spawnIcon.OpenMenu = function(spawnIcon)
			PLUGIN:PressCharIcon(self.char);
		end;
	end;

	self.spawnIcon:SetModel(char.model);
	self.spawnIcon:SetSize(40, 40);
	self.cachedInfo = {model = model, skin = skin};
end;

function PANEL:Think()
	local informationColor = Clockwork.option:GetColor("information");

	local name = Clockwork.kernel:MarkupTextWithColor("["..self.name.."]", informationColor);
	local markupToolTip = name.."\n Steam ID: "..self.char.steamID;
	local markupToolTip = markupToolTip.."\n Faction: "..self.char.faction;
	local markupToolTip = markupToolTip.."\n Money: "..self.char.cash;
	local markupToolTip = markupToolTip.."\n Time Created: "..os.date("%c", self.char.timeCreated);
	local markupToolTip = markupToolTip.."\n Last Played: "..os.date("%c", self.char.lastPlayed);
	
	self.spawnIcon:SetMarkupToolTip(markupToolTip);
end;

vgui.Register("cwCharItem", PANEL, "DPanel");