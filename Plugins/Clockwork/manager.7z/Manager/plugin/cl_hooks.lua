--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:MenuItemsAdd(menuItems)
	local charmanagerName =  Clockwork.option:GetKey("name_charmanager");
	local playermanagerName =  Clockwork.option:GetKey("name_playermanager");
	
	menuItems:Add(charmanagerName, "cwCharManager", Clockwork.option:GetKey("description_charmanager"));
	menuItems:Add(playermanagerName, "cwPlayerManager", Clockwork.option:GetKey("description_playermanager"));
end;

function PLUGIN:CharacterManagerShowInventory(character)
	local target = Clockwork.player:FindByID(character.steamID);
	Clockwork.datastream:Start("CharManagerAct", {character, "ShowInv"});	
end;

function PLUGIN:GetCharManagerOptions(character, options)
	local data = character;

	options["Delete"] = function()
		Derma_Query("Are you sure you want to delete this character?", "Delete "..character.name, "Yes", function()
			Clockwork.datastream:Start("CharManagerAct", {data, "Delete"});	
		end, "No", function() end);
	end;
	
	options["Inventory"] = function()
		Clockwork.plugin:Call("CharacterManagerShowInventory", data);
	end;
end;

function PLUGIN:GetPlayersManagerOptions(cwplayer, options)
	local data = cwplayer;

	options["Delete"] = function()
		Derma_Query("Are you sure you want to delete this player?", "Delete "..cwplayer.steamName, "Yes", function()
			Clockwork.datastream:Start("playermanagerAct", {data, "Delete"});	
		end, "No", function() end);
	end;
end;