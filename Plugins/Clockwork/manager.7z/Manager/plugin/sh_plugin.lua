--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.option:SetKey("name_charmanager", "Manager - Character");
Clockwork.option:SetKey("name_playermanager", "Manager - Players");
Clockwork.option:SetKey("description_charmanager", "Access a variety of chars.");
Clockwork.option:SetKey("description_playermanager", "Access a variety of players.");

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");