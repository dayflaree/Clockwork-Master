--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.playermanager = Clockwork.kernel:NewLibrary("PlayerManager");

if (SERVER) then
	
	Clockwork.datastream:Hook("playermanagerAct", function(player, data)
		local cwplayer = data[1];
		local action = data[2];
		
		if (!player:IsSuperAdmin()) then return; end;
		
		if (cwplayer and action) then
			
			if (action == "Delete") then
				local playersTable = Clockwork.config:Get("mysql_players_table"):Get();
				local schemaFolder = Clockwork.kernel:GetSchemaFolder();
				
				local queryObj = Clockwork.database:Delete(playersTable);
					queryObj:AddWhere("_Schema", schemaFolder);
					queryObj:AddWhere("_SteamID", cwplayer.steamID);
				queryObj:Push();
				
				timer.Simple(1, function()
					Clockwork.plugin:Call("PlayerManagerSendData", player, true);
				end);
			end;
		end;
	end);
	
	
	Clockwork.datastream:Hook("cwPlayerManagerGetPlayers", function(player, data)
		if (!player:IsSuperAdmin()) then return; end;
		Clockwork.plugin:Call("PlayerManagerSendData", player, data);
	end);

else
	Clockwork.datastream:Hook("cwPlayerManagerGetPlayers", function(data)
		Clockwork.playermanager.panel:PlayerPanelFill(data);
	end);

end;