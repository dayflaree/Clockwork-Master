--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.charmanager = Clockwork.kernel:NewLibrary("CharManager");

if (SERVER) then
	
	function Clockwork.charmanager:Delete(player,data)
		local target = Clockwork.player:FindByID(data.steamID);
		local characterID = tonumber(data.characterID);
		
		if (target and target:GetCharacter().characterID != characterID) then
			Clockwork.player:ForceDeleteCharacter(target, characterID)
		elseif (target and target:GetCharacter().characterID == characterID) then
			Clockwork.player:Notify(player, "You cannot interact with this character!");
			return;
		else
			local charactersTable = Clockwork.config:Get("mysql_characters_table"):Get();
			local schemaFolder = Clockwork.kernel:GetSchemaFolder();
		
			local queryObj = Clockwork.database:Delete(charactersTable);
				queryObj:AddWhere("_Schema", schemaFolder);
				queryObj:AddWhere("_SteamID", data.steamID);
				queryObj:AddWhere("_CharacterID", data.characterID);
			queryObj:Push();
		end;
		
		Clockwork.player:NotifyAll(player:Name().." deleted character of ".. data.steamName.." - "..data.name..".");
		
	end;
	
	function Clockwork.charmanager:ShowInventory(player,data)
		local target = Clockwork.player:FindByID(data.steamID);
		local characterID = tonumber(data.characterID);
		
		if (target and target:GetCharacter().characterID == characterID) then
			Clockwork.player:RunClockworkCommand(player, "PlySearch", target:Name());	
		else	
			if (!player.cwSearching) then
				local inventory = Clockwork.inventory:ToLoadable(Clockwork.player:ConvertCharacterDataString(data.inventory));
				player.cwSearching = player;
				
				Clockwork.storage:Open(player, {
					name = data.name,
					cash = tonumber(data.cash),
					inventory = inventory,
					entity = target or player;
					data = data,
					OnClose = function(player, storageTable, entity)
						local charactersTable = Clockwork.config:Get("mysql_characters_table"):Get();
						local schemaFolder = Clockwork.kernel:GetSchemaFolder();
						
						player.cwSearching = nil;
						
						local queryObj = Clockwork.database:Update(charactersTable);
							queryObj:AddWhere("_Schema", schemaFolder);
							queryObj:AddWhere("_SteamID", storageTable.data.steamID);
							queryObj:AddWhere("_CharacterID", storageTable.data.characterID);
							queryObj:SetValue("_Inventory", Clockwork.json:Encode(Clockwork.inventory:ToSaveable(storageTable.inventory)));
						queryObj:Push();
						
						if (entity:SteamID() == storageTable.data.steamID ) then
							entity.cwCharacterList[tonumber(storageTable.data.characterID)].inventory = storageTable.inventory;
						end;
						
					end,
					OnTake = function(player, storageTable, itemTable) end,
					OnGive = function(player, storageTable, itemTable) end
				});
			else
				Clockwork.player:Notify(player, "You are already searching a character!");
			end;
		end;
	end;
	
	Clockwork.datastream:Hook("CharManagerAct", function(player, data)
		local character = data[1];
		local action = data[2];
		
		if (!player:IsSuperAdmin()) then return; end;
		
		if (character and action) then
			local fault = Clockwork.plugin:Call("PlayerCanManageCharacter", player, action, character);
			
			if (fault == false or type(fault) == "string") then
				Clockwork.player:Notify(player, "You cannot interact with this character!");
			elseif (action == "Delete") then
				Clockwork.charmanager:Delete(player, character);
				
				timer.Simple(1, function()
					Clockwork.plugin:Call("CharacterManagerSendData", player, true);
				end);
			elseif (action == "ShowInv") then
				Clockwork.charmanager:ShowInventory(player, character);
			end;
		end;
	end);
	

	
	
	Clockwork.datastream:Hook("cwCharManagerGetChars", function(player, data)
		if (!player:IsSuperAdmin()) then return; end;
		Clockwork.plugin:Call("CharacterManagerSendData", player, data);
	end);

else
	Clockwork.datastream:Hook("cwCharManagerGetChars", function(data)
		Clockwork.charmanager.panel:CharPanelFill(data);
	end);

end;