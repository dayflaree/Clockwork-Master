--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

function PLUGIN:PressCharIcon(rawCharacter)
	local options = {};
	
	Clockwork.plugin:Call("GetCharManagerOptions", rawCharacter, options);
	if (table.Count(options) == 0) then return; end;
	
	Clockwork.kernel:AddMenuFromData(nil, options);
end;

function PLUGIN:PressPlayerIcon(rawPlayer)
	local options = {};
	
	Clockwork.plugin:Call("GetPlayersManagerOptions", rawPlayer, options);
	if (table.Count(options) == 0) then return; end;
	
	Clockwork.kernel:AddMenuFromData(nil, options);
end;