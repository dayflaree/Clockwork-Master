--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:CharacterManagerSendData(player, data)
	local charactersTable = Clockwork.config:Get("mysql_characters_table"):Get();
	local schemaFolder = Clockwork.kernel:GetSchemaFolder();
	
	local queryObj = Clockwork.database:Select(charactersTable);
		queryObj:AddWhere("_Schema", schemaFolder);
		queryObj:SetCallback(function(result)
			data = {};
			for k,v in pairs(result) do
				data[#data + 1] = Clockwork.player:ConvertToCamelCase(v);
			end;
			
			Clockwork.datastream:Start(player, "cwCharManagerGetChars", Clockwork.player:ConvertToCamelCase(data));	
		end);
	queryObj:Pull();
end;

function PLUGIN:PlayerManagerSendData(player, data)
	local playersTable = Clockwork.config:Get("mysql_players_table"):Get();
	local schemaFolder = Clockwork.kernel:GetSchemaFolder();
	
	local queryObj = Clockwork.database:Select(playersTable);
		queryObj:AddWhere("_Schema", schemaFolder);
		queryObj:SetCallback(function(result)
			data = {};
			for k,v in pairs(result) do
				local count = #data + 1
				data[count] = Clockwork.player:ConvertToCamelCase(v);
				data[count].cwData = Clockwork.player:ConvertDataString(nil, v._Data);
			end;
			
			Clockwork.datastream:Start(player, "cwPlayerManagerGetPlayers", Clockwork.player:ConvertToCamelCase(data));	
		end);
	queryObj:Pull();
end;