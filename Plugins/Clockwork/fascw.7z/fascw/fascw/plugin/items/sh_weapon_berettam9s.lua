--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Beretta M9 Silenced";
	ITEM.model = "models/weapons/b_92sup.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "weapon_fas_berettam9s";
	ITEM.description = "A reliable and popular semi-automatic Italian service pistol, fitted with a military grade silencer.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
ITEM:Register();






