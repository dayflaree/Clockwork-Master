--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "H&K HK416";
	ITEM.batch = 1;
	ITEM.model = "models/weapons/j_rif_hk4ed.mdl";
	ITEM.weight = 4;
	ITEM.uniqueID = "weapon_fas_416";
	ITEM.business = false;
	ITEM.description = "A modern German assault carbine, based on the iconic M4.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();











