--[[
	Name: sh_auto.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

openAura.player:RegisterSharedVar("sh_callid", NWTYPE_NUMBER, true);

openAura:IncludePrefixed("sv_hooks.lua");
openAura:IncludePrefixed("sh_coms.lua");