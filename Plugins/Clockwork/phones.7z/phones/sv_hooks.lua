--[[
	Name: cl_auto.lua.
	Author: Euphe.
--]]

local PLUGIN = PLUGIN;

-- Called when the player first spawns
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
local hasnumber = player:GetSharedVar("callid")
local callnumber = tostring(8) .. tostring(math.random(7,9)) .. tostring(math.random(6,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9)) .. tostring(math.random(1,9))
	if (!firstSpawn and !lightSpawn and !hasnumber) then
		player:SetCharacterData("callid", tonumber(callnumber));
		openAura.player:Notify(player, "Your phone number is ".. player:GetCharacterData("callid")..", use /number command to find it out if you forget.");
	elseif hasnumber then
		player:SetCharacterData("callid", hasnumber);
end
end

-- Called when a player's character data should be saved.
function PLUGIN:PlayerSaveCharacterData(player, data)
	if ( data["callid"] ) then
		data["callid"] = math.Round( data["callid"] );
	end;
end;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["callid"] = data["callid"] or 100;
end;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "sh_callid", math.Round( player:GetCharacterData("callid") ) );
end;