--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local TRAIT = Clockwork.trait:New();

TRAIT.description = "You can understand and speak Hindi.";
TRAIT.name = "Hindi";
TRAIT.uniqueID = "hindi";
TRAIT.image = "kalighati/hud/traits/hindi";

TRAIT_HINDI = Clockwork.trait:Register(TRAIT);