--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local TRAIT = Clockwork.trait:New();

TRAIT.description = "You can understand and speak Arabic.";
TRAIT.name = "Arabic";
TRAIT.uniqueID = "arabic";
TRAIT.image = "kalighati/hud/traits/arabic";

TRAIT_ARABIC = Clockwork.trait:Register(TRAIT);