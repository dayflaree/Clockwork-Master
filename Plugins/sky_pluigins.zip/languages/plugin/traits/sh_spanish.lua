--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local TRAIT = Clockwork.trait:New();

TRAIT.description = "You can understand and speak Spanish.";
TRAIT.name = "Spanish";
TRAIT.uniqueID = "spanish";
TRAIT.image = "kalighati/hud/traits/spanish";

TRAIT_SPANISH = Clockwork.trait:Register(TRAIT);