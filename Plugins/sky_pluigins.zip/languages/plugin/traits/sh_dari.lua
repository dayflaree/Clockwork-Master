--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local TRAIT = Clockwork.trait:New();

TRAIT.description = "You can understand and speak Dari.";
TRAIT.name = "Dari";
TRAIT.uniqueID = "dari";
TRAIT.image = "kalighati/hud/traits/dari";

TRAIT_DARI = Clockwork.trait:Register(TRAIT);