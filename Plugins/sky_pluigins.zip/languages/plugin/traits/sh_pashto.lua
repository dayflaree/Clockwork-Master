--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local TRAIT = Clockwork.trait:New();

TRAIT.description = "You can understand and speak Pashto.";
TRAIT.name = "Pashto";
TRAIT.uniqueID = "pashto";
TRAIT.image = "kalighati/hud/traits/pashto";

TRAIT_PASHTO = Clockwork.trait:Register(TRAIT);