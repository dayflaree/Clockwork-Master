--[[
	This project is created with the Clockwork framework by Cloud Sixteen.
	http://cloudsixteen.com
--]]

local FACTION = Clockwork.faction:New("Spectator");

FACTION.whitelist = true; -- Do we need to be whitelisted to select this faction?
FACTION.useFullName = true; -- Do we allow players to enter a full name, otherwise it only lets them select a first and second.
FACTION.material = "kalighati/factions/spectator"; -- The path to the faction material (shown on the creation screen).
FACTION.singleGender = GENDER_MALE;
FACTION.models = {
		male = {
			"models/Combine_Soldier.mdl"
		};
	};
FACTION_SPECTATOR = FACTION:Register();