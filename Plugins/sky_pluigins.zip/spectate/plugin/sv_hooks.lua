local PLUGIN = PLUGIN;

function PLUGIN:PlayerUse(player, entity)
	if (IsValid(player) and player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)	
	if (player:GetFaction() == FACTION_SPECTATOR) then
		if (player.cwObserverMode != true) then
			cwObserverMode:MakePlayerEnterObserverMode(player);
		end;
	end;
end;

function PLUGIN:PlayerThink(player, infoTable, curTime)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		if (player:Health() < 100) then
			player:SetHealth(100);
		end;
	end;
	
	if (player:GetFaction() == FACTION_SPECTATOR) then
		if (player.cwObserverMode != true) then
			cwObserverMode:MakePlayerEnterObserverMode(player);
		end;
	end;
end;

function PLUGIN:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		damageInfo:SetDamage(0);
		damageInfo:ScaleDamage(0);
	end;
	
	if (attacker:IsPlayer() and attacker:GetFaction() == FACTION_SPECTATOR) then
		damageInfo:SetDamage(0);
		damageInfo:ScaleDamage(0);
	end;
end;

function PLUGIN:PlayerCanSwitchCharacter(player, character)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return true;
	end;
end;

function PLUGIN:PlayerCanSayLOOC(player, text)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot speak in LOOC as a spectator!")
		
		return false
	end
end

function PLUGIN:PlayerCanSayIC(player, text)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot speak in character as a spectator!")
		
		return false
	end
end

function PLUGIN:PlayerCanSayOOC(player, text)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot speak in OOC as a spectator!")
		local shouldSend = false
		return false
	end
end


function PLUGIN:PlayerCanUseCommand(player, commandTable, arguments)
	local lowername = string.lower(commandTable.name);
	
	if (lowername != "adminhelp" or lowername != "sc") then
		if (player:GetFaction() == FACTION_SPECTATOR) then
			Clockwork.player:Notify(player, "You cannot use commands as a spectator!");
			
			return false;
		end;
	end;
end;

function PLUGIN:PlayerPickupItem(player, itemTable, itemEntity, bQuickUse) 
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot pick up items as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerUseItem(player, itemTable, itemEntity) 
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot use items as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerDropItem(player, itemTable, position, entity) 
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot drop items as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerDestroyItem(player, itemTable) 
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot destroy items as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerCanPickupWeapon(player, weapon)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot pick up weapons as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerCanBeGivenWeapon(player, class, uniqueID, forceReturn)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PlayerCanRagdoll(player, state, delay, decay, ragdoll)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return true;
	end;
end;

function PLUGIN:PlayerCanDeleteCharacter(player, character)
	if (character:GetFaction() == FACTION_SPECTATOR) then
		return true;
	end;
end;

function PLUGIN:PlayerCanUseDoor(player, door)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		Clockwork.player:Notify(player, "You cannot use doors as a spectator!");
		
		return false;
	end;
end;

function PLUGIN:PlayerPlayDeathSound(player, gender)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PlayerCanDropWeapon(player, itemTable, weapon, bNoMsg)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:PlayerCanUseItem(player, itemTable, bNoMsg)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;

function PLUGIN:CanPlayerEnterVehicle(player, vehicle, role)
	if (player:GetFaction() == FACTION_SPECTATOR) then
		return false;
	end;
end;