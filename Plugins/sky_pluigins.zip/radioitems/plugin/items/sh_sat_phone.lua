
local ITEM = Clockwork.item:New();
ITEM.name = "Sattelite Phone";
ITEM.uniqueID = "sat_phone";
ITEM.model = "models/unconid/phones/motorola_dynatac_8000x.mdl";
ITEM.weight = 1;
ITEM.category = "Communication";
ITEM.business = false;
ITEM.description = "An old boxy sattelite phone, reliable, but antique.";
ITEM.frequency = "sat";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();