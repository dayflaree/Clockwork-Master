
local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlaySoundRadius");
COMMAND.tip = "Plays a sound to a radius.";
COMMAND.text = "<string SoundPath> <Float Radius>";
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local psound = table.concat(arguments, " ", 2);
	local radius = tonumber(arguments[2]);

	if (!radius) then
		radius = 256; // 5m
	end;

	local pCount = 0;

	if (!target) then Clockwork.player:Notify(player, {"NotValidPlayer", arguments[1]}); return end;

	if (psound) then
		for i,v in pairs(libPlayer.GetAll()) do
			if (v != player and IsValid(player)) then
				if (player:GetPos():DistToSqr(v:GetPos()) <= radius * radius ) then
					local messageData = {};

					Clockwork.datastream:Start(v, "play_sound", psound);

					player:CPNotify("Playing: "..psound, "control_play_blue")
				end;
			end;
		end;
	end;

	player:CPNotify("Playing: "..psound.."to "..pCount.."players.", "control_play_blue")
end;

COMMAND:Register();