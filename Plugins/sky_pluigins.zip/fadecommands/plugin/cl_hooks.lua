local PLUGIN = PLUGIN;

PLUGIN.LetterBoxScreenBarLength = 0;
PLUGIN.LetterBoxSpeed = 1;

Clockwork.MiddleText = Clockwork.kernel:NewLibrary("MiddleText");
Clockwork.MiddleText.classes = Clockwork.MiddleText.classes or {};
Clockwork.MiddleText.defaultClasses = Clockwork.MiddleText.defaultClasses or {}
Clockwork.MiddleText.messages = Clockwork.MiddleText.messages or {};
Clockwork.MiddleText.historyPos = Clockwork.MiddleText.historyPos or 0;
Clockwork.MiddleText.historyMsgs = Clockwork.MiddleText.historyMsgs or {};
Clockwork.MiddleText.spaceWidths = Clockwork.MiddleText.spaceWidths or {};

Clockwork.CenterText = Clockwork.kernel:NewLibrary("CenterText");
Clockwork.CenterText.classes = Clockwork.CenterText.classes or {};
Clockwork.CenterText.defaultClasses = Clockwork.CenterText.defaultClasses or {}
Clockwork.CenterText.messages = Clockwork.CenterText.messages or {};
Clockwork.CenterText.historyPos = Clockwork.CenterText.historyPos or 0;
Clockwork.CenterText.historyMsgs = Clockwork.CenterText.historyMsgs or {};
Clockwork.CenterText.spaceWidths = Clockwork.CenterText.spaceWidths or {};


Clockwork.datastream:Hook("ShowLetterBox", function(data)

	PLUGIN.drawLetterBox = true;
	PLUGIN.LetterBoxScreenDone = false;
	PLUGIN.LetterBoxBarsAlpha = 0;
	PLUGIN.LetterBoxBarsTarget = 255;

	if data and data.multiplier != nil then
		PLUGIN.LetterBoxBarsMultiplier = data.multiplier;
	else
		PLUGIN.LetterBoxBarsMultiplier = nil;
	end;

end);

Clockwork.datastream:Hook("HideLetterBox", function(data)

	PLUGIN.LetterBoxScreenDone = true;

end);

Clockwork.datastream:Hook("SpeedLetterBox", function(data)

	PLUGIN.LetterBoxSpeed = data or 1;

end);

Clockwork.datastream:Hook("MiddleTextAdd", function(data)

	Clockwork.MiddleText:Add(false, nil, data);

end);

Clockwork.datastream:Hook("CenterTextAdd", function(data)

	Clockwork.CenterText:Add(false, nil, data);

end);


function Clockwork.MiddleText:WrappedText(newLine, message, color, text, OnHover)
	local chatBoxTextFont = Clockwork.option:GetFont("chat_box_text");
	local width, height = Clockwork.kernel:GetTextSize(chatBoxTextFont, text);
	local maximumWidth = ScrW() * 0.6;
	
	if (width > maximumWidth) then
		local currentWidth = 0;
		local firstText = nil;
		local secondText = nil;
		
		for i = 0, #text do
			local currentCharacter = string.utf8sub(text, i, i);
			local currentSingleWidth = Clockwork.kernel:GetTextSize(chatBoxTextFont, currentCharacter);
			
			if ((currentWidth + currentSingleWidth) >= maximumWidth) then
				secondText = string.utf8sub(text, i);
				firstText = string.utf8sub(text, 0, (i - 1));
				
				break;
			else
				currentWidth = currentWidth + currentSingleWidth;
			end;
		end;
		
		if (firstText and firstText != "") then
			Clockwork.MiddleText:WrappedText(true, message, color, firstText, OnHover);
		end;
		
		if (secondText and secondText != "") then
			Clockwork.MiddleText:WrappedText(nil, message, color, secondText, OnHover);
		end;
	else
		message.text[#message.text + 1] = {
			newLine = newLine,
			OnHover = OnHover,
			height = height,
			width = width,
			color = color,
			text = text
		};
		
		if (newLine) then
			message.lines = message.lines + 1;
		end;
	end;
end;

function Clockwork.MiddleText:Add(filtered, icon, ...)
	if (ScrW() == 160 or ScrH() == 27) then
		return;
	end;
	
	if (!filtered) then
		local maximumLines = 5//math.Clamp(CW_CONVAR_MAXCHATLINES:GetInt(), 1, 10);
		local colorWhite = Clockwork.option:GetColor("white");
		local curTime = UnPredictedCurTime();
		local message = {
			timeFinish = curTime + 11,
			timeStart = curTime,
			timeFade = curTime + 10,
			fadeIn = curTime + 1,
			spacing = 0,
			alpha = 255,
			lines = 1,
			icon = icon
		};
		
		if (self.multiplier) then
			message.multiplier = self.multiplier;
			self.multiplier = nil;
		end;
		
		local curOnHover = nil;
		local curColor = nil;
		local text = {...};
		
		/*if (CW_CONVAR_SHOWTIMESTAMPS:GetInt() == 1) then
			local timeInfo = "("..os.date("%H:%M")..") ";
			local color = Color(150, 150, 150, 255);
			
			if (CW_CONVAR_TWELVEHOURCLOCK:GetInt() == 1) then
				timeInfo = "("..string.lower(os.date("%I:%M%p"))..") ";
			end;
			
			if (text) then
				table.insert(text, 1, color);
				table.insert(text, 2, timeInfo);
			else
				text = {timeInfo, color};
			end;
		end;*/
		
		if (text) then
			message.text = {};
			
			for k, v in pairs(text) do
				if (type(v) == "string" or type(v) == "number" or type(v) == "boolean") then
					Clockwork.MiddleText:WrappedText(
						nil, message, curColor or colorWhite, tostring(v), curOnHover
					);
					curColor = nil;
					curOnHover = nil;
				elseif (type(v) == "function") then
					curOnHover = v;
				elseif (type(v) == "Player") then
					Clockwork.MiddleText:WrappedText(
						nil, message, cwTeam.GetColor(v:Team()), v:Name(), curOnHover
					);
					curColor = nil;
					curOnHover = nil;
				elseif (type(v) == "table") then
					curColor = Color(v.r or colorWhite.r, v.g or colorWhite.g, v.b or colorWhite.b);
				end;
			end;
		end;
		
		if (self.historyPos == #self.historyMsgs) then
			self.historyPos = #self.historyMsgs + 1;
		end;
		
		self.historyMsgs[#self.historyMsgs + 1] = message;
		
		if (#self.messages == maximumLines) then
			table.remove(self.messages, maximumLines);
		end;
		
		table.insert(self.messages, 1, message);
		
		//Clockwork.option:PlaySound("tick");
		Clockwork.kernel:PrintColoredText(...);
	end;
end;

function PLUGIN:HUDPaintForeground()
	Clockwork.MiddleText:PaintMiddleText();
	Clockwork.CenterText:PaintCenterText();
end;

function Clockwork.MiddleText:PaintMiddleText()
	local chatBoxSyntaxFont = Clockwork.option:GetFont("chat_box_syntax");
	local chatBoxTextFont = Clockwork.option:GetFont("chat_box_text");
	local isOpen = false;
	
	Clockwork.kernel:OverrideMainFont(chatBoxTextFont);
	
	if (!self.spaceWidths[chatBoxTextFont]) then
		self.spaceWidths[chatBoxTextFont] = Clockwork.kernel:GetTextSize(chatBoxTextFont, " ");
	end;
	
	//local isTypingCommand = Clockwork.chatBox:IsTypingCommand();
	local chatBoxSpacing = Clockwork.chatBox:GetSpacing();
	local maximumLines = 5;//math.Clamp(CW_CONVAR_MAXCHATLINES:GetInt(), 1, 10);
	local origX, origY = ScrW()/2, ScrH() * (4/5);//Clockwork.chatBox:GetPosition(4);
	local onHoverData = nil;
	local spaceWidth = self.spaceWidths[chatBoxTextFont];
	local fontHeight = chatBoxSpacing - 4;
	local isTypingVC, voiceCommands = Clockwork.chatBox:IsTypingVC();
	local messages = self.messages;
	local x, y = origX, origY;
	local box = {width = 0, height = 0};

	if (!isOpen) then
		if (#self.historyMsgs > 100) then
			local amount = #self.historyMsgs - 100;
			
			for i = 1, amount do
				table.remove(self.historyMsgs, 1);
			end;
		end;
	else
		messages = {};
		
		for i = 0, (maximumLines - 1) do
			messages[#messages + 1] = self.historyMsgs[self.historyPos - i];
		end;
	end;
	
	for k, v in pairs(messages) do
		local fontName = Clockwork.fonts:GetMultiplied(chatBoxTextFont, v.multiplier or 1);
		Clockwork.kernel:OverrideMainFont(fontName);
		
		if (!self.spaceWidths[fontName]) then
			self.spaceWidths[fontName] = Clockwork.kernel:GetTextSize(fontName, " ");
		end;

		chatBoxSpacing = Clockwork.chatBox:GetSpacing(fontName);
		spaceWidth = self.spaceWidths[fontName];
		
		if (messages[k - 1]) then
			y = y - messages[k - 1].spacing;
		end;
		
		if (!isOpen and k == 1) then
			y = y - ((chatBoxSpacing + v.spacing) * (v.lines - 1)) + 14;
		else
			y = y - ((chatBoxSpacing + v.spacing) * v.lines);
			
			if (k == 1) then
				y = y + 2;
			end;
		end;
		
		local messageX = x;
		local messageY = y;
		local alpha = v.alpha;
		
		if (v.icon) then
			local messageIcon = Clockwork.kernel:GetMaterial(v.icon);

			surface.SetMaterial(messageIcon);
			surface.SetDrawColor(255, 255, 255, alpha);
			surface.DrawTexturedRect(messageX, messageY + (fontHeight / 2) - 8, 16, 16);
			
			messageX = messageX + 16 + spaceWidth;
		end;
		
		local mouseX = gui.MouseX();
		local mouseY = gui.MouseY();
		
		for k2, v2 in pairs(v.text) do
			local textColor = Color(v2.color.r, v2.color.g, v2.color.b, alpha);
			local newLine = false;
			
			if (mouseX > messageX and mouseY > messageY
			and mouseX < messageX + v2.width
			and mouseY < messageY + v2.height) then
				if (v2.OnHover) then
					onHoverData = v2;
				end;
			end;

			messageX = ScrW()/2 - (v2.width/2);
			
			Clockwork.kernel:DrawSimpleText(v2.text, messageX, messageY, textColor);

			if (v2.newLine) then
				messageY = messageY + chatBoxSpacing + v.spacing;
				messageX = ScrW()/2 - (v2.width/2);
			end;
		end;
	end;
	
	Clockwork.kernel:OverrideMainFont(false);

	if (onHoverData) then
		onHoverData.OnHover(onHoverData);
	end;
end;

function Clockwork.CenterText:WrappedText(newLine, message, color, text, OnHover)
	local chatBoxTextFont = Clockwork.option:GetFont("chat_box_text");
	local width, height = Clockwork.kernel:GetTextSize(chatBoxTextFont, text);
	local maximumWidth = ScrW() * 0.6;
	
	if (width > maximumWidth) then
		local currentWidth = 0;
		local firstText = nil;
		local secondText = nil;
		
		for i = 0, #text do
			local currentCharacter = string.utf8sub(text, i, i);
			local currentSingleWidth = Clockwork.kernel:GetTextSize(chatBoxTextFont, currentCharacter);
			
			if ((currentWidth + currentSingleWidth) >= maximumWidth) then
				secondText = string.utf8sub(text, i);
				firstText = string.utf8sub(text, 0, (i - 1));
				
				break;
			else
				currentWidth = currentWidth + currentSingleWidth;
			end;
		end;
		
		if (firstText and firstText != "") then
			Clockwork.CenterText:WrappedText(true, message, color, firstText, OnHover);
		end;
		
		if (secondText and secondText != "") then
			Clockwork.CenterText:WrappedText(nil, message, color, secondText, OnHover);
		end;
	else
		message.text[#message.text + 1] = {
			newLine = newLine,
			OnHover = OnHover,
			height = height,
			width = width,
			color = color,
			text = text
		};
		
		if (newLine) then
			message.lines = message.lines + 1;
		end;
	end;
end;

function Clockwork.CenterText:Add(filtered, icon, ...)
	if (ScrW() == 160 or ScrH() == 27) then
		return;
	end;
	
	if (!filtered) then
		local maximumLines = 5//math.Clamp(CW_CONVAR_MAXCHATLINES:GetInt(), 1, 10);
		local colorWhite = Clockwork.option:GetColor("white");
		local curTime = UnPredictedCurTime();
		local message = {
			timeFinish = curTime + 11,
			timeStart = curTime,
			timeFade = curTime + 10,
			fadeIn = curTime + 1,
			spacing = 0,
			alpha = 255,
			lines = 1,
			icon = icon
		};
		
		if (self.multiplier) then
			message.multiplier = self.multiplier;
			self.multiplier = nil;
		end;
		
		local curOnHover = nil;
		local curColor = nil;
		local text = {...};
		
		/*if (CW_CONVAR_SHOWTIMESTAMPS:GetInt() == 1) then
			local timeInfo = "("..os.date("%H:%M")..") ";
			local color = Color(150, 150, 150, 255);
			
			if (CW_CONVAR_TWELVEHOURCLOCK:GetInt() == 1) then
				timeInfo = "("..string.lower(os.date("%I:%M%p"))..") ";
			end;
			
			if (text) then
				table.insert(text, 1, color);
				table.insert(text, 2, timeInfo);
			else
				text = {timeInfo, color};
			end;
		end;*/
		
		if (text) then
			message.text = {};
			
			for k, v in pairs(text) do
				if (type(v) == "string" or type(v) == "number" or type(v) == "boolean") then
					Clockwork.CenterText:WrappedText(
						nil, message, curColor or colorWhite, tostring(v), curOnHover
					);
					curColor = nil;
					curOnHover = nil;
				elseif (type(v) == "function") then
					curOnHover = v;
				elseif (type(v) == "Player") then
					Clockwork.CenterText:WrappedText(
						nil, message, cwTeam.GetColor(v:Team()), v:Name(), curOnHover
					);
					curColor = nil;
					curOnHover = nil;
				elseif (type(v) == "table") then
					curColor = Color(v.r or colorWhite.r, v.g or colorWhite.g, v.b or colorWhite.b);
				end;
			end;
		end;
		
		if (self.historyPos == #self.historyMsgs) then
			self.historyPos = #self.historyMsgs + 1;
		end;
		
		self.historyMsgs[#self.historyMsgs + 1] = message;
		
		if (#self.messages == maximumLines) then
			table.remove(self.messages, maximumLines);
		end;
		
		table.insert(self.messages, 1, message);
		
		//Clockwork.option:PlaySound("tick");
		Clockwork.kernel:PrintColoredText(...);
	end;
end;

function PLUGIN:Think()
	local curTime = UnPredictedCurTime();
	
	for k, v in pairs(Clockwork.CenterText.messages) do
		if (curTime >= v.timeFade) then
			local fadeTime = v.timeFinish - v.timeFade;
			local timeLeft = v.timeFinish - curTime;
			local alpha = math.Clamp((255 / fadeTime) * timeLeft, 0, 255);
			
			if (alpha == 0) then
				table.remove(Clockwork.CenterText.messages, k);
			else
				v.alpha = alpha;
			end;
		elseif (curTime <= v.fadeIn) then
			local fadeTime = v.fadeIn - v.timeStart;
			local timeLeft = curTime - v.timeStart;
			local alpha = math.Clamp((255 / fadeTime) * timeLeft, 0, 255);

			v.alpha = alpha;
		end;
	end;

	for k, v in pairs(Clockwork.MiddleText.messages) do
		if (curTime >= v.timeFade) then
			local fadeTime = v.timeFinish - v.timeFade;
			local timeLeft = v.timeFinish - curTime;
			local alpha = math.Clamp((255 / fadeTime) * timeLeft, 0, 255);
			
			if (alpha == 0) then
				table.remove(Clockwork.MiddleText.messages, k);
			else
				v.alpha = alpha;
			end;
		elseif (curTime <= v.fadeIn) then
			local fadeTime = v.fadeIn - v.timeStart;
			local timeLeft = curTime - v.timeStart;
			local alpha = math.Clamp((255 / fadeTime) * timeLeft, 0, 255);

			v.alpha = alpha;
		end;
	end;
end;

function Clockwork.CenterText:PaintCenterText()
	local chatBoxSyntaxFont = Clockwork.option:GetFont("chat_box_syntax");
	local chatBoxTextFont = Clockwork.option:GetFont("chat_box_text");
	local isOpen = false;
	
	Clockwork.kernel:OverrideMainFont(chatBoxTextFont);
	
	if (!self.spaceWidths[chatBoxTextFont]) then
		self.spaceWidths[chatBoxTextFont] = Clockwork.kernel:GetTextSize(chatBoxTextFont, " ");
	end;
	
	//local isTypingCommand = Clockwork.chatBox:IsTypingCommand();
	local chatBoxSpacing = Clockwork.chatBox:GetSpacing();
	local maximumLines = 5;//math.Clamp(CW_CONVAR_MAXCHATLINES:GetInt(), 1, 10);
	local origX, origY = ScrW()/2, ScrH()/2;//Clockwork.chatBox:GetPosition(4);
	local onHoverData = nil;
	local spaceWidth = self.spaceWidths[chatBoxTextFont];
	local fontHeight = chatBoxSpacing - 4;
	local isTypingVC, voiceCommands = Clockwork.chatBox:IsTypingVC();
	local messages = self.messages;
	local x, y = origX, origY;
	local box = {width = 0, height = 0};

	if (!isOpen) then
		if (#self.historyMsgs > 100) then
			local amount = #self.historyMsgs - 100;
			
			for i = 1, amount do
				table.remove(self.historyMsgs, 1);
			end;
		end;
	else
		messages = {};
		
		for i = 0, (maximumLines - 1) do
			messages[#messages + 1] = self.historyMsgs[self.historyPos - i];
		end;
	end;
	
	for k, v in pairs(messages) do
		local fontName = Clockwork.fonts:GetMultiplied(chatBoxTextFont, v.multiplier or 1);
		Clockwork.kernel:OverrideMainFont(fontName);
		
		if (!self.spaceWidths[fontName]) then
			self.spaceWidths[fontName] = Clockwork.kernel:GetTextSize(fontName, " ");
		end;

		chatBoxSpacing = Clockwork.chatBox:GetSpacing(fontName);
		spaceWidth = self.spaceWidths[fontName];
		
		if (messages[k - 1]) then
			y = y - messages[k - 1].spacing;
		end;
		
		if (!isOpen and k == 1) then
			y = y - ((chatBoxSpacing + v.spacing) * (v.lines - 1)) + 14;
		else
			y = y - ((chatBoxSpacing + v.spacing) * v.lines);
			
			if (k == 1) then
				y = y + 2;
			end;
		end;
		
		local messageX = x;
		local messageY = y;
		local alpha = v.alpha;
		
		if (v.icon) then
			local messageIcon = Clockwork.kernel:GetMaterial(v.icon);

			surface.SetMaterial(messageIcon);
			surface.SetDrawColor(255, 255, 255, alpha);
			surface.DrawTexturedRect(messageX, messageY + (fontHeight / 2) - 8, 16, 16);
			
			messageX = messageX + 16 + spaceWidth;
		end;
		
		local mouseX = gui.MouseX();
		local mouseY = gui.MouseY();
		
		for k2, v2 in pairs(v.text) do
			local textColor = Color(v2.color.r, v2.color.g, v2.color.b, alpha);
			local newLine = false;
			
			if (mouseX > messageX and mouseY > messageY
			and mouseX < messageX + v2.width
			and mouseY < messageY + v2.height) then
				if (v2.OnHover) then
					onHoverData = v2;
				end;
			end;

			messageX = ScrW()/2 - (v2.width/2);
			
			Clockwork.kernel:DrawSimpleText(v2.text, messageX, messageY, textColor);

			if (v2.newLine) then
				messageY = messageY + chatBoxSpacing + v.spacing;
				messageX = ScrW()/2 - (v2.width/2);
			end;
		end;
	end;
	
	Clockwork.kernel:OverrideMainFont(false);

	if (onHoverData) then
		onHoverData.OnHover(onHoverData);
	end;
end;

function PLUGIN:GetPlayerESPInfo(player, text)
    
    if (player:IsValid()) then
        local fadeColor = player:GetSharedVar("fadeColor");
        
        if fadeColor and fadeColor != "" then
            local actualColor = string.ToColor(fadeColor);
            local colorText = "white";

            if actualColor then
            	if actualColor == Color(0, 0, 0, 255) then
            		colorText = "black";
            	end;

	            table.insert(text, {
	    			text = "Faded to "..colorText, 
	    			color = actualColor//Color(170, 170, 170, 255)
	    			//icon = cwPly:GetChatIcon(player)
	    		});
	    	end;
    	end;
    end;
    
end;

function PLUGIN:HUDDrawScoreBoard()
	if (Clockwork.Client:HasInitialized() and !Clockwork.kernel:IsChoosingCharacter() and self.drawLetterBox) then
		self:DrawLetterBoxBars();
	end;
end;

function PLUGIN:DrawLetterBoxBars()
		//if (self.drawLetterBox) then
		local maxBarLength = ScrH() / 8;
		
		if (!self.LetterBoxBarsTarget and !self.LetterBoxBarsAlpha) then
			self.LetterBoxBarsAlpha = 0;
			self.LetterBoxBarsTarget = 255;
			//Clockwork.option:PlaySound("rollover");
		end;
		
		self.LetterBoxBarsAlpha = math.Approach(self.LetterBoxBarsAlpha, self.LetterBoxBarsTarget, (255/self.LetterBoxSpeed * FrameTime())); //1
		
		if (self.LetterBoxScreenDone) then
			if (self.LetterBoxScreenBarLength != 0) then
				self.LetterBoxScreenBarLength = math.Clamp((maxBarLength / 255) * self.LetterBoxBarsAlpha, 0, maxBarLength);
			end;
			
			if (self.LetterBoxBarsTarget != 0) then
				self.LetterBoxBarsTarget = 0;
				//Clockwork.option:PlaySound("rollover");
			end;
			
			if (self.LetterBoxBarsAlpha == 0) then
				self.LetterBoxBarsDrawn = true;
			end;
		elseif (self.LetterBoxScreenBarLength != maxBarLength) then
			//if (!self.LetterBoxBarsMultiplier) then
			//	self.LetterBoxBarsMultiplier = 1;
			//else
			//	self.LetterBoxBarsMultiplier = math.Clamp(self.LetterBoxBarsMultiplier + (FrameTime() * 8), 1, 12);
			//end;
			
			self.LetterBoxScreenBarLength = math.Clamp((maxBarLength / 255) * math.Clamp(self.LetterBoxBarsAlpha /** self.LetterBoxBarsMultiplier*/, 0, 255), 0, maxBarLength);
		end;
		
		draw.RoundedBox(0, 0, 0, ScrW(), self.LetterBoxScreenBarLength, Color(0, 0, 0, 255));
		draw.RoundedBox(0, 0, ScrH() - self.LetterBoxScreenBarLength, ScrW(), self.LetterBoxScreenBarLength, Color(0, 0, 0, 255));
		//draw.RoundedBox(0, 0, ScrH() - self.LetterBoxScreenBarLength, ScrW(), maxBarLength, Color(0, 0, 0, 255));

		if (self.LetterBoxScreenBarLength <= 0) then
			self.drawLetterBox = false;
			self.LetterBoxScreenDone = false;
			self.LetterBoxBarsMultiplier = nil;
			self.LetterBoxBarsAlpha = 0;
			self.LetterBoxBarsTarget = 255;
		end;
		//end;
	end;