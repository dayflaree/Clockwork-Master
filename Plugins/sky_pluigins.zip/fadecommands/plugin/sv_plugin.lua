/*Clockwork.config:Add("stats_hunger_tick", 120);
Clockwork.config:Add("stats_hydration_tick", 60);
Clockwork.config:Add("stats_toxicity_tick", 60);
Clockwork.config:Add("stats_radiation_tick", 60);*/

local PLUGIN = PLUGIN;

PLUGIN.GlobalSounds = {};