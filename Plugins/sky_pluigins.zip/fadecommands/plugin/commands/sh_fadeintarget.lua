local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("FadeInTarget");
COMMAND.tip = "Make a person fade back in.";
COMMAND.text = "<String Target> <Float Fade Time>";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local fadeTime = tonumber(arguments[2]);

	if (!target) then Clockwork.player:Notify(player, {"NotValidPlayer", arguments[1]}); return end;

	if (!fadeTime) then
		fadeTime = 1;
	end;

	local fadeColor = string.ToColor(target:GetSharedVar("fadeColor")) or Color( 255, 255, 255, 255 );

	//Clockwork.kernel:SetSharedVar("fadeOn", false);
	target:SetSharedVar("fadeColor", "");
	
	target:ScreenFade(SCREENFADE.IN + SCREENFADE.PURGE, fadeColor, fadeTime, 0)

	target:UnLock();

	Clockwork.player:Notify(player, "Fading back in.");
end;

COMMAND:Register();