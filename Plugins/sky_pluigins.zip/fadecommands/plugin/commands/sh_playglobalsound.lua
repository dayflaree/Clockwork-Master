local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("PlayGlobalSound");
COMMAND.tip = "Add a new global sound to play.";
COMMAND.text = "[String Sound Path]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local soundPath = arguments[1];

	if (SERVER) then
		local sndFilter = RecipientFilter();
		sndFilter:AddAllPlayers();

		local snd = CreateSound(game.GetWorld(), soundPath, sndFilter);

		if snd then
			snd:SetSoundLevel(0);
			snd:Play();
			table.insert(PLUGIN.GlobalSounds, {sound = snd, path = soundPath, filter = sndFilter});
		end;

		Clockwork.player:Notify(player, "Playing sound!");
	end;
end;

COMMAND:Register();