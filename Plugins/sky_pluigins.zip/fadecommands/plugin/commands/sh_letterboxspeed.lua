local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("LetterBoxSpeed");
COMMAND.tip = "Adjust the speed of the letter box entrance and closing.";
COMMAND.text = "<Float Time to come in/out>";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local newSpeed = tonumber(arguments[1]) or 1;

	for i,v in pairs(libPlayer.GetAll()) do
		Clockwork.datastream:Start(v, "SpeedLetterBox", newSpeed);
	end;

	
	Clockwork.player:Notify(player, "Set the speed of the letter box transition to "..newSpeed.." second(s).");
	
end;

COMMAND:Register();