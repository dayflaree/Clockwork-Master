local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("FadeInRadius");
COMMAND.tip = "Make everyone in a specified radius fade back in. 52 = 1 meter, 256 = 5 meters.";
COMMAND.text = "<Float Fade Time> <Float Radius>";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local fadeTime = tonumber(arguments[1]);
	local radius = tonumber(arguments[2]);

	if (!fadeTime) then
		fadeTime = 1;
	end;

	if (!radius) then
		radius = 256; // 5m
	end;

	local pCount = 0;

	for i,v in pairs(libPlayer.GetAll()) do
		if (v != player and IsValid(player)) then
			if ( player:GetPos():DistToSqr(v:GetPos()) <= radius * radius ) then
			    local color = string.ToColor(v:GetSharedVar("fadeColor"));
        	    if color then
            	    v:SetSharedVar("fadeColor", "");
            		v:ScreenFade(SCREENFADE.IN + SCREENFADE.PURGE, color, fadeTime, 0)
            		v:UnLock();
    				pCount = pCount + 1;
				end;
			end;
		end;
	end;

	//Clockwork.kernel:SetSharedVar("fadeOn", true);
	//Clockwork.kernel:SetSharedVar("fadeColor", string.FromColor(Color( 255, 255, 255, 255 )));

	Clockwork.player:Notify(player, "Fading back in in radius. "..pCount.." players were affected.");
end;

COMMAND:Register();