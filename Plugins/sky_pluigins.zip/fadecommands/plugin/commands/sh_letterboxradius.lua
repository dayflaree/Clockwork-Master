local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("LetterBoxRadius");
COMMAND.tip = "Make everyone in a specified radius show the letter box. 52 = 1 meter, 256 = 5 meters.";
COMMAND.text = "<Float Radius> [Bool Hide Letter Box?]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	//local fadeTime = tonumber(arguments[1]);
	local radius = tonumber(arguments[1]);
	local stopLetterBox = Clockwork.kernel:ToBool(arguments[2]) or false;

	if (!fadeTime) then
		fadeTime = 1;
	end;

	if (!radius) then
		radius = 256; // 5m
	end;

	local pCount = 0;

	for i,v in pairs(libPlayer.GetAll()) do
		if (v != player) then
			if ( player:GetPos():DistToSqr(v:GetPos()) <= radius * radius ) then
				if (stopLetterBox) then
					Clockwork.datastream:Start(v, "HideLetterBox");
				else
					Clockwork.datastream:Start(v, "ShowLetterBox", {multiplier = 0});
				end;
				pCount = pCount + 1;
			end;
		end;
	end;

	//Clockwork.kernel:SetSharedVar("fadeOn", true);
	//Clockwork.kernel:SetSharedVar("fadeColor", string.FromColor(Color( 255, 255, 255, 255 )));

	if (stopLetterBox) then
		Clockwork.player:Notify(player, "Hiding letter box in radius. "..pCount.." players were affected.");
	else
		Clockwork.player:Notify(player, "Showing letter box in radius. "..pCount.." players were affected.");
	end;

	//Clockwork.player:Notify(player, "Fading to white in radius. "..pCount.." players were affected.");
end;

COMMAND:Register();