local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("LetterBoxTarget");
COMMAND.tip = "Make a person show or hide the letter box.";
COMMAND.text = "<String Target> [Bool Hide Letter Box?]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local stopLetterBox = Clockwork.kernel:ToBool(arguments[2]) or false;

	if (!target) then Clockwork.player:Notify(player, {"NotValidPlayer", arguments[1]}); return end;

	if (stopLetterBox) then
		Clockwork.datastream:Start(target, "HideLetterBox");
		Clockwork.player:Notify(player, "Hiding the target's letter box.");
	else
		Clockwork.datastream:Start(target, "ShowLetterBox", {multiplier = 0});
		Clockwork.player:Notify(player, "Showing the target's letter box.");
	end;

end;

COMMAND:Register();