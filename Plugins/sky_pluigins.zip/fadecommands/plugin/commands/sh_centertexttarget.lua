--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local player = player;
local libPlayer = player;

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CenterTextTarget");

COMMAND.tip = "Send a center text to a target.";
COMMAND.text = "<String Target> <String Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local centerText = table.concat(arguments, " ", 2);

	if (!target) then Clockwork.player:Notify(player, {"NotValidPlayer", arguments[1]}); return end;

	if (centerText) then
		local messageData = {};

		Clockwork.datastream:Start(target, "CenterTextAdd", centerText);
	end;
end;

COMMAND:Register();