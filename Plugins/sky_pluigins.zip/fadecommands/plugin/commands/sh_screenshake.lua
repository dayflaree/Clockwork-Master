local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("ScreenShake");
COMMAND.tip = "Make everyone shake their screen.";
COMMAND.text = "<Float Shake Time> [Float Shake Amplitude] [Float Shake Frequency] [Float Shake Radius]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 3;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local shakeTime = tonumber(arguments[1]) or 2;
	local shakeAmp = tonumber(arguments[2]) or 5;
	local shakeFreq = tonumber(arguments[3]) or 5;
	local shakeRadius = tonumber(arguments[4]) or 10000000;

	util.ScreenShake(player:GetPos(), shakeAmp, shakeFreq, shakeTime, shakeRadius);

	Clockwork.player:Notify(player, "Shaking.");
end;

COMMAND:Register();