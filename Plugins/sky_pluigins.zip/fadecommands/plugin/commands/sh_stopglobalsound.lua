local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("StopGlobalSound");
COMMAND.tip = "Stop and remove a global sound.";
COMMAND.text = "[Integer Sound ID]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local soundID = tonumber(arguments[1]);

	if (SERVER) then
		if (!soundID) then 
			Clockwork.player:Notify(player, "Argument isn't a number!");
			return false;
		end;

		local globalSound = PLUGIN.GlobalSounds[soundID];

		if (globalSound) then

			PLUGIN.GlobalSounds[soundID].sound:Stop()
			PLUGIN.GlobalSounds[soundID] = nil;

			Clockwork.player:Notify(player, "Stopped and removed a global sound!");

		else
			Clockwork.player:Notify(player, "That's not a valid global sound ID!");
			return false;
		end;

	end;
end;

COMMAND:Register();