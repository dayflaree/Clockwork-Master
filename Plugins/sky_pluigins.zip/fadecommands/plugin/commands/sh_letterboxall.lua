local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("LetterBoxAll");
COMMAND.tip = "Turn on or off the letterbox for all players.";
COMMAND.text = "[Bool Hide Letter Box?]";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local stopLetterBox = Clockwork.kernel:ToBool(arguments[1]) or false;

	for i,v in pairs(libPlayer.GetAll()) do
		if (stopLetterBox) then
			Clockwork.datastream:Start(v, "HideLetterBox");
		else
			Clockwork.datastream:Start(v, "ShowLetterBox", {multiplier = 0});
		end;
	end;

	if (stopLetterBox) then
		Clockwork.player:Notify(player, "Hiding letter box for everyone.");
	else
		Clockwork.player:Notify(player, "Showing letter box for everyone.");
	end;
	
end;

COMMAND:Register();