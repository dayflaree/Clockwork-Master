local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("FadeBlackTarget");
COMMAND.tip = "Make a person fade to black.";
COMMAND.text = "<String Target> <Float Fade Time>";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local fadeTime = tonumber(arguments[2]);

	if (!target) then Clockwork.player:Notify(player, {"NotValidPlayer", arguments[1]}); return end;

	if (!fadeTime) then
		fadeTime = 1;
	end;

	//Clockwork.kernel:SetSharedVar("fadeOn", false);
	target:SetSharedVar("fadeColor", string.FromColor(Color( 0, 0, 0, 255 )));
	target:ScreenFade(SCREENFADE.OUT + SCREENFADE.STAYOUT, Color( 0, 0, 0, 255 ), fadeTime, 0)
	target:Lock();

	Clockwork.player:Notify(player, "Fading target to black.");
end;

COMMAND:Register();