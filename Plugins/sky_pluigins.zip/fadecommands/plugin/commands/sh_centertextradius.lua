--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local player = player;
local libPlayer = player;

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CenterTextRadius");

COMMAND.tip = "Send a center text to players in a radius.";
COMMAND.text = "<String Text> <Float Radius>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local centerText = table.concat(arguments, " ", 1);
	local radius = tonumber(arguments[2]);

	if (!radius) then
		radius = 256; // 5m
	end;

	local pCount = 0;
	
	if (middleText) then
		for i,v in pairs(libPlayer.GetAll()) do
			if (v != player and IsValid(player)) then
				if (player:GetPos():DistToSqr(v:GetPos()) <= radius * radius ) then
					local messageData = {};

					Clockwork.datastream:Start(v, "CenterTextAdd", middleText);
				end;
			end;
		end;
	end;

	Clockwork.player:Notify(player, "Center texting in radius. "..pCount.." players were affected.");
end;

COMMAND:Register();