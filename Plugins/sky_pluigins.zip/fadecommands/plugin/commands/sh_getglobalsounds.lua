local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("GetGlobalSounds");
COMMAND.tip = "List all global sounds.";
COMMAND.text = "";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	//local soundPath = arguments[1]);

	if (SERVER) then
		for i, v in pairs(PLUGIN.GlobalSounds) do
			Clockwork.chatBox:Add(player, nil, "notify", "Sound ID: "..tostring(i).." Sound Path: "..tostring(v.path));
		end;
	end;
end;

COMMAND:Register();