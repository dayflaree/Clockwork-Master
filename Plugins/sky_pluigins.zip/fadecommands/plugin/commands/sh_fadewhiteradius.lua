local PLUGIN = PLUGIN;
local player = player;
local libPlayer = player;

local COMMAND = Clockwork.command:New("FadeWhiteRadius");
COMMAND.tip = "Make everyone in a specified radius fade to white. 52 = 1 meter, 256 = 5 meters.";
COMMAND.text = "<Float Fade Time> <Float Radius>";
COMMAND.flags = 0;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local fadeTime = tonumber(arguments[1]);
	local radius = tonumber(arguments[2]);

	if (!fadeTime) then
		fadeTime = 1;
	end;

	if (!radius) then
		radius = 256; // 5m
	end;

	local pCount = 0;

	for i,v in pairs(libPlayer.GetAll()) do
		if (v != player and IsValid(player)) then
			if ( !player:IsNoClipping() and player:GetPos():DistToSqr(v:GetPos()) <= radius * radius ) then
				v:SetSharedVar("fadeColor", string.FromColor(Color( 255, 255, 255, 255 )));
				v:ScreenFade(SCREENFADE.OUT + SCREENFADE.STAYOUT, Color( 255, 255, 255, 255 ), fadeTime, 0);
				v:Lock();
				pCount = pCount + 1;
			end;
		end;
	end;

	//Clockwork.kernel:SetSharedVar("fadeOn", true);
	//Clockwork.kernel:SetSharedVar("fadeColor", string.FromColor(Color( 255, 255, 255, 255 )));

	Clockwork.player:Notify(player, "Fading to white in radius. "..pCount.." players were affected.");
end;

COMMAND:Register();