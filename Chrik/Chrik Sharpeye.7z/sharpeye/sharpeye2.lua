////////////////////////////////////////////////
// -- SharpeYe                                //
// by Hurricaaane (Ha3)                       //
//                                            //
// http://www.youtube.com/user/Hurricaaane    //
//--------------------------------------------//
// eMotion                                    //
////////////////////////////////////////////////
local sharpeye = sharpeye

function sharpeye:ApplyEmotion( ply, origin, angles, fov, view )
	
end
 