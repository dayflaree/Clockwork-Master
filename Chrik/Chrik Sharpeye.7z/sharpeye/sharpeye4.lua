////////////////////////////////////////////////
// -- SharpeYe                                //
// by Hurricaaane (Ha3)                       //
//                                            //
// http://www.youtube.com/user/Hurricaaane    //
//--------------------------------------------//
// Vision                                     //
////////////////////////////////////////////////
local sharpeye = sharpeye

function sharpeye:IsCrosshairEnabled()
	return false
end

function sharpeye:IsOverlayEnabled()
	return self:GetVar("core_overlay") > 0
end

function sharpeye:HudSmooth( fCurrent, fTarget, fSmooth )
	return fCurrent + (fTarget - fCurrent) * math.Clamp( fSmooth * FrameTime() * 25 , 0 , 1 )
end

function sharpeye:SetDrawColorFromVar( sVar )
	return surface.SetDrawColor(
		self:GetVarColorVariadic( sVar )
	)
end

function sharpeye:GetCrosshairStaticSize()
	return self:GetVar("xhair_staticsize") / 8 * 48
end

function sharpeye:GetCrosshairDynamicSize()
	return self:GetVar("xhair_dynamicsize") / 8.0 * 4
end

function sharpeye:GetCrosshairShadowSize()
	return self:GetVar("xhair_shadowsize") / 8.0 * 8
end

function sharpeye:GetCrosshairFocusSize()
	return self:GetVar("xhair_focussize") / 8.0 * 4
end

function sharpeye:GetCrosshairFocusShadowSize()
	return self:GetVar("xhair_focusshadowsize") / 8.0 * 4
end

function sharpeye:GetCrosshairFocusSpin()
	return self:GetVar("xhair_focusspin") / 4.0 * 0.1
end

function sharpeye:GetCrosshairFocusAngle()
	return self:GetVar("xhair_focusangle") * 11.25
end

function sharpeye.HUDShouldDraw( sName )

end

function sharpeye.HUDPaint()
end

function sharpeye.RenderScreenspaceEffects()

end

 