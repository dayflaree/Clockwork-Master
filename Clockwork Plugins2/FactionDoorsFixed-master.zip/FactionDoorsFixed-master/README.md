# FactionDoorsFixed
Fixed version of FactionDoors by Cervidae Kosmonaut. Fixed by Viz.

Uninstall the original version for this fix to work as intended.
