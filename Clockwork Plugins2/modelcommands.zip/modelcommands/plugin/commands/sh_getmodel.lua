local Clockwork = Clockwork;
 
local COMMAND = Clockwork.command:New("GetModel");
COMMAND.tip = "Get the model name of that you're looking at.";
COMMAND.text = "";
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor()
	local target = trace.Entity
	
	if IsValid(target) and IsEntity(target) then
		local targetModel = target:GetModel()
		
		Clockwork.player:Notify(player, targetModel);
	else
		Clockwork.player:Notify(player, "You must look at a valid entity!");
	end;
end;

COMMAND:Register();