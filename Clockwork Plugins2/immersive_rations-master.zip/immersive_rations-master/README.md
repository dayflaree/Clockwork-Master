# immersive_rations
Makes rations equippable and immersive.

# Workshop link (sound files)
https://steamcommunity.com/sharedfiles/filedetails/?id=1533582907
