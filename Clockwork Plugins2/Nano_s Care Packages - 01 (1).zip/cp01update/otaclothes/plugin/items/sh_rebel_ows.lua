--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Rebel Overwatch Uniform";
ITEM.replacement = "models/city8_overwatch.mdl";
ITEM.weight = 4.5;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A wearable Rebel Overwatch uniform.";


ITEM:Register();