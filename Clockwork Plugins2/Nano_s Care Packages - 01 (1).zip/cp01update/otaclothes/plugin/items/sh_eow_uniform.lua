--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Elite Overwatch Uniform";
ITEM.replacement = "models/Combine_Super_Soldier.mdl";
ITEM.weight = 6.5;
ITEM.access = "V";
ITEM.business = true;
ITEM.description = "A wearable Elite Overwatch uniform.";


ITEM:Register();