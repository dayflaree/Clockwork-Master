local Clockwork = Clockwork;

--This is alphabetical, and should be kept that way. 
Clockwork.animation:AddFemaleHumanModel("models/lambdamovement_female.mdl");
Clockwork.animation:AddMaleHumanModel("models/lambdamovement.mdl");

















