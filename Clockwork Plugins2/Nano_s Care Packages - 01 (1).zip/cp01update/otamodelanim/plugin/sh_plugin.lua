local Clockwork = Clockwork;

--This is alphabetical, and should be kept that way. 
Clockwork.animation:AddCombineOverwatchModel("models/city8_overwatch_elite.mdl");
Clockwork.animation:AddCombineOverwatchModel("models/city8_overwatch.mdl");



















