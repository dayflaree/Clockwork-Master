--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Lambda Uniform";
ITEM.weight = 3.5;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A unique Lambda Movement uniform.";
function ITEM:GetReplacement(player)
                if (player:GetGender() == GENDER_FEMALE) then
                return "models/lambdamovement_female.mdl"
                else
                return "models/lambdamovement.mdl"
        end;
end;

ITEM:Register();