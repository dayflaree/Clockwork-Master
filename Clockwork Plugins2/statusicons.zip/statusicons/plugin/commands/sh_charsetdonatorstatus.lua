COMMAND = Clockwork.command:New("CharSetDonatorStatus")
COMMAND.tip = "Grant or revoke a player's donator status.";
COMMAND.text = "<string Name>";
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
        local target = Clockwork.player:FindByID( arguments[1] );
        
        if (target) then
                if (!Clockwork.player:HasFlags(target, "D")) then
                        Clockwork.player:NotifyAll(" "..target:Name().." has been granted donator status.");
                        Clockwork.player:GiveFlags(target, "D")
                        target:SetData("donator", 1)
                        Clockwork.player:LightSpawn(target, true, true);
                else
                        Clockwork.player:NotifyAll(""..target:Name().."'s donator status has been revoked.");
                        Clockwork.player:TakeFlags(target, "D")
                        target:SetData("donator", 0)
                        Clockwork.player:LightSpawn(target, true, true);

                end
        else
                Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
        end;
end;

COMMAND:Register();