local PLUGIN = PLUGIN;

Clockwork.flag:Add("D", "Donator", "Access to Donator benefits in OOC chat.");
Clockwork.flag:Add("H", "Honorable", "Access to Honorable memeber benefits in OOC chat.");