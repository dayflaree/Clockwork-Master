local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitPostEntity()
    self:LoadCraftingTables();
    self:LoadForges();
end;

function PLUGIN:PostSaveData()
	self:SaveCraftingTables();
	self:SaveForges();
end;

Clockwork.datastream:Hook("cwCraft", function(Player, data)
	if PLUGIN:CanMix(Player, Player:GetInventory(),data) and PLUGIN.MixtureDatabase[data].CanMix(Player) then
		local MixtureTable = PLUGIN.MixtureDatabase[data];
		if MixtureTable.RequiredEntity then
			if MixtureTable.RequiredEntity == "Forge" then
				if !PLUGIN:NearForge(Player) then
					Clockwork.player:Notify(Player, "You need to be near a source of heat.");
					Clockwork.datastream:Start(Player, "cwCraft_Rebuild");
					return false;
				end
			elseif MixtureTable.RequiredEntity == "Crafting Table" then
				if !PLUGIN:NearCraftingTable(Player) then
					Clockwork.player:Notify(Player, "You need to be near a crafting table");
					Clockwork.datastream:Start(Player, "cwCraft_Rebuild");
					return false;
				end
			end
		end
		
		if !Player:CanHoldWeight(Clockwork.item:FindByID(PLUGIN.MixtureDatabase[data].Produces).weight) then
			Clockwork.player:Notify(Player, "You do not have enough inventory space!");
			Clockwork.datastream:Start(Player, "cwCraft_Rebuild");
			return false; 
		end
		
		for k,v in pairs(PLUGIN.MixtureDatabase[data].Requires) do
			for i=1, v do
				Player:TakeItem(Player:FindItemByID(k))
			end
		end
		Player:GiveItem(PLUGIN.MixtureDatabase[data].Produces)
		Clockwork.datastream:Start(Player, "cwCraft_Rebuild");
	end
end);