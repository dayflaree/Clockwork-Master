ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.PrintName = "Forge";
ENT.Author = "Crapy";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.PhysgunDisabled = true;