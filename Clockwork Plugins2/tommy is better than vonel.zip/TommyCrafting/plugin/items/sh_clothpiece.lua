local ITEM = Clockwork.item:New();
ITEM.name = "Cloth Piece";
ITEM.cost = 6;
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl";
ITEM.weight = 0.1;
ITEM.business = false;
ITEM.description = "A light piece of cloth.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();