local ITEM = Clockwork.item:New();
ITEM.name = "Electrical Parts";
ITEM.cost = 6;
ITEM.model = "models/Items/battery.mdl";
ITEM.weight = 1;
ITEM.business = false;
ITEM.description = "A chunk of electrical parts. It seems to still have some life in it.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();