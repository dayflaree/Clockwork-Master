local ITEM = Clockwork.item:New();
ITEM.name = "Dangerous Chemicals";
ITEM.cost = 6;
ITEM.model = "models/props_junk/plasticbucket001a.mdl";
ITEM.weight = 2;
ITEM.business = false;
ITEM.description = "A bucket full of awful smelling chemicals.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();