local ITEM = Clockwork.item:New();
ITEM.name = "Plastic Piece";
ITEM.cost = 6;
ITEM.model = "models/Gibs/helicopter_brokenpiece_02.mdl";
ITEM.weight = 0.1;
ITEM.business = false;
ITEM.description = "A piece of plastic.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();