local ITEM = Clockwork.item:New();
ITEM.name = "Metal Pipe";
ITEM.cost = 6;
ITEM.model = "models/props_canal/mattpipe.mdl";
ITEM.weight = 2;
ITEM.business = false;
ITEM.description = "A metal pipe. You could probably knock someone out with this.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();