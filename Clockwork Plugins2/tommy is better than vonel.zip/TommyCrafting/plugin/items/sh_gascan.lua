local ITEM = Clockwork.item:New();
ITEM.name = "Gas Can";
ITEM.cost = 6;
ITEM.model = "models/props_junk/gascan001a.mdl";
ITEM.weight = 3;
ITEM.business = false;
ITEM.description = "A large can of gasoline.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();