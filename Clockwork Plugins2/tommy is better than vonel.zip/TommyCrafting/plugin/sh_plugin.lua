local PLUGIN = PLUGIN;

PLUGIN.MixtureDatabase = {};
PLUGIN.CraftText = "Combine ingredients near a crafting table.";
PLUGIN.ForgeText = "Combine ingredients near a source of heat.";

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

function PLUGIN:RegisterMixture(MixtureTable) 
	local FoundError = false;
	for k,v in pairs(MixtureTable.Requires) do
		if !Clockwork.item:FindByID(k) then
			FoundError = true;
			print("ERROR LOADING ITEM "..k.." IN MIXTURE "..MixtureTable.ID); 
		end
	end
	if !Clockwork.item:FindByID(MixtureTable.Produces) then
		FoundError = true;
		print("ERROR LOADING MIXTURE: "..MixtureTable.ID); 
	end
	
	if !FoundError then
		self.MixtureDatabase[MixtureTable.ID] = MixtureTable;
	end
end

for k, v in pairs(_file.Find(PLUGIN:GetBaseDir().."/mixtures/*.lua", "LUA", "namedesc")) do
	Clockwork.kernel:IncludePrefixed(PLUGIN:GetBaseDir().."/mixtures/"..v);
end;


function PLUGIN:NearCraftingTable(Player)
	for k,v in pairs(ents.FindInSphere(Player:GetPos(), 64)) do
		if v:GetClass() == "cw_craftingtable" then
			return true;
		end
	end
end

function PLUGIN:NearForge(Player)
	for k,v in pairs(ents.FindInSphere(Player:GetPos(), 64)) do
		if v:GetClass() == "cw_forge" then
			return true;
		end
	end
end


function PLUGIN:CanMix(Player, Inventory, MixtureID)
	if self.MixtureDatabase[MixtureID] then
		local MixtureTable = self.MixtureDatabase[MixtureID]
		local ItemTable = Clockwork.item:FindByID(MixtureTable.Produces);
		local HasIngredients = true;
		for k,v in pairs(MixtureTable.Requires) do
			local UniqueID = Clockwork.item:FindByID(k).uniqueID
			if !Inventory[UniqueID] or table.Count(Inventory[UniqueID]) < v then
				HasIngredients = false;
			end
		end
		
		if !HasIngredients or (MixtureTable.HasFlags and !Clockwork.player:HasFlags(Player, MixtureTable.HasFlags)) then
			return false;
		end
		
		return true;
	end

	return false;
end;