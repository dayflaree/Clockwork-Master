local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_refined_plastic_piece';
MIXTURE.Name = 'Refined Plastic Piece';
MIXTURE.Requires = {["Plastic Piece"] = 2, ["Gas Can"] = 1};
MIXTURE.Produces = 'Refined Plastic Piece';
MIXTURE.Produces_Text = 'Extremely High Quality plastic, many uses in industrial settings';
MIXTURE.RequiredEntity = "Forge"

MIXTURE.HasFlags = "j"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);