local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_biogelhealthkit';
MIXTURE.Name = 'Health Kit';
MIXTURE.Requires = {["Health Vial"] = 1, ["Plastic Piece"] = 1, ["Bandage"] = 1};
MIXTURE.Produces = 'Health Kit';
MIXTURE.Produces_Text = 'A newly crafted health kit, containing medical essentials.';
MIXTURE.RequiredEntity = "Forge"


function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);