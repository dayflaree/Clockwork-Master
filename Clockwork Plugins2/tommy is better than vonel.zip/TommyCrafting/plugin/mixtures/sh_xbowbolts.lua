local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_xbowbolts';
MIXTURE.Name = 'Crossbow Bolts';
MIXTURE.Requires = {["Metal Pipe"] = 2, ["Gas Can"] = 1};
MIXTURE.Produces = 'Crossbow Bolts';
MIXTURE.Produces_Text = 'A set of iron bolts, the coating is rusting away.';
MIXTURE.RequiredEntity = "Forge"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);