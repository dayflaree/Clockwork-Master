local PLUGIN = PLUGIN;

local MIXTURE = {};

MIXTURE.ID = 'mixture_pistol';
MIXTURE.Name = 'Pistol';
MIXTURE.Requires = {["Metal Piece"] = 3, ["Plastic Piece"] = 2, ["Electrical Parts"] = 1};
MIXTURE.Produces = 'USP Pistol';
MIXTURE.Produces_Text = 'A basic pistol crafted finely, a very nice item.';
MIXTURE.RequiredEntity = "Forge"

MIXTURE.HasFlags = "j"

function MIXTURE.CanMix ( Player )
	return true;
end

PLUGIN:RegisterMixture(MIXTURE);