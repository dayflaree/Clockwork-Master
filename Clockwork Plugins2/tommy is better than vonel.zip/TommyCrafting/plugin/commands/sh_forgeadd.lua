local COMMAND = Clockwork.command:New("ForgeAdd");

COMMAND.tip = "Add a forge at your position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	if (!trace.Hit) then return end
	
	local whychessnut = ents.Create("cw_forge");
	local entity = whychessnut:SpawnFunction(player, trace)
	whychessnut:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a forge.");
	end;
end;

COMMAND:Register()