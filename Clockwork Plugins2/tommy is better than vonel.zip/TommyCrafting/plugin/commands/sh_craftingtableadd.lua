local COMMAND = Clockwork.command:New("CraftingTableAdd");

COMMAND.tip = "Add a Crafting Table at your position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	if (!trace.Hit) then return end
	
	local whychessnut = ents.Create("cw_craftingtable");
	local entity = whychessnut:SpawnFunction(player, trace)
	whychessnut:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a crafting table.");
	end;
end;

COMMAND:Register()