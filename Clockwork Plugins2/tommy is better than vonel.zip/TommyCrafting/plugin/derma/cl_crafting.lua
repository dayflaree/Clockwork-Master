local Clockwork = Clockwork;
local PLUGIN = PLUGIN;
local IsValid = IsValid;
local pairs = pairs;
local ScrH = ScrH;
local ScrW = ScrW;
local table = table;
local vgui = vgui;
local math = math;

local PANEL = {};
local DisableButtons = false;

function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());
	
	self.panelList = vgui.Create("cwPanelList", self);
 	self.panelList:SetPadding(2);
 	self.panelList:SetSpacing(2);
 	self.panelList:SizeToContents();
	self.panelList:EnableVerticalScrollbar();
	
	self.DisableButtons = false;
	
	self:Rebuild();
end;

function PANEL:Rebuild()
	self.panelList:Clear();
	local ToMix = 0;
	for k,v in pairs(PLUGIN.MixtureDatabase) do
		if PLUGIN:CanMix(Clockwork.Client, Clockwork.inventory:GetClient(), v.ID) and Clockwork.item:FindByID(v.Produces) then
			ToMix = ToMix + 1
			local RequiredString = ""
			for k,v in pairs(v.Requires) do
				RequiredString = RequiredString .. v .. "x "..k.. " ";
			end
			local panel = vgui.Create("panel")
			panel:SetSize(self.panelList:GetWide()-8, 120)
			panel:SetPos(5, 5)
			panel.Paint = function()
				draw.RoundedBox( 1, 0, 0, panel:GetWide(), panel:GetTall(), Color( 140, 140, 140, 255))
				draw.DrawText(v.Produces_Text, "Default", 85, 25, Color(245, 245, 245, 255), TEXT_ALIGN_LEFT)
				draw.DrawText("Requires: "..RequiredString, "Default", 85, 75, Color(245, 245, 245, 255), TEXT_ALIGN_LEFT)
				if v.RequiredEntity then
					if v.RequiredEntity == "Forge" then
						draw.DrawText(PLUGIN.ForgeText, "Default", 85, 95, Color(245, 245, 245, 255), TEXT_ALIGN_LEFT)
					elseif v.RequiredEntity == "Crafting Table" then
						draw.DrawText(PLUGIN.CraftText, "Default", 85, 95, Color(245, 245, 245, 255), TEXT_ALIGN_LEFT)
					end
				end
			end
			local Icon = vgui.Create("SpawnIcon", panel)
			Icon:SetModel(Clockwork.item:FindByID(v.Produces).model)
			Icon:SetSize(64, 64)
			Icon:SetPos(10, 27)
			Icon:SetToolTip(v.Name)
			Icon.PaintOver = function(w, h) end
			Icon.PerformLayout = function() end
			Icon.Paint = function()
				draw.RoundedBox( 1, 0, 0, Icon:GetWide(), Icon:GetTall(), Color(255, 255, 255, 255))
				draw.RoundedBox( 1, 1, 1, Icon:GetWide()-2, Icon:GetTall()-2, Color(120, 120, 120, 255))
			end
			function Icon:LayoutEntity( Entity ) return end
			
			local CraftButton = vgui.Create("DButton", panel)
			CraftButton:SetText("Craft")
			CraftButton:SetSize(45, 22)
			CraftButton:SetPos(panel:GetWide()-CraftButton:GetWide()-12, 10)
			CraftButton.DoClick = function()
				self.DisableButtons = true;
				Clockwork.datastream:Start("cwCraft", v.ID);
			end
			CraftButton.Think = function()
				if self.DisableButtons != CraftButton:GetDisabled() then
					CraftButton:SetDisabled(self.DisableButtons);
				end
			end
			
			self.panelList:AddItem(panel)
		end
	end
	if ToMix < 1 then
		local panel = vgui.Create("DPanel")
		panel:SetSize(self.panelList:GetWide()-8, 120)
		panel:SetPos(5,5)
		
		local label = vgui.Create("DLabel", panel)
		label:SetText("Hey what are you doing here?")
		label:SizeToContents();
		label:Center();
		self.panelList:AddItem(panel)
	end
	self.panelList:InvalidateLayout(true);
end;

function PANEL:OnMenuOpened()
	if (Clockwork.menu:IsPanelActive(self)) then
		self:Rebuild();
	end;
end;

Clockwork.datastream:Hook("cwCraft_Rebuild", function(data)
	local activePanel = Clockwork.menu:GetActivePanel();
	
	if (activePanel and activePanel:GetPanelName() == "Crafting") then
		activePanel:Rebuild();
		activePanel.DisableButtons = false;
	end;
end);

function PANEL:OnSelected() self:Rebuild(); end;

function PANEL:PerformLayout(w, h)
	self.panelList:StretchToParent(4, 28, 4, 4);
	self:SetSize(w, math.min(self.panelList.pnlCanvas:GetTall() + 32, ScrH() * 0.75));
end;

function PANEL:Paint(w, h)
	derma.SkinHook("Paint", "Frame", self, w, h);
	
	return true;
end;

function PANEL:Think()
	self:InvalidateLayout(true);
end;

vgui.Register("cwCrafting", PANEL, "EditablePanel");