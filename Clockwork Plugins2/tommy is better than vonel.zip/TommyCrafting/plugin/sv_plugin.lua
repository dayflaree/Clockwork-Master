local Clockwork = Clockwork;

local PLUGIN = PLUGIN;

function PLUGIN:LoadCraftingTables()
	local CraftingTables = Clockwork.kernel:RestoreSchemaData("plugins/craftingsystem/craftingtable/"..game.GetMap());
	
	for k, v in pairs(CraftingTables) do
		local entity = ents.Create("cw_craftingtable");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		entity:Activate();

		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
	end;
end;

function PLUGIN:LoadForges()
	local Forges = Clockwork.kernel:RestoreSchemaData("plugins/craftingsystem/forge/"..game.GetMap());
	
	for k, v in pairs(Forges) do
		local entity = ents.Create("cw_forge");
		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		entity:Activate();

		local physicsObject = entity:GetPhysicsObject();
		
		if ( IsValid(physicsObject) ) then
			physicsObject:EnableMotion(false);
		end;
	end;
end;

function PLUGIN:SaveCraftingTables()
	local CraftingTables = {};
	
	for k, v in pairs(ents.FindByClass("cw_craftingtable")) do
		local position = v:GetPos();
		local angles = v:GetAngles();

		CraftingTables[#CraftingTables + 1] = {
			position = position,
			angles = angles
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/craftingsystem/craftingtable/"..game.GetMap(), CraftingTables);
end;

function PLUGIN:SaveForges()
	local Forges = {};
	
	for k, v in pairs(ents.FindByClass("cw_forge")) do
		local position = v:GetPos();
		local angles = v:GetAngles();

		Forges[#Forges + 1] = {
			position = position,
			angles = angles
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/craftingsystem/forge/"..game.GetMap(), Forges);
end;

