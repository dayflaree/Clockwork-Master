local PLUGIN = PLUGIN;

function PLUGIN:MenuItemsAdd(menuItems)
	menuItems:Add("Crafting", "cwCrafting", "Craft items into something nice.");
end