local Clockwork = Clockwork;

--This is alphabetical, and should be kept that way. 
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/arctic_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/badass_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/biopolice.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/blacop.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/c08cop.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/civil_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/elite_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/female_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hd_barney.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hdpolice.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hl2beta_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hl2concept.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/hunter_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/phoenix_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/police_bt.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/police_fragger.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/policetrench.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/resistance_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/retrocop.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/rogue_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/rtb_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/steampunk_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/tf2_metrocop.mdl")
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/tribal_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/tron_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/urban_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/dpfilms/metropolice/zombie_police.mdl");
Clockwork.animation:AddCivilProtectionModel("models/blacop_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/leet_police3_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/leet_police4_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/leet_police5_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/metrold_nobp_medic.mdl");
Clockwork.animation:AddCivilProtectionModel("models/policetrench2_medic.mdl");
