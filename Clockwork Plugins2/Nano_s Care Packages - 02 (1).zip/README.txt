its not copyrighted by nano.
but i made it.
visit me on:
www.steamcommunity.com/profiles/76561198038479821/


also you guys really need to stop being mad
its only game.
;^)

Put all of this stuff in cwhl2rp/plugins

And enjoy. Map restart will be needed obviously. 
NOTE: Clothes are disabled for business; don't freak out when you
dont see 'em.

also:
shoutout to whatever server uses my plugins. I truly feel happy when I see someone using it




































(although i pretty much only minge now)