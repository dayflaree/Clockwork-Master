--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "HELIX - Standard Uniform";
ITEM.replacement = "models/dpfilms/metropolice/civil_medic.mdl";
ITEM.weight = 3.7;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A light-weight uniform with medical equipment attached to it.";


ITEM:Register();