--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "CITY 08 - Uniform";
ITEM.replacement = "models/dpfilms/metropolice/c08cop.mdl";
ITEM.weight = 3.5;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A unique, general uniform for City 8.";


ITEM:Register();