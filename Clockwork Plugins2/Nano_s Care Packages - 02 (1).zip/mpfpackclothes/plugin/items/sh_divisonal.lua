--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "UU - Divisonal Leader Uniform";
ITEM.replacement = "models/dpfilms/metropolice/blacop.mdl";
ITEM.weight = 3.9;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A slim, dark-shaded uniform with multiple glowing lights on it.";


ITEM:Register();