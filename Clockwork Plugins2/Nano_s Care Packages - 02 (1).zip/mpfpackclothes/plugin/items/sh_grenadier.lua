--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "UNION - Grenadier/Heavy Uniform";
ITEM.replacement = "models/dpfilms/metropolice/rtb_police.mdl";
ITEM.weight = 6.5;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A huge, dark, uniform with equipment attached to it.";


ITEM:Register();