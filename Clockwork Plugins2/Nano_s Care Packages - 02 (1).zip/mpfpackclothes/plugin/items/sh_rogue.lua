--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "ROGUE - General Uniform";
ITEM.replacement = "models/dpfilms/metropolice/rogue_police.mdl";
ITEM.weight = 2.3;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A dark, suspicious looking rogue uniform.";


ITEM:Register();