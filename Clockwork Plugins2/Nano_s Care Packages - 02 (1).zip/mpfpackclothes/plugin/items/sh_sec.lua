--[[
	?2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "UU - Sectorial/Commanding Uniform";
ITEM.replacement = "models/dpfilms/metropolice/phoenix_police.mdl";
ITEM.weight = 4.5;
ITEM.access = "V";
ITEM.business = false;
ITEM.description = "A slim, dark-shaded red uniform that has a 'UU' patch on the side.";


ITEM:Register();