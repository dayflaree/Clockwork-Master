--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Porn Magazine";
ITEM.cost = 25;
ITEM.model = "models/porn.mdl";
ITEM.weight = 0.5;
ITEM.access = "1";
ITEM.business = false;
ITEM.category = "Lewd";
ITEM.description = "A Magainze containing NSFW content of Russian models.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();