--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Bear Detector";
ITEM.cost = 3200;
ITEM.model = "models/kali/miscstuff/stalker/detector_bear.mdl";
ITEM.weight = 0.5;
ITEM.access = "2";
ITEM.business = false;
ITEM.category = "Detector";
ITEM.description = "The last generation of anomalous activity detector can be used to locate anomalous formations and has a color diode panel, which not only indicates the direction of artifacts, but also measures the distance to them. To switch to artifact search mode, open the device's front cover. Unfortunately the device is programmed with a somewhat outdated list of detectable artifacts.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();