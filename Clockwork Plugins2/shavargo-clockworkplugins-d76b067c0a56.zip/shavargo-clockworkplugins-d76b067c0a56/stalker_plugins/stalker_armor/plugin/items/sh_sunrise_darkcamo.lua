--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");

ITEM.name = "Dark Camo Sunrise";
ITEM.model = "models/tnb/stalker/items/sunrise.mdl";
ITEM.uniqueID = "sunrise_darkcamo";
ITEM.access = "0";
ITEM.batch = 1;
ITEM.weight = 5;
ITEM.business = true;
ITEM.protection = 35;
ITEM.cost = 12000;
ITEM.description = "Offers little protection from gunfire or claws and it's absolutely useless against radiation or anomalies .";

-- Called when a player changes clothes.
function ITEM:OnChangeClothes(player, bIsWearing)
	if (bIsWearing) then
		local model = player:GetModel();
		local sunrise = string.Replace( model, "anorak", "sunrise" );
		player:SetModel(sunrise)
		player:SetSkin(6);
	else
		Clockwork.player:SetDefaultModel(player);
		Clockwork.player:SetDefaultSkin(player);
	end;
	
	if (self.OnChangedClothes) then
		self:OnChangedClothes(player, bIsWearing);
	end;
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, extraData)
	player:RemoveClothes();
end;

ITEM:Register();