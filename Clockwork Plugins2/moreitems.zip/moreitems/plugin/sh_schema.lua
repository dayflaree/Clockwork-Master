local PLUGIN = PLUGIN;

Clockwork.flag:Add("L", "More Items", "Access to More items in the business menu.");
