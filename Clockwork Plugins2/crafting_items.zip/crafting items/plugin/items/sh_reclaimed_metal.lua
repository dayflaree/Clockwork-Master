local ITEM = Clockwork.item:New();
ITEM.name = "Reclaimed Metal";
ITEM.cost = 50;
ITEM.model = "models/gibs/metal_gib4.mdl";
ITEM.weight = 0.5;
ITEM.access = "b";
ITEM.category = "Crafting";
ITEM.business = true;
ITEM.description = "A reclaimed metal, it can be used to craft something.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();