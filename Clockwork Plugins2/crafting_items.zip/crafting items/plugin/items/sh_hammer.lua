local ITEM = Clockwork.item:New();
ITEM.name = "Hammer";
ITEM.cost = 50;
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
ITEM.weight = 0.2;
ITEM.access = "b";
ITEM.category = "Crafting";
ITEM.business = true;
ITEM.description = "A hammer, it's a tool that helps you to craft something.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();