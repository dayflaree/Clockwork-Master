local ITEM = Clockwork.item:New();
ITEM.name = "Scrap Plastic";
ITEM.cost = 10;
ITEM.model = "models/props_junk/garbage_plasticbottle001a.mdl";
ITEM.weight = 0.5;
ITEM.access = "b";
ITEM.category = "Crafting";
ITEM.business = true;
ITEM.description = "A scrap plastic, it can be used to craft something.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();