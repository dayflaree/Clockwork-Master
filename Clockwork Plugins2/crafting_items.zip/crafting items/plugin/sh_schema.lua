local PLUGIN = PLUGIN;

Clockwork.flag:Add("b", "Crafting Union", "Access to crafting union goods.");