
ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"
ENT.PrintName			= ""
ENT.Author			= ""
ENT.Purpose			= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
