
ENT.Spawnable			= false
ENT.AdminSpawnable		= false

include('shared.lua')

language.Add( "sent_rocket", "Rocket" )