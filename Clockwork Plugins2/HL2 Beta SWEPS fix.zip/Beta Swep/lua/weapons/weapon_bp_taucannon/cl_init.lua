include('shared.lua')
	language.Add("weapon_bp_taucannon", "Tau Cannon")
	SWEP.PrintName		= "Tau Cannon"
	SWEP.Slot		= 5
	SWEP.SlotPos		= 1
	SWEP.CSMuzzleFlashes    = true
	SWEP.ViewModelFOV	= 56
	SWEP.Drawammo 		= false
	SWEP.DrawCrosshair 	= true
	SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/tau_cannon") 
	SWEP.DrawWeaponInfoBox	= false
	SWEP.BounceWeaponIcon = false 