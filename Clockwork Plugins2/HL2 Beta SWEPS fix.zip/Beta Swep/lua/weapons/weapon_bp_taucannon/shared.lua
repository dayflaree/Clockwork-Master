AddCSLuaFile("shared.lua")

if CLIENT then

	function SWEP:GetBoneOrientation( basetab, tab, ent, bone_override )
		
		local bone, pos, ang
		if (tab.rel and tab.rel != "") then
			
			local v = basetab[tab.rel]
			
			if (!v) then return end
			
			pos, ang = self:GetBoneOrientation( basetab, v, ent )
			
			if (!pos) then return end
			
			pos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
				
		else
		
			bone = ent:LookupBone(bone_override or tab.bone)

			if (!bone) then return end
			
			pos, ang = Vector(0,0,0), Angle(0,0,0)
			local m = ent:GetBoneMatrix(bone)
			if (m) then
				pos, ang = m:GetTranslation(), m:GetAngles()
			end
			
			if (IsValid(self.Owner) and self.Owner:IsPlayer() and 
				ent == self.Owner:GetViewModel() and self.ViewModelFlip) then
				ang.r = -ang.r // Fixes mirrored models
			end
		
		end
		
		return pos, ang
	end


	
	local allbones
	local hasGarryFixedBoneScalingYet = false

	function SWEP:UpdateBonePositions(vm)
		if self.ARitzHadToFixTheBoneResetGlitchOnHisFuckingOwn then return end --Fucking hell!
		if self.ViewModelBoneMods then
			
			if (!vm:GetBoneCount()) then return end
			
			local loopthrough = self.ViewModelBoneMods
			if (!hasGarryFixedBoneScalingYet) then
				allbones = {}
				for i=0, vm:GetBoneCount() do
					local bonename = vm:GetBoneName(i)
					if (self.ViewModelBoneMods[bonename]) then 
						allbones[bonename] = self.ViewModelBoneMods[bonename]
					else
						allbones[bonename] = { 
							scale = Vector(1,1,1),
							pos = Vector(0,0,0),
							angle = Angle(0,0,0)
						}
					end
				end
				
				loopthrough = allbones
			end
			
			for k, v in pairs( loopthrough ) do
				local bone = vm:LookupBone(k)
				if (!bone) then continue end
				
				local s = Vector(v.scale.x,v.scale.y,v.scale.z)
				local p = Vector(v.pos.x,v.pos.y,v.pos.z)
				local ms = Vector(1,1,1)
				if (!hasGarryFixedBoneScalingYet) then
					local cur = vm:GetBoneParent(bone)
					while(cur >= 0) do
						local pscale = loopthrough[vm:GetBoneName(cur)].scale
						ms = ms * pscale
						cur = vm:GetBoneParent(cur)
					end
				end
				
				s = s * ms
				
				if vm:GetManipulateBoneScale(bone) != s then
					vm:ManipulateBoneScale( bone, s )
				end
				if vm:GetManipulateBoneAngles(bone) != v.angle then
					vm:ManipulateBoneAngles( bone, v.angle )
				end
				if vm:GetManipulateBonePosition(bone) != p then
					vm:ManipulateBonePosition( bone, p )
				end
			end
		else
			self:ResetBonePositions(vm)
		end
		   
	end
	 
	function SWEP:ResetBonePositions(vm)
		
		if (!vm:GetBoneCount()) then return end
		for i=0, vm:GetBoneCount() do
			vm:ManipulateBoneScale( i, Vector(1, 1, 1) )
			vm:ManipulateBoneAngles( i, Angle(0, 0, 0) )
			vm:ManipulateBonePosition( i, Vector(0, 0, 0) )
		end
		
	end

	function table.FullCopy( tab )

		if (!tab) then return nil end
		
		local res = {}
		for k, v in pairs( tab ) do
			if (type(v) == "table") then
				res[k] = table.FullCopy(v) // recursion ho!
			elseif (type(v) == "Vector") then
				res[k] = Vector(v.x, v.y, v.z)
			elseif (type(v) == "Angle") then
				res[k] = Angle(v.p, v.y, v.r)
			else
				res[k] = v
			end
		end
		
		return res
		
	end

	function SWEP:ViewModelDrawn()
		local vm = self.Owner:GetViewModel()
		if !IsValid(vm) then return end
		self:UpdateBonePositions(vm)
	end
SWEP.ViewModelBoneMods = {
	["Spinner"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 0, -180) },
	["Fan"] = { scale = Vector(1, 1, 1), pos = Vector(0, 0, 0), angle = Angle(0, 0, -180) }
}

	SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/tau_cannon") 
	SWEP.DrawWeaponInfoBox	= false
	SWEP.BounceWeaponIcon = false 
	
else
 

	resource.AddFile( "materials/models/weapons/V_Gauss/back.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/back.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/capacitor.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/capacitor.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/coils.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/coils.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/details1.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/details1.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/fan.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/fan.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/fanback.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/fanback.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/generator.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/generator.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/glowCHROME.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/glowCHROME.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/glowtube.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/glowtube.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/hand.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/hand.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/spindle.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/spindle.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/stock.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/stock.vtf" )
	resource.AddFile( "materials/models/weapons/V_Gauss/supportarm.vmt" )
	resource.AddFile( "materials/models/weapons/V_Gauss/supportarm.vtf" )
	resource.AddFile( "models/weapons/w_gauss.dx80.vtx" )
	resource.AddFile( "models/weapons/w_gauss.dx90.vtx" )
	resource.AddFile( "models/weapons/w_gauss.mdl" )
	resource.AddFile( "models/weapons/w_gauss.phy" )
	resource.AddFile( "models/weapons/w_gauss.sw.vtx" )
	resource.AddFile( "models/weapons/w_gauss.vvd" )
	resource.AddFile( "models/weapons/v_gaus5.dx80.vtx" )
	resource.AddFile( "models/weapons/v_gaus5.dx90.vtx" )
	resource.AddFile( "models/weapons/v_gaus5.mdl" )
	resource.AddFile( "models/weapons/v_gaus5.sw.vtx" )
	resource.AddFile( "models/weapons/v_gaus5.vvd" )
	util.AddNetworkString( "Taucannonfire" )
	util.AddNetworkString( "Taucannonlaser" )
end
SWEP.TauCannon = true
SWEP.Category = "HL2 Beta Sweps"
SWEP.HoldType = "smg"

SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.UseHands = false
SWEP.ViewModel = "models/weapons/v_gaus5.mdl";
SWEP.WorldModel = "models/weapons/w_gauss.mdl";
SWEP.ViewModelFOV = 56

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = true
SWEP.Secondary.Ammo = "none"

SWEP.PrintName = "Tau Cannon"
SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

SWEP.Weight = 10;
SWEP.AutoSwitchTo = false;
SWEP.AutoSwitchFrom = false;
--game.AddDecal( "taushot", "decals/redglowfade" ) 

function SWEP:Initialize()
	self:SetWeaponHoldType( self.HoldType )
	if CLIENT then
		self.charge = CreateSound(self, "weapons/gauss/chargeloop.wav" )
		self.PowerLevel = 0
		self.SpinSpeed = 1
		self.SpinType = false --True = Charge | False = Idle
		self.SpinAng = -31337
		self.FanAng = -31337
		self.Charging = false
		self.ChargeDelay = 0
		self.ChargeOver = 1.2
		self.ViewModelBoneMods = table.FullCopy( self.ViewModelBoneMods )
		if IsValid(self.Owner) then
			local vm = self.Owner:GetViewModel()
			if IsValid(vm) then
				self:ResetBonePositions(vm)
				
				if (self.ShowViewModel == nil or self.ShowViewModel) then
					vm:SetColor(Color(255,255,255,255))
				else
					vm:SetColor(Color(255,255,255,1))
					vm:SetMaterial("Debug/hsv")			
				end
			end
		end
	end
end


function SWEP:PrimaryAttack()
	if self:IsUnderWater() then return end
	if SERVER then
		net.Start("Taucannonfire")
		net.WriteBit(false)
		net.Send(self.Owner)
	end
	self.Idle = true
	self.IdleDelay = CurTime() + 1
	self:EmitSound("weapons/gauss/fire1.wav")
	self:EmitSound("weapons/1gauss/electro"..math.random(1,3)..".wav")
	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	local trace = self.Owner:GetEyeTrace()
	local length = (self.Owner:GetShootPos() - trace.HitPos):Length()
	local bullet = {}
	bullet.Num 		= 1
	bullet.Src 		= self.Owner:GetShootPos()			-- Source
	bullet.Dir 		= self.Owner:GetAimVector()			-- Dir of bullet
	bullet.Spread 	= Vector( 0, 0, 0 )			-- Aim Cone
	bullet.Tracer	= 1									-- Show a tracer on every x bullets 
	bullet.Force	= 1								-- Amount of force to give to phys objects
	bullet.Damage	= 20
	bullet.AmmoType = "GaussEnergy"
	self.Owner:ViewPunch( Angle( math.random(-.5, .5), math.random(-.5, .5), math.random(-.5, .5) ) )
	self.Owner:SetVelocity(self.Owner:GetAimVector()*-80)
	self.Owner:FireBullets( bullet )
	local Pos1 = trace.HitPos + trace.HitNormal
	local Pos2 = trace.HitPos - trace.HitNormal
	util.Decal( "RedGlowFade", Pos1, Pos2 ) 
	local effectdata = EffectData()
		effectdata:SetOrigin( trace.HitPos )
		effectdata:SetStart( self.Owner:GetShootPos() )
		effectdata:SetAttachment( 1 )
		effectdata:SetEntity( self.Weapon )
		effectdata:SetScale( length * 10 )	
		effectdata:SetMagnitude( 20 )	
	util.Effect( "bp_arctaucannon", effectdata )
	self:SetNextPrimaryFire(CurTime()+0.2)
	self:SetNextSecondaryFire(CurTime()+0.2)
end
function SWEP:SecondaryAttack()
	if self:IsUnderWater() then return end
	if SERVER then
		net.Start("Taucannonfire")
		net.WriteBit(true)
		net.Send(self.Owner)
		if !self.Charging then
			self:SendWeaponAnim( ACT_VM_PULLBACK_LOW )
			self.Charging = true
			self.ReloadAnim = true
			self.ReloadDelay = CurTime() + 1
		end
	end
	self:SetNextPrimaryFire(CurTime()+0.01)
	self:SetNextSecondaryFire(CurTime()+0.01)
end
function SWEP:CrgTauBlt(pwr)
	local force = (25 + pwr*175)/20
	local bullet = {}
	bullet.Num 		= 1
	bullet.Src 		= self.Owner:GetShootPos()			-- Source
	bullet.Dir 		= self.Owner:GetAimVector()			-- Dir of bullet
	bullet.Spread 	= Vector( 0, 0, 0 )			-- Aim Cone
	bullet.Tracer	= 1									-- Show a tracer on every x bullets 
	bullet.Force	= force							-- Amount of force to give to phys objects
	bullet.Damage	= 25 + pwr*185
	bullet.TracerName = "AR2Tracer"
	bullet.AmmoType = "GaussEnergy"
	self.Owner:FireBullets( bullet )
end
net.Receive( "Taucannonlaser", function(length)
	local weapon = net.ReadEntity()
	local tab = net.ReadTable() 
	if !weapon.TauCannon then return end
	weapon:Laser(tab[1],tab[2],tab[3],tab[4])
end)
function SWEP:IsUnderWater()
	if self:WaterLevel() < 3 then
		return false
	else
		if SERVER then
			--local pos = self:GetPos()+Vector(0,0,50)
			local pos = (self.Owner:GetShootPos() + self.Owner:GetAimVector()*40)-Vector(0,0,25)
			tes = ents.Create( "point_tesla" )
			tes:SetPos( pos )
			tes:SetKeyValue( "m_SoundName", "DoSpark" )
			tes:SetKeyValue( "texture", "sprites/laserbeam.spr" )
			tes:SetKeyValue( "m_Color", "255 180 180" )
			tes:SetKeyValue("rendercolor", "255 180 180")
			tes:SetKeyValue( "m_flRadius", "100" )
			tes:SetKeyValue( "beamcount_max", "10" )
			tes:SetKeyValue( "thick_min", "5" )
			tes:SetKeyValue( "thick_max", "10" )
			tes:SetKeyValue( "lifetime_min", "0.1" )
			tes:SetKeyValue( "lifetime_max", "0.3" )
			tes:SetKeyValue( "interval_min", "0.1" )
			tes:SetKeyValue( "interval_max", "0.2" )
			tes:Spawn()
			tes:Fire( "DoSpark", "", 0 )
			tes:Fire( "DoSpark", "", 0.1 )
			tes:Fire( "DoSpark", "", 0.2 )
			tes:Fire( "DoSpark", "", 0.3 )
			tes:Fire( "kill", "", 0.3 )
			local hitdie = ents.Create("point_hurt"); --This is what kills stuff
			hitdie:SetKeyValue("Damage",100)
			hitdie:SetKeyValue("DamageRadius",100)
			hitdie:SetKeyValue("DamageType","SHOCK")
			hitdie:SetParent( self.Owner )
			hitdie:SetPos( pos )
			hitdie:Spawn();
			hitdie:Fire("hurt","",0.1); -- ACTIVATE THE POINT_HURT
			hitdie:Fire("kill","",1.2);
		end
		self.Idle = true
		self.IdleDelay = CurTime() + 1
		self:EmitSound("ambient/energy/weld"..math.random(1,2)..".wav")
		self:EmitSound("weapons/1gauss/electro"..math.random(1,3)..".wav")
		self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK )
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
		self:SetNextPrimaryFire(CurTime()+0.8)
		self:SetNextSecondaryFire(CurTime()+0.8)
		return true
	end
end
function SWEP:Laser(player,from, to, mag)
	if SERVER then
	local Ang = self.Owner:GetEyeTrace().HitNormal:Angle()
	Ang.pitch = Ang.pitch + 90
	local spark = ents.Create("env_spark")
	spark:SetPos( to )
	spark:SetAngles(Ang)
	spark:Spawn()
	spark:SetKeyValue("targetname", "entItem")
	spark:SetKeyValue("spawnflags","128")
	spark:SetKeyValue("Magnitude",5)
	spark:SetKeyValue("TrailLength",3)
	spark:Fire( "SparkOnce","",0.0 )
	spark:Fire("kill","",0.2)
	--[[
	entItem = ents.Create ("info_target")
	entItem:SetKeyValue("targetname", "entItem")
	entItem:Fire("kill", "", 0.15)
	entItem:SetPos(to)
	entItem:Spawn()
	]]
	beam = ents.Create("env_laser")
		beam:SetKeyValue("renderamt", "200")
		beam:SetKeyValue("rendercolor", "255 255 150")
		beam:SetKeyValue("texture", "sprites/laserbeam.spr")
		beam:SetKeyValue("TextureScroll", "14")
		beam:SetKeyValue("targetname", "beam" )
		beam:SetKeyValue("renderfx", "2")
		beam:SetKeyValue("width", ""..mag/100)
		beam:SetKeyValue("dissolvetype", "None")
		beam:SetKeyValue("EndSprite", "")
		beam:SetKeyValue("LaserTarget", "entItem")
		beam:SetKeyValue("TouchType", "-1")
		beam:SetKeyValue("NoiseAmplitude", ""..mag/6.66666666666666666666666666666666666666666666)
	beam:Spawn()
	beam:Fire("TurnOn", "", 0.01)
	beam:Fire("kill", "", 0.15)
	beam:SetPos(from)
	beam2 = ents.Create("env_laser")
		beam2:SetKeyValue("renderamt", "200")
		beam2:SetKeyValue("rendercolor", "255 145 "..math.random(0,16))
		beam2:SetKeyValue("texture", "sprites/laserbeam.spr")
		beam2:SetKeyValue("TextureScroll", "14")
		beam2:SetKeyValue("targetname", "beam" )
		beam2:SetKeyValue("renderfx", "2")
		beam2:SetKeyValue("width", ""..mag/25)
		beam2:SetKeyValue("dissolvetype", "None")
		beam2:SetKeyValue("EndSprite", "")
		beam2:SetKeyValue("LaserTarget", "entItem")
		beam2:SetKeyValue("TouchType", "-1")
		beam2:SetKeyValue("NoiseAmplitude", "0")
	beam2:Spawn()
	beam2:Fire("TurnOn", "", 0.01)
	beam2:Fire("kill", "", 0.15)
	beam2:SetPos(from)	
	
	end
end
net.Receive( "Taucannonfire", function(length)
	if SERVER then
		local weapon = net.ReadEntity()
		local hurt = tobool(net.ReadBit())
		if hurt then
			if weapon:Health() <= 0 then
				weapon:Kill()
			end
			if weapon:Armor() > 0 then
				weapon:SetArmor(weapon:Armor() - math.random(2,5)) --In this case, "weapon" is a player
				if weapon:Armor() < 0 then
					weapon:SetArmor(0)
				end
			else
				weapon:SetHealth(weapon:Health() - math.random(5,10)) --In this case, "weapon" is a player
			end
			weapon:ViewPunch( Angle( math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1) ) )
		return end
		if !weapon.TauCannon then return end
		local pwrlvl = net.ReadFloat()
		local ply = weapon:GetOwner()
		local force = (25 + pwrlvl*175)/20
		local punch = (pwrlvl*10)
		local trace = ply:GetEyeTrace()
		local length = (ply:GetShootPos() - trace.HitPos):Length()
		ply:ViewPunch( Angle( math.random(-punch, punch), math.random(-punch, punch), math.random(-punch, punch) ) )
		ply:SetVelocity(ply:GetAimVector()*-force*40)
		weapon:CrgTauBlt(pwrlvl)
		
	local effectdata = EffectData()
		effectdata:SetOrigin( trace.HitPos )
		effectdata:SetStart( ply:GetShootPos() )
		effectdata:SetAttachment( 1 )
		effectdata:SetEntity( weapon )
		effectdata:SetScale( length * 10 )	
		effectdata:SetMagnitude( 25 + pwrlvl*175 )	
	util.Effect( "bp_arctaucannon", effectdata )
		weapon:EmitSound("weapons/gauss/fire1.wav")
		weapon:EmitSound("weapons/1gauss/electro"..math.random(1,3)..".wav")
		if pwrlvl < 0.48 then
			weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK)
		else
			weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK)
		end
		weapon.Idle = true
		weapon.IdleDelay = CurTime() + 1
		local Pos1 = trace.HitPos + trace.HitNormal
		local Pos2 = trace.HitPos - trace.HitNormal
		util.Decal( "RedGlowFade", Pos1, Pos2 ) 
		weapon.Charging = false
		local ent = trace.Entity
		if !IsValid(trace.Entity) then return end
		local class = ent:GetClass()
		if pwrlvl > 1.2 then
			if class == "npc_rollermine" then
				ent:Fire("InteractivePowerDown", "", 0)
				ent:SetColor(Color(255,0,0,255))
			elseif class == "npc_turret_floor"then
				ent:Fire("SelfDestruct", "", 0)
				ent:SetColor(Color(255,0,0,255))
			elseif class == "npc_helicopter" || class == "npc_combinegunship" then
				ent:Fire("SelfDestruct", "", 0)
			elseif class == "npc_strider" then
				ent:Fire("SetHealth",0,0)
			end
		elseif pwrlvl > 0.9 then
			if class == "npc_rollermine" then
				ent:Fire("InteractivePowerDown", "", 0)
				ent:SetColor(Color(255,0,0,255))
			elseif class == "npc_turret_floor"then
				ent:Fire("SelfDestruct", "", 0)
				ent:SetColor(Color(255,0,0,255))
			end
		end
	else
		local charge = tobool(net.ReadBit())
		local weapon = LocalPlayer():GetActiveWeapon()
		if !weapon.TauCannon then return end
		if charge then
			if !weapon.Charging then
				weapon.ChargeOver = 1.2
				weapon:SendWeaponAnim( ACT_VM_PULLBACK_LOW )
				weapon.Charging = true
				weapon.ReloadAnim = true
				weapon.ReloadDelay = CurTime() + 1
				weapon.charge:Play();
				weapon.charge:ChangePitch( 25, 0.001 ) 
				timer.Simple(0.1,function()
				if !IsValid(weapon) then return end
					weapon.charge:ChangePitch( 255, 2.5 ) 
				end)
				weapon.PowerLevel = CurTime() + 2.75
			end
			weapon.ChargeDelay = CurTime() + 0.1
		else
			weapon.SpinSpeed = 2.5
		end
	end
end )
function SWEP:Think()
	if CLIENT then --CLIENT)
	if self.Charging then	
	local pwrlvl = (-(self.PowerLevel - CurTime() - 2.75))/2.75
	if pwrlvl >= 1.0 then
		pwrlvl = (pwrlvl/10) + 0.9;
	end
	if pwrlvl > self.ChargeOver then
		--RunConsoleCommand("play","weapons/1gauss/electro"..math.random(1,3)..".wav")
		self:EmitSound("weapons/1gauss/electro"..math.random(1,3)..".wav")
		if pwrlvl >= 1.5 then
			self.ChargeOver = self.ChargeOver + 0.02
			net.Start( "Taucannonfire" )
			net.WriteEntity( self.Owner ) 
			net.WriteBit(true)
			net.SendToServer()
		else
			self.ChargeOver = self.ChargeOver + 0.15
		end
	end
	if self.SpinSpeed < pwrlvl*15 then
		self.SpinSpeed = pwrlvl*15
	end
		if (self.ChargeDelay <= CurTime() && !self.Owner:KeyDown(IN_ATTACK2)) || self:IsUnderWater() then
			net.Start( "Taucannonfire" )
			net.WriteEntity( self ) 
			net.WriteBit(false)
			net.WriteFloat(pwrlvl)
			net.SendToServer()
			--self:CrgTauBlt(pwrlvl)
			if pwrlvl < 0.48 then
				self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK)
			else
				self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK)
			end
			self.Charging = false
			self.charge:Stop()
			self:EmitSound("weapons/gauss/fire1.wav")
			self:EmitSound("weapons/1gauss/electro"..math.random(1,3)..".wav")
			self.Idle = true
			self.IdleDelay = CurTime() + 1
			self.ChargeOver = 1.2
		end
	end
	
	self.SpinAng = self.SpinAng or -31337
	self.FanAng = self.FanAng or -31337
	self.SpinSpeed = self.SpinSpeed or 10
	if self.SpinAng > 7200 then
		self.SpinAng = -7200
	end
	if self.FanAng > 7200 then
		self.FanAng = -7200
	end
	self.FanAng = self.FanAng + 15
	self.SpinAng = self.SpinAng + self.SpinSpeed
	if self.SpinSpeed > 0 then
		self.SpinSpeed = self.SpinSpeed * 0.99
	elseif self.SpinSpeed < 0 then
		self.SpinSpeed = 0
	end
	self.ViewModelBoneMods["Spinner"].angle = Angle(0, 0, self.SpinAng)
	self.ViewModelBoneMods["Fan"].angle = Angle(0, 0, self.FanAng)
	end
	
	
	if self.Idle && self.IdleDelay <= CurTime() then	
		self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
		self.Idle = false
	end
	if self.ReloadAnim && self.ReloadDelay <= CurTime() && self.Charging then	
		self.Weapon:SendWeaponAnim( ACT_VM_PULLBACK )
		self.ReloadAnim = false
	end
end

--[[
function SWEP:Reload() 
	if SERVER then
		if self.ReloadButtonDelay <= CurTime() then
			net.Start("dd_gui")
			net.Send(self.Owner)
			self.ReloadButtonDelay = CurTime() + 1
		end
	end
end
]]
function SWEP:OnRemove( ) 
	if CLIENT then
		if !IsValid(self.Owner)||self.Owner == nil||self.Owner == NULL then return end
		local vm = self.Owner:GetViewModel();
		self.ARitzHadToFixTheBoneResetGlitchOnHisFuckingOwn = true;
		if IsValid(vm) then
			self:ResetBonePositions(vm);
		end;
		self.charge:Stop();
	end
end
function SWEP:Holster()
	
	if CLIENT and IsValid(self.Owner) then
		local vm = self.Owner:GetViewModel()
		if IsValid(vm) then
			self:ResetBonePositions(vm)
		end
		self.charge:Stop();
	end
	return true
end

function SWEP:Deploy()
	if (!IsValid(self.Owner)||!self.Owner:Alive()) then return false end
        self.m_WeaponDeploySpeed=1
        self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
        self:SetNextPrimaryFire( CurTime() + 1 )
        self:SetNextSecondaryFire( CurTime() + 1 )	
		self.Idle = true
		self.IdleDelay = CurTime() + 0.5
	return true
end

function SWEP:DoImpactEffect()
return true
end