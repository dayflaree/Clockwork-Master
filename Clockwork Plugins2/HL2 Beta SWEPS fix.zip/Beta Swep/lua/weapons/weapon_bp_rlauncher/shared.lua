 if SERVER then
	AddCSLuaFile( "shared.lua" )
	AddCSLuaFile( "cl_init.lua" )
end

if CLIENT then
	language.Add("weapon_bp_rlauncher", "Leak Rocket Launcher")
	SWEP.Category 		= "HL2 Beta Sweps"
	SWEP.PrintName		= "Rocket Launcher"
	SWEP.ViewModelFOV	= "70" 
	SWEP.Slot		= 4
	SWEP.Slotpos 		= 5
	SWEP.CSMuzzleFlashes	= true
	SWEP.DrawWeaponInfoBox	= false
	SWEP.BounceWeaponIcon 	= false 
	SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_launcher") 
end

SWEP.data = {}
SWEP.data.newclip			= false

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.ViewModel			= "models/weapons/v_lsr.mdl"
SWEP.WorldModel			= "models/Weapons/w_rocket_launcher.mdl"
SWEP.ViewModelFlip		= false
SWEP.HoldType			= "rpg"

SWEP.Primary.Sound		= Sound( "weapons/rocket_fire.wav" )
SWEP.Primary.Recoil		= 0.2
SWEP.Primary.Damage		= 19
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone		= 0.01
SWEP.Primary.ClipSize		= 1
SWEP.Primary.Delay		= 1
SWEP.Primary.DefaultClip	= 4
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo		= "RPG_Round"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo		= "none"
SWEP.Zoom = 0

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end

function SWEP:SecondaryAttack()
	if(self.Zoom == 0) then
		if(SERVER) then
			self.Owner:SetFOV( 40, 0.30 )
			self.Owner:ConCommand("pp_mat_overlay effects/scope03.vmt");
			self.Owner:DrawViewModel(false)
		end
		self:EmitSound("Weapon_AR2.Special1")
                self.Zoom = 1
	else
		if(SERVER) then
			self.Owner:SetFOV( 0, 0.30 )
			self.Owner:ConCommand("pp_mat_overlay \"\"");
			self.Owner:DrawViewModel(true)
		end
		self:EmitSound("Weapon_AR2.Special2")
                self.Zoom = 0
	end
end

function SWEP:PrimaryAttack()

	if ( !self:CanPrimaryAttack() ) then return end

	self.Weapon:EmitSound(self.Primary.Sound)

	self:TakePrimaryAmmo( self.Primary.NumShots )

	self:TakePrimaryAmmo( 0 )
	self.Owner:ViewPunch( Angle( -1.00, 0, 0 ) )
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )

	local shotpos = self.Owner:GetShootPos()
	shotpos = shotpos + self.Owner:GetForward() * 0
	shotpos = shotpos + self.Owner:GetRight() * 10
	shotpos = shotpos + self.Owner:GetUp() * -5

	if (SERVER) then
			
		local rocket = ents.Create("sent_bp_rpgpiercing")
		if (IsValid(rocket)) then
			rocket:SetPos( shotpos )
			rocket:SetAngles( Angle(self.Owner:GetAimVector()) )
			rocket:SetOwner(self.Owner)
 			rocket:Spawn()
			rocket.Owner = self.Owner
			rocket:Activate()
		end

		local Trail = ents.Create("env_rockettrail")
		Trail:SetPos(rocket:GetPos() - 16*rocket:GetForward())
		Trail:SetParent(rocket)
		Trail:SetLocalAngles(Angle(0,0,0))
		Trail:SetKeyValue("scale", "0.2")
		Trail:Spawn()

		local b = ents.Create( "info_target" )
		if (IsValid(b)) then
			b:SetPos( self.Owner:GetEyeTrace( ).HitPos + Vector(0,0,0))
			b:Spawn( )
			rocket:PointAtEntity( b )
			b:Remove( )
		end
	end
        
	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
	self.Owner:MuzzleFlash()
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
end

function SWEP:Reload()
	if self.Owner:GetActiveWeapon():Clip1() == self.Primary.ClipSize then return end
	if self.Reloading || self.Owner:GetAmmoCount( "RPG_Round" ) == 0 then return end
	if self.Weapon:Clip1() < self.Primary.ClipSize then
		self.data.oldclip = self.Weapon:Clip1()
		self.Weapon:EmitSound(Sound("buttons/button1.wav"))
		self.Weapon:DefaultReload(ACT_VM_RELOAD)
		self.data.newclip = 1
		self.Owner:SetFOV( 0, 0.30 )
		self.Owner:ConCommand("pp_mat_overlay \"\"");
		self.Owner:DrawViewModel(true)
		self:Idle()
                self.Zoom = 0
	end
end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then		
		self:Idle()
		end
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
   return true
end

function SWEP:Holster()
		self.Owner:SetFOV( 0, 0.30 )
        self.Zoom = 0
	return true
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end
	self.Owner:ConCommand("pp_mat_overlay \"\"");
	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end