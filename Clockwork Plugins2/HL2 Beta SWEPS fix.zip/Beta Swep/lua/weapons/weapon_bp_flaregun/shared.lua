if SERVER then
	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo		= false
	SWEP.AutoSwitchFrom		= false
	SWEP.HoldType			= "Ar2"
end

if CLIENT then
language.Add("weapon_bp_flaregun", "Flare Gun")

SWEP.PrintName = "Flare Gun"
SWEP.Slot = 1
SWEP.SlotPos = 5
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 45
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_flaregunl") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end

SWEP.Base = "weapon_base"
SWEP.HoldType			= "pistol"
SWEP.Category			= "HL2 Beta Sweps"

SWEP.Spawnable = true
SWEP.AdminSpawnable = false

SWEP.ViewModel = "models/weapons/v_flar3gun.mdl"
SWEP.WorldModel = "models/weapons/w_flaregun.mdl"

game.AddAmmoType( { name = "bp_flare" } )
if ( CLIENT ) then language.Add( "bp_flare_ammo", "Flares" ) end

SWEP.Primary.Recoil            = 2
SWEP.Primary.Sound = Sound( "weapons/flaregun/fire.wav" )
SWEP.Primary.NumShots = 1
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 20
SWEP.Primary.Automatic = false
SWEP.Primary.Delay = 1
SWEP.Primary.Ammo = "bp_flare"

SWEP.Secondary.ClipSize = 1
SWEP.Secondary.DefaultClip = 1
SWEP.Secondary.Automatic = false

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:Idle()
	return true
end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then	
		self:Idle()
		end
	if !self.Flare or !IsValid( self.Flare ) then return end
    if self.Flare:WaterLevel() > 0 then self.Flare:Fire( "Die", "0.1", 0 ) end
	
	for k, v in pairs( ents.FindInSphere( self.Flare:GetPos(), 12 ) ) do
		if IsValid( v ) and ( v:IsNPC() or v:IsPlayer() ) and v != self.Owner and v:Health() > 0 then
			v:Ignite( math.Rand( 14, 21 ), 1 )
		end
	end
end

function SWEP:PrimaryAttack()
	if (!self:CanPrimaryAttack()) then return; end
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	self.Weapon:EmitSound( self.Primary.Sound )
	self:SetClip1( self:Clip1() -1 )
	self:LaunchFlare()	
	self.Weapon:TakePrimaryAmmo( 1 )
	self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	self.Weapon:SetNetworkedFloat( "LastShootTime", CurTime() )
        self.Flare:Fire( "Launch", "2000", 0 )
	self.Flare:Fire( "Die", "20" )
	self.Owner:ViewPunch( Angle( math.Rand(-0.4,-0.4) * self.Primary.Recoil, math.Rand(-0.2,0.2) *self.Primary.Recoil, 0 ) )
end

function SWEP:Reload( )
	if ( self:Clip1() < self.Primary.ClipSize && self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	if self.Weapon:DefaultReload(ACT_VM_RELOAD) then
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
		end
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:LaunchFlare()
	local tracer = self.Owner:GetEyeTrace()
	local Forward = self.Owner:EyeAngles():Forward()
	local Right = self.Owner:EyeAngles():Right()
	local Up = self.Owner:EyeAngles():Up()

	self.Flare = ents.Create("env_flare")
	self.Flare:SetPos( self.Owner:GetShootPos() + Forward * 18 + Right * 6 + Up * -3)
	self.Flare:SetAngles( self.Owner:EyeAngles() )
	self.Flare:SetKeyValue( "scale", "10" )
	self.Flare:Spawn()
	self.Flare:Activate()
	self.Flare:Fire( "Launch", "2000", 0 )
end

function SWEP:Initialize()
	if (SERVER) then
		self:SetWeaponHoldType(self.HoldType)
	end
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end