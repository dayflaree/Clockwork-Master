if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )
end

if ( CLIENT ) then

language.Add("weapon_bp_cocktail", "Molotov Cocktail")

SWEP.Category = "HL2 Beta Sweps"
SWEP.PrintName = "Molotov Cocktail"
SWEP.Slot = 4
SWEP.SlotPos = 4
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/molotov_cocktail") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
		
end

SWEP.ViewModel			= "models/weapons/v_molot0v.mdl"
SWEP.WorldModel			= "models/weapons/w_molot0v.mdl"
SWEP.HoldType			= "grenade"

SWEP.Weight				= 2
SWEP.AutoSwitchTo		= false
SWEP.AutoSwitchFrom		= false

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

game.AddAmmoType( { name = "bp_molotov" } )
if ( CLIENT ) then language.Add( "bp_molotov_ammo", "Molotov Cocktails" ) end

SWEP.Primary.Recoil			= 0
SWEP.Primary.Delay 			= 0
SWEP.Primary.Damage			= 0
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= 5
SWEP.Primary.Reload 		= 0
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "bp_molotov"

SWEP.Secondary.Delay		= 0
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
	
function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then	
		self:Idle()
		end
end

function SWEP:PrimaryAttack()
local Player = self.Owner

	if (!SERVER) then return end
if ( self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then

local Molotov = ents.Create( "sent_bp_molotov" )
local Forward = self.Owner:EyeAngles():Forward()
local Right = self.Owner:EyeAngles():Right()
local Up = self.Owner:EyeAngles():Up()
	Molotov:SetOwner( Player )
	Molotov:SetPos( self.Owner:GetShootPos() + Forward * -8 + Right * 6 + Up * -8)
--	Molotov:SetAngel( Player:GetAimVector() )
	Molotov:Spawn()

	local mPhys = Molotov:GetPhysicsObject()
	local Force = Player:GetAimVector() * 3000
		
		mPhys:ApplyForceCenter( Force )
		
	self.Weapon:SendWeaponAnim( ACT_VM_THROW )
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	self.Weapon:SetNextPrimaryFire( CurTime() + 2 )
	self.Weapon:SetNextSecondaryFire( CurTime() + 2 )
	self:TakePrimaryAmmo( 1 )
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
		self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
		self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
		self:NextThink( CurTime() + self:SequenceDuration() )
		self:Idle()
	return true
end

	
function SWEP:Reload()
	return false
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end
