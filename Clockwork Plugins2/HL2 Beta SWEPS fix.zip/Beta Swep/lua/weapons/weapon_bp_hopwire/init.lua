AddCSLuaFile("shared.lua")
include("shared.lua")


function SWEP:Holster( )
	if timer.Exists("anim_timer"..tostring(self.Weapon)) then
		timer.Remove("anim_timer"..tostring(self.Weapon))
	end

	return true
end

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
   return true
end

function SWEP:Reload()
end

function SWEP:Think()
end

function SWEP:PrimaryAttack()

	if (!SERVER) then return end
if ( self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	local ent = ents.Create( "sent_bp_hopwire" )
	local Forward = self.Owner:EyeAngles():Forward()
	local Right = self.Owner:EyeAngles():Right()
	local Up = self.Owner:EyeAngles():Up()
	ent:SetNetworkedBool( "Active", false )
	ent:SetPos( self.Owner:GetShootPos() + Forward * 8 + Right * 6 + Up * -3)
	ent:Spawn()
	ent:Activate()
	ent:GetPhysicsObject():ApplyForceCenter( self.Owner:GetAimVector() * 4000 )
	
	self.Weapon:SendWeaponAnim( ACT_VM_THROW )
	self.Weapon:SetNextPrimaryFire( CurTime() + 1.2 )
	self.Weapon:SetNextSecondaryFire( CurTime() + 1.2 )

	undo.Create("Hopwire")
	undo.AddEntity( ent )
	undo.SetPlayer( self.Owner )
	undo.Finish()

	timer.Create( "anim_timer"..tostring(self.Weapon), 0.5, 1, function() self:ResetAnim() end )
	self:TakePrimaryAmmo( 1 )
	end
end


function SWEP:ResetAnim( )

	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )

end

function SWEP:SecondaryAttack()
	if (!SERVER) then return end
if ( self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	local ent = ents.Create( "sent_bp_hopwire" )
	local Forward = self.Owner:EyeAngles():Forward()
	local Right = self.Owner:EyeAngles():Right()
	local Up = self.Owner:EyeAngles():Up()
	ent:SetNetworkedBool( "Active", false )
	ent:SetPos( self.Owner:GetShootPos() + Forward * 8 + Right * 3 + Up * -3)
	ent:Spawn()
	ent:Activate()
	ent:GetPhysicsObject():ApplyForceCenter( self.Owner:GetAimVector() * 1000 )
	
	self.Weapon:SendWeaponAnim( ACT_VM_HAULBACK )
	self.Weapon:SetNextPrimaryFire( CurTime() + 1.2 )
	self.Weapon:SetNextSecondaryFire( CurTime() + 1.2 )

	undo.Create("Hopwire")
	undo.AddEntity( ent )
	undo.SetPlayer( self.Owner )
	undo.Finish()

	timer.Create( "anim_timer"..tostring(self.Weapon), 0.5, 1, function() self:ResetAnim() end )
	self:TakePrimaryAmmo( 1 )
	end
end

