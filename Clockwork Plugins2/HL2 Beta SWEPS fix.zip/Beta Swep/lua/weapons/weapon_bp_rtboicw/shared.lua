if SERVER then
AddCSLuaFile( "shared.lua" )
SWEP.HoldType		= "ar2"
end

if CLIENT then
language.Add("weapon_bp_rtboicw", "RTB OICW")

SWEP.PrintName = "RTB OICW"
SWEP.Slot = 2
SWEP.SlotPos = 4
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 55
SWEP.ViewModelFlip = false

SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/weapon_oicw") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end

SWEP.Category 		= "HL2 Beta Sweps"
SWEP.PrintName		= "RTB OICW"	

SWEP.ViewModelFOV	= 55
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/leakwep/v_o1c4.mdl"
SWEP.WorldModel		= "models/leakwep/w_o1c4.mdl"
SWEP.HoldType		= "ar2"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

game.AddAmmoType( { name = "bp_medium" } )
if ( CLIENT ) then language.Add( "bp_medium_ammo", "Medium Rounds" ) end

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 90
SWEP.Primary.Automatic		= true
SWEP.Primary.Delay		= 0.2
SWEP.Primary.Ammo		= "bp_medium"
SWEP.Primary.Recoil            = 1

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Delay		= 1
SWEP.Secondary.Ammo		= "bp_medium"

SWEP.Zoom = 0

function SWEP:Initialize()
		self:SetWeaponHoldType(self.HoldType)
	end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
   return true
end

function SWEP:Holster()
	self.Owner:SetFOV( 0, 0.25 )
	self.Zoom = 0

	return true
end

function SWEP:Reload()
	if self:DefaultReload( ACT_VM_RELOAD ) then 
		if(SERVER) then
			self.Owner:SetFOV( 0, 0.25 )
			
		end
		self:Idle()
		self:EmitSound(Sound("weapons/1oicw/ar2_reload.wav")) 
         end
end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then	
		self:Idle()
		end
end

function SWEP:PrimaryAttack()

	if ( !self:CanPrimaryAttack() ) then return end

	if (self.Zoom == 0 || self:Clip1() < 2 ) then
		self:ShootBullet( 10, 1, 0.025 )
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.09 )
		self:EmitSound( Sound("weapons/1oicw/ar1_1.wav") )
		self:TakePrimaryAmmo( 1 )
		self.Owner:ViewPunch( Angle( math.Rand(-0.3,-0.3) * self.Primary.Recoil, math.Rand(-0.3,0.3) *self.Primary.Recoil, math.Rand(-0.1,0.1) ) )

	end
	
end

function SWEP:SecondaryAttack()
	if self:Clip1() <= 4 then return end
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Secondary.Delay )
	self.Weapon:EmitSound("weapons/1oicw/44k/ar2_fire1.wav")
	self:TakePrimaryAmmo( 5 )
	self.Owner:ViewPunch( Angle( math.Rand(-0.3,-0.3) * self.Primary.Recoil, math.Rand(-0.3,0.3) *self.Primary.Recoil, math.Rand(-0.1,0.1) ) )
	self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	if (!SERVER) then return end
	
	local Forward = self.Owner:EyeAngles():Forward()
	local Right = self.Owner:EyeAngles():Right()
	local Up = self.Owner:EyeAngles():Up()
	
	local ent = ents.Create( "grenade_ar2" )
	if ( IsValid( ent ) ) then
	
			ent:SetPos( self.Owner:GetShootPos() + Forward * 7 + Right * 6 + Up * -12)
			ent:SetAngles( self.Owner:EyeAngles() )
		ent:Spawn()	
		ent:SetVelocity( Forward * 1200 )
		ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		
	end
	
	ent:SetOwner( self.Owner )
	
end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	self.Zoom = 0
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end