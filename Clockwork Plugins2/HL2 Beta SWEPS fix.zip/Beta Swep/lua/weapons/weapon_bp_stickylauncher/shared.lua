-- Based on _Kilburn's sticky bomb launcher.
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "init.lua" )
if CLIENT then

language.Add("weapon_bp_stickylauncher", "Sticky Launcher")

SWEP.PrintName = "Sticky Launcher"
SWEP.Category 		= "HL2 Beta Sweps"
SWEP.Slot = 1
SWEP.SlotPos = 2
SWEP.DrawAmmo = true
SWEP.DrawCrosshair = true
SWEP.ViewModelFOV = 54
SWEP.ViewModelFlip = false
SWEP.HoldType		= "pistol"
SWEP.WepSelectIcon = surface.GetTextureID("HUD/swepicons/sticky") 
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false 
end

SWEP.HoldType = "pistol"
SWEP.Base                = "weapon_base"
SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true
SWEP.ViewModel            = Model("models/weapons/v_pist0l.mdl")
SWEP.WorldModel            = Model("models/weapons/w_pistol.mdl")
SWEP.Weight                = 5
SWEP.AutoSwitchTo        = false
SWEP.AutoSwitchFrom        = false

SWEP.Primary.Recoil            = 1
SWEP.Primary.ClipSize        = 18
SWEP.Primary.Delay            = 0.1
SWEP.Primary.DefaultClip    = 36
SWEP.Primary.Automatic        = false
SWEP.Primary.Ammo            = "none"

SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo            = "none"

SWEP.IsRapidFire = false
SWEP.ReloadSingle = true

SWEP.Bombs = {}

SWEP.ProjectileShootOffset = Vector(52.6, 13, -6)
SWEP.Force = 10000--6400
SWEP.MaxForce = 15500

SWEP.ShootSound = Sound("weapons/1sticky/pistol_fire1.wav")
SWEP.ShootCritSound = Sound("weapons/1sticky/pistol_fire1.wav")
SWEP.DetonateSound = Sound("weapons/1sticky/mine_activate.wav")

function SWEP:Initialize()
    self:SetWeaponHoldType( self.HoldType )
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
	self:SetNextPrimaryFire( CurTime() + self:SequenceDuration())
	self:SetNextSecondaryFire( CurTime() + self:SequenceDuration())
	self:NextThink( CurTime() + self:SequenceDuration() )
	self:Idle()
	return true
end

function SWEP:Think()
	if ( self.Owner:KeyReleased( IN_ATTACK ) || ( !self.Owner:KeyDown( IN_ATTACK ) && self.Sound ) ) then		
		self:Idle()
		end
end 

function SWEP:PrimaryAttack()

    self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
    self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
        self:EmitSound( "weapons/1sticky/pistol_fire1.wav" )
    
    self:ShootProjectile()
    
    if ( self.Owner:IsNPC() ) then return end
    
    self.Owner:ViewPunch( Angle( math.Rand(-0.2,-0.1) * self.Primary.Recoil, math.Rand(-0.1,0.1) *self.Primary.Recoil, 0 ) )

end

function SWEP:Reload()
end

function SWEP:InitOwner()
    self.Owner.Bombs = {}
end

hook.Add( "KeyPress", "BlobStickyDetonation", function(ply, key)
    if key == IN_ATTACK2 then
        local wep = ply:GetActiveWeapon()
        if wep.DetonateProjectiles then
            wep:DetonateProjectiles()
            timer.Simple(0.2, function ()
				if !wep or !wep.DetonateProjectiles then return end
				wep:DetonateProjectiles(true,false)
			end) -- Detonate one more time in case a few stickybombs haven't become active yet
        end
    end
end)

function SWEP:SecondaryAttack()
end

function SWEP:ProjectileShootPos()
    local pos, ang = self.Owner:GetShootPos(), self.Owner:EyeAngles()
    return pos +
        self.ProjectileShootOffset.x * ang:Forward() +
        self.ProjectileShootOffset.y * ang:Right() +
        self.ProjectileShootOffset.z * ang:Up()
end

function SWEP:ShootProjectile()

    if SERVER then
        if not self.Owner.Bombs then
            self:InitOwner()
        end
        
        local grenade = ents.Create("sent_bp_sticky")
        grenade:SetPos(self:ProjectileShootPos())
        grenade:SetAngles(self.Owner:EyeAngles())
        
        grenade:SetOwner(self.Owner)
        
        grenade:Spawn()
        
		if not IsValid(grenade) then return end
        
        local vel = self.Owner:GetAimVector() * self.Force + Vector(0, 0, 1100)
        
		local phys = grenade:GetPhysicsObject()
		
		if IsValid(phys) then
			phys:AddAngleVelocity(Vector(math.random(-2000,2000),math.random(-2000,2000),math.random(-2000,2000)))
			phys:ApplyForceCenter(vel)
		end
        
        table.insert(self.Owner.Bombs, grenade)
        end
        
    self:ShootEffects()
    
end

function SWEP:DetonateProjectiles(nosound, noexplode)
    local det = false
    if SERVER then
        if not self or not self:IsValid() then return end
        
        local owner = self.Owner
        if not IsValid(owner) then return end
        local bombs = owner.Bombs
        
        if not bombs then
            self:InitOwner()
            bombs = self.Owner.Bombs
        end
        
        local b
        for k=#bombs,1,-1 do
            b = bombs[k]
            if !b then break end
            if b.Ready or noexplode then
				local bomb = table.remove(bombs, k)
				if IsValid(bomb) then
					if noexplode then
						bomb:Break()
					else
						bomb:Explode()
						det = true
					end
				end
            end
        end         
    end
end

function SWEP:OnRemove()
    self:DetonateProjectiles(true, true)
end


function SWEP:ShootEffects()

    self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
    self.Owner:MuzzleFlash()
    self.Owner:SetAnimation( PLAYER_ATTACK1 )

end

function SWEP:Holster( weapon )
	if ( CLIENT ) then return end

	self:StopIdle()
	
	return true
end

function SWEP:DoIdleAnimation()
	self:SendWeaponAnim( ACT_VM_IDLE )
end

function SWEP:DoIdle()
	self:DoIdleAnimation()

	timer.Adjust( "weapon_idle" .. self:EntIndex(), self:SequenceDuration(), 0, function()
		if ( !IsValid( self ) ) then timer.Destroy( "weapon_idle" .. self:EntIndex() ) return end

		self:DoIdleAnimation()
	end )
end

function SWEP:StopIdle()
	timer.Destroy( "weapon_idle" .. self:EntIndex() )
end

function SWEP:Idle()
	if ( CLIENT || !IsValid( self.Owner ) ) then return end
	timer.Create( "weapon_idle" .. self:EntIndex(), self:SequenceDuration() - 0.2, 1, function()
		if ( !IsValid( self ) ) then return end
		self:DoIdle()
	end )
end