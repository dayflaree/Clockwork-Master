Allows you to configure custom hints to be shown in the top right of the screen with colors! Much like the clockwork issues green hint thing.

**Add your own adverts in libraries/sh_advertisement.lua**


**There is a clockwork config option, "advert interval" which you can change. Minimum is 60 seconds**
