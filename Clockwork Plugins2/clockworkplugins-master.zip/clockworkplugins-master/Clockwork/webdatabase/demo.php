<?php
session_start();
$_SESSION["steamid"] = "76561198031633135";
header("Location: index.php");
?>