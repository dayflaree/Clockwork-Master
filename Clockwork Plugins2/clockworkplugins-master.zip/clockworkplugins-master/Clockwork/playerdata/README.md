Desc
===
Works like character data, but for players. Consistent over characters. Admin only obviously.

Usage
===
/playerdata <character name>

Media
===
![player data](https://raw.githubusercontent.com/trurascalz/clockworkpluginimages/master/clockwork/playerdata.jpg)
