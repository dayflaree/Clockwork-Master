ClockworkKodeRedeemer
=====================
A donation script for clockwork
Notes:

### No SQL files are required for this. The Clockwork Plugin does this automatically.
### No support will be given if you have **not read** the instructions and IPN guide.
### If you have a random mysql port number you must modify the mysql connection script see example 1, second part in http://php.net/manual/en/mysqli.quickstart.connections.php
