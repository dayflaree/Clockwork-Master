Description
====
Hides the characters belonging to this faction from the scoreboard, unless the viewer is a admin or is part of the faction.

>Player 1 is a citizen, they cannot see player 2 in the scoreboard becuase they are part of this incognito faction.Player 3 is also a citizen but can see player 2 in this faction because they are a admin.Player 4 can see player 2 in the scoreboard because they are also part of this faction.

**Line 30 of sh_incognito.lua in the faction folder to change the name on the scoreboard. Respective faction lines to edit the names.**
