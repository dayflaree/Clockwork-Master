ClockworkWebFlagGiver
=====================

A Web app to distribute flags


## We suggest the player is not on the character or in game at the time of flags
