local Clockwork = Clockwork;

Clockwork.config:AddToSystem("Logger URL", "logger_url", "The URL for the logger to link to.");