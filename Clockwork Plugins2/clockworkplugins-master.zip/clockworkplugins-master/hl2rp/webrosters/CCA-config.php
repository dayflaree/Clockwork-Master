<?php
//// Prefix Setting
$prefixbefore = ".";
$prefixafter = ".";


$general = "SWORD";        

$court = "JUDGE";           

$medic = "SHIELD";            

$engineer = "GRID";  
$scanner = "Scanner";
$recruit = "Recruit";    


/// COMMANDER RANK /// - some people use CCA-CMD.XXXXX, this is just personal preference
$cmdenable = 1; 
$cmdname = "CmD";
/// CUSTOM DIVISONS ///
////////// Enable Custom Divison 1? ////
$enableextra1 = 1; // Either 0 OR 1
////////// Custom Divison 1 Name /////
$extra1 = "GHOST";
////////// Enable Custom Divison 2? ////
$enableextra2 = 1; // Either 0 OR 1
////////// Custom Divison 2 Name /////
$extra2 = "REAPER";

?>