<?php
///////////////////
//    Global     //
// Configuration //
///////////////////
//    Database   //
// Configuration //
///////////////////

$DB_HOST = "localhost";
$DB_USER = "clockwork_db";
$DB_PASS = "pass";
$DB_NAME = "clockwork_db";
$characters ="characters";
$players = "players";

///////////////////////
// END GLOBAL CONFIG //
///////////////////////
$website = "http://www.mygamingcommunity.com";
$site = "My Gaming Community"; // This is a friendly version of your community name, no URL jargon
$game = "Half life 2 Roleplay"; // gamemode
$productname = " CCA Roster"; // A name for this product, default: CCA Roster
///////////////////////
// HL2RP Web Rosters //
///////////////////////


// Created 27/3/13 at 6:20PM
// Pulbic Version

// Template: 

/*
include('globalconfig.php');
$con = mysql_connect($address,$user,$pass);
if (!$con)
  {
  die('ERROR! Unable to connect: ' . mysql_error());
  }

mysql_select_db($database, $con);
*/
?>