Clockwork Half Life 2 Roleplay web rosters
===============
Installation:
Place all files in a folder on a web-server.
Edit:
Global Config<br>
 * Edit all settings in there</p>

CCA Config
* Prefix<br>
 * This relates to the unit name, eg.<br>
        "CCA-UNION.05.12345"<br>
The "."'s are the prefix.
The default setting is . but some people use - 

* Extra ranks
 * This application is configured to allow 2 custom ranks.
   All you need to do is enable them here and they will be added to the navigation bar.
  * If you require extra assistance in adding more, feel free to contact me.

