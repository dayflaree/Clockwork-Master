hl2rpsounds
===========

These sounds are released under discretion of Valve Corporation. 
Valve at any time as the original owners of these sound files can 
request me to remove/identify themselves in these files.

These sound are to be placed in 

/garrysmod/sound/*a folder name*/

then you will use 

resource.AddFile( "/sound/*a folder name*/*file name*" )
which will be placed in /lua/autorun/resources.lua

A transcript is given.

