--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["HintBook"] = "책에 투자하여 당신의 캐릭터가 더 똑똑해지게 해 보세요.";
CW_KOREAN["Books"] = "책들";
CW_KOREAN["Read"] = "읽기";