--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["HintBook"] = "Invierte en un libro, dale a tu personaje algo de conocimiento.";
CW_SPANISH["Books"] = "Libros";
CW_SPANISH["Read"] = "Leer";