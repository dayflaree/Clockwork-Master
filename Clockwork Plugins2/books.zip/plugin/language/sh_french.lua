--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_FRENCH = Clockwork.lang:GetTable("French");

CW_FRENCH["HintBook"] = "Liser un livre, donne à votre personnage des connaissances.";
CW_FRENCH["Books"] = "Livres";
CW_FRENCH["Read"] = "Lire";