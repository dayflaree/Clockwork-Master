--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Overwatch Transhuman Arm Anatomy";
ITEM.cost = 6;
ITEM.model = "models/props_lab/bindergreenlabel.mdl";
ITEM.uniqueID = "book_otaanat";
ITEM.business = true;
ITEM.description = "A book with an antlion on the front.";
ITEM.bookInformation = [[
<font color='red' size='4'>Universal Union Property</font>

This is Property of the Universal Union. Any unauthorized readings, or viewings of this book qualifies
for Level 6 Prosecution of immediate amputation. Report this to a Metropolice Officer Immediately if found.

The Overwatch Transhuman Arm Soldier. The process of making an Overwatch Transhuman Arm soldier is not an easy
process. The first thing required of making an Overwatch Transhuman Arm soldier is to first capture a male. Females
are unable to become OTA as they are suseptible to the elements, and have a lower maximum body strength. Once a male
is captured and claimed property of the Universal Union, they must be locked in a biopod immediately for approximately
3 to 6 months with minimal supplements pumped into them. Once they are close to 5%-6% fat, they must immediately
undergo a surgery that will involve in replacing their legs, arms, and head with Robotic-Union Approved circutry. They
will then be brainwashed and connected to the OTA Database VIA headset. They will then be taught to walk, breathe, and
perform basic training. They will follow your command at no problem. These Pre-OTA soldiers are known as "Stalkers" for
their boney-like structure and very thin body. After basic training is complete, they will be sent back to their pod
and given pure nutrients only for 1-2 months, and will have surgically implants in their feet, arms, and the rest of their
head. They will then be given a heavy set of OTA Kevlar, and will wear that whilst on duty. The day they come out of
that pod, they are under your command, and will know who the target is, and who to obey. You must always make sure that
you know you are in control. The OTA soldiers are the most strongest specimen of life on earth, and can easily crush
the rebellion, as long as you know who is in charge.

It is impossible for them to become corrupted.
]];

ITEM:Register();