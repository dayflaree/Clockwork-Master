--[[
	� CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");

ITEM.name = "Ravenholm Journal";
ITEM.cost = 6;
ITEM.model = "models/props_lab/bindergraylabel01b.mdl";
ITEM.uniqueID = "book_rj";
ITEM.business = false;
ITEM.description = "A journal with headcrab blood on the front.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by Jamie Ruzicano.</font>
                                       DAY 1:
My name is Jamie Ruzicano, I recently arrived from Black Mesa East through a tunnel. 
The people here seem nice but the priest Father Grigori seems troubled and almost mad. Nevertheless, i was given a small room to sleep in with two other people Eddy and Matthew, they seem to be okay people but Eddy is slightly suspicious for some reason He always fiddles about with a Radio talking into it. I might have to look into that....
                                       DAY 3:
This is day three of my arrival to Ravenholm. Some of the resistance guards are talking about a place called 'New Little Odessa' led by Colonel Odessa Cubbage. They were joking about him saying he smells of cabbage but mentioned there one of the few settlements to have a functioning communication between outposts via radio.
Eddy is still tinkering with the radio but Matthew has been at the bar recently drinking a bit more than he should have. Father Grigori which is the town priest and i presume town 
mayor has made a sermon on alcholism and urges that we should all have atleast a weapon on us at all times.
                                      DAY 5:
There's been a break-in of those alien things. The Vortiguants there exclaims that they're from the borderworld 'Xen' and that someone named 'Freeman' stopped the Aliens from invading but that didnt stop the combine from coming! Anyways, i digress. Matthew and i tried breaking the radio that Eddy has been talking into but he spotted us and pulled out a Revolver he had on him, he shot Matthew right in the chest!
He died shortly thereafter but i retaliated and shot him right in the forehead with my pistol. I heard screams from many resistance members but one had caught my attention and said 'They're shelling us! Run for your life!' i looked out the window and saw zombies and headcrabs everywhere. I could not believe my eyes!
                                      
                                     DAY ??:
I dashed back to the tunnel leading to Black Mesa East and escaped from there. I now am here in City 11, whoever reads this Don't go to Ravenholm. 
I'm thinking of helping the local resistance with their cause however. I wish luck to whoever finds this if i die
]];

ITEM:Register();