--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Forcefield Schematics";
ITEM.cost = 6;
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.uniqueID = "book_forc";
ITEM.business = true;
ITEM.description = "A book with a picture of a Forcefield on the Front.";
ITEM.bookInformation = [[
Property of the Universal Union.
Report this documentation to a Civil Officer if found immediately. Level 3 Violation if found.

The Forcefield.

The Universal Union Forcefield is a device used for crowd control, redirection, and for blocking restricted zones or
regulating traffic. The Universal Union Forcefield is Enginnered by <REDACTED> and was brought to life by a man 
named <REDACTED>. The current way they work is you must have an A GATE, and a B GATE, and they must be exactly lined up
using a <REDACTED> tool. A GRID Unit should have said tool, and will be able to install a field wherever need be.
The Forcefield powers by connecting it to an Outlet and keeping it powered. When they activate, they will glow a light
blue color. This means that they are activated, but are not yet ready for the purpose they have. You must consult a
certified GRID unit to configure the field so that it can only allow Metropolice, or Loyalists in with a keycard. The
Forcefield also must be constantly powered, or the configurations will be reset. If for any reason the forcefield is
shut down, then you must report it to a GRID officer immediately. The Forcefield is blast proof, and cannot be blown up
or destroyed, so the only way they can be disabled is via the cord. If you notice a damaged cord, report it to a certified
GRID officer for testing and repair.
]];

ITEM:Register();