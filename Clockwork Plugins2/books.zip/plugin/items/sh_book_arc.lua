--[[
	� CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");

ITEM.name = "C14 Unit Escapee";
ITEM.cost = 6;
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.uniqueID = "book_arc";
ITEM.business = true;
ITEM.description = "A book with wear and tear on it";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by CPF://C17.KILO-i4.67589.</font>

Hello to whomever reads this, I will have to keep this short. I fear that the combine will come for me soon, I ripped out all the pages in the book or wrote over them just to write this detailed plan for anyone planning to join the civil protection to go undercover. Tip 1: Have a escape plan, I am a runaway unit, I found a place where you and I can get out of City 14.

It's through a small outpost in the sewers of City 14, the leaders there got me out to the outlands in a big heavy truck and I arrived in a somewhat weird forest base. I hope whoever reads this can join me one day. I saw many horrors, people being sent to death. People sent to becoming a stalker, people being beat to death by a unit just for not saying anything. Do not join the Civil Protection even if you're loyal, they'll soon assimilate you to be made a Overwatch Unit.

The only reason I escaped was I ditched my mask. The mask holds the signal connecting to your heart, if the mask is destroyed your signal will go off but they cannot track you if you do it. I want to say however, do not keep the suit if you escape the outlands. Keep the vest only, the people there will most likely shoot you thinking you're a patrol. Tip 2: Supply yourself with weapons, food and water. Anything that can be benefical for you. Tip 3: Don't tell anyone you're going unless they've changed their loyalty to Humanity. God bless us all and dear god hope the Resistance free us from our oppressors - CPO://C17.KILO-i2.67589
]];

ITEM:Register();