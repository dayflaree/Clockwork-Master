--[[
	� CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");

ITEM.cost = 3;
ITEM.name = "The F. Word II";
ITEM.model = "models/props_lab/bindergraylabel01b.mdl";
ITEM.uniqueID = "book_tfwII";
ITEM.business = true;
ITEM.description = "A book about fuck all II.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by M. Stanley Bubien.</font>

<font size = '+2'>M</font>ommy!' my son cried out as he ran into the kitchen while i was making some coffee for my husband who was yet to wake, 'Cherish just said
the -word!' I set the coffee down thinking what Cherish did this time the little bitch, took his hand and asked, 'What is the n-word honey-bun?'

He looked around the room. 'Look It's okay to tell me, just like when Cherish said the f-word'
Meeting my gaze, he shrugged looking pale and very uncomfortable, 'I can't say it mom! i just cant!.' I was looking obviously confused by my son's response. I looked at my daughter's room and back to him. 'Honey, look its fine to say it. Just whisper it into my ear.' My son finally decided to give in, he said "I'm gonna say the n-word!" he then proceeded to whisper it ever so quietly into my ear. I was in shock! I expected more from Cherish after the reasonable beating i gave her after she said the f-word. 

I stood up and told him to go back to his room. I walked back into my room and opened up my Husband's belt drawer. Most of the belts were leather, i picked the snake skin belt with the buckle still on. and walked into the living room sitting down elegantly and shouted Cherish! come in here. Right now! Cherish came in with half of her makeup on. He was going to meet her boyfriend with her negro friend. I shouted at her "Those words you said to your little brother is not the words we use in our house!' I stood up, motioning her over to the couch i was sitting on, she sat down with slight tears in her eyes. I said 'This better be the last time i do this Cherish! I then proceeded to wack her in her arms and chest. Making sure she cried i then slapped her with my backhand. I rushed her out back into her room her makeup looking awful most of it was tears! I shouted to her "You're not going to be seeing your boyfriend this week or the next week! I walked back to the drawer and put it back in. My husband was awake at this time and asked me 'What happened?' i said to him later 'I'll tell you later, i made you the coffee hurry off to work now!'
]];

ITEM:Register();