--[[
	� CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");

ITEM.cost = 6;
ITEM.name = "Mein Kampf";
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.business = true;
ITEM.uniqueID = "book_hitler";
ITEM.description = "A red book with a picture of Adolf Hitler on the cover, it's only got Chapter 1.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by Adolf Hitler.</font>


                                                                   KAPITEL 1 IM HAUS MEINER ELTERN 

Heute scheint es mir vorsehungvoll, dass das Schicksal Braunau am Inn zu meinem Geburtsort h�tte w�hlen sollen. Denn diese kleine Stadt liegt an der Grenze zweier deutscher Staaten, die wir zumindest der j�ngeren generation zu unserem Lebenswerk gemacht haben, uns mit allen uns zur Verf�gung stehenden Mitteln zu vereinen.

Deutsch-�sterreich muss in das gro�e Deutsche Mutterland zur�ckkehren und nicht aus wirtschaftlichen Erw�gungen. Nein, und wieder Nein: selbst wenn eine solche union aus wirtschaftlicher Sicht unwichtig w�re; ja, selbst wenn Sie sch�dlich w�re, muss Sie dennoch stattfinden. Ein Blut verlangt ein Reich. Niemals wird die Deutsche nation das moralische Recht haben, Kolonialpolitik zu betreiben, bis Sie zumindest Ihre eigenen S�hne in einem einzigen Staat umarmt. Erst wenn die Reichsgrenzen den allerletzten deutschen einschlie�en, aber sein t�gliches Brot nicht mehr garantieren k�nnen, entsteht das moralische Recht, fremden Boden zu erwerben, aus der not unseres eigenen Volkes. Ihr Schwert wird unser Pflug werden, und aus den Tr�nen des Krieges wird das t�gliche Brot zuk�nftiger Generationen wachsen. Und so scheint mir diese kleine Stadt an der Grenze das symbol einer gro�en mission zu sein. Und auch in anderer Hinsicht ist es eine Mahnung an die Gegenwart. Vor mehr als hundert Jahren hatte dieser unbedeutende Ort den Unterschied, zumindest in der deutschen Geschichte in den Annalen verewigt zu sein, denn es war der Schauplatz einer tragischen Katastrophe, die die gesamte Deutsche nation ergriff. Zur Zeit der tiefsten Dem�tigung unseres Vaterlandes starb dort Johannes Palm von N�rnberg, B�rger, Buchh�ndler, kompromissloser nationalist und franz�sischer Hasser, f�r das Deutschland, das er selbst in Ihrem Ungl�ck so leidenschaftlich liebte. Er hatte sich hartn�ckig geweigert, seine Komplizen anzuprangern, die in der Tat seine Vorgesetzten waren. In so �hnelte er Leo Schlageter. Und wie er wurde auch er von einem Vertreter seiner Regierung an die Franzosen angeprangert, Ein Augsburger Polizeichef gewann diesen wenig beneidenswerten Ruhm und lieferte so ein Beispiel f�r unsere modernen deutschen Beamten im Reich Herr Severing.

In dieser kleinen, von den Strahlen des deutschen M�rtyrertums vergoldeten Stadt am Inn, bayerisch durch Blut, technisch �sterreichisch, lebten meine Eltern Ende der achtziger Jahre des vergangenen Jahrhunderts; mein Vater ein pflichtbewusster Beamter meine Mutter schenkte Ihr ganzes Wesen dem Haushalt und widmete sich vor allem uns Kindern in Ewiger, liebevoller F�rsorge Wenig bleibt in meiner Erinnerung an diese Zeit, denn nach ein paar Jahren hatte mein Vater die kleine Grenzstadt verlassen, die er gelernt hatte zu lieben, Umzug nach unten das Gasthaus, um eine neue position in Passau zu nehmen,das hei�t, in Deutschland an sich.

Damals war st�ndiger Umzug das Los eines �sterreichischen Zollbeamten. Kurze Zeit sp�ter wurde mein Vater nach Linz geschickt und dort wurde er schlie�lich in Pension genommen. Doch in der Tat sollte das f�r den alten Herrn nicht "Ruhe" bedeuten. In seinen j�ngeren Tagen, als Sohn eines Armen h�uslers, konnte er es nicht ertragen, zu Hause zu bleiben. Bevor er noch dreizehn war, schn�rte der kleine junge seinen kleinen Rucksack und rannte von seinem Haus im Waldviertel Weg. Trotz der Versuchungen "erfahrener" Dorfbewohner, ihn davon abzubringen, machte er sich auf den Weg nach Wien, um dort einen Beruf zu erlernen. Dies war in den f�nfziger Jahren des vergangenen Jahrhunderts. Eine verzweifelte Entscheidung, auf die Stra�e mit nur drei gulden f�r Reisegeld zu nehmen,und Tauchen Sie ein in das unbekannte. Als der dreizehnj�hrige siebzehn Jahre alt wurde, hatte er die Pr�fung seines Lehrlings bestanden, war aber noch nicht zufrieden. Im Gegenteil. Die lange Zeit der not, des endlosen Elends und des Leidens, die er durchgemacht hatte, st�rkte seine Entschlossenheit, sein Handwerk aufzugeben und etwas besseres zu werden."Fr�her hatte der Arme junge den Priester als Verk�rperung aller menschlich erreichbaren H�hen angesehen; jetzt in der gro�en Stadt, die so stark seine Perspektive erweitert hatte, war es der Rang eines Beamten. Mit all der Hartn�ckigkeit eines Jungen Mannes, den Leid und F�rsorge schon als halbes Kind " alt " gemacht hatten, klammerte sich der siebzehnj�hrige an seine neue Entscheidung-er trat in den �ffentlichen Dienst ein. Und nach fast 23 Jahren, glaube ich, hat er sein Ziel erreicht. So schien er ein Gel�bde erf�llt zu haben, das er als armer junge gemacht hatte: dass er nicht in sein geliebtes Heimatdorf zur�ckkehren w�rde, bis er etwas von sich selbst gemacht hatte.

Sein Ziel wurde erreicht; aber niemand im Dorf konnte sich an den kleinen Jungen fr�herer Tage erinnern, und f�r ihn war das Dorf seltsam geworden.

Als er schlie�lich im Alter von sechsundf�nfzig Jahren in den Ruhestand ging, konnte er es nicht ertragen, einen einzigen Tag seiner Freizeit in M��iggang zu verbringen. In der N�he des Ober�sterreichischen marktdorfes Lambach kaufte er einen Hof, den er selbst arbeitete, und kehrte so in den Kreislauf eines langen und flei�igen Lebens zu den Urspr�ngen seiner Vorfahren zur�ck.

Zu dieser Zeit nahmen die ersten ideale in meiner Brust Gestalt an. All mein Spiel im freien, der lange Weg zur Schule, und besonders meine Verbindung mit extrem "husky" Jungen, die manchmal meine Mutter bittere Angst verursacht, machte mich das Gegenteil von einem Aufenthalt zu Hause. Und obwohl ich damals kaum ernsthafte Vorstellungen von dem Beruf hatte, den ich eines Tages aus�ben sollte, lag mein Mitgef�hl ohnehin nicht in Richtung der Karriere meines Vaters. Ich glaube, dass schon damals mein rednerisches talent in Form von mehr oder weniger gewaltt�tigen Auseinandersetzungen mit meinen Mitsch�lern entwickelt wurde. Ich war ein kleiner R�delsf�hrer geworden; in der Schule lernte ich leicht und damals sehr gut, war aber sonst eher schwer zu handhaben. Da ich in meiner Freizeit Gesangsunterricht im Kreuzgang in Lambach erhielt, hatte ich eine hervorragende Gelegenheit, mich mit der feierlichen Pracht der Brillanten Kirchenfeste zu berauschen. Wie es nur nat�rlich war, schien mir der Abt, wie der Dorfpriester meinem Vater einmal erschienen war, das h�chste und begehrteste ideal. Zumindest f�r eine Zeit war dies der Fall. Aber da mein Vater aus verst�ndlichen Gr�nden nicht in der Lage war, die rednerischen Talente seines k�mpferischen Jungen zu sch�tzen oder daraus positive R�ckschl�sse auf die Zukunft seiner Nachkommen zu ziehen, konnte er nat�rlich kein Verst�ndnis f�r solche Jugendlichen Ideen erlangen. Mit Sorge beobachtete er diesen naturkonflikt.

Wie es geschah, war mein vor�bergehendes Streben nach diesem Beruf auf jeden Fall bald zu verschwinden, Platz f�r Hoffnungen mehr zu meinem temperament erkl�rt. Als ich durch die Bibliothek meines Vaters st�berte, stie� ich auf verschiedene B�cher milit�rischer Art, darunter eine popul�re Ausgabe des Deutsch-franz�sischen Krieges von 1870-71. Es Bestand aus zwei Ausgaben einer Illustrierten Zeitschrift aus jenen Jahren, die jetzt zu meiner Lieblingslekt�re wurde es dauerte nicht lange, bis der gro�e heroische Kampf zu meiner gr��ten inneren Erfahrung geworden war. Von da an begeisterte ich mich immer mehr f�r alles, was in irgendeiner Weise mit Krieg oder Soldatentum verbunden war

Aber auch in anderer Hinsicht sollte das f�r mich von Bedeutung sein. Zum ersten mal, wenn auch noch in verwirrter form, wurde mir die Frage aufgezwungen: gab es einen Unterschied - und wenn ja, welchen Unterschied-zwischen den deutschen, die diese K�mpfe gef�hrt haben, und anderen deutschen? Warum hat �sterreich nicht an diesem Krieg teilgenommen, warum hat mein Vater und alle anderen nicht gek�mpft?

Sind wir nicht die gleichen wie alle anderen deutschen?

Geh�ren wir nicht alle zusammen? Dieses problem begann zum ersten mal an meinem kleinen Gehirn zu nagen. Ich stellte vorsichtige Fragen und erhielt mit heimlichem Neid die Antwort, dass nicht jeder Deutsche das Gl�ck hatte, Bismarcks Reich zu geh�ren..

Das war mehr, als ich verstehen konnte.

*...............*...............*

Es wurde beschlossen, dass ich zur high school gehen sollte.

Aus meiner ganzen Natur und in noch gr��erem Ma�e aus meinem temperament glaubte mein Vater, er k�nne daraus schlie�en, dass das humanistische Gymnasium einen Konflikt mit meinen Talenten darstellen w�rde. Eine Realschule schien ihm geeigneter. Meiner Meinung nach wurde er besonders durch meine offensichtliche zeichnerische Begabung gest�rkt; ein Thema, das seiner Meinung nach in den �sterreichischen Gymnasien vernachl�ssigt wurde. Ein weiterer Faktor mag seine eigene m�hsame Karriere gewesen sein, die das humanistische Studium in seinen Augen unpraktisch und daher weniger w�nschenswert erscheinen lie�. Es war seine grundlegende Meinung und Absicht, dass sein Sohn wie er Beamter werden w�rde und muss. Es war nur nat�rlich, dass die Strapazen seiner Jugend seine sp�tere Leistung in seinen Augen verbessern sollten, zumal es ausschlie�lich aus seiner eigenen Energie und seinem eisernen Flei� resultierte. Es war der stolz des selfmade-Mannes, der ihn dazu brachte, dass sein Sohn in die gleiche Position im Leben Aufstieg, oder, wenn m�glich, sogar noch h�her, zumal er durch sein eigenes flei�iges Leben dachte, dass er die Entwicklung seines Kindes so sehr erleichtern k�nnte.

Es war ihm einfach undenkbar, dass ich das, was sein ganzes Leben ausmachte, ablehne. Folglich war die Entscheidung meines Vaters einfach, eindeutig und klar; in seinen eigenen Augen meine ich nat�rlich. Schlie�lich hatte ihm ein ganzes Leben lang im erbitterten Existenzkampf eine herrschs�chtige Natur gegeben, und es w�re ihm unertr�glich erschienen, die endg�ltige Entscheidung in solchen Angelegenheiten einem unerfahrenen Jungen zu �berlassen, der noch kein Verantwortungsgef�hl Hatte. Dar�ber hinaus w�re dies eine s�ndige und Verwerfliche Schw�che in der Aus�bung seiner elterlichen Autorit�t und Verantwortung f�r das zuk�nftige Leben seines Kindes und als solche absolut unvereinbar mit seinem pflichtbegriff.

Und doch sollte es anders ausgehen.

Dann kaum elf Jahre alt, wurde ich zum ersten mal in meinem Leben in opposition gezwungen. Hart und entschlossen, wie mein Vater in der Umsetzung durch Pl�ne und Zwecke einmal konzipiert sein k�nnte sein Sohn war genauso hartn�ckig und widerspenstig bei der Ablehnung einer Idee, die ihn �berhaupt nicht angesprochen, oder in jedem Fall sehr wenig. 

Ich wollte kein Beamter werden.


]];

ITEM:Register();