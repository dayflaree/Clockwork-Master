--[[
	� CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");

ITEM.cost = 6;
ITEM.name = "A soldier's last moments";
ITEM.model = "models/props_lab/binderbluelabel.mdl";
ITEM.business = false;
ITEM.uniqueID = "book_aslm";
ITEM.description = "A blue book with paper tearing and scrap paper inside.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by SSGT. David Ranklin.</font>

I don't have much time left i'm afraid, these may well be my last written words. My name is SSGT. David Ranklin Marine Corps 34th Armored Regiment, i'm currently trapped in a building with my battalion, we're under invasion by alien forces. 

Currently this is the 3rd hour and it's Hell on Earth. They've already captured most of the other batallions fighting this war. I fear we will lose, I hear some gunfire coming towards the building but it sounds electronic. I think these are my final moments on earth. God Bless the US of A and hope to god i die peacefully.
]];

ITEM:Register();