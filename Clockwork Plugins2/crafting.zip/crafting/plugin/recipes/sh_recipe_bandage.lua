local RECIPE = PLUGIN.recipe:New();

RECIPE.name = "Crafting: Bandage";
RECIPE.uniqueID = "recipe_bandage";
RECIPE.model = "models/pg_props/pg_obj/pg_bandage.mdl";
RECIPE.category = "Medical";
RECIPE.description = "Knitting cloth together, you can create a decent bandage for wrapping";
RECIPE.ingredients = {["cloth_scraps"] = 2};
RECIPE.result = {["bandage"] = {1, 1, 1, 1, 1, 1, 2}};
RECIPE.hidden = false;

RECIPE:Register();