--[[
	© 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

function PLUGIN:PlayerSaveCharacterData(player, data)
	if (data["Hunger"]) then
		data["Hunger"] = math.Round(data["Hunger"]);
	end;
end;

function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["Hunger"] = data["Hunger"] or 100;
	player.lastTime = 0;
	player.HungerMessage = false;
	player.LastHung = 100
end;

function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("Hunger", 100);
	end;
end;

function PLUGIN:PlayerUseItem(player, itemTable)
	if (itemTable.category == "Consumables" or itemTable.category == "Alcohol") then
		if (itemTable.filling) then
			player:SetCharacterData("Hunger", math.Clamp(player:GetCharacterData("Hunger") + itemTable.filling,0,100));
		else
			player:SetCharacterData("Hunger", math.Clamp(player:GetCharacterData("Hunger") + CW.config:Get("hunger_default_refill"):Get(),0,100))
		end
		player:SaveCharacter();
	end;
end;

function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar("Hunger", math.Round(player:GetCharacterData("Hunger")));
end;

function PLUGIN:PlayerHasHunger(player)
	return !(Schema:PlayerIsCombine(player));
end;

function PLUGIN:OnePlayerSecond(player, curTime, infoTable)
	if (player:HasInitialized()) then
		local hunger = player:GetCharacterData("Hunger");
		local stamina = player:GetCharacterData("Stamina");
		local step = 100 / math.Round(CW.config:Get("hunger_tick"):Get());

		if (plugin.Call("PlayerHasHunger", player)) then
			player:SetCharacterData("Hunger", math.Clamp(player:GetCharacterData("Hunger") - step, 0, 100));
		end;

		if (stamina) then
			if (hunger < 60) then
				staminamax = math.Round(100 - (100 - hunger * 1.1));
				player:SetCharacterData("Stamina", math.Clamp(player:GetCharacterData("Stamina"), 0, staminamax));
			end;
		end;

		if (hunger < 15) then
			if (player:Health() > 50) then
				player:SetHealth(50);
			end;
		end;

		if (hunger < 5) then
			if (player:Health() > 20) then
				player:SetHealth(20);
			end;
		end;
	end;
end;
