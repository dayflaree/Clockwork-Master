--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("ru");

lang["#DisplayLines_1"] = "Transmitting physical transition vector...";
lang["#DisplayLines_2"] = "Modulating external temperature levels...";
lang["#DisplayLines_3"] = "Parsing view ports and data arrays...";
lang["#DisplayLines_4"] = "Translating Union practicalities...";
lang["#DisplayLines_5"] = "Updating biosignal co-ordinates...";
lang["#DisplayLines_6"] = "Parsing Clockwork protocol messages...";
lang["#DisplayLines_7"] = "Downloading recent dictionaries...";
lang["#DisplayLines_8"] = "Pinging connection to network...";
lang["#DisplayLines_9"] = "Updating mainframe connection...";
lang["#DisplayLines_10"] = "Synchronizing locational data...";
lang["#DisplayLines_11"] = "Translating radio messages...";
lang["#DisplayLines_12"] = "Emptying outgoing pipes...";
lang["#DisplayLines_13"] = "Sensoring proximity...";
lang["#DisplayLines_14"] = "Pinging loopback...";
lang["#DisplayLines_15"] = "Сброс подключения...";

lang["#Directory_CombineDispatch"] = "Надзор Г.О.";
lang["#Directory_CP"] = "Гражданская Оборона";

lang["#HL2RP_CashName"] = "Токены";

lang["#Quiz_Question1"] = "Вы понимаете, что данный игровой режим имеет медленный темп?";
lang["#Quiz_Yes"] = "Да.";
lang["#Quiz_No"] = "Нет.";

lang["#Quiz_Question2"] = "Как по-вашему будет правильнее написать:";
lang["#Quiz_Question2_BrainDead"] = "как нить так";
lang["#Quiz_Question2_Correct"] = "Как-нибудь вот так.";

lang["#Quiz_Question3"] = "Вы понимаете, что вам не нужно оружие для игры на сервере?";
lang["#Quiz_Question4"] = "Вы понимаете, что вам не нужны дополнительные предметы для отыгрыша роли?";
lang["#Quiz_Question5"] = "О чем, по вашему мнению, данный игровой режим?";
lang["#Quiz_Question5_Wrong"] = "Тут надо сбежать в закрытый сектор и присоединиться к повстанцам.";
lang["#Quiz_Question5_Correct"] = "Тут следует заниматься разработкой истории своего персонажа.";

lang["#Quiz_Question6"] = "По вселенной какой игры сделан данный игровой режим?";
lang["#Quiz_Question6_Wrong"] = "Garry's Mod.";
lang["#Quiz_Question6_Correct"] = "Half-Life 2.";

lang["#Class_OverwatchSoldier"] = "Сверхсолдат Надзора";
lang["#Class_OverwatchSoldier_Desc"] = "A transhuman Overwatch soldier produced by the Combine.";
lang["#Class_OverwatchSoldier_Wages"] = "Supplies";
lang["#Class_MPF"] = "Гражданская Оборона";
lang["#Class_MPF_Desc"] = "A metropolice unit working as Civil Protection.";
lang["#Class_MPF_Wages"] = "Supplies";
lang["#Class_Scanner"] = "Сканер";
lang["#Class_Scanner_Desc"] = "A metropolice scanner, it utilises Combine technology.";
lang["#Class_RCT"] = "Рекрут Г.О.";
lang["#Class_RCT_Desc"] = "A metropolice recruit working as Civil Protection.";
lang["#Class_RCT_Wages"] = "Supplies";
lang["#Class_OverwatchSoldierElite"] = "Элитный Сверхсолдат Надзора";
lang["#Class_OverwatchSoldierElite_Desc"] = "An elite transhuman Overwatch soldier produced by the Combine.";
lang["#Class_OverwatchSoldierElite_Wages"] = "Supplies";
lang["#Class_MPFElite"] = "Элитный Сотрудник Г.О.";
lang["#Class_MPFElite_Desc"] = "An elite metropolice unit working as Civil Protection.";
lang["#Class_MPFElite_Wages"] = "Supplies";
lang["#Class_CWU"] = "Г.С.Р.";
lang["#Class_CWU_Desc"] = "A civil worker's union worker.";
lang["#Class_CWU_Wages"] = "Supplies";
lang["#Class_Citizen"] = "Гражданин";
lang["#Class_Citizen_Desc"] = "A regular human citizen enslaved by the Universal Union.";
lang["#Class_Citizen_Wages"] = "Supplies";
lang["#Class_Admin"] = "Администратор Города";
lang["#Class_Admin_Desc"] = "A human Administrator advised by the Universal Union.";
lang["#Class_Admin_Wages"] = "Allowance";
lang["#Class_Rebel"] = "Повстанец";
lang["#Class_Rebel_Desc"] = "A rebel scum.";
lang["#Class_Rebel_Wages"] = "Share";

lang["#Faction_OTA"] = "Сверхсолдат Надзора";
lang["#Faction_MPF"] = "Гражданская Оборона";
lang["#Faction_CWU"] = "Гражданский Союз Рабочих";
lang["#Faction_Citizen"] = "Гражданин";
lang["#Faction_Admin"] = "Администратор";
lang["#Faction_Rebel"] = "Повстанец";

lang["#Attribute_Acrobatics"] = "Высота прыжка";
lang["#Attribute_Strength"] = "Сила";
lang["#Attribute_Medical"] = "Познания в медицине";
lang["#Attribute_Endurance"] = "Выносливость";
lang["#Attribute_Dexterity"] = "Ловкость рук";
lang["#Attribute_Agility"] = "Скорость бега";

lang["#Attribute_Acrobatics_Desc"] = "Влияет на высоту прыжка.";
lang["#Attribute_Strength_Desc"] = "Влияет на силу вашего персонажа, например как сильно он сможет ударить в рукопашной.";
lang["#Attribute_Medical_Desc"] = "Влияет на то, сколько здоровья будут восстанавливать аптечки.";
lang["#Attribute_Endurance_Desc"] = "Влияет на количество урона, который ваш персонаж может получить.";
lang["#Attribute_Dexterity_Desc"] = "Влияет на скорость связывания/развязывания пластиковых наручников, а также открытия и закрытия дверей.";
lang["#Attribute_Agility_Desc"] = "Влияет на то, как быстро вы можете бежать.";