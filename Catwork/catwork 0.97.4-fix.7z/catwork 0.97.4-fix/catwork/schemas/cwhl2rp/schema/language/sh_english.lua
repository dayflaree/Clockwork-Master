--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("en");

lang["#DisplayLines_1"] = "Transmitting physical transition vector...";
lang["#DisplayLines_2"] = "Modulating external temperature levels...";
lang["#DisplayLines_3"] = "Parsing view ports and data arrays...";
lang["#DisplayLines_4"] = "Translating Union practicalities...";
lang["#DisplayLines_5"] = "Updating biosignal co-ordinates...";
lang["#DisplayLines_6"] = "Parsing Clockwork protocol messages...";
lang["#DisplayLines_7"] = "Downloading recent dictionaries...";
lang["#DisplayLines_8"] = "Pinging connection to network...";
lang["#DisplayLines_9"] = "Updating mainframe connection...";
lang["#DisplayLines_10"] = "Synchronizing locational data...";
lang["#DisplayLines_11"] = "Translating radio messages...";
lang["#DisplayLines_12"] = "Emptying outgoing pipes...";
lang["#DisplayLines_13"] = "Sensoring proximity...";
lang["#DisplayLines_14"] = "Pinging loopback...";
lang["#DisplayLines_15"] = "Idle connection...";

lang["#Directory_CombineDispatch"] = "Combine Dispatcher";
lang["#Directory_CP"] = "Civil Protection";

lang["#HL2RP_CashName"] = "Tokens";

lang["#Quiz_Question1"] = "Do you understand that roleplaying is slow paced and relaxed?";
lang["#Quiz_Yes"] = "Yes.";
lang["#Quiz_No"] = "No.";

lang["#Quiz_Question2"] = "Can you type properly, using capital letters and full-stops?";
lang["#Quiz_Question2_BrainDead"] = "yeah sure i can";
lang["#Quiz_Question2_Correct"] = "Yes, I can.";

lang["#Quiz_Question3"] = "You do not need weapons to roleplay, do you understand?";
lang["#Quiz_Question4"] = "You do not need items to roleplay, do you understand?";
lang["#Quiz_Question5"] = "What do you think serious roleplaying is about?";
lang["#Quiz_Question5_Wrong"] = "Collecting items and upgrades.";
lang["#Quiz_Question5_Correct"] = "Developing your character.";

lang["#Quiz_Question6"] = "What universe is this roleplaying game set in?";
lang["#Quiz_Question6_Wrong"] = "Real Life.";
lang["#Quiz_Question6_Correct"] = "Half-Life 2.";

lang["#Class_OverwatchSoldier"] = "Overwatch Soldier";
lang["#Class_OverwatchSoldier_Desc"] = "A transhuman Overwatch soldier produced by the Combine.";
lang["#Class_OverwatchSoldier_Wages"] = "Supplies";
lang["#Class_MPF"] = "Metropolice Unit";
lang["#Class_MPF_Desc"] = "A metropolice unit working as Civil Protection.";
lang["#Class_MPF_Wages"] = "Supplies";
lang["#Class_Scanner"] = "Metropolice Scanner";
lang["#Class_Scanner_Desc"] = "A metropolice scanner, it utilises Combine technology.";
lang["#Class_RCT"] = "Metropolice Recruit";
lang["#Class_RCT_Desc"] = "A metropolice recruit working as Civil Protection.";
lang["#Class_RCT_Wages"] = "Supplies";
lang["#Class_OverwatchSoldierElite"] = "Elite Overwatch Soldier";
lang["#Class_OverwatchSoldierElite_Desc"] = "An elite transhuman Overwatch soldier produced by the Combine.";
lang["#Class_OverwatchSoldierElite_Wages"] = "Supplies";
lang["#Class_MPFElite"] = "Elite Metropolice";
lang["#Class_MPFElite_Desc"] = "An elite metropolice unit working as Civil Protection.";
lang["#Class_MPFElite_Wages"] = "Supplies";
lang["#Class_CWU"] = "Civil Worker's Union";
lang["#Class_CWU_Desc"] = "A civil worker's union worker.";
lang["#Class_CWU_Wages"] = "Supplies";
lang["#Class_Citizen"] = "Citizen";
lang["#Class_Citizen_Desc"] = "A regular human citizen enslaved by the Universal Union.";
lang["#Class_Citizen_Wages"] = "Supplies";
lang["#Class_Admin"] = "Administrator";
lang["#Class_Admin_Desc"] = "A human Administrator advised by the Universal Union.";
lang["#Class_Admin_Wages"] = "Allowance";
lang["#Class_Rebel"] = "Rebel";
lang["#Class_Rebel_Desc"] = "A rebel scum.";
lang["#Class_Rebel_Wages"] = "Share";

lang["#Faction_OTA"] = "Overwatch Transhuman Arm";
lang["#Faction_MPF"] = "Metropolice Force";
lang["#Faction_CWU"] = "Civil Worker's Union";
lang["#Faction_Citizen"] = "Citizen";
lang["#Faction_Admin"] = "Administrator";
lang["#Faction_Rebel"] = "Rebel";

lang["#Attribute_Acrobatics"] = "Acrobatics";
lang["#Attribute_Strength"] = "Strength";
lang["#Attribute_Medical"] = "Medical";
lang["#Attribute_Endurance"] = "Endurance";
lang["#Attribute_Dexterity"] = "Dexterity";
lang["#Attribute_Agility"] = "Agility";

lang["#Attribute_Acrobatics_Desc"] = "Affects the overall height at which you can jump.";
lang["#Attribute_Strength_Desc"] = "Affects your overall strength, e.g: how hard you punch.";
lang["#Attribute_Medical_Desc"] = "Affects your overall medical skills, e.g: health gained from vials and kits.";
lang["#Attribute_Endurance_Desc"] = "Affects your overall endurance, e.g: how much pain you can take.";
lang["#Attribute_Dexterity_Desc"] = "Affects your overall dexterity, e.g: how fast you can tie/untie.";
lang["#Attribute_Agility_Desc"] = "Affects your overall speed, e.g: how fast you run.";
