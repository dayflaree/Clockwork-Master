--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "#Attribute_Acrobatics";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "acr";
	ATTRIBUTE.description = "#Attribute_Acrobatics_Desc";
	ATTRIBUTE.isOnCharScreen = true;
ATB_ACROBATICS = CW.attribute:Register(ATTRIBUTE);