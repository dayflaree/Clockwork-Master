--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "#Attribute_Agility";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "agt";
	ATTRIBUTE.description = "#Attribute_Agility_Desc"
	ATTRIBUTE.isOnCharScreen = true;
ATB_AGILITY = CW.attribute:Register(ATTRIBUTE);