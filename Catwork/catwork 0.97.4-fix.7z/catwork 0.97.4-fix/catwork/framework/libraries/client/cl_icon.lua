--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.icon = CW.kernel:NewLibrary("Icon");
CW.icon.stored = CW.icon.stored or {};
	
-- A function to add a chat icon.
function CW.icon:Add(uniqueID, path, callback, bIsPlayer)
	if (uniqueID) then
		if (path) then
			if (callback) then
				self.stored[uniqueID] = {
					path = path,
					callback = callback,
					isPlayer = bIsPlayer
				};
			else
				MsgC(Color(255, 100, 0, 255), "[CW:Icon] Error: Attempting to add icon without providing a callback.\n");
			end;
		else
			MsgC(Color(255, 100, 0, 255), "[CW:Icon] Error: Attempting to add icon without providing a path..\n");
		end;
	else
		MsgC(Color(255, 100, 0, 255), "[CW:Icon] Error: Attempting to add an icon without providing a uniqueID.\n");
	end;
end;

-- A function to remove a chat icon.
function CW.icon:Remove(uniqueID)
	if (uniqueID) then
		self.stored[uniqueID] = nil;
	else
		MsgC(Color(255, 100, 0, 255), "[CW:Icon] Error: Attempting to remove an icon without providing a uniqueID.\n");
	end;
end;

-- A function to set a player's icon.
function CW.icon:PlayerSet(steamID, uniqueID, path)
	CW.icon:Add(uniqueID, path, function(player)
		if (steamID == player:SteamID()) then
			return true;
		end;
	end, true);
end;

-- A function to set a group's icon.
function CW.icon:GroupSet(group, uniqueID, path)
	CW.icon:Add(uniqueID, path, function(player)
		if (player:IsUserGroup(group)) then
			return true;
		end;
	end);
end;

-- A function to return the stored icons.
function CW.icon:GetAll()
	return CW.icon.stored;
end;

CW.icon:GroupSet("superadmin", "SuperAdminShield", "icon16/shield.png");
CW.icon:GroupSet("admin", "AdminStar", "icon16/star.png");
CW.icon:GroupSet("operator", "OperatorSmile", "icon16/emoticon_smile.png");