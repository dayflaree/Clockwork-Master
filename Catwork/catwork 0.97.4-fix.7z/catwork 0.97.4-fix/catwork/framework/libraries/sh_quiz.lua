--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.quiz = CW.kernel:NewLibrary("Quiz");
CW.quiz.stored = CW.quiz.stored or {};

-- A function to set the quiz name.
function CW.quiz:SetName(name)
	self.name = name;
end;

-- A function to get the quiz name.
function CW.quiz:GetName()
	return self.name or "#QuizPanel_Questions";
end;

-- A function to set whether the quiz is enabled.
function CW.quiz:SetEnabled(enabled)
	self.enabled = enabled;
end;

-- A function to get whether the quiz is enabled.
function CW.quiz:GetEnabled()
	return self.enabled;
end;

-- A function to get the amount of quiz questions.
function CW.quiz:GetQuestionsAmount()
	return table.Count(self.stored);
end;

-- A function to get the quiz questions.
function CW.quiz:GetQuestions()
	return self.stored;
end;

-- A function to get a question.
function CW.quiz:GetQuestion(index)
	return self.stored[index];
end;

-- A function to get if an answer is correct.
function CW.quiz:IsAnswerCorrect(index, answer)
	question = self:GetQuestion(index);
	
	if (question) then
		if (type(question.answer) == "table" and table.HasValue(question.answer, answer)) then
			return true;
		elseif (answer == question.possibleAnswers[question.answer]) then
			return true;
		elseif (question.answer == answer) then
			return true;
		end;
	end;
end;

-- A function to add a new quiz question.
function CW.quiz:AddQuestion(question, answer, ...)
	local index = CW.kernel:GetShortCRC(question);
	
	self.stored[index] = {
		possibleAnswers = {...},
		question = question,
		answer = answer
	};
end;

-- A function to remove a quiz question.
function CW.quiz:RemoveQuestion(question)
	if (self.stored[question]) then
		self.stored[question] = nil;
	else
		local index = CW.kernel:GetShortCRC(question);
		
		if (self.stored[index]) then
			self.stored[index] = nil;
		end;
	end;
end;

if (CLIENT) then
	function CW.quiz:SetCompleted(completed)
		self.completed = completed;
	end;
	
	-- A function to get whether the quiz is completed.
	function CW.quiz:GetCompleted()
		return self.completed;
	end;
	
	-- A function to get the quiz panel.
	function CW.quiz:GetPanel()
		if (IsValid(self.panel)) then
			return self.panel;
		end;
	end;
else
	function CW.quiz:SetCompleted(player, completed)
		if (completed) then
			player:SetData("Quiz", self:GetQuestionsAmount());
		else
			player:SetData("Quiz", nil);
		end;
		
		netstream.Start(player, "QuizCompleted", completed);
	end;
	
	-- A function to get whether a player has completed the quiz.
	function CW.quiz:GetCompleted(player)
		if (player:GetData("Quiz") == self:GetQuestionsAmount()) then
			return true;
		else
			return player:IsBot();
		end;
	end;
	
	-- A function to set the quiz percentage.
	function CW.quiz:SetPercentage(percentage)
		self.percentage = percentage;
	end;
	
	-- A function to get the quiz percentage.
	function CW.quiz:GetPercentage()
		return self.percentage or 100;
	end;
	
	-- A function to call the quiz kick Callback.
	function CW.quiz:CallKickCallback(player, correctAnswers)
		local kickCallback = self:GetKickCallback();
		
		if (kickCallback) then
			kickCallback(player, correctAnswers);
		end;
	end;
	
	-- A function to get the quiz kick Callback.
	function CW.quiz:GetKickCallback()
		if (self.kickCallback) then
			return self.kickCallback;
		else
			return function(player, correctAnswers)
				player:Kick(CW.lang:GetString(player:GetNWString("Language"), "#QuizPanel_KickReason"));
			end;
		end;
	end;
	
	-- A function to set the quiz kick Callback.
	function CW.quiz:SetKickCallback(Callback)
		self.kickCallback = Callback;
	end;
end;