--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

function CW:ClockworkSchemaLoaded()
	self.directory:AddCategoryPage("Credits", "Clockwork", "http://authx.cloudsixteen.com/credits.php", true);
	
	MsgC(Color(255, 255, 0), "CW::Client - Loaded external Directory pages. See the Directory for more information.\n");
end;

local colour_stack = { {r=255,g=255,b=255,a=255} }
local font_stack = { "DermaDefault" }
local curtag = nil
local blocks = {}

function CW:ClockworkLoadShared()
	self.kernel.OldGetMaterial = self.kernel.GetMaterial;
	if (self.kernel.OldGetMaterial) then
		function self.kernel:GetMaterial(materialPath, pngParameters)
			if (type(materialPath) == "string") then
				return self:OldGetMaterial(materialPath, pngParameters);
			else
				return materialPath;
			end;
		end;
	end;

	if (Schema and Schema.author == "kurozael") then
		Schema.author = "kurozael (CloudSixteen.com)";
	end;
end;

function extern_CharModelOnMousePressed(panel)
	if (panel.DoClick) then
		panel:DoClick();
	end;
end;

function extern_SetModelAndSequence(panel, model)
	panel:ClockworkSetModel(model);
 
	local entity = panel.Entity;
 
	if (!IsValid(entity)) then
		return;
	end;
 
	local sequence = entity:LookupSequence("idle");
	local menuSequence = CW.animation:GetMenuSequence(model, true);
	local leanBackAnims = {"LineIdle01", "LineIdle02", "LineIdle03"};
	
	local leanBackAnim = entity:LookupSequence(
		leanBackAnims[math.random(1, #leanBackAnims)]
	);
 
	if (leanBackAnim > 0) then
		sequence = leanBackAnim;
	end;
 
	if (menuSequence) then
		menuSequence = entity:LookupSequence(menuSequence);
 
		if (menuSequence > 0) then
			sequence = menuSequence;
		end;
	end;
 
	if (sequence <= 0) then
		sequence = entity:LookupSequence("idle_unarmed");
	end;
 
	if (sequence <= 0) then
		sequence = entity:LookupSequence("idle1");
	end;
 
	if (sequence <= 0) then
		sequence = entity:LookupSequence("walk_all");
	end;
 
	if (sequence > 0) then
		entity:ResetSequence(sequence);
	end;
end;

function extern_CharModelInit(panel)
	panel:SetCursor("none");
	panel.ClockworkSetModel = panel.SetModel;
	panel.SetModel = extern_SetModelAndSequence;
 
	CW.kernel:CreateMarkupToolTip(panel);
end;

function extern_CharModelLayoutEntity(panel)
	local screenW = ScrW();
	local screenH = ScrH();
 
	local fractionMX = gui.MouseX() / screenW;
	local fractionMY = gui.MouseY() / screenH;
 
	local entity = panel.Entity;
	local x, y = panel:LocalToScreen(panel:GetWide() / 2);
	local fx = x / screenW;
 
	entity:SetPoseParameter("head_pitch", fractionMY * 80 - 30);
	entity:SetPoseParameter("head_yaw", (fractionMX - fx) * 70);
	entity:SetAngles(Angle(0, 45, 0));
	entity:SetIK(false);
 
	panel:RunAnimation();
end;

local cwOldRunConsoleCommand = RunConsoleCommand;
function RunConsoleCommand(...)
	local arguments = {...};
 
	if (arguments[1] == nil) then
		return;
	end;
 
	cwOldRunConsoleCommand(...);
end;