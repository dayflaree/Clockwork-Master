--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local THEME = CW.theme:New("Clockwork");

-- Called when fonts should be created.
function THEME:CreateFonts()
	CW.fonts:Add("cwMainText", 
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(7),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwESPText", 
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(5.5),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwTooltip", 
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(5),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("CW.menuTextBig",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(18),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("CW.menuTextTiny",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(7),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwInfoTextFont",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(6),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("CW.menuTextHuge",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(30),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("CW.menuTextSmall",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(10),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwIntroTextBig",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(18),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwIntroTextTiny",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(9),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwIntroTextSmall",
	{
		font		= "Arial",
		size		= CW.kernel:FontScreenScale(7),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwLarge3D2D",
	{
		font		= "Arial",
		size		= CW.kernel:GetFontSize3D(),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwScoreboardName",
	{
		font		= "Arial",
		size		= 20,
		weight		= 600,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwScoreboardDesc",
	{
		font		= "Arial",
		size		= 16,
		weight		= 600,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwScoreboardClass",
	{
		font		= "Arial",
		size		= 25,
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwCinematicText",
	{
		font		= "Trebuchet",
		size		= CW.kernel:FontScreenScale(8),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	CW.fonts:Add("cwChatSyntax",
	{
		font		= "Courier New",
		size		= CW.kernel:FontScreenScale(7),
		weight		= 600,
		antialiase	= true,
		additive 	= false
	});
end;

-- Called when to initialize the theme.
function THEME:Initialize()

	--[[ Set Default Options --]]
	CW.option:SetKey("icon_data_classes", {path = "tag", size = nil});
	CW.option:SetKey("icon_data_settings", {path = "wrench", size = nil});
	CW.option:SetKey("icon_data_system", {path = "cog", size = nil});
	CW.option:SetKey("icon_data_scoreboard", {path = "list-alt", size = 3});
	CW.option:SetKey("icon_data_inventory", {path = "inbox", size = nil});
	CW.option:SetKey("icon_data_directory", {path = "book", size = nil});
	CW.option:SetKey("icon_data_attributes", {path = "bar-chart", size = 2});
	CW.option:SetKey("icon_data_business", {path = "briefcase", size = 2});
	
	CW.option:SetKey("top_bar_width_scale", 0.3);
	
	CW.option:SetKey("info_text_icon_size", 16);
	CW.option:SetKey("info_text_red_icon", "icon16/exclamation.png");
	CW.option:SetKey("info_text_green_icon", "icon16/tick.png");
	CW.option:SetKey("info_text_orange_icon", "icon16/error.png");
	CW.option:SetKey("info_text_blue_icon", "icon16/information.png");

	CW.option:SetKey("name_attributes", "Attributes");
	CW.option:SetKey("name_attribute", "Attribute");
	CW.option:SetKey("name_system", "System");
	CW.option:SetKey("name_scoreboard", "Scoreboard");
	CW.option:SetKey("name_directory", "Directory");
	CW.option:SetKey("name_inventory", "Inventory");
	CW.option:SetKey("name_business", "Business");
	CW.option:SetKey("name_destroy", "Destroy");

	CW.option:SetKey("description_business", "Order items for your business.");
	CW.option:SetKey("description_inventory", "Manage the items in your inventory.");
	CW.option:SetKey("description_directory", "A directory of various topics and information.");
	CW.option:SetKey("description_system", "Access a variety of server-side options.");
	CW.option:SetKey("description_scoreboard", "See which players are on the server.");
	CW.option:SetKey("description_attributes", "Check the status of your attributes.");

	CW.option:SetKey("gradient", nil);

	--[[ Set Default Colors --]]
	CW.option:SetColor("columnsheet_shadow_normal", Color(0, 0, 0, 255));
	CW.option:SetColor("columnsheet_text_normal", Color(255, 255, 255, 255));
	CW.option:SetColor("columnsheet_shadow_active", Color(255, 255, 255, 255));
	CW.option:SetColor("columnsheet_text_active", Color(50, 50, 50, 255));
	
	CW.option:SetColor("basic_form_highlight", Color(0, 0, 0, 255));
	CW.option:SetColor("basic_form_color", Color(0, 0, 0, 255));
	
	CW.option:SetColor("scoreboard_name", Color(0, 0, 0, 255));
	CW.option:SetColor("scoreboard_desc", Color(0, 0, 0, 255));
	CW.option:SetColor("scoreboard_item_background", Color(255, 255, 255, 50));
	
	CW.option:SetColor("positive_hint", Color(100, 175, 100, 255));
	CW.option:SetColor("negative_hint", Color(175, 100, 100, 255));
	CW.option:SetColor("background", Color(0, 0, 0, 125));
	CW.option:SetColor("foreground", Color(50, 50, 50, 125));
	CW.option:SetColor("target_id", Color(50, 75, 100, 255));
	CW.option:SetColor("white", Color(255, 255, 255, 255));

	--[[ Set Default Fonts --]]
	CW.option:SetFont("schema_description", "cwMainText");
	CW.option:SetFont("scoreboard_desc", "cwScoreboardDesc");
	CW.option:SetFont("scoreboard_name", "cwScoreboardName");
	CW.option:SetFont("scoreboard_class", "cwScoreboardClass");
	CW.option:SetFont("player_info_text", "cwMainText");
	CW.option:SetFont("intro_text_small", "cwIntroTextSmall");
	CW.option:SetFont("intro_text_tiny", "cwIntroTextTiny");
	CW.option:SetFont("menu_text_small", "CW.menuTextSmall");
	CW.option:SetFont("chat_box_syntax", "cwChatSyntax");
	CW.option:SetFont("menu_text_huge", "CW.menuTextHuge");
	CW.option:SetFont("intro_text_big", "cwIntroTextBig");
	CW.option:SetFont("info_text_font", "cwInfoTextFont");
	CW.option:SetFont("menu_text_tiny", "CW.menuTextTiny");
	CW.option:SetFont("date_time_text", "CW.menuTextSmall");
	CW.option:SetFont("cinematic_text", "cwCinematicText");
	CW.option:SetFont("target_id_text", "cwMainText");
	CW.option:SetFont("auto_bar_text", "cwMainText");
	CW.option:SetFont("menu_text_big", "CW.menuTextBig");
	CW.option:SetFont("chat_box_text", "cwMainText");
	CW.option:SetFont("large_3d_2d", "cwLarge3D2D");
	CW.option:SetFont("hints_text", "cwIntroTextTiny");
	CW.option:SetFont("main_text", "cwMainText");
	CW.option:SetFont("bar_text", "cwMainText");
	CW.option:SetFont("esp_text", "cwESPText");

	--[[ Set Default Sounds --]]
	CW.option:SetSound("click_release", "ui/buttonclickrelease.wav");
	CW.option:SetSound("rollover", "ui/buttonrollover.wav");
	CW.option:SetSound("click", "ui/buttonclick.wav");
	CW.option:SetSound("tick", "common/talk.wav");

	--[[ Bar Settings --]]
	CW.bars.height = 12;
	CW.bars.padding = 14;
end;

-- Called when the menu is closed.
function THEME.module:MenuClosed()
	if (CW.Client:HasInitialized()) then
		CW.kernel:RemoveBackgroundBlur("MainMenu");
	end;
end;

-- Called after the character menu has initialized.
function THEME.hooks:PostCharacterMenuInit(panel) end;

-- Called every frame that the character menu is open.
function THEME.hooks:PostCharacterMenuThink(panel) end;

-- Called after the character menu is painted.
function THEME.hooks:PostCharacterMenuPaint(panel) end;

-- Called after a character menu panel is opened.
function THEME.hooks:PostCharacterMenuOpenPanel(panel) end;

-- Called after the main menu has initialized.
function THEME.hooks:PostMainMenuInit(panel) end;

-- Called after the main menu is rebuilt.
function THEME.hooks:PostMainMenuRebuild(panel) end;

-- Called after a main menu panel is opened.
function THEME.hooks:PostMainMenuOpenPanel(panel, panelToOpen) end;

-- Called after the main menu is painted.
function THEME.hooks:PostMainMenuPaint(panel) end;

-- Called every frame that the main menu is open.
function THEME.hooks:PostMainMenuThink(panel) end;

CW.theme:Register();