local ITEM = Clockwork.item:New()
ITEM.name = "Карта награды: 2 ОЛ"
ITEM.uniqueID = "reward_card_loyal_2"
ITEM.model = "models/gibs/metal_gib4.mdl"
ITEM.weight = 0.1
ITEM.RareItem = true
ITEM.useText = "Вставить"
ITEM.category = "Карты"
ITEM.description = "Маленькая металлическая карточка со странными символами на ней.\nОчки Лояльности: 2."

-- Called when a custom function is used.
function ITEM:OnUse(player, itemEntity)
	local itemTable = player:FindItemByID("reward_card_loyal_2");			
	local entity = player:GetEyeTraceNoCursor().Entity
	if (entity:GetClass() == "hl2_combinemonitor") then
		if (entity:GetPos():Distance(player:GetShootPos()) <= 192) then
			player:TakeItem(self)

			local rewardReputation = 2
			CW.player:Notify(player, "C14 Терминал - ''Спасибо за использование терминала награждения. Получите своё вознаграждение.''")
			timer.Simple(2, function()
				entity:EmitSound("ambient/machines/combine_terminal_idle4.wav");			
				player:SetCharacterData("civ_reputation", player:GetCharacterData("civ_reputation")+rewardReputation)
			end);	
		else
			Clockwork.player:Notify(player, "Терминал слишком далеко!")
		end
	else
		Clockwork.player:Notify(player, "Вы должны смотреть на терминал выдачи награды!")
	end
	return false
end

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();