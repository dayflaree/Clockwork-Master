--[[
	© Songbird aka Alko -  do not re-distribute without permission of its author (ael9000 gmail.com).
--]]

local PLUGIN = PLUGIN

Clockwork.kernel:IncludePrefixed("cl_hooks.lua")
Clockwork.kernel:IncludePrefixed("sv_hooks.lua")
Clockwork.kernel:IncludePrefixed("cl_plugin.lua")

local playerMeta = FindMetaTable("Player")

function playerMeta:CombineRequestSay(text)
	for k, v in pairs(player.GetAll()) do
		if (Schema:PlayerIsCombine(v)) then
			if (v:Alive()) then							
				v:EmitSound("npc/combine_soldier/vo/on2.wav")
				chatbox.AddText(v, text, {suffix = " говорит по рации: ", sender = self, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(75, 150, 50, 255), data = {radio = true}})
			end
		end
	end

	for k, v in pairs(ents.FindInSphere(self:GetPos(), Clockwork.config:Get("talk_radius"):Get())) do
		if (IsValid(v) and v:IsPlayer() and v:Alive()) then
			if (!Schema:PlayerIsCombine(v)) then
				if (v:Alive()) then
					chatbox.AddText(v, text, {suffix = " говорит по рации: ", sender = self, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(75, 150, 50, 255), data = {radio = true}})
				end
			end
		end
	end	
end

function playerMeta:CombineRequestAnswer(text)
	chatbox.AddText(self, text, {suffix = ": ", sender = self, playerName = "Центр", forceName = true, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(25, 150, 0, 255), data = {radio = true}})
end

function PLUGIN:CombineBroadcast(text)
	chatbox.AddText(nil, text, {suffix = " сообщает: ", playerName = "Система оповещения", forceName = true, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(150, 100, 100, 255), data = {dispatch = true}})
end