local COMMAND = Clockwork.command:New("cwuWPRequest")
COMMAND.tip = "Запрос начисления гражданину Очков Труда."
COMMAND.text = "<string CID> <number AMOUNT>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if combine:GetFaction() == FACTION_CWU then
		local stringCID = arguments[1]
		local numberAMOUNT = tonumber(arguments[2])

		for k, citizen in pairs(player.GetAll()) do
			if citizen:GetCharacterData("citizenid") == arguments[1] then
				if citizen:GetFaction() == FACTION_CITIZEN or citizen:GetFaction() == FACTION_CWU or citizen:GetFaction() == FACTION_REBEL or citizen:GetFaction() == FACTION_REFUGE or citizen:GetFaction() == FACTION_RENEG then				
					citizen:SetCharacterData("civ_wp", math.Clamp(citizen:GetCharacterData("civ_wp") + numberAMOUNT, 0, 220))					

					local newBMD = citizen:GetCharacterData("civ_wp")
					combine:CombineRequestAnswer("Очки рабочего гражданину #"..stringCID.." были начислены. Гражданин получил "..numberAMOUNT.." очков рабочего, общее количество"..newBMD.."/220.")

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "You are not a CWU!")
	end
end

COMMAND:Register();