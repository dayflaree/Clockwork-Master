local PLUGIN = PLUGIN

Clockwork.setting:AddCheckBox("#Framework", "Включить вид от 3-его лица.", "cwThirdPerson", "Использовать ли вид от третьего лица.");