--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

PLUGIN:SetGlobalAlias("cwCustomSpawn")

CW.kernel:IncludePrefixed("sv_hooks.lua");