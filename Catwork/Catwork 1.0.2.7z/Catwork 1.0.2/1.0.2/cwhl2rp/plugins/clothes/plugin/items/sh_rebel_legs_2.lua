--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Blue Tactical Pants"
	ITEM.PrintName = "#ITEM_Rebel_Legs_2_Name"
	ITEM.cost = 100
	ITEM.model = "models/tnb/items/pants_rebel.mdl"
	ITEM.skin = 2
	ITEM.plural = "#ITEM_Rebel_Legs_2_Plural"
	ITEM.weight = 1
	ITEM.uniqueID = "rebel_legs_2"
	ITEM.business = false
	ITEM.bodyGroup = 2
	ITEM.bodyGroupVal = 5
	ITEM.description = "#ITEM_Rebel_Legs_2_Desc"
	ITEM.protection = 12
ITEM:Register();