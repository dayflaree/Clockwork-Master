--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Medic Pants"
	ITEM.PrintName = "#ITEM_Rebel_Legs_3_Name"
	ITEM.cost = 120
	ITEM.model = "models/tnb/items/pants_rebel.mdl"
	ITEM.plural = "#ITEM_Rebel_Legs_3_Plural"
	ITEM.weight = 1
	ITEM.uniqueID = "rebel_legs_3"
	ITEM.business = false
	ITEM.bodyGroup = 2
	ITEM.bodyGroupVal = 6
	ITEM.description = "#ITEM_Rebel_Legs_3_Desc"
	ITEM.protection = 17
ITEM:Register();