--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Gloves"
	ITEM.PrintName = "#ITEM_Gloves_Name"
	ITEM.cost = 30
	ITEM.model = "models/tnb/items/gloves.mdl"
	ITEM.plural = "#ITEM_Gloves_Plural"
	ITEM.weight = 0.2
	ITEM.uniqueID = "gloves"
	ITEM.business = false
	ITEM.bodyGroup = 3
	ITEM.bodyGroupVal = 1
	ITEM.description = "#ITEM_Gloves_Desc"
ITEM:Register();