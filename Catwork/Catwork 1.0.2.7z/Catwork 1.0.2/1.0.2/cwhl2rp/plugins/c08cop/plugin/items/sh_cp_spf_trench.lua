local ITEM = Clockwork.item:New("cpoutfit_base")
ITEM.uniqueID = "cp_spf_trench"
ITEM.name = "Set of Civil Protection outfit: 'Special Forces' Trenchcoat"
ITEM.PrintName = "Комплект экипировки ГО: 'Special Forces' с тренчем"
ITEM.model = "models/props_c17/SuitCase001a.mdl"
ITEM.weight = 5
ITEM.category = "Гражданская Оборона - Комплекты"
ITEM.description = "Экипировка спец. сил Гражданской Обороны с тренчем."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = {
	uniform = "5",
	bodygroups = "001101117",
	gasmask = "5",
	gasmaskshock = "0",
	glow = "1"
}
ITEM.cparmband = nil
ITEM.cppvisor = "1_7_1"
ITEM.cpsvisor = "1_3_1"
ITEM.rank = nil

ITEM:Register()