local Clockwork = Clockwork

local ITEM = Clockwork.item:New(nil, true)
ITEM.name = "CPOutfit Base"
ITEM.model = "models/props_c17/SuitCase001a.mdl"
ITEM.weight = 5
ITEM.useText = "Надеть"
ITEM.category = "Одежда"
ITEM.description = ""

ITEM.cpoutfit = nil
ITEM.cparmband = nil
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = nil
ITEM.changeModel = false

local function processOutfit(item, player)
	if item.cpoutfit then
		local outfit = player:GetCharacterData("CP08_Outfit") or "0_0000000000_0_0_0"
		local strTable = string.Explode("_", outfit)
		local uID = strTable[1]
		local bodygroups =strTable[2]
		local gasmaskID = strTable[3]
		local gasmaskShockID = strTable[4]
		local gasmaskGlow = strTable[5]

		local newOutfit = ""
		if item.cpoutfit.uniform then
			newOutfit = newOutfit .. tostring(item.cpoutfit.uniform) .. "_"
		else
			newOutfit = newOutfit .. uID .. "_"
		end
		if item.cpoutfit.bodygroups then
			newOutfit = newOutfit .. tostring(item.cpoutfit.bodygroups) .. "_"
		else
			newOutfit = newOutfit .. bodygroups .. "_"
		end
		if item.cpoutfit.gasmask then
			newOutfit = newOutfit .. tostring(item.cpoutfit.gasmask) .. "_"
		else
			newOutfit = newOutfit .. gasmaskID .. "_"
		end
		if item.cpoutfit.gasmaskshock then
			newOutfit = newOutfit .. tostring(item.cpoutfit.gasmaskshock) .. "_"
		else
			newOutfit = newOutfit .. gasmaskShockID .. "_"
		end
		if item.cpoutfit.glow then
			newOutfit = newOutfit .. tostring(item.cpoutfit.glow)
		else
			newOutfit = newOutfit .. gasmaskGlow
		end

		ReadCPOutfit(player, newOutfit)
		player:SetCharacterData("CP08_Outfit", newOutfit)
	end
	if item.cparmband then
		ReadCPArmband(player, item.cparmband)
		player:SetCharacterData("CP08_Armband", item.cparmband)
	end
	if item.cppvisor and item.cpsvisor then
		ReadCPVisors(player, item.cppvisor, item.cpsvisor)
		player:SetCharacterData("CP08_PVisor", item.cppvisor)
		player:SetCharacterData("CP08_SVisor", item.cpsvisor)
	end
	if item.rank then
		if Schema:PlayerIsCombine(player) then
			local name = player:GetName()
			local finished = string.gsub(name,"(CP%:.*%.).*(%.%d+)","%1"..item.rank.."%2")
			Clockwork.player:SetName(player, finished)
		end
	end
end

function ITEM:OnUse(player, itemEntity)
	if SERVER then
		if cpoutfit.IsSupported(player:GetModel()) then
			processOutfit(self, player)
		else
			if self.changeModel then
				if player:GetGender() == GENDER_MALE then
					player:SetCharacterData("Model", "models/metropolice/c08.mdl", true)
					player:SetModel("models/metropolice/c08.mdl")
				else
					player:SetCharacterData("Model", "models/metropolice/c08_female_2.mdl", true)
					player:SetModel("models/metropolice/c08_female_2.mdl")
				end
				processOutfit(self, player)
			end
		end
	end
end

function ITEM:OnDrop(player, position) return true end
Clockwork.item:Register(ITEM);