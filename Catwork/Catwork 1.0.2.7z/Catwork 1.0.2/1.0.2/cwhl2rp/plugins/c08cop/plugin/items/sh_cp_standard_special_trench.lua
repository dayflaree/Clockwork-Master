local ITEM = Clockwork.item:New("cpoutfit_base")
ITEM.uniqueID = "cp_standard_special_trench"
ITEM.name = "Set of Civil Protection outfit: Standard 'Digital' Trenchcoat"
ITEM.PrintName = "Комплект экипировки ГО: Стандартный цифровой с тренчем"
ITEM.model = "models/props_c17/SuitCase001a.mdl"
ITEM.weight = 5
ITEM.category = "Гражданская Оборона - Комплекты"
ITEM.description = "Стандартная цифровая экипировка Гражданской Обороны с тренчем."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = {
	uniform = "6",
	bodygroups = "0010000000",
	gasmask = "0",
	gasmaskshock = "0",
	glow = "1"
}
ITEM.cparmband = nil
ITEM.cppvisor = "-1_-1_-1"
ITEM.cpsvisor = "1_3_1"
ITEM.rank = nil

ITEM:Register()