local ITEM = Clockwork.item:New("cpoutfit_base")
ITEM.uniqueID = "armband_sec"
ITEM.name = "Armband: 'SeC'"
ITEM.PrintName = "Повязка: 'SeC'"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.1
ITEM.category = "Гражданская Оборона - Повязки"
ITEM.description = "Серая повязка, на которой написано 'c14:SeC'. На ней также изображен зеленый символ City-14."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = nil
ITEM.cparmband = "(255,255,255)_2_(183,48,41,250)_1_(160,188,176,200)_1"
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = "SeC"

ITEM:Register()