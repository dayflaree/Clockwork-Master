--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("CharSetVisor")
COMMAND.tip = "Set a Civil Protection visors"
COMMAND.text = "<string Name> <string Primary Visor color> <string Secondary Visor color>"
COMMAND.flags = bit.bor(CMD_DEFAULT)
COMMAND.arguments = 3

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])

	if target then
		if player:IsAdmin() or Schema:IsPlayerCombineRank(player, { "SeC", "CmD", "MaJ", "CpT" }) then
			if arguments[2] == "" or arguments[3] == "" then
				return
			end

			target:SetCharacterData("CP08_PVisor", arguments[2])
			target:SetCharacterData("CP08_SVisor", arguments[3])
			ReadCPVisors(target, arguments[2], arguments[3])
			Clockwork.player:Notify(player, "You have changed character's Civil Protection visor colors successfull.")
		else
			Clockwork.player:Notify(player, "У вас нет прав.")
		end
	else
		Clockwork.player:Notify(player, L(player, "NotValidCharacter", arguments[1]))
	end
end

COMMAND:Register();