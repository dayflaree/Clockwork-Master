PLUGIN:SetGlobalAlias("cwC08CP")

Clockwork.player:AddCharacterData("CP08_Outfit", NWTYPE_STRING, "0_0000000000_0_0_0", true)
Clockwork.player:AddCharacterData("CP08_Armband", NWTYPE_STRING, "(0,0,0)_0_(0,0,0,0)_0_(0,0,0,0)_0", true)
Clockwork.player:AddCharacterData("CP08_PVisor", NWTYPE_STRING, "0_0_0", true)
Clockwork.player:AddCharacterData("CP08_SVisor", NWTYPE_STRING, "0_0_0", true)
Clockwork.player:AddCharacterData("MdlSkin", NWTYPE_NUMBER, 0, true)

function ReadCPOutfit(ply, str)
	if !IsValid(ply) then return end
	if !cpoutfit.IsSupported(ply:GetModel()) then return end

	local strTable = string.Explode("_", str)

	local uID = tonumber(strTable[1])
	local bodygroups = tostring(strTable[2])
	local gasmaskID = tonumber(strTable[3])
	local gasmaskShockID = tonumber(strTable[4])
	local gasmaskGlow = tonumber(strTable[5])

	if bodygroups then
		for i = 1, 9 do
			local number = string.sub(bodygroups, i, i)
			if number and number != "" then
				ply:SetBodygroup(i, tonumber(number))
			end
		end
	end

	cpoutfit.SetPlayerOutfit(ply, "uniform", uID)
	cpoutfit.SetPlayerOutfit(ply, "gasmask_style", gasmaskID)
	cpoutfit.SetPlayerOutfit(ply, "gasmaskshock_style", gasmaskShockID)
	cpoutfit.SetPlayerOutfit(ply, "visor_style", gasmaskGlow)
end
function ReadCPArmband(ply, str)
	if !IsValid(ply) then return end
	if !cpoutfit.IsSupported(ply:GetModel()) then return end

	local codeTable = string.Explode("_", str)
	if codeTable then
		local bg_color = Color(255,255,255)
		local icon_color = Color(255,255,255)
		local text_color = Color(255,255,255)

		if codeTable[1] then
			local r, g, b = codeTable[1]:match("%((%d+),(%d+),(%d+)%)")
			bg_color = Color(r, g, b)
		end
		if codeTable[3] then
			local r, g, b, a = codeTable[3]:match("%((%d+),(%d+),(%d+),(%d+)%)")
			icon_color = Color(r, g, b, a)
		end
		if codeTable[5] then
			local r, g, b, a = codeTable[5]:match("%((%d+),(%d+),(%d+),(%d+)%)")
			text_color = Color(r, g, b, a)
		end

		local backgroundID = tonumber(codeTable[2])
		local iconID = tonumber(codeTable[4])
		local textID = tonumber(codeTable[6])

		ply:SetArmbandCode(bg_color, backgroundID, icon_color, iconID, text_color, textID)
	end
end
function ReadCPVisors(ply, pvisor, svisor)
	if !IsValid(ply) then return end
	if !cpoutfit.IsSupported(ply:GetModel()) then return end

	if pvisor then
		local pvisor_table = string.Explode("_", pvisor)
		ply:SetPrimaryVisorColor(Vector(tonumber(pvisor_table[1]), tonumber(pvisor_table[2]), tonumber(pvisor_table[3])))
	end
	if svisor then
		local svisor_table = string.Explode("_", svisor)
		ply:SetSecondaryVisorColor(Vector(tonumber(svisor_table[1]), tonumber(svisor_table[2]), tonumber(svisor_table[3])))
	end
end

if SERVER then
	function cwC08CP:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
		local outfit = player:GetCharacterData("CP08_Outfit","0_0000000000_0_0_0")
		local armband = player:GetCharacterData("CP08_Armband","(0,0,0)_0_(0,0,0,0)_0_(0,0,0,0)_0")
		local pvisor = player:GetCharacterData("CP08_PVisor","0_0_0")
		local svisor = player:GetCharacterData("CP08_SVisor","0_0_0")
		local skin_overwrite = player:GetCharacterData("MdlSkin",0)
		local bodygroups = player:GetCharacterData("BodyGroups",{})

		for k, v in pairs(player:GetBodyGroups()) do
			player:SetBodygroup(v.id, 0)
		end
		for k, v in pairs(bodygroups) do
			for z, x in pairs(v) do
				player:SetBodygroup(z, tonumber(x))
			end
		end

		player:SetSubMaterial(nil, nil)

		if cpoutfit.IsSupported(player:GetModel()) then
			ReadCPOutfit(player, outfit)
			ReadCPArmband(player, armband)
			ReadCPVisors(player, pvisor, svisor)
		end

		if skin_overwrite then
			player:SetSkin(skin_overwrite)
		end
	end
	function cwC08CP:PlayerUnragdolled(player, state, ragdollTable)
		local outfit = player:GetCharacterData("CP08_Outfit", "0_0000000000_0_0_0")
		local armband = player:GetCharacterData("CP08_Armband", "(0,0,0)_0_(0,0,0,0)_0_(0,0,0,0)_0")
		local pvisor = player:GetCharacterData("CP08_PVisor", "0_0_0")
		local svisor = player:GetCharacterData("CP08_SVisor", "0_0_0")
		local bodygroups = player:GetCharacterData("BodyGroups",{})

		for k, v in pairs(player:GetBodyGroups()) do
			player:SetBodygroup(v.id, 0)
		end
		for k, v in pairs(bodygroups) do
			for z, x in pairs(v) do
				player:SetBodygroup(z, tonumber(x))
			end
		end

		player:SetSubMaterial(nil, nil)

		if cpoutfit.IsSupported(player:GetModel()) then
			ReadCPOutfit(player, outfit)
			ReadCPArmband(player, armband)
			ReadCPVisors(player, pvisor, svisor)
		end
	end
	function cwC08CP:PlayerAdjustCharacterScreenInfo(player, character, info)
		local outfit = character.data["CP08_Outfit"] or "0_0000000000_0_0_0"
		local armband = character.data["CP08_Armband"] or "(0,0,0)_0_(0,0,0,0)_0_(0,0,0,0)_0"
		local pvisor = character.data["CP08_PVisor"] or "0_0_0"
		local svisor = character.data["CP08_SVisor"] or "0_0_0"
		if cpoutfit.IsSupported(info.model) then
			info.c08outfit = outfit
			info.c08armband = armband
			info.c08pvisor = pvisor
			info.c08svisor = svisor
		end
	end
	function cwC08CP:PlayerCharacterCreated(player, character)
		if character.faction == FACTION_MPF then
			character.data["CP08_Outfit"] = "0_0000000000_0_0_1"
			character.data["CP08_Armband"] = "(100,125,140)_8_(50,255,60,255)_1_(200,225,170,255)_37"
			character.data["CP08_PVisor"] = "-1_-1_-1"
			character.data["CP08_SVisor"] = "0_3_3.5"
		end
	end
end