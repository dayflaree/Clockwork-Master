local PLUGIN = PLUGIN

CW.kernel:IncludePrefixed("sv_hooks.lua")
CW.kernel:IncludePrefixed("sv_plugin.lua");