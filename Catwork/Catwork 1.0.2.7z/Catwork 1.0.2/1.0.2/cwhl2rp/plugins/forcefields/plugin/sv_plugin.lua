local PLUGIN = PLUGIN;

function PLUGIN:LoadForceFields()
	local forcefields = CW.kernel:RestoreSchemaData("plugins/forcefields/"..game.GetMap());

	for k, v in pairs(forcefields) do
		local entity = ents.Create("cw_forcefield");

		entity:SetPos(v.position);
		entity:Spawn();

		if (IsValid(entity)) then
			entity:SetAngles(v.angles);

			local phys = entity:GetPhysicsObject()

			if (IsValid(phys)) then
				phys:EnableMotion(false);
			end;
		end;
	end;
end;

function PLUGIN:SaveForceFields()
	local forcefields = {};

	for k, v in pairs(ents.FindByClass("cw_forcefield")) do
		forcefields[#forcefields + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos(),
		};
	end;

	CW.kernel:SaveSchemaData("plugins/forcefields/"..game.GetMap(), forcefields);
end;