local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitPostEntity()
	self:LoadForceFields();
end;

function PLUGIN:PostSaveData()
	self:SaveForceFields();
end;

function PLUGIN:PlayerCanGoThrough(player)
	if (player:GetFaction() == FACTION_CWU or Schema:PlayerIsCombine(player)) then
		return true
	end

	return false
end

function PLUGIN:PlayerCanGetUp(player)
	local entities = ents.FindInSphere(player:GetPos(), 200);

	for k, v in ipairs(entities) do
		if (v:GetClass() == "cw_forcefield") then
			return false
		end;
	end;
end;