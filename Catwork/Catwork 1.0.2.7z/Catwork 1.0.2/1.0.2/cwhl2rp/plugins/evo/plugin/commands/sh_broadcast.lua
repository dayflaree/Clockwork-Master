--[[
		Created by Polis, July 2014.
		Do not re-distribute as your own.
]]

local COMMAND = Clockwork.command:FindByID("broadcast")

function COMMAND:OnRun(player, arguments)
	if (player:GetFaction() == FACTION_ADMIN) then
		local text = table.concat(arguments, " ")

		if (text == "") then
			Clockwork.player:Notify(player, "Вы не предоставили текст!")

			return
		end

		Schema:SayBroadcast(player, text)
		Schema:AddCombineDisplayLine("!ПЕРЕДАЧА: "..text, Color(212,111, 249, 255))
	else
		Clockwork.player:Notify(player, "Вы не Городской Администратор!")
	end
end

COMMAND:Register();