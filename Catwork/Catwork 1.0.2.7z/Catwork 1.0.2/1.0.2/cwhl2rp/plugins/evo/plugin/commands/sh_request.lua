--[[
		Created by Polis, July 2014.
		Do not re-distribute as your own.
]]

local COMMAND = Clockwork.command:FindByID("request")

-- Called when the command is run by the player.
function COMMAND:OnRun(player, arguments)
	local isCityAdmin = (player:GetFaction() == FACTION_ADMIN)
	local isCombine = Schema:PlayerIsCombine(player)
	local text = table.concat(arguments, " ")
	local cid

	local ciD = player:GetCharacterData("citizenid", 0)
	if ciD == 0 then
		cid = "N/A"
	else
		cid = ciD
	end

	if (text == "") then
		Clockwork.player:Notify(player, L"You did not specify enough text!")

		return
	end

	if (player:HasItemByID("request_device") or isCombine or isCityAdmin) then
		local curTime = CurTime()

		if (!player.nextRequestTime or isCityAdmin or isCombine or curTime >= player.nextRequestTime) then

			player:EmitSound("evo/virgil_2.wav")
			Schema:SayRequest(player, text)

			if (!isCityAdmin and !isCombine) then
				player.nextRequestTime = curTime + 1
			end
		else
			Clockwork.player:Notify(player, "Вы не сможете отправить запрос еще "..math.ceil(player.nextRequestTime - curTime).." секунд!")
		end
	else
		Clockwork.player:Notify(player, "У Вас нет устройства запроса!")
	end
end
