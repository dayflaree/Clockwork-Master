--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

function cwGarbage:GetProgressBarInfo()
	local action, percentage = CW.player:GetAction(CW.Client, true)

	if (!CW.Client:IsRagdolled()) then
		if (action == "farming") then
			return {text = "Вы собираете урожай...", percentage = percentage, flash = percentage < 10}
		end
	end
end