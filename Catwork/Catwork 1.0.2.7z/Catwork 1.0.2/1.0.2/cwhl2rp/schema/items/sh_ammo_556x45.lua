local ITEM = Clockwork.item:New("ammo_base")
	ITEM.name = "Ammo 5.56x45"
	ITEM.PrintName = "Коробка патронов: 5.56х45мм"
	ITEM.cost = 0
	ITEM.classes = {CLASS_EMP, CLASS_EOW}
	ITEM.model = "models/items/boxmrounds.mdl"
	ITEM.weight = 3
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_556x45"
	ITEM.business = true
	ITEM.ammoClass = "5.56x45mm"
	ITEM.ammoAmount = 30
	ITEM.description = "Тяжелый контейнер, наполненный патронами калибра 5.56х45мм."
ITEM:Register();