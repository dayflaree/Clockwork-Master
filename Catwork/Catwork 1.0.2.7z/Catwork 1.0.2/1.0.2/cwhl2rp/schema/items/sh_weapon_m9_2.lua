local ITEM = Clockwork.item:New("weapon_base")
	ITEM.name = "M9 Beretta Suppressor"
	ITEM.PrintName = "М9 Беретта с глушителем"
	ITEM.cost = 0
	ITEM.model = "models/weapons/w_m9_2.mdl"
	ITEM.weight = 1
	ITEM.access = "V"
	ITEM.classes = {CLASS_EOW}
	ITEM.uniqueID = "sxbase_m9_2"
	ITEM.business = false
	ITEM.description = "Старый итальянский пистолет калибра 9х19."
	ITEM.isAttachment = true
	ITEM.loweredOrigin = Vector(3, 0, -4)
	ITEM.loweredAngles = Angle(0, 45, 0)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis"
	ITEM.attachmentOffsetAngles = Angle(-180, 180, 90)
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54)

ITEM:Register();