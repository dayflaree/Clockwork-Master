local ITEM = Clockwork.item:New()
ITEM.name = "Empty Carton"
ITEM.PrintName = "Пустая коробка"
ITEM.uniqueID = "empty_carton"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_milkcarton002a.mdl"
ITEM.weight = 0.25
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая коробка из под молока."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();