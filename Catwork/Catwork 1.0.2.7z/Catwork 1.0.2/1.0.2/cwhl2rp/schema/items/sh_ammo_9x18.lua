--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New("ammo_base")
	ITEM.name = "9x18 Bullets"
	ITEM.PrintName = "Коробка патронов: 9х18мм"
	ITEM.cost = 20
	ITEM.classes = {CLASS_EMP, CLASS_EOW}
	ITEM.model = "models/items/boxsrounds.mdl"
	ITEM.weight = 1
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_9x18"
	ITEM.business = true
	ITEM.ammoClass = "9x18mm"
	ITEM.ammoAmount = 30
	ITEM.description = "Контейнер, в котором находятся патроны калибра 9х18мм."
ITEM:Register();