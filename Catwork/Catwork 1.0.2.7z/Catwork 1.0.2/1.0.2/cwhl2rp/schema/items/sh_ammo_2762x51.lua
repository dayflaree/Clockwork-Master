local ITEM = Clockwork.item:New("ammo_base")
	ITEM.name = "Ящик патронов: 7.62x51mm Box"
	ITEM.PrintName = " 7.62х51мм"
	ITEM.cost = 0
	ITEM.classes = {CLASS_EMP, CLASS_EOW}
	ITEM.model = "models/items/largeboxbrounds.mdl"
	ITEM.weight = 4
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_2762x51"
	ITEM.business = true
	ITEM.ammoClass = "7.62x51mm"
	ITEM.ammoAmount = 100
	ITEM.description = "Небольшой ящик с двумя пулеметными лентами внутри калибра 7.62x51."
ITEM:Register();