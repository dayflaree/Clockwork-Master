--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PKModeOff")
COMMAND.tip = "Turn PK mode off and cancel the timer."
COMMAND.access = "o"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	netvars.SetNetVar("PKMode", 0)
	CW.kernel:DestroyTimer("pk_mode")

	CW.player:NotifyAll(player:Name().." has turned off perma-kill mode, you are safe now.")
end

COMMAND:Register();