--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Dispatch")
COMMAND.tip = "Dispatch a message to all characters."
COMMAND.text = "<string Text>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		if (Schema:IsPlayerCombineRank(player, {"SCN", "OfC", "EpU", "DvL", "CmD", "SeC"}) or player:GetFaction() == FACTION_OTA) then
			local text = table.concat(arguments, " ")

			if (text == "") then
				CW.player:Notify(player, "You did not specify enough text!")

				return
			end

			Schema:SayDispatch(player, text)
		else
			CW.player:Notify(player, "You are not ranked high enough to use this command!")
		end
	else
		CW.player:Notify(player, "You are not the Combine!")
	end
end

COMMAND:Register();