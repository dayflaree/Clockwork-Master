--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("DispenserAdd")
COMMAND.tip = "Add a ration dispenser at your target position."
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "s"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor()
	local entity = ents.Create("cw_rationdispenser")

	entity:SetPos(trace.HitPos)
	entity:Spawn()

	if (IsValid(entity)) then
		entity:SetAngles(Angle(0, player:EyeAngles().yaw + 180, 0))

		CW.player:Notify(player, "You have added a ration dispenser.")
	end
end

COMMAND:Register();