--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local FACTION = CW.faction:New("#Faction_MPF")

FACTION.isCombineFaction = true
FACTION.whitelist = true
FACTION.material = "halfliferp/factions/mpf"
FACTION.models = {
male = {
	"models/metropolice/c08.mdl"
},
female = {
	"models/metropolice/c08_female_2.mdl"
}}

-- Called when a player's name should be assigned for the faction.
function FACTION:GetName(player, character)
	return "CP.C17.RCT:"..CW.kernel:ZeroNumberToDigits(math.random(1, 999), 3)
end

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)	
	if (faction.name == FACTION_OTA) then
		if (name) then
			CW.player:SetName(player, string.gsub(player:QueryCharacter("name"), ".+(%d%d%d%d%d)", " С17.CP:RCT.UNION-%1"), true)
		else
			return false, "You need to specify a name as the third argument!"
		end
	else
		CW.player:SetName(player, self:GetName(player, player:GetCharacter()))
	end

	if (player:QueryCharacter("gender") == GENDER_MALE) then
		player:SetCharacterData("model", self.models.male[1], true)
	else
		player:SetCharacterData("model", self.models.female[1], true)
	end
end

FACTION_MPF = FACTION:Register();