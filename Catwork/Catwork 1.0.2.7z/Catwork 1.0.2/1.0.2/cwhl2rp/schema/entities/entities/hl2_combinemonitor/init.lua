AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")
function ENT:Initialize()
	self:SetModel(self.Model)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetHealth(1)
	self:SetSolid(SOLID_VPHYSICS)

	self:SetNetVar("monitor_activated", false)

	self.timeGen = CurTime()

	local physicsObject = self:GetPhysicsObject()
	if (IsValid(physicsObject)) then
		physicsObject:Sleep()
		physicsObject:EnableMotion(false)
	end
end

function ENT:SpawnFunction(client, trace)
	local entity = ents.Create(self.ClassName)
	entity:SetPos(trace.HitPos)
	entity:SetAngles(trace.HitNormal:Angle())
	entity:Spawn()
	entity:Activate()

	return entity
end

function ENT:_turnOff()
	self:SetNetVar("monitor_activated", false)
	self:EmitSound("buttons/blip1.wav")
	--MsgC("turn off\n")
end

function ENT:_turnOn(pl)	
	if pl:GetCharacterData("cit_cid", 0) then
		self:SetNetVar("monitor_activated", true)
		self:EmitSound("buttons/blip1.wav")
		self.timeGen = CurTime() + 8 -- 8
		--MsgC("turn on\n")
	end
end

function ENT:Think()
	local dt = self:GetNetVar("users", {})
	if self:GetNetVar("monitor_activated") then
		for _, i in ipairs(dt) do
			if i.status == "ANTI-CITIZEN" then
				if !nextmessage || CurTime() >= nextmessage then
					local getall = player.GetAll()
					for _, combine in ipairs(getall) do
						if combine:Alive() && combine:getChar() then
							if combine:isCombine() then
								combine:addDisplay("Всем постам. Нарушитель #"..i.cid.." замечен по координатам: "..math.floor(self:GetPos()[1])..", "..math.floor(self:GetPos()[2])..", "..math.floor(self:GetPos()[3])..".", Color(255, 0, 0))
							end
						end
					end
					nextmessage = CurTime() + 10
				end
			end
		end

		if self.timeGen < CurTime() then
			self:_turnOff()
			self:SetNetVar("users", {})
		end
	else
		self.activator = nil
	end
	self:NextThink(CurTime() + 1)
end

function ENT:_canTurnOn(pl)
	return (!self:GetNetVar("monitor_activated") && !pl:IsCombine())
end

-- (c) AleXXX_007
function ENT:_dataList(p)
	local data = self:GetNetVar("users", {})

	local civ_citizenid = p:GetCharacterData("citizenid")
	local civ_lid = p:GetCharacterData("civ_lid")
	local civ_reputation = p:GetCharacterData("civ_reputation")
	local civ_blackmarks = p:GetCharacterData("civ_blackmarks")
	local civ_verdict = p:GetCharacterData("civ_status")
	local civ_wp = p:GetCharacterData("civ_wp")
	local civ_faction = p:GetCharacterData("civ_faction")
	local wplevel = 0
	if civ_wp >= 220 then
		wplevel = 10
	elseif civ_wp >= 170 then
		wplevel = 9
	elseif civ_wp >= 130 then
		wplevel = 8
	elseif civ_wp >= 90 then
		wplevel = 7
	elseif civ_wp >= 60 then
		wplevel = 6
	elseif civ_wp >= 35 then
		wplevel = 5
	elseif civ_wp >= 20 then
		wplevel = 4
	elseif civ_wp >= 10 then
		wplevel = 3
	elseif civ_wp >= 5 then
		wplevel = 2
	elseif civ_wp >= 0 then
		wplevel = 1
	end

	data = {
		name = p:Name(),
		cid = civ_citizenid,
		lp = civ_reputation,
		pp = civ_blackmarks,
		status = civ_verdict,
		work = civ_wp,
		worklvl = wplevel,
		lid = civ_lid,
		faction = civ_faction
	}

	self:SetNetVar("users", data)
end

function ENT:Use(pl)
	if self:_canTurnOn(pl) then
		self.activator = pl
		self:_turnOn(pl)
		self:_dataList(pl)

		return
	end
end