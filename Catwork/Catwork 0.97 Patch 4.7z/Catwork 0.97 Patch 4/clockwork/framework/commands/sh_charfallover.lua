--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("CharFallOver");
COMMAND.tip = "Make your character fall to the floor.";
COMMAND.text = "[number Seconds]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Fallover"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local curTime = CurTime();
	
	if (!player.cwNextFallTime or curTime >= player.cwNextFallTime) then
		player.cwNextFallTime = curTime + 5;
		
		if (!player:InVehicle() and !CW.player:IsNoClipping(player)) then
			local seconds = tonumber(arguments[1]);
			
			if (seconds) then
				seconds = math.Clamp(seconds, 2, 30);
			elseif (seconds == 0) then
				seconds = nil;
			end;
			
			if (!player:IsRagdolled()) then
				CW.player:SetRagdollState(player, RAGDOLL_FALLENOVER, seconds);
				
				player:SetSharedVar("FallenOver", true);
			end;
		else
			CW.player:Notify(player, "You cannot do this action at the moment!");
		end;
	end;
end;

COMMAND:Register();