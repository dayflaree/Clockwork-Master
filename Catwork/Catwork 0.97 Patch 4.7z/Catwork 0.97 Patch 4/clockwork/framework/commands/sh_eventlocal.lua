--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("EventLocal");
COMMAND.tip = "Send an event to characters around you.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"LocalEvent", "EL"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	chatbox.AddText(nil, "* "..table.concat(arguments, " "), {filter = "player_events", textColor = Color("#FFAB00"), icon = false, position = player:GetPos()});
end;

COMMAND:Register();