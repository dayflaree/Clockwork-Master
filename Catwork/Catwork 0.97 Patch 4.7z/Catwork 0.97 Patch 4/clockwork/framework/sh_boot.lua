--[[ 
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

if (!CW) then
	CW = GM;
else
	CurrentGM = CW;
	table.Merge(CurrentGM, GM);
	CW = nil;
	
	CW = GM;
	table.Merge(CW, CurrentGM);
	CurrentGM = nil;
end;

Clockwork = CW or {};

-- Name conflict fixes.
_player, _team, _file = player, team, file;
cwPlayer, cwTeam, cwFile = player, team, file;

CW.ClockworkFolder = CW.ClockworkFolder or GM.Folder;
CW.SchemaFolder = CW.SchemaFolder or GM.Folder;
CW.KernelVersion = "0.97";
CW.KernelBuild = "patch4"
CW.DeveloperVersion = true;
CW.Website = "http://cloudsixteen.com";
CW.Author = "Cloud Sixteen";
CW.Email = "kurozael@gmail.com";
CW.Name = "Clockwork";

--[[
	Since this Clockwork lacks CloudAuthX, feel free
	to edit this function!
	But we'd recommend simply renaming the schema though.
--]]
function CW:GetGameDescription()
	local schemaName = self.kernel:GetSchemaGamemodeName();
	return "CW: "..schemaName;
end;

AddCSLuaFile("cl_kernel.lua");
AddCSLuaFile("cl_theme.lua");
AddCSLuaFile("sh_kernel.lua");
AddCSLuaFile("sh_fixes.lua");
AddCSLuaFile("sh_enum.lua");
AddCSLuaFile("sh_boot.lua");
include("sh_enum.lua");
include("sh_fixes.lua");
include("sh_kernel.lua");

if (CLIENT) then
	if (CW_SCRIPT_SHARED) then
		CW_SCRIPT_SHARED = CW.kernel:Deserialize(CW_SCRIPT_SHARED);
	else
		CW_SCRIPT_SHARED = {};
	end;
	
	include("cl_clientcode.lua");
else
	AddCSLuaFile("cl_clientcode.lua");
end;

if (CW_SCRIPT_SHARED.schemaFolder) then
	CW.SchemaFolder = CW_SCRIPT_SHARED.schemaFolder;
end;

if (!game.GetWorld) then
	game.GetWorld = function() return Entity(0); end;
end;

if (SERVER) then 
	include("sv_ota.lua");
end;

CW.kernel:IncludeDirectory("libraries/server", true);
CW.kernel:IncludeDirectory("libraries/client", true);
CW.kernel:IncludeDirectory("libraries/", true);
CW.kernel:IncludePrefixed("cl_theme.lua");
CW.kernel:IncludeDirectory("directory/", true);
CW.kernel:IncludeDirectory("config/", true);
CW.kernel:IncludePlugins("plugins/", true);
CW.kernel:IncludeDirectory("system/", true);
CW.kernel:IncludeDirectory("items/", true);
CW.kernel:IncludeDirectory("derma/", true);

--[[ The following code is loaded over-the-Cloud. --]]
if (SERVER and CW.LoadPreSchemaExternals) then
	CW:LoadPreSchemaExternals();
end;

local startTime = os.clock();

print("[Clockwork] Loading schema...");

--[[ Load the schema and let any plugins know about it. --]]
CW.kernel:IncludeSchema();
plugin.Call("ClockworkSchemaLoaded");

print("[Clockwork] Schema took "..math.Round(os.clock() - startTime, 3).." second(s) to load!");

if (SERVER) then
	MsgC(Color(0, 255, 100, 255), "[Clockwork] Schema \""..Schema:GetName().."\" ["..CW.kernel:GetSchemaGamemodeVersion().."] by "..Schema:GetAuthor().." loaded!\n");
end;

--[[ The following code is loaded over-the-Cloud. --]]
if (SERVER and CW.LoadPostSchemaExternals) then
	CW:LoadPostSchemaExternals();
end;	

if (CLIENT) then
	plugin.Call("ClockworkLoadShared", CW_SCRIPT_SHARED);
end;

CW.kernel:IncludeDirectory("commands/", true);

CW.player:AddCharacterData("PhysDesc", NWTYPE_STRING, "");
CW.player:AddPlayerData("Language", NWTYPE_STRING, "English", true);

plugin.IncludeEffects("Clockwork/framework");
plugin.IncludeWeapons("Clockwork/framework");
plugin.IncludeEntities("Clockwork/framework");

if (SERVER) then
	plugin.Call("ClockworkSaveShared", CW_SCRIPT_SHARED);

	local scriptShared = "CW_SCRIPT_SHARED = [["..CW.kernel:Serialize(CW_SCRIPT_SHARED).."]];";
	fileio.Write("lua/CW.lua", scriptShared);
	
	AddCSLuaFile("CW.lua");
end;