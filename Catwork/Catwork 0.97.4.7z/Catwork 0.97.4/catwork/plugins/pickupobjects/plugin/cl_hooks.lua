--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when the top text is needed.
function cwPickupObjects:GetTopText(topText)
	local beingDragged = CW.Client:GetSharedVar("IsDragged") or false;
	
	if (CW.Client:IsRagdolled() and beingDragged) then
		topText:Add("BEING_DRAGGED", "You are being dragged");
	end;
end;

-- Called when the local player attempts to get up.
function cwPickupObjects:PlayerCanGetUp()
	local beingDragged = CW.Client:GetSharedVar("IsDragged") or false;
	
	if (beingDragged) then
		return false;
	end;
end;

timer.Simple(1, function()
	local SWEP = weapons.GetStored("cw_hands");

	if (SWEP) then
		SWEP.Instructions = "Reload: Drop\n"..SWEP.Instructions;
		
		SWEP.Instructions = CW.kernel:Replace(SWEP.Instructions, "Knock.", "Knock/Pickup.");
		SWEP.Instructions = CW.kernel:Replace(SWEP.Instructions, "Punch.", "Punch/Throw.");
	end;
end);