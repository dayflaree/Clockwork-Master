--[[
	© 2016 TeslaCloud Studios LLC.
	Please do not re-use.
--]]

library.New("thunder", _G);
thunder.groups = thunder.groups or {};
thunder.permissions = thunder.permissions or {};
thunder.players = thunder.players or {};

local CLASS_TABLE = {__index = CLASS_TABLE};

-- A function to create a new group object.
function thunder.NewGroup(name)
	local obj = NewMetaTable(CLASS_TABLE)
	obj.name = name or "Unknown Usergroup";

	return obj;
end;

-- A function to register group object.
function CLASS_TABLE:Register()
	return thunder.RegisterGroup(self.name, self);
end;

-- A function to register group object.
function thunder.RegisterGroup(name, data)
	if (!name or !data) then return; end;

	local id = data.uniqueID;

	if (!id) then
		id = string.lower(string.Replace(name, " ", ""));
	end;

	thunder.groups[id] = data;
	thunder.groups[id].active = data.active or true;

	CW.kernel:Debug("Registered User Group: "..id)
end;

local PERM_CLASS_TABLE = {__index = PERM_CLASS_TABLE};

-- A function to create a new permission object.
function thunder.NewPermission(name)
	local obj = NewMetaTable(PERM_CLASS_TABLE)
	obj.name = name or "Unknown Permission";
	
	return obj;
end;

-- A function to register permission object.
function PERM_CLASS_TABLE:Register()
	return thunder.RegisterPermission(self.name, self);
end;

-- A function to register permission object.
function thunder.RegisterPermission(name, data)
	if (!name or !data) then return; end;

	local id = data.uniqueID or false;

	if (!id) then
		id = string.lower(string.Replace(name, " ", "_"));
	end;

	thunder.permissions[id] = data;

	CW.kernel:Spam("Registered Permission: "..id)
end;

function thunder.PermissionExists(id)
	if (thunder.permissions[id]) then
		return true;
	end;

	return false;
end;

function thunder.GroupExists(id)
	if (thunder.groups[id]) then
		return true;
	end;

	return false;
end;