--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local PANEL = {};

function PANEL:SetupLabel(menuItem, panel)
	self:SetFont(CW.option:GetFont("menu_text_tiny"));
	
	if (!menuItem.text:StartWith("#")) then
		menuItem.text = "#"..menuItem.text;
	end;
	
	local text = CW.lang:GetString(GetConVar("gmod_language"):GetString(), menuItem.text);
	
	self:SetText(text:utf8upper());
	
	if (menuItem.iconData.path != "") then
		self:SetIcon(menuItem.iconData.path);
	else
		self:SetIcon("bars");
	end;
	
	local offsetX = 4;
	
	if (menuItem.iconData.size) then
		offsetX = menuItem.iconData.size;
	end;
	
	self:SetIconSize(24, 24, offsetX, 4)
	self:SetTextOffset(34, 0)
	
	self:FadeIn(0.5);
	
	self:SetTooltip(menuItem.tip);
	
	self:SetCallback(function(button)
		if (CW.menu:GetActivePanel() != panel) then
			CW.menu:GetPanel():OpenPanel(panel);
		end;
	end);
	
	self:SizeToContents();
	self:SetMouseInputEnabled(true);
	
	self.ContentPanel = panel;
	self:UpdatePositioning();
end;

-- A function to update the positioning of child items.
function PANEL:UpdatePositioning()
	self:SetSize(200, 32);
end;

vgui.Register("CW.menuButton", PANEL, "cwFAButton");