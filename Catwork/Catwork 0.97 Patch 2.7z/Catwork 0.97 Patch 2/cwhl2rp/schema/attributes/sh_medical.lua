--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "Medical";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "med";
	ATTRIBUTE.description = "Affects your overall medical skills, e.g: health gained from vials and kits.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_MEDICAL = CW.attribute:Register(ATTRIBUTE);