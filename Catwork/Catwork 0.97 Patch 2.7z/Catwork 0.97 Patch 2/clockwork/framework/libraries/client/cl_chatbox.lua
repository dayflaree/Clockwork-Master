--[[ 
	© 2016 TeslaCloud Studios LLC.
	For internal use only.
--]]

--[[ We need the datastream library to add the hooks! --]]
if (!netstream) then
	include("clockwork/framework/libraries/sh_netstream.lua");
end;

if (!CW.fonts) then
	include("clockwork/framework/libraries/client/cl_fonts.lua");
end;

if (!cdraw) then
	include("clockwork/framework/libraries/client/cl_clouddraw.lua");
end;

CW.fonts:Add("cwChatBoxFont", {
	font		= "Roboto",
	size		= 17,
	weight		= 500,
	extended 	= true,
	shadow 		= true
});

CW.fonts:Add("cwChatBoxFontBold", {
	font		= "Roboto",
	size		= 17,
	weight		= 1000,
	extended 	= true,
	shadow 		= true
});

CW.fonts:Add("cwChatBoxSyntax", {
	font		= "Roboto",
	size		= 20,
	weight		= 500,
	extended 	= true,
	shahow		= true
});

library.New("chatbox", _G);
chatbox.history 	= chatbox.history or {}; -- Entire chat history. Last X meesages, configurable.
chatbox.display		= chatbox.display or {}; -- Pre-parsed lines that are currently being drawn.
chatbox.filters 	= chatbox.filters or {}; -- Table that stores filter data.
chatbox.types 		= chatbox.types or {}; -- Table that stores message types data.
chatbox.emotes 		= chatbox.emotes or {} -- Table that stores emotes data.
chatbox.codes 		= chatbox.codes or {}; -- Table that stores BB-Codes data.

chatbox.oldAddText 	= chatbox.oldAddText or chat.AddText;

-- A function to add text to the chat box.
function chat.AddText(...)
	chatbox.AddText(...);
end;

function chatbox.GetLineCount()
	local lines = 0;
	
	for k, v in ipairs(chatbox.history) do
		lines = lines + (v.lineCount or 1);
	end;
	
	return lines;
end;

--[[
	Sizes and Configuration
--]]
chatbox.width = chatbox.width or 600;
chatbox.height = chatbox.height or 410;
chatbox.x = chatbox.x or 4;
chatbox.y = ScrH() - chatbox.height - 36;
chatbox.maxLength = chatbox.maxLength or 512;
chatbox.curAlpha = chatbox.curAlpha or 255;

--[[
	Filters and Types
--]]

function chatbox.AddFilter(id, callback)
	if (!id or id == "") then return; end;
	
	chatbox.filters[id] = callback;
end;

function chatbox.AddType(id, callback)
	if (!id or id == "") then return; end;
	
	chatbox.types[id] = callback;
end;

function chatbox.GetFilter(id)
	if (!id or id == "") then return; end;
	
	if (chatbox.filters[id]) then
		return chatbox.filters[id];
	else
		return chatbox.filters["default"];
	end;
end;

function chatbox.GetType(id)
	if (!id or id == "") then return; end;
	
	if (chatbox.types[id]) then
		return chatbox.types[id];
	end;
end;

--[[
	Message table prototype:
	{
		text = string, -- text of the message
		playerName = string, -- name of the player who sent this message
		sender = plyObject, -- player object
		filter = string, -- filter id
		type = string, -- message type id
		icon = string, -- path to icon material. "" = no icon
		time = uint, -- time when the message has been added
		drawAvatar = bool, -- draw avatar or not
		drawTime = bool, -- draw time or not
		drawModel = bool, -- draw player model panel
		isPlayerMessage = bool, -- was this message sent by a valid player?
		sizeOverride = int, -- font size override
		rich = bool, -- force the bbcode parser on/off
		translate = bool -- whether or not to translate the message using #phrases system
	}
	
	display table prototype:
chatbox.display[1] = {
	[1] = { 0, LocalPlayer(), Color(255, 255, 255), "[SendTime:"..os.time().."]", "[icon:icon16/shield.png]", Color(255, 0, 0), "[SenderAvatar]", "[OOC] ", Color(255, 255, 255), "Mr. Meow: ", "Test message Test Message"},
	[2] = { 20, Color(255, 255, 255), "It is hardcoded btw. Render testing." }
}
--]]

do
	chatbox.AddFilter("default", function(messageData)
		messageData.drawAvatar = messageData.drawAvatar or false;
		messageData.drawTime = messageData.drawTime or true;
		messageData.drawModel = messageData.drawModel or false;
		messageData.isPlayerMessage = messageData.isPlayerMessage or false;
		messageData.rich = messageData.rich or true;
		messageData.translate = messageData.translate or true;
		messageData.type = messageData.type or "default";
	end);
	
	chatbox.AddFilter("system", function(messageData)
		-- system messages define this table themselves
		messageData.type = messageData.type or "system";
	end);
	
	chatbox.AddFilter("ooc", function(messageData)
		messageData.drawAvatar = true;
		messageData.drawTime = true;
		messageData.drawModel = false;
		messageData.isPlayerMessage = true;
		messageData.icon = CW.player:GetChatIcon(messageData.sender)
		messageData.rich = true;
		messageData.translate = false;
		messageData.type = "ooc";
	end);
	
	chatbox.AddFilter("admin", function(messageData)
		messageData.drawAvatar = true;
		messageData.drawTime = true;
		messageData.drawModel = false;
		messageData.isPlayerMessage = true;
		messageData.icon = false;
		messageData.rich = true;
		messageData.translate = false;
		messageData.type = "admin";
	end);
	
	chatbox.AddFilter("ic", function(messageData)
		messageData.drawAvatar = false;
		messageData.drawTime = true;
		messageData.drawModel = true;
		messageData.isPlayerMessage = true;
		messageData.icon = "";
		messageData.rich = false;
		messageData.translate = false;
		messageData.type = "ic";
	end);
	
	chatbox.AddFilter("looc", function(messageData)
		messageData.drawAvatar = false;
		messageData.drawTime = true;
		messageData.drawModel = false;
		messageData.isPlayerMessage = true;
		messageData.icon = CW.player:GetChatIcon(messageData.sender)
		messageData.rich = true;
		messageData.translate = false;
		messageData.type = "looc";
	end);
	
	chatbox.AddFilter("player_events", function(messageData)
		messageData.drawAvatar = false;
		messageData.drawTime = messageData.drawTime or true;
		messageData.drawModel = false;
		messageData.isPlayerMessage = false;
		
		if (messageData.icon == nil) then
			messageData.icon = "icon16/lightning.png";
		end;
		
		messageData.rich = true;
		messageData.translate = messageData.translate or true;
		messageData.type = "player_events";
	end);
end;

do
	chatbox.AddType("default", function(messageData)
		messageData.textColor = messageData.textColor or Color(255, 255, 255);
	end);
	
	chatbox.AddType("system", function(messageData)
		messageData.textColor = messageData.textColor or Color(255, 255, 255);
	end);
	
	chatbox.AddType("ooc", function(messageData)
		messageData.textColor = Color(255, 255, 255);
		messageData.prefix = "[OOC] ";
		messageData.prefixColor = Color(255, 20, 20);
	end);
	
	chatbox.AddType("admin", function(messageData)
		messageData.textColor = messageData.textColor or Color("#F0AAAA");
		messageData.prefix = messageData.prefix or "* [Admin Chat] ";
		messageData.prefixColor = Color(255, 20, 20);
	end);
	
	chatbox.AddType("pm", function(messageData)
		messageData.prefix = "[PM] ";
		messageData.prefixColor = Color("#65DBAC");
	end);
	
	chatbox.AddType("ic", function(messageData)
		messageData.textColor = messageData.textColor or Color(255, 255, 200);
	end);
	
	chatbox.AddType("player_events", function(messageData)
		messageData.textColor = messageData.textColor or Color("#EE4343");
		messageData.prefix = messageData.prefix or nil;
		messageData.prefixColor = messageData.prefixColor or Color(255, 20, 20);
	end);
	
	chatbox.AddType("looc", function(messageData)
		messageData.textColor = Color(255, 255, 255);
		messageData.prefix = "[LOOC] ";
		messageData.prefixColor = Color(255, 20, 20);
	end);
end;

--[[
	Emotes and BB-Codes
--]]

function chatbox.AddBBCode(id, callback, requireRich)
	if (!id or id == "") then return; end;
	
	chatbox.codes[id] = chatbox.codes[id] or {};
	chatbox.codes[id].Callback = callback;
	chatbox.codes[id].requireRich = requireRich or true;
end;

function chatbox.GetBBCode(id)
	if (chatbox.codes[id]) then
		return chatbox.codes[id].Callback;
	end;
end;

chatbox.LastBBCode = nil

function chatbox.ParseBBCodes(line, rich)
	if (chatbox.LastBBCode) then
		table.insert(line, 3, chatbox.LastBBCode);
	end;
	
	for k, v in ipairs(line) do
		if (typeof(v) == "string") then
			local whole = v;
			local hits = string.FindAll(v, "%b[]");
			local rm = false;
			local nextInsert = 0;
			local prevOffset = 0;
			
			if (#hits > 0) then
				for i, hit in ipairs(hits) do
					local text = hit[1];
					local wS, wE = hit[2], hit[3];
					local eq = text:find("=");
					local code = "";
					local eqWhat = "";
					
					wS = wS - prevOffset;
					wE = wE - prevOffset;
					
					if (eq) then
						code = text:sub(2, eq - 1);
						eqWhat = text:sub(eq + 1, text:len() - 1);
					else
						code = text:sub(2, text:len() - 1);
					end;
					
					if (chatbox.codes[code]) then
						if (!chatbox.codes[code].requireRich or rich) then
							if (!rm) then
								table.remove(line, k);
								nextInsert = k;
								rm = true;
							end;
							
							local result = chatbox.GetBBCode(code)(eqWhat);
							
							chatbox.LastBBCode = result;
							
							if (!whole:StartWith("[")) then
								table.insert(line, nextInsert, whole:sub(1, wS - 1));
								nextInsert = nextInsert + 1
							end;
							
							whole = whole:sub(wE + 1, whole:len());
							
							table.insert(line, nextInsert, result);
							nextInsert = nextInsert + 1;
							
							if (i == #hits) then
								table.insert(line, nextInsert, whole);
								nextInsert = nextInsert + 1;
								break;
							end;
						end;
					end;
					
					prevOffset = wE;
				end;
			end;
		end;
	end;
end;

local colors = {};
colors["red"] = Color(255, 20, 20);
colors["green"] = Color(20, 255, 20);
colors["blue"] = Color(20, 20, 255);
colors["darkRed"] = Color(150, 0, 0);
colors["darkBreen"] = Color(0, 150, 0);
colors["darkBlue"] = Color(0, 0, 150);
colors["lightRed"] = Color(255, 125, 125);
colors["lightBreen"] = Color(125, 255, 125);
colors["lightBlue"] = Color(125, 125, 255);

do
	chatbox.AddBBCode("color", function(text)
		local exploded = string.Explode(",", text);
		
		for k, v in ipairs(exploded) do
			exploded[k] = v:Replace(" ", "");
		end;
		
		if (!exploded[2]) then
			local text = exploded[1];
			
			if (text:StartWith("#")) then
				return Color(text);
			else
				return (colors[text] or Color(255, 255, 255));
			end;
		else
			return Color((tonumber(exploded[1]) or 255), (tonumber(exploded[2]) or 255), (tonumber(exploded[3]) or 255), (tonumber(exploded[4]) or 255));
		end;
	end);
	
	chatbox.AddBBCode("/color", function(text)
		return Color(255, 255, 255);
	end);
end;

--[[
	Text parser and renderer
--]]

function chatbox.WrapText(text, maxWidth, initWidth)
	local wrapped = {};
	local exploded = string.Explode(" ", text);
	local curWidth = initWidth or 0;
	local curText = "";
	local spaceWidth = util.GetTextSize("cwChatBoxFont", " ");
	local dashWidth = util.GetTextSize("cwChatBoxFont", "-");
	
	for k, v in ipairs(exploded) do
		local val = string.gsub(v, "%b[]", "");
		local w, h = util.GetTextSize("cwChatBoxFont", val);
		
		-- if word's width is less than the remaining width
		if ((w + spaceWidth) < (maxWidth - curWidth)) then
			curText = curText..v.." ";
			curWidth = curWidth + w + spaceWidth;
		-- if it's exactly the width that's left
		elseif ((w + spaceWidth) == (maxWidth - curWidth) or w == (maxWidth - curWidth)) then
			curText = curText..v;
			table.insert(wrapped, curText);
			curText = "";
			curWidth = 0;
		-- if it's more
		else
			-- if the word doesn't fit in a single line
			if (w > maxWidth) then
				local characters = string.Explode("", v);
				local curWord = "";
				local wordWide = 0;
				
				for k2, v2 in ipairs(characters) do
					local w, h = util.GetTextSize("cwChatBoxFont", v2);
					
					-- if we don't have enough characters to fill in the entire line
					if ((wordWide + w + dashWidth) < (maxWidth - curWidth)) then
						curWord = curWord..v2;
						wordWide = wordWide + w;
					-- if we do
					else
						curWord = curWord..v2.."-";
						curText = curText..curWord;
						table.insert(wrapped, curText);
						wordWide = 0;
						curWidth = 0;
						curText = "";
						curWord = "";
					end;
				end;
				
				if (curWord != "") then
					curText = curWord.." ";
				end;
			-- if it does
			else
				table.insert(wrapped, curText);
				curText = v.." ";
				curWidth = w + spaceWidth;
			end;
		end;
	end;
	
	-- insert the leftover text.
	if (curText != "") then
		table.insert(wrapped, curText);
	end;
	
	return wrapped;
end;

g_DisplayY = g_DisplayY or 0;

function chatbox.ParseText(messageData)
	local parsed = {};
	local msgWidth = 0;
	
	messageData.filter = messageData.filter or "ooc";
	
	chatbox.GetFilter(messageData.filter)(messageData);
	chatbox.GetType(messageData.type)(messageData);
	
	parsed[1] = parsed[1] or {};
	table.insert(parsed[1], g_DisplayY);
	
	if (messageData.isPlayerMessage and IsValid(messageData.sender)) then
		table.insert(parsed[1], messageData.sender);
	end;
	
	if (messageData.drawTime) then
		table.insert(parsed[1], Color(255, 255, 255));
		table.insert(parsed[1], "[SendTime:"..messageData.time.."]");
		table.insert(parsed[1], " - ");
		msgWidth = msgWidth + 50;
	end;
	
	if (messageData.icon and messageData.icon != "") then
		table.insert(parsed[1], "[icon:"..messageData.icon.."]");
		msgWidth = msgWidth + 20;
	end;
	
	if (messageData.drawAvatar and IsValid(messageData.sender)) then
		if (!file.Exists("cwavatars/"..messageData.sender:SteamID64()..".jpg", "DATA")) then
			if (!file.Exists("cwavatars", "DATA")) then
				file.CreateDir("cwavatars");
			end;
			
			http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=76415A95E2F81DDA1D7CD2378D16C11D&steamids="..messageData.sender:SteamID64(), function(body)
				local response = util.JSONToTable(body);
				local avatarURL = response["response"]["players"][1].avatar;
				
				http.Fetch(avatarURL, function(avatarImage)
					file.Write("cwavatars/"..messageData.sender:SteamID64()..".jpg", avatarImage);
					
					if (CW.kernel.CachedMaterial[messageData.sender:SteamID64()..".jpg"]) then
						CW.kernel.CachedMaterial[messageData.sender:SteamID64()..".jpg"] = nil;
					end;
				end);
			end);
		end;
		
		table.insert(parsed[1], "[SenderAvatar]");
		msgWidth = msgWidth + 20;
	end;
	
	if (messageData.prefix) then
		table.insert(parsed[1], messageData.prefixColor);
		table.insert(parsed[1], messageData.prefix);
		
		local wide = util.GetTextSize("cwChatBoxFont", messageData.prefix);
		msgWidth = msgWidth + wide;
	end;
	
	if (messageData.isPlayerMessage) then
		if (IsValid(messageData.sender)) then
			messageData.playerTeam = messageData.sender:Team();
			messageData.playerName = messageData.sender:Name();
		end;
		
		if (messageData.filter != "ic" and messageData.playerTeam) then
			table.insert(parsed[1], _team.GetColor(messageData.playerTeam));
		else
			table.insert(parsed[1], messageData.textColor);
		end;
		
		table.insert(parsed[1], messageData.playerName..(messageData.suffix or ": "));
		
		local wide = util.GetTextSize("cwChatBoxFont", messageData.playerName..(messageData.suffix or ": "));
		msgWidth = msgWidth + wide;
	end;
	
	if (messageData.text) then
		local wrapped = chatbox.WrapText(messageData.text, chatbox.width - 8, msgWidth);
		
		for k, v in ipairs(wrapped) do
			parsed[k] = parsed[k] or {};
			
			if (k > 1) then
				table.insert(parsed[k], g_DisplayY)
			end;
			
			table.insert(parsed[k], messageData.textColor);
			table.insert(parsed[k], v);
		end;
	end;
	
	for i = 1, #parsed do
		chatbox.ParseBBCodes(parsed[i], messageData.rich);
	end;
	
	chatbox.LastBBCode = nil;
	
	return parsed;
end;

--[[
	Panels
--]]

local PANEL = {};
PANEL.isOpen = false;
PANEL.scrollOffset = 0;

function PANEL:Init()
	self:SetSize(chatbox.width, chatbox.height);
	self:SetPos(chatbox.x, chatbox.y);
	
	self.scrollBar = vgui.Create("Panel", self);
	self.scrollBar:SetMouseInputEnabled(true);
	
	self.scrollBar.Think = function(sb)
		sb:SetSize(chatbox.width, chatbox.height);
		sb:SetPos(0, 0);
	end;
	
	self.scrollBar.OnMouseWheeled = function(sb, delta)
		-- prettiest code contest 2k16 lmao
		self.scrollOffset = math.Clamp(self.scrollOffset + delta, 0, math.Clamp(chatbox.GetLineCount() - 19, 0, chatbox.GetLineCount()));
		chatbox.UpdateDisplay();
	end;
end;

function PANEL:SetChatOpen(bIsOpen)
	self.isOpen = bIsOpen;
end;

local function IsIcon(text)
	return (text:StartWith("[icon:") and text:EndsWith(".png]"));
end;

local function IsAvatar(text)
	return (text == "[SenderAvatar]");
end;

local function IsTime(text)
	return (text:StartWith("[SendTime:"));
end;

local function SendTime(text)
	if (IsTime(text)) then
		return tonumber(text:sub(11, text:find("]") - 1));
	end;
end;

local function ToIcon(text)
	if (IsIcon(text)) then
		return text:sub(7, text:find("]") - 1);
	end;
end;

function PANEL:Paint(w, h)
	if (CW.kernel:IsChoosingCharacter()) then return; end;
	
	if (self.isOpen) then
		draw.RoundedBox(2, 0, 0, w, h, Color(60, 60, 60));
	end;
	
	surface.SetFont("cwChatBoxFont");
	local offX = 4;
	local offY = 0;
	local curSender = nil;
	
	for k, v in ipairs(chatbox.display) do
		if ((os.time() - v._METADATA.time) < 8 or self.isOpen) then
			for k2, v2 in pairs(v) do
				if (typeof(v2) == "table") then
					if (k2 != "_METADATA") then
						v2.a = chatbox.curAlpha or v2.a or 255;
						surface.SetTextColor(v2);
					end;
				elseif (typeof(v2) == "string") then
					if (IsTime(v2)) then
						local time = os.date("%H:%M", SendTime(v2));

						surface.SetTextPos(offX, offY);
						surface.DrawText(time);

						local width = util.GetTextSize("cwChatBoxFont", time);
						offX = offX + width + 2;
					elseif (IsIcon(v2)) then
						local matPath = ToIcon(v2);
						local material = CW.kernel:GetMaterial(matPath);

						surface.SetDrawColor(255, 255, 255, chatbox.curAlpha)
						surface.SetMaterial(material) -- If you use Material, cache it!
						surface.DrawTexturedRect(offX, offY, 16, 16)

						offX = offX + 18;
					elseif (IsAvatar(v2)) then
						if (IsValid(curSender)) then
							local matPath = ToIcon(v2);
							local material = Material("data/cwavatars/"..curSender:SteamID64()..".jpg");

							surface.SetDrawColor(255, 255, 255, chatbox.curAlpha)
							surface.SetMaterial(material)
							surface.DrawTexturedRect(offX, offY, 16, 16)

							offX = offX + 18;
						end;
					else
						surface.SetTextPos(offX, offY);
						surface.DrawText(v2);

						local width = util.GetTextSize("cwChatBoxFont", v2);
						offX = offX + width;
					end;
				elseif (typeof(v2) == "number") then
					offY = v2;
					offX = 4;
				elseif (typeof(v2) == "player") then
					curSender = v2;
				else
					print(v2);
				end;
			end;
		end;
	end;
	
	if (chatbox.IsTypingCommand()) then
		local splitTable = string.Explode(" ", string.utf8sub(chatbox.GetCurrentText(), 2));
		local commands = {};
		local command = splitTable[1];
		local cX, cY = 4, chatbox.y / 4 + 38;
		
		if (command and command != "") then
			chatbox.curAlpha = 50;
			
			for k, v in pairs(Clockwork.command:GetAlias()) do
				local commandLen = string.utf8len(command);

				if (commandLen == 0) then
					commandLen = 1;
				end;

				if (string.utf8sub(k, 1, commandLen) == string.lower(command) and (!splitTable[2] or string.lower(command) == k)) then
					local cmdTable = Clockwork.command:FindByAlias(v);
 					
 					if (cmdTable and Clockwork.player:HasFlags(Clockwork.Client, cmdTable.access)) then
 						local bShouldAdd = true;
 
 						-- It can so happen that multiple alias for the same command begin with the same string.
 						-- We don't want to display the same command multiple times, so we check for that.
 						for k, v in pairs(commands) do
 							if (v == cmdTable) then
 								bShouldAdd = false;
 							end;
 						end;
 
 						if (bShouldAdd) then
 							commands[#commands + 1] = cmdTable;
 						end;
 					end;
				end;
				
				if (#commands == 8) then
					break;
				end;
			end;
			
			for k, v in ipairs(commands) do
				cX = 4;
				draw.SimpleText("/"..v.name, "cwChatBoxSyntax", cX, cY, Color(240, 240, 240));
				local w = util.GetTextSize("cwChatBoxSyntax", "/"..v.name);
				cX = cX + w + 8;
				draw.SimpleText((v.tip or ""), "cwChatBoxFont", cX, cY + 4, Color(206, 206, 206));
				
				if (#commands == 1) then
					local offsetX = 24;
					
					if (v.alias) then
						local text = "#CMDDesc_Aliases ";
						
						if (#v.alias > 1) then
							for i, a in ipairs(v.alias) do
								text = text..a.."; ";
							end;
						else
							text = text..v.alias[1];
						end;
						
						draw.SimpleText(text, "cwChatBoxFont", 4, cY + offsetX, Color(240, 240, 240))
						
						offsetX = offsetX + 20;
					end;
					
					draw.SimpleText("#CMDDesc_Usage ".."/"..v.name.." "..v.text, "cwChatBoxFont", 4, cY + offsetX, Color(240, 240, 240));
				end;
				
				cY = cY + 24;
			end;
		else
			chatbox.curAlpha = 255;
		end;
	else
		chatbox.curAlpha = 255;
	end;
end;

function PANEL:Think()
	if (self.isOpen and input.IsKeyDown(KEY_ESCAPE)) then
		chatbox.Hide();
	end;
end;

vgui.Register("cwChatBox", PANEL, "EditablePanel");

local PANEL = {};

function PANEL:Init()
	self:SetText("");
end;

function PANEL:Paint(w, h)
	draw.RoundedBox(2, 0, 0, w, h, Color(25, 25, 25));
	self:DrawTextEntryText(Color(255, 255, 255, 255), Color(255, 250, 200), Color(255, 255, 255, 255));
end;

function PANEL:OnEnter()
	local text = self:GetValue();
	
	netstream.Start("ChatboxTextEntered", text);
	
	plugin.Call("ChatBoxTextTyped", text);
	
	self:SetText("");
	chatbox.Hide();
end;

function PANEL:Think()
	self:SetSize(chatbox.width, 24);
	self:SetPos(0, chatbox.height - 24);
end;

function PANEL:SetValue(text)
	self:SetText(text);
	
	if (text and text != "") then
		if (limit) then
			if (self:GetCaretPos() > string.utf8len(text)) then
				self:SetCaretPos(string.utf8len(text));
			end;
		else
			self:SetCaretPos(string.utf8len(text));
		end;
	end;
end;

function PANEL:OnKeyCodeTyped(code)
	if (code == KEY_ENTER and !self:IsMultiline() and self:GetEnterAllowed()) then
		self:FocusNext();
		self:OnEnter();
	else
		local text = plugin.Call("ChatBoxKeyCodeTyped", code, self:GetValue());

		if (text and type(text) == "string") then
			self:SetValue(text);
		end;
	end;
end;

vgui.Register("cwChatTextEntry", PANEL, "DTextEntry");

function chatbox.CreateChatBox()
	if (!chatbox.panel) then
		chatbox.panel = vgui.Create("cwChatBox");
	end;
end;

function chatbox.IsOpen()
	if (IsValid(chatbox.panel)) then
		return chatbox.panel.isOpen;
	end;
end;

-- A function to get the current text.
function chatbox.GetCurrentText()
	local textEntry = chatbox.textEntry;
	
	if (textEntry:IsVisible() and chatbox.IsOpen()) then
		return textEntry:GetValue();
	else
		return "";
	end;
end;

function chatbox.IsTypingOOC()
	local text = chatbox.GetCurrentText();
	
	return (text:StartWith("//") or text:StartWith(".//") or text:StartWith("[["));
end;

-- A function to get whether the player is typing a command.
function chatbox.IsTypingCommand()
	local text = chatbox.GetCurrentText();
	local prefix = {"/", "/?"};

	for k, v in pairs(prefix) do
		if (text:StartWith(v) and !chatbox.IsTypingOOC()) then
			return true;
		end;
	end;
	
	return false;
end;

function chatbox.CreateTextEntry()
	if (!chatbox.textEntry) then
		chatbox.textEntry = vgui.Create("cwChatTextEntry", chatbox.panel);
		chatbox.textEntry:SetFont("cwChatBoxFont");
		chatbox.textEntry:SetTextColor(Color(255, 255, 255));
	end;
end;

function chatbox.CreateDerma()
	chatbox.CreateChatBox();
	chatbox.CreateTextEntry();
end;

function chatbox.Show()
	chatbox.panel:SetChatOpen(true);
	chatbox.panel:MakePopup();
	chatbox.textEntry:Show();
	chatbox.panel.scrollBar:SetVisible(true);
	chatbox.textEntry:RequestFocus();
end

function chatbox.Hide()
	chatbox.panel:SetChatOpen(false);
	chatbox.panel:SetMouseInputEnabled(false);
	chatbox.panel:SetKeyboardInputEnabled(false);
	chatbox.textEntry:Hide()
	chatbox.panel.scrollBar:SetVisible(false);
	
	hook.Run("FinishChat");
	timer.Simple(FrameTime() * 0.5, function() RunConsoleCommand("cancelselect") end)
end;

function chatbox.RecreatePanel()
	chatbox.panel:SetVisible(false);
	chatbox.textEntry:SetVisible(false);
	chatbox.textEntry:Remove();
	chatbox.panel.scrollBar:SetVisible(false);
	chatbox.panel.scrollBar:Remove()
	chatbox.panel:Remove();
	chatbox.panel = nil;
	chatbox.textEntry = nil;
	chatbox.CreateDerma();
end;

concommand.Add("cw_resetchat", chatbox.RecreatePanel)

function chatbox.UpdateDisplay()
	local i = 1;
	local maxMessages = 20;
	
	g_DisplayY = (maxMessages - 2) * 20;
	chatbox.display = {};
	local curMsg = 0;
	
	for k, v in SortedPairs(chatbox.history, true) do
		if (curMsg < chatbox.panel.scrollOffset) then
			--nothing
		else
			if (i < maxMessages) then
				local parsed = chatbox.ParseText(chatbox.history[k]);

				for _, line in ipairs(parsed) do
					line._METADATA = {};
					line._METADATA.time = v.time;
					line._METADATA.index = k;
					
					if (#parsed > 1) then
						line._METADATA.multiLine = true;
					end;
					
					line._METADATA.lineCount = #parsed;
					chatbox.history[k].lineCount = #parsed;
					
					table.insert(chatbox.display, line);
				end;

				i = i + 1;
			else
				break;
			end;
		end;

		curMsg = curMsg + 1;
	end;
	
	local lastIdx = 0;
	local multiLineOffset = 0;
	local curLine = 1;
	
	for k, v in pairs(chatbox.display) do
		if (v._METADATA.index == lastIdx) then
			curLine = curLine + 1;
			
			v[1] = g_DisplayY + (curLine * 20);
		else
			multiLineOffset = 0;
			curLine = 1;
			
			if (v._METADATA.multiLine) then
				multiLineOffset = v._METADATA.lineCount * 20 - 20;
				
				v[1] = g_DisplayY - multiLineOffset;
				g_DisplayY = g_DisplayY - multiLineOffset - 20;
				
				lastIdx = v._METADATA.index;
			else
				v[1] = g_DisplayY;
				g_DisplayY = g_DisplayY - 20;
				lastIdx = v._METADATA.index;
			end;
		end;
	end;
end;

function chatbox.AddText(...)
	netstream.Start("ChatboxAddText", ...);
end;

--[[
	Hooks
--]]

hook.Add("PlayerBindPress", "chatbox.PlayerBindPress", function(player, bind, bPress)
	if ((string.find(bind, "messagemode") or string.find(bind, "messagemode2")) and bPress) then
		if (CW.Client:HasInitialized()) then
			chatbox.Show();
		end;
		
		return true;
	end;
end);

netstream.Hook("ChatboxTextEnter", function(player, messageData)
	if (IsValid(player)) then
		chat.PlaySound()
		
		table.insert(chatbox.history, messageData);
		
		chatbox.UpdateDisplay();
	end;
end);

netstream.Hook("ChatboxAddText", function(messageData)
	chat.PlaySound()

	table.insert(chatbox.history, messageData);

	chatbox.UpdateDisplay();
end);