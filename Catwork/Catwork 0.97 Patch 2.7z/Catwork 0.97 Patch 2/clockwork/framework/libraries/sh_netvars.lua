
library.New("netvars", _G);

-- This code is taken from NutScript.
-- NutScript and code license are found here:
-- https://github.com/Chessnut/NutScript

if (SERVER) then

	local entityMeta = FindMetaTable("Entity")
	local playerMeta = FindMetaTable("Player")

	netvars.stored = netvars.stored or {};
	netvars.globals = netvars.globals or {}

	-- Check if there is an attempt to send a function. Can't send those.
	local function checkBadType(name, object)
		local objectType = type(object)
		
		if (objectType == "function") then
			ErrorNoHalt("Net var '"..name.."' contains a bad object type!")
			
			return true
		elseif (objectType == "table") then
			for k, v in pairs(object) do
				-- Check both the key and the value for tables, and has recursion.
				if (checkBadType(name, k) or checkBadType(name, v)) then
					return true
				end
			end
		end
	end

	function netvars.SetNetVar(key, value, receiver)
		if (checkBadType(key, value)) then return end
		if (netvars.GetNetVar(key) == value) then return end

		netvars.globals[key] = value
		netstream.Start(receiver, "gVar", key, value)
	end

	function playerMeta:SyncVars()
		for entity, data in pairs(netvars.stored) do
			if (entity == "globals") then
				for k, v in pairs(data) do
					netstream.Start(self, "gVar", k, v)
				end
			elseif (IsValid(entity)) then
				for k, v in pairs(data) do
					netstream.Start(self, "nVar", entity:EntIndex(), k, v)
				end
			end
		end
	end

	function entityMeta:SendNetVar(key, receiver)
		netstream.Start(receiver, "nVar", self:EntIndex(), key, netvars.stored[self] and netvars.stored[self][key])
	end

	function entityMeta:ClearNetVars(receiver)
		netvars.stored[self] = nil
		netstream.Start(receiver, "nDel", self:EntIndex())
	end

	function entityMeta:SetNetVar(key, value, receiver)
		if (checkBadType(key, value)) then return end
			
		netvars.stored[self] = netvars.stored[self] or {}

		if (netvars.stored[self][key] != value) then
			netvars.stored[self][key] = value
		end

		self:SendNetVar(key, receiver)
	end

	function entityMeta:GetNetVar(key, default)
		if (netvars.stored[self] and netvars.stored[self][key] != nil) then
			return netvars.stored[self][key]
		end

		return default
	end

	function playerMeta:SetLocalVar(key, value)
		if (checkBadType(key, value)) then return end
		
		netvars.stored[self] = netvars.stored[self] or {}
		netvars.stored[self][key] = value

		netstream.Start(self, "nLcl", key, value)
	end

	playerMeta.GetLocalVar = entityMeta.GetNetVar

	function netvars.GetNetVar(key, default)
		local value = netvars.globals[key]

		return value != nil and value or default
	end

	hook.Add("EntityRemoved", "nCleanUp", function(entity)
		entity:ClearNetVars()
	end)

	hook.Add("PlayerInitialSpawn", "nSync", function(client)
		client:SyncVars()
	end)

else

	local entityMeta = FindMetaTable("Entity")
	local playerMeta = FindMetaTable("Player")

	netvars.globals = netvars.globals or {}
	netvars.stored = netvars.stored or {};

	netstream.Hook("nVar", function(index, key, value)
		netvars.stored[index] = netvars.stored[index] or {}
		netvars.stored[index][key] = value
	end)

	netstream.Hook("nDel", function(index)
		netvars.stored[index] = nil
	end)

	netstream.Hook("nLcl", function(key, value)
		netvars.stored[LocalPlayer():EntIndex()] = netvars.stored[LocalPlayer():EntIndex()] or {}
		netvars.stored[LocalPlayer():EntIndex()][key] = value
	end)

	netstream.Hook("gVar", function(key, value)
		netvars.globals[key] = value
	end)

	function netvars.GetNetVar(key, default)
		local value = netvars.globals[key]

		return value != nil and value or default
	end

	function entityMeta:GetNetVar(key, default)
		local index = self:EntIndex()

		if (netvars.stored[index] and netvars.stored[index][key] != nil) then
			return netvars.stored[index][key]
		end

		return default
	end

	playerMeta.GetLocalVar = entityMeta.GetNetVar

end