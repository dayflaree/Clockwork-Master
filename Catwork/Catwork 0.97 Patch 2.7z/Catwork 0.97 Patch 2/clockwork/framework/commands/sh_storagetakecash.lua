--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("StorageTake"..string.gsub(NAME_CASH, "%s", ""));
COMMAND.tip = "Take some "..string.lower(NAME_CASH).." from storage.";
COMMAND.text = "<number "..string.gsub(NAME_CASH, "%s", "")..">";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local storageTable = player:GetStorageTable();
	
	if (storageTable) then
		local target = storageTable.entity;
		local cash = math.floor(tonumber(arguments[1]));
		
		if ((target and !IsValid(target)) or !CW.config:Get("cash_enabled"):Get()) then
			return;
		end;
		
		if (cash and cash > 1 and cash <= storageTable.cash) then
			if (!storageTable.CanTakeCash
			or (storageTable.CanTakeCash(player, storageTable, cash) != false)) then
				if (!target or !target:IsPlayer()) then
					CW.player:GiveCash(player, cash, nil, true);
					CW.storage:UpdateCash(player, storageTable.cash - cash);
				else
					CW.player:GiveCash(player, cash, nil, true);
					CW.player:GiveCash(target, -cash, nil, true);
					CW.storage:UpdateCash(player, target:GetCash());
				end;
				
				if (storageTable.OnTakeCash
				and storageTable.OnTakeCash(player, storageTable, cash)) then
					CW.storage:Close(player);
				end;
			end;
		end;
	else
		CW.player:Notify(player, L("StorageNotOpen"));
	end;
end;

COMMAND:Register();