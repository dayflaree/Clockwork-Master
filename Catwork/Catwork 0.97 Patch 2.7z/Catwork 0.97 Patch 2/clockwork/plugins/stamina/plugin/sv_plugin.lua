--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

CW.config:Add("stam_regen_scale", 0.1, true);
CW.config:Add("stam_drain_scale", 0.2, true);
CW.config:Add("breathing_volume", 1, true);
