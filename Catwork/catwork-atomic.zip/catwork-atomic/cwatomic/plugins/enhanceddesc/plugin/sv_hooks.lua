local PLUGIN = PLUGIN;

function PLUGIN:PlayerUse(player, target)
	if (IsValid(target) and target:IsPlayer()) then
		if (target:GetSharedVar("tied") == 0) then
			Clockwork.datastream:Start(player, "ViewDetDesc", {target, target:GetCharacterData("DetailDesc") or target:GetCharacterData("PhysDesc"), target:GetCharacterData("PictureDesc") or ""});
		end;
	end;
end;

util.AddNetworkString("descSend")

net.Receive("descSend", function()
	local StringTable = util.JSONToTable(net.ReadString());
	local player = Clockwork.player:FindByID(StringTable.name);

	if (player) then
		player:SetCharacterData("DetailDesc", StringTable.desc);
		player:SetCharacterData("PictureDesc", StringTable.sendlink);
	end;
end);