local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("SelfExamine");
COMMAND.tip = "Look at yourself";
COMMAND.text = "[No Text]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:GetSharedVar("tied") == 0) then
		Clockwork.datastream:Start(player, "ViewDetDesc", {player, player:GetCharacterData("DetailDesc") or player:GetCharacterData("PhysDesc"), player:GetCharacterData("PictureDesc") or ""});
	end;
end;

COMMAND:Register();