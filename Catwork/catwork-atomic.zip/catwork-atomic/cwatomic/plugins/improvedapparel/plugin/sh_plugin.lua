local PLUGIN = PLUGIN;

PLUGIN:SetGlobalAlias("cwImprovedApparel");

local playerMeta = FindMetaTable("Player");
local entMeta = FindMetaTable("Entity");

function playerMeta:GetClothesGroup()
	return PLUGIN:GetClothesGroup(self);
end;

function playerMeta:IsGhoul()
	return PLUGIN:IsGhoul(self);
end;

function playerMeta:GetHair()
	return PLUGIN:GetHair(self);
end;

function playerMeta:SetHair(index)
	PLUGIN:SetHair(self, index);
end;

function playerMeta:RestoreHair()
	PLUGIN:RestoreHair(self);
end;

function playerMeta:RemoveHair()
	PLUGIN:RemoveHair(self);
end;

function PLUGIN:GetClothesGroup(player)
	return player:GetNWString("cwClothesGroup", "group100");
end;

function PLUGIN:IsGhoul(player)
	return player:GetNWBool("cwGhoul", false);
end;

local function IsFOModel(sModel)
	return string.find(sModel, "models/lazarusroleplay/heads/");
end;

function PLUGIN:GetHair(player)
	return player:GetBodygroup(2);
end;

function PLUGIN:SetHair(player, index)
	print(player:GetBodygroupName(2));
	player:SetBodygroup(2, index);
end;

function PLUGIN:RemoveHair(player)
	player.cwIA_SavedHair = self:GetHair(player);
	player:SetBodygroup(2, 0);
end;

function PLUGIN:RestoreHair(player)
	player:SetBodygroup(2, player.cwIA_SavedHair or 0);
	player.cwIA_SavedHair = nil;
end;

if (CLIENT) then
	if (cwAnimatedLegs) then
		-- Because IK is really stupid and annoying.
		function cwAnimatedLegs:CreateLegs()
			self.LegsEntity = ClientsideModel(Clockwork.Client:GetModel(), RENDER_GROUP_OPAQUE_ENTITY);
			self.LegsEntity:SetNoDraw(true);
			self.LegsEntity:SetSkin(Clockwork.Client:GetSkin());
			self.LegsEntity:SetMaterial(Clockwork.Client:GetMaterial());
			self.LegsEntity:SetIK(false);
			self.LegsEntity.LastTick = 0;
		end;

		-- To make the models draw with the animated legs.
		function cwAnimatedLegs:RenderScreenspaceEffects()
			cam.Start3D(EyePos(), EyeAngles());
				if (self:ShouldDrawLegs()) then
					self.RenderPos = Clockwork.Client:GetPos();
					
					if (!Clockwork.Client:InVehicle()) then
						self.BiasAngles = Clockwork.Client:EyeAngles();
						self.RenderAngle = Angle(0, self.BiasAngles.y, 0)
						self.RadAngle = math.rad(self.BiasAngles.y);
						self.ForwardOffset = -12 + (1 - (math.Clamp(self.BiasAngles.p - 45, 0, 45) / 45) * 7);
						self.RenderPos.x = self.RenderPos.x + math.cos(self.RadAngle) * self.ForwardOffset;
						self.RenderPos.y = self.RenderPos.y + math.sin(self.RadAngle) * self.ForwardOffset;
						
						if (Clockwork.Client:GetGroundEntity() == NULL) then
							self.RenderPos.z = self.RenderPos.z + 8;
							
							if (Clockwork.Client:KeyDown(IN_DUCK)) then
								self.RenderPos.z = self.RenderPos.z - 28;
							end;
						end;
					else
						self.RenderAngle = Clockwork.Client:GetVehicle():GetAngles();
						self.RenderAngle:RotateAroundAxis(self.RenderAngle:Up(), 90);
					end;
					
					self.RenderColor = Clockwork.Client:GetColor(true);
					
					render.EnableClipping(true);
					render.PushCustomClipPlane(self.ClipVector, self.ClipVector:Dot(EyePos()));
					render.SetColorModulation(self.RenderColor.r / 255, self.RenderColor.g / 255, self.RenderColor.b / 255);
					render.SetBlend(self.RenderColor.a / 255);
					
					self.LegsEntity:SetRenderOrigin(self.RenderPos);
					self.LegsEntity:SetRenderAngles(self.RenderAngle);
					self.LegsEntity:SetupBones();
					self.LegsEntity:DrawModel();
					self.LegsEntity:SetRenderOrigin();
					self.LegsEntity:SetRenderAngles();

					if (cwImprovedApparel:HasModels(self.LegsEntity)) then
						self.LegsEntity.atomClothes:SetRenderOrigin(self.RenderPos);
						self.LegsEntity.atomClothes:SetRenderAngles(self.RenderAngle);
						self.LegsEntity.atomClothes:DrawModel();
						self.LegsEntity.atomClothes:SetRenderOrigin();
						self.LegsEntity.atomClothes:SetRenderAngles();

						self.LegsEntity.atomArms:SetRenderOrigin(self.RenderPos);
						self.LegsEntity.atomArms:SetRenderAngles(self.RenderAngle);
						self.LegsEntity.atomArms:DrawModel();
						self.LegsEntity.atomArms:SetRenderOrigin();
						self.LegsEntity.atomArms:SetRenderAngles();
					end;
					
					render.SetBlend(1);
					render.SetColorModulation(1, 1, 1);
					render.PopCustomClipPlane();
					render.EnableClipping(false);
				end;
			cam.End3D();
		end;
	end;

	function PLUGIN:PlayerTick(player)
		if (self:HasModels(player)) then
			local noDraw = player:GetNoDraw();

			player.atomClothes:SetNoDraw(noDraw);
			player.atomClothes:DrawShadow(!noDraw);
			player.atomArms:SetNoDraw(noDraw);
			player.atomArms:DrawShadow(!noDraw);
		end;
	end;

	function PLUGIN:RemoveModels(player)
		if (!IsValid(player) or !self:HasModels(player)) then return; end;

		player.atomArms:Remove();
		player.atomClothes:Remove();
	end;

	function PLUGIN:HasModels(player)
		return (IsValid(player.atomArms) or IsValid(player.atomClothes));
	end;

	function PLUGIN:SetupModels(player, group, ragdoll, bTimer, bSpawning)
		if (IsValid(player) and IsFOModel(player.Prone_OldModel or player:GetModel())) then
			self:RemoveModels(player);

			local group = group or player:GetClothesGroup();
			local gender = "male";

			if (player:GetGender() == GENDER_FEMALE) then
				gender = "female";
			end;

			if (player:IsGhoul()) then
				gender = "ghoul";
			end;

			-- Attach to the ragdoll if it exists (death ragdoll).
			if (ragdoll and !bTimer) then
				-- Workaround because GetRagdollEntity doesn't actually return the ragdoll the moment this hook is called.
				timer.Create("RagdollModels"..player:EntIndex(), 0, 0, function()
					if (IsValid(player) and IsValid(player:GetRagdollEntity())) then
						self:SetupModels(player, nil, nil, true);
						
						timer.Remove("RagdollModels"..player:EntIndex());
					end;
				end);

				return;
			end;

			ragdoll = player:GetRagdollEntity();

			-- so we can ignore the ragdoll (which for some reason still exists).
			if (ragdoll and !bSpawning) then
				player = ragdoll;
			end;

			if (IsValid(player.ProneModel) and !player.Prone_Leaving) then
				player = player.ProneModel;
				self:RemoveModels(player);
			end;

			player.atomArms = ClientsideModel("models/thespireroleplay/humans/"..group.."/arms/"..gender.."_arm.mdl", RENDERGROUP_OPAQUE);
			player.atomArms:SetParent(player);
			player.atomArms:AddEffects(EF_BONEMERGE);
			player.atomArms:SetIK(false);

			player.atomClothes = ClientsideModel("models/thespireroleplay/humans/"..group.."/"..gender..".mdl", RENDERGROUP_OPAQUE);
			player.atomClothes:SetParent(player);
			player.atomClothes:AddEffects(EF_BONEMERGE);
			player.atomClothes:SetIK(false);

			if (player == Clockwork.Client and cwAnimatedLegs and cwAnimatedLegs.LegsEntity) then
				self:RemoveModels(cwAnimatedLegs.LegsEntity);

				cwAnimatedLegs.LegsEntity.atomArms = ClientsideModel("models/thespireroleplay/humans/"..group.."/arms/"..gender.."_arm.mdl", RENDERGROUP_OPAQUE);
				cwAnimatedLegs.LegsEntity.atomArms:SetParent(cwAnimatedLegs.LegsEntity);
				cwAnimatedLegs.LegsEntity.atomArms:AddEffects(EF_BONEMERGE);
				cwAnimatedLegs.LegsEntity.atomArms:SetNoDraw(true);
				cwAnimatedLegs.LegsEntity.atomArms:SetIK(false);

				cwAnimatedLegs.LegsEntity.atomClothes = ClientsideModel("models/thespireroleplay/humans/"..group.."/"..gender..".mdl", RENDERGROUP_OPAQUE);
				cwAnimatedLegs.LegsEntity.atomClothes:SetParent(cwAnimatedLegs.LegsEntity);
				cwAnimatedLegs.LegsEntity.atomClothes:AddEffects(EF_BONEMERGE);
				cwAnimatedLegs.LegsEntity.atomClothes:SetNoDraw(true);
				cwAnimatedLegs.LegsEntity.atomClothes:SetIK(false);
			end;
		end;
	end;

	-- To clean up the clientside models when the player's entity gets removed.
	function PLUGIN:EntityRemoved(player)
		self:RemoveModels(player);
	end;

	-- Called when a player's fake prone model is created (basically when they prone).
	function PLUGIN:Prone_ModelCreated(proneModel, player, model, modelColor, bodygroups, skin, playerColor)
		player.Prone_OldModel = proneModel:GetModel();

		self:SetupModels(player);
	end;

	function PLUGIN:Prone_PostEndProne(player)
		if (player.Prone_OldModel and IsFOModel(player.Prone_OldModel)) then
			timer.Create("ProneWaitForModel"..player:EntIndex(), 0, 0, function()
				local isValid = IsValid(player);

				if (isValid and IsFOModel(player:GetModel())) then
					player.Prone_Leaving = true;
					self:SetupModels(player);
					player.Prone_OldModel = nil;
					player.Prone_Leaving = nil;

					timer.Remove("ProneWaitForModel"..player:EntIndex());
				elseif (!isValid) then
					timer.Remove("ProneWaitForModel"..player:EntIndex());
				end;
			end);
		end;
	end;

	-- Load all current players' models.
	function PLUGIN:InitPostEntity()
		for k, v in pairs(_player.GetAll()) do
			PLUGIN:SetupModels(v);
		end;
	end;

	-- Called to setup the extra models needed for the apparel system to work properly.
	Clockwork.datastream:Hook("cwSetupClothes", function(data)
		local player = Entity(data[1]);

		PLUGIN:SetupModels(player, data[2], data[3], nil, data[4]);
	end);

	-- Called to remove the player's extra models.
	Clockwork.datastream:Hook("cwRemoveClothes", function(data)
		local player = Entity(data[1]);
		local ragdoll = player:GetRagdollEntity();

		PLUGIN:RemoveModels(player);

		if (ragdoll) then
			PLUGIN:RemoveModels(ragdoll);
		end;
	end);
else
	function playerMeta:SetClothesGroup(sGroup)
		PLUGIN:SetClothesGroup(self, sGroup);
	end;

	function PLUGIN:SetClothesGroup(player, sGroup)
		player:SetNWString("cwClothesGroup", sGroup);

		Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex(), sGroup});
	end;

	-- Called after a player's active character data has been loaded and initialized.
	function PLUGIN:PlayerCharacterInitialized(player)
		Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex()});
	end;

	-- Called after the player has been spawned.
	function PLUGIN:PostPlayerSpawn(player)
		if (player:HasInitialized()) then
			Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex(), [4] = true});
		end;
	end;

	-- Called when a player has been ragdolled.
	function PLUGIN:PlayerRagdolled(player, state, ragdoll)
		Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex(), [3] = true});
	end;

	-- Called when a player has been unragdolled.
	function PLUGIN:PlayerUnragdolled(player, state, ragdoll)
		Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex()});
	end;

	function PLUGIN:PlayerModelChanged(player, model)
		if (player:HasInitialized()) then
			if (!IsFOModel(model)) then
				Clockwork.datastream:Start(nil, "cwRemoveClothes", {player:EntIndex()});
			else
				Clockwork.datastream:Start(nil, "cwSetupClothes", {player:EntIndex()});
			end;
		end;
	end;

	concommand.Add("changeclothesgroup", function(player, cmd, args)
		player:SetClothesGroup(args[1]);
	end);

	concommand.Add("changehair", function(player, cmd, args)
		player:SetHair(args[1]);
	end);
end;

FACTION_CITIZENS_FEMALE = {
	"models/lazarusroleplay/heads/female_caucasian.mdl",
	"models/lazarusroleplay/heads/female_african.mdl",
	"models/lazarusroleplay/heads/female_asian.mdl",
	"models/lazarusroleplay/heads/female_hispanic.mdl"
};

FACTION_CITIZENS_MALE = {
	"models/lazarusroleplay/heads/male_caucasian.mdl",
	"models/lazarusroleplay/heads/male_african.mdl",
	"models/lazarusroleplay/heads/male_asian.mdl",
	"models/lazarusroleplay/heads/male_hispanic.mdl"
};