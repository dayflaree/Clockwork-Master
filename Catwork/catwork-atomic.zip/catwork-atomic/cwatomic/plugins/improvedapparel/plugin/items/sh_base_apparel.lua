local ITEM = Clockwork.item:FindByID("base_apparel");

-- Called when the item's client side model is needed.
function ITEM:GetClientSideModel()
	local replacement = nil;
	
	if (self.GetReplacement) then
		replacement = self:GetReplacement(Clockwork.Client);
	end;
	
	if (type(replacement) == "string") then
		return replacement;
	elseif (self("replacement")) then
		return self("replacement");
	elseif (self("group")) then
		return "models/thespireroleplay/items/"..self("group")..".mdl";
	end;
end;

-- Called when a player changes clothes.
function ITEM:OnChangeClothes(player, bIsWearing)
	if (bIsWearing) then
		local replacement = nil;
		
		if (self.GetReplacement) then
			replacement = self:GetReplacement(player);
		end;
		
		if (type(replacement) == "string") then
			player:SetModel(replacement);
		elseif (self("replacement")) then
			player:SetModel(self("replacement"));
		elseif (self("group")) then
			player:SetClothesGroup(self("group"));
		end;

		if (self.specialBoost) then
			for k, v in pairs(self.specialBoost) do
				player:AddBoost(k, v, true);
			end;
		end;

		local armor = self:GetData("Armor");

		if (armor) then
			player:SetArmor(math.Clamp(armor, 0, player:GetMaxArmor()));
		end;

		player:EmitSound("atomic/items/clothing/clothing_equip_0"..math.random(1, 3)..".mp3");
	else
		if (self.specialBoost) then
			for k, v in pairs(self.specialBoost) do
				player:AddBoost(k, 0, true);
			end;
		end;

		Clockwork.player:SetDefaultModel(player);
		Clockwork.player:SetDefaultSkin(player);

		player:SetClothesGroup("group100");

		local armor = self:GetData("Armor");

		if (armor) then
			player:SetArmor(math.Clamp(player:Armor() - armor, 0, player:GetMaxArmor()));
		end;

		player:EmitSound("atomic/items/clothing/clothing_remove_0"..math.random(1, 3)..".mp3");
	end;
	
	if (self.overlay) then
		Atomic.overlay:SetEnabled(self.overlay, bIsWearing, player);
	end;

	if (self.OnChangedClothes) then
		self:OnChangedClothes(player, bIsWearing);
	end;

	Clockwork.plugin:Call("OnChangedClothes", player, self, bIsWearing);
end;

-- Remove these other items from the schema for now.
local function removeItem(sItem)
	Clockwork.item.stored["apparel_"..sItem] = nil;
end;

removeItem("combat_armor");
removeItem("combat_armor_2");
removeItem("desert_combat_armor");
removeItem("hazard_suit");
removeItem("leather_armor");
removeItem("ncr_uniform");
removeItem("ranger_patrol_armor");
removeItem("scout_jumpsuit");
removeItem("scout_vault_jumpsuit");
removeItem("scrapmail");
removeItem("tactical_gasmask");
removeItem("utility_armor");