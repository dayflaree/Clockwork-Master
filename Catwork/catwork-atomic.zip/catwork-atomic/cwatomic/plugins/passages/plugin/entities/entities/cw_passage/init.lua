--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

local PLUGIN = PLUGIN;

-- Called when the entity initializes.
function ENT:Initialize()	
	
end;

-- Called when the entity's transmit state should be updated.
function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS;
end;

-- Called when the entity is used.
function ENT:Use(activator, caller)
	if (activator:IsPlayer() and activator:GetEyeTraceNoCursor().Entity == self) then
		local curTime = CurTime();

		if (!activator.passageCooldown or activator.passageCooldown <= curTime) then		
			if (self.server and self.server != "") then
				local doorExists = false;
				local doors = ents.FindByClass("cw_passage");

				for k, v in pairs(doors) do
					if (v.uniqueID == self.entryUniqueID) then
						doorExists = true;

						break;
					end;
				end;

				if (doorExists) then
					self:EmitSound("srp/fnv/door/generic_open.mp3");

					PLUGIN:TransferPlayer(activator, self.server, self.password, self.entryUniqueID);

					timer.Simple(1.5, function()
						self:EmitSound("srp/fnv/door/generic_close.mp3");
					end);
				else
					self:EmitSound("srp/fnv/door/locked/locked_0"..math.random(1, 4)..".mp3");
				end;
			else
				self:EmitSound("srp/fnv/door/locked/locked_0"..math.random(1, 4)..".mp3");
			end;

			activator.passageCooldown = curTime + 3;
		end;
	end;
end;