local PLUGIN = PLUGIN;

PLUGIN:SetGlobalAlias("cwPassages");

local fadeDuration = 1.5;

if (SERVER) then
	function Atomic:PlayerDataLoaded(player)
		local charID = player:GetData("Passages_CharacterID");

		if (charID and charID != "") then
			local uniqueID = player:GetData("Passages_EntryUniqueID");

			if (uniqueID and uniqueID != "") then
				player.entryUniqueID = uniqueID;
			end;

			player:SendLua("Passages_StopCharacter = true");
		else
			Clockwork.datastream:Start(player, "StartIntroduction", {player:GetData("FNVIntro")});
			player:SetData("FNVIntro", true);
		end;

		player:SetData("ClockworkIntro", true);
	end;

	function cwPassages:PostSaveData()
		local passages = {};
	
		for k, v in pairs( ents.FindByClass("cw_passage") ) do
			local physicsObject = v:GetPhysicsObject();
			local moveable;
			
			if ( IsValid(physicsObject) ) then
				moveable = physicsObject:IsMoveable();
			end;
			
			passages[#passages + 1] = {
				angles = v:GetAngles(),
				moveable = moveable,
				position = v:GetPos(),
				model = v:GetModel(),
				server = v.server,
				password = v.password,
				name = v:GetNWString("name"),
				uniqueID = v.uniqueID,
				entry = v.entryUniqueID
			};
		end;
		
		Clockwork.kernel:SaveSchemaData("plugins/passages/"..game.GetMap(), passages);
	end;

	function cwPassages:ClockworkInitPostEntity()
		local passages = Clockwork.kernel:RestoreSchemaData("plugins/passages/"..game.GetMap());
		
		for k, v in pairs(passages) do
			local entity = ents.Create("cw_passage");
		
			entity:SetAngles(v.angles);
			entity:SetPos(v.position);
			entity:SetModel(v.model);

			entity:SetMoveType(MOVETYPE_VPHYSICS);
			entity:PhysicsInit(SOLID_VPHYSICS);
			entity:SetUseType(SIMPLE_USE);
			entity:SetSolid(SOLID_VPHYSICS);

			entity:Spawn();
			entity:Activate();

			entity.server = v.server;
			entity.password = v.password;
			entity:SetNWString("name", v.name);
			entity.uniqueID = v.uniqueID;
			entity.entryUniqueID = v.entry;

			if (!v.moveable) then
				local physicsObject = entity:GetPhysicsObject();
				
				if ( IsValid(physicsObject) ) then
					physicsObject:EnableMotion(false);
				end;
			end;
		end;
	end;

	function cwPassages:TransferPlayer(player, server, password, uniqueID)
		if (server and server != "") then
			if (server == game.GetIPAddress()) then
				self:FadePlayer(player);
				player.entryUniqueID = uniqueID;

				timer.Simple(fadeDuration, function()
					if (IsValid(player)) then
						self:TeleportPlayer(player);
					end;
				end);
			else
				if (password and password != "") then
					player:SendLua("Clockwork.Client:ConCommand('password "..password.."')");
				end;

				player:SetData("Passages_CharacterID", Clockwork.player:GetCharacter(player).characterID);

				if (uniqueID and uniqueID != "") then
					player:SetData("Passages_EntryUniqueID", uniqueID);
				end;

				self:FadePlayer(player);

				timer.Simple(fadeDuration, function()
					player:SendLua("Clockwork.Client:ConCommand('connect "..server.."')");
				end);
			end;
		end;
	end;

	function cwPassages:FadePlayer(player)
		player.fadeLerpStart = CurTime();
		player:SendLua("cwPassages:StartFadeOut()");
	end;

	function cwPassages:PlayerTick(player)
		local lerpStart = player.fadeLerpStart;

		if (lerpStart) then
			local fadeBack = player.fadeBackLerp;

			if (fadeBack) then
				local fraction = (CurTime() - fadeBack) / fadeDuration;
				local weapon = player:GetActiveWeapon();
				local color = player:GetColor();
				local alpha = Lerp(fraction, 0, 255);

				player:SetRenderMode(RENDERMODE_TRANSALPHA);
				player:SetColor(ColorAlpha(color, alpha));
				player:DrawShadow(true);

				if (IsValid(weapon)) then
					local wepColor = weapon:GetColor();

					weapon:SetRenderMode(RENDERMODE_TRANSALPHA);
					weapon:SetColor(ColorAlpha(color, alpha));
				end;

				if (fraction >= 1) then
					player.fadeBackLerp = nil;
					player.fadeLerpStart = nil;

					player:SetRenderMode(player.lastRenderMode or RENDERMODE_NORMAL);
					player.lastRenderMode = nil;

					if (IsValid(weapon)) then
						weapon:SetRenderMode(weapon.lastRenderMode or RENDERMODE_NORMAL);
						weapon.lastRenderMode = nil;
					end;
				end;
			else
				local fraction = (CurTime() - lerpStart) / fadeDuration;
				local weapon = player:GetActiveWeapon();
				local color = player:GetColor();
				local alpha = Lerp(fraction, 255, 0);

				player.lastRenderMode = player.lastRenderMode or player:GetRenderMode();
				player:SetRenderMode(RENDERMODE_TRANSALPHA);
				player:SetColor(ColorAlpha(color, alpha));
				player:DrawShadow(false);

				if (IsValid(weapon)) then
					local wepColor = weapon:GetColor();

					weapon.lastRenderMode = weapon.lastRenderMode or weapon:GetRenderMode();
					weapon:SetRenderMode(RENDERMODE_TRANSALPHA);
					weapon:SetColor(ColorAlpha(color, alpha));
				end;

				if (fraction == 1) then
					player.fadeBackLerp = CurTime();
				end;
			end;
		end;
	end;

	-- A function to teleport a player to the door that matches their storedID according to whatever door they used.
	function cwPassages:TeleportPlayer(player)
		local doors = ents.FindByClass("cw_passage");
		local door = nil;

		for k, v in pairs(doors) do
			if (v.uniqueID == player.entryUniqueID) then
				door = v;

				break;
			end;
		end;

		if (IsValid(door)) then
			local plyAngles = player:EyeAngles();
			local doorAngles = door:GetAngles();

			player:SetEyeAngles(Angle(plyAngles.p, doorAngles.y, plyAngles.r));
			player:SetPos(door:GetPos() + (door:GetForward() * 30) + (door:GetRight() * -25) + (door:GetUp() * -10));

			timer.Simple(0.5, function()
				door:EmitSound("srp/fnv/door/generic_close.mp3");
			end);
		end;
	end;

	Clockwork.datastream:Hook("Passages_LoadCharacter", function(player, data)
		Clockwork.player:LoadCharacter(player, player:GetData("Passages_CharacterID"));

		player:SetData("Passages_EntryUniqueID", "");
		player:SetData("Passages_CharacterID", "");

		cwPassages:TeleportPlayer(player);
	end);
else
	local lerpStart = nil;
	local fadeInStart = nil;
	local lerpDuration = 0.5;

	function cwPassages:Initialize()
		CW_CONVAR_PASSAGEESP = Clockwork.kernel:CreateClientConVar("cwPassageESP", 0, false, true);
	end;
	
	function cwPassages:GetAdminESPInfo(info)
		if (CW_CONVAR_PASSAGEESP:GetInt() == 1) then
			local passages = ents.FindByClass("cw_passage");

			for k, v in pairs(passages) do
				if (v:IsValid()) then
					local position = v:GetPos() + Vector(0, 0, 80);
					local name = v:GetNWString("name");
					local color = Color(100, 150, 0, 255);

					table.insert(info, {
						position = position,
						text = {
							{
								text = "[Passage]", 
								color = color
							},
							{
								text = name, 
								color = color
							}
						}
					});
				end;
			end;
		end;
	end;

	function cwPassages:PlayerCharacterScreenCreated()
		if (Passages_StopCharacter) then
			Clockwork.character:SetPanelOpen(false);
			Clockwork.CinematicScreenDone = true;
			Clockwork.CinematicInfoAlpha = 0;
			Clockwork.CinematicInfoSlide = 0;

			Clockwork.datastream:Start("Passages_LoadCharacter", {});
		end;
	end;

	function cwPassages:StartFadeOut()
		lerpStart = CurTime();

		timer.Simple((fadeDuration * 2) - lerpDuration, function()
			lerpStart = nil;

			fadeInStart = CurTime();
		end);
	end;

	local timerStarted = false;

	function cwPassages:HUDPaint()
		if (lerpStart) then
			local fraction = (CurTime() - lerpStart) / lerpDuration;

			surface.SetDrawColor(0, 0, 0, Lerp(fraction, 0, 255));
			surface.DrawRect(0, 0, ScrW(), ScrH());
		elseif (fadeInStart) then
			local fraction = (CurTime() - fadeInStart) / lerpDuration;

			surface.SetDrawColor(0, 0, 0, Lerp(fraction, 255, 0));
			surface.DrawRect(0, 0, ScrW(), ScrH());

			if (fraction >= 1) then
				fadeInStart = nil;
			end;
		end;
	end;

	Clockwork.setting:AddCheckBox("Admin ESP", "Show passage entities.", "cwPassageESP", "Whether or not to view passages in the admin ESP.", function()
		return Clockwork.player:IsAdmin(Clockwork.Client);
	end);
end;