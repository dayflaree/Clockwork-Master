local PLUGIN = PLUGIN;

function PLUGIN:PlayerCharacterUnloaded(player)
	if (player:IsProne()) then
		prone.EndProne(player, true);
	end;
end;

function PLUGIN:PlayerNoClip(player)
	if (player:IsAdmin() and player:IsProne()) then
		prone.EndProne(player, true);
	end;
end;

function PLUGIN:PlayerModelChanged(ply, model)
	if (ply:IsProne() and !ply.cwProneCheck) then
		ply.Prone_OldModel = model;
		ply.Prone_OldColor = ply:GetColor();

		prone.UpdateProneModel(ply, ply.Prone_OldModel);

		local function FindName(word)
			return tobool(string.find(string.lower(ply.Prone_OldModel), word));
		end;

		local ProneMdl = "models/player/p_kleiner.mdl";

		if FindName("female") or FindName("alyx") or FindName("mossman") then
			ProneMdl = "models/player/p_alyx.mdl";	-- Doesn't make too much of a difference but why not
		end;

		timer.Simple(.1, function()
			if (ply:IsProne()) then
				--[[
					We do it this way because Clockwork runs checks on EVERY SetModel,
					so we don't want it to run this code again when we set the final model.
				--]]
				ply.cwProneCheck = true;
				ply:SetModel(ProneMdl);
				ply.cwProneCheck = nil;
			end;
		end);
	end;
end;

function PLUGIN:PlayerCanRagdoll(ply)
	if (ply:IsProne()) then
		prone.EndProne(ply, true);
	end;
end;