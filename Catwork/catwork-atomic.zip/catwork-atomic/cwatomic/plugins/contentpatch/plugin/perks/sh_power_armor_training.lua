local PERK = Atomic.perks:New();

PERK.name = "Power Armor Training";
PERK.icon = "atomic/hud/perks/power_armor.png";
PERK.description = "You have received the specialized training needed to move in any form of Power Armor.";

PERK:Register();