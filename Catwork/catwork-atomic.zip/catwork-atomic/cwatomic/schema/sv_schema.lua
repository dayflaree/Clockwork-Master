--[[ 
    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

CW.config:Add("intro_text_small", "War... War never changes..", true);
CW.config:Add("intro_text_big", "Wasteland, 2280.", true);

CW.config:Add("can_anon", true, true);
CW.config:Add("enable_special", true, true);
CW.config:Add("is_s2k", false, true);
CW.config:Add("show_boosts", false, true);
CW.config:Add("show_menu_blur", true, true);
CW.config:Add("enable_slow_death", true, true);
CW.config:Add("medical_effect", 50, true);
CW.config:Add("agility_effect", 0.75, true);
CW.config:Add("condition_decrease_scale", 1);
CW.config:Add("default_special_points", 21, true);
CW.config:Add("mute_crouched", true, true);
//CW.config:Add("step_volume", 1, true);
//CW.config:Add("crouch_step_volume", 0.60, true);
CW.config:Add("repair_amount", 0.20, true);

CW.config:Get("enable_gravgun_punt"):Set(false);
CW.config:Get("scale_prop_cost"):Set(0);
CW.config:Get("default_cash"):Set(20);

CW.hint:Add("Staff", "The staff are here to help you, please respect them.");
CW.hint:Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
CW.hint:Add("Healing", "You can heal players by using the Give command in your inventory.");
CW.hint:Add("Wasteland", "Bored and alone in the wasteland? Travel with a friend.");
CW.hint:Add("Metagaming", "Metagaming is when you use out-of-character information in-character.");
CW.hint:Add("Development", "Develop your character, give them a story to tell.");
CW.hint:Add("Powergaming", "Powergaming is when you force your actions on others.");

CW.kernel:AddFile("resource/fonts/monofonto.ttf");

-- A function to load the radios.
function Atomic:LoadMusicRadios()
	local radios = CW.kernel:RestoreSchemaData("plugins/musicradios/"..game.GetMap());
	
	for k, v in pairs(radios) do
		local entity = ents.Create("cw_music_radio");

		entity:SetAngles(v.angles);
		entity:SetPos(v.position);
		entity:Spawn();
		
		if ( IsValid(entity) ) then
			entity:SetNWBool("Off", v.off);
		end;
		
		if (!v.moveable) then
			local physicsObject = entity:GetPhysicsObject();
			
			if ( IsValid(physicsObject) ) then
				physicsObject:EnableMotion(false);
			end;
		end;
	end;
end;

-- A function to save the radios.
function Atomic:SaveMusicRadios()
	local radios = {};
	
	for k, v in pairs(ents.FindByClass("cw_music_radio")) do
		local physicsObject = v:GetPhysicsObject();
		local moveable;
		
		if ( IsValid(physicsObject) ) then
			moveable = physicsObject:IsMoveable();
		end;
		
		radios[#radios + 1] = {
			off = v:GetNWBool("Off"),
			angles = v:GetAngles(),
			moveable = moveable,
			position = v:GetPos(),
		};
	end;
	
	CW.kernel:SaveSchemaData("plugins/musicradios/"..game.GetMap(), radios);
end;

-- A function to make an explosion.
function Atomic:MakeExplosion(position, scale)
	local explosionEffect = EffectData();
	local smokeEffect = EffectData();
	
	explosionEffect:SetOrigin(position);
	explosionEffect:SetScale(scale);
	smokeEffect:SetOrigin(position);
	smokeEffect:SetScale(scale);
	
	util.Effect("explosion", explosionEffect, true, true);
	util.Effect("cw_effect_smoke", smokeEffect, true, true);
end;

-- A function to get a player's heal amount.
function Atomic:GetHealAmount(player, base)
	return base * (1 + (Clockwork.attributes:Get(player, "Medicine") / (Clockwork.config:Get("medical_effect"):Get() or 50)));
end;

-- A function to get a player's dexterity time.
function Atomic:GetDexterityTime(player, base)
	if (!base) then base = 10; end;

	return base - (player:GetSpecial("A") * (Clockwork.config:Get("agility_effect"):Get() or 0.75));
end;

-- Called when the character info needs to be adjusted.
function Atomic:PlayerAdjustCharacterCreationInfo(player, info, data)
	for k, v in pairs(data.special) do
		info.data["s_"..k] = v;
	end;
end;

function Atomic:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!lightSpawn) then
		player:SetNWInt("Sneak", CW.attributes:Get(player, "Sneak"));
	end;
end;

-- Called at an interval while a player is connected.
function Atomic:PlayerThink(player, curTime, infoTable)
	infoTable.inventoryWeight = CW.plugin:Call("AdjustInvWeight", player, infoTable.inventoryWeight) or infoTable.inventoryWeight;
	infoTable.walkSpeed = CW.plugin:Call("AdjustWalkSpeed", player, infoTable.walkSpeed) or infoTable.walkSpeed;
	infoTable.runSpeed = CW.plugin:Call("AdjustRunSpeed", player, infoTable.runSpeed) or infoTable.runSpeed;
	infoTable.jumpPower = CW.plugin:Call("AdjustJumpPower", player, infoTable.jumpPower) or infoTable.jumpPower;

	if (player:Crouching() and player:GetVelocity() != Vector(0, 0, 0) and player:IsOnGround()) then
		player:ProgressAttribute("sneak", 0.080, true);
	end;
end;

function Atomic:AdjustJumpPower(player, jumpPower)
	local Agility = Atomic.special:GetSpecial(player, "A");

	return jumpPower + (jumpPower * (Agility * 0.05));
end;

function Atomic:AdjustMaxHealth(player, maxHealth)
	local Endurance = Atomic.special:GetSpecial(player, "E");

	if (Endurance) then
		return maxHealth + (Endurance * 10);
	end;
end;

function Atomic:AdjustInvWeight(player, invWeight)
	local Strength = Atomic.special:GetSpecial(player, "S");

	return invWeight + (Strength * 10);
end;

-- Called to adjust a player's walk speed each think.
function Atomic:AdjustWalkSpeed(player, speed)
	local itemTable = player:GetClothesItem();
		
	if (itemTable and itemTable.isPowerArmor) then
		return speed - (speed * 0.10);
	end;
end;

-- Called to adjust a player's run speed each think.
function Atomic:AdjustRunSpeed(player, speed)
	local Agility = Atomic.special:GetSpecial(player, "A");

	return speed + (speed * (Agility * 0.05));
end;

-- A function that adjust the player's max health based on perks and endurance, and then sets their health to the same percentage.
function Atomic:AdjustPlayerHealth(player)
	local percent = player:Health() / player:GetMaxHealth();
	local newMaxHealth = CW.plugin:Call("AdjustMaxHealth", player, 100);

	player:SetMaxHealth(newMaxHealth);
	player:SetHealth(math.Clamp(newMaxHealth * percent, 0, newMaxHealth));
end;

function Atomic:DoFireBullets(entity, bulletInfo)
	local player;

	if (entity:IsPlayer()) then
		player = entity;

		entity = entity:GetActiveWeapon();
	end;
	
	if (entity and entity:IsWeapon()) then
		local itemTable = CW.item:GetByWeapon(entity);
		
		if (itemTable) then
			local originalDamage = bulletInfo.Damage;
			local durability = itemTable:GetData("Condition");
			local drainScale = itemTable.drainScale * CW.config:Get("condition_decrease_scale"):Get();
			local health = itemTable.health;

			if (durability and health) then
				local percent = durability / health;

				bulletInfo.Damage = originalDamage * (itemTable.minimum + percent * (1 - itemTable.minimum));
				bulletInfo.Spread = bulletInfo.Spread * (itemTable.minimum + percent * (1 - itemTable.minimum));
				
				itemTable:SetData("Condition", math.max(durability - drainScale, 0));
			end;

			if (player) then
				if (itemTable.category == "Melee") then
					player:ProgressAttribute("melWep", 0.03, true);
				elseif (itemTable.category == "Energy Weapons") then
					player:ProgressAttribute("enegWep", 0.03, true);
				else
					player:ProgressAttribute("guns", 0.01, true);
				end;
			end;
		end;
	end;
end;

function Atomic:DoTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	local itemTable = player:GetClothesItem();

	if (itemTable) then
		local armor = itemTable:GetData("Armor");

		if (armor) then
			itemTable:SetData("Armor", player:Armor());
		end;
	end;

	if (CW.config:Get("enable_slow_death"):GetBoolean()) then	
		if (player:Health() <= 10 and math.random() <= 0.75) then
			if (CW.player:GetAction(player) != "die") then
				CW.player:SetRagdollState(player, RAGDOLL_FALLENOVER, nil, nil, CW.kernel:ConvertForce(damageInfo:GetDamageForce() * 32));
				
				CW.player:SetAction(player, "die", 120, 1, function()
					if (IsValid(player) and player:Alive()) then
						player:TakeDamage(player:Health() * 2, attacker, inflictor);
					end;
				end);
			end;
		end;
	end;
end;

CW.datastream:Hook("ObjectPhysDesc", function(player, data)
	if (type(data) == "table" and type( data[1] ) == "string") then
		if ( player.objectPhysDesc == data[2] ) then
			local physDesc = data[1];
			
			if (string.len(physDesc) > 80) then
				physDesc = string.sub(physDesc, 1, 80).."...";
			end;
			
			data[2]:SetNetworkedString("physDesc", physDesc);
		end;
	end;
end);

CW.datastream:Listen("GetEntityRelationship", function(player, data)
	local entity = ents.FindByClass(data[1])[1];
			
	return true, entity:Disposition(player);
end);