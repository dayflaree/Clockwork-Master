--[[ 
    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Tattered Shoe";
	ITEM.worth = 1;
	ITEM.model = "models/props_junk/shoe001a.mdl";
	ITEM.weight = 0.1
	ITEM.description = "A smelly old shoe.";
ITEM:Register();