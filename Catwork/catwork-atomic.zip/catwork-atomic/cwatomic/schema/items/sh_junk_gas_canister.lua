--[[ 
    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Gas Canister";
	ITEM.worth = 2;
	ITEM.model = "models/props_junk/gascan001a.mdl";
	ITEM.weight = 1;
	ITEM.description = "A empty can of gasoline.";
ITEM:Register();