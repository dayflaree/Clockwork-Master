--[[ 
    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local THEME = CW.theme:Begin();

-- Called when fonts should be created.
function THEME:CreateFonts()
	surface.CreateFont("ato_Large3D2D", {
		size = CW.kernel:FontScreenScale(2048),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextSmall", {
		size = CW.kernel:FontScreenScale(16),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextTiny", {
		size = CW.kernel:FontScreenScale(12),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_CinematicText", {
		size = CW.kernel:FontScreenScale(18),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextBig", {
		size = CW.kernel:FontScreenScale(18),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_TargetIDText", {
		size = CW.kernel:FontScreenScale(8),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextHuge", {
		size = CW.kernel:FontScreenScale(22),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextBig", {
		size = CW.kernel:FontScreenScale(20),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});


	surface.CreateFont("ato_MainText", {
		size = CW.kernel:FontScreenScale(8),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextSmall", {
		size = CW.kernel:FontScreenScale(10),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextMedium", {
		size = CW.kernel:FontScreenScale(13),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText", {
		size = CW.kernel:FontScreenScale(12),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_small", {
		size = CW.kernel:FontScreenScale(5),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText2", {
		size = CW.kernel:FontScreenScale(20),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_blur", {
		size = CW.kernel:FontScreenScale(12),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_small_blur", {
		size = CW.kernel:FontScreenScale(5),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText2_blur", {
		size = CW.kernel:FontScreenScale(20),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_PrimaryHUDText", {
		size = CW.kernel:FontScreenScale(15),
		weight = 100,
		antialias = true,
		font = "Roboto Condensed Bold"
	});

	surface.CreateFont("ato_PrimaryHUDTextBig", {
		size = CW.kernel:FontScreenScale(18),
		weight = 100,
		antialias = true,
		font = "Roboto Condensed Bold"
	});

	surface.CreateFont("ato_PrimaryHUDTextSmall", {
		size = CW.kernel:FontScreenScale(11),
		weight = 100,
		antialias = true,
		font = "Roboto Condensed Bold"
	});

	surface.CreateFont("ato_PrimaryHUDTextTiny", {
		size = CW.kernel:FontScreenScale(10),
		weight = 100,
		antialias = true,
		font = "Roboto Condensed Bold"
	});

	for k, i in pairs({28, 25, 16, 19, 70, 20}) do
		surface.CreateFont("ato_menu"..i, {
			font = "Tahoma",
			size = i,
			antialias = true,
			weight = 900,
			shadow = true
		})
		
		surface.CreateFont("ato_menu_glow"..i, {
			font = "Tahoma",
			size = i,
			blursize = 4,
			scanlines = 2,
			antialias = true,
			weight = 900
		})
	end;
end;

local function setTextColor(PANEL, color)
	local infoColor = color or CW.option:GetColor("information");
	local colorDarkest = Color(
		math.max(infoColor.r - 180, 0),
		math.max(infoColor.g - 180, 0),
		math.max(infoColor.b - 180, 0),
		180
	);

	for k, v in pairs(PANEL:GetChildren()) do
		local className = v:GetClassName();

		if (v.SetTextColor) then
			v:SetTextColor(infoColor);
		end;

		if (!v.paintSet) then
			if (className == "TextEntry") then
				v:SetDrawBackground(false);

				local textBack = vgui.Create("EditablePanel", PANEL);

				function v:Think()
					local infoColor = CW.option:GetColor("information");

					if (infoColor != self:GetHighlightColor()) then
						self:SetHighlightColor(infoColor);
					end;

					textBack:SetPos(self:GetPos());
					textBack:SetSize(self:GetSize());
				end;

				function textBack:Paint(w, h)
					draw.RoundedBox(0, 0, 0, w, h, colorDarkest);

					surface.SetDrawColor(infoColor);

					for i = 0, 1 do
						surface.DrawOutlinedRect(i, i, w - (i * 2), h - (i * 2));
					end;

					return true;
				end;

				v:MoveToAfter(textBack);

				v.paintSet = true;
			elseif (v:GetTable().ClassName == "DComboBox") then
				function v:Paint(w, h)
					draw.RoundedBox(0, 0, 0, w, h, colorDarkest);

					surface.SetDrawColor(infoColor);

					for i = 0, 1 do
						surface.DrawOutlinedRect(i, i, w - (i * 2), h - (i * 2));
					end;

					draw.SimpleText(self:GetValue(), "DermaDefault", w * 0.01, h * 0.5, infoColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER);

					return true;
				end;

				v.paintSet = true;
			end;
		end;

		if (v:HasChildren()) then
			setTextColor(v, infoColor);
		end;
	end;
end;

-- Called when to initialize the theme.
function THEME:Initialize()
	CW.option:SetColor("target_id", Color(165, 155, 95, 255));
	CW.option:SetColor("background", Color(0, 0, 0, 255));

	CW.option:SetFont("bar_text", "ato_IntroTextTiny");
	CW.option:SetFont("main_text", "ato_MainText");
	CW.option:SetFont("hints_text", "ato_IntroTextTiny");
	CW.option:SetFont("large_3d_2d", "ato_Large3D2D");
	CW.option:SetFont("target_id_text", "ato_TargetIDText");
	CW.option:SetFont("cinematic_text", "ato_CinematicText");
	CW.option:SetFont("date_time_text", "ato_IntroTextSmall");
	CW.option:SetFont("menu_text_big", "ato_MenuTextBig");
	CW.option:SetFont("menu_text_huge", "ato_MenuTextHuge");
	CW.option:SetFont("menu_text_tiny", "ato_MainText");
	CW.option:SetFont("intro_text_big", "ato_IntroTextBig");
	CW.option:SetFont("menu_text_small", "ato_MenuTextSmall");
	CW.option:SetFont("menu_text_medium", "ato_MenuTextMedium");
	CW.option:SetFont("intro_text_tiny", "ato_IntroTextTiny");
	CW.option:SetFont("intro_text_small", "ato_IntroTextSmall");
	CW.option:SetFont("player_info_text", "ato_MainText");
	CW.option:SetFont("hud_text", "ato_HUDText");
	CW.option:SetFont("hud_text_small", "ato_HUDText_small");
	CW.option:SetFont("hud_text_big", "ato_HUDText2");
	CW.option:SetFont("hud_text_blur", "ato_HUDText_blur");
	CW.option:SetFont("hud_text_small_blur", "ato_HUDText_small_blur");
	CW.option:SetFont("hud_text_big_blur", "ato_HUDText2_blur");
	CW.option:SetFont("prim_hud_text", "ato_PrimaryHUDText");
	CW.option:SetFont("prim_hud_text_small", "ato_PrimaryHUDTextSmall");
	CW.option:SetFont("prim_hud_text_tiny", "ato_PrimaryHUDTextTiny");
	CW.option:SetFont("prim_hud_text_big", "ato_PrimaryHUDTextBig");

	for k, i in pairs({28, 25, 16, 19, 70, 20}) do
		CW.option:SetFont("atomic_menu_text_"..i, "ato_menu"..i);
		CW.option:SetFont("atomic_menu_text_glow_"..i, "ato_menu_glow"..i);
	end;

	local color = Color(
		GetConVarNumber("cwTextColorR"), 
		GetConVarNumber("cwTextColorG"), 
		GetConVarNumber("cwTextColorB"), 
		GetConVarNumber("cwTextColorA")
	);

	CW.option:SetColor("basic_form_highlight", color);
	CW.option:SetColor("basic_form_color", color);
	CW.option:SetColor("scoreboard_name", color);
	CW.option:SetColor("scoreboard_desc", color);
	CW.option:SetColor("target_id", color);

	CW.option:SetSound("click_release", "atomic/menu_release.wav");
	CW.option:SetSound("rollover", "atomic/menu_rollover.wav");
	CW.option:SetSound("click", "atomic/menu_rollover.wav");
	CW.option:SetSound("tick", "atomic/menu_rollover1.wav");

	CW.option:SetKey("icon_data_classes", {path = "", size = 32});
	CW.option:SetKey("icon_data_settings", {path = "atomic/hud/menuitems/settings.png", size = 32});
	CW.option:SetKey("icon_data_perks", {path = "atomic/hud/menuitems/perks.png", size = 32});
	CW.option:SetKey("icon_data_donations", {path = "", size = 32});
	CW.option:SetKey("icon_data_system", {path = "atomic/hud/menuitems/system.png", size = 32});
	CW.option:SetKey("icon_data_scoreboard", {path = "atomic/hud/menuitems/scoreboard.png", size = 32});
	CW.option:SetKey("icon_data_inventory", {path = "atomic/hud/menuitems/inventory.png", size = 32});
	CW.option:SetKey("icon_data_directory", {path = "atomic/hud/menuitems/directory.png", size = 32});
	CW.option:SetKey("icon_data_attributes", {path = "atomic/hud/menuitems/skills.png", size = 32});
	CW.option:SetKey("icon_data_special", {path = "atomic/hud/menuitems/special.png", size = 32});
	CW.option:SetKey("icon_data_business", {path = "", size = 32});

	CW.option:SetKey("name_attributes", "Skills");
	CW.option:SetKey("name_attribute", "Skill");
end;

-- Called just before a bar is drawn.
function THEME.module:PreDrawBar(barInfo)
	if (barInfo.text) then
		barInfo.text = string.upper(barInfo.text);
	end;
end;

-- Called just after a bar is drawn.
function THEME.module:PostDrawBar(barInfo)
end;

-- Called when the menu is opened.
function THEME.module:MenuOpened()
	if (CW.Client:HasInitialized() and CW.config:Get("show_menu_blur"):Get()) then
		CW.kernel:RegisterBackgroundBlur("MainMenu", SysTime());
	end;
end;

-- Called when the menu is closed.
function THEME.module:MenuClosed()
	if (CW.Client:HasInitialized()) then
		CW.kernel:RemoveBackgroundBlur("MainMenu");
	end;
end;

-- Called just before the weapon selection info is drawn.
function THEME.module:PreDrawWeaponSelectionInfo(info)
	THEME:DrawAtomicBorder(info)
	info.drawBackground = false;
end;

-- Called when the weapon list is drawn.
function THEME.module:DrawWeaponList(x, y, w, h, alpha, wepType)
	if (wepType == "current" and alpha) then
		local color = CW.option:GetColor("information");
		
		Atomic.Draw:WeaponSelect(x, y, w, h, color);
	end;
end;	

function THEME.module:PaintChatboxBackground(x, y, w, h, alpha)
	local offset = h * 0.02;

	DisableClipping(true);
		THEME:DrawAtomicBorder({
			x = x,
			y = y - offset * 0.5,
			width = w,
			height = h + offset,
			alpha = alpha
		});
	DisableClipping(false);

	return true;
end;

function THEME.module:ChatboxEntryPaint(panel, x, y, w, h)
	local color = CW.option:GetColor("information");
	local colorDarker = Color(
		math.max(color.r - 130, 0),
		math.max(color.g - 130, 0),
		math.max(color.b - 130, 0),
		150
	);
	local colorDarkest = Color(
		math.max(color.r - 150, 0),
		math.max(color.g - 150, 0),
		math.max(color.b - 150, 0),
		180
	);

	draw.RoundedBox(0, 0, 0, w, h, colorDarkest);
//	surface.SetDrawColor(color);

//	for i = 0, 1 do
//		surface.DrawOutlinedRect(i, i, w - (i * 2), h - (i * 2));
//	end;

	panel:DrawTextEntryText(color, colorDarker, color);

	return true;
end;

-- A function to draw a border.
function THEME:DrawAtomicBorder(info)
	local color = CW.option:GetColor("information");
	local colorBlack = Color(10, 10, 10, 255);
	local colorDarker = Color(
		math.max(color.r - 130, 0),
		math.max(color.g - 130, 0),
		math.max(color.b - 130, 0),
		150
	);

	if (info.alpha) then
		colorDarker = ColorAlpha(colorDarker, math.max(0, info.alpha * 0.588));
		colorBlack = ColorAlpha(colorBlack, math.max(0, info.alpha));
		color = ColorAlpha(color, math.max(0, info.alpha));
	end;

--	draw.RoundedBox(0, info.x, info.y, info.width, info.height, colorDarker); --BACKGROUND--

	Atomic.Draw:SimpleBlurBox(info.x, info.y, info.width, info.height, colorDarker, 4);

	if (info.lines) then
		local colorDarkest = Color(
			math.max(color.r - 150, 0),
			math.max(color.g - 150, 0),
			math.max(color.b - 150, 0),
			180
		);

		if (info.alpha) then
			colorDarkest = ColorAlpha(colorDarkest, math.max(0, info.alpha * 0.705));
		end;

		for i = 1, (info.height / 4) - 2 do
			draw.RoundedBox(0, info.x, i * 4 + 5, info.width, 1, colorDarkest);
		end;
	end;
	
	DisableClipping(true);
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + 1, info.width + 6, 2, color, "down");
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + info.height - 3, info.width + 6, 2, color, "up");

		Atomic.Draw:ShadowedLine(info.x - 3, info.y + 3, 2, 12, color, "rightdown");
		Atomic.Draw:ShadowedLine(info.x + info.width + 1, info.y + 3, 2, 12, color, "leftdown");
		
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + info.height - 15, 2, 12, color, "rightup");
		Atomic.Draw:ShadowedLine(info.x + info.width + 1, info.y + info.height - 15, 2, 12, color, "leftup");
	DisableClipping(false);
end;

-- Called just before the local player's information is drawn.
function THEME.module:PreDrawPlayerInfo(boxInfo, information, subInformation)
	THEME:DrawAtomicBorder(boxInfo);
	
	boxInfo.drawBackground = false;
end;

-- Called before the character's background blur is drawn.
function THEME.module:ShouldDrawCharacterBackgroundBlur()
	return CW.config:Get("show_menu_blur"):Get();
end;

local PANEL = {};

-- Called every frame.
function PANEL:Think()
	if (self.animation) then
		self.animation:Run();
	end;
	
	local color = CW.option:GetColor("information");
	local colorBlack = Color(0, 0, 0, 255);
	local colorDisabled = Color(
		math.max(color.r - 170, 0),
		math.max(color.g - 170, 0),
		math.max(color.b - 170, 0),
		255
	);

	if (self:IsHovered()) then
		self:SetTextColor(colorBlack);
	else
		if (self:GetDisabled()) then
			self:SetTextColor(self.OverrideColorHover or colorDisabled);
		else
			self:SetTextColor(self.OverrideColorNormal or color);
		end;
	end;
	
	self:SetExpensiveShadow(1, Color(0, 0, 0, 150));
end;

-- A function to set the panel's Callback.
function PANEL:SetCallback(Callback)
	self.DoClick = function(button)
		surface.PlaySound("atomic/pipboy_t3_press.wav");
		Callback(button);
	end;
end;

vgui.Register("cwMenuLblBtn", PANEL, "cwLabelButton");

local lerpStart;
local lerpTarget;
local lerpOrigin;

-- Fade In/Out Time.
local lerpDuration = 2;

local currentMat = nil;
local nextMat = nil;
local backMat = Material("srp/fnv/menu_background.png");

local images = {};

-- We do it this way so I don't have to type out each and every material manually (Thank god).
local loadTypes = {
	billboard = 9,
	building = 3,
	bulletinboard = 9,
	desktop = 8,
	magazines = 3,
	posters = 3	
};

for k, v in pairs(loadTypes) do
	for i = 1, v do
		images[#images + 1] = Material("srp/fnv/loading/loading_"..k.."0"..i..".png");
	end;
end;

function Atomic:nextImage()
	lerpStart = CurTime();
	lerpTarget = 255;
	lerpOrigin = 0;

	currentMat = nextMat or backMat;
	nextMat = images[math.random(1, #images)];
end;

-- Called before the character menu has initialized.
function THEME.hooks:PreCharacterMenuInit(panel)
	local smallTextFont = CW.option:GetFont("menu_text_medium");
	local scrH = ScrH();
	local scrW = ScrW();

	local mainButtonX = ScrW() * 0.55;
	local mainButtonY = ScrH() * 0.4;
		
	panel:SetPos(0, 0);
	panel:SetSize(scrW, scrH);
	panel:SetDrawOnTop(false)
	panel:SetPaintBackground(false);
	panel:SetMouseInputEnabled(true);
			
	local schemaLogo = CW.option:GetKey("schema_logo")
	
	panel.createButton = vgui.Create("cwMenuLblBtn", panel);
	panel.createButton:SetFont(smallTextFont);
	panel.createButton:SetText("NEW");
	panel.createButton:FadeIn(0.5);
	panel.createButton:SetCallback(function(panel)
		if (table.Count(CW.character:GetAll()) >= CW.player:GetMaximumCharacters()) then
			return CW.character:SetFault("You cannot create any more characters!");
		end;
		
		CW.character:ResetCreationInfo();
		CW.character:OpenNextCreationPanel();
	end);
	panel.createButton:SizeToContents();
	panel.createButton:SetMouseInputEnabled(true);
	panel.createButton:SetPos(mainButtonX, mainButtonY);
	
	mainButtonY = mainButtonY + panel.createButton:GetTall();
		
	panel.loadButton = vgui.Create("cwMenuLblBtn", panel);
	panel.loadButton:SetFont(smallTextFont);
	panel.loadButton:SetText("LOAD");
	panel.loadButton:FadeIn(0.5);
	
	panel.loadButton:SetCallback(function(PANEL)
		panel:OpenPanel("cwCharacterList", nil, function(PANEL)
			CW.character:RefreshPanelList();
		end);
	end);
	
	panel.loadButton:SizeToContents();
	panel.loadButton:SetMouseInputEnabled(true);
	panel.loadButton:SetPos(mainButtonX, mainButtonY);

	mainButtonY = mainButtonY + panel.createButton:GetTall();

	panel.aboutButton = vgui.Create("cwMenuLblBtn", panel);
	panel.aboutButton:SetFont(smallTextFont);
	panel.aboutButton:SetText("FORUMS");
	panel.aboutButton:SetAlpha(0);
	panel.aboutButton:FadeIn(1);
	
	panel.aboutButton:SetCallback(function(panel)
		gui.OpenURL(CW.option:GetKey("menu_forum_url"));
	end);

	panel.aboutButton:SizeToContents();
	panel.aboutButton:SetMouseInputEnabled(true);
	panel.aboutButton:SetPos(mainButtonX, mainButtonY);

	mainButtonY = mainButtonY + panel.createButton:GetTall();

	panel.disconnectButton = vgui.Create("cwMenuLblBtn", panel);
	panel.disconnectButton:SetFont(smallTextFont);
	panel.disconnectButton:SetText("DISCONNECT");
	panel.disconnectButton:FadeIn(0.5);
	panel.disconnectButton:SetCallback(function(panel)
		if (CW.Client:HasInitialized() and !CW.character:IsMenuReset()) then
			CW.character:SetPanelMainMenu();
			CW.character:SetPanelOpen(false);
		else
			RunConsoleCommand("disconnect");
		end;
	end);
	panel.disconnectButton:SizeToContents();
	panel.disconnectButton:SetPos(mainButtonX, mainButtonY);
	panel.disconnectButton:SetMouseInputEnabled(true);
	
	panel.previousButton = vgui.Create("cwMenuLblBtn", panel);
	panel.previousButton:SetFont(smallTextFont);
	panel.previousButton:SetText("PREVIOUS");
	panel.previousButton:SetCallback(function(panel)
		if (!CW.character:IsCreationProcessActive()) then
			local activePanel = CW.character:GetActivePanel();
			
			if (activePanel and activePanel.OnPrevious) then
				activePanel:OnPrevious();
			end;
		else
			CW.character:OpenPreviousCreationPanel()
		end;
	end);
	panel.previousButton:SizeToContents();
	panel.previousButton:SetMouseInputEnabled(true);
	panel.previousButton:SetPos((scrW * 0.2) - (panel.previousButton:GetWide() / 2), scrH * 0.9);
	
	panel.nextButton = vgui.Create("cwMenuLblBtn", panel);
	panel.nextButton:SetFont(smallTextFont);
	panel.nextButton:SetText("NEXT");
	panel.nextButton:SetCallback(function(panel)
		if (!CW.character:IsCreationProcessActive()) then
			local activePanel = CW.character:GetActivePanel();
			
			if (activePanel and activePanel.OnNext) then
				activePanel:OnNext();
			end;
		else
			CW.character:OpenNextCreationPanel()
		end;
	end);
	panel.nextButton:SizeToContents();
	panel.nextButton:SetMouseInputEnabled(true);
	panel.nextButton:SetPos((scrW * 0.8) - (panel.nextButton:GetWide() / 2), scrH * 0.9);
	
	panel.cancelButton = vgui.Create("cwMenuLblBtn", panel);
	panel.cancelButton:SetFont(smallTextFont);
	panel.cancelButton:SetText("CANCEL");
	panel.cancelButton:SetCallback(function(PANEL)
		panel:ReturnToMainMenu();
	end);
	panel.cancelButton:SizeToContents();
	panel.cancelButton:SetMouseInputEnabled(true);
	panel.cancelButton:SetPos((scrW * 0.5) - (panel.cancelButton:GetWide() / 2), scrH * 0.9);
	
	panel.characterModel = vgui.Create("cwCharacterModel", panel);
	panel.characterModel:SetSize(512, 512);
	panel.characterModel:SetAlpha(0);
	panel.characterModel:SetModel("models/error.mdl");
	panel.createTime = SysTime();

	return true;
end;

-- Called after the character menu has initialized.
function THEME.hooks:PostCharacterMenuInit(panel) end;

-- Called before the character menu fades in its title elements.
function THEME.hooks:PreCharacterFadeInTitle(panel)
	panel.createButton:FadeIn(0.5)
	panel.loadButton:FadeIn(0.5)
	panel.aboutButton:FadeIn(0.5)
	panel.disconnectButton:FadeIn(0.5)

	return true;
end;

-- Called before the character menu fades out its title elements.
function THEME.hooks:PreCharacterFadeOutTitle(panel)
	panel.createButton:FadeOut(0.5)
	panel.loadButton:FadeOut(0.5)
	panel.aboutButton:FadeOut(0.5)
	panel.disconnectButton:FadeOut(0.5)

	return true;
end;

-- Called every frame that the character menu is open.
function THEME.hooks:PreCharacterMenuThink(panel)
	local characters = table.Count(CW.character:GetAll());
	local bIsLoading = CW.character:IsPanelLoading();
	local schemaLogo = CW.option:GetKey("schema_logo");
	local activePanel = CW.character:GetActivePanel();
	local fault = CW.character:GetFault();
		
	if (CW.plugin:Call("ShouldDrawCharacterBackgroundBlur")) then
		CW.kernel:RegisterBackgroundBlur(panel, panel.createTime);
	else
		CW.kernel:RemoveBackgroundBlur(panel);
	end;
		
	if (panel.characterModel) then
		if (!panel.characterModel.currentModel
		or panel.characterModel.currentModel == "models/error.mdl") then
			panel.characterModel:SetAlpha(0);
		end;
	end;
		
	if (!CW.character:IsCreationProcessActive()) then
		if (activePanel) then
			if (activePanel.GetNextDisabled
			and activePanel:GetNextDisabled()) then
				panel.nextButton:SetDisabled(true);
			else
				panel.nextButton:SetDisabled(false);
			end;
				
			if (activePanel.GetPreviousDisabled
			and activePanel:GetPreviousDisabled()) then
				panel.previousButton:SetDisabled(true);
			else
				panel.previousButton:SetDisabled(false);
			end;
		end;
	else
		local previousPanelInfo = CW.character:GetPreviousCreationPanel();
			
		if (previousPanelInfo) then
			panel.previousButton:SetDisabled(false);
		else
			panel.previousButton:SetDisabled(true);
		end;
			
		panel.nextButton:SetDisabled(false);
	end;
		
	if (characters == 0 or bIsLoading) then
		panel.loadButton:SetDisabled(true);
	else
		panel.loadButton:SetDisabled(false);
	end;
		
	if (characters >= CW.player:GetMaximumCharacters() or CW.character:IsPanelLoading() or CW.config:Get("is_s2k"):Get()) then
		panel.createButton:SetDisabled(true);
	else
		panel.createButton:SetDisabled(false);
	end;

	if (LocalPlayer():HasInitialized() and !CW.character:IsMenuReset()) then
		panel.disconnectButton:SetText("CANCEL");
		panel.disconnectButton:SizeToContents();
	else
		panel.disconnectButton:SetText("DISCONNECT");
		panel.disconnectButton:SizeToContents();
	--	panel.disconnectButton:SetPos(ScrW() * 0.70, ScrH() * 0.85);
	end;

	if (panel.animation) then
		panel.animation:Run();
	end;
		
	panel:SetSize(ScrW(), ScrH());

	return true;
end;

local logoMat = Material("srp/fnv/fnv_logo_base.png");
local boltMat = Material("srp/fnv/fnv_logo_bolt_bloom.png");
local neonMat = Material("srp/fnv/fnv_logo_neon_bloom3.png");

local colorBlack = Color(0, 0, 0, 255);
local colorWhite = Color(255, 255, 255, 255);

-- Called after the character menu is painted.
function THEME.hooks:PreCharacterMenuPaint(panel)
	local scrW, scrH = ScrW(), ScrH();
	local schemaLogo = CW.option:GetKey("schema_logo");
	local subLabelAlpha = panel.createButton:GetAlpha();
	local color = CW.option:GetColor("information");
	local curTime = CurTime();
	local communityLogo = CW.option:GetKey("community_logo");

	draw.RoundedBox(0, 0, 0, scrW, scrH, colorBlack);

	local fraction = nil;
	local imageAlpha = 0;

	if (lerpStart) then
		fraction = (curTime - lerpStart) / lerpDuration;
		imageAlpha = Lerp(fraction, lerpOrigin, lerpTarget);
	end;

	-- Draw background images.
	surface.SetDrawColor(colorWhite.r, colorWhite.g, colorWhite.b, 255 - imageAlpha);
	surface.SetMaterial(currentMat or backMat);
	surface.DrawTexturedRect(0, 0, scrW, scrH);

	if (nextMat) then
		surface.SetDrawColor(colorWhite.r, colorWhite.g, colorWhite.b, imageAlpha);
		surface.SetMaterial(nextMat);
		surface.DrawTexturedRect(0, 0, scrW, scrH);
	end;

	if (subLabelAlpha > 0) then
		local logoW, logoH = 512, 256;
		local logoX, logoY = (scrW * 0.53) - 512, scrH * 0.40;
		local baseAlpha = subLabelAlpha;

		-- Base
		surface.SetDrawColor(colorWhite.r, colorWhite.g, colorWhite.b, baseAlpha);
		surface.SetMaterial(logoMat);
		surface.DrawTexturedRect(logoX, logoY, logoW, logoH);

		local alpha = math.Clamp(baseAlpha - math.abs(math.sin(CurTime()) * (baseAlpha * 0.75)), 0, baseAlpha);
		local boltAlpha = math.Clamp(baseAlpha - math.abs(math.sin(CurTime() + 0.3) * (baseAlpha * 0.30)), 0, baseAlpha);

		-- Lightning Bolt in Logo
		surface.SetDrawColor(colorWhite.r, colorWhite.g, colorWhite.b, boltAlpha);
		surface.SetMaterial(boltMat);
		surface.DrawTexturedRect(logoX, logoY, logoW, logoH);

		-- Neon Lights in Logo
		surface.SetDrawColor(colorWhite.r, colorWhite.g, colorWhite.b, alpha);
		surface.SetMaterial(neonMat);
		surface.DrawTexturedRect(logoX, logoY, logoW, logoH);

		if (!panel.c16) then
			panel.c16 = Material("atomic/c16_logo.png");
		end;

		if (!panel.community) then
			panel.community = Material(communityLogo..".png");				
		end;
			
		if (communityLogo != "") then
			surface.SetDrawColor(color.r, color.g, color.b, subLabelAlpha - 70);
			surface.SetMaterial(panel.community);
			surface.DrawTexturedRect(60, ScrH() - 366, 256, 256);
		end;

		surface.SetDrawColor(color.r, color.g, color.b, subLabelAlpha - 70);
		surface.SetMaterial(panel.c16);
		surface.DrawTexturedRect(60, ScrH() - 110, 256, 80);
	end;
		
	local x, y = panel:CursorPos();
	local canPlay = panel.canPlay;
	local boxX, boxY, boxW, boxH;

	if (subLabelAlpha == 255) then
		THEME:DrawAtomicBorder({
			x = panel.createButton.x - 30,
			y = panel.createButton.y - 30,
			width = 240,
			height = 400
		});

		if (x >= panel.createButton.x and x <= panel.createButton.x + panel.createButton:GetWide()
		and y >= panel.createButton.y and y <= panel.createButton.y + panel.createButton:GetTall()) then
			boxX = panel.createButton.x;
			boxY = panel.createButton.y;
			boxW = panel.createButton:GetWide();
			boxH = panel.createButton:GetTall();

			panel.canPlay = 1;
		elseif (x >= panel.loadButton.x and x <= panel.loadButton.x + panel.loadButton:GetWide()
		and y >= panel.loadButton.y and y <= panel.loadButton.y + panel.loadButton:GetTall()) then
			boxX = panel.loadButton.x;
			boxY = panel.loadButton.y;
			boxW = panel.loadButton:GetWide();
			boxH = panel.loadButton:GetTall();

			panel.canPlay = 2;
		elseif (x >= panel.aboutButton.x and x <= panel.aboutButton.x + panel.aboutButton:GetWide()
		and y >= panel.aboutButton.y and y <= panel.aboutButton.y + panel.aboutButton:GetTall()) then
			boxX = panel.aboutButton.x;
			boxY = panel.aboutButton.y;
			boxW = panel.aboutButton:GetWide();
			boxH = panel.aboutButton:GetTall();

			panel.canPlay = 3;
		elseif (x >= panel.disconnectButton.x and x <= panel.disconnectButton.x + panel.disconnectButton:GetWide()
		and y >= panel.disconnectButton.y and y <= panel.disconnectButton.y + panel.disconnectButton:GetTall()) then
			boxX = panel.disconnectButton.x;
			boxY = panel.disconnectButton.y;
			boxW = panel.disconnectButton:GetWide();
			boxH = panel.disconnectButton:GetTall();	

			panel.canPlay = 4;
		else
			panel.canPlay = nil
		end;
	elseif (panel.previousButton:GetAlpha() == 255) then
		if (x >= panel.previousButton.x and x <= panel.previousButton.x + panel.previousButton:GetWide()
		and y >= panel.previousButton.y and y <= panel.previousButton.y + panel.previousButton:GetTall()) then
			boxX = panel.previousButton.x;
			boxY = panel.previousButton.y;
			boxW = panel.previousButton:GetWide();
			boxH = panel.previousButton:GetTall();	

			panel.canPlay = 5;
		elseif (x >= panel.cancelButton.x and x <= panel.cancelButton.x + panel.cancelButton:GetWide()
		and y >= panel.cancelButton.y and y <= panel.cancelButton.y + panel.cancelButton:GetTall()) then
			boxX = panel.cancelButton.x;
			boxY = panel.cancelButton.y;
			boxW = panel.cancelButton:GetWide();
			boxH = panel.cancelButton:GetTall();	

			panel.canPlay = 6;
		elseif (x >= panel.nextButton.x and x <= panel.nextButton.x + panel.nextButton:GetWide()
		and y >= panel.nextButton.y and y <= panel.nextButton.y + panel.nextButton:GetTall()) then
			boxX = panel.nextButton.x;
			boxY = panel.nextButton.y;
			boxW = panel.nextButton:GetWide();
			boxH = panel.nextButton:GetTall();	

			panel.canPlay = 7;
		else
			panel.canPlay = nil
		end;
	end;

	if (boxX and boxX != nil) then
		boxX = boxX - 10;
		boxW = boxW + 20;

		surface.SetDrawColor(color.r, color.g, color.b, 255);

		if (panel.canPlay > 4) then
			surface.DrawRect(boxX, boxY, boxW, boxH);
		else
			surface.DrawRect(panel.createButton.x - 20, boxY, 220, boxH);
		end;
	end;
		
	if (panel.canPlay and canPlay != panel.canPlay) then
		surface.PlaySound("atomic/pipboy_rollover.wav");
	end;

	return true;
end;

-- Called after a character menu panel is opened.
function THEME.hooks:PostCharacterMenuOpenPanel(panel) end;

-- Called after the main menu has initialized.
function THEME.hooks:PostMainMenuInit(panel) end;

-- Called after the main menu is rebuilt.
function THEME.hooks:PostMainMenuRebuild(panel) end;

-- Called after a main menu panel is opened.
function THEME.hooks:PostMainMenuOpenPanel(panel, panelToOpen) end;

-- Called after the main menu is painted.
function THEME.hooks:PostMainMenuPaint(panel)
	for k, v in pairs(CW.menu:GetItems()) do
		if (IsValid(v.button)) then
			local activePanel = CW.menu:GetActivePanel();
			local offset = -5;
			
			if (v.button.Icon) then
				offset = 35;
				v.button.Icon:SetImageColor(CW.option:GetColor("information"));				
			end;

			if (v.button.LabelButton:GetHovered() or activePanel == v.panel) then
				THEME:DrawAtomicBorder({
					x = v.button.x + offset,
					y = v.button.y - 5,
					width = v.button.LabelButton:GetWide() + 10,
					height = v.button.LabelButton:GetTall() + 10
				});
			end;
		end;
	end;
end;

-- Called every frame that the main menu is open.
function THEME.hooks:PostMainMenuThink(panel) end;

CW.theme:HookReplace("cwScoreboard", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

CW.theme:HookReplace("CW.characterStageTwo", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	setTextColor(PANEL);

	return true;
end);

CW.theme:HookAfter("CW.characterStageTwo", "Init", function(PANEL)
 	function PANEL.categoryList:Paint(w, h)
//		return true;
	end;
	
	if (!CW.faction.stored[PANEL.info.faction].GetName) then
		function PANEL.nameForm:Paint(w, h)
			return true;
		end;
	end;
	
	if (PANEL.bSelectModel or PANEL.bPhysDesc) then
		function PANEL.appearanceForm:Paint(w, h)
			return true;
		end;

		if (PANEL.bSelectModel) then
			function PANEL.modelItemsList:Paint(w, h)
				return true;
			end;
		end;
	end;
end);

CW.theme:HookReplace("DMenu", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	setTextColor(PANEL);

	return true;
end);

CW.theme:HookReplace("CW.storage", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

CW.theme:HookAfter("CW.quiz", "Init", function(PANEL)
	function PANEL.scrollList:Paint(w, h)
		setTextColor(PANEL);

		return true;
	end;

	function PANEL.panelList:Paint(w, h)
		THEME:DrawAtomicBorder({
			x = 0,
			y = 0,
			width = w,
			height = h
		});

		return true;
	end;
end);

CW.theme:HookAfter("CW.storage", "Init", function(PANEL)
 	function PANEL.containerPanel:Paint(w, h)
		return true;
	end;
	
	if (!CW.storage:GetIsOneSided()) then
		function PANEL.inventoryPanel:Paint(w, h)
			return true;
		end;
	end;
end);

CW.theme:HookReplace("cwAttributes", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

CW.theme:HookReplace("cwSettings", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

CW.theme:HookAfter("cwInventory", "Init", function(PANEL)
	PANEL.inventoryList:SetPadding(10);
 	PANEL.inventoryList:SetSpacing(8);
 	PANEL.equipmentList:SetPadding(10);
 	PANEL.equipmentList:SetSpacing(8);

	function PANEL.inventoryList.Paint(invList, w, h)
		THEME:DrawAtomicBorder({
			x = 0,
			y = 0,
			width = w,
			height = h
		});

		return true;
	end;

	function PANEL.equipmentList.Paint(invList, w, h)
		THEME:DrawAtomicBorder({
			x = 0,
			y = 0,
			width = w,
			height = h
		});

		return true;
	end;
end);

local PANEL = {};

-- A function to add a new sheet.
function PANEL:AddSheet(label, panel, material)
	if (!IsValid(panel)) then
		return;
	end;
	
	local newSheet = {};
	
	if (self.ButtonOnly) then
		newSheet.Button = vgui.Create("DImageButton", self.Navigation);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 1, 0, 0);
	else
		newSheet.Button = vgui.Create("cwIconButton", self.Navigation);
		
		local size = CW.fonts:GetSize(CW.option:GetFont("menu_text_tiny"), 20);
	
		newSheet.Button:SetTall(32);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 0, 0, 8);
		newSheet.Button:SetFont(size);
		
		newSheet.Button.Paint = function(sheet, w, h)
			local color = CW.option:GetColor("information");

			sheet:SetColor(color);
			sheet:SetExpensiveShadow(1, color);
		end;
	end;
	
	newSheet.Button:SetImage(material);
	newSheet.Button.Target = panel;
	newSheet.Button:SetText(label);
	newSheet.Button.DoClick = function()
		self:SetActiveButton(newSheet.Button)
	end;
	
	newSheet.Panel = panel;
	newSheet.Panel:SetParent(self.Content);
	newSheet.Panel:SetVisible(false);
	
	if (self.ButtonOnly) then
		newSheet.Button:SizeToContents();
	end;
	
	table.insert(self.Items, newSheet)
	
	if (!IsValid(self.ActiveButton)) then
		self:SetActiveButton(newSheet.Button);
	end;
end;

-- A function to set the active button.
function PANEL:SetActiveButton(active)
	if (self.ActiveButton == active) then
		return;
	end;
	
	if (self.ActiveButton && self.ActiveButton.Target) then	
		self.ActiveButton.Target:SetVisible(false)
		self.ActiveButton:SetSelected(false)

		self.ActiveButton.Paint = function(sheet, w, h)
			local color = CW.option:GetColor("information");

			sheet:SetColor(color);
			sheet:SetExpensiveShadow(1, color);
		end;
	end;

	self.ActiveButton = active;
	
	active.Target:SetVisible(true);
	active:SetSelected(true);

	active.Paint = function(sheet, w, h)
		local color = CW.option:GetColor("information");

		surface.SetDrawColor(color.r, color.g, color.b, 50);
		surface.DrawRect(0, 0, w, h);

		surface.SetDrawColor(color.r, color.g, color.b, alpha);

		for i= 0, 2 do
			surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
		end;

		sheet:SetColor(color);
		sheet:SetExpensiveShadow(1, color);
	end;
	
	self.Content:InvalidateLayout();
end
	
vgui.Register("cwColumnSheet", PANEL, "DColumnSheet");

THEME.skin.frameBorder = Color(255, 255, 255, 255);
THEME.skin.frameTitle = Color(255, 255, 255, 255);

THEME.skin.bgColorBright = Color(255, 255, 255, 255);
THEME.skin.bgColorSleep = Color(70, 70, 70, 255);
THEME.skin.bgColorDark = Color(50, 50, 50, 255);
THEME.skin.bgColor = Color(40, 40, 40, 225);

THEME.skin.controlColorHighlight = Color(70, 70, 70, 255);
THEME.skin.controlColorActive = Color(175, 175, 175, 255);
THEME.skin.controlColorBright = Color(100, 100, 100, 255);
THEME.skin.controlColorDark = Color(30, 30, 30, 255);
THEME.skin.controlColor = Color(60, 60, 60, 255);

THEME.skin.colPropertySheet = Color(255, 255, 255, 255);
THEME.skin.colTabTextInactive = Color(0, 0, 0, 255);
THEME.skin.colTabInactive = Color(255, 255, 255, 255);
THEME.skin.colTabShadow = Color(0, 0, 0, 170);
THEME.skin.colTabText = Color(255, 255, 255, 255);
THEME.skin.colTab = Color(0, 0, 0, 255);

THEME.skin.fontCategoryHeader = "ato_MainText";
THEME.skin.fontMenuOption = "ato_MainText";
THEME.skin.fontFormLabel = "ato_MainText";
THEME.skin.fontButton = "ato_MainText";
THEME.skin.fontFrame = "ato_MainText";
THEME.skin.fontTab = "ato_MainText";

-- A function to draw a generic background.
function THEME.skin:DrawGenericBackground(x, y, w, h, color)
	surface.SetDrawColor(color);
	surface.DrawRect(x, y, w, h);
end;

-- Called when a frame is layed out.
function THEME.skin:LayoutFrame(panel)
	panel.lblTitle:SetFont(self.fontFrame);
	panel.lblTitle:SetText(panel.lblTitle:GetText():upper());
	panel.lblTitle:SetTextColor(Color(0, 0, 0, 255));
	panel.lblTitle:SizeToContents();
	panel.lblTitle:SetExpensiveShadow(nil);
	
	panel.btnClose:SetDrawBackground(true);
	panel.btnClose:SetPos(panel:GetWide() - 22, 2);
	panel.btnClose:SetSize(18, 18);
	panel.lblTitle:SetPos(8, 2);
	panel.lblTitle:SetSize(panel:GetWide() - 25, 20);
end;

-- Called when a form is schemed.
function THEME.skin:SchemeForm(panel)
	panel.Label:SetFont(self.fontFormLabel);
	panel.Label:SetText(panel.Label:GetText():upper());
	panel.Label:SetTextColor(Color(255, 255, 255, 255));
	panel.Label:SetExpensiveShadow(1, Color(0, 0, 0, 200));
end;

-- Called when a tab is painted.
function THEME.skin:PaintTab(panel)
	if (panel:GetPropertySheet():GetActiveTab() == panel) then
		self:DrawGenericBackground(1, 1, panel:GetWide() - 2, panel:GetTall() + 8, self.colTab);
	else
		self:DrawGenericBackground(1, 2, panel:GetWide() - 2, panel:GetTall() + 8, self.colTabInactive);
	end;
end;

-- Called when a list view is painted.
function THEME.skin:PaintListView(panel)
	if (panel.m_bBackground) then
		surface.SetDrawColor(255, 255, 255, 255);
		panel:DrawFilledRect();
	end;
end;
	
-- Called when a list view line is painted.
function THEME.skin:PaintListViewLine(panel)
	local color = Color(50, 50, 50, 255);
	local textColor = Color(255, 255, 255, 255);
	
	if (panel:IsSelected()) then
		color = Color(255, 255, 255, 255);
		textColor = Color(0, 0, 0, 255);
	elseif (panel.Hovered) then
		color = Color(100, 100, 100, 255);
	elseif (panel.m_bAlt) then
		color = Color(75, 75, 75, 255);
	end;
	
	for k, v in pairs(panel.Columns) do
		v:SetTextColor(textColor);
	end;
 
	surface.SetDrawColor(color.r, color.g, color.b, color.a);
	surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall());
end;

-- Called when a list view label is schemed.
function THEME.skin:SchemeListViewLabel(panel)
	panel:SetTextInset(3);
	panel:SetTextColor(Color(255, 255, 255, 255));
end;

-- Called when a menu is painted.
function THEME.skin:PaintMenu(panel)
	surface.SetDrawColor(Color(0, 0, 0, 255));
	panel:DrawFilledRect(0, 0, w, h);
end;

-- Called when a menu is painted over.
function THEME.skin:PaintOverMenu(panel) end;

-- Called when a menu option is schemed.
function THEME.skin:SchemeMenuOption(panel)
	panel:SetFGColor(255, 255, 255, 255);
end;

-- Called when a menu option is painted.
function THEME.skin:PaintMenuOption(panel)
	local textColor = Color(255, 255, 255, 255);
	
	if (panel.m_bBackground and panel.Hovered) then
		local color = nil;

		if (panel.Depressed) then
			color = Color(225, 225, 225, 255);
		else
			color = Color(255, 255, 255, 255);
		end;

		surface.SetDrawColor(color.r, color.g, color.b, color.a);
		surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall());
		
		textColor = Color(0, 0, 0, 255);
	end;
	
	panel:SetFGColor(textColor);
end;

-- Called when a menu option is layed out.
function THEME.skin:LayoutMenuOption(panel)
	panel:SetFont(self.fontMenuOption);
	panel:SizeToContents();
	panel:SetWide(panel:GetWide() + 30);
	panel:SetSize(math.max(panel:GetParent():GetWide(), panel:GetWide()), 18);
	
	if (panel.SubMenuArrow) then
		panel.SubMenuArrow:SetSize(panel:GetTall(), panel:GetTall());
		panel.SubMenuArrow:CenterVertical();
		panel.SubMenuArrow:AlignRight();
	end;
end;

-- Called when a button is painted.
function THEME.skin:PaintButton(panel)
	local w, h = panel:GetSize();
	local textColor = Color(255, 255, 255, 255);
	
	if (panel.m_bBackground) then
		local color = Color(0, 0, 0, 255);
		local borderColor = Color(255, 255, 255, 255);
		
		if (panel:GetDisabled()) then
			color = self.controlColorDark;
		elseif (panel.Depressed or panel:GetSelected()) then
			color = Color(255, 255, 255, 255);
			textColor = Color(0, 0, 0, 255);
		elseif (panel.Hovered) then
			color = self.controlColorHighlight;
		end;

		self:DrawGenericBackground(0, 0, w, h, borderColor);
		self:DrawGenericBackground(1, 1, w - 2, h - 2, color);
	end;
	
	panel:SetFGColor(textColor);
end;

-- Called when a scroll bar grip is painted.
function THEME.skin:PaintScrollBarGrip(panel)
	local w, h = panel:GetSize();
	local color = Color(255, 255, 255, 255);

	self:DrawGenericBackground(0, 0, w, h, color);
	self:DrawGenericBackground(2, 2, w - 4, h - 4, Color(0, 0, 0, 255));
end;

CW.theme:Finish(THEME);