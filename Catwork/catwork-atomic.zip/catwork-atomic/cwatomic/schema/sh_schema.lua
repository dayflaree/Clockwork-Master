--[[ 
    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

Schema:SetGlobalAlias("Atomic");

CW.kernel:IncludePrefixed("cl_schema.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");
CW.kernel:IncludePrefixed("cl_intro.lua");
CW.kernel:IncludePrefixed("cl_theme.lua");
CW.kernel:IncludePrefixed("sh_hooks.lua");
CW.kernel:IncludePrefixed("sv_schema.lua");
CW.kernel:IncludePrefixed("sv_hooks.lua");

CW.option:SetKey("default_date", {month = 8, year = 2280, day = 22});
CW.option:SetKey("default_time", {minute = 0, hour = 12, day = 1});

CW.option:SetKey("intro_image", "atomic/atomic_logo_2");
CW.option:SetKey("schema_logo", "atomic/atomic_logo_2");
CW.option:SetKey("community_logo", ""); -- 256 x 256 PNG
CW.option:SetKey("menu_forum_url", "https://google.com");
CW.option:SetKey("menu_music", "");
CW.option:SetKey("model_cash", "models/props_lab/box01a.mdl");

CW.option:SetKey("format_cash", "%a %n");
CW.option:SetKey("name_cash", "Caps");
CW.option:SetKey("format_singular_cash", "%a");
CW.option:SetKey("model_shipment", "models/props_junk/cardboard_box003b.mdl");

CW.option:SetKey("gradient", "srp/fnv/loading/loading_screen01");

CW.quiz:SetEnabled(false);
CW.quiz:AddQuestion("Which game is this server based on?", 2, "Fallout 4.", "Fallout: New Vegas.");
CW.quiz:AddQuestion("What is this server about?", 2, "Leveling up by completing quests, and collecting items to get better gear.", "Developing your character with those around you.");
CW.quiz:AddQuestion("Do you understand that every action and claim can be verified by server logs?", 1, "Yes.", "No.");
CW.quiz:AddQuestion("Do you understand that roleplaying is a hobby and disruptive behavior will not be tolerated?", 1, "Yes.", "No.");
CW.quiz:AddQuestion("Do you understand that you may have to compromise with complete strangers?", 2, "No.", "Yes.");
CW.quiz:AddQuestion("Do you understand that Administrators are your first and best resource for ANY questions or concerns you may have?", 1, "Yes.", "No.");
CW.quiz:AddQuestion("What setting does this server take place in?", 2, "Boston.", "Yuma Proving Grounds.");

CW.attribute.stored = {};

FACTION_CITIZENS_FEMALE = {};
FACTION_CITIZENS_MALE = {};

local dirString = "models/thespireroleplay/humans/";

-- Add all the default player models for the factions.
for k, v in pairs({05, 06, 10, 11, 12, 16, 52, 53, 54, 55, 60, 61}) do
	local group = "group00"..v;

	if (v >= 10) then
		group = "group0"..v;
	end;

	for i = 1, 11 do
		local number = "0"..i;

		if (i >= 10) then
			number = i;
		end;

		if (i == 11 and v == 60) then
			continue;
		end;

		table.insert(FACTION_CITIZENS_FEMALE, dirString..group.."/female_"..number..".mdl");
	end;

	-- Uncomment this for ghoul model.
//	table.insert(FACTION_CITIZENS_FEMALE, dirString..group.."/female_01g.mdl");

	for i = 1, 18 do
		local number = "0"..i;

		if (i >= 10) then
			number = i;
		end;

		table.insert(FACTION_CITIZENS_MALE, dirString..group.."/male_"..number..".mdl");
	end;

	-- Uncomment this for ghoul model.
//	table.insert(FACTION_CITIZENS_MALE, dirString..group.."/male_01g.mdl");
end;

function Atomic:SetSkillUpdate(player, name, amount)
	if (SERVER) then
		CW.datastream:Start(player, "SetSkillUpdate", {name, amount});
	else
		player.skillDisplay = {name = name, amount = amount};
	end;
end;

if (SERVER) then
	-- A function to get a player's attribute as a fraction.
	function CW.attributes:Fraction(player, attribute, fraction, negative)
		local attributeTable = CW.attribute:FindByID(attribute);
		
		if (attributeTable) then
			local maximum = attributeTable.maximum;
			local amount = self:Get(player, attribute, nil, negative) or 0;
			
			if (amount < 0 and type(negative) == "number") then
				fraction = negative;
			end;
			
			if (!attributeTable.cache[amount][fraction]) then
				attributeTable.cache[amount][fraction] = (fraction / maximum) * amount;
			end;
			
			return attributeTable.cache[amount][fraction];
		else
			return 0;
		end;
	end;
else
	-- A function to get the local player's attribute as a fraction.
	function CW.attributes:Fraction(attribute, fraction, negative)
		local attributeTable = CW.attribute:FindByID(attribute);
		
		if (attributeTable) then
			local maximum = attributeTable.maximum;
			local amount = self:Get(attribute, nil, negative) or 0;
			
			if (amount < 0 and type(negative) == "number") then
				fraction = negative;
			end;
			
			if (!attributeTable.cache[amount][fraction]) then
				attributeTable.cache[amount][fraction] = (fraction / maximum) * amount;
			end;
			
			return attributeTable.cache[amount][fraction];
		else
			return 0;
		end;
	end;
end;