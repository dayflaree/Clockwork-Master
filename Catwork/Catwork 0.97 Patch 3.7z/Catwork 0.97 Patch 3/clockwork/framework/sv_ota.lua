--[[
	
--]]

local playerMeta = FindMetaTable("Player");
playerMeta.ClockworkSteamID64 = playerMeta.ClockworkSteamID64 or playerMeta.SteamID64;

function playerMeta:SteamID64()
	local value = self:ClockworkSteamID64();
 
	if (value == nil) then
		print("[Clockwork] Temporary fix for SteamID64 has been used.");
		return "";
	else
		return value;
	end;
end;

concommand.Add("gm_save", function(ply)
	MsgN("[Clockwork] "..ply:Name().." tried to use gm_save -- beware!");
end);

function AddRestartMessage(message)
	if (CW_RESTART_MESSAGE == nil) then
		CW_RESTART_MESSAGE = message;
	else
		CW_RESTART_MESSAGE = CW_RESTART_MESSAGE..", "..message;
	end;
 
	CW_RESTART_LEVEL = true;
end;

if (!system.IsLinux()) then
	require("tmysql4");
else
	require("mysqloo");
end;

function CW.kernel:ModifyPhysDesc(description)
	if (string.len(description) <= 256) then
		if (!string.find(string.sub(description, -2), "%p")) then
			return description..".";
		else
			return description;
		end;
	else
		return string.sub(description, 1, 253).."...";
	end;
end;

function SimpleBan(name, steamId, duration, reason, fullTime)
	if (not fullTime) then
		duration = os.time() + duration;
	end;
 
	CW.bans.stored[steamId] = {
		unbanTime = duration,
		steamName = name,
		duration = duration,
		reason = reason
	};
end;

function CW:LoadPostSchemaExternals()
	SimpleBan("kurozael", "STEAM_0:1:8387555", 1460410678, "Being a nasty person.", true);
end;

function CW:LoadPreSchemaExternals()
	plugin.__Register = plugin.__Register or plugin.Register;
	plugin.__Add = plugin.__Add or plugin.Add;
	
	function plugin.Register(...)
		plugin.__Register(...);
 
		if (plugin.ClearHookCache) then
			plugin.ClearHookCache();
			plugin.sortedModules = nil;
			plugin.sortedPlugins = nil;
		end;
	end;
	
	function plugin.Add(...)
		plugin.__Add(...);
	 
		if (plugin.ClearHookCache) then
			plugin.ClearHookCache();
			plugin.sortedModules = nil;
			plugin.sortedPlugins = nil;
		end;
	end;
 
	if (cwXCS) then
		--ErrorNoHalt("Disabling CrossServerChat::ClockworkDatabaseConnected hook.\n");
		cwXCS.ClockworkDatabaseConnected = nil;
	end;


	function CW.player:RestoreData(player, data)
		for k, v in pairs(data) do
			self:UpdatePlayerData(player, k, v);
		end;
		
		for k, v in pairs(self.playerData) do
			if (data[k] == nil) then
				player:SetData(k, v.default);
			end;
		end;
	end;
	
	function CW.player:RestoreCharacterData(player, data)
		for k, v in pairs(data) do
			self:UpdateCharacterData(player, k, v);
		end;
	 
		for k, v in pairs(self.characterData) do
			if (data[k] == nil) then
				player:SetCharacterData(k, v.default);
			end;
		end;
	end;
	
	function CW.player:UpdateCharacterData(player, key, value)
		local characterData = self.characterData;
		
		if (characterData[key]) then
			if (characterData[key].callback) then
				value = characterData[key].callback(player, value);
			end;
			
			player:SetSharedVar(key, value);
		end;
	end;

	function CW.player:UpdatePlayerData(player, key, value)
		local playerData = self.playerData;
		
		if (playerData[key]) then
			if (playerData[key].callback) then
				value = playerData[key].callback(player, value);
			end;
			
			player:SetSharedVar(key, value);
		end;
	end;
	
	CW.lang.fileList = CW.lang.fileList or {};
	
	function CW.lang:Add(language, fileName)
		if (not self.fileList[language]) then
			self.fileList[language] = {};
		end;
	 
		table.insert(self.fileList[language], fileName);
	end;
	
	function CW.lang:Set(language) end;
	
	function CW.inventory:SendUpdateByInstance(player, itemTable)
		if (itemTable) then
			netstream.Start(
				player, "InvUpdate", {CW.item:GetDefinition(itemTable, true)}
			);
		end;
	end;
	
	function CW.inventory:SendUpdateAll(player)
		local inventory = player:GetInventory();
 
		for k, v in pairs(inventory) do
			self:SendUpdateByID(player, k);
		end;
	end;
	
	function CW.inventory:SendUpdateByID(player, uniqueID)
		local itemTables = self:GetItemsByID(player:GetInventory(), uniqueID);
	 
		if (itemTables) then
			local definitions = {};
	 
			for k, v in pairs(itemTables) do
				definitions[#definitions + 1] = CW.item:GetDefinition(v, true);
			end;
	 
			netstream.Start(player, "InvUpdate", definitions);
		end;
	end;
	
	function CW.inventory:Rebuild(player)
		CW.kernel:OnNextFrame("RebuildInv"..player:UniqueID(), function()
			if (IsValid(player)) then
				netstream.Start(player, "InvRebuild");
			end;
		end);
	end;

	function SetGameDescription(description)
		function CW:GetGameDescription()
			return "CW: "..description;
		end;
		 
		if (GM) then
			function GM:GetGameDescription()
				return "CW: "..description;
			end;
		end;
		 
		if (GAMEMODE) then
			function GAMEMODE:GetGameDescription()
				return "CW: "..description;
			end;
		end;
	end;
end;