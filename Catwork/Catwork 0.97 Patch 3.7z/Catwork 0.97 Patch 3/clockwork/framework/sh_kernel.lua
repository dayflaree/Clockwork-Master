--[[ 
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

CW.kernel = CW.kernel or {};
CW.Timers = CW.Timers or {};
CW.Libraries = CW.Libraries or {};

--[[
	This is a hack to allow us to call plugin hooks based
	on default GMod hooks that are called.

	It modifies the hook.Call funtion to call hooks inside Clockwork plugins
	as well as hooks that are added normally with hook.Add.
--]]
hook.ClockworkCall = hook.ClockworkCall or hook.Call;

local function ArgsToError(...)
	local args = {...};
	
	for k, v in pairs(args) do
		if (v != nil) then
			MsgC(Color(255, 100, 0), v);
		end;
	end;
	
	MsgC(Color(255, 255, 255), "\n");
end;

function hook.Call(name, gamemode, ...)
	local arguments = {...};
	
	if (CLIENT) then
		if (!IsValid(CW.Client)) then
			CW.Client = LocalPlayer();
			cwClient = CW.Client;
		end;
	else
		if (name == "EntityTakeDamage") then
			if (CW.kernel:DoEntityTakeDamageHook(arguments)) then
				return;
			end;
		elseif (name == "PlayerDisconnected") then
			if (!IsValid(arguments[1])) then
				return;
			end;
		end;
	end;
	
	local bStatus, value, a, b, c = pcall(plugin.RunHooks, name, nil, unpack(arguments));

	if (!bStatus) then
		MsgC(Color(255, 100, 0, 255), "\n[CW:Kernel]\nThe '"..name.."' hook has failed to run.\n");
		ArgsToError(value, a, b, c);
	end;
	
	if (value == nil or name == THINK_NAME) then
		local bStatus, value, a, b, c = pcall(hook.ClockworkCall, name, gamemode or Clockwork, unpack(arguments));
		
		if (!bStatus) then
			MsgC(Color(255, 100, 0, 255), "\n[CW:Kernel]\nThe '"..name.."' gamemode hook failed to run.\n");
			ArgsToError(value, a, b, c);
		else
			return value, a, b, c;
		end;
	else
		return value, a, b, c;
	end;
end;

base64 = base64 or {};
	
local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
-- encoding
function base64.encode(data)
	return ((data:gsub('.', function(x) 
		local r,b='',x:byte()
		for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
		return r;
	end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
		if (#x < 6) then return '' end
		local c=0
		for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
		return b:sub(c+1,c+1)
	end)..({ '', '==', '=' })[#data%3+1])
end

-- decoding
function base64.decode(data)
	data = string.gsub(data, '[^'..b..'=]', '')
	return (data:gsub('.', function(x)
		if (x == '=') then return '' end
		local r,f='',(b:find(x)-1)
		for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
		return r;
	end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
		if (#x ~= 8) then return '' end
		local c=0
		for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
			return string.char(c)
	end))
end

-- A function to convert a single hexadecimal digit to decimal.
function util.HexToDec(hex)
	local hexDigits = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};
	local negative = false;
	
	if (hex:StartWith("-")) then
		hex = hex:sub(2, 2);
		negative = true;
	end;
	
	for k, v in ipairs(hexDigits) do
		if (v == hex) then
			if (!negative) then
				return k - 1;
			else
				return -(k - 1);
			end;
		end;
	end;
	
	ErrorNoHalt("[CatWork] '"..hex.."' is not a hexadecimal number!");
	return 0;
end;

-- A function to convert hexadecimal color to a color structure.
function util.HexToColor(hex)
	if (hex:StartWith("#")) then
		hex = hex:sub(2, hex:len());
	end;
	
	if (hex:len() != 6 and hex:len() != 8) then
		return Color(255, 255, 255);
	end;
	
	local hexColors = {};
	local initLen = hex:len() / 2;
	
	for i = 1, hex:len() / 2 do
		table.insert(hexColors, hex:sub(1, 2))
		
		if (i != initLen) then
			hex = hex:sub(3, hex:len());
		end;
	end;
	
	local color = {};
	
	for k, v in ipairs(hexColors) do
		local chars = table.Reverse(string.Explode("", v));
		local sum = 0;
		
		for i = 1, 2 do
			sum = sum + util.HexToDec(chars[i]) * math.pow(16, i - 1);
		end;
		
		table.insert(color, sum);
	end;
	
	return Color(color[1], color[2], color[3], (color[4] or 255));
end;

-- A helper function to get lowercase name of the data type.
function typeof(obj)
	return string.lower(type(obj));
end;

CW.oldColor = CW.oldColor or Color;

function Color(r, g, b, a)
	if (typeof(r) == "string") then
		return util.HexToColor(r);
	else
		return CW.oldColor(r, g, b, a);
	end;
end;

-- A function to do C-style formatted prints.
function printf(str, ...)
	print(Format(str, ...));
end;

-- Let's face it. When you develop for C++ you kinda want to do this in Lua.
function cout(...)
	print(...);
end;

-- A function to select a random player.
function player.Random()
	local allPly = player.GetAll();

	if (#allPly > 0) then
		return allPly[math.random(1, #allPly)];
	end;
end;

function string.FindAll(str, pattern)
	if (!str or !pattern) then return; end;
	
	local hits = {};
	local lastPos = 1;
	
	while (true) do
		local startPos, endPos = string.find(str, pattern, lastPos);
		
		if (!startPos) then
			break;
		end;
		
		table.insert(hits, {str:sub(startPos, endPos), startPos, endPos})
		
		lastPos = endPos + 1;
	end;
	
	return hits;
end;

--[[
	@codebase Shared
	@details A function to encode a URL.
	@param String The URL to encode.
	@returns String The encoded URL.
--]]
function CW.kernel:URLEncode(url)
	local output = "";
	
	for i = 1, #url do
		local c = string.utf8sub(url, i, i);
		local a = string.byte(c);
		
		if (a < 128) then
			if (a == 32 or a >= 34 and a <= 38 or a == 43 or a == 44 or a == 47 or a >= 58
			and a <= 64 or a >= 91 and a <= 94 or a == 96 or a >= 123 and a <= 126) then
				output = output.."%"..string.format("%x", a);
			else
				output = output..c;
			end;
		end;
	end;
	
	return output;
end;

--[[
	@codebase Shared
	@details A function to get whether two tables are equal.
	@param Table The first unique table to compare.
	@param Table The second unique table to compare.
	@returns Bool Whether or not the tables are equal.
--]]
function CW.kernel:AreTablesEqual(tableA, tableB)
	if (type(tableA) == "table" and type(tableB) == "table") then
		for k, v in pairs(tableA) do
			if (!self:AreTablesEqual(v, tableB[k])) then
				return false;
			end;
		end;

		return true;
	end;
	
	return (tableA == tableB);
end;

--[[
	@codebase Shared
	@details A function to get whether a weapon is a default weapon.
	@param Entity The weapon entity.
	@returns Bool Whether or not the weapon is a default weapon.
--]]
function CW.kernel:IsDefaultWeapon(weapon)
	if (IsValid(weapon)) then
		local class = string.lower(weapon:GetClass());
		if (class == "weapon_physgun" or class == "gmod_physcannon"
		or class == "gmod_tool") then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to format cash.
function CW.kernel:FormatCash(amount, singular, lowerName)
	local formatSingular = CW.option:GetKey("format_singular_cash");
	local formatCash = CW.option:GetKey("format_cash");
	local cashName = CW.option:GetKey("name_cash", lowerName);
	local realAmount = tostring(math.Round(amount));
	
	if (singular) then
		return self:Replace(self:Replace(formatSingular, "%n", cashName), "%a", realAmount);
	else
		return self:Replace(self:Replace(formatCash, "%n", cashName), "%a", realAmount);
	end;
end;

do
	--[[
		Define the default library class.
	--]]
	
	local LIBRARY = {};

	-- A function to add a library function to a metatable.
	function LIBRARY:AddToMetaTable(metaName, funcName, newName)
		local metaTable = FindMetaTable(metaName);
		
		metaTable[newName or funcName] = function(...)
			return self[funcName](self, ...)
		end;
	end;

	-- A function to create a new library.
	function CW.kernel:NewLibrary(libName)
		if (!CW.Libraries[libName]) then
			CW.Libraries[libName] = self:NewMetaTable(LIBRARY);
		end;
		
		return CW.Libraries[libName];
	end;

	-- A function find a library by its name.
	function CW.kernel:FindLibrary(libName)
		return CW.Libraries[libName];
	end;

	-- A function to create a library if it doesn't exist, and then return it.
	function cwLibrary(libName)
		if (!Clockwork[libName]) then
			Clockwork[libName] = CW.kernel:NewLibrary(libName);
		end;

		return Clockwork[libName];
	end;

	-- An alias for the above function.
	function cwLib(libName)
		return cwLibrary(libName);
	end;

	-- A function to create a library and class function.
	function cwClass(name)
		local lib = cwLib(name);
		local CLASS = {__index = CLASS};

		function lib:New(...)
			local obj = CW.kernel:NewMetaTable(CLASS);
				obj = lib[name](obj, ...);
			return obj, lib;
		end;
	end;
end;

if (typeof(library) != "table") then
	library = {};
end;

local libStorage = {};

-- A function to create a new library.
-- if 'parent' is specified, it's going to create
-- a library in that parent table.
-- So if we do library.New("test", teslacode),
-- it is going to create a teslacode.test table.
function library.New(name, parent)
	if (parent and type(parent) == "table") then
		parent[name] = parent[name] or {};
		return parent[name];
	end;

	libStorage[name] = libStorage[name] or {};
	return libStorage[name];
end;

-- A function to get a library.
-- Especially useful for libraries that
-- are stored in the local storage.
function lib(name, parent) 
	if (parent) then
		return parent[name] or {};
	end;
	
	return libStorage[name] or {};
end;

library.New("test", CW);

-- A function to convert a string to a color.
function CW.kernel:StringToColor(text)
	local explodedData = string.Explode(",", text);
	local color = Color(255, 255, 255, 255);
	
	if (explodedData[1]) then
		color.r = tonumber(explodedData[1]:Trim()) or 255;
	end;
	
	if (explodedData[2]) then
		color.g = tonumber(explodedData[2]:Trim()) or 255;
	end;
	
	if (explodedData[3]) then
		color.b = tonumber(explodedData[3]:Trim()) or 255;
	end;
	
	if (explodedData[4]) then
		color.a = tonumber(explodedData[4]:Trim()) or 255;
	end;
	
	return color;
end;

-- A function to get a log type color.
function CW.kernel:GetLogTypeColor(logType)
	local logTypes = {
		Color(255, 50, 50, 255),
		Color(255, 150, 0, 255),
		Color(255, 200, 0, 255),
		Color(0, 150, 255, 255),
		Color(0, 255, 125, 255)
	};
	
	return logTypes[logType] or logTypes[5];
end;

--[[
	@codebase Shared
	@details A function to get the kernel version.
	@returns String The kernel version.
--]]
function CW.kernel:GetVersion()
	return CW.KernelVersion;
end;

--[[
	@codebase Shared
	@details A function to get the kernel build.
	@returns String The kernel build.
--]]
function CW.kernel:GetBuild()
	return CW.KernelBuild;
end;

--[[
	@codebase Shared
	@details A function to get the kernel version and build.
	@returns String The kernel version and build concatenated.
--]]
function CW.kernel:GetVersionBuild()
	if (CW.KernelBuild) then
		return CW.KernelVersion.."-"..CW.KernelBuild;
	else
		return CW.KernelVersion;
	end;
end;

--[[
	@codebase Shared
	@details A function to get the schema folder.
	@returns String The schema folder.
--]]
function CW.kernel:GetSchemaFolder(sFolderName)
	if (sFolderName) then
		return (string.gsub(CW.SchemaFolder, "gamemodes/", "").."/schema/"..sFolderName);
	else
		return (string.gsub(CW.SchemaFolder, "gamemodes/", ""));
	end;
end;

--[[
	@codebase Shared
	@details A function to get the schema gamemode path.
	@returns String The schema gamemode path.
--]]
function CW.kernel:GetSchemaGamemodePath()
	return (string.gsub(CW.SchemaFolder, "gamemodes/", "").."/gamemode");
end;

--[[
	@codebase Shared
	@details A function to get the Clockwork folder.
	@returns String The Clockwork folder.
--]]
function CW.kernel:GetClockworkFolder()
	return (string.gsub(CW.ClockworkFolder, "gamemodes/", ""));
end;

--[[
	@codebase Shared
	@details A function to get the Clockwork path.
	@returns String The Clockwork path.
--]]
function CW.kernel:GetClockworkPath()
	return (string.gsub(CW.ClockworkFolder, "gamemodes/", "").."/framework");
end;

-- A function to get the path to GMod.
function CW.kernel:GetPathToGMod()
	return util.RelativePathToFull("."):sub(1, -2);
end;

-- A function to convert a string to a boolean.
function CW.kernel:ToBool(text)
	if (text == "true" or text == "yes" or text == "1") then
		return true;
	else
		return false;
	end;
end;

-- A function to remove text from the end of a string.
function CW.kernel:RemoveTextFromEnd(text, toRemove)
	local toRemoveLen = string.utf8len(toRemove);
	if (string.utf8sub(text, -toRemoveLen) == toRemove) then
		return (string.utf8sub(text, 0, -(toRemoveLen + 1)));
	else
		return text;
	end;
end;

-- A function to split a string.
function CW.kernel:SplitString(text, interval)
	local length = string.utf8len(text);
	local baseTable = {};
	local i = 0;
	
	while (i * interval < length) do
		baseTable[i + 1] = string.utf8sub(text, i * interval + 1, (i + 1) * interval);
		i = i + 1;
	end;
	
	return baseTable;
end;

-- A function to get whether a letter is a vowel.
function CW.kernel:IsVowel(letter)
	letter = string.lower(letter);
	return (letter == "a" or letter == "e" or letter == "i"
	or letter == "o" or letter == "u");
end;

-- A function to pluralize some text.
function CW.kernel:Pluralize(text)
	if (string.utf8sub(text, -2) != "fe") then
		local lastLetter = string.utf8sub(text, -1);
		
		if (lastLetter == "y") then
			if (self:IsVowel(string.utf8sub(text, string.utf8len(text) - 1, 2))) then
				return string.utf8sub(text, 1, -2).."ies";
			else
				return text.."s";
			end;
		elseif (lastLetter == "h") then
			return text.."es";
		elseif (lastLetter != "s") then
			return text.."s";
		else
			return text;
		end;
	else
		return string.utf8sub(text, 1, -3).."ves";
	end;
end;

-- A function to serialize a table.
function CW.kernel:Serialize(tableToSerialize)
	local bSuccess, value = pcall(von.serialize, tableToSerialize);
  
	if (!bSuccess) then
		print(value);
		return "";  	
	end;
  
	return value;
end;

-- A function to deserialize a string.
function CW.kernel:Deserialize(stringToDeserialize)
	local bSuccess, value = pcall(von.deserialize, stringToDeserialize);
  
	if (!bSuccess) then
		print(value);
		return {};  	
	end;
  
	return value;
end;

-- A function to get ammo information from a weapon.
function CW.kernel:GetAmmoInformation(weapon)
	if (IsValid(weapon) and IsValid(weapon.Owner) and weapon.Primary and weapon.Secondary) then
		if (!weapon.AmmoInfo) then
			weapon.AmmoInfo = {
				primary = {
					ammoType = weapon:GetPrimaryAmmoType(),
					clipSize = weapon.Primary.ClipSize
				},
				secondary = {
					ammoType = weapon:GetSecondaryAmmoType(),
					clipSize = weapon.Secondary.ClipSize
				}
			};
		end;
		
		weapon.AmmoInfo.primary.ownerAmmo = weapon.Owner:GetAmmoCount(weapon.AmmoInfo.primary.ammoType);
		weapon.AmmoInfo.primary.clipBullets = weapon:Clip1();
		weapon.AmmoInfo.primary.doesNotShoot = (weapon.AmmoInfo.primary.clipBullets == -1);
		weapon.AmmoInfo.secondary.ownerAmmo = weapon.Owner:GetAmmoCount(weapon.AmmoInfo.secondary.ammoType);
		weapon.AmmoInfo.secondary.clipBullets = weapon:Clip2();
		weapon.AmmoInfo.secondary.doesNotShoot = (weapon.AmmoInfo.secondary.clipBullets == -1);
		
		if (!weapon.AmmoInfo.primary.doesNotShoot and weapon.AmmoInfo.primary.ownerAmmo > 0) then
			weapon.AmmoInfo.primary.ownerClips = math.ceil(weapon.AmmoInfo.primary.clipSize / weapon.AmmoInfo.primary.ownerAmmo);
		else
			weapon.AmmoInfo.primary.ownerClips = 0;
		end;
		
		if (!weapon.AmmoInfo.secondary.doesNotShoot and weapon.AmmoInfo.secondary.ownerAmmo > 0) then
			weapon.AmmoInfo.secondary.ownerClips = math.ceil(weapon.AmmoInfo.secondary.clipSize / weapon.AmmoInfo.secondary.ownerAmmo);
		else
			weapon.AmmoInfo.secondary.ownerClips = 0;
		end;
		
		return weapon.AmmoInfo;
	end;
end;

-- Called when a player's footstep sound should be played.
function CW:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	if (CLIENT) then return true; end;

	if (!plugin.Call("PrePlayerDefaultFootstep", player, position, foot, sound, volume, recipientFilter)) then
		local itemTable = player:GetClothesItem();
			
		if (itemTable) then
			if ( player:IsRunning() or player:IsJogging() ) then
				if (itemTable.runSound) then
					if (type(itemTable.runSound) == "table") then
						sound = itemTable.runSound[ math.random(1, #itemTable.runSound) ];
					else
						sound = itemTable.runSound;
					end;
				end;
			elseif (itemTable.walkSound) then
				if (type(itemTable.walkSound) == "table") then
					sound = itemTable.walkSound[ math.random(1, #itemTable.walkSound) ];
				else
					sound = itemTable.walkSound;
				end;
			end;
		end;

		player:EmitSound(sound);
		
		return true;
	end;
end;

-- Called when the player's jumping animation should be handled.
function CW:HandlePlayerJumping(player)
	if (!player.m_bJumping and !player:OnGround() and player:WaterLevel() <= 0) then
		player.m_bJumping = true;
		player.m_bFirstJumpFrame = false;
		player.m_flJumpStartTime = 0;
	end
	
	if (player.m_bJumping) then
		if (player.m_bFirstJumpFrame) then
			player.m_bFirstJumpFrame = false;
			player:AnimRestartMainSequence();
		end;
		
		if (player:WaterLevel() >= 2) then
			player.m_bJumping = false;
			player:AnimRestartMainSequence();
		elseif (CurTime() - player.m_flJumpStartTime > 0.2) then
			if (player:OnGround()) then
				player.m_bJumping = false;
				player:AnimRestartMainSequence();
			end
		end
		
		if (player.m_bJumping) then
			player.CalcIdeal = self.animation:GetForModel(player:GetModel(), "jump");
			
			return true;
		end;
	end;
	
	return false;
end;

-- Called when the player's ducking animation should be handled.
function CW:HandlePlayerDucking(player, velocity)
	if (player:Crouching()) then
		local model = player:GetModel();
		local weapon = player:GetActiveWeapon();
		local bIsRaised = self.player:GetWeaponRaised(player, true);
		local velLength = velocity:Length2D();
		local animationAct = "crouch";
		local weaponHoldType = "pistol";
		
		if (IsValid(weapon)) then
			weaponHoldType = self.animation:GetWeaponHoldType(player, weapon);
		
			if (weaponHoldType) then
				animationAct = animationAct.."_"..weaponHoldType;
			end;
		end;
		
		if (bIsRaised) then
			animationAct = animationAct.."_aim";
		end;
		
		if (velLength > 0.5) then
			animationAct = animationAct.."_walk";
		else
			animationAct = animationAct.."_idle";
		end;

		player.CalcIdeal = self.animation:GetForModel(model, animationAct);
		
		return true;
	end;
	
	return false;
end;

-- Called when the player's swimming animation should be handled.
function CW:HandlePlayerSwimming(player)
	if (player:WaterLevel() >= 2) then
		if (player.m_bFirstSwimFrame) then
			player:AnimRestartMainSequence();
			player.m_bFirstSwimFrame = false;
		end;
		
		player.m_bInSwim = true;
	else
		player.m_bInSwim = false;
		
		if (!player.m_bFirstSwimFrame) then
			player.m_bFirstSwimFrame = true;
		end;
	end;
	
	return false;
end;

-- Called when the player's driving animation should be handled.
function CW:HandlePlayerDriving(player)
	if (player:InVehicle()) then
		player.CalcIdeal = self.animation:GetForModel(player:GetModel(), "sit");
		return true;
	end;
	
	return false;
end;

-- Called when a player's animation is updated.
function CW:UpdateAnimation(player, velocity, maxSeqGroundSpeed)
	local velLength = velocity:Length2D();
	local rate = 1.0;
	
	if (velLength > 0.5) then
		rate = ((velLength * 0.8) / maxSeqGroundSpeed);
	end
	
	player.cwPlaybackRate = math.Clamp(rate, 0, 1.5);
	player:SetPlaybackRate(player.cwPlaybackRate);
	
	if (player:InVehicle() and CLIENT) then
		local vehicle = player:GetVehicle();
		
		if (IsValid(vehicle)) then
			local velocity = vehicle:GetVelocity();
			local steer = (vehicle:GetPoseParameter("vehicle_steer") * 2) - 1;
			
			player:SetPoseParameter("vertical_velocity", velocity.z * 0.01);
			player:SetPoseParameter("vehicle_steer", steer);
		end;
	end;
end;

local IdleActivity = ACT_HL2MP_IDLE;
local IdleActivityTranslate = {
	[ACT_MP_ATTACK_CROUCH_PRIMARYFIRE] = IdleActivity + 5,
	[ACT_MP_ATTACK_STAND_PRIMARYFIRE] = IdleActivity + 5,
	[ACT_MP_RELOAD_CROUCH] = IdleActivity + 6,
	[ACT_MP_RELOAD_STAND] = IdleActivity + 6,
	[ACT_MP_CROUCH_IDLE] = IdleActivity + 3,
	[ACT_MP_STAND_IDLE] = IdleActivity,
	[ACT_MP_CROUCHWALK] = IdleActivity + 4,
	[ACT_MP_JUMP] = ACT_HL2MP_JUMP_SLAM,
	[ACT_MP_WALK] = IdleActivity + 1,
	[ACT_MP_RUN] = IdleActivity + 2,
};
	
-- Called when a player's activity is supposed to be translated.
function CW:TranslateActivity(player, act)
	local model = player:GetModel();
	local bIsRaised = self.player:GetWeaponRaised(player, true);
	
	if (string.find(model, "/player/")) then
		local newAct = player:TranslateWeaponActivity(act);
		
		if (!bIsRaised or act == newAct) then
			return IdleActivityTranslate[act];
		else
			return newAct;
		end;
	end;
	
	return act;
end;

-- Called when the main activity should be calculated.
function CW:CalcMainActivity(player, velocity)
	local model = player:GetModel();
	
	ANIMATION_PLAYER = player;
	
	local weapon = player:GetActiveWeapon();
	local bIsRaised = self.player:GetWeaponRaised(player, true);
	local animationAct = "stand";
	local weaponHoldType = "pistol";
	local forcedAnimation = player:GetForcedAnimation();

	if (IsValid(weapon)) then
		weaponHoldType = self.animation:GetWeaponHoldType(player, weapon);
	
		if (weaponHoldType) then
			animationAct = animationAct.."_"..weaponHoldType;
		end;
	end;
	
	if (bIsRaised) then
		animationAct = animationAct.."_aim";
	end;
	
	player.CalcIdeal = self.animation:GetForModel(model, animationAct.."_idle");
	player.CalcSeqOverride = -1;
	
	if (!self:HandlePlayerDriving(player)
	and !self:HandlePlayerJumping(player)
	and !self:HandlePlayerDucking(player, velocity)
	and !self:HandlePlayerSwimming(player)
	and !self:HandlePlayerNoClipping(player, velocity)
	and !self:HandlePlayerVaulting(player, velocity)) then
		local velLength = velocity:Length2D();
				
		if (player:IsRunning() or player:IsJogging()) then
			player.CalcIdeal = self.animation:GetForModel(model, animationAct.."_run");
		elseif (velLength > 0.5) then
			player.CalcIdeal = self.animation:GetForModel(model, animationAct.."_walk");
		end;
		
		if (CLIENT) then
			player:SetIK(false);
		end;
	end;
	
	if (forcedAnimation) then
		player.CalcSeqOverride = forcedAnimation.animation;
		
		if (forcedAnimation.OnAnimate) then
			forcedAnimation.OnAnimate(player);
			forcedAnimation.OnAnimate = nil;
		end;
	end;
	
	if (type(player.CalcSeqOverride) == "string") then
		player.CalcSeqOverride = player:LookupSequence(player.CalcSeqOverride);
	end;
	
	if (type(player.CalcIdeal) == "string") then
		player.CalcSeqOverride = player:LookupSequence(player.CalcIdeal);
	end;
	
	ANIMATION_PLAYER = nil;

	local eyeAngles = player:EyeAngles();
	local yaw = velocity:Angle().yaw;
	local normalized = math.NormalizeAngle(yaw - eyeAngles.y);

	player:SetPoseParameter("move_yaw", normalized);

	return player.CalcIdeal, player.CalcSeqOverride;
end;

-- Called when the animation event is supposed to be done.
function CW:DoAnimationEvent(player, event, data)
	local model = player:GetModel();
	
	if (string.find(model, "/player/")) then
		return self.BaseClass:DoAnimationEvent(player, event, data);
	end;
	
	local weapon = player:GetActiveWeapon();
	local animationAct = "pistol";
	
	if (IsValid(weapon)) then
		weaponHoldType = self.animation:GetWeaponHoldType(player, weapon);
	
		if (weaponHoldType) then
			animationAct = weaponHoldType;
		end;
	end;
	
	if (event == PLAYERANIMEVENT_ATTACK_PRIMARY) then
		local gestureSequence = self.animation:GetForModel(model, animationAct.."_attack");
		
		if (gestureSequence) then
			if (player:Crouching()) then
				player:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, gestureSequence, true);
			else
				player:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, gestureSequence, true);
			end;
		end;
		
		return ACT_VM_PRIMARYATTACK;
	elseif (event == PLAYERANIMEVENT_RELOAD) then
		local gestureSequence = self.animation:GetForModel(model, animationAct.."_reload");

		if (gestureSequence) then
			if (player:Crouching()) then
				player:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, gestureSequence, true);
			else
				player:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, gestureSequence, true);
			end;
		end;
		
		return ACT_INVALID;
	elseif (event == PLAYERANIMEVENT_JUMP) then
		player.m_bJumping = true;
		player.m_bFirstJumpFrame = true;
		player.m_flJumpStartTime = CurTime();
		
		player:AnimRestartMainSequence();
		
		return ACT_INVALID;
	elseif (event == PLAYERANIMEVENT_CANCEL_RELOAD) then
		player:AnimResetGestureSlot(GESTURE_SLOT_ATTACK_AND_RELOAD);
		
		return ACT_INVALID;
	end;

	return nil;
end;

-- Credit to Alex Grist for compiling this map list.
CW.WorkshopMaps = {};
CW.WorkshopMaps["md_venetianredux_b2fix"] = 106094354;
CW.WorkshopMaps["rp_c18_v1"] = 132931674;
CW.WorkshopMaps["rp_c18_v2"] = 132937160;
CW.WorkshopMaps["rp_city8"] = 132913036;
CW.WorkshopMaps["rp_city8_2"] = 132940295;
CW.WorkshopMaps["rp_city8_canals"] = 132911524;
CW.WorkshopMaps["rp_city8_district1"] = 132919876;
CW.WorkshopMaps["rp_city8_district9"] = 132916875;
CW.WorkshopMaps["rp_city11_night_v1b"] = 127632645;
CW.WorkshopMaps["rp_city17_v1"] = 113352748;
CW.WorkshopMaps["rp_city23_night"] = 143076340;
CW.WorkshopMaps["rp_city45_2013"] = 118759412;
CW.WorkshopMaps["rp_city45_catalyst_x1f_final"] = 221567663;
CW.WorkshopMaps["rp_coast_03_fix"] = 132960387;
CW.WorkshopMaps["rp_coast_04"] = 132961866;
CW.WorkshopMaps["rp_coast05"] = 132962296;
CW.WorkshopMaps["rp_coast_07_final"] = 132962909;
CW.WorkshopMaps["rp_coast_09"] = 132963389;
CW.WorkshopMaps["rp_coast_12"] = 132964637;
CW.WorkshopMaps["rp_industrial17_v1"] = 171962560;
CW.WorkshopMaps["rp_lp_industrial17_v1a"] = 386903539;
CW.WorkshopMaps["rp_outercanals"] = 119420070;
CW.WorkshopMaps["rp_shhnexustraining_v1"] = 147818395;
CW.WorkshopMaps["rp_tb_city45_v01"] = 132933551;
CW.WorkshopMaps["rp_tb_city45_v02n"] = 132934734;
CW.WorkshopMaps["rp_tnb_central18nexus_v2"] = 133029448;
CW.WorkshopMaps["rp_venetian_iconoclasm"] = 119692505;
CW.WorkshopMaps["rp_cc_caves_01"] = 242386747;
CW.WorkshopMaps["rp_cc_thecanals_1"] = 263502310;
CW.WorkshopMaps["rp_cc_thecanals_2"] = 268370407;
CW.WorkshopMaps["rp_lp_industrial17_v1a"] = 386903539;
CW.WorkshopMaps["rp_nova_prospekt_v8a_proc"] = 450795921;
CW.WorkshopMaps["rp_lr_refuge_v1"] = 337486491;
CW.WorkshopMaps["rp_nc_industrial17_v2"] = 698222128;
CW.WorkshopMaps["rp_nc_city8_v2a"] = 736405289;

if (SERVER) then
	local ServerLog = ServerLog;
	local cvars = cvars;

	CW.Entities = CW.Entities or {};
	CW.TempPlayerData = CW.TempPlayerData or {};
	CW.HitGroupBonesCache = {
		{"ValveBiped.Bip01_R_UpperArm", HITGROUP_RIGHTARM},
		{"ValveBiped.Bip01_R_Forearm", HITGROUP_RIGHTARM},
		{"ValveBiped.Bip01_L_UpperArm", HITGROUP_LEFTARM},
		{"ValveBiped.Bip01_L_Forearm", HITGROUP_LEFTARM},
		{"ValveBiped.Bip01_R_Thigh", HITGROUP_RIGHTLEG},
		{"ValveBiped.Bip01_R_Calf", HITGROUP_RIGHTLEG},
		{"ValveBiped.Bip01_R_Foot", HITGROUP_RIGHTLEG},
		{"ValveBiped.Bip01_R_Hand", HITGROUP_RIGHTARM},
		{"ValveBiped.Bip01_L_Thigh", HITGROUP_LEFTLEG},
		{"ValveBiped.Bip01_L_Calf", HITGROUP_LEFTLEG},
		{"ValveBiped.Bip01_L_Foot", HITGROUP_LEFTLEG},
		{"ValveBiped.Bip01_L_Hand", HITGROUP_LEFTARM},
		{"ValveBiped.Bip01_Pelvis", HITGROUP_STOMACH},
		{"ValveBiped.Bip01_Spine2", HITGROUP_CHEST},
		{"ValveBiped.Bip01_Spine1", HITGROUP_CHEST},
		{"ValveBiped.Bip01_Head1", HITGROUP_HEAD},
		{"ValveBiped.Bip01_Neck1", HITGROUP_HEAD}
	};
	CW.MeleeTranslation = {
		[ACT_HL2MP_GESTURE_RANGE_ATTACK] = ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE2,
		[ACT_HL2MP_GESTURE_RELOAD] = ACT_HL2MP_GESTURE_RELOAD_MELEE2,
		[ACT_HL2MP_WALK_CROUCH] = ACT_HL2MP_WALK_CROUCH_MELEE2,
		[ACT_HL2MP_IDLE_CROUCH] = ACT_HL2MP_IDLE_CROUCH_MELEE2,
		[ACT_RANGE_ATTACK1] = ACT_RANGE_ATTACK1_MELEE2,
		[ACT_HL2MP_IDLE] = ACT_HL2MP_IDLE_MELEE2,
		[ACT_HL2MP_WALK] = ACT_HL2MP_WALK_MELEE2,
		[ACT_HL2MP_JUMP] = ACT_HL2MP_JUMP_MELEE2,
		[ACT_HL2MP_RUN] = ACT_HL2MP_RUN_MELEE2
	};
	
	-- A function to save schema data.
	function CW.kernel:SaveSchemaData(fileName, data)
		if (type(data) != "table") then
			MsgC(Color(255, 100, 0, 255), "[CW:Kernel] The '"..fileName.."' schema data has failed to save.\nUnable to save type "..type(data)..", table required.\n");
			return;
		end;
	
		return fileio.Write("settings/clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".cw", self:Serialize(data));
	end;

	-- A function to delete schema data.
	function CW.kernel:DeleteSchemaData(fileName)
		return fileio.Delete("settings/clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".cw");
	end;

	-- A function to check if schema data exists.
	function CW.kernel:SchemaDataExists(fileName)
		return _file.Exists("settings/clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".cw", "GAME");
	end;
	
	-- A function to get the schema data path.
	function CW.kernel:GetSchemaDataPath()
		return "settings/clockwork/schemas/"..self:GetSchemaFolder();
	end;
	
	local SCHEMA_GAMEMODE_INFO = nil;
	
	-- A function to get the schema gamemode info.
	function CW.kernel:GetSchemaGamemodeInfo()
		if (SCHEMA_GAMEMODE_INFO) then return SCHEMA_GAMEMODE_INFO; end;
		
		local schemaFolder = string.lower(self:GetSchemaFolder());
		local schemaData = util.KeyValuesToTable(
			fileio.Read("gamemodes/"..schemaFolder.."/"..schemaFolder..".txt")
		);

		if (!schemaData) then
			schemaData = {};
		end;
		
		if (schemaData["Gamemode"]) then
			schemaData = schemaData["Gamemode"];
		end;
		
		SCHEMA_GAMEMODE_INFO = {};
			SCHEMA_GAMEMODE_INFO["name"] = schemaData["title"] or "Undefined";
			SCHEMA_GAMEMODE_INFO["author"] = schemaData["author"] or "Undefined";
			SCHEMA_GAMEMODE_INFO["description"] = schemaData["description"] or "Undefined";
			SCHEMA_GAMEMODE_INFO["version"] = schemaData["version"] or "Undefined";
		return SCHEMA_GAMEMODE_INFO;
	end;
	
	-- A function to get the schema gamemode name.
	function CW.kernel:GetSchemaGamemodeName()
		local schemaInfo = self:GetSchemaGamemodeInfo();
		return schemaInfo["name"];
	end;

	-- A function to get the schema version.
	function CW.kernel:GetSchemaGamemodeVersion()
		local schemaInfo = self:GetSchemaGamemodeInfo();
		return schemaInfo["version"];
	end;
	
	-- A function to find schema data in a directory.
	function CW.kernel:FindSchemaDataInDir(directory)
		return _file.Find("settings/clockwork/schemas/"..self:GetSchemaFolder().."/"..directory, "GAME");
	end;

	-- A function to restore schema data.
	function CW.kernel:RestoreSchemaData(fileName, failSafe)
		if (self:SchemaDataExists(fileName)) then
			local data = fileio.Read("settings/clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".cw", "namedesc");
			
			if (data) then
				local bSuccess, value = pcall(self.Deserialize, self, data);

				if (bSuccess and value != nil) then
					return value;
				else
					MsgC(Color(255, 100, 0, 255), "[CW:Kernel] '"..fileName.."' schema data has failed to restore.\n"..value.."\n");
					
					self:DeleteSchemaData(fileName);
				end;
			end;
		end;
		
		if (failSafe != nil) then
			return failSafe;
		else
			return {};
		end;
	end;

	-- A function to restore Clockwork data.
	function CW.kernel:RestoreClockworkData(fileName, failSafe)
		if (self:ClockworkDataExists(fileName)) then
			local data = fileio.Read("settings/clockwork/"..fileName..".cw");
			
			if (data) then
				local bSuccess, value = pcall(util.JSONToTable, data);
				
				if (bSuccess and value != nil) then
					return value;
				else
					local bSuccess, value = pcall(self.Deserialize, self, data);
					
					if (bSuccess and value != nil) then
						return value;
					else
						MsgC(Color(255, 100, 0, 255), "[CW:Kernel] '"..fileName.."' clockwork data has failed to restore.\n"..value.."\n");
						
						self:DeleteClockworkData(fileName);
					end;
				end;
			end;
		end;
		
		if (failSafe != nil) then
			return failSafe;
		else
			return {};
		end;
	end;
	
	-- A function to setup a full directory.
	function CW.kernel:SetupFullDirectory(filePath)
		local directory = string.gsub(self:GetPathToGMod()..filePath, "\\", "/");
		local exploded = string.Explode("/", directory);
		local currentPath = "";
		
		for k, v in pairs(exploded) do
			if (k < #exploded) then
				currentPath = currentPath..v.."/";
				fileio.MakeDirectory(currentPath);
			end;
		end;
		
		return currentPath..exploded[#exploded];
	end;

	-- A function to save Clockwork data.
	function CW.kernel:SaveClockworkData(fileName, data)
		if (type(data) != "table") then
			MsgC(Color(255, 100, 0, 255), "[CW:Kernel] The '"..fileName.."' clockwork data has failed to save.\nUnable to save type "..type(data)..", table required.\n");
			
			return;
		end;
	
		return fileio.Write("settings/clockwork/"..fileName..".cw", self:Serialize(data));
	end;

	-- A function to check if Clockwork data exists.
	function CW.kernel:ClockworkDataExists(fileName)
		return _file.Exists("settings/clockwork/"..fileName..".cw", "GAME");
	end;

	-- A function to delete Clockwork data.
	function CW.kernel:DeleteClockworkData(fileName)
		return fileio.Delete("settings/clockwork/"..fileName..".cw");
	end;

	-- A function to convert a force.
	function CW.kernel:ConvertForce(force, limit)
		local forceLength = force:Length();
		
		if (forceLength == 0) then
			return Vector(0, 0, 0);
		end;
		
		if (!limit) then
			limit = 800;
		end;
		
		if (forceLength > limit) then
			return force / (forceLength / limit);
		else
			return force;
		end;
	end;
	
	-- A function to save a player's attribute boosts.
	function CW.kernel:SavePlayerAttributeBoosts(player, data)
		local attributeBoosts = player:GetAttributeBoosts();
		local curTime = CurTime();
		
		if (data["AttrBoosts"]) then
			data["AttrBoosts"] = nil;
		end;
		
		if (table.Count(attributeBoosts) > 0) then
			data["AttrBoosts"] = {};
			
			for k, v in pairs(attributeBoosts) do
				data["AttrBoosts"][k] = {};
				
				for k2, v2 in pairs(v) do
					if (v2.duration) then
						if (curTime < v2.endTime) then
							data["AttrBoosts"][k][k2] = {
								duration = math.ceil(v2.endTime - curTime),
								amount = v2.amount
							};
						end;
					else
						data["AttrBoosts"][k][k2] = {
							amount = v2.amount
						};
					end;
				end;
			end;
		end;
	end;
	
	-- A function to calculate a player's spawn time.
	function CW.kernel:CalculateSpawnTime(player, inflictor, attacker, damageInfo)
		local info = {
			attacker = attacker,
			inflictor = inflictor,
			spawnTime = CW.config:Get("spawn_time"):Get(),
			damageInfo = damageInfo
		};

		plugin.Call("PlayerAdjustDeathInfo", player, info);

		if (info.spawnTime and info.spawnTime > 0) then
			CW.player:SetAction(player, "spawn", info.spawnTime, 3);
		end;
	end;
	
	-- A function to create a decal.
	function CW.kernel:CreateDecal(texture, position, temporary)
		local decal = ents.Create("infodecal");
		
		if (temporary) then
			decal:SetKeyValue("LowPriority", "true");
		end;
		
		decal:SetKeyValue("Texture", texture);
		decal:SetPos(position);
		decal:Spawn();
		decal:Fire("activate");
		
		return decal;
	end;
	
	-- A function to handle a player's weapon fire delay.
	function CW.kernel:HandleWeaponFireDelay(player, bIsRaised, weapon, curTime)
		local delaySecondaryFire = nil;
		local delayPrimaryFire = nil;
		
		if (!plugin.Call("PlayerCanFireWeapon", player, bIsRaised, weapon, true)) then
			delaySecondaryFire = curTime + 60;
		end;
		
		if (!plugin.Call("PlayerCanFireWeapon", player, bIsRaised, weapon)) then
			delayPrimaryFire = curTime + 60;
		end;
		
		if (delaySecondaryFire == nil and weapon.secondaryFireDelayed) then
			weapon:SetNextSecondaryFire(weapon.secondaryFireDelayed);
			weapon.secondaryFireDelayed = nil;
		end;
		
		if (delayPrimaryFire == nil and weapon.primaryFireDelayed) then
			weapon:SetNextPrimaryFire(weapon.primaryFireDelayed);
			weapon.primaryFireDelayed = nil;
		end;
		
		if (delaySecondaryFire) then
			if (!weapon.secondaryFireDelayed) then
				weapon.secondaryFireDelayed = weapon:GetNextSecondaryFire();
			end;
			
			--[[
				This is a terrible hotfix for the SMG not being able 
				to fire after loading ammunition.
			--]]
			if (weapon:GetClass() != "weapon_smg1") then
				weapon:SetNextSecondaryFire(delaySecondaryFire);
			end;
		end;
		
		if (delayPrimaryFire) then
			if (!weapon.primaryFireDelayed) then
				weapon.primaryFireDelayed = weapon:GetNextPrimaryFire();
			end;
			
			weapon:SetNextPrimaryFire(delayPrimaryFire);
		end;
	end;
	
	-- A function to scale damage by hit group.
	function CW:ScaleDamageByHitGroup(player, attacker, hitGroup, damageInfo, baseDamage)
		if (!damageInfo:IsFallDamage() and !damageInfo:IsDamageType(DMG_CRUSH)) then
			if (hitGroup == HITGROUP_HEAD) then
				damageInfo:ScaleDamage(self.config:Get("scale_head_dmg"):Get());
			elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_GENERIC) then
				damageInfo:ScaleDamage(self.config:Get("scale_chest_dmg"):Get());
			elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM or hitGroup == HITGROUP_LEFTLEG
			or hitGroup == HITGROUP_RIGHTLEG or hitGroup == HITGROUP_GEAR) then
				damageInfo:ScaleDamage(self.config:Get("scale_limb_dmg"):Get());
			end;
		end;
		
		plugin.Call("PlayerScaleDamageByHitGroup", player, attacker, hitGroup, damageInfo, baseDamage);
	end;
	
	-- A function to calculate player damage.
	function CW.kernel:CalculatePlayerDamage(player, hitGroup, damageInfo)
		local bDamageIsValid = damageInfo:IsBulletDamage() or damageInfo:IsDamageType(DMG_CLUB) or damageInfo:IsDamageType(DMG_SLASH);
		local bHitGroupIsValid = true;
		
		if (CW.config:Get("armor_chest_only"):Get()) then
			if (hitGroup != HITGROUP_CHEST and hitGroup != HITGROUP_GENERIC) then
				bHitGroupIsValid = nil;
			end;
		end;
		
		if (player:Armor() > 0 and bDamageIsValid and bHitGroupIsValid) then
			local armor = player:Armor() - damageInfo:GetDamage();
			
			if (armor < 0) then
				CW.limb:TakeDamage(player, hitGroup, damageInfo:GetDamage() * 2);
				player:SetHealth(math.max(player:Health() - math.abs(armor), 1));
				player:SetArmor(math.max(armor, 0));
			else
				player:SetArmor(math.max(armor, 0));
			end;
		else
			CW.limb:TakeDamage(player, hitGroup, damageInfo:GetDamage() * 2);
			player:SetHealth(math.max(player:Health() - damageInfo:GetDamage(), 1));
		end;
		
		if (damageInfo:IsFallDamage()) then
			CW.limb:TakeDamage(player, HITGROUP_RIGHTLEG, damageInfo:GetDamage());
			CW.limb:TakeDamage(player, HITGROUP_LEFTLEG, damageInfo:GetDamage());
		end;
	end;
	
	-- A function to get a ragdoll's hit bone.
	function CW.kernel:GetRagdollHitBone(entity, position, failSafe, minimum)
		local closest = {};
		
		for k, v in pairs(CW.HitGroupBonesCache) do
			local bone = entity:LookupBone(v[1]);
			
			if (bone) then
				local bonePosition = entity:GetBonePosition(bone);
				
				if (bonePosition) then
					local distance = bonePosition:Distance(position);
					
					if (!closest[1] or distance < closest[1]) then
						if (!minimum or distance <= minimum) then
							closest[1] = distance;
							closest[2] = bone;
						end;
					end;
				end;
			end;
		end;
		
		if (closest[2]) then
			return closest[2];
		else
			return failSafe;
		end;
	end;
	
	-- A function to get a ragdoll's hit group.
	function CW.kernel:GetRagdollHitGroup(entity, position)
		local closest = {nil, HITGROUP_GENERIC};
		
		for k, v in pairs(CW.HitGroupBonesCache) do
			local bone = entity:LookupBone(v[1]);
			
			if (bone) then
				local bonePosition = entity:GetBonePosition(bone);
				
				if (position) then
					local distance = bonePosition:Distance(position);
					
					if (!closest[1] or distance < closest[1]) then
						closest[1] = distance;
						closest[2] = v[2];
					end;
				end;
			end;
		end;
		
		return closest[2];
	end;

	-- A function to create blood effects at a position.
	function CW.kernel:CreateBloodEffects(position, decals, entity, forceVec, fScale)
		if (!entity.cwNextBlood or CurTime() >= entity.cwNextBlood) then
			local effectData = EffectData();
				effectData:SetOrigin(position);
				effectData:SetNormal(forceVec or (VectorRand() * 80));
				effectData:SetScale(fScale or 0.5);
			util.Effect("cw_bloodsmoke", effectData, true, true);
			
			local effectData = EffectData();
				effectData:SetOrigin(position);
				effectData:SetEntity(entity);
				effectData:SetStart(position);
				effectData:SetScale(fScale or 0.5);
			util.Effect("BloodImpact", effectData, true, true);
			
			for i = 1, decals do
				local trace = {};
					trace.start = position;
					trace.endpos = trace.start;
					trace.filter = entity;
				trace = util.TraceLine(trace);
				
				util.Decal("Blood", trace.HitPos + trace.HitNormal, trace.HitPos - trace.HitNormal);
			end;
			
			entity.cwNextBlood = CurTime() + 0.5;
		end;
	end;
	
	-- A function to do the entity take damage hook.
	function CW.kernel:DoEntityTakeDamageHook(arguments)
		local entity = arguments[1];
		local damageInfo = arguments[2];
		
		if (!IsValid(entity)) then
			return;
		end;		
		
		local inflictor = damageInfo:GetInflictor();
		local attacker = damageInfo:GetAttacker();
		local amount = damageInfo:GetDamage();
	
		if (amount != damageInfo:GetDamage()) then
			amount = damageInfo:GetDamage();
		end;
		
		local player = CW.entity:GetPlayer(entity);
		
		if (player) then
			local ragdoll = player:GetRagdollEntity();
			
			hook.Call("PrePlayerTakeDamage", Clockwork, player, attacker, inflictor, damageInfo);
			
			if (!hook.Call("PlayerShouldTakeDamage", Clockwork, player, attacker, inflictor, damageInfo)
			or player:IsInGodMode()) then
				damageInfo:SetDamage(0);
				
				return true;
			end;
			
			if (ragdoll and entity != ragdoll) then
				hook.Call("EntityTakeDamage", Clockwork, ragdoll, damageInfo);
				damageInfo:SetDamage(0);
				
				return true;
			end;
			
			if (entity == ragdoll) then
				local physicsObject = entity:GetPhysicsObject();
				
				if (IsValid(physicsObject)) then
					local velocity = physicsObject:GetVelocity():Length();
					local curTime = CurTime();
					
					if (damageInfo:IsDamageType(DMG_CRUSH)) then
						if (entity.cwNextFallDamage
						and curTime < entity.cwNextFallDamage) then
							damageInfo:SetDamage(0);
							return true;
						end;
						
						amount = hook.Call("GetFallDamage", Clockwork, player, velocity);
						entity.cwNextFallDamage = curTime + 1;
						damageInfo:SetDamage(amount)
					end;
				end;
			end;
		end;
	end;
	
	-- A function to perform the date and time think.
	function CW.kernel:PerformDateTimeThink()
		local defaultDays = CW.option:GetKey("default_days");
		local minute = CW.time:GetMinute();
		local month = CW.date:GetMonth();
		local year = CW.date:GetYear();
		local hour = CW.time:GetHour();
		local day = CW.time:GetDay();
		
		CW.time.minute = CW.time:GetMinute() + 1;

		if (CW.time:GetMinute() >= 60) then
			CW.time.minute = 0;
			CW.time.hour = CW.time:GetHour() + 1;

			if (CW.time:GetHour() >= 24) then
				CW.time.hour = 0;
				CW.time.day = CW.time:GetDay() + 1;
				CW.date.day = CW.date:GetDay() + 1;
				
				if (CW.time:GetDay() == #defaultDays + 1) then
					CW.time.day = 1;
				end;

				if (CW.date:GetDay() >= 31) then
					CW.date.day = 1;
					CW.date.month = CW.date:GetMonth() + 1;

					if (CW.date:GetMonth() >= 13) then
						CW.date.month = 1;
						CW.date.year = CW.date:GetYear() + 1;
					end;
				end;
			end;
		end;
		
		if (CW.time:GetMinute() != minute) then
			plugin.Call("TimePassed", TIME_MINUTE);
		end;
		
		if (CW.time:GetHour() != hour) then
			plugin.Call("TimePassed", TIME_HOUR);
		end;
		
		if (CW.time:GetDay() != day) then
			plugin.Call("TimePassed", TIME_DAY);
		end;
		
		if (CW.date:GetMonth() != month) then
			plugin.Call("TimePassed", TIME_MONTH);
		end;
		
		if (CW.date:GetYear() != year) then
			plugin.Call("TimePassed", TIME_YEAR);
		end;
		
		local month = self:ZeroNumberToDigits(CW.date:GetMonth(), 2);
		local day = self:ZeroNumberToDigits(CW.date:GetDay(), 2);
		
		self:SetSharedVar("Minute", CW.time:GetMinute());
		self:SetSharedVar("Hour", CW.time:GetHour());
		self:SetSharedVar("Date", day.."/"..month.."/"..CW.date:GetYear());
		self:SetSharedVar("Day", CW.time:GetDay());
	end;
	
	-- A function to create a ConVar.
	function CW.kernel:CreateConVar(name, value, flags, Callback)
		local conVar = CreateConVar(name, value, flags or FCVAR_REPLICATED + FCVAR_NOTIFY + FCVAR_ARCHIVE);
		
		cvars.AddChangeCallback(name, function(conVar, previousValue, newValue)
			plugin.Call("ClockworkConVarChanged", conVar, previousValue, newValue);
			
			if (Callback) then
				Callback(conVar, previousValue, newValue);
			end;
		end);
		
		return conVar;
	end;
	
	-- A function to check if the server is shutting down.
	function CW.kernel:IsShuttingDown()
		return CW.ShuttingDown;
	end;
	
	-- A function to distribute wages cash.
	function CW.kernel:DistributeWagesCash()
		local plyTable = cwPlayer.GetAll();

		for k, v in pairs(plyTable) do
			if (v:HasInitialized() and v:Alive()) then
				local info = {
					wages = v:GetWages();
				};
				
				plugin.Call("PlayerModifyWagesInfo", v, info);
				
				if (plugin.Call("PlayerCanEarnWagesCash", v, info.wages)) then
					if (info.wages > 0) then
						if (plugin.Call("PlayerGiveWagesCash", v, info.wages, v:GetWagesName())) then
							CW.player:GiveCash(v, info.wages, v:GetWagesName());
						end;
					end;
					
					plugin.Call("PlayerEarnWagesCash", v, info.wages);
				end;
			end;
		end;
	end;
	
	-- A function to include the schema.
	function CW.kernel:IncludeSchema()
		local schemaFolder = self:GetSchemaFolder();
		
		if (schemaFolder and type(schemaFolder) == "string") then
			CW.config:Load(nil, true);
				plugin.Include(schemaFolder.."/schema", true);
			CW.config:Load();
		end;
	end;
	
	-- A function to print a log message.
	function CW.kernel:PrintLog(logType, text)
		local listeners = {};
		local plyTable = cwPlayer.GetAll();

		for k, v in pairs(plyTable) do
			if (v:HasInitialized() and v:GetInfoNum("cwShowLog", 0) == 1) then
				if (CW.player:IsAdmin(v)) then
					listeners[#listeners + 1] = v;
				end;
			end;
		end;
		
		netstream.Start(listeners, "Log", {
			logType = (logType or 5), text = text
		});
		
		if (CW_CONVAR_LOG:GetInt() == 1 and game.IsDedicated()) then
			self:ServerLog(text);
		end;
	end;
	
	-- A function to log to the server.
	function CW.kernel:ServerLog(text)
		local dateInfo = os.date("*t");
		local unixTime = os.time();
		
		if (dateInfo) then
			if (dateInfo.month < 10) then dateInfo.month = "0"..dateInfo.month; end;
			if (dateInfo.day < 10) then dateInfo.day = "0"..dateInfo.day; end;
			local fileName = dateInfo.year.."-"..dateInfo.month.."-"..dateInfo.day;
			
			if (dateInfo.hour < 10) then dateInfo.hour = "0"..dateInfo.hour; end;
			if (dateInfo.min < 10) then dateInfo.min = "0"..dateInfo.min; end;
			if (dateInfo.sec < 10) then dateInfo.sec = "0"..dateInfo.sec; end;
			local time = dateInfo.hour..":"..dateInfo.min..":"..dateInfo.sec;
			local logText = time..": "..string.gsub(text, "\n", "");

			fileio.Append("logs/clockwork/"..fileName..".log", logText.."\n");
		end;
	
		ServerLog(text.."\n"); plugin.Call("ClockworkLog", text, unixTime);
	end;
	
	-- the function below is from Gristwork i believe.
	-- so kudos to Alex Grist for making this awesome function
	
	-- A function to add workshop collections to the resources.
	function CW.kernel:AddWorkshopCollection(id)
		http.Fetch("http://steamcommunity.com/sharedfiles/filedetails/?id="..id, function(page)
			for k in string.gmatch(page, [[<div id="sharedfile_(.-)" class="collectionItem">]]) do
				resource.AddWorkshop(k);
			end;
		end);
	end;

	do
		if (CW.WorkshopMaps[game.GetMap()]) then
			resource.AddWorkshop(CW.WorkshopMaps[game.GetMap()]);
		else
			resource.AddSingleFile("maps/"..game.GetMap()..".bsp");
		end;

		local workshopCollection = GetConVarString("host_workshop_collection");

		if (workshopCollection != "") then
			CW.kernel:AddWorkshopCollection(workshopCollection)
		end;
	end;
else
	local CreateClientConVar = CreateClientConVar;
	local CloseDermaMenus = CloseDermaMenus;
	local ChangeTooltip = ChangeTooltip;
	local ScreenScale = ScreenScale;
	local FrameTime = FrameTime;
	local DermaMenu = DermaMenu;
	local ScrW = ScrW;
	local ScrH = ScrH;
	local surface = surface;
	local render = render;
	local draw = draw;
	local vgui = vgui;
	local cam = cam;
	local gui = gui;

	CW.BackgroundBlurs = CW.BackgroundBlurs or {};
	CW.RecognisedNames = CW.RecognisedNames or {};
	CW.NetworkProxies = CW.NetworkProxies or {};
	CW.AccessoryData = CW.AccessoryData or {};
	CW.InfoMenuOpen = CW.InfoMenuOpen or false;
	CW.ColorModify = CW.ColorModify or {};
	CW.ClothesData = CW.ClothesData or {};
	CW.Cinematics = CW.Cinematics or {};
	
	CW.kernel.CenterHints = CW.kernel.CenterHints or {};
	CW.kernel.ESPInfo = CW.kernel.ESPInfo or {};
	CW.kernel.Hints = CW.kernel.Hints or {};

	-- A function to register a network proxy.
	function CW.kernel:RegisterNetworkProxy(entity, name, Callback)
		if (!CW.NetworkProxies[entity]) then
			CW.NetworkProxies[entity] = {};
		end;
		
		CW.NetworkProxies[entity][name] = {
			Callback = Callback,
			oldValue = nil
		};
	end;
	
	-- A function to get whether the info menu is open.
	function CW.kernel:IsInfoMenuOpen()
		return CW.InfoMenuOpen;
	end;
	
	-- A function to create a client ConVar.
	function CW.kernel:CreateClientConVar(name, value, save, userData, Callback)
		local conVar = CreateClientConVar(name, value, save, userData);
		
		cvars.AddChangeCallback(name, function(conVar, previousValue, newValue)
			plugin.Call("ClockworkConVarChanged", conVar, previousValue, newValue);
			
			if (Callback) then
				Callback(conVar, previousValue, newValue);
			end;
		end);
		
		return conVar;
	end;
	
	do
		local aspect = ScrW() / ScrH();
		
		function ScreenIsRatio(w, h)
			return (aspect == w / h);
		end;
	end;
	
	-- A function to scale a font size to the screen.
	function CW.kernel:FontScreenScale(size)
		size = size * 3;
		
		if (ScreenIsRatio(16, 9)) then
			return size * (ScrH() / 1080);
		elseif (ScreenIsRatio(16, 10)) then
			return size * (ScrH() / 1200);
		elseif (ScreenIsRatio(4, 3)) then
			return size * (ScrH() / 1024)
		else
			return size * (ScrH() / 1080);
		end;
	end;
	
	-- A function to scale a font size to the screen without multiplying.
	function CW.kernel:HDFontScreenScale(size)
		if (ScreenIsRatio(16, 9)) then
			return size * (ScrH() / 1080);
		elseif (ScreenIsRatio(16, 10)) then
			return size * (ScrH() / 1200);
		elseif (ScreenIsRatio(4, 3)) then
			return size * (ScrH() / 1024)
		else
			return size * (ScrH() / 1080);
		end;
	end;
	
	-- A function to get a material.
	function CW.kernel:GetMaterial(materialPath, pngParameters)
		self.CachedMaterial = self.CachedMaterial or {};

		if (!self.CachedMaterial[materialPath]) then
			self.CachedMaterial[materialPath] = Material(materialPath, pngParameters);
		end;

		return self.CachedMaterial[materialPath];
	end;

	-- A function to get the 3D font size.
	function CW.kernel:GetFontSize3D()
		return self:FontScreenScale(32);
	end;
	
	-- A function to get the size of text.
	function CW.kernel:GetTextSize(font, text)
		local defaultWidth, defaultHeight = self:GetCachedTextSize(font, "U");
		local height = defaultHeight;
		local width = 0;
		local textLength = 0;
		
		for i in string.gmatch(text, "([%z\1-\127\194-\244][\128-\191]*)") do
			local currentCharacter = textLength + 1;
			local textWidth, textHeight = self:GetCachedTextSize(font, string.utf8sub(text, currentCharacter, currentCharacter));

			if (textWidth == 0) then
				textWidth = defaultWidth;
			end;
			
			if (textHeight > height) then
				height = textHeight;
			end;

			width = width + textWidth;
			textLength = textLength + 1;
		end;
		
		return width, height;
	end;
	
	-- A function to calculate alpha from a distance.
	function CW.kernel:CalculateAlphaFromDistance(maximum, start, finish)
		if (type(start) == "Player") then
			start = start:GetShootPos();
		elseif (type(start) == "Entity") then
			start = start:GetPos();
		end;
		
		if (type(finish) == "Player") then
			finish = finish:GetShootPos();
		elseif (type(finish) == "Entity") then
			finish = finish:GetPos();
		end;
		
		return math.Clamp(255 - ((255 / maximum) * (start:Distance(finish))), 0, 255);
	end;
	
	-- A function to wrap text into a table.
	function CW.kernel:WrapText(text, font, maximumWidth, baseTable)
		if (maximumWidth <= 0 or !text or text == "") then
			return;
		end;
		
		if (self:GetTextSize(font, text) > maximumWidth) then
			local currentWidth = 0;
			local firstText = nil;
			local secondText = nil;
			
			for i = 0, #text do
				local currentCharacter = string.utf8sub(text, i, i);
				local currentSingleWidth = self:GetTextSize(font, currentCharacter);
				
				if ((currentWidth + currentSingleWidth) >= maximumWidth) then
					baseTable[#baseTable + 1] = string.utf8sub(text, 0, (i - 1));
					text = string.utf8sub(text, i);
					
					break;
				else
					currentWidth = currentWidth + currentSingleWidth;
				end;
			end;
			
			if (self:GetTextSize(font, text) > maximumWidth) then
				self:WrapText(text, font, maximumWidth, baseTable);
			else
				baseTable[#baseTable + 1] = text;
			end;
		else
			baseTable[#baseTable + 1] = text;
		end;
	end;
	
	-- A function to handle an entity's menu.
	function CW.kernel:HandleEntityMenu(entity)
		local options = {};
		local itemTable = nil;
		
		plugin.Call("GetEntityMenuOptions", entity, options);

		if (entity:GetClass() == "cw_item") then
			itemTable = entity:GetItemTable();
			if (itemTable and itemTable:IsInstance() and itemTable.GetOptions) then
				local itemOptions = itemTable:GetOptions(entity);
				
				for k, v in pairs(itemOptions) do
					options[k] = {
						title = k,
						name = v,
						isOptionTable = true,
						isArgTable = true
					};
				end;
			end;
		end;

		if (table.Count(options) == 0) then return; end;
		
		if (self:GetEntityMenuType()) then
			local menuPanel = self:AddMenuFromData(nil, options, function(menuPanel, option, arguments)
				if (itemTable and type(arguments) == "table" and arguments.isOptionTable) then
					menuPanel:AddOption(arguments.title, function()
						if (itemTable.HandleOptions) then
							local transmit, data = itemTable:HandleOptions(arguments.name, nil, nil, entity);
							
							if (transmit) then
								netstream.Start("MenuOption", {
									option = arguments.name,
									data = data,
									item = itemTable("itemID"),
									entity = entity
								});
							end;
						end;
					end)
				else
					menuPanel:AddOption(option, function()
						if (type(arguments) == "table" and arguments.isArgTable) then
							if (arguments.Callback) then
								arguments.Callback(function(arguments)
									CW.entity:ForceMenuOption(
										entity, option, arguments
									);
								end);
							else
								CW.entity:ForceMenuOption(
									entity, option, arguments.arguments
								);
							end;
						else
							CW.entity:ForceMenuOption(
								entity, option, arguments
							);
						end;
						
						timer.Simple(FrameTime(), function()
							self:RemoveActiveToolTip();
						end);
					end);
				end;
				
				menuPanel.Items = menuPanel:GetChildren();
				local panel = menuPanel.Items[#menuPanel.Items];
				
				if (IsValid(panel)) then
					if (type(arguments) == "table") then
						if (arguments.isOrdered) then
							menuPanel.Items[#menuPanel.Items] = nil;
							table.insert(menuPanel.Items, 1, panel);
						end;
						
						if (arguments.toolTip) then
							self:CreateMarkupToolTip(panel);
							panel:SetMarkupToolTip(arguments.toolTip);
						end;
					end;
				end;
			end);
			
			self:RegisterBackgroundBlur(menuPanel, SysTime());
			self:SetTitledMenu(menuPanel, "INTERACT WITH THIS ENTITY");
			menuPanel.entity = entity;
			
			return menuPanel;
		end;
	end;

	-- A function to get what type of entity menu to use.
	function CW.kernel:GetEntityMenuType()
		return true;
	end;

	-- A function to get the gradient texture.
	function CW.kernel:GetGradientTexture()
		return CW.GradientTexture;
	end;
	
	-- A function to add a menu from data.
	function CW.kernel:AddMenuFromData(menuPanel, data, Callback, iMinimumWidth, bManualOpen)
		local bCreated = false;
		local options = {};
		
		if (!menuPanel) then
			bCreated = true; menuPanel = DermaMenu();
			
			if (iMinimumWidth) then
				menuPanel:SetMinimumWidth(iMinimumWidth);
			end;
		end;
		
		for k, v in pairs(data) do
			options[#options + 1] = {k, v};
		end;
		
		table.sort(options, function(a, b)
			return a[1] < b[1];
		end);
		
		for k, v in pairs(options) do
			if (type(v[2]) == "table" and !v[2].isArgTable) then
				if (table.Count(v[2]) > 0) then
					self:AddMenuFromData(menuPanel:AddSubMenu(v[1]), v[2], Callback);
				end;
			elseif (type(v[2]) == "function") then
				menuPanel:AddOption(v[1], v[2]);
			elseif (Callback) then
				Callback(menuPanel, v[1], v[2]);
			end;
		end;
		
		if (!bCreated) then return; end;
		
		if (!bManualOpen) then
			if (#options > 0) then
				menuPanel:Open();
			else
				menuPanel:Remove();
			end;
		end;
		
		return menuPanel;
	end;
	
	-- A function to adjust the width of text.
	function CW.kernel:AdjustMaximumWidth(font, text, width, addition, extra)
		local textString = tostring(self:Replace(text, "&", "U"));
		local textWidth = self:GetCachedTextSize(font, textString) + (extra or 0);
		
		if (textWidth > width) then
			width = textWidth + (addition or 0);
		end;
		
		return width;
	end;
	
	--[[
		A function to add a center hint. If bNoSound is false then no
		sound will play, otherwise if it is a string then it will
		play that sound.
	--]]
	function CW.kernel:AddCenterHint(text, delay, color, bNoSound, showDuplicated)
		local colorWhite = CW.option:GetColor("white");
		
		if (color) then
			if (type(color) == "string") then
				color = CW.option:GetColor(color);
			end;
		else
			color = colorWhite;
		end;
		
		if (!showDuplicated) then
			for k, v in pairs(self.CenterHints) do
				if (v.text == text) then
					return;
				end;
			end;
		end;
		
		if (table.Count(self.CenterHints) == 10) then
			table.remove(self.CenterHints, 10);
		end;
		
		if (type(bNoSound) == "string") then
			surface.PlaySound(bNoSound);
		elseif (bNoSound == nil) then
			surface.PlaySound("hl1/fvox/blip.wav");
		end;
		
		self.CenterHints[#self.CenterHints + 1] = {
			startTime = SysTime(),
			velocityX = -5,
			velocityY = 0,
			targetAlpha = 255,
			alphaSpeed = 64,
			color = color,
			delay = delay,
			alpha = 0,
			text = text,
			y = ScrH() * 0.6,
			x = ScrW() * 0.5
		};
	end;
	
	local function UpdateCenterHint(index, hintInfo, iCount)
		local hintsFont = CW.option:GetFont("hints_text");
		local fontWidth, fontHeight = CW.kernel:GetCachedTextSize(
			hintsFont, hintInfo.text
		);
		local height = fontHeight;
		local width = fontWidth;
		local alpha = 255;
		local x = hintInfo.x;
		local y = hintInfo.y;
		
		local idealY = (ScrH() * 0.4) + (height * (index - 1));
		local idealX = (ScrW() * 0.5) - (width * 0.5);
		local timeLeft = (hintInfo.startTime - (SysTime() - hintInfo.delay) + 2);
		
		if (timeLeft < 0.7) then
			idealX = idealX - 50;
			alpha = 0;
		end;
		
		if (timeLeft < 0.2) then
			idealX = idealX + width * 2;
		end;
		
		local fSpeed = FrameTime() * 15;
			y = y + hintInfo.velocityY * fSpeed;
			x = x + hintInfo.velocityX * fSpeed;
		local distanceY = idealY - y;
		local distanceX = idealX - x;
		local distanceA = (alpha - hintInfo.alpha);
		
		hintInfo.velocityY = hintInfo.velocityY + distanceY * fSpeed * 1;
		hintInfo.velocityX = hintInfo.velocityX + distanceX * fSpeed * 1;
		
		if (math.abs(distanceY) < 2 and math.abs(hintInfo.velocityY) < 0.1) then
			hintInfo.velocityY = 0;
		end;
		
		if (math.abs(distanceX) < 2 and math.abs(hintInfo.velocityX) < 0.1) then
			hintInfo.velocityX = 0;
		end;
		
		hintInfo.velocityX = hintInfo.velocityX * (0.95 - FrameTime() * 8);
		hintInfo.velocityY = hintInfo.velocityY * (0.95 - FrameTime() * 8);
		hintInfo.alpha = hintInfo.alpha + distanceA * fSpeed * 0.1;
		hintInfo.x = x;
		hintInfo.y = y;
		
		return (timeLeft < 0.1);
	end;
	
	--[[
		A function to add a top hint. If bNoSound is false then no
		sound will play, otherwise if it is a string then it will
		play that sound.
	--]]
	function CW.kernel:AddTopHint(text, delay, color, bNoSound, showDuplicated)
		local colorWhite = CW.option:GetColor("white");
		
		if (color) then
			if (type(color) == "string") then
				color = CW.option:GetColor(color);
			end;
		else
			color = colorWhite;
		end;
		
		if (!showDuplicated) then
			for k, v in pairs(self.Hints) do
				if (v.text == text) then
					return;
				end;
			end;
		end;
		
		if (table.Count(self.Hints) == 10) then
			table.remove(self.Hints, 10);
		end;
		
		if (type(bNoSound) == "string") then
			surface.PlaySound(bNoSound);
		elseif (bNoSound == nil) then
			surface.PlaySound("hl1/fvox/blip.wav");
		end;
		
		self.Hints[#self.Hints + 1] = {
			startTime = SysTime(),
			velocityX = -5,
			velocityY = 0,
			targetAlpha = 255,
			alphaSpeed = 64,
			color = color,
			delay = delay,
			alpha = 0,
			text = text,
			y = ScrH() * 0.2,
			x = ScrW()
		};
	end;

	local function UpdateHint(index, hintInfo, iCount)
		local hintsFont = CW.option:GetFont("hints_text");
		local fontWidth, fontHeight = CW.kernel:GetCachedTextSize(
			hintsFont, hintInfo.text
		);
		local height = fontHeight;
		local width = fontWidth;
		local alpha = 255;
		local x = hintInfo.x;
		local y = hintInfo.y;
		
		local idealY = 24 + (height * (index - 1));
		local idealX = ScrW() - width - 48;
		local timeLeft = (hintInfo.startTime - (SysTime() - hintInfo.delay) + 2);
		
		if (timeLeft < 0.7) then
			idealX = idealX - 50;
			alpha = 0;
		end;
		
		if (timeLeft < 0.2) then
			idealX = idealX + width * 2;
		end;
		
		local fSpeed = FrameTime() * 15;
			y = y + hintInfo.velocityY * fSpeed;
			x = x + hintInfo.velocityX * fSpeed;
		local distanceY = idealY - y;
		local distanceX = idealX - x;
		local distanceA = (alpha - hintInfo.alpha);
		
		hintInfo.velocityY = hintInfo.velocityY + distanceY * fSpeed * 1;
		hintInfo.velocityX = hintInfo.velocityX + distanceX * fSpeed * 1;
		
		if (math.abs(distanceY) < 2 and math.abs(hintInfo.velocityY) < 0.1) then
			hintInfo.velocityY = 0;
		end;
		
		if (math.abs(distanceX) < 2 and math.abs(hintInfo.velocityX) < 0.1) then
			hintInfo.velocityX = 0;
		end;
		
		hintInfo.velocityX = hintInfo.velocityX * (0.95 - FrameTime() * 8);
		hintInfo.velocityY = hintInfo.velocityY * (0.95 - FrameTime() * 8);
		hintInfo.alpha = hintInfo.alpha + distanceA * fSpeed * 0.1;
		hintInfo.x = x;
		hintInfo.y = y;
		
		return (timeLeft < 0.1);
	end;
	
	-- A function to calculate the hints.
	function CW.kernel:CalculateHints()
		for k, v in pairs(self.Hints) do
			if (UpdateHint(k, v, #self.Hints)) then
				table.remove(self.Hints, k);
			end;
		end;
		
		for k, v in pairs(self.CenterHints) do
			if (UpdateCenterHint(k, v, #self.CenterHints)) then
				table.remove(self.CenterHints, k);
			end;
		end;
	end;
	
	-- A utility function to draw text within an info block.
	local function Util_DrawText(info, text, color, bCentered, sFont)
		local realWidth = 0;
		
		if (sFont) then CW.kernel:OverrideMainFont(sFont); end;
		
		if (!bCentered) then
			info.y, realWidth = CW.kernel:DrawInfo(
				text, info.x - (info.width / 2), info.y, color, nil, true
			);
		else
			info.y, realWidth = CW.kernel:DrawInfo(
				text, info.x, info.y, color
			);
		end;
		
		if (realWidth > info.width) then
			info.width = realWidth + 16;
		end;
		
		if (sFont) then
			CW.kernel:OverrideMainFont(false);
		end;
	end;
	
	-- A function to draw the date and time.
	function CW.kernel:DrawDateTime()
		local backgroundColor = CW.option:GetColor("background");
		local mainTextFont = CW.option:GetFont("main_text");
		local colorWhite = CW.option:GetColor("white");
		local colorInfo = CW.option:GetColor("information");
		local scrW = ScrW();
		local scrH = ScrH();
		local info = {
			DrawText = Util_DrawText,
			width = math.min(scrW * 0.5, 512),
			x = scrW / 2,
			y = scrH * 0.2
		};
		
		info.originalX = info.x;
		info.originalY = info.y;
		
		if (CW.LastDateTimeInfo and CW.LastDateTimeInfo.y > info.y) then
			local height = (CW.LastDateTimeInfo.y - info.y) + 8;
			local width = CW.LastDateTimeInfo.width + 16;
			local x = CW.LastDateTimeInfo.x - (CW.LastDateTimeInfo.width / 2) - 8;
			local y = CW.LastDateTimeInfo.y - height - 8;
			
			self:OverrideMainFont(CW.option:GetFont("menu_text_tiny"));
			self:DrawInfo("CHARACTER AND ROLEPLAY INFO", x, y + 4, colorInfo, nil, true, function(x, y, width, height)
				return x, y - height;
			end);
			
			cdraw.DrawBox(x, y + 8, width, height, backgroundColor);
			y = y + height + 16;
			
			if (self:CanCreateInfoMenuPanel() and self:IsInfoMenuOpen()) then
				local menuPanelX = x;
				local menuPanelY = y;
				
				self:DrawInfo("SELECT A QUICK MENU OPTION", x, y, colorInfo, nil, true, function(x, y, width, height)
					menuPanelY = menuPanelY + height + 8;
					return x, y;
				end);
				
				self:CreateInfoMenuPanel(menuPanelX, menuPanelY, width);
				
				cdraw.DrawBox(CW.InfoMenuPanel.x - 4, CW.InfoMenuPanel.y - 4, CW.InfoMenuPanel:GetWide() + 8, CW.InfoMenuPanel:GetTall() + 8, backgroundColor);
				
				--[[ Override the menu's width to fit nicely. --]]
				CW.InfoMenuPanel:SetSize(width, CW.InfoMenuPanel:GetTall());
				CW.InfoMenuPanel:SetMinimumWidth(width);
				
				if (!CW.InfoMenuPanel.VisibilitySet) then
					CW.InfoMenuPanel.VisibilitySet = true;
					
					timer.Simple(FrameTime() * 2, function()
						if (IsValid(CW.InfoMenuPanel)) then
							CW.InfoMenuPanel:SetVisible(true);
						end;
					end);
				end;
			end;
			
			self:OverrideMainFont(false);
			CW.LastDateTimeInfo.height = height;
		end;
		
		if (plugin.Call("PlayerCanSeeDateTime")) then
			local dateTimeFont = CW.option:GetFont("date_time_text");
			local dateString = CW.date:GetString();
			local timeString = CW.time:GetString();
			
			if (dateString and timeString) then
				local dayName = CW.time:GetDayName();
				local text = string.upper(dateString..". "..dayName..", "..timeString..".");
				
				self:OverrideMainFont(dateTimeFont);
					info.y = self:DrawInfo(text, info.x, info.y, colorWhite, 255);
				self:OverrideMainFont(false);
			end;
		end;
		
		self:DrawBars(info, "tab");
			CW.PlayerInfoBox = self:DrawPlayerInfo(info);
			plugin.Call("PostDrawDateTimeBox", info);
		CW.LastDateTimeInfo = info;
		
		if (!plugin.Call("PlayerCanSeeLimbDamage")) then
			return;
		end;
		
		local tipHeight = 0;
		local tipWidth = 0;
		local limbInfo = {};
		local height = 240;
		local width = 120;
		local texInfo = {
			shouldDisplay = true,
			textures = {
				[HITGROUP_RIGHTARM] = CW.limb:GetTexture(HITGROUP_RIGHTARM),
				[HITGROUP_RIGHTLEG] = CW.limb:GetTexture(HITGROUP_RIGHTLEG),
				[HITGROUP_LEFTARM] = CW.limb:GetTexture(HITGROUP_LEFTARM),
				[HITGROUP_LEFTLEG] = CW.limb:GetTexture(HITGROUP_LEFTLEG),
				[HITGROUP_STOMACH] = CW.limb:GetTexture(HITGROUP_STOMACH),
				[HITGROUP_CHEST] = CW.limb:GetTexture(HITGROUP_CHEST),
				[HITGROUP_HEAD] = CW.limb:GetTexture(HITGROUP_HEAD),
				["body"] = CW.limb:GetTexture("body")
			},
			names = {
				[HITGROUP_RIGHTARM] = CW.limb:GetName(HITGROUP_RIGHTARM),
				[HITGROUP_RIGHTLEG] = CW.limb:GetName(HITGROUP_RIGHTLEG),
				[HITGROUP_LEFTARM] = CW.limb:GetName(HITGROUP_LEFTARM),
				[HITGROUP_LEFTLEG] = CW.limb:GetName(HITGROUP_LEFTLEG),
				[HITGROUP_STOMACH] = CW.limb:GetName(HITGROUP_STOMACH),
				[HITGROUP_CHEST] = CW.limb:GetName(HITGROUP_CHEST),
				[HITGROUP_HEAD] = CW.limb:GetName(HITGROUP_HEAD),
			}
		};
		local x = info.x + (info.width / 2) + 32;
		local y = info.originalY + 8;
		
		plugin.Call("GetPlayerLimbInfo", texInfo);
		
		if (texInfo.shouldDisplay) then
			surface.SetDrawColor(255, 255, 255, 150);
			surface.SetMaterial(texInfo.textures["body"]);
			surface.DrawTexturedRect(x, y, width, height);
			
			for k, v in pairs(CW.limb.hitGroups) do
				local limbHealth = CW.limb:GetHealth(k);
				local limbColor = CW.limb:GetColor(limbHealth);
				local newIndex = #limbInfo + 1;
				
				surface.SetDrawColor(limbColor.r, limbColor.g, limbColor.b, 150);
				surface.SetMaterial(texInfo.textures[k]);
				surface.DrawTexturedRect(x, y, width, height);
				
				limbInfo[newIndex] = {
					color = limbColor,
					text = texInfo.names[k]..": "..limbHealth.."%"
				};
				
				local textWidth, textHeight = self:GetCachedTextSize(mainTextFont, limbInfo[newIndex].text);
				tipHeight = tipHeight + textHeight + 4;
				
				if (textWidth > tipWidth) then
					tipWidth = textWidth;
				end;
				
				limbInfo[newIndex].textHeight = textHeight;
			end;
			
			local mouseX = gui.MouseX();
			local mouseY = gui.MouseY();
			
			if (mouseX >= x and mouseX <= x + width
			and mouseY >= y and mouseY <= y + height) then
				local tipX = mouseX + 16;
				local tipY = mouseY + 16;
				
				self:DrawSimpleGradientBox(
					2, tipX - 8, tipY - 8, tipWidth + 16, tipHeight + 12, backgroundColor
				);
				
				for k, v in pairs(limbInfo) do
					self:DrawInfo(v.text, tipX, tipY, v.color, 255, true);
					
					if (k < #limbInfo) then
						tipY = tipY + v.textHeight + 4;
					else
						tipY = tipY + v.textHeight;
					end;
				end;
			end;
		end;
	end;

	-- A function to draw the top hints.
	function CW.kernel:DrawHints()
		if (plugin.Call("PlayerCanSeeHints") and #self.Hints > 0) then
			local hintsFont = CW.option:GetFont("hints_text");
			
			for k, v in pairs(self.Hints) do
				self:OverrideMainFont(hintsFont);
					self:DrawInfo(v.text, v.x, v.y, v.color, v.alpha, true);
				self:OverrideMainFont(false);
			end;
		end;
		
		if (plugin.Call("PlayerCanSeeCenterHints") and #self.CenterHints > 0) then
			for k, v in pairs(self.CenterHints) do
				self:OverrideMainFont(hintsFont);
					self:DrawInfo(v.text, v.x, v.y, v.color, v.alpha, true);
				self:OverrideMainFont(false);
			end;
		end;
	end;

	-- A function to draw the top bars.
	function CW.kernel:DrawBars(info, class)
		if (plugin.Call("PlayerCanSeeBars", class)) then
			local barTextFont = CW.option:GetFont("bar_text");
			
			CW.bars.width = info.width;
			CW.bars.height = CW.bars.height or 12;
			CW.bars.padding = CW.bars.padding or 14;
			CW.bars.y = info.y;
			
			if (class == "tab") then
				CW.bars.x = info.x - (info.width / 2);
			else
				CW.bars.x = info.x;
			end;
			
			CW.option:SetFont("bar_text", CW.option:GetFont("auto_bar_text"));
				for k, v in pairs(CW.bars.stored) do
					CW.bars.y = self:DrawBar(CW.bars.x, CW.bars.y, CW.bars.width, CW.bars.height, v.color, v.text, v.value, v.maximum, v.flash, {uniqueID = v.uniqueID}) + (CW.bars.padding + 2);
				end;
			CW.option:SetFont("bar_text", barTextFont);
			
			info.y = CW.bars.y;
		end;
	end;
	
	-- A function to get the ESP info.
	function CW.kernel:GetESPInfo()
		return self.ESPInfo;
	end;
	
	-- A function to draw the admin ESP.
	function CW.kernel:DrawAdminESP()
		local colorWhite = CW.option:GetColor("white");
		local curTime = UnPredictedCurTime();

		if (!CW.NextGetESPInfo or curTime >= CW.NextGetESPInfo) then
			CW.NextGetESPInfo = curTime + (CW_CONVAR_ESPTIME:GetInt() or 1);
			self.ESPInfo = {};
			
			plugin.Call("GetAdminESPInfo", self.ESPInfo);
		end;
		
		for k, v in pairs(self.ESPInfo) do
			local position = v.position:ToScreen();
			local text, color, height;
			
			if (position) then
				if (type(v.text) == "string") then
					self:DrawSimpleText(v.text, position.x, position.y, v.color or colorWhite, 1, 1);
				else
					for k2, v2 in ipairs(v.text) do	
						local barValue;
						local maximum = 100;

						if (type(v2) == "string") then
							text = v2;
							color = v.color;
						else
							text = v2.text;
							color = v2.color;

							local barNumbers = v2.bar;

							if (type(barNumbers) == "table") then
								barValue = barNumbers.value;
								maximum = barNumbers.max;
							else
								barValue = barNumbers;
							end;
						end;
						
						if (k2 > 1) then
							self:OverrideMainFont(CW.option:GetFont("esp_text"));
							height = draw.GetFontHeight(CW.option:GetFont("esp_text"));
						else
							self:OverrideMainFont(false);
							height = draw.GetFontHeight(CW.option:GetFont("main_text"));
						end;

						if (v2.icon) then
							local icon = "icon16/exclamation.png";
							local width = surface.GetTextSize(text);

							if (type(v2.icon == "string") and v2.icon != "") then
								icon = v2.icon;
							end;

							surface.SetDrawColor(255, 255, 255, 255);
							surface.SetMaterial(CW.kernel:GetMaterial(icon));
							surface.DrawTexturedRect(position.x - (width * 0.40) - height, position.y - height * 0.5, height, height);
						end;

						if (barValue and CW_CONVAR_ESPBARS:GetInt() == 1) then
							local barHeight = height * 0.80;
							local barColor = v2.barColor or CW:GetValueColor(barValue);
							local grayColor = Color(150, 150, 150, 170);
							local progress = 100 * (barValue / maximum);

							if progress < 0 then
								progress = 0;
							end;

							draw.RoundedBox(6, position.x - 50, position.y - (barHeight * 0.45), 100, barHeight, grayColor);
							draw.RoundedBox(6, position.x - 50, position.y - (barHeight * 0.45), math.floor(progress), barHeight, barColor);
						end;

						if (type(text) == "string") then
							self:DrawSimpleText(text, position.x, position.y, color or colorWhite, 1, 1);
						end;

						position.y = position.y + height;
					end;
				end;			
			end;
		end;
	end;

	-- A function to draw a bar with a value and a maximum.
	function CW.kernel:DrawBar(x, y, width, height, color, text, value, maximum, flash, barInfo)
		local backgroundColor = CW.option:GetColor("background");
		local foregroundColor = CW.option:GetColor("foreground");
		local progressWidth = math.Clamp(((width - 4) / maximum) * value, 0, width - 4);
		local colorWhite = CW.option:GetColor("white");
		local newBarInfo = {
			progressWidth = progressWidth,
			drawBackground = true,
			drawProgress = true,
			cornerSize = 2,
			maximum = maximum,
			height = height,
			width = width,
			color = color,
			value = value,
			flash = flash,
			text = text,
			x = x,
			y = y,
			isBlocky = false,
			blocksAmt = 24
		};
		
		if (barInfo) then
			for k, v in pairs(newBarInfo) do
				if (barInfo[k] == nil) then
					barInfo[k] = v;
				end;
			end;
		else
			barInfo = newBarInfo;
		end;
		
		if (!plugin.Call("PreDrawBar", barInfo)) then
			if (barInfo.drawBackground) then
				cdraw.DrawBox(barInfo.x, barInfo.y, barInfo.width, barInfo.height, backgroundColor);
			end;
			
			if (barInfo.drawProgress) then
				render.SetScissorRect(barInfo.x, barInfo.y, barInfo.x + barInfo.progressWidth, barInfo.y + barInfo.height, true);
					cdraw.DrawBox(barInfo.x + 2, barInfo.y + 2, barInfo.width - 4, barInfo.height - 4, barInfo.color);
				render.SetScissorRect(barInfo.x, barInfo.y, barInfo.x + barInfo.progressWidth, barInfo.height, false);
			end;
			
			if (barInfo.flash) then
				local alpha = math.Clamp(math.abs(math.sin(UnPredictedCurTime()) * 50), 0, 50);
				
				if (alpha > 0) then
					draw.RoundedBox(0, barInfo.x + 2, barInfo.y + 2, barInfo.width - 4, barInfo.height - 4,
					Color(colorWhite.r, colorWhite.g, colorWhite.b, alpha));
				end;
			end;
		end;
		
		if (!plugin.Call("PostDrawBar", barInfo)) then
			if (barInfo.text and barInfo.text != "") then
				self:OverrideMainFont(CW.option:GetFont("bar_text"));
					self:DrawSimpleText(
						barInfo.text, barInfo.x + (barInfo.width / 2), barInfo.y + (barInfo.height / 2),
						Color(colorWhite.r, colorWhite.g, colorWhite.b, alpha), 1, 1
					);
				self:OverrideMainFont(false);
			end;
		end;
		
		return barInfo.y;
	end;
	
	-- A function to set the recognise menu.
	function CW.kernel:SetRecogniseMenu(menuPanel)
		CW.RecogniseMenu = menuPanel;
		self:SetTitledMenu(menuPanel, "SELECT WHO CAN RECOGNISE YOU");
	end;
	
	-- A function to get the recognise menu.
	function CW.kernel:GetRecogniseMenu(menuPanel)
		return CW.RecogniseMenu;
	end;
	
	-- A function to override the main font.
	function CW.kernel:OverrideMainFont(font)
		if (font) then
			if (!CW.PreviousMainFont) then
				CW.PreviousMainFont = CW.option:GetFont("main_text");
			end;
			
			CW.option:SetFont("main_text", font);
		elseif (CW.PreviousMainFont) then
			CW.option:SetFont("main_text", CW.PreviousMainFont)
		end;
	end;

	-- A function to get the screen's center.
	function CW.kernel:GetScreenCenter()
		return ScrW() / 2, (ScrH() / 2) + 32;
	end;
	
	-- A function to draw some simple text.
	function CW.kernel:DrawSimpleText(text, x, y, color, alignX, alignY, shadowless, shadowDepth)
		local mainTextFont = CW.option:GetFont("main_text");
		local realX = math.Round(x);
		local realY = math.Round(y);
		
		if (!shadowless) then
			local outlineColor = Color(25, 25, 25, math.min(225, color.a));
			
			for i = 1, (shadowDepth or 1) do
				draw.SimpleText(text, mainTextFont, realX + -i, realY + -i, outlineColor, alignX, alignY);
				draw.SimpleText(text, mainTextFont, realX + -i, realY + i, outlineColor, alignX, alignY);
				draw.SimpleText(text, mainTextFont, realX + i, realY + -i, outlineColor, alignX, alignY);
				draw.SimpleText(text, mainTextFont, realX + i, realY + i, outlineColor, alignX, alignY);
			end;
		end;
		
		draw.SimpleText(text, mainTextFont, realX, realY, color, alignX, alignY);
		local width, height = self:GetCachedTextSize(mainTextFont, text);
		
		return realY + height + 2, width;
	end;
	
	-- A function to get the black fade alpha.
	function CW.kernel:GetBlackFadeAlpha()
		return CW.BlackFadeIn or CW.BlackFadeOut or 0;
	end;
	
	-- A function to get whether the screen is faded black.
	function CW.kernel:IsScreenFadedBlack()
		return (CW.BlackFadeIn == 255);
	end;
	
	--[[ 
		A function to print colored text to the console.
		Sure, it's hacky, but Garry is being a douche.
	--]]
	function CW.kernel:PrintColoredText(...)
		local currentColor = nil;
		local colorWhite = CW.option:GetColor("white");
		local text = {};
		
		for k, v in pairs({...}) do
			if (type(v) == "Player") then
				text[#text + 1] = cwTeam.GetColor(v:Team());
				text[#text + 1] = v:Name();
			elseif (type(v) == "table") then
				currentColor = v;
			elseif (currentColor) then
				text[#text + 1] = currentColor;
				text[#text + 1] = v;
				currentColor = nil;
			else
				text[#text + 1] = colorWhite;
				text[#text + 1] = v;
			end;
		end;
		
		chatbox.oldAddText(unpack(text));
	end;
	
	-- A function to get whether a custom crosshair is used.
	function CW.kernel:UsingCustomCrosshair()
		return CW.CustomCrosshair;
	end;
	
	-- A function to get a cached text size.
	function CW.kernel:GetCachedTextSize(font, text)
		if (!CW.CachedTextSizes) then
			CW.CachedTextSizes = {};
		end;
		
		if (!CW.CachedTextSizes[font]) then
			CW.CachedTextSizes[font] = {};
		end;
		
		if (!CW.CachedTextSizes[font][text]) then
			surface.SetFont(font);
			
			CW.CachedTextSizes[font][text] = { surface.GetTextSize(text) };
		end;
		
		return CW.CachedTextSizes[font][text][1], CW.CachedTextSizes[font][text][2];
	end;
	
	-- A function to draw scaled information at a position.
	function CW.kernel:DrawInfoScaled(scale, text, x, y, color, alpha, bAlignLeft, Callback, shadowDepth)
		local newFont = CW.fonts:GetMultiplied("cwMainText", scale);
		local returnY = 0;
		
		self:OverrideMainFont(newFont);
		
		returnY = self:DrawInfo(text, x, y, color, alpha, bAlignLeft, Callback, shadowDepth);
		
		self:OverrideMainFont(false);
		
		return returnY;
	end;
	
	-- A function to draw information at a position.
	function CW.kernel:DrawInfo(text, x, y, color, alpha, bAlignLeft, Callback, shadowDepth)
		local mainTextFont = CW.option:GetFont("main_text");
		local width, height = self:GetCachedTextSize(mainTextFont, text);
		
		if (width and height) then
			if (!bAlignLeft) then
				x = x - (width / 2);
			end;
			
			if (Callback) then
				x, y = Callback(x, y, width, height);
			end;
		
			return self:DrawSimpleText(text, x, y, Color(color.r, color.g, color.b, alpha or color.a), nil, nil, nil, shadowDepth);
		end;
	end;
	
	-- A function to get the player info box.
	function CW.kernel:GetPlayerInfoBox()
		return CW.PlayerInfoBox;
	end;

	-- A function to draw the local player's information.
	function CW.kernel:DrawPlayerInfo(info)
		if (!plugin.Call("PlayerCanSeePlayerInfo")) then
			return;
		end;
		
		local foregroundColor = CW.option:GetColor("foreground");
		local subInformation = CW.PlayerInfoText.subText;
		local information = CW.PlayerInfoText.text;
		local colorWhite = CW.option:GetColor("white");
		local textWidth, textHeight = self:GetCachedTextSize(
			CW.option:GetFont("player_info_text"), "U"
		);
		local width = CW.PlayerInfoText.width;
		
		if (width < info.width) then
			width = info.width;
		elseif (width > width) then
			info.width = width;
		end;
		
		if (#information == 0 and #subInformation == 0) then
			return;
		end;
		
		local height = (textHeight * #information) + ((textHeight + 12) * #subInformation);
		local scrW = ScrW();
		local scrH = ScrH();
		
		if (#information > 0) then
			height = height + 8;
		end;
		
		local y = info.y + 8;
		local x = info.x - (width / 2);
		
		local boxInfo = {
			subInformation = subInformation,
			drawBackground = true,
			information = information,
			textHeight = textHeight,
			cornerSize = 2,
			textWidth = textWidth,
			height = height,
			width = width,
			x = x,
			y = y
		};
		
		if (!plugin.Call("PreDrawPlayerInfo", boxInfo, information, subInformation)) then
			self:OverrideMainFont(CW.option:GetFont("player_info_text"));
			
			for k, v in pairs(subInformation) do
				x, y = self:DrawPlayerInfoSubBox(v.text, x, y, width, boxInfo);
			end;
			
			if (#information > 0 and boxInfo.drawBackground) then
				cdraw.DrawBox(x, y, width, height - ((textHeight + 12) * #subInformation), Color(200, 200, 200));
			end;
			
			if (#information > 0) then
				x = x + 8
				y = y + 4;
			end;
				
			for k, v in pairs(information) do
				self:DrawInfo(v.text, x, y - 1, colorWhite, 255, true);
				y = y + textHeight;
			end;
			
			self:OverrideMainFont(false);
		end;
		
		plugin.Call("PostDrawPlayerInfo", boxInfo, information, subInformation);
		info.y = info.y + boxInfo.height + 12;
		
		return boxInfo;
	end;
	
	-- A function to get whether the info menu panel can be created.
	function CW.kernel:CanCreateInfoMenuPanel()
		return (table.Count(CW.quickmenu.stored) > 0 or table.Count(CW.quickmenu.categories) > 0);
	end;
	
	-- A function to create the info menu panel.
	function CW.kernel:CreateInfoMenuPanel(x, y, iMinimumWidth)
		if (IsValid(CW.InfoMenuPanel)) then return; end;
		
		local options = {};
		
		for k, v in pairs(CW.quickmenu.categories) do
			options[k] = {};
			
			for k2, v2 in pairs(v) do
				local info = v2.GetInfo();
				
				if (type(info) == "table") then
					options[k][k2] = info;
					options[k][k2].isArgTable = true;
				end;
			end;
		end;
		
		for k, v in pairs(CW.quickmenu.stored) do
			local info = v.GetInfo();
			
			if (type(info) == "table") then
				options[k] = info;
				options[k].isArgTable = true;
			end;
		end;
		
		CW.InfoMenuPanel = self:AddMenuFromData(nil, options, function(menuPanel, option, arguments)
			if (arguments.name) then
				option = arguments.name;
			end;
			
			if (arguments.options) then
				local subMenu = menuPanel:AddSubMenu(option);
				
				for k, v in pairs(arguments.options) do
					local name = v;
					
					if (type(v) == "table") then
						name = v[1];
					end;
					
					subMenu:AddOption(name, function()
						if (arguments.Callback) then
							if (type(v) == "table") then
								arguments.Callback(v[2]);
							else
								arguments.Callback(v);
							end;
						end;
						
						self:RemoveActiveToolTip();
						self:CloseActiveDermaMenus();
					end);
				end;
				
				if (IsValid(subMenu)) then
					if (arguments.toolTip) then
						subMenu:SetToolTip(arguments.toolTip);
					end;
				end;
			else
				menuPanel:AddOption(option, function()
					if (arguments.Callback) then
						arguments.Callback();
					end;
					
					self:RemoveActiveToolTip();
					self:CloseActiveDermaMenus();
				end);
				
				menuPanel.Items = menuPanel:GetChildren();
				local panel = menuPanel.Items[#menuPanel.Items];
				
				if (IsValid(panel) and arguments.toolTip) then
					panel:SetToolTip(arguments.toolTip);
				end;
			end;
		end, iMinimumWidth);
		
		if (IsValid(CW.InfoMenuPanel)) then
			CW.InfoMenuPanel:SetVisible(false);
			CW.InfoMenuPanel:SetSize(iMinimumWidth, CW.InfoMenuPanel:GetTall());
			CW.InfoMenuPanel:SetPos(x, y);
		end;
	end;
	
	-- A function to get the ragdoll eye angles.
	function CW.kernel:GetRagdollEyeAngles()
		if (!CW.RagdollEyeAngles) then
			CW.RagdollEyeAngles = Angle(0, 0, 0);
		end;
		
		return CW.RagdollEyeAngles;
	end;
	
	-- A function to draw a gradient.
	function CW.kernel:DrawGradient(gradientType, x, y, width, height, color)
		if (!CW.Gradients[gradientType]) then
			return;
		end;
		
		surface.SetDrawColor(color.r, color.g, color.b, color.a);
		surface.SetTexture(CW.Gradients[gradientType]);
		surface.DrawTexturedRect(x, y, width, height);
	end;
	
	-- A function to draw a simple gradient box.
	function CW.kernel:DrawSimpleGradientBox(cornerSize, x, y, width, height, color, maxAlpha)
		local gradientAlpha = math.min(color.a, maxAlpha or 100);
		
		draw.RoundedBox(cornerSize, x, y, width, height, Color(color.r, color.g, color.b, color.a * 0.75));
		
		-- Let's face it: gradients are UGLY.
		/*if (x + cornerSize < x + width and y + cornerSize < y + height) then
			surface.SetDrawColor(gradientAlpha, gradientAlpha, gradientAlpha, gradientAlpha);
			surface.SetMaterial(self:GetGradientTexture());
			surface.DrawTexturedRect(x + cornerSize, y + cornerSize, width - (cornerSize * 2), height - (cornerSize * 2));
		end;*/
	end;
	
	-- A function to draw a textured gradient.
	function CW.kernel:DrawTexturedGradientBox(cornerSize, x, y, width, height, color, maxAlpha)
		local gradientAlpha = math.min(color.a, maxAlpha or 100);
		
		draw.RoundedBox(cornerSize, x, y, width, height, Color(color.r, color.g, color.b, color.a * 0.75));

		if (x + cornerSize < x + width and y + cornerSize < y + height) then
			surface.SetDrawColor(gradientAlpha, gradientAlpha, gradientAlpha, gradientAlpha);
			surface.SetMaterial(self:GetGradientTexture());
			surface.DrawTexturedRect(x + cornerSize, y + cornerSize, width - (cornerSize * 2), height - (cornerSize * 2));
		end;
	end;
	
	-- A function to draw a player information sub box.
	function CW.kernel:DrawPlayerInfoSubBox(text, x, y, width, boxInfo)
		local foregroundColor = CW.option:GetColor("foreground");
		local colorInfo = CW.option:GetColor("information");
		local boxHeight = boxInfo.textHeight + 8;
		
		if (boxInfo.drawBackground) then
			cdraw.DrawBox(x, y, width, boxHeight, foregroundColor);
		end;
		
		self:DrawInfo(text, x + 8, y + (boxHeight / 2), colorInfo, 255, true,
			function(x, y, width, height)
				return x, y - (height / 2);
			end
		);
		
		return x, y + boxHeight + 4;
	end;
	
	-- A function to handle an item's spawn icon click.
	function CW.kernel:HandleItemSpawnIconClick(itemTable, spawnIcon, Callback)
		local customFunctions = itemTable("customFunctions");
		local itemFunctions = {};
		local destroyName = CW.option:GetKey("name_destroy");
		local dropName = CW.option:GetKey("name_drop");
		local useName = CW.option:GetKey("name_use");
		
		if (itemTable.OnUse) then
			itemFunctions[#itemFunctions + 1] = itemTable("useText", useName);
		end;
		
		if (itemTable.OnDrop) then
			itemFunctions[#itemFunctions + 1] = itemTable("dropText", dropName);
		end;
		
		if (itemTable.OnDestroy) then
			itemFunctions[#itemFunctions + 1] = itemTable("destroyText", destroyName);
		end;
		
		if (customFunctions) then
			for k, v in pairs(customFunctions) do
				itemFunctions[#itemFunctions + 1] = v;
			end;
		end;

		if (itemTable.GetOptions) then
			local options = itemTable:GetOptions(nil, nil);
			for k, v in pairs(options) do
				itemFunctions[#itemFunctions + 1] = {title = k, name = v};
			end
		end
		
		if (itemTable.OnEditFunctions) then
			itemTable:OnEditFunctions(itemFunctions);
		end;
		
		plugin.Call("PlayerAdjustItemFunctions", itemTable, itemFunctions);
		self:ValidateTableKeys(itemFunctions);
		
		table.sort(itemFunctions, function(a, b) return ((type(a) == "table" and a.title) or a) < ((type(b) == "table" and b.title) or b); end);
		if (#itemFunctions == 0 and !Callback) then return; end;
		
		local options = {};
		
		if (itemTable.GetEntityMenuOptions) then
			itemTable:GetEntityMenuOptions(nil, options);
		end;
	
		local itemMenu = self:AddMenuFromData(nil, options, function(menuPanel, option, arguments)
			menuPanel:AddOption(option, function()
				if (type(arguments) == "table" and arguments.isArgTable) then
					if (arguments.Callback) then
						arguments.Callback();
					end;
				elseif (arguments == "function") then
					arguments();
				end;
				
				timer.Simple(FrameTime(), function()
					self:RemoveActiveToolTip();
				end);
			end);
			
			menuPanel.Items = menuPanel:GetChildren();
			local panel = menuPanel.Items[#menuPanel.Items];
			
			if (IsValid(panel)) then
				if (type(arguments) == "table") then
					if (arguments.toolTip) then
						self:CreateMarkupToolTip(panel);
						panel:SetMarkupToolTip(arguments.toolTip);
					end;
				end;
			end;
		end, nil, true);
		
		if (Callback) then Callback(itemMenu); end;
		
		itemMenu:SetMinimumWidth(100);
		plugin.Call("PlayerAdjustItemMenu", itemTable, itemMenu, itemFunctions);
			
		for k, v in pairs(itemFunctions) do
			local useText = itemTable("useText", "Use");
			local dropText = itemTable("dropText", "Drop");
			local destroyText = itemTable("destroyText", "Destroy");
			
			if ((!useText and v == "Use") or (useText and v == useText)) then
				itemMenu:AddOption(v, function()
					if (itemTable) then
						if (itemTable.OnHandleUse) then
							itemTable:OnHandleUse(function()
								self:RunCommand(
									"InvAction", "use", itemTable("uniqueID"), itemTable("itemID")
								);
							end);
						else
							self:RunCommand(
								"InvAction", "use", itemTable("uniqueID"), itemTable("itemID")
							);
						end;
					end;
				end);
			elseif ((!dropText and v == "Drop") or (dropText and v == dropText)) then
				itemMenu:AddOption(v, function()
					if (itemTable) then
						self:RunCommand(
							"InvAction", "drop", itemTable("uniqueID"), itemTable("itemID")
						);
					end;
				end);
			elseif ((!destroyText and v == "Destroy") or (destroyText and v == destroyText)) then
				local subMenu = itemMenu:AddSubMenu(v);
				
				subMenu:AddOption("Yes", function()
					if (itemTable) then
						self:RunCommand(
							"InvAction", "destroy", itemTable("uniqueID"), itemTable("itemID")
						);
					end;
				end);
				
				subMenu:AddOption("No", function() end);
			elseif (type(v) == "table") then
				itemMenu:AddOption(v.title, function()
					local defaultAction = true;
					
					if (itemTable.HandleOptions) then
						local transmit, data = itemTable:HandleOptions(v.name);
						
						if (transmit) then
							netstream.Start("MenuOption", {option = v.name, data = data, item = itemTable("itemID")});
							defaultAction = false;
						end;
					end;
					
					if (defaultAction) then
						self:RunCommand(
							"InvAction", v.name, itemTable("uniqueID"), itemTable("itemID")
						);
					end;
				end);
			else
				if (itemTable.OnCustomFunction) then
					itemTable:OnCustomFunction(v);
				end;
				
				itemMenu:AddOption(v, function()
					if (itemTable) then
						self:RunCommand(
							"InvAction", v, itemTable("uniqueID"), itemTable("itemID")
						);
					end;
				end);
			end;
		end;
		
		itemMenu:Open();
	end;
	
	-- A function to handle an item's spawn icon right click.
	function CW.kernel:HandleItemSpawnIconRightClick(itemTable, spawnIcon)
		if (itemTable.OnHandleRightClick) then
			local functionName = itemTable:OnHandleRightClick();
			
			if (functionName and functionName != "Use") then
				local customFunctions = itemTable("customFunctions");
				
				if (customFunctions and table.HasValue(customFunctions, functionName)) then
					if (itemTable.OnCustomFunction) then
						itemTable:OnCustomFunction(v);
					end;
				end;
				
				self:RunCommand(
					"InvAction", string.lower(functionName), itemTable("uniqueID"), itemTable("itemID")
				);
				return;
			end;
		end;
		
		if (itemTable.OnUse) then
			if (itemTable.OnHandleUse) then
				itemTable:OnHandleUse(function()
					self:RunCommand("InvAction", "use", itemTable("uniqueID"), itemTable("itemID"));
				end);
			else
				self:RunCommand("InvAction", "use", itemTable("uniqueID"), itemTable("itemID"));
			end;
		end;
	end;
	
	-- A function to set a panel's perform layout callback.
	function CW.kernel:SetOnLayoutCallback(target, Callback)
		if (target.PerformLayout) then
			target.OldPerformLayout = target.PerformLayout;
			
			-- Called when the panel's layout is performed.
			function target.PerformLayout()
				target:OldPerformLayout(); Callback(target);
			end;
		end;
	end;
	
	-- A function to set the active titled DMenu.
	function CW.kernel:SetTitledMenu(menuPanel, title)
		CW.TitledMenu = {
			menuPanel = menuPanel,
			title = title
		};
	end;
	
	-- A function to add a markup line.
	function CW.kernel:AddMarkupLine(markupText, text, color)
		if (markupText != "") then
			markupText = markupText.."\n";
		end;
		
		return markupText..self:MarkupTextWithColor(text, color);
	end;
	
	-- A function to draw a markup tool tip.
	function CW.kernel:DrawMarkupToolTip(markupObject, x, y, alpha)
		local height = markupObject:GetHeight();
		local width = markupObject:GetWidth();
		
		if (x - (width / 2) > 0) then
			x = x - (width / 2);
		end;
		
		if (x + width > ScrW()) then
			x = x - width - 8;
		end;
		
		if (y + (height + 8) > ScrH()) then
			y = y - height - 8;
		end;
		
		self:DrawSimpleGradientBox(2, x - 8, y - 8, width + 16, height + 16, Color(50, 50, 50, alpha));
		markupObject:Draw(x, y, nil, nil, alpha);
	end;
	
	-- A function to override a markup object's draw function.
	function CW.kernel:OverrideMarkupDraw(markupObject, sCustomFont)
		function markupObject:Draw(xOffset, yOffset, hAlign, vAlign, alphaOverride)
			for k, v in pairs(self.blocks) do
				if (!v.colour) then
					debug.Trace();
					return;
				end;
			
				local alpha = v.colour.a or 255;
				local y = yOffset + (v.height - v.thisY) + v.offset.y;
				local x = xOffset;
				
				if (hAlign == TEXT_ALIGN_CENTER) then
					x = x - (self.totalWidth / 2);
				elseif (hAlign == TEXT_ALIGN_RIGHT) then
					x = x - self.totalWidth;
				end;
				
				x = x + v.offset.x;
				
				if (hAlign == TEXT_ALIGN_CENTER) then
					y = y - (self.totalHeight / 2);
				elseif (hAlign == TEXT_ALIGN_BOTTOM) then
					y = y - self.totalHeight;
				end;
				
				if (alphaOverride) then
					alpha = alphaOverride;
				end;
				
				CW.kernel:OverrideMainFont(sCustomFont or v.font);
					CW.kernel:DrawSimpleText(v.text, x, y, Color(v.colour.r or 255, v.colour.g or 255, v.colour.b or 255, alpha));
				CW.kernel:OverrideMainFont(false);
			end;
		end;
	end;
	
	-- A function to get the active markup tool tip.
	function CW.kernel:GetActiveMarkupToolTip()
		return CW.MarkupToolTip;
	end;
	
	-- A function to get markup from a color.
	function CW.kernel:ColorToMarkup(color)
		return "<color="..math.ceil(color.r)..","..math.ceil(color.g)..","..math.ceil(color.b)..">";
	end;
	
	-- A function to markup text with a color.
	function CW.kernel:MarkupTextWithColor(text, color, scale)
		local fontName = CW.fonts:GetMultiplied("cwTooltip", scale or 1);
		local finalText = text;
		
		if (color) then
			finalText = self:ColorToMarkup(color)..text.."</color>";
		end;
		
		finalText = "<font="..fontName..">"..finalText.."</font>";
		
		return finalText;
	end;
	
	-- A function to create a markup tool tip.
	function CW.kernel:CreateMarkupToolTip(panel)
		panel.OldCursorExited = panel.OnCursorExited;
		panel.OldCursorEntered = panel.OnCursorEntered;
		
		-- Called when the cursor enters the panel.
		function panel.OnCursorEntered(panel, ...)
			if (panel.OldCursorEntered) then
				panel:OldCursorEntered(...);
			end;
			
			CW.MarkupToolTip = panel;
		end;

		-- Called when the cursor exits the panel.
		function panel.OnCursorExited(panel, ...)
			if (panel.OldCursorExited) then
				panel:OldCursorExited(...);
			end;
			
			if (CW.MarkupToolTip == panel) then
				CW.MarkupToolTip = nil;
			end;
		end;
		
		-- A function to set the panel's markup tool tip.
		function panel.SetMarkupToolTip(panel, text)
			if (!text or text == "") then
				return;
			end;
			
			if (!panel.MarkupToolTip or panel.MarkupToolTip.text != text) then
				panel.MarkupToolTip = {
					object = markup.Parse(text, ScrW() * 0.25),
					text = text
				};
				
				self:OverrideMarkupDraw(panel.MarkupToolTip.object);
			end;
		end;
		
		-- A function to get the panel's markup tool tip.
		function panel.GetMarkupToolTip(panel)
			return panel.MarkupToolTip;
		end;
		
		-- A function to set the panel's tool tip.
		function panel.SetToolTip(panel, toolTip)
			panel:SetMarkupToolTip(toolTip);
		end;
		
		return panel;
	end;
	
	-- A function to create a custom category panel.
	function CW.kernel:CreateCustomCategoryPanel(categoryName, parent)
		if (!parent.CategoryList) then
			parent.CategoryList = {};
		end;
		
		local collapsibleCategory = vgui.Create("DCollapsibleCategory", parent);
			collapsibleCategory:SetExpanded(true);
			collapsibleCategory:SetPadding(2);
			collapsibleCategory:SetLabel(categoryName);
		parent.CategoryList[#parent.CategoryList + 1] = collapsibleCategory;
		
		return collapsibleCategory;
	end;
	
	-- A function to draw the armor bar.
	function CW.kernel:DrawArmorBar()
		local armor = math.Clamp(CW.Client:Armor(), 0, CW.Client:GetMaxArmor());
		
		if (!self.armor) then
			self.armor = armor;
		else
			self.armor = math.Approach(self.armor, armor, 1);
		end;
		
		if (armor > 0) then
			CW.bars:Add("ARMOR", Color(139, 174, 179, 255), "", self.armor, CW.Client:GetMaxArmor(), self.health < 10, 1);
		end;
	end;

	-- A function to draw the health bar.
	function CW.kernel:DrawHealthBar()
		local health = math.Clamp(CW.Client:Health(), 0, CW.Client:GetMaxHealth());
		
		if (!self.armor) then
			self.health = health;
		else
			self.health = math.Approach(self.health, health, 1);
		end;
		
		if (health > 0) then
			CW.bars:Add("HEALTH", Color(179, 46, 49, 255), "", self.health, CW.Client:GetMaxHealth(), self.health < 10, 2);
		end;
	end;
	
	-- A function to remove the active tool tip.
	function CW.kernel:RemoveActiveToolTip()
		ChangeTooltip();
	end;
	
	-- A function to close active Derma menus.
	function CW.kernel:CloseActiveDermaMenus()
		CloseDermaMenus();
	end;
	
	-- A function to register a background blur.
	function CW.kernel:RegisterBackgroundBlur(panel, fCreateTime)
		CW.BackgroundBlurs[panel] = fCreateTime or SysTime();
	end;
	
	-- A function to remove a background blur.
	function CW.kernel:RemoveBackgroundBlur(panel)
		CW.BackgroundBlurs[panel] = nil;
	end;
	
	-- A function to draw the background blurs.
	function CW.kernel:DrawBackgroundBlurs()
		local scrH, scrW = ScrH(), ScrW();
		local sysTime = SysTime();
		
		for k, v in pairs(CW.BackgroundBlurs) do
			if (type(k) == "string" or (IsValid(k) and k:IsVisible())) then
				local fraction = math.Clamp((sysTime - v) / 1, 0, 1);
				local x, y = 0, 0;
				
				surface.SetMaterial(CW.ScreenBlur);
				surface.SetDrawColor(255, 255, 255, 255);
				
				for i = 0.33, 1, 0.33 do
					CW.ScreenBlur:SetFloat("$blur", fraction * 5 * i);
					CW.ScreenBlur:Recompute();
					
					if (render) then render.UpdateScreenEffectTexture();end;
					
					surface.DrawTexturedRect(x, y, scrW, scrH);
				end;
				
				surface.SetDrawColor(10, 10, 10, 200 * fraction);
				surface.DrawRect(x, y, scrW, scrH);
			end;
		end;
	end;
	
	-- A function to get the notice panel.
	function CW.kernel:GetNoticePanel()
		if (IsValid(CW.NoticePanel) and CW.NoticePanel:IsVisible()) then
			return CW.NoticePanel;
		end;
	end;
	
	-- A function to set the notice panel.
	function CW.kernel:SetNoticePanel(noticePanel)
		CW.NoticePanel = noticePanel;
	end;
	
	-- A function to add some cinematic text.
	function CW.kernel:AddCinematicText(text, color, barLength, hangTime, font, bThisOnly)
		local colorWhite = CW.option:GetColor("white");
		local cinematicTable = {
			barLength = barLength or (ScrH() * 8),
			hangTime = hangTime or 3,
			color = color or colorWhite,
			font = font,
			text = text,
			add = 0
		};
		
		if (bThisOnly) then
			CW.Cinematics[1] = cinematicTable;
		else
			CW.Cinematics[#CW.Cinematics + 1] = cinematicTable;
		end;
	end;
	
	-- A function to add a notice.
	function CW.kernel:AddNotify(text, class, length)
		if (class != NOTIFY_HINT or string.utf8sub(text, 1, 6) != "#Hint_") then
			if (CW.BaseClass.AddNotify) then
				CW.BaseClass:AddNotify(text, class, length);
			end;
		end;
	end;
	
	-- A function to get whether the local player is using the tool gun.
	function CW.kernel:IsUsingTool()
		if (IsValid(CW.Client:GetActiveWeapon())
		and CW.Client:GetActiveWeapon():GetClass() == "gmod_tool") then
			return true;
		else
			return false;
		end;
	end;

	-- A function to get whether the local player is using the camera.
	function CW.kernel:IsUsingCamera()
		if (IsValid(CW.Client:GetActiveWeapon())
		and CW.Client:GetActiveWeapon():GetClass() == "gmod_camera") then
			return true;
		else
			return false;
		end;
	end;
	
	-- A function to get the target ID data.
	function CW.kernel:GetTargetIDData()
		return CW.TargetIDData;
	end;
	
	-- A function to calculate the screen fading.
	function CW.kernel:CalculateScreenFading()
		if (plugin.Call("ShouldPlayerScreenFadeBlack")) then
			if (!CW.BlackFadeIn) then
				if (CW.BlackFadeOut) then
					CW.BlackFadeIn = CW.BlackFadeOut;
				else
					CW.BlackFadeIn = 0;
				end;
			end;
			
			CW.BlackFadeIn = math.Clamp(CW.BlackFadeIn + (FrameTime() * 20), 0, 255);
			CW.BlackFadeOut = nil;
			self:DrawSimpleGradientBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, CW.BlackFadeIn));
		else
			if (CW.BlackFadeIn) then
				CW.BlackFadeOut = CW.BlackFadeIn;
			end;
			
			CW.BlackFadeIn = nil;
			
			if (CW.BlackFadeOut) then
				CW.BlackFadeOut = math.Clamp(CW.BlackFadeOut - (FrameTime() * 40), 0, 255);
				self:DrawSimpleGradientBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, CW.BlackFadeOut));
				
				if (CW.BlackFadeOut == 0) then
					CW.BlackFadeOut = nil;
				end;
			end;
		end;
	end;
	
	-- A function to draw a cinematic.
	function CW.kernel:DrawCinematic(cinematicTable, curTime)
		local maxBarLength = cinematicTable.barLength or (ScrH() / 13);
		local font = cinematicTable.font or CW.option:GetFont("cinematic_text");
		
		if (cinematicTable.goBack and curTime > cinematicTable.goBack) then
			cinematicTable.add = math.Clamp(cinematicTable.add - 2, 0, maxBarLength);
			
			if (cinematicTable.add == 0) then
				table.remove(CW.Cinematics, 1);
				cinematicTable = nil;
			end;
		else
			cinematicTable.add = math.Clamp(cinematicTable.add + 1, 0, maxBarLength);
			
			if (cinematicTable.add == maxBarLength and !cinematicTable.goBack) then
				cinematicTable.goBack = curTime + cinematicTable.hangTime;
			end;
		end;
		
		if (cinematicTable) then
			draw.RoundedBox(0, 0, -maxBarLength + cinematicTable.add, ScrW(), maxBarLength, Color(0, 0, 0, 255));
			draw.RoundedBox(0, 0, ScrH() - cinematicTable.add, ScrW(), maxBarLength, Color(0, 0, 0, 255));
			draw.SimpleText(cinematicTable.text, font, ScrW() / 2, (ScrH() - cinematicTable.add) + (maxBarLength / 2), cinematicTable.color, 1, 1);
		end
	end;
	
	-- A function to draw the cinematic introduction.
	function CW.kernel:DrawCinematicIntro(curTime)
		local cinematicInfo = plugin.Call("GetCinematicIntroInfo");
		local colorWhite = CW.option:GetColor("white");
		
		if (cinematicInfo) then
			if (CW.CinematicScreenAlpha and CW.CinematicScreenTarget) then
				CW.CinematicScreenAlpha = math.Approach(CW.CinematicScreenAlpha, CW.CinematicScreenTarget, 1);
				
				if (CW.CinematicScreenAlpha == CW.CinematicScreenTarget) then
					if (CW.CinematicScreenTarget == 255) then
						if (!CW.CinematicScreenGoBack) then
							CW.CinematicScreenGoBack = curTime + 2.5;
							CW.option:PlaySound("rollover");
						end;
					else
						CW.CinematicScreenDone = true;
					end;
				end;
				
				if (CW.CinematicScreenGoBack and curTime >= CW.CinematicScreenGoBack) then
					CW.CinematicScreenGoBack = nil;
					CW.CinematicScreenTarget = 0;
					CW.option:PlaySound("rollover");
				end;
				
				if (!CW.CinematicScreenDone and cinematicInfo.credits) then
					local alpha = math.Clamp(CW.CinematicScreenAlpha, 0, 255);
					
					self:OverrideMainFont(CW.option:GetFont("intro_text_tiny"));
						self:DrawSimpleText(cinematicInfo.credits, ScrW() / 8, ScrH() * 0.75, Color(colorWhite.r, colorWhite.g, colorWhite.b, alpha));
					self:OverrideMainFont(false);
				end;
			else
				CW.CinematicScreenAlpha = 0;
				CW.CinematicScreenTarget = 255;
				CW.option:PlaySound("rollover");
			end;
		end;
	end;
	
	-- A function to draw the cinematic introduction bars.
	function CW.kernel:DrawCinematicIntroBars()
		if (CW.config:Get("draw_intro_bars"):Get()) then
			local maxBarLength = ScrH() / 8;
			
			if (!CW.CinematicBarsTarget and !CW.CinematicBarsAlpha) then
				CW.CinematicBarsAlpha = 0;
				CW.CinematicBarsTarget = 255;
				CW.option:PlaySound("rollover");
			end;
			
			CW.CinematicBarsAlpha = math.Approach(CW.CinematicBarsAlpha, CW.CinematicBarsTarget, 1);
			
			if (CW.CinematicScreenDone) then
				if (CW.CinematicScreenBarLength != 0) then
					CW.CinematicScreenBarLength = math.Clamp((maxBarLength / 255) * CW.CinematicBarsAlpha, 0, maxBarLength);
				end;
				
				if (CW.CinematicBarsTarget != 0) then
					CW.CinematicBarsTarget = 0;
					CW.option:PlaySound("rollover");
				end;
				
				if (CW.CinematicBarsAlpha == 0) then
					CW.CinematicBarsDrawn = true;
				end;
			elseif (CW.CinematicScreenBarLength != maxBarLength) then
				if (!CW.IntroBarsMultiplier) then
					CW.IntroBarsMultiplier = 1;
				else
					CW.IntroBarsMultiplier = math.Clamp(CW.IntroBarsMultiplier + (FrameTime() * 8), 1, 12);
				end;
				
				CW.CinematicScreenBarLength = math.Clamp((maxBarLength / 255) * math.Clamp(CW.CinematicBarsAlpha * CW.IntroBarsMultiplier, 0, 255), 0, maxBarLength);
			end;
			
			draw.RoundedBox(0, 0, 0, ScrW(), CW.CinematicScreenBarLength, Color(0, 0, 0, 255));
			draw.RoundedBox(0, 0, ScrH() - CW.CinematicScreenBarLength, ScrW(), maxBarLength, Color(0, 0, 0, 255));
		end;
	end;
	
	-- A function to draw the cinematic info.
	function CW.kernel:DrawCinematicInfo()
		if (!CW.CinematicInfoAlpha and !CW.CinematicInfoSlide) then
			CW.CinematicInfoAlpha = 255;
			CW.CinematicInfoSlide = 0;
		end;
		
		CW.CinematicInfoSlide = math.Approach(CW.CinematicInfoSlide, 255, 1);
		
		if (CW.CinematicScreenAlpha and CW.CinematicScreenTarget) then
			CW.CinematicInfoAlpha = math.Approach(CW.CinematicInfoAlpha, 0, 1);
			
			if (CW.CinematicInfoAlpha == 0) then
				CW.CinematicInfoDrawn = true;
			end;
		end;
		
		local cinematicInfo = plugin.Call("GetCinematicIntroInfo");
		local colorWhite = CW.option:GetColor("white");
		local colorInfo = CW.option:GetColor("information");
		
		if (cinematicInfo) then
			local screenHeight = ScrH();
			local screenWidth = ScrW();
			local textPosScale = 1 - (CW.CinematicInfoAlpha / 255);
			local textPosY = (screenHeight * 0.35) - ((screenHeight * 0.15) * textPosScale);
			local textPosX = screenWidth * 0.3;
			
			if (cinematicInfo.title) then
				local cinematicInfoTitle = string.upper(cinematicInfo.title);
				local cinematicIntroText = string.upper(cinematicInfo.text);
				local introTextSmallFont = CW.option:GetFont("intro_text_small");
				local introTextBigFont = CW.option:GetFont("intro_text_big");
				local textWidth, textHeight = self:GetCachedTextSize(introTextBigFont, cinematicInfoTitle);
				local boxAlpha = math.min(CW.CinematicInfoAlpha, 150);
				
				if (cinematicInfo.text) then
					local smallTextWidth, smallTextHeight = self:GetCachedTextSize(introTextSmallFont, cinematicIntroText);
					
					self:DrawGradient(
						GRADIENT_RIGHT, 0, textPosY - 80, screenWidth, textHeight + smallTextHeight + 160, Color(100, 100, 100, boxAlpha)
					);
				else
					self:DrawGradient(
						GRADIENT_RIGHT, 0, textPosY - 80, screenWidth, textHeight + 160, Color(100, 100, 100, boxAlpha)
					);
				end;
				
				self:OverrideMainFont(introTextBigFont);
					self:DrawSimpleText(cinematicInfoTitle, textPosX, textPosY, Color(colorInfo.r, colorInfo.g, colorInfo.b, CW.CinematicInfoAlpha), nil, nil, true);
				self:OverrideMainFont(false);
				
				if (cinematicInfo.text) then
					self:OverrideMainFont(introTextSmallFont);
						self:DrawSimpleText(cinematicIntroText, textPosX, textPosY + textHeight + 8, Color(colorWhite.r, colorWhite.g, colorWhite.b, CW.CinematicInfoAlpha), nil, nil, true);
					self:OverrideMainFont(false);
				end;
			elseif (cinematicInfo.text) then
				self:OverrideMainFont(introTextSmallFont);
					self:DrawSimpleText(cinematicIntroText, textPosX, textPosY, Color(colorWhite.r, colorWhite.g, colorWhite.b, CW.CinematicInfoAlpha), nil, nil, true);
				self:OverrideMainFont(false);
			end;
		end;
	end;
	
	-- A function to draw some door text.
	function CW.kernel:DrawDoorText(entity, eyePos, eyeAngles, font, nameColor, textColor)
		local entityColor = entity:GetColor();
		
		if (entityColor.a <= 0 or entity:IsEffectActive(EF_NODRAW)) then
			return;
		end;
		
		local doorData = CW.entity:CalculateDoorTextPosition(entity);
		
		if (!doorData.hitWorld) then
			local frontY = -26;
			local backY = -26;
			local alpha = self:CalculateAlphaFromDistance(256, eyePos, entity:GetPos());
			
			if (alpha <= 0) then
				return;
			end;
			
			local owner = CW.entity:GetOwner(entity);
			local name = plugin.Call("GetDoorInfo", entity, DOOR_INFO_NAME);
			local text = plugin.Call("GetDoorInfo", entity, DOOR_INFO_TEXT);
			
			if (name or text) then
				local nameWidth, nameHeight = self:GetCachedTextSize(font, name or "");
				local textWidth, textHeight = self:GetCachedTextSize(font, text or "");
				local longWidth = nameWidth;
				local boxAlpha = math.min(alpha, 150);
				
				if (textWidth > longWidth) then
					longWidth = textWidth;
				end;
				
				local scale = math.abs((doorData.width * 0.75) / longWidth);
				local nameScale = math.min(scale, 0.05);
				local textScale = math.min(scale, 0.03);
				local longHeight = nameHeight + textHeight + 8;
				
				cam.Start3D2D(doorData.position, doorData.angles, nameScale);
					self:DrawGradient(GRADIENT_CENTER, -(longWidth / 2) - 128, frontY - 8, longWidth + 256, longHeight, Color(100, 100, 100, boxAlpha));
				cam.End3D2D();
				
				cam.Start3D2D(doorData.positionBack, doorData.anglesBack, nameScale);
					self:DrawGradient(GRADIENT_CENTER, -(longWidth / 2) - 128, frontY - 8, longWidth + 256, longHeight, Color(100, 100, 100, boxAlpha));
				cam.End3D2D();
				
				if (name) then
					if (!text or text == "") then
						nameColor = textColor or nameColor; 
					end;
					
					cam.Start3D2D(doorData.position, doorData.angles, nameScale);
						self:OverrideMainFont(font);
							frontY = self:DrawInfo(name, 0, frontY, nameColor, alpha, nil, nil, 3);
						self:OverrideMainFont(false);
					cam.End3D2D();
					
					cam.Start3D2D(doorData.positionBack, doorData.anglesBack, nameScale);
						self:OverrideMainFont(font);
							backY = self:DrawInfo(name, 0, backY, nameColor, alpha, nil, nil, 3);
						self:OverrideMainFont(false);
					cam.End3D2D();
				end;
				
				if (text) then
					cam.Start3D2D(doorData.position, doorData.angles, textScale);
						self:OverrideMainFont(font);
							frontY = self:DrawInfo(text, 0, frontY, textColor, alpha, nil, nil, 3);
						self:OverrideMainFont(false);
					cam.End3D2D();
					
					cam.Start3D2D(doorData.positionBack, doorData.anglesBack, textScale);
						self:OverrideMainFont(font);
							backY = self:DrawInfo(text, 0, backY, textColor, alpha, nil, nil, 3);
						self:OverrideMainFont(false);
					cam.End3D2D();
				end;
			end;
		end;
	end;
	
	-- A function to get whether the local player's character screen is open.
	function CW.kernel:IsCharacterScreenOpen(isVisible)
		if (CW.character:IsPanelOpen()) then
			local panel = CW.character:GetPanel();
			
			if (isVisible) then
				if (panel) then
					return panel:IsVisible();
				end;
			else
				return panel != nil;
			end;
		end;
	end;
	
	-- A function to save schema data.
	function CW.kernel:SaveSchemaData(fileName, data)
		if (type(data) != "table") then
			MsgC(Color(255, 100, 0, 255), "[CW:Kernel] The '"..fileName.."' schema data has failed to save.\nUnable to save type "..type(data)..", table required.\n");
			
			return;
		end;	
	
		_file.Write("clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".txt", self:Serialize(data));
	end;

	-- A function to delete schema data.
	function CW.kernel:DeleteSchemaData(fileName)
		_file.Delete("clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".txt");
	end;

	-- A function to check if schema data exists.
	function CW.kernel:SchemaDataExists(fileName)
		return _file.Exists("clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".txt", "DATA");
	end;
	
	-- A function to find schema data in a directory.
	function CW.kernel:FindSchemaDataInDir(directory)
		return _file.Find("clockwork/schemas/"..self:GetSchemaFolder().."/"..directory, "LUA", "namedesc");
	end;

	-- A function to restore schema data.
	function CW.kernel:RestoreSchemaData(fileName, failSafe)
		if (self:SchemaDataExists(fileName)) then
			local data = _file.Read("clockwork/schemas/"..self:GetSchemaFolder().."/"..fileName..".txt", "DATA");
			
			if (data) then
				local bSuccess, value = pcall(util.JSONToTable, data);
				
				if (bSuccess and value != nil) then
					return value;
				else
					local bSuccess, value = pcall(self.Deserialize, self, data);
					
					if (bSuccess and value != nil) then
						return value;
					else
						MsgC(Color(255, 100, 0, 255), "[CW:Kernel] '"..fileName.."' schema data has failed to restore.\n"..value.."\n");
						
						self:DeleteSchemaData(fileName);
					end;
				end;
			end;
		end;
		
		if (failSafe != nil) then
			return failSafe;
		else
			return {};
		end;
	end;

	-- A function to restore Clockwork data.
	function CW.kernel:RestoreClockworkData(fileName, failSafe)
		if (self:ClockworkDataExists(fileName)) then
			local data = _file.Read("clockwork/"..fileName..".txt", "DATA");
			
			if (data) then
				local success, value = pcall(util.JSONToTable, data);
				
				if (success and value != nil) then
					return value;
				else
					local bSuccess, value = pcall(self.Deserialize, self, data);
					
					if (bSuccess and value != nil) then
						return value;
					else
						MsgC(Color(255, 100, 0, 255), "[CW:Kernel] '"..fileName.."' clockwork data has failed to restore.\n"..value.."\n");
						
						self:DeleteClockworkData(fileName);
					end;
				end;
			end;
		end;
		
		if (failSafe != nil) then
			return failSafe;
		else
			return {};
		end;
	end;

	-- A function to save Clockwork data.
	function CW.kernel:SaveClockworkData(fileName, data)
		if (type(data) != "table") then
			MsgC(Color(255, 100, 0, 255), "[CW:Kernel] The '"..fileName.."' clockwork data has failed to save.\nUnable to save type "..type(data)..", table required.\n");
			
			return;
		end;	
	
		_file.Write("clockwork/"..fileName..".txt", self:Serialize(data));
	end;

	-- A function to check if Clockwork data exists.
	function CW.kernel:ClockworkDataExists(fileName)
		return _file.Exists("clockwork/"..fileName..".txt", "DATA");
	end;

	-- A function to delete Clockwork data.
	function CW.kernel:DeleteClockworkData(fileName)
		_file.Delete("clockwork/"..fileName..".txt");
	end;
	
	-- A function to run a Clockwork command.
	function CW.kernel:RunCommand(command, ...)
		RunConsoleCommand("cwCmd", command, ...);
	end;
	
	-- A function to get whether the local player is choosing a character.
	function CW.kernel:IsChoosingCharacter()
		if (CW.character:GetPanel()) then
			return CW.character:IsPanelOpen();
		else
			return true;
		end;
	end;
	
	-- A function to include the schema.
	function CW.kernel:IncludeSchema()
		local schemaFolder = self:GetSchemaFolder();
		
		if (schemaFolder and type(schemaFolder) == "string") then
			plugin.Include(schemaFolder.."/schema", true);
		end;
	end;
end;

-- A function to explode a string by tags.
function CW.kernel:ExplodeByTags(text, seperator, open, close, hide)
	local results = {};
	local current = "";
	local tag = nil;
	
	for i = 1, #text do
		local character = string.utf8sub(text, i, i);
		
		if (!tag) then
			if (character == open) then
				if (!hide) then
					current = current..character;
				end;
				
				tag = true;
			elseif (character == seperator) then
				results[#results + 1] = current; current = "";
			else
				current = current..character;
			end;
		else
			if (character == close) then
				if (!hide) then
					current = current..character;
				end;
				
				tag = nil;
			else
				current = current..character;
			end;
		end;
	end;
	
	if (current != "") then
		results[#results + 1] = current;
	end;
	
	return results;
end;

-- A function to modify a physical description.
function CW.kernel:ModifyPhysDesc(description)
	if (string.utf8len(description) <= 128) then
		if (!string.find(string.utf8sub(description, -2), "%p")) then
			return description..".";
		else
			return description;
		end;
	else
		return string.utf8sub(description, 1, 125).."...";
	end;
end;

local MAGIC_CHARACTERS = "([%(%)%.%%%+%-%*%?%[%^%$])";

-- A function to replace something in text without pattern matching.
function CW.kernel:Replace(text, find, replace)
	return (text:gsub(find:gsub(MAGIC_CHARACTERS, "%%%1"), replace));
end;

-- A function to create a new meta table.
function CW.kernel:NewMetaTable(baseTable)
	local object = {};
		setmetatable(object, baseTable);
		baseTable.__index = baseTable;
	return object;
end;

-- A function to make a proxy meta table.
function CW.kernel:MakeProxyTable(baseTable, baseClass, proxy)
	baseTable[proxy] = {};
	
	baseTable.__index = function(object, key)
		local value = rawget(object, key);
		
		if (type(value) == "function") then
			return value;
		elseif (object.__proxy) then
			return object:__proxy(key);
		else
			return object[proxy][key];
		end;
	end;
	
	baseTable.__newindex = function(object, key, value)
		if (type(value) ~= "function") then
			object[proxy][key] = value;
			return;
		end;
		
		rawset(object, key, value);
	end;
	
	for k, v in pairs(baseTable) do
		if (type(v) ~= "function" and k ~= proxy) then
			baseTable[proxy][k] = v;
			baseTable[k] = nil;
		end;
	end;
	
	setmetatable(baseTable, baseClass);
end;

-- A function to set whether a string should be in camel case.
function CW.kernel:SetCamelCase(text, bCamelCase)
	if (bCamelCase) then
		return string.gsub(text, "^.", string.lower);
	else
		return string.gsub(text, "^.", string.upper);
	end;
end;

-- A function to add files to the content download.
function CW.kernel:AddDirectory(directory, bRecursive)
	if (string.utf8sub(directory, -1) == "/") then
		directory = directory.."*.*";
	end;
	
	local files, folders = _file.Find(directory, "GAME", "namedesc");
	local rawDirectory = string.match(directory, "(.*)/").."/";
	
	for k, v in pairs(files) do
		self:AddFile(rawDirectory..v);
	end;
	
	if (bRecursive) then
		for k, v in pairs(folders) do
			if (v != ".." and v != ".") then
				self:AddDirectory(rawDirectory..v, true);
			end;
		end;
	end;
end;

-- A function to add a file to the content download.
function CW.kernel:AddFile(fileName)
	if (_file.Exists(fileName, "GAME")) then
		resource.AddFile(fileName);
	else
		-- print(Format("[Clockwork] File does not exist: %s.", fileName));
	end;
end;

-- A function to include files in a directory.
function CW.kernel:IncludeDirectory(directory, bFromBase)
	if (bFromBase) then
		directory = "clockwork/framework/"..directory;
	end;
	
	if (string.utf8sub(directory, -1) != "/") then
		directory = directory.."/";
	end;
	
	for k, v in pairs(_file.Find(directory.."*.lua", "LUA", "namedesc")) do
		self:IncludePrefixed(directory..v);
	end;
end;

-- A function to include a prefixed cwFile.
function CW.kernel:IncludePrefixed(fileName)
	local isShared = (string.find(fileName, "sh_") or string.find(fileName, "shared.lua"));
	local isClient = (string.find(fileName, "cl_") or string.find(fileName, "cl_init.lua"));
	local isServer = (string.find(fileName, "sv_"));
	
	if (isServer and !SERVER) then
		return;
	end;
	
	if (isShared and SERVER) then
		AddCSLuaFile(fileName);
	elseif (isClient and SERVER) then
		AddCSLuaFile(fileName);
		return;
	end;

	include(fileName);
end;

-- A function to include plugins in a directory.
function CW.kernel:IncludePlugins(directory, bFromBase)
	if (bFromBase) then
		directory = "Clockwork/"..directory;
	end;
	
	if (string.utf8sub(directory, -1) != "/") then
		directory = directory.."/";
	end;
	
	local files, pluginFolders = _file.Find(directory.."*", "LUA", "namedesc");
	
	for k, v in pairs(pluginFolders) do
		if (v != ".." and v != ".") then
			plugin.Include(directory..v.."/plugin");
		end;
	end;	
	
	return true;
end;

-- A function to perform the timer think.
function CW.kernel:CallTimerThink(curTime)
	for k, v in pairs(CW.Timers) do
		if (!v.paused) then
			if (curTime >= v.nextCall) then
				local bSuccess, value = pcall(v.Callback, unpack(v.arguments));
				
				if (!bSuccess) then
					MsgC(Color(255, 100, 0, 255), "[CW:Kernel] The '"..tostring(k).."' timer has failed to run.\n"..value.."\n");
				end;
				
				v.nextCall = curTime + v.delay;
				v.calls = v.calls + 1;
				
				if (v.calls == v.repetitions) then
					CW.Timers[k] = nil;
				end;
			end;
		end;
	end;
end;

-- A function to get whether a timer exists.
function CW.kernel:TimerExists(name)
	return CW.Timers[name];
end;

-- A function to start a timer.
function CW.kernel:StartTimer(name)
	if (CW.Timers[name] and CW.Timers[name].paused) then
		CW.Timers[name].nextCall = CurTime() + CW.Timers[name].timeLeft;
		CW.Timers[name].paused = nil;
	end;
end;

-- A function to pause a timer.
function CW.kernel:PauseTimer(name)
	if (CW.Timers[name] and !CW.Timers[name].paused) then
		CW.Timers[name].timeLeft = CW.Timers[name].nextCall - CurTime();
		CW.Timers[name].paused = true;
	end;
end;

-- A function to destroy a timer.
function CW.kernel:DestroyTimer(name)
	CW.Timers[name] = nil;
end;

-- A function to create a timer.
function CW.kernel:CreateTimer(name, delay, repetitions, Callback, ...)
	CW.Timers[name] = {
		calls = 0,
		delay = delay,
		nextCall = CurTime() + delay,
		Callback = Callback,
		arguments = {...},
		repetitions = repetitions
	};
end;

-- A function to run a function on the next frame.
function CW.kernel:OnNextFrame(name, Callback)
	self:CreateTimer(name, FrameTime(), 1, Callback);
end;

-- A function to get whether a player has access to an object.
function CW.kernel:HasObjectAccess(player, object)
	local hasAccess = false;
	local faction = player:GetFaction();
	
	if (object.access) then
		if (CW.player:HasAnyFlags(player, object.access)) then
			hasAccess = true;
		end;
	end;
	
	if (object.factions) then
		if (table.HasValue(object.factions, faction)) then
			hasAccess = true;
		end;
	end;
	
	if (object.classes) then
		local team = player:Team();
		local class = CW.class:FindByID(team);
		
		if (class) then
			if (table.HasValue(object.classes, team)
			or table.HasValue(object.classes, class.name)) then
				hasAccess = true;
			end;
		end;
	end;
	
	if (!object.access and !object.factions
	and !object.classes) then
		hasAccess = true;
	end;
	
	if (object.blacklist) then
		local team = player:Team();
		local class = CW.class:FindByID(team);
		
		if (table.HasValue(object.blacklist, faction)) then
			hasAccess = false;
		elseif (class) then
			if (table.HasValue(object.blacklist, team)
			or table.HasValue(object.blacklist, class.name)) then
				hasAccess = false;
			end;
		else
			for k, v in pairs(object.blacklist) do
				if (type(v) == "string") then
					if (CW.player:HasAnyFlags(player, v)) then
						hasAccess = false;
						
						break;
					end;
				end;
			end;
		end;
	end;
	
	if (object.HasObjectAccess) then
		return object:HasObjectAccess(player, hasAccess);
	end;
	
	return hasAccess;
end;

-- A function to get the sorted commands.
function CW.kernel:GetSortedCommands()
	local commands = {};
	local source = CW.command.stored;
	
	for k, v in pairs(source) do
		commands[#commands + 1] = k;
	end;
	
	table.sort(commands, function(a, b)
		return a < b;
	end);
	
	return commands;
end;

-- A function to zero a number to an amount of digits.
function CW.kernel:ZeroNumberToDigits(number, digits)
	return string.rep("0", math.Clamp(digits - string.utf8len(tostring(number)), 0, digits))..tostring(number);
end;

-- A function to get a short CRC from a value.
function CW.kernel:GetShortCRC(value)
	return math.ceil(util.CRC(value) / 100000);
end;

-- A function to validate a table's keys.
function CW.kernel:ValidateTableKeys(baseTable)
	for i = 1, #baseTable do
		if (!baseTable[i]) then
			table.remove(baseTable, i);
		end;
	end;
end;

-- A function to get the map's physics entities.
function CW.kernel:GetPhysicsEntities()
	local entities = {};
	
	for k, v in pairs(ents.FindByClass("prop_physicsmultiplayer")) do
		if (IsValid(v)) then
			entities[#entities + 1] = v;
		end;
	end;
	
	for k, v in pairs(ents.FindByClass("prop_physics")) do
		if (IsValid(v)) then
			entities[#entities + 1] = v;
		end;
	end;
	
	return entities;
end;

-- A function to create a multicall table (by Deco Da Man).
function CW.kernel:CreateMulticallTable(baseTable, object)
	local metaTable = getmetatable(baseTable) or {};
		function metaTable.__index(baseTable, key)
			return function(baseTable, ...)
				for k, v in pairs(baseTable) do
					object[key](v, ...);
				end;
			end
		end
	setmetatable(baseTable, metaTable);
	
	return baseTable;
end;

-- A function to create fake damage info.
function CW.kernel:FakeDamageInfo(damage, inflictor, attacker, position, damageType, damageForce)
	local damageInfo = DamageInfo();
	local realDamage = math.ceil(math.max(damage, 0));
	
	damageInfo:SetDamagePosition(position);
	damageInfo:SetDamageForce(Vector() * damageForce);
	damageInfo:SetDamageType(damageType);
	damageInfo:SetInflictor(inflictor);
	damageInfo:SetAttacker(attacker);
	damageInfo:SetDamage(realDamage);
	
	return damageInfo;
end;

-- A function to unpack a color.
function CW.kernel:UnpackColor(color)
	return color.r, color.g, color.b, color.a;
end;

-- A function to parse data in text.
function CW.kernel:ParseData(text)
	local classes = {"%^", "%!"};
	
	for k, v in pairs(classes) do
		for key in string.gmatch(text, v.."(.-)"..v) do
			local lower = false;
			local amount;
			
			if (string.utf8sub(key, 1, 1) == "(" and string.utf8sub(key, -1) == ")") then
				lower = true;
				amount = tonumber(string.utf8sub(key, 2, -2));
			else
				amount = tonumber(key);
			end;
			
			if (amount) then
				text = string.gsub(text, v..string.gsub(key, "([%(%)])", "%%%1")..v, tostring(self:FormatCash(amount, k == 2, lower)));
			end;
		end;
	end;
	
	for k in string.gmatch(text, "%*(.-)%*") do
		k = string.gsub(k, "[%(%)]", "");
		
		if (k != "") then
			text = string.gsub(text, "%*%("..k.."%)%*", tostring(CW.option:GetKey(k, true)));
			text = string.gsub(text, "%*"..k.."%*", tostring(CW.option:GetKey(k)));
		end;
	end;
	
	if (CLIENT) then
		for k in string.gmatch(text, ":(.-):") do
			if (k != "" and input.LookupBinding(k)) then
				text = self:Replace(text, ":"..k..":", "<"..string.upper(tostring(input.LookupBinding(k)))..">");
			end;
		end;
	end;
	
	return CW.config:Parse(text);
end;

function Clockwork.kernel:SetSharedVar(key, val, sendTo)
	return netvars.SetNetVar(key, val, sendTo);
end;

function Clockwork.kernel:GetSharedVar(key, default)
	return netvars.GetNetVar(key, default);
end;

-- Autorefresh support.
-- Called when the gamemode has been reloaded by AutoRefresh.
function CW:OnReloaded()
	CW.Reloaded = true;
	
	if (SERVER) then
		CW.database:OnConnected();
		print("[Clockwork] OnReloaded hook called serverside!");
	else
		CW.theme:Get():CreateFonts();
			CW.theme:CopySkin();
		CW.theme:Get():Initialize();

		CW.kernel:PrintColoredText(
			CW.kernel:GetLogTypeColor(LOGTYPE_MINOR), "Clockwork has AutoRefreshed clientside!"
		);
	end;
end;

timer.Create("CW.HalfSecondTimer", 0.5, 0, function()
	hook.Call("HalfSecond");
end);

timer.Create("CW.OneSecondTimer", 1, 0, function()
	hook.Call("OneSecond");
end);

timer.Create("CW.OneMinuteTimer", 60, 0, function()
	hook.Call("OneMinute");
end);
