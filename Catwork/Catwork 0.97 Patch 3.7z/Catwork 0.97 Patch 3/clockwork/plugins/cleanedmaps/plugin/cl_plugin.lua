--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

CW.config:AddToSystem("Remove Map Physics", "remove_map_physics", "Whether or not physics entities should be removed when the map is loaded.");