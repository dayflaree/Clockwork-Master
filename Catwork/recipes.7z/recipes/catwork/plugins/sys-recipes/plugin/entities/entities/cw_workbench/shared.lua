DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "Duck";
ENT.PrintName = "Workbench";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.UsableInVehicle = true;
ENT.PhysgunDisabled = true;