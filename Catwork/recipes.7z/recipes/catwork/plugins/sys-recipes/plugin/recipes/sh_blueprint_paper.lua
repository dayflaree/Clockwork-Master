local RECIPE = Clockwork.recipe:New("Paper");
	RECIPE:Require("Scrap Paper", 2, 2);	
	RECIPE:Require("Scrap Glue", 1, 1);		
	RECIPE:Output("Paper", 1);
	RECIPE.model = "models/props_c17/paper01.mdl";
	RECIPE.description = "A scrap peice of paper.";
	RECIPE.category = "Reusables";
RECIPE:Register();