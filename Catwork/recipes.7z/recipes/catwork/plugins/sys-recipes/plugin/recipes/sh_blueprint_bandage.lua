local RECIPE = Clockwork.recipe:New("Bandages");
	RECIPE:Require("Scrap Cloth", 2, 2);
	RECIPE:Output("Bandage", 3);
	RECIPE.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
	RECIPE.description = "Make-shift bandages.";
	RECIPE.category = "Medical";
RECIPE:Register();