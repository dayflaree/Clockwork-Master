local RECIPE = Clockwork.recipe:New("Black Sweater");
	RECIPE:Require("Salvaged Cloth", 2, 2);
	RECIPE:Require("Refined Cloth", 1, 1);
	RECIPE:Require("Kabar Hunting Knife", 1, 0);		
	RECIPE:Output("Black Sweater", 1);
	RECIPE.model = "models/tnb/items/shirt_citizen1.mdl";
	RECIPE.description = "A carefully-crafted black sweater.";
	RECIPE.category = "Clothing";
RECIPE:Register();