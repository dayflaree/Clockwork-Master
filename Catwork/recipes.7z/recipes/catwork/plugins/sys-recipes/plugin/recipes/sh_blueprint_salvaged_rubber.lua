local RECIPE = Clockwork.recipe:New("Salvaged Rubber");
	RECIPE:Require("Scrap Rubber", 3, 3);				
	RECIPE:Output("Salvaged Rubber", 1);
	RECIPE.model = "models/gibs/antlion_gib_small_3.mdl";
	RECIPE.description = "Some rubber of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();