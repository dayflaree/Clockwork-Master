local RECIPE = Clockwork.recipe:New("Facewrap");
	RECIPE:Require("Scrap Cloth", 2, 2);
	RECIPE:Require("Salvaged Cloth", 1, 1);
	RECIPE:Require("Kabar Hunting Knife", 1, 0);		
	RECIPE:Output("Facewrap", 1);
	RECIPE.model = "models/tnb/items/facewrap.mdl";
	RECIPE.description = "A facewrap made from scrap cloth.";
	RECIPE.category = "Clothing";
RECIPE:Register();