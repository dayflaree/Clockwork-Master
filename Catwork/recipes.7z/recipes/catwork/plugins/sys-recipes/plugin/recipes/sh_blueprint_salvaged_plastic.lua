local RECIPE = Clockwork.recipe:New("Salvaged Plastic");
	RECIPE:Require("Scrap Plastic", 3, 3);				
	RECIPE:Output("Salvaged Plastic", 1);
	RECIPE.model = "models/props_junk/vent001_chunk7.mdl";
	RECIPE.description = "Some plastic of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();