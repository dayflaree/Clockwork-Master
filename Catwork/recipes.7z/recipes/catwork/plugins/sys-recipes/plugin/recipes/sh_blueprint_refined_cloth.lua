local RECIPE = Clockwork.recipe:New("Refined Cloth");
	RECIPE:Require("Salvaged Cloth", 3, 3);
	RECIPE:Require("Salvaged Glue", 1, 1);			
	RECIPE:Require("Kabar Hunting Knife", 1, 0);			
	RECIPE:Output("Refined Cloth", 1);
	RECIPE.model = "models/props_wasteland/prison_toiletchunk01g.mdl";
	RECIPE.description = "A peice of cloth of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();