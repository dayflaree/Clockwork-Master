local RECIPE = Clockwork.recipe:New("Scrap Metal");
	RECIPE:Require("aluminum_can", 5, 5);	
	RECIPE:Require("Hammer", 1, 0);					
	RECIPE:Output("Scrap Metal", 1);
	RECIPE.model = "models/props_c17/oildrumchunk01e.mdl";
	RECIPE.description = "Some metal of poor quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();