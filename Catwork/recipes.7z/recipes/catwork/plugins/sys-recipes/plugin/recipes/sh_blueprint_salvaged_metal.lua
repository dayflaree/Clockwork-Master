local RECIPE = Clockwork.recipe:New("Salvaged Metal");
	RECIPE:Require("Scrap Metal", 3, 3);				
	RECIPE:Output("Salvaged Metal", 1);
	RECIPE.model = "models/gibs/metal_gib3.mdl";
	RECIPE.description = "Some metal of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();