local RECIPE = Clockwork.recipe:New("Refined Metal");
	RECIPE:Require("Salvaged Metal", 3, 3);				
	RECIPE:Output("Refined Metal", 1);
	RECIPE.model = "models/gibs/metal_gib2.mdl";
	RECIPE.description = "Some metal of high quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();