local RECIPE = Clockwork.recipe:New("Scrap Leather");
	RECIPE:Require("Suitcase", 2, 2);	
	RECIPE:Require("Kabar Hunting Knife", 1, 0);					
	RECIPE:Output("Scrap Leather", 1);
	RECIPE.model = "models/gibs/antlion_gib_small_2.mdl";
	RECIPE.description = "Some leather of poor quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();