local RECIPE = Clockwork.recipe:New("Medic Uniform");
	RECIPE:Require("Refined Cloth", 3, 3);
	RECIPE:Require("Salvaged Glue", 3, 3);		
	RECIPE:Require("Kabar Hunting Knife", 1, 0);			
	RECIPE:Output("medic_uniform", 1);
	RECIPE.model = "models/props_c17/suitcase_passenger_physics.mdl";
	RECIPE.description = "A uniform that signifies medical authority.";
	RECIPE.category = "Clothes";
RECIPE:Register();