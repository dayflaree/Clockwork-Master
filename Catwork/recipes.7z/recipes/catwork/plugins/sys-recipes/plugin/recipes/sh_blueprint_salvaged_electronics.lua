local RECIPE = Clockwork.recipe:New("Salvaged Electronics");
	RECIPE:Require("Scrap Electronics", 3, 3);				
	RECIPE:Output("Salvaged Electronics", 1);
	RECIPE.model = "models/props_lab/reciever01b.mdl";
	RECIPE.description = "Some electronics of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();