local RECIPE = Clockwork.recipe:New("Kevlar Sheet");
	RECIPE:Require("Refined Cloth", 3, 3);
	RECIPE:Require("Salvaged Glue", 2, 2);	
	RECIPE:Output("Kevlar Sheet", 1);
	RECIPE.model = "models/props_junk/garbage_newspaper001a.mdl";
	RECIPE.description = "A standard sheet of Kevlar.";
	RECIPE.category = "Materials";
RECIPE:Register();