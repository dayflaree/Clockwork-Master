local RECIPE = Clockwork.recipe:New("Refined Electronics");
	RECIPE:Require("Salvaged Electronics", 3, 3);
	RECIPE:Require("Salvaged Glue", 1, 1);					
	RECIPE:Output("Refined Electronics", 1);
	RECIPE.model = "models/props_lab/reciever01a.mdl";
	RECIPE.description = "Some electrical equipment of high quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();