local RECIPE = Clockwork.recipe:New("Salvaged Glue");
	RECIPE:Require("Scrap Glue", 3, 3);				
	RECIPE:Output("Salvaged Glue", 1);
	RECIPE.model = "models/props_lab/jar01a.mdl";
	RECIPE.description = "Some glue of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();