local RECIPE = Clockwork.recipe:New("Salvaged Chemicals");
	RECIPE:Require("Scrap Chemicals", 3, 3);				
	RECIPE:Output("Salvaged Chemicals", 1);
	RECIPE.model = "models/props_junk/garbage_plasticbottle001a.mdl";
	RECIPE.description = "Some chemicals of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();