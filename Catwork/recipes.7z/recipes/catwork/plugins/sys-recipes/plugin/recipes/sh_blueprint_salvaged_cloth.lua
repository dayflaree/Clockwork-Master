local RECIPE = Clockwork.recipe:New("Salvaged Cloth");
	RECIPE:Require("Scrap Cloth", 3, 3);				
	RECIPE:Output("Salvaged Cloth", 1);
	RECIPE.model = "models/props_wasteland/prison_toiletchunk01g.mdl";
	RECIPE.description = "Some cloth of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();