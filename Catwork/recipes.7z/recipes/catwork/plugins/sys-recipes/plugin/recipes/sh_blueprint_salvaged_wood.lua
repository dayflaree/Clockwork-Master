local RECIPE = Clockwork.recipe:New("Salvaged Wood");
	RECIPE:Require("Scrap Wood", 3, 3);				
	RECIPE:Output("Salvaged Wood", 1);
	RECIPE.model = "models/items/item_item_crate_chunk02.mdl";
	RECIPE.description = "Some wood of average quality.";
	RECIPE.category = "Raw Materials";
RECIPE:Register();