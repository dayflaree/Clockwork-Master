local ITEM = Clockwork.item:New()
ITEM.name = "Car Battery"
ITEM.model = "models/items/car_battery01.mdl"
ITEM.weight = 2.5
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "A battery that used to be in a car."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()