local ITEM = Clockwork.item:New()
ITEM.name = "Pins"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.1
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "A box with some pins in it, often used to keep things in place."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()