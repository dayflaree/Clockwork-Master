local ITEM = Clockwork.item:New()
ITEM.name = "Salvaged Leather"
ITEM.model = "models/gibs/shield_scanner_gib6.mdl"
ITEM.weight = 0.4
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A torn leather scrap that's in a rough shape."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()