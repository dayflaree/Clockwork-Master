local ITEM = Clockwork.item:New()
ITEM.name = "Salvaged Plastic"
ITEM.model = "models/props_junk/vent001_chunk7.mdl"
ITEM.weight = 0.4
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A salvaged piece of plastic."

	-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_c17/furnituremetal001a")
end

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()