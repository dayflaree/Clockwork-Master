local ITEM = Clockwork.item:New()
ITEM.name = "Refined Electronics"
ITEM.model = "models/props_lab/reciever01a.mdl"
ITEM.weight = 0.3
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "An item full of useful electrical parts."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()