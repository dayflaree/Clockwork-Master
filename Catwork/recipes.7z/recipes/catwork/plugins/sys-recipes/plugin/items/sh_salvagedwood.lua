local ITEM = Clockwork.item:New()
ITEM.name = "Salvaged Wood"
ITEM.model = "models/items/item_item_crate_chunk02.mdl"
ITEM.weight = 0.6
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A sturdy piece of wood."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()