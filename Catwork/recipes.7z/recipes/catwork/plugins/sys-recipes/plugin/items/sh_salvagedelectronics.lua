local ITEM = Clockwork.item:New()
ITEM.name = "Salvaged Electronics"
ITEM.model = "models/props_lab/reciever01b.mdl"
ITEM.weight = 0.7
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "An item full of mangled electrical parts."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()