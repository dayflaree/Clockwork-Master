local ITEM = Clockwork.item:New()
ITEM.name = "Kevlar Sheet"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl"
ITEM.weight = 0.4
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "A light sheet of kevlar."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()