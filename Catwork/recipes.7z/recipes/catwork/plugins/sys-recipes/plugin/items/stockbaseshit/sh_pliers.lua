local ITEM = Clockwork.item:New()
ITEM.name = "Pliers"
ITEM.model = "models/props_c17/tools_pliers01a.mdl"
ITEM.weight = 0.2
ITEM.category = "Tools"
ITEM.business = false
ITEM.description = "Simply a pair of pliers."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()