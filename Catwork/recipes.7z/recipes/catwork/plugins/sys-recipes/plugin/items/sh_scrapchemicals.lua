local ITEM = Clockwork.item:New();
ITEM.name = "Scrap Chemicals";
ITEM.cost = 6;
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl";
ITEM.weight = 0.4;
ITEM.access = "v";
ITEM.useText = "Inject";
ITEM.factions = {FACTION_MPF, FACTION_OTA};
ITEM.category = "Raw Materials"
ITEM.business = true;
ITEM.useSound = "items/medshot4.wav";
ITEM.description = "A small container with some liquid inside.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + Schema:GetHealAmount(player, 1.5), 0, player:GetMaxHealth() ) );
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();