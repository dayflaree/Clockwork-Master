local ITEM = Clockwork.item:New();
ITEM.name = "Salvaged Chemicals";
ITEM.cost = 15;
ITEM.model = "models/props_junk/garbage_plasticbottle001a.mdl";
ITEM.weight = 0.5;
ITEM.access = "v";
ITEM.useText = "Inject";
ITEM.factions = {FACTION_MPF, FACTION_OTA};
ITEM.category = "Raw Materials"
ITEM.business = true;
ITEM.useSound = "items/medshot4.wav";
ITEM.description = "A large container with some liquid inside.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + Schema:GetHealAmount(player, 1.5), 0, player:GetMaxHealth() ) );
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();