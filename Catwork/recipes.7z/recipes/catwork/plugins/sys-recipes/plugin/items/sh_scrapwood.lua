local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Wood"
ITEM.model = "models/items/item_item_crate_chunk01.mdl"
ITEM.weight = 0.2
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A chunk of dirty, worn wood."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()