local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Paper"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl"
ITEM.weight = 0.1
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A scrappy bit of paper."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()