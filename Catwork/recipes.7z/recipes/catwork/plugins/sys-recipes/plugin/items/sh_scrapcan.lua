local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Can"
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.weight = 0.02
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "An empty, dirty tin can."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()