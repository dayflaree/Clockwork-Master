local ITEM = Clockwork.item:New()
ITEM.name = "Salvaged Metal"
ITEM.model = "models/gibs/metal_gib3.mdl"
ITEM.weight = 0.4
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A sturdy and tough piece of metal."

-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_pipes/destroyedpipes01a")
end

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()