local ITEM = Clockwork.item:New()
ITEM.name = "Metal Pipe"
ITEM.model = "models/props_canal/mattpipe.mdl"
ITEM.weight = 0.8
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "A pipe, could be used for something."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()