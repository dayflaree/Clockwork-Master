local ITEM = Clockwork.item:New()
ITEM.name = "Refined Cloth"
ITEM.model = "models/props_wasteland/prison_toiletchunk01g.mdl"
ITEM.weight = 0.2
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A fabric that's in a smooth square shape."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()