local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Metal"
ITEM.model = "models/props_c17/oildrumchunk01e.mdl"
ITEM.weight = 0.3
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A chunk of dirty, bent metal."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()