local ITEM = Clockwork.item:New()
ITEM.name = "Common Collectible"
ITEM.model = "models/props_lab/huladoll.mdl"
ITEM.weight = 0.1
ITEM.category = "Collectibles"
ITEM.business = false
ITEM.description = "An Common collectible."

-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_pipes/GutterMetal01a")
end

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()