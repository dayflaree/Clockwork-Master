local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Glue"
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.weight = 0.2
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A nearly-empty jar of glue."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()