local ITEM = Clockwork.item:New()
ITEM.name = "Screw Driver"
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl"
ITEM.weight = 0.2
ITEM.category = "Tools"
ITEM.business = false
ITEM.description = "A tool useful for tightening screws."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()