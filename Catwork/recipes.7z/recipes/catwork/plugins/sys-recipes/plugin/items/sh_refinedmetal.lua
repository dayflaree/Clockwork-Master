local ITEM = Clockwork.item:New()
ITEM.name = "Refined Metal"
ITEM.model = "models/gibs/metal_gib2.mdl"
ITEM.weight = 0.8
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A strong and clean piece of metal."

-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_canal/metalwall005b")
end

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()