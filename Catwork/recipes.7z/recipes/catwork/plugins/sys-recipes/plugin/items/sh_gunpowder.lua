local ITEM = Clockwork.item:New()
ITEM.name = "Gunpowder"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.4
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "A small box with a fine black powder."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()