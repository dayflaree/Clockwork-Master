local ITEM = Clockwork.item:New()
ITEM.name = "Hammer"
ITEM.model = "models/props_lab/pipesystem02e.mdl"
ITEM.weight = 1
ITEM.category = "Tools"
ITEM.business = false
ITEM.description = "A tool useful for hitting or flattening."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()