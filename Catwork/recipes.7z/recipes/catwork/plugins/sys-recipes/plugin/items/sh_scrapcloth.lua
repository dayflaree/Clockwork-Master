local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Cloth"
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl"
ITEM.weight = 0.2
ITEM.category = "Raw Materials"
ITEM.business = false
ITEM.description = "A torn fabric that's in a rough square shape."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()