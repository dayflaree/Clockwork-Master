local ITEM = Clockwork.item:New()
ITEM.name = "Scrap Electronics"
ITEM.model = "models/props_lab/reciever01d.mdl"
ITEM.weight = 0.3
ITEM.category = "Scraps"
ITEM.business = false
ITEM.description = "Some broken electronics with few usable parts left."

function ITEM:CanPickup(player, quickUse, itemEntity) end

function ITEM:OnDrop(player, position) end

ITEM:Register()