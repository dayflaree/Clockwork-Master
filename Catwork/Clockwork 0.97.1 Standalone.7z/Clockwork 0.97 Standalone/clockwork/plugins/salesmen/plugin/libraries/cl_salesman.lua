--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

CW.salesman = CW.kernel:NewLibrary("Salesman");

-- A function to get whether the salesman is open.
function CW.salesman:IsSalesmanOpen()
	local panel = self:GetPanel();
	
	if (IsValid(panel) and panel:IsVisible()) then
		return true;
	end;
end;

-- A function to get whether the items are bought shipments.
function CW.salesman:BuyInShipments()
	return self.buyInShipments;
end;

-- A function to get the salesman price scale.
function CW.salesman:GetPriceScale()
	return self.priceScale or 1;
end;

-- A function to get whether the salesman's chat bubble is shown.
function CW.salesman:GetShowChatBubble()
	return self.showChatBubble;
end;

-- A function to get the salesman stock.
function CW.salesman:GetStock()
	return self.stock;
end;

-- A function to get the salesman cash.
function CW.salesman:GetCash()
	return self.cash;
end;

-- A function to get the salesman buy rate.
function CW.salesman:GetBuyRate()
	return self.buyRate;
end;

-- A function to get the salesman classes.
function CW.salesman:GetClasses()
	return self.classes;
end;

-- A function to get the salesman factions.
function CW.salesman:GetFactions()
	return self.factions;
end;

-- A function to get the salesman text.
function CW.salesman:GetText()
	return self.text;
end;

-- A function to get what the salesman sells.
function CW.salesman:GetSells()
	return self.sells;
end;

-- A function to get what the salesman buys.
function CW.salesman:GetBuys()
	return self.buys;
end;

-- A function to get the salesman items.
function CW.salesman:GetItems()
	return self.items;
end;

-- A function to get the salesman panel.
function CW.salesman:GetPanel()
	return self.panel;
end;

-- A function to get the salesman model.
function CW.salesman:GetModel()
	return self.model;
end;

-- A function to get the salesman name.
function CW.salesman:GetName()
	return self.name;
end;