--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("Me");
COMMAND.tip = "Speak in third person to others around you.";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;
COMMAND.alias = {"Perform"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");
	
	if (text == "") then
		CW.player:Notify(player, L(player, "NotEnoughText"));
		
		return;
	end;
	
	text = string.gsub(text, "^.", string.lower);
	text = player:Name().." "..text;

	chatbox.AddText(player, text, {textColor = Color("#89D235"), filter = "player_events", icon = false});
end;

COMMAND:Register();