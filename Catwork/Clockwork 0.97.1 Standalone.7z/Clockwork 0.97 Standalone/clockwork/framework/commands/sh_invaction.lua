--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("InvAction");
COMMAND.tip = "Run an inventory action on an item.";
COMMAND.text = "<string Action> <string UniqueID> [string ItemID]";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local itemAction = string.lower(arguments[1]);
	itemAction = itemAction:Replace("#", "");
	local itemTable = player:FindItemByID(arguments[2], tonumber(arguments[3]));
	
	if (itemTable) then
		local customFunctions = itemTable("customFunctions");
		
		if (customFunctions) then
			for k, v in pairs(customFunctions) do
				if (string.lower(v) == itemAction) then
					if (itemTable.OnCustomFunction) then
						itemTable:OnCustomFunction(player, v);
						return;
					end;
				end;
			end;
		end;
		
		if (itemAction == "destroy") then
			if (plugin.Call("PlayerCanDestroyItem", player, itemTable)) then
				CW.item:Destroy(player, itemTable);
			end;
		elseif (itemAction == "drop") then
			local position = player:GetEyeTraceNoCursor().HitPos;
			
			if (player:GetShootPos():Distance(position) <= 192) then
				if (plugin.Call("PlayerCanDropItem", player, itemTable, position)) then
					CW.item:Drop(player, itemTable);
				end;
			else
				CW.player:Notify(player, "You cannot drop the item that far away!");
			end;
		elseif (itemAction == "use") then
			if (player:InVehicle() and itemTable("useInVehicle") == false) then
				CW.player:Notify(player, "You cannot use this item in a vehicle!");
				
				return;
			end;
			
			if (plugin.Call("PlayerCanUseItem", player, itemTable)) then
				return CW.item:Use(player, itemTable);
			end;
		else
			plugin.Call("PlayerUseUnknownItemFunction", player, itemTable, itemAction);
		end;
	else
		CW.player:Notify(player, "You do not own this item!");
	end;
end;

COMMAND:Register();