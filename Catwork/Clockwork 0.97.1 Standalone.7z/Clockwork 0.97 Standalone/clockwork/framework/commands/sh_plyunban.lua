--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("PlyUnban");
COMMAND.tip = "Unban a Steam ID from the server.";
COMMAND.text = "<string SteamID|IPAddress>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"Unban"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local playersTable = CW.config:Get("mysql_players_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local identifier = string.upper(arguments[1]);
	
	if (CW.bans.stored[identifier]) then
		CW.player:NotifyAll(player:Name().." has unbanned '"..CW.bans.stored[identifier].steamName.."'.");
		CW.bans:Remove(identifier);
	else
		CW.player:Notify(player, "There are no banned players with the '"..identifier.."' identifier!");
	end;
end;

COMMAND:Register();