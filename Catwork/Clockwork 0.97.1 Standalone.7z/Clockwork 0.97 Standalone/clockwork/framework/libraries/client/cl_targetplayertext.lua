--[[ 
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

CW.TargetPlayerText = CW.kernel:NewLibrary("TargetPlayerText");
CW.TargetPlayerText.stored = CW.TargetPlayerText.stored or {};

-- A function to add some target player text.
function CW.TargetPlayerText:Add(uniqueID, text, color, scale)
	self.stored[#self.stored + 1] = {
		uniqueID = uniqueID,
		color = color,
		scale = scale,
		text = text
	};
end;
	
-- A function to get some target player text.
function CW.TargetPlayerText:Get(uniqueID)
	for k, v in pairs(self.stored) do
		if (v.uniqueID == uniqueID) then
			return v;
		end;
	end;
end;

-- A function to destroy some target player text.
function CW.TargetPlayerText:Destroy(uniqueID)
	for k, v in pairs(self.stored) do
		if (v.uniqueID == uniqueID) then
			table.remove(self.stored, k);
		end;
	end;
end;