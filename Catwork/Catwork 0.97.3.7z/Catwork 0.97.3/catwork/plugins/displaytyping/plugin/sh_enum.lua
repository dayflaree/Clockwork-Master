--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

TYPING_WHISPER = 6;
TYPING_PERFORM = 5;
TYPING_NORMAL = 4;
TYPING_RADIO = 3;
TYPING_YELL = 2;
TYPING_OOC = 1;