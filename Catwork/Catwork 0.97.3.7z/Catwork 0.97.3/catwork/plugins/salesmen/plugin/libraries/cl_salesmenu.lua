--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.salesmenu = CW.kernel:NewLibrary("Salesmenu");

-- A function to get whether the salesmenu is open.
function CW.salesmenu:IsSalesmenuOpen()
	local panel = self:GetPanel();
	
	if (IsValid(panel) and panel:IsVisible()) then
		return true;
	end;
end;

-- A function to get whether the items are bought shipments.
function CW.salesmenu:BuyInShipments()
	return self.buyInShipments;
end;

-- A function to get the salesmenu price scale.
function CW.salesmenu:GetPriceScale()
	return self.priceScale or 1;
end;

-- A function to get the salesmenu buy rate.
function CW.salesmenu:GetBuyRate()
	return self.buyRate;
end;

-- A function to get the salesmenu classes.
function CW.salesmenu:GetClasses()
	return self.classes;
end;

-- A function to get the salesmenu factions.
function CW.salesmenu:GetFactions()
	return self.factions;
end;

-- A function to get the salesmenu stock.
function CW.salesmenu:GetStock()
	return self.stock;
end;

-- A function to get the salesmenu cash.
function CW.salesmenu:GetCash()
	return self.cash;
end;

-- A function to get the salesmenu text.
function CW.salesmenu:GetText()
	return self.text;
end;

-- A function to get the salesmenu entity.
function CW.salesmenu:GetEntity()
	return self.entity;
end;

-- A function to get the salesmenu buys.
function CW.salesmenu:GetBuys()
	return self.buys;
end;

-- A function to get the salesmenu sels.
function CW.salesmenu:GetSells()
	return self.sells;
end;

-- A function to get the salesmenu panel.
function CW.salesmenu:GetPanel()
	return self.panel;
end;

-- A function to get the salesmenu name.
function CW.salesmenu:GetName()
	return self.name;
end;