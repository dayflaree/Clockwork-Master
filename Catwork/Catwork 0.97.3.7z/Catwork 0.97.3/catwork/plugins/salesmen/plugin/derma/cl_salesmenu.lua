--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local salesmenuName = CW.salesmenu:GetName();
	
	self:SetTitle(salesmenuName);
	self:SetBackgroundBlur(true);
	self:SetDeleteOnClose(false);
	
	-- Called when the button is clicked.
	function self.btnClose.DoClick(button)
		CloseDermaMenus();
		self:Close(); self:Remove();
		
		netstream.Start("SalesmanDone", CW.salesmenu.entity);
			CW.salesmenu.buyInShipments = nil;
			CW.salesmenu.priceScale = nil;
			CW.salesmenu.factions = nil;
			CW.salesmenu.buyRate = nil;
			CW.salesmenu.classes = nil;
			CW.salesmenu.entity = nil;
			CW.salesmenu.stock = nil;
			CW.salesmenu.sells = nil;
			CW.salesmenu.cash = nil;
			CW.salesmenu.text = nil;
			CW.salesmenu.buys = nil;
			CW.salesmenu.name = nil;
		gui.EnableScreenClicker(false);
	end;
	
	self.propertySheet = vgui.Create("DPropertySheet", self);
	self.propertySheet:SetPadding(4);
	
	if (table.Count(CW.salesmenu:GetSells()) > 0) then
		self.sellsPanel = vgui.Create("cwPanelList");
		self.sellsPanel:SetPadding(2);
		self.sellsPanel:SetSpacing(3);
		self.sellsPanel:SizeToContents();
		self.sellsPanel:EnableVerticalScrollbar();
		
		self.propertySheet:AddSheet("Sells", self.sellsPanel, "icon16/box.png", nil, nil, "View items that "..salesmenuName.." sells.");
	end;
	
	if (table.Count(CW.salesmenu:GetBuys()) > 0) then
		self.buysPanel = vgui.Create("cwPanelList");
		self.buysPanel:SetPadding(2);
		self.buysPanel:SetSpacing(3);
		self.buysPanel:SizeToContents();
		self.buysPanel:EnableVerticalScrollbar();
		
		self.propertySheet:AddSheet("Buys", self.buysPanel, "icon16/add.png", nil, nil, "View items that "..salesmenuName.." buys.");
	end;

	CW.kernel:SetNoticePanel(self);
end;

-- A function to rebuild a panel.
function PANEL:RebuildPanel(typeName, panelList, inventory)
	panelList:Clear(true);
	panelList.inventory = inventory;
	
	if (CW.config:Get("cash_enabled"):Get()) then
		local totalCash = CW.salesmenu:GetCash();
		
		if (totalCash > -1) then
			local cashForm = vgui.Create("DForm", panelList);
				cashForm:SetName(CW.option:GetKey("name_cash"));
				cashForm:SetPadding(4);
			panelList:AddItem(cashForm);
			
			cashForm:Help(
				CW.salesmenu:GetName().." has "..CW.kernel:FormatCash(totalCash, nil, true).." to their name."
			);
		end;
	end;
	
	local categories = {};
	local items = {};
	
	for k, v in pairs(panelList.inventory) do
		if (typeName == "Sells") then
			local itemTable = CW.item:FindByID(k);
			
			if (itemTable) then
				local itemCategory = itemTable("category");
				
				if (itemCategory) then
					items[itemCategory] = items[itemCategory] or {};
					items[itemCategory][#items[itemCategory] + 1] = {k, v};
				end;
			end;
		else
			local itemsList = CW.inventory:GetItemsByID(
				CW.inventory:GetClient(), k
			);
			
			if (itemsList) then
				for k2, v2 in pairs(itemsList) do
					local itemCategory = v2("category");
					
					if (itemCategory) then
						items[itemCategory] = items[itemCategory] or {};
						items[itemCategory][#items[itemCategory] + 1] = v2;
					end;
				end;
			end;
		end;
	end;
	
	for k, v in pairs(items) do
		categories[#categories + 1] = {
			category = k,
			items = v
		};
	end;
	
	if (table.Count(categories) > 0) then
		for k, v in pairs(categories) do
			local collapsibleCategory = CW.kernel:CreateCustomCategoryPanel(v.category, panelList);
				collapsibleCategory:SetCookieName("Salesmenu"..typeName..v.category);
			panelList:AddItem(collapsibleCategory);
			
			local categoryList = vgui.Create("DPanelList", collapsibleCategory);
				categoryList:EnableHorizontal(true);
				categoryList:SetAutoSize(true);
				categoryList:SetPadding(4);
				categoryList:SetSpacing(4);
			collapsibleCategory:SetContents(categoryList);
			
			if (typeName == "Sells") then
				table.sort(v.items, function(a, b)
					local itemTableA = CW.item:FindByID(a[1]);
					local itemTableB = CW.item:FindByID(b[1]);
					
					if (itemTableA.cost == itemTableB.cost) then
						return itemTableA.name < itemTableB.name;
					else
						return itemTableA.cost > itemTableB.cost;
					end;
				end);
				
				for k2, v2 in pairs(v.items) do
					CURRENT_ITEM_DATA = {
						itemTable = CW.item:FindByID(v2[1]),
						typeName = typeName
					};
					
					categoryList:AddItem(
						vgui.Create("cwSalesmenuItem", categoryList)
					);
				end;
			else
				table.sort(v.items, function(a, b)
					if (a.cost == b.cost) then
						return a.name < b.name;
					else
						return a.cost > b.cost;
					end;
				end);
				
				for k2, v2 in pairs(v.items) do
					CURRENT_ITEM_DATA = {
						itemTable = v2,
						typeName = typeName
					};
					
					categoryList:AddItem(
						vgui.Create("cwSalesmenuItem", categoryList)
					);
				end;
			end;
		end;
	end;
end;

-- A function to rebuild the panel.
function PANEL:Rebuild()
	if (IsValid(self.sellsPanel)) then
		self:RebuildPanel("Sells", self.sellsPanel, CW.salesmenu:GetSells());
	end;
	
	if (IsValid(self.buysPanel)) then
		self:RebuildPanel("Buys", self.buysPanel, CW.salesmenu:GetBuys());
	end;
end;

-- Called each frame.
function PANEL:Think()
	local scrW = ScrW();
	local scrH = ScrH();
	
	self:SetSize(scrW * 0.5, scrH * 0.75);
	self:SetPos((scrW / 2) - (self:GetWide() / 2), (scrH / 2) - (self:GetTall() / 2));
end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	DFrame.PerformLayout(self);

	self.propertySheet:StretchToParent(4, 28, 4, 4);
end;

vgui.Register("cwSalesmenu", PANEL, "DFrame");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local itemData = self:GetParent().itemData or CURRENT_ITEM_DATA;
	
	self:SetSize(40, 40);
	self.itemTable = itemData.itemTable;
	self.typeName = itemData.typeName;
	self.spawnIcon = CW.kernel:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self));
	self.spawnIcon:SetColor(self.itemTable("color"));
	
	-- Called when the spawn icon is clicked.
	function self.spawnIcon.DoClick(spawnIcon)
		local entity = CW.salesmenu:GetEntity();
		
		if (IsValid(entity)) then
			netstream.Start("Salesmenu", {
				tradeType = self.typeName,
				uniqueID = self.itemTable("uniqueID"),
				itemID = self.itemTable("itemID"),
				entity = entity
			});
		end;
	end;
	
	local model, skin = CW.item:GetIconInfo(self.itemTable);
	self.spawnIcon:SetModel(model, skin);
	self.spawnIcon:SetToolTip("");
	self.spawnIcon:SetSize(40, 40);
end;

-- Called each frame.
function PANEL:Think()
	local function DisplayCallback(displayInfo)
		local priceScale = 1;
		local amount = 0;
		
		if (self.typeName == "Sells") then
			if (CW.salesmenu:BuyInShipments()) then
				amount = self.itemTable("batch");
			else
				amount = 1;
			end;
			
			priceScale = CW.salesmenu:GetPriceScale();
		elseif (self.typeName == "Buys") then
			priceScale = CW.salesmenu:GetBuyRate() / 100;
		end;
		
		if (CW.config:Get("cash_enabled"):Get()) then
			if (self.itemTable("cost") != 0) then
				displayInfo.weight = CW.kernel:FormatCash(
					(self.itemTable("cost") * priceScale) * math.max(amount, 1)
				);
			else
				displayInfo.weight = "Free";
			end;
			
			local overrideCash = CW.salesmenu.sells[self.itemTable("uniqueID")];
			
			if (self.typeName == "Buys") then
				overrideCash = CW.salesmenu.buys[self.itemTable("uniqueID")];
			end;
			
			if (type(overrideCash) == "number") then
				displayInfo.weight = CW.kernel:FormatCash(overrideCash * math.max(amount, 1));
			end;
		end;
		
		if (self.typeName == "Sells") then
			if (amount > 1) then
				displayInfo.name = amount.." "..CW.kernel:Pluralize(self.itemTable("name"));
			else
				displayInfo.name = self.itemTable("name");
			end;
		end;
		
		local iStockLeft = CW.salesmenu.stock[self.itemTable("uniqueID")];
		
		if (self.typeName == "Sells" and iStockLeft) then
			displayInfo.itemTitle = "["..iStockLeft.."] ["..displayInfo.name..", "..displayInfo.weight.."]";
		end;
	end;
	
	self.spawnIcon:SetMarkupToolTip(
		CW.item:GetMarkupToolTip(self.itemTable, true, DisplayCallback)
	);
	self.spawnIcon:SetColor(self.itemTable("color"));
end;

vgui.Register("cwSalesmenuItem", PANEL, "DPanel");