-- This code is taken from NutScript.
-- NutScript and code license are found here:
-- https://github.com/Chessnut/NutScript

if (netvars) then return; end;

library.New("netvars", _G);

if (SERVER) then

	local entityMeta = FindMetaTable("Entity")
	local playerMeta = FindMetaTable("Player")
	
	local stored = {};
	local globals = {};

	-- Check if there is an attempt to send a function. Can't send those.
	local function checkBadType(name, object)
		local objectType = type(object)
		
		if (objectType == "function") then
			ErrorNoHalt("Net var '"..name.."' contains a bad object type!")
			
			return true
		elseif (objectType == "table") then
			for k, v in pairs(object) do
				-- Check both the key and the value for tables, and has recursion.
				if (checkBadType(name, k) or checkBadType(name, v)) then
					return true
				end
			end
		end
	end

	function netvars.SetNetVar(key, value, receiver)
		if (checkBadType(key, value)) then return end
		if (netvars.GetNetVar(key) == value) then return end
		if (globals[key] == value) then return end

		globals[key] = value
		netstream.Start(receiver, "gVar", key, value)
	end

	function playerMeta:SyncVars()
		for entity, data in pairs(stored) do
			if (entity == "globals") then
				for k, v in pairs(data) do
					netstream.Start(self, "gVar", k, v)
				end
			elseif (IsValid(entity)) then
				for k, v in pairs(data) do
					netstream.Start(self, "nVar", entity:EntIndex(), k, v)
				end
			end
		end
	end

	function entityMeta:SendNetVar(key, receiver)
		netstream.Start(receiver, "nVar", self:EntIndex(), key, stored[self] and stored[self][key])
	end

	function entityMeta:ClearNetVars(receiver)
		stored[self] = nil
		netstream.Start(receiver, "nDel", self:EntIndex())
	end

	function entityMeta:SetNetVar(key, value, receiver)
		if (checkBadType(key, value)) then return end
		if (self:GetNetVar(key) == value) then return end
			
		stored[self] = stored[self] or {}

		if (stored[self][key] != value) then
			stored[self][key] = value
		end

		self:SendNetVar(key, receiver)
	end

	function entityMeta:GetNetVar(key, default)
		if (stored[self] and stored[self][key] != nil) then
			return stored[self][key]
		end

		return default
	end

	function playerMeta:SetLocalVar(key, value)
		if (checkBadType(key, value)) then return end
		
		stored[self] = stored[self] or {}
		stored[self][key] = value

		netstream.Start(self, "nLcl", key, value)
	end

	playerMeta.GetLocalVar = entityMeta.GetNetVar

	function netvars.GetNetVar(key, default)
		local value = globals[key]

		return value != nil and value or default
	end

	hook.Add("EntityRemoved", "nCleanUp", function(entity)
		entity:ClearNetVars()
	end)

	hook.Add("PlayerInitialSpawn", "nSync", function(client)
		client:SyncVars()
	end)

else

	local entityMeta = FindMetaTable("Entity")
	local playerMeta = FindMetaTable("Player")

	local stored = {};
	local globals = {};

	netstream.Hook("nVar", function(index, key, value)
		stored[index] = stored[index] or {}
		stored[index][key] = value
	end)

	netstream.Hook("nDel", function(index)
		stored[index] = nil
	end)

	netstream.Hook("nLcl", function(key, value)
		stored[LocalPlayer():EntIndex()] = stored[LocalPlayer():EntIndex()] or {}
		stored[LocalPlayer():EntIndex()][key] = value
	end)

	netstream.Hook("gVar", function(key, value)
		globals[key] = value
	end)

	function netvars.GetNetVar(key, default)
		local value = globals[key]

		return value != nil and value or default
	end

	function entityMeta:GetNetVar(key, default)
		local index = self:EntIndex()

		if (stored[index] and stored[index][key] != nil) then
			return stored[index][key]
		end

		return default
	end

	playerMeta.GetLocalVar = entityMeta.GetNetVar

end