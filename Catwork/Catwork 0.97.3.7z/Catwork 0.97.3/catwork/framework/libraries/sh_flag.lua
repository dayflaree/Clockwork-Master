--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.flag = CW.kernel:NewLibrary("Flag");
CW.flag.stored = CW.flag.stored or {};

-- A function to add a new flag.
function CW.flag:Add(flag, name, details)
	if (CLIENT and !self.stored[flag]) then
		CW.directory:AddCode("Flags", [[
			<tr>
				<td class="cwTableContent"><b><font color="red">]]..flag..[[</font></b></td>
				<td class="cwTableContent"><i>]]..details..[[</i></td>
			</tr>
		]], nil, flag, function(htmlCode, sortData)
			if (CW.player:HasFlags(CW.Client, sortData)) then
				return CW.kernel:Replace(CW.kernel:Replace(htmlCode, [[<font color="red">]], [[<font color="green">]]), "</font>", "</font>");
			else
				return htmlCode;
			end;
		end);
	end;
	
	self.stored[flag] = {
		name = name,
		details = details
	};
end;

-- A function to get a flag.
function CW.flag:Get(flag)
	return self.stored[flag];
end;

-- A function to get the stored flags.
function CW.flag:GetStored()
	return self.stored;
end;

-- A function to get a flag's name.
function CW.flag:GetName(flag, default)
	if (self.stored[flag]) then
		return self.stored[flag].name;
	else
		return default;
	end;
end;

-- A function to get a flag's details.
function CW.flag:GetDescription(flag, default)
	if (self.stored[flag]) then
		return self.stored[flag].details;
	else
		return default;
	end;
end;

-- A function to get a flag by it's name.
function CW.flag:GetFlagByName(name, default)
	local lowerName = string.lower(name);
	
	for k, v in pairs(self.stored) do
		if (string.lower(v.name) == lowerName) then
			return k;
		end;
	end;
	
	return default;
end;

CW.flag:Add("C", "Spawn Vehicles", "Access to spawn vehicles.");
CW.flag:Add("r", "Spawn Ragdolls", "Access to spawn ragdolls.");
CW.flag:Add("c", "Spawn Chairs", "Access to spawn chairs.");
CW.flag:Add("e", "Spawn Props", "Access to spawn props.");
CW.flag:Add("p", "Physics Gun", "Access to the physics gun.");
CW.flag:Add("n", "Spawn NPCs", "Access to spawn NPCs.");
CW.flag:Add("t", "Tool Gun", "Access to the tool gun.");
CW.flag:Add("G", "Give Item", "Access to the give items.");