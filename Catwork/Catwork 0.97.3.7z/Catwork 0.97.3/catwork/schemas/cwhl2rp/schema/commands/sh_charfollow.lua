--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharFollow");
COMMAND.tip = "Follow the closest character to you (as a scanner).";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema.scanners[player]) then
		local scanner = Schema.scanners[player][1];
		
		if (IsValid(scanner)) then
			local closest;
			
			for k, v in ipairs( _player.GetAll() ) do
				if (v:HasInitialized() and !Schema.scanners[v]) then
					if (CW.player:CanSeeEntity(player, v, 0.9, true)) then
						local distance = v:GetPos():Distance( scanner:GetPos() );
						
						if (!closest or distance < closest[2]) then
							closest = {v, distance};
						end;
					end;
				end;
			end;
			
			if (closest) then
				scanner.followTarget = closest[1];
				
				scanner:Input("SetFollowTarget", closest[1], closest[1], "!activator");
				
				CW.player:Notify(player, "You are now following "..closest[1]:Name().."!");
			else
				CW.player:Notify(player, "There are no characters near you!");
			end;
		end;
	else
		CW.player:Notify(player, "You are not a scanner!");
	end;
end;

COMMAND:Register();