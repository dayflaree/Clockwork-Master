--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "Medical";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "med";
	ATTRIBUTE.description = "Affects your overall medical skills, e.g: health gained from vials and kits.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_MEDICAL = CW.attribute:Register(ATTRIBUTE);