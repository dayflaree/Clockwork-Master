--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "Agility";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "agt";
	ATTRIBUTE.description = "Affects your overall speed, e.g: how fast you run.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_AGILITY = CW.attribute:Register(ATTRIBUTE);