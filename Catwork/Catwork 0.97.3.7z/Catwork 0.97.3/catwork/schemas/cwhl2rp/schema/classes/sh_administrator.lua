--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local CLASS = CW.class:New("Administrator");
	CLASS.color = Color(255, 200, 100, 255);
	CLASS.wages = 50;
	CLASS.factions = {FACTION_ADMIN};
	CLASS.isDefault = true;
	CLASS.wagesName = "Allowance";
	CLASS.description = "A human Administrator advised by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing a clean brown suit";
CLASS_ADMIN = CLASS:Register();