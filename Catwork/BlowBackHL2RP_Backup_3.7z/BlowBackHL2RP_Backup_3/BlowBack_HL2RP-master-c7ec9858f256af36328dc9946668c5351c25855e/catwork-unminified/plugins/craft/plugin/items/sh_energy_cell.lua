

ITEM.name = "Energy Cell"
ITEM.PrintName = "Энергоячейка"
ITEM.model = "models/items/battery.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Заряженный источник питания."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

