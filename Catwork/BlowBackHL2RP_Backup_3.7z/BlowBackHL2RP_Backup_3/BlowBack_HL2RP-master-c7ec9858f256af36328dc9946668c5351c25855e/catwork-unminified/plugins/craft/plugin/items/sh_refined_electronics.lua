

ITEM.name = "Refined Electronics"
ITEM.PrintName = "Электрозапчасти"
ITEM.model = "models/props_lab/reciever01b.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Здесь полным полно всякой электрической всячины."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

