local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "HK-21"
BLUEPRINT.uniqueID = "blueprint_hk21"
BLUEPRINT.model = "models/weapons/w_hmg.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Починить пулемет, заменив некоторые детали."
BLUEPRINT.craftplace = "cw_craft_wep"
BLUEPRINT.reqatt = {
	{"rem", 60}
}
BLUEPRINT.updatt = {
	{"rem", 40}
}
BLUEPRINT.required = {
	{"screw_driver", 1},
	{"weld", 1},
	{"wrench", 1}
}
BLUEPRINT.recipe = {
	{"broken_hk-21", 1},
	{"reclaimed_metal", 3},
	{"box_of_screws", 1},
}
BLUEPRINT.finish = {
	{"sxbase_hmg", 1}
}
BLUEPRINT:Register();