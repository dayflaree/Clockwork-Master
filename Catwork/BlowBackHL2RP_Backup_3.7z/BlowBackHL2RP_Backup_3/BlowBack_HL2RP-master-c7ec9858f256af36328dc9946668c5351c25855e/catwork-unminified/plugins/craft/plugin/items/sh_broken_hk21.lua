

ITEM.name = "Broken HK-21"
ITEM.PrintName = "Поломанный HK-21"
ITEM.model = "models/weapons/w_hmg.mdl"
ITEM.weight = 6
ITEM.category = "Materials"
ITEM.description = "Пулемет без сошек, рукояти и ствольной коробки."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

