

ITEM.name = "Cloth"
ITEM.PrintName = "Ткань"
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Лоскут размером примерно 50х50 см."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

