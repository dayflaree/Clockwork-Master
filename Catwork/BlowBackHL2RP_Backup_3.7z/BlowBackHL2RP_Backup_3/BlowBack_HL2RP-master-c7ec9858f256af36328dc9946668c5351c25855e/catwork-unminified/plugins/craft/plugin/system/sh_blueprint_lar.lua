local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "LAR Grizzly Big Boar"
BLUEPRINT.uniqueID = "blueprint_lar"
BLUEPRINT.model = "models/rtb_weapons/w_sniper.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Починить снайперскую винтовку, заменив некоторые детали."
BLUEPRINT.craftplace = "cw_craft_wep"
BLUEPRINT.reqatt = {
	{"rem", 80}
}
BLUEPRINT.updatt = {
	{"rem", 80}
}
BLUEPRINT.required = {
	{"screw_driver", 1},
	{"weld", 1},
	{"wrench", 1}
}
BLUEPRINT.recipe = {
	{"broken_lar", 1},
	{"reclaimed_metal", 2},
	{"box_of_screws", 1},
	{"plastic", 1},
	{"empty_glass_bottle", 1}
}
BLUEPRINT.finish = {
	{"sxbase_lar", 1}
}
BLUEPRINT:Register();