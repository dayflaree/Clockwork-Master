
ITEM.name = "Wooden Board"
ITEM.PrintName = "Деревянная доска"
ITEM.uniqueID = "wooden_board"
ITEM.model = "models/gibs/furniture_gibs/furnituredrawer002a_gib07.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "Грязная и местами поврежденная доска."

function ITEM:OnDrop(player, position) end

