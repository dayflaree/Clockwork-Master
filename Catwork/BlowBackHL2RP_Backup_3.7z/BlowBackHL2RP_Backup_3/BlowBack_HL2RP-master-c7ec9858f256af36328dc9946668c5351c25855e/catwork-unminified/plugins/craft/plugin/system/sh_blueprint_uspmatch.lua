local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "USP Match"
BLUEPRINT.uniqueID = "blueprint_uspmatch"
BLUEPRINT.model = "models/weapons/w_uspmatch.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Починить пистолет, заменив некоторые детали."
BLUEPRINT.craftplace = "cw_craft_wep"
BLUEPRINT.reqatt = {
	{"rem", 30}
}
BLUEPRINT.updatt = {
	{"rem", 20}
}
BLUEPRINT.required = {
	{"screw_driver", 1}
}
BLUEPRINT.recipe = {
	{"broken_usp_match", 1},
	{"reclaimed_metal", 1},
	{"box_of_screws", 1}
}
BLUEPRINT.finish = {
	{"sxbase_uspmatch", 1}
}
BLUEPRINT:Register();