

ITEM.name = "Broken M40A1"
ITEM.PrintName = "Поломанная М40А1"
ITEM.model = "models/items/m40a1.mdl"
ITEM.weight = 3
ITEM.category = "Materials"
ITEM.description = "Снайперская винтовка с разбитым прицелом и треснутым стволом."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

