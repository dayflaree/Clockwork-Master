local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "M40A1"
BLUEPRINT.uniqueID = "blueprint_m40a1"
BLUEPRINT.model = "models/items/m40a1.mdl"
BLUEPRINT.category = "Чертежи оружия"
BLUEPRINT.description = "Починить снайперскую винтовку, заменив некоторые детали."
BLUEPRINT.craftplace = "cw_craft_wep"
BLUEPRINT.reqatt = {
	{"rem", 50}
}
BLUEPRINT.updatt = {
	{"rem", 30}
}
BLUEPRINT.required = {
	{"screw_driver", 1},
}
BLUEPRINT.recipe = {
	{"broken_m40a1", 1},
	{"reclaimed_metal", 1},
	{"box_of_screws", 1},
	{"plastic", 1},
	{"empty_glass_bottle", 1}
}
BLUEPRINT.finish = {
	{"sxbase_m40a1", 1}
}
BLUEPRINT:Register();