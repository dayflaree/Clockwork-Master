

ITEM.name = "Broken LAR"
ITEM.PrintName = "Поломанный LAR Grizzly Big Boar"
ITEM.model = "models/rtb_weapons/w_sniper.mdl"
ITEM.weight = 3
ITEM.category = "Materials"
ITEM.description = "Снайперская винтовка с разбитым прицелом и треснутым стволом."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

