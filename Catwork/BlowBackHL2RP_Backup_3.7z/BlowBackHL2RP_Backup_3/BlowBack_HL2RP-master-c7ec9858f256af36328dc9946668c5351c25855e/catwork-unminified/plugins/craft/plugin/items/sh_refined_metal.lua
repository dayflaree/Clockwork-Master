

ITEM.name = "Refined Metal"
ITEM.PrintName = "Очищенный металл"
ITEM.model = "models/gibs/metal_gib2.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.description = "Лист чистого металла."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

