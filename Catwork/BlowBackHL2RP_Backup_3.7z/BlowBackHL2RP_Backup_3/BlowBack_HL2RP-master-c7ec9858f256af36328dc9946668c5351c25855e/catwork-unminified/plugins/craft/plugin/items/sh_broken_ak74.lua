

ITEM.name = "Broken AK-74"
ITEM.PrintName = "Поломанный АК-74"
ITEM.model = "models/weapons/w_ak74.mdl"
ITEM.weight = 3
ITEM.category = "Materials"
ITEM.description = "Каким-то образом 'Калаш' умудрились сломать."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

