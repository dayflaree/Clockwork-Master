--[[
	(C) 2017 Mr. Meow
	Ugh, I guess insert some really restrictive license here
	that doesn't let you do anything with the code?
--]]

local cax_serial = '2668ceb78eebbd1ecb8222c4af722d34'
local cax_session_token = '991f365d595daac5262b7c4afba47fd1'
local lastSend = nil
local nextSend = nil
local sent = false
local lastSent = false

function cw.core:URLEncode(url)
	local output = "";

	if (type(url) != "string") then return ""; end;

	for i = 1, url:len() do
		local c = string.sub(url, i, i);
		local a = string.byte(c);

		if (a != nil) then
			if (a < 128) then
				if (a == 32 or a >= 34 and a <= 38 or a == 43 or a == 44 or a == 47 or a >= 58
				and a <= 64 or a >= 91 and a <= 94 or a == 96 or a >= 123 and a <= 126) then
					output = output.."%"..string.format("%x", a);
				else
					output = output..c;
				end;
			end;
		end;
	end;

	return output;
end;

function CAX_SEND_INFO()
	if (cax_serial) then
		local baseURL = "http://authx.cloudsixteen.com/auth_hostname.php?"
		local hostname = cw.core:URLEncode(GetConVarString("hostname"))
		local serial = cw.core:URLEncode(cax_serial)
	
		http.Fetch(baseURL.."hostname="..hostname.."&serial="..serial, function(body)
			if (sent) then
				print("[Catwork] Sent info to C16 servers.")

				sent = false
			end

			if (lastSent) then
				print("[Catwork] Finished spamming kuro's servers.")
			end
		end, function(error)
			--print("[Catwork] Unable to send info to C16 servers.")
			--MsgN(error)
		end)
	end
end

hook.Add("Tick", "Cat.Cax.SendInfo", function()
	local curTime = CurTime()

	if (!lastSend or !nextSend) then
		lastSend = curTime + 20
		nextSend = curTime

		if (!sent) then
			sent = true
		end
	end

	if (nextSend < curTime) then
		CAX_SEND_INFO()

		nextSend = curTime + 0.1
	end

	if (lastSend < curTime) then
		hook.Remove("Tick", "Cat.Cax.SendInfo")

		lastSent = true

		CAX_SEND_INFO()
	end
end)