--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("StaticWhitelistRemove")
COMMAND.tip = "Remove a class of entity from the static whitelist."
COMMAND.text = "<string Class>"
COMMAND.access = "a"
COMMAND.arguments = 1
COMMAND.alias = {"SWRemove"}

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)	
	if (table.HasValue(cwStaticEnts.whitelist, arguments[1])) then
		table.RemoveByValue(cwStaticEnts.whitelist, arguments[1])
		cw.core:SaveSchemaData("maps/"..game.GetMap().."/static_entities/whitelist", cwStaticEnts.whitelist)

		cw.player:Notify(player, "You have removed "..arguments[1].." from the list of entities that can be staticed.")
	else
		cw.player:Notify(player, arguments[1].." isn't in the static whitelist!")
	end	
end

COMMAND:Register();