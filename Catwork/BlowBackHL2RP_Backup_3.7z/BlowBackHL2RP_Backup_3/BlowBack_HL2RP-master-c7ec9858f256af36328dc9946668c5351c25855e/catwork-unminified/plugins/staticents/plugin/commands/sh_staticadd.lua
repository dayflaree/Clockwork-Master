--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("StaticAdd")
COMMAND.tip = "Add a static entity at your target position."
COMMAND.access = "o"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity

	if (IsValid(target)) then
		local class = hook.Run("CanEntityStatic", target)

		if (class != false) then
			for k, v in pairs(cwStaticEnts.staticEnts) do
				if (target == v) then
					cw.player:Notify(player, "This entity is already static!")

					return
				end
			end

			cwStaticEnts:SaveEntity(target)

			cw.player:Notify(player, "You have added a static entity.");		
		else
			cw.player:Notify(player, "You cannot static this entity!")
		end
	else
		cw.player:Notify(player, "You must look at a valid entity!")
	end
end

COMMAND:Register();