--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("StaticRemove")
COMMAND.tip = "Remove static entities at your target position."
COMMAND.access = "a"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity

	if (IsValid(target)) then
		for k, v in pairs(cwStaticEnts.staticEnts) do
			if (target == v) then
				table.remove(cwStaticEnts.staticEnts, k)
				cwStaticEnts:SaveStaticEnts()

				cw.player:Notify(player, "You have removed a static entity.")

				return
			end
		end

		cw.player:Notify(player, "This entity is not static.")
	else
		cw.player:Notify(player, "You must look at a valid entity!")
	end
end

COMMAND:Register();