--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- A function to check if an entity can be static.
function cwStaticEnts:CanEntityStatic(entity)
	if (entity:IsValid()) then
		local class = entity:GetClass()
		local whitelist = {
			"prop_physics",
			"gmod_",
			"prop_ragdoll",
			"edit_"
		}
		local blacklist = {
			"gmod_tool"
		}

		hook.Run("EditStaticWhitelist", whitelist)
		hook.Run("EditStaticBlacklist", blacklist)

		for k, v in ipairs(blacklist) do
			if (string.find(class, v)) then
				return false
			end
		end

		for k, v in ipairs(whitelist) do
			if (string.find(class, v)) then
				return class
			end
		end

		return false
	end
end

-- Called before the whitelist is checked when an entity is staticed.
function cwStaticEnts:EditStaticWhitelist(whitelist)
	table.Merge(whitelist, cw.core:RestoreSchemaData("maps/"..game.GetMap().."/static_entities/whitelist"))
end

-- A function to save an entity.
function cwStaticEnts:SaveEntity(entity)
	if (IsValid(entity) and hook.Run("CanEntityStatic", entity)) then
		table.insert(self.staticEnts, entity)
	end

	self:SaveStaticEnts()
end

-- A function to return the static mode boolean variable.
function cwStaticEnts:GetStaticMode()
	return self.staticMode[1]
end

-- A function to load the static entities.
function cwStaticEnts:LoadStaticEnts()
	self.whitelist = cw.core:RestoreSchemaData("maps/"..game.GetMap().."/static_entities/whitelist") or {}
	self.staticMode = cw.core:RestoreSchemaData("maps/"..game.GetMap().."/static_entities/static_mode") or {false}
	local classTable = cw.core:RestoreSchemaData("maps/"..game.GetMap().."/static_entities/classtable")
	local staticEnts = {}
	self.staticEnts = {}

	if (#classTable == 0) then
		table.insert(classTable, "prop_physics_multiplayer")
	end

	if (classTable and type(classTable) == "table") then
		for k, v in pairs(classTable) do
			local loadTable = cw.core:RestoreSchemaData("maps/"..game.GetMap().."/static_entities/"..v)

			if (loadTable and #loadTable > 0) then
				for k2, v2 in ipairs(loadTable) do
					table.insert(staticEnts, v2)
				end

				if (v == "prop_physics") then
					cw.core:SaveSchemaData("maps/"..game.GetMap().."/static_entities/backup/"..v, loadTable)
					cw.core:DeleteSchemaData("maps/"..game.GetMap().."/static_entities/"..v)
				end
			end
		end
	end

	staticEnts = hook.Run("StaticEntCleanup", staticEnts)

	for k, v in pairs(staticEnts) do
		if (v.class == "prop_physics") then
			v.class = "prop_physics_multiplayer"
		end

		local entity = ents.Create(v.class)

		entity:SetMaterial(v.material)
		entity:SetAngles(v.angles)
		entity:SetModel(v.model)
		entity:SetPos(v.position)

		if (!v.renderMode) then
			v.renderMode = 0
			v.renderFX = 0
		end

		if (v.color.a < 255 and v.renderMode == 0) then
			v.renderMode = 1
		end

		entity:SetColor(v.color)
		entity:SetRenderMode(v.renderMode)
		entity:SetRenderFX(v.renderFX)

		entity:Spawn()

		hook.Run("OnStaticEntityLoaded", entity, v)

		table.insert(self.staticEnts, entity)
	end

	hook.Run("PostStaticEntsLoaded")
end

function cwStaticEnts:StaticEntCleanup(entsTable)
	local newTable = {}

	print("Cleaning up static entities...")

	for i, v in ipairs(entsTable) do
		if (#newTable == 0) then
			table.insert(newTable, v)
			continue
		end

		local shouldAdd = true

		for i2, v2 in ipairs(newTable) do
			if (v2.position == v.position and v2.class == v.class) then
				shouldAdd = false
			end
		end

		if (shouldAdd) then
			table.insert(newTable, v)
		else
			print("FOUND DUPE: "..v.class)
		end
	end

	return newTable
end

-- A function to save the static entities.
function cwStaticEnts:SaveStaticEnts()
	local staticEnts = {}

	if (type(self.staticEnts) == "table") then
		for k, v in pairs(self.staticEnts) do
			if (IsValid(v)) then
				local entTable = {}
				local physicsObject = v:GetPhysicsObject()
				local class = v:GetClass()

				if (class == "prop_physics") then
					class = "prop_physics_multiplayer"
				end

				staticEnts[class] = staticEnts[class] or {}

				entTable.class = class;			
				entTable.color = v:GetColor()
				entTable.model = v:GetModel()
				entTable.angles = v:GetAngles()
				entTable.position = v:GetPos()
				entTable.material = v:GetMaterial()
				entTable.renderMode = v:GetRenderMode()
				entTable.renderFX = v:GetRenderFX()

				if (IsValid(physicsObject)) then
					entTable.moveable = physicsObject:IsMoveable()
				end

				hook.Run("OnStaticEntitySaved", v, entTable)

				table.insert(staticEnts[class], entTable)
			end
		end

		local classTable = {}

		for k, v in pairs(staticEnts) do
			cw.core:SaveSchemaData("maps/"..game.GetMap().."/static_entities/"..k, v)

			if (!classTable[k]) then
				table.insert(classTable, k)
			end
		end

		cw.core:SaveSchemaData("maps/"..game.GetMap().."/static_entities/classtable", classTable)
	end
end

function cwStaticEnts:OnStaticEntitySaved(entity, entTable)
	if (entity:GetClass() == "gmod_lamp") then
		entTable.texture = entity:GetFlashlightTexture()
		entTable.fov = entity:GetLightFOV()
		entTable.distance = entity:GetDistance()
		entTable.brightness = entity:GetBrightness();	
	elseif (entity:GetClass() == "gmod_light") then
		entTable.brightness = entity:GetBrightness()
		entTable.size = entity:GetLightSize()
	elseif (entity:GetClass() == "prop_ragdoll") then
		local boneTable = {}

		for i = 0, entity:GetPhysicsObjectCount() - 1 do
			local bone = entity:GetPhysicsObjectNum(i)
			table.insert(boneTable, {
				ang = bone:GetAngles(),
				pos = bone:GetPos(),
				wake = bone:IsAsleep(),
				moveable = bone:IsMoveable()
			})
		end

		entTable.bones = boneTable
	end
end

function cwStaticEnts:OnStaticEntityLoaded(entity, entTable)
	if (entTable.bones) then
		for k, v in ipairs(entTable.bones) do
			local bone = entity:GetPhysicsObjectNum(k - 1)

			bone:EnableMotion(v.moveable)
			bone:Wake();					
			bone:SetAngles(v.ang)
			bone:SetPos(v.pos)

			if (v.wake == true) then
				bone:Sleep()
			end
		end
	elseif (IsValid(entity:GetPhysicsObject())) then
		entity:GetPhysicsObject():EnableMotion(entTable.moveable)
	end

	if (entTable.texture) then
		entity:SetFlashlightTexture(entTable.texture)
		entity:SetLightFOV(entTable.fov)
		entity:SetDistance(entTable.distance)
		entity:SetBrightness(entTable.brightness)
		entity:SetToggle(false)
		entity:Switch(true)
	end

	if (entTable.size) then
		entity:SetBrightness(entTable.brightness)
		entity:SetLightSize(entTable.size)
		entity:SetOn(true)
	end
end