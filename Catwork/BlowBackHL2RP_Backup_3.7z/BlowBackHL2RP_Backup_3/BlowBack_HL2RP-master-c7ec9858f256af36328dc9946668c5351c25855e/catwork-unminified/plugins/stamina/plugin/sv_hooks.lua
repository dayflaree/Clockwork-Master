--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when a player's character data should be saved.
function cwStamina:PlayerSaveCharacterData(player, data)
	if (data["stamina"]) then
		data["stamina"] = math.Round(data["stamina"])
	end
end

-- Called when a player's character data should be restored.
function cwStamina:PlayerRestoreCharacterData(player, data)
	if (!data["Stamina"]) then
		data["Stamina"] = 100
	end
end

-- Called just after a player spawns.
function cwStamina:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("Stamina", 100)
	end
end

-- Called when a player attempts to throw a punch.
function cwStamina:PlayerCanThrowPunch(player)
	if (player:GetCharacterData("Stamina") <= 10) then
		return false
	end
end

-- Called when a player throws a punch.
function cwStamina:PlayerPunchThrown(player)
	local attribute = cw.attributes:Fraction(player, ATB_ENDURANCE, 1.5, 0.25)
	local decrease = 5 / (1 + attribute)

	player:SetCharacterData("Stamina", math.Clamp(player:GetCharacterData("Stamina") - decrease, 0, 100))
	player:ProgressAttribute(ATB_MELEE, 1, true)
end

-- Called when a player's shared variables should be set.
function cwStamina:OnePlayerSecond(player, curTime)
	player:SetNetVar("Stamina", math.floor(player:GetCharacterData("Stamina")))
end

-- Called when a player's stamina should regenerate.
function cwStamina:PlayerShouldStaminaRegenerate(player)
	return true
end

-- Called when a player's stamina should drain.
function cwStamina:PlayerShouldStaminaDrain(player)
	return true
end

-- Called at an interval while a player is connected.
function cwStamina:PlayerThink(player, curTime, infoTable)
	local regenScale = config.Get("stam_regen_scale"):Get()
	local drainScale = config.Get("stam_drain_scale"):Get()
	local attribute = cw.attributes:Fraction(player, ATB_ENDURANCE, 1, 0.25)
	local regeneration = 0
	local maxHealth = player:GetMaxHealth()
	local healthScale = (drainScale * (math.Clamp(player:Health(), maxHealth * 0.1, maxHealth) / maxHealth))
	local decrease = (drainScale + (drainScale - healthScale)) - ((drainScale * 0.5) * attribute)
	local isJumping = infoTable.isJumping

	if (!player:IsNoClipping()) then
		local playerVelocityLength = player:GetVelocity():Length()

		if (isJumping) then
			player:SetCharacterData(
				"Stamina", math.Clamp(player:GetCharacterData("Stamina") - decrease, 0, 100)
			)

			player:ProgressAttribute(ATB_ENDURANCE, 0.02, true)
		end

		if ((infoTable.isRunning and !isJumping and player:IsOnGround()) and playerVelocityLength != 0) then
			if (hook.Run("PlayerShouldStaminaDrain", player)) then
				local newStamina = math.Clamp(player:GetCharacterData("Stamina") - decrease, 0, 100)

				player:SetCharacterData("Stamina", newStamina)

				if (newStamina > 1) then
					player:ProgressAttribute(ATB_ENDURANCE, 0.025, true)
				end
			end
		elseif (playerVelocityLength == 0) then
			if (player:Crouching()) then
				regeneration = (regenScale + attribute) * 2
			else
				regeneration = (regenScale + attribute)
			end
		else
			regeneration = regenScale / 3
		end
	end

	if (regeneration > 0 and hook.Run("PlayerShouldStaminaRegenerate", player)) then
		player:SetCharacterData(
			"Stamina", math.Clamp(
				player:GetCharacterData("Stamina") + regeneration, 0, 100 - player:GetCharacterData("Fatigue", 0)
			)
		)
	end

	local newRunSpeed = infoTable.runSpeed * 2
	local diffRunSpeed = newRunSpeed - infoTable.walkSpeed
	local maxRunSpeed = config.GetVal("run_speed")

	infoTable.runSpeed = math.Clamp(newRunSpeed - (diffRunSpeed - ((diffRunSpeed / 100) * player:GetCharacterData("Stamina"))), infoTable.walkSpeed, maxRunSpeed)

	local stamina = player:GetCharacterData("Stamina")
	local bShouldPlayBreathingSound = false

	if (stamina < 25 and cw.event:CanRun("sounds", "breathing")) then
		bShouldPlayBreathingSound = true
	end

	if (!player.nextBreathingSound or curTime >= player.nextBreathingSound) then
		if (!cw.player:IsNoClipping(player)) then
			player.nextBreathingSound = curTime + 1

			if (bShouldPlayBreathingSound) then
				local volume = config.GetVal("breathing_volume") - stamina

				cw.player:StartSound(player, "LowStamina", "player/breathe1.wav", volume / 100)
			else
				cw.player:StopSound(player, "LowStamina", 4)
			end
		end
	end
end
