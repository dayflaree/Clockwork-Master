--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	You don't have to do this, but I think it's nicer.
	Alternatively, you can simply use the PLUGIN variable.
--]]
PLUGIN:SetGlobalAlias("cwStorage")

--[[ You don't have to do this either, but I prefer to seperate the functions. --]]
util.Include("cl_plugin.lua")
util.Include("sv_plugin.lua")
util.Include("sv_hooks.lua")
util.Include("cl_hooks.lua")

cwStorage.containerList = {
	["models/props_wasteland/controlroom_storagecloset001a.mdl"] = {8, "Шкаф"},
	["models/props_wasteland/controlroom_storagecloset001b.mdl"] = {15, "Шкаф"},
	["models/props_wasteland/controlroom_filecabinet001a.mdl"] = {4, "Картотечный шкаф"},
	["models/props_wasteland/controlroom_filecabinet002a.mdl"] = {8, "Картотечный шкаф"},
	["models/props_c17/suitcase_passenger_physics.mdl"] = {5, "Кейс"},
	["models/props_junk/wood_crate001a_damagedmax.mdl"] = {8, "Деревянный ящик"},
	["models/props_junk/wood_crate001a_damaged.mdl"] = {8, "Деревянный ящик"},
	["models/props_interiors/furniture_desk01a.mdl"] = {4, "Письменный стол"},
	["models/props_c17/furnituredresser001a.mdl"] = {10, "Шкаф"},
	["models/props_c17/furnituredrawer001a.mdl"] = {8, "Шкаф"},
	["models/props_c17/furnituredrawer002a.mdl"] = {4, "Шкаф"},
	["models/props_c17/furniturefridge001a.mdl"] = {8, "Холодильник"},
	["models/props_c17/furnituredrawer003a.mdl"] = {8, "Шкаф"},
	["models/weapons/w_suitcase_passenger.mdl"] = {5, "Кейс"},
	["models/props_junk/trashdumpster01a.mdl"] = {15, "Мусорный ящик"},
	["models/props_junk/wood_crate001a.mdl"] = {8, "Деревянный ящик"},
	["models/props_junk/wood_crate002a.mdl"] = {10, "Деревянный ящик"},
	["models/items/ammocrate_rockets.mdl"] = {15, "Большой ящик"},
	["models/props_lab/filecabinet02.mdl"] = {8, "Картотечный шкаф"},
	["models/items/ammocrate_grenade.mdl"] = {15, "Большой ящик"},
	["models/props_junk/trashbin01a.mdl"] = {10, "Мусорка"},
	["models/props_c17/suitcase001a.mdl"] = {8, "Кейс"},
	["models/items/item_item_crate.mdl"] = {4, "Ящик"},
	["models/props_c17/oildrum001.mdl"] = {8, "Бочка"},
	["models/items/ammocrate_smg1.mdl"] = {15, "Большой ящик"},
	["models/items/ammocrate_ar2.mdl"] = {15, "Большой ящик"},
	["models/props_junk/cardboard_box001a.mdl"] = {4, "Коробка"},
	["models/props_junk/cardboard_box002a.mdl"] = {4, "Коробка"},
	["models/props_junk/cardboard_box003a.mdl"] = {3, "Коробка"},
	["models/props_wasteland/kitchen_fridge001a.mdl"] = {25, "Промышленный холодильник"},
	["models/props_lab/partsbin01.mdl"] = {4, "Почтовый ящик"},
	["models/props_office/file_cabinet_large_static.mdl"] = {25, "Большой картотечный шкаф"},
	["models/props/CS_militia/footlocker01_closed.mdl"] = {15, "Сундук"},
};