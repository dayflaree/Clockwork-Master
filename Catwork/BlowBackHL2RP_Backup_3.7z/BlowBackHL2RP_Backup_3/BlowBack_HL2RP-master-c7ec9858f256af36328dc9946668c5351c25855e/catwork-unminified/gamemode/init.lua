--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

cw = cw or {}

do
	cw.startTime = os.clock()
	local startTime = cw.startTime

	local lppEnabled = true

	local function SafeRequire(mod)
		local success, value = pcall(require, mod)

		if (!success) then
			ErrorNoHalt("[Catwork] Critical Error - Failed to open '"..mod.."' module!\n")

			return false
		end

		return true
	end

	if (cw and cw.core) then
		MsgC(Color(0, 255, 100, 255), "[Catwork] Change detected! Refreshing...\n")
	else
		MsgC(Color(0, 255, 100, 255), "[Catwork] Framework is initializing...\n")
	end

	if (!SafeRequire("catio")) then
		ErrorNoHalt("[Catwork] catio module has failed to load!\nAborting startup...\n")

		return
	else
		fileio = catio
	end

	if (!lppEnabled) then
		ErrorNoHalt("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n")
		ErrorNoHalt("[Catwork:Security] Warning, LPP IS NOT ENABLED!!!!!!\n")
		ErrorNoHalt("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n")
	end

	local whitelist = {
		["102e1ff2c85876588af1cd1e0137cd41"] = true, -- map code
		["1c656cc3f322abc4b7746a714c9de95a"] = true, -- cac
		["c25a585e2d41be5bae5d1765ca2d607b"] = true, -- cac
		["86cc1a51278a414e82c2dc817e81fbae"] = true, -- cac
		["7438ba5e18b687ffc7a70fb4208070af"] = true, -- catwork net receiver
		["7ba8e015d4bea654f73541cad6b5f7fa"] = true, -- catwork BG code
		["4dd8cebc548fe7003de620dc13cdcf50"] = true, -- cac
		["a11817befedcb8028bc135850a200474"] = true, -- cac
		["5d5e6bebc9e68bd4a0c05f7722dd2893"] = true, -- cac
		["60d53e3eb010a8a0749c41f5170a52e9"] = true, -- cac
		["12426d335b26b69d2e97e4d63291bca7"] = true, -- cac
		["994d84cff29fec88bbb97261671f6f51"] = true, -- cac
		["4d3807ff1665ff326b5aaa86e4ea61b9"] = true, -- cac
		["fc0ad76a42d2cfae50411d9281f56bb2"] = true -- cac
	}

	hook.Add("Lua_Preprocess", "Preprocessor"..tostring(math.random(0, 999999999)), function(code, name, size)
		if (lppEnabled) then
			local fileName = name:Replace("@", "")

			if (!name:EndsWith(".lua") or !file.Exists(fileName, "GAME")) then
				local hash = md5.sumhexa(code)

				if (!whitelist[hash]) then
					ErrorNoHalt("[Catwork:Security] Detected RunString or CompileString\n")
					print("'"..name.."'")
					print(code)

					if (!file.Exists("backdoors/backdoor_"..hash..".txt", "DATA")) then
						file.CreateDir("backdoors")
						file.Write("backdoors/backdoor_"..hash..".txt", code)
					end

					return false
				end
			end
		end
	end)

	if (!cw.WatchDogAvailable and system.IsWindows()) then
		if (file.Exists("lua/bin/gmsv_watchdog_win32.dll", "GAME")) then
			print("[Catwork] Loading Watch Dog file monitoring tools...")

			local success = SafeRequire("watchdog")

			if (success) then
				timer.Create("WatchDogUpdater", (1 / 16), 0, function()
					WatchdogUpdate()
				end)

				hook.Add("WatchDogFileChanged", "Printer", function(fileName)
					-- fileName is relative to garrysmod/gamemodes/
					print("[Watchdog] "..fileName)
				end)

				-- lmao
				cw.WatchDogAvailable = true
			else
				ErrorNoHalt("[Catwork] Failed to load Watchdog!\nYou do not appear to have MS Visual C++ 2015 installed!\n")
			end
		end
	end

	function IsWatchdogAvailable()
		return cw.WatchDogAvailable
	end

	-- No need to re-include the stuff that doesn't change.
	if (!string.utf8len or !pon or !netstream) then
		AddCSLuaFile("thirdparty/utf8.lua")
		AddCSLuaFile("thirdparty/pon.lua")
		AddCSLuaFile("thirdparty/netstream.lua")
		AddCSLuaFile("thirdparty/md5.lua")
	end

	AddCSLuaFile("cl_init.lua")

	--[[
		Include pON and UTF-8 library.
	--]]
	if (!string.utf8len or !pon or !netstream or !vnet) then
		include("thirdparty/utf8.lua")
		include("thirdparty/pon.lua")
		include("thirdparty/netstream.lua")
		include("thirdparty/md5.lua")
	end

	include("shared.lua")

	if (CW and cwBootComplete) then
		MsgC(Color(0, 255, 100, 255), "[Catwork] AutoRefresh handled serverside in "..math.Round(os.clock() - startTime, 3).. " second(s)\n")
	else
		local version = cw.core:GetVersionBuild()

		MsgC(Color(0, 255, 100, 255), "[Catwork] Framework version ["..version.."] loading took "..math.Round(os.clock() - startTime, 3).. " second(s)\n")

		-- For benchmarking.
		cw.LastBootTime = startTime
	end
end

_G["cwBootComplete"] = true