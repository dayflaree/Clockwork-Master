--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.inventory = CW.kernel:NewLibrary("Inventory");

-- A function to add an instance to a table.
function CW.inventory:AddInstance(inventory, itemTable, quantity)
	quantity = quantity or 1;

	if (itemTable == nil) then
		return false;
	end;

	if (!itemTable:IsInstance()) then
		debug.Trace();
		return false;
	end;
	
	if (!inventory[itemTable("uniqueID")]) then
		inventory[itemTable("uniqueID")] = {};
	end;
	
	inventory[itemTable("uniqueID")][itemTable("itemID")] = itemTable;
	
	if (quantity != 1) then
		self:AddInstance(inventory, CW.item:CreateInstance(itemTable("uniqueID")), quantity - 1);
	end;
	
	return itemTable;
end;

-- A function to calculate the space of an inventory.
function CW.inventory:CalculateSpace(inventory)
	local space = 0;
	
	for k, v in pairs(self:GetAsItemsList(inventory)) do
		local spaceUsed = v("space");
		if (spaceUsed) then space = space + spaceUsed; end;
	end;
	
	return space;
end;

-- A function to calculate the weight of an inventory.
function CW.inventory:CalculateWeight(inventory)
	local weight = 0;
	
	for k, v in pairs(self:GetAsItemsList(inventory)) do
		if (v("weight")) then
			weight = weight + v("weight");
		end;
	end;
	
	return weight;
end;

-- A function to create a duplicate of an inventory.
function CW.inventory:CreateDuplicate(inventory)
	local duplicate = {};
		for k, v in pairs(inventory) do
			duplicate[k] = {};
			for k2, v2 in pairs(v) do
				duplicate[k][k2] = v2;
			end;
		end;
	return duplicate;
end;

-- A function to find an item within an inventory by ID.
function CW.inventory:FindItemByID(inventory, uniqueID, itemID)
	local itemTable = CW.item:FindByID(uniqueID);
	
	if (!inventory) then
		debug.Trace();
		return;
	end;
	
	if (itemID) then
		itemID = tonumber(itemID);
	end;
	
	if (!itemTable or !inventory[itemTable("uniqueID")]) then
		return;
	end;
	
	local itemsList = inventory[itemTable("uniqueID")];
	
	if (itemID) then
		if (itemsList) then
			return itemsList[itemID];
		end;
	else
		local firstValue = table.GetFirstValue(itemsList);
		if (firstValue) then
			return itemsList[firstValue.itemID];
		end;
	end;
end;

-- A function to find an item within an inventory by name.
function CW.inventory:FindItemByName(inventory, uniqueID, name)
	local itemTable = CW.item:FindByID(uniqueID);
	
	if (!itemTable or !inventory[itemTable("uniqueID")]) then
		return;
	end;
	
	for k, v in pairs(inventory[itemTable("uniqueID")]) do
		if (string.lower(v("name")) == string.lower(name)) then
			return v;
		end;
	end;
end;

-- A function to get an inventory's items by unique ID.
function CW.inventory:GetItemsByID(inventory, uniqueID)
	local itemTable = CW.item:FindByID(uniqueID);
	
	if (itemTable) then
		return inventory[itemTable("uniqueID")];
	else
		return {};
	end;
end;

-- A function to find an item within an inventory by name.
function CW.inventory:FindItemsByName(inventory, uniqueID, name)
	local itemTable = CW.item:FindByID(uniqueID);
	local itemsList = {};
	
	if (!itemTable or !inventory[itemTable("uniqueID")]) then
		return;
	end;
	
	for k, v in pairs(inventory[itemTable("uniqueID")]) do
		if (string.lower(v("name")) == string.lower(name)) then
			itemsList[#itemsList + 1] = v;
		end;
	end;
	
	return itemsList;
end;

-- A function to get an inventory as an items list.
function CW.inventory:GetAsItemsList(inventory)
	local itemsList = {};
		for k, v in pairs(inventory) do
			table.Add(itemsList, v);
		end;
	return itemsList;
end;

--[[
	@codebase Shared
	@details A function to get the amount of items an entity has in its inventory by ID.
	@param Table Inventory of the entity.
	@param Int ID of item looked up in the inventory to get the amount.
	@returns Int Number of items in the inventory that match the ID.
--]]
function CW.inventory:GetItemCountByID(inventory, uniqueID)
	local itemTable = CW.item:FindByID(uniqueID);
	
	return table.Count(inventory[itemTable("uniqueID")]);
end;

-- A function to get whether an inventory has an item by ID.
function CW.inventory:HasItemByID(inventory, uniqueID)
	local itemTable = CW.item:FindByID(uniqueID);
	return (inventory[itemTable("uniqueID")]
	and table.Count(inventory[itemTable("uniqueID")]) > 0);
end;

--[[
	@codebase Shared
	@details A function to get whether a player has a specific amount of items in their inventory by ID.
	@param Table Inventory of the entity.
	@param Int ID of the item being checked for its amount in the inventory.
	@param Int Amount of items the entity needs to have in order to return true.
	@returns Bool Whether the entity has a specific amount of items in its inventory or not.
--]]
function CW.inventory:HasItemCountByID(inventory, uniqueID, amount)
	local amountInInventory = self:GetItemCountByID(inventory, uniqueID);
	
	if (amountInInventory >= amount) then
		return true;
	else
		return false;
	end;
end;

-- A function to get whether an inventory item instance.
function CW.inventory:HasItemInstance(inventory, itemTable)
	local uniqueID = itemTable("uniqueID");
	return (inventory[uniqueID] and inventory[uniqueID][itemTable("itemID")] != nil);
end;

-- A function to get whether an inventory is empty.
function CW.inventory:IsEmpty(inventory)
	if (!inventory) then return true; end;
	local bEmpty = true;
	
	for k, v in pairs(inventory) do
		if (table.Count(v) > 0) then
			return false;
		end;
	end;
	
	return true;
end;

-- A function to remove an instance from a table.
function CW.inventory:RemoveInstance(inventory, itemTable)
	if (!itemTable:IsInstance()) then
		debug.Trace();
		return false;
	end;
	
	if (inventory[itemTable("uniqueID")]) then
		inventory[itemTable("uniqueID")][itemTable("itemID")] = nil;
		return CW.item:FindInstance(itemTable("itemID"));
	end;
end;

-- A function to remove a uniquen ID from a table.
function CW.inventory:RemoveUniqueID(inventory, uniqueID, itemID)
	local itemTable = CW.item:FindByID(uniqueID);
	if (itemID) then itemID = tonumber(itemID); end;
	
	if (itemTable and inventory[itemTable("uniqueID")]) then
		if (!itemID) then
			local firstValue = table.GetFirstValue(inventory[itemTable("uniqueID")]);
			
			if (firstValue) then
				inventory[itemTable("uniqueID")][firstValue.itemID] = nil;
				return CW.item:FindInstance(firstValue.itemID);
			end;
		else
			inventory[itemTable("uniqueID")][itemID] = nil;
		end;
	end;
end;

-- A function to make an inventory loadable.
function CW.inventory:ToLoadable(inventory)
	local newTable = {};

	for k, v in pairs(inventory) do
		local itemTable = CW.item:FindByID(k);
		
		if (itemTable) then
			local uniqueID = itemTable("uniqueID");

			if (uniqueID != k) then
				continue;
			end;
			
			if (!newTable[uniqueID]) then
				newTable[uniqueID] = {};
			end;
			
			for k2, v2 in pairs(v) do
				local itemID = tonumber(k2);
				local instance = CW.item:CreateInstance(
					k, itemID, v2
				);
				
				if (instance and !instance.OnLoaded
				or instance:OnLoaded() != false) then
					newTable[uniqueID][itemID] = instance;
				end;
			end;
		end;
	end;
	
	return newTable;
end;

-- A function to make an inventory saveable.
function CW.inventory:ToSaveable(inventory)
	local newTable = {};
	
	for k, v in pairs(inventory) do
		local itemTable = CW.item:FindByID(k);
		
		if (itemTable) then
			local defaultData = itemTable("defaultData");
			local uniqueID = itemTable("uniqueID");
			
			if (!newTable[uniqueID]) then
				newTable[uniqueID] = {};
			end;
			
			for k2, v2 in pairs(v) do
				if (type(v2) == "table"
				and (v2.IsInstance and v2:IsInstance())) then
					local newData = {};
					local itemID = tostring(k2);
					
					for k3, v3 in pairs(v2("data")) do
						if (defaultData[k3] != v3) then
							newData[k3] = v3;
						end;
					end;
					
					if (!v2.OnSaved
					or v2:OnSaved(newData) != false) then
						newTable[uniqueID][itemID] = newData;
					end;
				end;
			end;
		end
	end;
	
	return newTable;
end;

-- A function to get whether we should use the space system.
function CW.inventory:UseSpaceSystem()
	return CW.config:Get("enable_space_system"):Get();
end;

if (CLIENT) then
	CW.inventory.client = CW.inventory.client or {};
	
	-- A function to get the local player's inventory.
	function CW.inventory:GetClient()
		return self.client;
	end;
	
	-- A function to get the inventory panel.
	function CW.inventory:GetPanel()
		return self.panel;
	end;
	
	-- A function to get whether the client has an item equipped.
	function CW.inventory:HasEquipped(itemTable)
		if (itemTable.HasPlayerEquipped) then
			return (itemTable:HasPlayerEquipped(CW.Client) == true);
		end;
		
		return false;
	end;
	
	-- A function to rebuild the local player's inventory.
	function CW.inventory:Rebuild(bForceRebuild)
		if (CW.menu:IsPanelActive(self:GetPanel()) or bForceRebuild) then
			CW.kernel:OnNextFrame("RebuildInv", function()
				if (IsValid(self:GetPanel())) then
					self:GetPanel():Rebuild();
				end;
			end);
		end;
	end;
	
	netstream.Hook("InvClear", function(data)
		CW.inventory.client = {};
		CW.inventory:Rebuild();
	end);

	netstream.Hook("InvGive", function(data)
		local itemTable = CW.item:CreateInstance(
			data.index, data.itemID, data.data
		);
		
		CW.inventory:AddInstance(
			CW.inventory.client, itemTable
		);
		
		CW.inventory:Rebuild();
		plugin.Call("PlayerItemGiven", itemTable);
	end);
	
	netstream.Hook("InvNetwork", function(data)
		local itemTable = CW.item:FindInstance(data.itemID);
		
		if (itemTable) then
			local bHasEquipped = CW.inventory:HasEquipped(itemTable);
			
			table.Merge(itemTable("data"), data.data);
			plugin.Call("ItemNetworkDataUpdated", itemTable, data.data);
			
			if (bHasEquipped != CW.inventory:HasEquipped(itemTable)) then
				CW.inventory:Rebuild(
					CW.menu:GetOpen()
				);
			end;
		end;
	end);
	
	netstream.Hook("InvRebuild", function(data)
		CW.inventory:Rebuild();
	end);
	
	netstream.Hook("InvTake", function(data)
		local itemTable = CW.inventory:FindItemByID(
			CW.inventory.client, data[1], data[2]
		);
		
		if (itemTable) then
			CW.inventory:RemoveInstance(
				CW.inventory.client, itemTable
			);
			
			CW.inventory:Rebuild();
			plugin.Call("PlayerItemTaken", itemTable);
		end;
	end);
	
	netstream.Hook("InvUpdate", function(data)
		for k, v in pairs(data) do
			local itemTable = CW.item:CreateInstance(
				v.index, v.itemID, v.data
			);
			
			CW.inventory:AddInstance(
				CW.inventory.client, itemTable
			);
		end;
		
		CW.inventory:Rebuild();
	end);
else
	function CW.inventory:SendUpdateByInstance(player, itemTable)
		if (itemTable) then
			netstream.Start(
				player, "InvUpdate", {CW.item:GetDefinition(itemTable, true)}
			);
		end;
	end;
	
	function CW.inventory:SendUpdateAll(player)
		local inventory = player:GetInventory();
 
		for k, v in pairs(inventory) do
			self:SendUpdateByID(player, k);
		end;
	end;
	
	function CW.inventory:SendUpdateByID(player, uniqueID)
		local itemTables = self:GetItemsByID(player:GetInventory(), uniqueID);
	 
		if (itemTables) then
			local definitions = {};
	 
			for k, v in pairs(itemTables) do
				definitions[#definitions + 1] = CW.item:GetDefinition(v, true);
			end;
	 
			netstream.Start(player, "InvUpdate", definitions);
		end;
	end;
	
	function CW.inventory:Rebuild(player)
		CW.kernel:OnNextFrame("RebuildInv"..player:UniqueID(), function()
			if (IsValid(player)) then
				netstream.Start(player, "InvRebuild");
			end;
		end);
	end;
end;