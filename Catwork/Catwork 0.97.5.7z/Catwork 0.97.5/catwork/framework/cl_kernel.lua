--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[ Initiate the shared booting process. --]]
include("sh_boot.lua");

cwClient = cwClient or nil;

--[[
	Derive from Sandbox, because we want the spawn menu and such!
	We also want the base Sandbox entities and weapons.
--]]
DeriveGamemode("sandbox");

do
	--[[
		This is a hack to display world tips correctly based on their owner.
	--]]

	local ClockworkAddWorldTip = AddWorldTip;

	function AddWorldTip(entIndex, text, dieTime, position, entity)
		local weapon = cwClient:GetActiveWeapon();
		
		if (IsValid(weapon) and string.lower(weapon:GetClass()) == "gmod_tool") then
			if (IsValid(entity) and entity.GetPlayerName) then
				if (cwClient:Name() == entity:GetPlayerName()) then
					ClockworkAddWorldTip(entIndex, text, dieTime, position, entity);
				end;
			end;
		end;
	end;
end;

timer.Destroy("HintSystem_OpeningMenu");
timer.Destroy("HintSystem_Annoy1");
timer.Destroy("HintSystem_Annoy2");

netstream.Hook("RunCommand", function(data)
	RunConsoleCommand(unpack(data));
end);

netstream.Hook("SharedTables", function(data)
	CW.SharedTables = data;
end);

netstream.Hook("SetSharedTableVar", function(data)
	CW.SharedTables[data.sharedTable] = CW.SharedTables[data.sharedTable] or {};
	CW.SharedTables[data.sharedTable][data.key] = data.value;
end);

netstream.Hook("HiddenCommands", function(data)
	for k, v in pairs(data) do
		for k2, v2 in pairs(CW.command:GetAll()) do
			if (CW.kernel:GetShortCRC(k2) == v) then
				CW.command:SetHidden(k2, true);
				
				break;
			end;
		end;
	end;
end);

netstream.Hook("OrderTime", function(data)
	CW.OrderCooldown = data;
	
	local activePanel = CW.menu:GetActivePanel();
	
	if (activePanel and activePanel:GetPanelName() == CW.option:GetKey("name_business")) then
		activePanel:Rebuild();
	end;
end);

netstream.Hook("CharacterInit", function(data)
	plugin.Call("PlayerCharacterInitialized", data);
end);

netstream.Hook("Log", function(data)
	local logType = data.logType;
	local text = data.text;
	
	CW.kernel:PrintColoredText(CW.kernel:GetLogTypeColor(logType), text);
end);

netstream.Hook("StartSound", function(data)
	if (IsValid(cwClient)) then
		local uniqueID = data.uniqueID;
		local sound = data.sound;
		local volume = data.volume;
		
		if (!cwClientSounds) then
			cwClientSounds = {};
		end;
		
		if (cwClientSounds[uniqueID]) then
			cwClientSounds[uniqueID]:Stop();
		end;
		
		cwClientSounds[uniqueID] = CreateSound(cwClient, sound);
		cwClientSounds[uniqueID]:PlayEx(volume, 100);
	end;
end);

netstream.Hook("StopSound", function(data)
	local uniqueID = data.uniqueID;
	local fadeOut = data.fadeOut;
	
	if (!cwClientSounds) then
		cwClientSounds = {};
	end;
	
	if (cwClientSounds[uniqueID]) then
		if (fadeOut != 0) then
			cwClientSounds[uniqueID]:FadeOut(fadeOut);
		else
			cwClientSounds[uniqueID]:Stop();
		end;
		
		cwClientSounds[uniqueID] = nil;
	end;
end);

netstream.Hook("InfoToggle", function(data)
	if (IsValid(cwClient) and cwClient:HasInitialized()) then
		if (!CW.InfoMenuOpen) then
			CW.InfoMenuOpen = true;
			CW.kernel:RegisterBackgroundBlur("InfoMenu", SysTime());
		else
			CW.kernel:RemoveBackgroundBlur("InfoMenu");
			CW.kernel:CloseActiveDermaMenus();
			CW.InfoMenuOpen = false;
		end;
	end;
end);

netstream.Hook("PlaySound", function(data)
	surface.PlaySound(data);
end);

netstream.Hook("DataStreaming", function(data)
	netstream.Start("DataStreamInfoSent", true);
end);

netstream.Hook("DataStreamed", function(data)
	CW.DataHasStreamed = true;
end);

netstream.Hook("QuizCompleted", function(data)
	if (!data) then
		if (!CW.quiz:GetCompleted()) then
			gui.EnableScreenClicker(true);
			
			CW.quiz.panel = vgui.Create("CW.quiz");
			CW.quiz.panel:Populate();
			CW.quiz.panel:MakePopup();
		end;
	else
		local characterPanel = CW.character:GetPanel();
		local quizPanel = CW.quiz:GetPanel();
		
		CW.quiz:SetCompleted(true);
		
		if (quizPanel) then
			quizPanel:Remove();
		end;
	end;
end);

netstream.Hook("RecogniseMenu", function(data)
	local menuPanel = CW.kernel:AddMenuFromData(nil, {
		["All characters within whispering range."] = function()
			netstream.Start("RecogniseOption", "whisper");
		end,
		["All characters within yelling range."] = function()
			netstream.Start("RecogniseOption", "yell");
		end,
		["All characters within talking range"] = function()
			netstream.Start("RecogniseOption", "talk");
		end,
		["The character you are looking at."] = function()
			netstream.Start("RecogniseOption", "look");
		end
	});
	
	if (IsValid(menuPanel)) then
		menuPanel:SetPos(
			(ScrW() / 2) - (menuPanel:GetWide() / 2), (ScrH() / 2) - (menuPanel:GetTall() / 2)
		);
	end;
	
	CW.kernel:SetRecogniseMenu(menuPanel);
end);

netstream.Hook("ClockworkIntro", function(data)
	if (!CW.ClockworkIntroFadeOut) then
		local introImage = CW.option:GetKey("intro_image");
		local introSound = CW.option:GetKey("intro_sound");
		local duration = 8;
		local curTime = UnPredictedCurTime();
		
		if (introImage != "") then
			duration = 16;
		end;
		
		CW.ClockworkIntroWhiteScreen = curTime + (FrameTime() * 8);
		CW.ClockworkIntroFadeOut = curTime + duration;
		CW.ClockworkIntroSound = CreateSound(cwClient, introSound);
		CW.ClockworkIntroSound:PlayEx(0.75, 100);
		
		timer.Simple(duration - 4, function()
			CW.ClockworkIntroSound:FadeOut(4);
			CW.ClockworkIntroSound = nil;
		end);
		
		surface.PlaySound("buttons/button1.wav");
	end;
end);

netstream.Hook("SharedVar", function(data)
	local key = data.key;
	local sharedVars = CW.kernel:GetSharedVars():Player();
	
	if (sharedVars and sharedVars[key]) then
		local sharedVarData = sharedVars[key];
		
		if (sharedVarData) then
			sharedVarData.value = data.value;
		end;
	end;
end);

netstream.Hook("HideCommand", function(data)
	local index = data.index;
	
	for k, v in pairs(CW.command:GetAll()) do
		if (CW.kernel:GetShortCRC(k) == index) then
			CW.command:SetHidden(k, data.hidden);
			
			break;
		end;
	end;
end);

netstream.Hook("CfgListVars", function(data)
	cwClient:PrintMessage(2, "######## [Catwork] Config ########\n");
		local sSearchData = data;
		local tConfigRes = {};
		
		if (sSearchData) then
			sSearchData = string.lower(sSearchData);
		end;
		
		for k, v in pairs(CW.config:GetStored()) do
			if (type(v.value) != "table" and (!sSearchData
			or string.find(string.lower(k), sSearchData)) and !v.isStatic) then
				if (v.isPrivate) then
					tConfigRes[#tConfigRes + 1] = {
						k, string.rep("*", string.utf8len(tostring(v.value)))
					};
				else
					tConfigRes[#tConfigRes + 1] = {
						k, tostring(v.value)
					};
				end;
			end;
		end;
		
		table.sort(tConfigRes, function(a, b)
			return a[1] < b[1];
		end);
		
		for k, v in pairs(tConfigRes) do
			local systemValues = CW.config:GetFromSystem(v[1]);
			
			if (systemValues) then
				cwClient:PrintMessage(2, "// "..systemValues.help.."\n");
			end;
			
			cwClient:PrintMessage(2, v[1].." = \""..v[2].."\";\n");
		end;
	cwClient:PrintMessage(2, "######## [Catwork] Config ########\n");
end);

netstream.Hook("ClearRecognisedNames", function(data)
	CW.RecognisedNames = {};
end);

netstream.Hook("RecognisedName", function(data)
	local key = data.key;
	local status = data.status;
	
	if (status > 0) then
		CW.RecognisedNames[key] = status;
	else
		CW.RecognisedNames[key] = nil;
	end;
end);

netstream.Hook("Hint", function(data)
	if (data and type(data) == "table") then
		if (data.center) then
			CW.kernel:AddCenterHint(
				CW.kernel:ParseData(data.text), data.delay, data.color, data.noSound, data.showDuplicates
			);
		else
			CW.kernel:AddTopHint(
				CW.kernel:ParseData(data.text), data.delay, data.color, data.noSound, data.showDuplicates
			);
		end;
	end;
end);

netstream.Hook("WeaponItemData", function(data)
	local weapon = Entity(data.weapon);

	if (IsValid(weapon)) then
		weapon.cwItemTable = CW.item:CreateInstance(
			data.definition.index, data.definition.itemID, data.definition.data
		);
	end;
end);

netstream.Hook("CinematicText", function(data)
	if (data and type(data) == "table") then
		CW.kernel:AddCinematicText(data.text, data.color, data.barLength, data.hangTime);
	end;
end);

netstream.Hook("AddAccessory", function(data)
	CW.AccessoryData[data.itemID] = data.uniqueID;
end);

netstream.Hook("RemoveAccessory", function(data)
	CW.AccessoryData[data.itemID] = nil;
end);

netstream.Hook("AllAccessories", function(data)
	CW.AccessoryData = {};
	
	for k, v in pairs(data) do
		CW.AccessoryData[k] = v;
	end;
end);

netstream.Hook("Notification", function(data)
	local text = data.text;
	local class = data.class;
	local sound = "ambient/water/drip2.wav";
	
	if (class == 1) then
		sound = "buttons/button10.wav";
	elseif (class == 2) then
		sound = "buttons/button17.wav";
	elseif (class == 3) then
		sound = "buttons/bell1.wav";
	elseif (class == 4) then
		sound = "buttons/button15.wav";
	end
	
	local info = {
		class = class,
		sound = sound,
		text = text
	};
	
	if (plugin.Call("NotificationAdjustInfo", info)) then
		CW.kernel:AddNotify(info.text, info.class, 10);
			surface.PlaySound(info.sound);
		print(info.text);
	end;
end);

do
	local cwOldRunConsoleCommand = RunConsoleCommand;

	function RunConsoleCommand(...)
		local arguments = {...};
	 
		if (arguments[1] == nil) then
			return;
		end;
	 
		cwOldRunConsoleCommand(...);
	end;
end;

--[[
	@codebase Client
	@details Called to display a HUD notification when a weapon has been picked up. (Used to override GMOD function)
--]]
function CW:HUDWeaponPickedUp(...) end;

--[[
	@codebase Client
	@details Called to display a HUD notification when an item has been picked up. (Used to override GMOD function)
--]]
function CW:HUDItemPickedUp(...) end;

--[[
	@codebase Client
	@details Called to display a HUD notification when ammo has been picked up. (Used to override GMOD function)
--]]
function CW:HUDAmmoPickedUp(...) end;

--[[
	@codebase Client
	@details Called when the context menu is opened.
--]]
function CW:OnContextMenuOpen()
	if (self.kernel:IsUsingTool()) then
		return self.BaseClass:OnContextMenuOpen(self);
	else
		gui.EnableScreenClicker(true);
	end;
end;

--[[
	@codebase Client
	@details Called when the context menu is close.
--]]
function CW:OnContextMenuClose()
	if (self.kernel:IsUsingTool()) then
		return self.BaseClass:OnContextMenuClose(self);
	else
		gui.EnableScreenClicker(false);
	end;
end;

--[[
	@codebase Client
	@details Called to determine if a player can use property.
	@param Player The player that is trying to use property.
	@param
	@param Entity The entity that is being used.
	@returns Bool Whether or not the player can use property.
--]]
function CW:CanProperty(player, property, entity)
	if (!IsValid(entity)) then
		return false;
	end;
	
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (!player:Alive() or player:IsRagdolled() or !bIsAdmin) then
		return false;
	end;
	
	return self.BaseClass:CanProperty(player, property, entity);
end;

--[[
	@codebase Client
	@details Called to determine if a player can drive.
	@param Player The player trying to drive.
	@param Entity The entity that the player is trying to drive.
	@return Bool Whether or not the player can drive the entity.
--]]
function CW:CanDrive(player, entity)
	if (!IsValid(entity)) then
		return false;
	end;
	
	if (!player:Alive() or player:IsRagdolled() or !self.player:IsAdmin(player)) then
		return false;
	end;

	return self.BaseClass:CanDrive(player, entity);
end;

--[[
	@codebase Client
	@details Called when the directory is rebuilt.
	@param <DPanel> The directory panel.
--]]
function CW:ClockworkDirectoryRebuilt(panel)
	for k, v in pairs(self.command.stored) do
		if (!self.player:HasFlags(self.Client, v.access)) then
			self.command:RemoveHelp(v);
		else
			self.command:AddHelp(v);
		end;
	end;
end;

--[[
	@codebase Client
	@details Called when the local player is given an item.
	@param Table The table of the item that was given.
--]]
function CW:PlayerItemGiven(itemTable)
	if (self.storage:IsStorageOpen()) then
		self.storage:GetPanel():Rebuild();
	end;
end;

--[[
	@codebase Client
	@details Called when the local player has an item taken from them.
	@param Table The table of the item that was taken.
--]]
function CW:PlayerItemTaken(itemTable)
	if (self.storage:IsStorageOpen()) then
		self.storage:GetPanel():Rebuild();
	end;
end;

-- Called when the local player's character has initialized.
function CW:PlayerCharacterInitialized(iCharacterKey) end;

--[[
	@codebase Client
	@details Called before the local player's storage is rebuilt.
	@param <DPanel> The player's storage panel.
--]]
function CW:PlayerPreRebuildStorage(panel) end;

--[[
	@codebase Client
	@details Called when the local player's storage is rebuilt.
	@param <DPanel> The player's storage panel.
	@param Table The categories for the player's storage.
--]]
function CW:PlayerStorageRebuilt(panel, categories) end;

--[[
	@codebase Client
	@details Called when the local player's business is rebuilt.
	@param <DPanel> The player's business panel.
	@param Table The categories for the player's business.
--]]
function CW:PlayerBusinessRebuilt(panel, categories) end;

--[[
	@codebase Client
	@details Called when the local player's storage is rebuilt.
	@param <DPanel> The player's storage panel.
	@param Table The categories for the player's inventory.
--]]
function CW:PlayerInventoryRebuilt(panel, categories) end;

--[[
	@codebase Client
	@details Called when an entity attempts to fire bullets.
	@param Entity The entity trying to fire bullets.
	@param Table The info of the bullets being fired.
--]]
function CW:EntityFireBullets(entity, bulletInfo) end;

--[[
	@codebase Client
	@details Called when a player's bulletInfo needs to be adjusted.
	@param Player The player that is firing bullets.
	@param Table The info of the bullets that need to be adjusted.
--]]
function CW:PlayerAdjustBulletInfo(player, bulletInfo) end;

--[[
	@codebase Client
	@details Called when clockwork's config is initialized.
	@param String The name of the config key.
	@param String The value relating to the key in the table.
--]]
function CW:ClockworkConfigInitialized(key, value)
	if (key == "cash_enabled" and !value) then
		for k, v in pairs(self.item:GetAll()) do
			v.cost = 0;
		end;
	end;
end;

local checkTable = {
	["cwTextColorR"] = true,
	["cwTextColorG"] = true,
	["cwTextColorB"] = true,
	["cwTextColorA"] = true
}

--[[
	@codebase Client
	@details Called when one of the client's console variables have been changed.
	@param String The name of the convar that was changed.
	@param String The previous value of the convar.
	@param String The new value of the convar.
--]]
function CW:ClockworkConVarChanged(name, previousValue, newValue)
	if (checkTable[name] and !self.theme:IsFixed()) then
		self.option:SetColor(
			"information",
			Color(
				GetConVarNumber("cwTextColorR"), 
				GetConVarNumber("cwTextColorG"), 
				GetConVarNumber("cwTextColorB"), 
				GetConVarNumber("cwTextColorA")
			)
		);
	elseif (name == "cwLang") then
		cwClient:SetNWString("Language", newValue);
	elseif (name == "cwActiveTheme") then
		if (self.config:Get("modify_themes"):GetBoolean()) then
			local newTheme = self.theme:FindByID(newValue);

			if (newTheme) then
				self.theme:SetActive(newTheme);
			end;
		end;
	end;
end;

--[[
	@codebase Client
	@details Called when one of the configs have been changed.
	@param String The config key that was changed.
	@param String The data provided.
	@param String The previous value of the key.
	@param String The new value of the key.
--]]
function CW:ClockworkConfigChanged(key, data, previousValue, newValue) end;

--[[
	@codebase Client
	@details Called when an entity's menu options are needed.
	@param Entity The entity that is being checked for menu options.
	@param Table The table of options for the entity.
--]]
function CW:GetEntityMenuOptions(entity, options)
	local class = entity:GetClass();
	
	if (class == "cw_item") then
		local itemTable = nil;
		
		if (entity.GetItemTable) then
			itemTable = entity:GetItemTable();
		else
			debug.Trace();
		end;
		
		if (itemTable) then
			local useText = itemTable("useText", "Use");
			
			if (itemTable.OnUse) then
				options[useText] = "CW.itemUse";
			end;
			
			if (itemTable.GetEntityMenuOptions) then
				itemTable:GetEntityMenuOptions(entity, options);
			end;
						
			options["Take"] = "CW.itemTake";
			options["Examine"] = "CW.itemExamine";
		end;
	elseif (class == "cw_belongings") then
		options["Open"] = "cwBelongingsOpen";
	elseif (class == "cw_shipment") then
		options["Open"] = "cwShipmentOpen";
	elseif (class == "cw_cash") then
		options["Take"] = "cwCashTake";
	end;
end;

--[[
	@codebase Client
	@details Called when the GUI mouse has been released.
--]]
function CW:GUIMouseReleased(code)
	if (!self.config:Get("use_opens_entity_menus"):Get()
	and vgui.CursorVisible()) then
		local trace = cwClient:GetEyeTrace();
		
		if (IsValid(trace.Entity) and trace.HitPos:Distance(cwClient:GetShootPos()) <= 80) then
			self.EntityMenu = self.kernel:HandleEntityMenu(trace.Entity);
			
			if (IsValid(self.EntityMenu)) then
				self.EntityMenu:SetPos(gui.MouseX() - (self.EntityMenu:GetWide() / 2), gui.MouseY() - (self.EntityMenu:GetTall() / 2));
			end;
		end;
	end;
end;

--[[
	@codebase Client
	@details Called when a key has been released.
	@param Player The player releasing a key.
	@param Key The key that is being released.
--]]
function CW:KeyRelease(player, key)
	if (self.config:Get("use_opens_entity_menus"):Get()) then
		if (key == IN_USE) then
			local activeWeapon = player:GetActiveWeapon();
			local trace = cwClient:GetEyeTraceNoCursor();
			
			if (IsValid(activeWeapon) and activeWeapon:GetClass() == "weapon_physgun") then
				if (player:KeyDown(IN_ATTACK)) then
					return;
				end;
			end;
			
			if (IsValid(trace.Entity) and trace.HitPos:Distance(cwClient:GetShootPos()) <= 80) then
				self.EntityMenu = self.kernel:HandleEntityMenu(trace.Entity);
				
				if (IsValid(self.EntityMenu)) then
					self.EntityMenu:SetPos(
						(ScrW() / 2) - (self.EntityMenu:GetWide() / 2), (ScrH() / 2) - (self.EntityMenu:GetTall() / 2)
					);
				end;
			end;
		end;
	end;
end;

--[[
	@codebase Client
	@details Called when the local player has been created.
--]]
function CW:LocalPlayerCreated()
	self.kernel:RegisterNetworkProxy(cwClient, "Clothes", function(entity, name, oldValue, newValue)
		if (oldValue != newValue) then
			if (newValue != "") then
				local clothesData = string.Explode(" ", newValue);
				self.ClothesData.uniqueID = clothesData[1];
				self.ClothesData.itemID = tonumber(clothesData[2]);
			else
				self.ClothesData.uniqueID = nil;
				self.ClothesData.itemID = nil;
			end;
			
			self.inventory:Rebuild();
		end;
	end);

	timer.Simple(1, function()
		netstream.Start("LocalPlayerCreated", true);
	end);
end;

--[[
	@codebase Client
	@details Called when the client initializes.
--]]
function CW:Initialize()
	CW_CONVAR_TWELVEHOURCLOCK = self.kernel:CreateClientConVar("cwTwelveHourClock", 0, true, true);
	CW_CONVAR_SHOWTIMESTAMPS = self.kernel:CreateClientConVar("cwShowTimeStamps", 0, true, true);
	CW_CONVAR_MAXCHATLINES = self.kernel:CreateClientConVar("cwHeadbobScale", 1, true, true);
	CW_CONVAR_SHOWSERVER = self.kernel:CreateClientConVar("cwShowServer", 1, true, true);
	CW_CONVAR_SHOWAURA = self.kernel:CreateClientConVar("cwShowCW", 1, true, true);
	CW_CONVAR_SHOWHINTS = self.kernel:CreateClientConVar("cwShowHints", 1, true, true);
	CW_CONVAR_SHOWLOG = self.kernel:CreateClientConVar("cwShowLog", 1, true, true);
	CW_CONVAR_SHOWOOC = self.kernel:CreateClientConVar("cwShowOOC", 1, true, true);
	CW_CONVAR_SHOWIC = self.kernel:CreateClientConVar("cwShowIC", 1, true, true);
	CW_CONVAR_VIGNETTE = self.kernel:CreateClientConVar("cwShowVignette", 1, true, true);

	CW_CONVAR_ESPTIME = self.kernel:CreateClientConVar("cwESPTime", 1, true, true);
	CW_CONVAR_ADMINESP = self.kernel:CreateClientConVar("cwAdminESP", 0, true, true);
	CW_CONVAR_ESPBARS = self.kernel:CreateClientConVar("cwESPBars", 1, true, true);
	CW_CONVAR_ITEMESP = self.kernel:CreateClientConVar("cwItemESP", 0, false, true);
	CW_CONVAR_PROPESP = self.kernel:CreateClientConVar("cwPropESP", 0, false, true);
	CW_CONVAR_SPAWNESP = self.kernel:CreateClientConVar("cwSpawnESP", 0, false, true);
	CW_CONVAR_SALEESP = self.kernel:CreateClientConVar("cwSaleESP", 0, false, true);
	CW_CONVAR_NPCESP = self.kernel:CreateClientConVar("cwNPCESP", 0, false, true);
	
	CW_CONVAR_ACTIVETHEME = self.kernel:CreateClientConVar("cwActiveTheme", "", true, true);
	CW_CONVAR_TEXTCOLORR = self.kernel:CreateClientConVar("cwTextColorR", 255, true, true);
	CW_CONVAR_TEXTCOLORG = self.kernel:CreateClientConVar("cwTextColorG", 200, true, true);
	CW_CONVAR_TEXTCOLORB = self.kernel:CreateClientConVar("cwTextColorB", 0, true, true);
	CW_CONVAR_TEXTCOLORA = self.kernel:CreateClientConVar("cwTextColorA", 255, true, true);
	CW_CONVAR_BACKCOLORR = self.kernel:CreateClientConVar("cwBackColorR", 40, true, true);
	CW_CONVAR_BACKCOLORG = self.kernel:CreateClientConVar("cwBackColorG", 40, true, true);
	CW_CONVAR_BACKCOLORB = self.kernel:CreateClientConVar("cwBackColorB", 40, true, true);
	CW_CONVAR_BACKCOLORA = self.kernel:CreateClientConVar("cwBackColorA", 255, true, true);
	CW_CONVAR_TABX = self.kernel:CreateClientConVar("cwTabPosX", 56, true, true);
	CW_CONVAR_TABY = self.kernel:CreateClientConVar("cwTabPosY", 112, true, true);
	CW_CONVAR_FADEPANEL = self.kernel:CreateClientConVar("cwFadePanels", 1, true, true);
//	CW_CONVAR_CHARSTRING = self.kernel:CreateClientConVar("cwCharString", "CHARACTERS", true, true);
//	CW_CONVAR_CLOSESTRING = self.kernel:CreateClientConVar("cwCloseString", "CLOSE MENU", true, true);
	CW_CONVAR_MATERIAL = self.kernel:CreateClientConVar("cwMaterial", "hunter/myplastic", true, true);
	CW_CONVAR_BACKX = self.kernel:CreateClientConVar("cwBackX", 61, true, true);
	CW_CONVAR_BACKY = self.kernel:CreateClientConVar("cwBackY", 109, true, true);
	CW_CONVAR_BACKW = self.kernel:CreateClientConVar("cwBackW", 321, true, true);
	CW_CONVAR_BACKH = self.kernel:CreateClientConVar("cwBackH", 109, true, true);
	CW_CONVAR_SHOWMATERIAL = self.kernel:CreateClientConVar("cwShowMaterial", 0, true, true);
	CW_CONVAR_SHOWGRADIENT = self.kernel:CreateClientConVar("cwShowGradient", 0, true, true);
	
	if (!chatbox.panel) then
		chatbox.CreateDerma();
		chatbox.Hide()
	end;
	
	self.item:Initialize();
	
	if (!self.option:GetKey("top_bars")) then
		CW_CONVAR_TOPBARS = self.kernel:CreateClientConVar("cwTopBars", 1, true, true);
	else
		self.setting:RemoveByConVar("cwTopBars");
	end;
	
	plugin.Call("ClockworkKernelLoaded");
	plugin.Call("ClockworkInitialized");
	
	self.theme:Initialize();

	self.setting:AddSettings();

	if (!self.theme:IsFixed()) then
		self.option:SetColor(
			"information",
			Color(
				GetConVarNumber("cwTextColorR"), 
				GetConVarNumber("cwTextColorG"), 
				GetConVarNumber("cwTextColorB"), 
				GetConVarNumber("cwTextColorA")
			)
		);
	end;

	hook.Remove("PostDrawEffects", "RenderWidgets")
end;

--[[
	@codebase Client
	@details Called when Clockwork has initialized.
--]]
function CW:ClockworkInitialized()
	local logoFile = "clockwork/logo/002.png";

	self.SpawnIconMaterial = self.kernel:GetMaterial("vgui/spawnmenu/hover");
	self.DefaultGradient = surface.GetTextureID("gui/gradient_down");
	self.GradientTexture = self.kernel:GetMaterial(self.option:GetKey("gradient")..".png");
	self.ClockworkSplash = self.kernel:GetMaterial(logoFile);
	self.FishEyeTexture = self.kernel:GetMaterial("models/props_c17/fisheyelens");
	self.GradientCenter = surface.GetTextureID("gui/center_gradient");
	self.GradientRight = surface.GetTextureID("gui/gradient");
	self.GradientUp = surface.GetTextureID("gui/gradient_up");
	self.ScreenBlur = self.kernel:GetMaterial("pp/blurscreen");
	self.Gradients = {
		[GRADIENT_CENTER] = self.GradientCenter;
		[GRADIENT_RIGHT] = self.GradientRight;
		[GRADIENT_DOWN] = self.DefaultGradient;
		[GRADIENT_UP] = self.GradientUp;
	};

	self.setting:AddSettings();
end;

--[[
	@codebase Client
	@details Called when the tool menu needs to be populated.
--]]
function CW:PopulateToolMenu()
	local toolGun = weapons.GetStored("gmod_tool");

	for k, v in pairs(self.tool:GetAll()) do
		toolGun.Tool[v.Mode] = v;

		if (v.AddToMenu != false) then		
			spawnmenu.AddToolMenuOption( v.Tab or "Main",
				v.Category or "New Category", 
				k, 
				v.Name or "#"..k, 
				v.Command or "gmod_tool "..k, 
				v.ConfigName or k,
				v.BuildCPanel 
			);			
		end;

		language.Add("tool."..v.UniqueID..".name", v.Name);
		language.Add("tool."..v.UniqueID..".desc", v.Desc);
		language.Add("tool."..v.UniqueID..".0", v.HelpText);
	end;
end;

--[[
	@codebase Client
	@details Called when an Clockwork item has initialized.
	@param Table The table of the item being initialized.
--]]
function CW:ClockworkItemInitialized(itemTable) end;

--[[
	@codebase Client
	@details Called after Clockwork items have been initialized.
	@param Table The table of items that have been initialized.
--]]
function CW:ClockworkPostItemsInitialized(itemsTable) end;

--[[
	@codebase Client
	@details Called when a player's phys desc override is needed.
	@param Player The player whose phys desc override is needed.
	@param String The player's physDesc.
--]]
function CW:GetPlayerPhysDescOverride(player, physDesc) end;

--[[
	@codebase Client
	@details Called when a player's door access name is needed.
--]]
function CW:GetPlayerDoorAccessName(player, door, owner)
	return player:Name();
end;

--[[
	@codebase Client
	@details Called when a player should show on the door access list.
--]]
function CW:PlayerShouldShowOnDoorAccessList(player, door, owner)
	return true;
end;

--[[
	@codebase Client
	@details Called when a player should show on the scoreboard.
--]]
function CW:PlayerShouldShowOnScoreboard(player)
	return true;
end;

--[[
	@codebase Client
	@details Called when the local player attempts to zoom.
--]]
function CW:PlayerCanZoom() return true; end;

-- Called when the local player attempts to see a business item.
function CW:PlayerCanSeeBusinessItem(itemTable) return true; end;

-- Called when a player presses a bind.
function CW:PlayerBindPress(player, bind, bPress)
	if (player:GetRagdollState() == RAGDOLL_FALLENOVER and string.find(bind, "+jump")) then
		self.kernel:RunCommand("CharGetUp");
	elseif (string.find(bind, "toggle_zoom")) then
		return true;
	elseif (string.find(bind, "+zoom")) then
		if (!plugin.Call("PlayerCanZoom")) then
			return true;
		end;
	end;
	
	if (string.find(bind, "+attack") or string.find(bind, "+attack2")) then
		if (self.storage:IsStorageOpen()) then
			return true;
		end;
	end;
	
	if (self.config:Get("block_inv_binds"):Get()) then
		if (string.find(string.lower(bind), self.config:Get("command_prefix"):Get().."invaction")
		or string.find(string.lower(bind), "cwcmd invaction")) then
			return true;
		end;
	end;
	
	return plugin.Call("TopLevelPlayerBindPress", player, bind, bPress);
end;

-- Called when a player presses a bind at the top level.
function CW:TopLevelPlayerBindPress(player, bind, bPress)
	return self.BaseClass:PlayerBindPress(player, bind, bPress);
end;

-- Called when the local player attempts to see while unconscious.
function CW:PlayerCanSeeUnconscious()
	return false;
end;

-- Called when the local player's move data is created.
function CW:CreateMove(userCmd)
	local ragdollEyeAngles = self.kernel:GetRagdollEyeAngles();
	
	if (ragdollEyeAngles and IsValid(cwClient)) then
		local defaultSensitivity = 0.05;
		local sensitivity = defaultSensitivity * (plugin.Call("AdjustMouseSensitivity", defaultSensitivity) or defaultSensitivity);
		
		if (sensitivity <= 0) then
			sensitivity = defaultSensitivity;
		end;
		
		if (cwClient:IsRagdolled()) then
			ragdollEyeAngles.p = math.Clamp(ragdollEyeAngles.p + (userCmd:GetMouseY() * sensitivity), -48, 48);
			ragdollEyeAngles.y = math.Clamp(ragdollEyeAngles.y - (userCmd:GetMouseX() * sensitivity), -48, 48);
		else
			ragdollEyeAngles.p = math.Clamp(ragdollEyeAngles.p + (userCmd:GetMouseY() * sensitivity), -90, 90);
			ragdollEyeAngles.y = math.Clamp(ragdollEyeAngles.y - (userCmd:GetMouseX() * sensitivity), -90, 90);
		end;
	end
end;

local LAST_RAISED_TARGET = 0;

-- Called when the view should be calculated.
function CW:CalcView(player, origin, angles, fov)
	local scale;
	
	if (CW_CONVAR_HEADBOBSCALE) then
		scale = math.Clamp(CW_CONVAR_HEADBOBSCALE:GetFloat(),0,1) or 1;
	else
		scale = 1;
	end;

	if (cwClient:IsRagdolled()) then
		local ragdollEntity = cwClient:GetRagdollEntity();
		local ragdollState = cwClient:GetRagdollState();
		
		if (self.BlackFadeIn == 255) then
			return {origin = Vector(20000, 0, 0), angles = Angle(0, 0, 0), fov = fov};
		else
			local eyes = ragdollEntity:GetAttachment(ragdollEntity:LookupAttachment("eyes"));
			
			if (eyes) then
				local ragdollEyeAngles = eyes.Ang + self.kernel:GetRagdollEyeAngles();
				local physicsObject = ragdollEntity:GetPhysicsObject();
				
				if (IsValid(physicsObject)) then
					local velocity = physicsObject:GetVelocity().z;
					
					if (velocity <= -1000 and cwClient:GetMoveType() == MOVETYPE_WALK) then
						ragdollEyeAngles.p = ragdollEyeAngles.p + math.sin(UnPredictedCurTime()) * math.abs((velocity + 1000) - 16);
					end;
				end;
				
				return {origin = eyes.Pos, angles = ragdollEyeAngles, fov = fov};
			else
				return self.BaseClass:CalcView(player, origin, angles, fov);
			end;
		end;
	elseif (!cwClient:Alive()) then
		return {origin = Vector(20000, 0, 0), angles = Angle(0, 0, 0), fov = fov};
	elseif (self.config:Get("enable_headbob"):Get() and scale > 0) then
		if (player:IsOnGround()) then
			local frameTime = FrameTime();
			
			if (!self.player:IsNoClipping(player)) then
				local approachTime = frameTime * 2;
				local curTime = UnPredictedCurTime();
				local info = {speed = 1, yaw = 0.5, roll = 0.1};
				
				if (!self.HeadbobAngle) then
					self.HeadbobAngle = 0;
				end;
				
				if (!self.HeadbobInfo) then
					self.HeadbobInfo = info;
				end;
				
				plugin.Call("PlayerAdjustHeadbobInfo", info);
				
				self.HeadbobInfo.yaw = math.Approach(self.HeadbobInfo.yaw, info.yaw, approachTime);
				self.HeadbobInfo.roll = math.Approach(self.HeadbobInfo.roll, info.roll, approachTime);
				self.HeadbobInfo.speed = math.Approach(self.HeadbobInfo.speed, info.speed, approachTime);
				self.HeadbobAngle = self.HeadbobAngle + (self.HeadbobInfo.speed * frameTime);
				
				local yawAngle = math.sin(self.HeadbobAngle);
				local rollAngle = math.cos(self.HeadbobAngle);
				
				angles.y = angles.y + (yawAngle * self.HeadbobInfo.yaw);
				angles.r = angles.r + (rollAngle * self.HeadbobInfo.roll);

				local velocity = player:GetVelocity();
				local eyeAngles = player:EyeAngles();
				
				if (!self.VelSmooth) then self.VelSmooth = 0; end;
				if (!self.WalkTimer) then self.WalkTimer = 0; end;
				if (!self.LastStrafeRoll) then self.LastStrafeRoll = 0; end;
				
				self.VelSmooth = math.Clamp(self.VelSmooth * 0.9 + velocity:Length() * 0.1, 0, 700)
				self.WalkTimer = self.WalkTimer + self.VelSmooth * FrameTime() * 0.05
				
				self.LastStrafeRoll = (self.LastStrafeRoll * 3) + (eyeAngles:Right():DotProduct(velocity) * 0.0001 * self.VelSmooth * 0.3);
				self.LastStrafeRoll = self.LastStrafeRoll * 0.25;
				angles.r = angles.r + self.LastStrafeRoll;
				
				if (player:GetGroundEntity() != NULL) then
					angles.p = angles.p + math.cos(self.WalkTimer * 0.5) * self.VelSmooth * 0.000002 * self.VelSmooth;
					angles.r = angles.r + math.sin(self.WalkTimer) * self.VelSmooth * 0.000002 * self.VelSmooth;
					angles.y = angles.y + math.cos(self.WalkTimer) * self.VelSmooth * 0.000002 * self.VelSmooth;
				end;
				
				velocity = cwClient:GetVelocity().z;
				
				if (velocity <= -1000 and cwClient:GetMoveType() == MOVETYPE_WALK) then
					angles.p = angles.p + math.sin(UnPredictedCurTime()) * math.abs((velocity + 1000) - 16);
				end;
			end;
		end;
	end;
	
	local view = self.BaseClass:CalcView(player, origin, angles, fov);
	
	plugin.Call("CalcViewAdjustTable", view);
	
	return view;
end;

local WEAPON_LOWERED_ANGLES = Angle(30, -30, -25);
local WEAPON_LOWERED_ORIGIN = Vector(0, 0, 0);
local DEFAULT_IRONSIGHTS_ORIGIN = Vector(-3.481, -8.242, 1.039);
local WEAPON_IRONSIGHTS = {
	weapon_pistol = {
		angles = Vector(0.493, -1.31, 2),
		origin = Vector(-5.841, -8.643, 2.939)
	},
	weapon_ar2 = {
		angles = Vector(0, 0, 0),
		origin = Vector(-3.481, -8.242, 1.039)
	},
	weapon_smg1 = {
		angles = Vector(1.208, 0, 0),
		origin = Vector(-6.422, -5.85, 0.8)
	},
	weapon_357 = {
		angles = Vector(0, -0.25, 1),
		origin = Vector(-4.7, -2, 0.65)
	},
	weapon_shotgun = {
		angles = Vector(0, 0, 0),
		origin = Vector(-8.961, -6.633, 4.239)
	}
};

function CW:CalcViewModelView(weapon, viewModel, oldEyePos, oldEyeAngles, eyePos, eyeAngles)
	if (!IsValid(weapon)) then return; end;

	local weaponRaised = self.player:GetWeaponRaised(self.Client);
	local isIronSights = self.ironsights:GetIronSights();

	if (!self.Client:HasInitialized() or !self.config:HasInitialized()
	or self.Client:GetMoveType() == MOVETYPE_OBSERVER) then
		weaponRaised = nil;
	end;
	
	local targetValue = 100;
	
	if (weaponRaised) then
		targetValue = 0;
	end;

	local fraction = (self.Client.cwRaisedFraction or 100) / 100;
	local itemTable = self.item:GetByWeapon(weapon);
	local originMod = weapon.LoweredOrigin or WEAPON_LOWERED_ORIGIN;
	local anglesMod = weapon.LoweredAngles or WEAPON_LOWERED_ANGLES;
	
	if (itemTable and itemTable("loweredAngles")) then
		anglesMod = itemTable("loweredAngles");
	elseif (weapon.LoweredAngles) then
		anglesMod = weapon.LoweredAngles;
	end;

	if (itemTable and itemTable("loweredOrigin")) then
		originMod = itemTable("loweredOrigin");
	elseif (weapon.LoweredOrigin) then
		originMod = weapon.LoweredOrigin;
	end;
		
	local viewInfo = {
		origin = originMod,
		angles = anglesMod
	};
	
	plugin.Call("GetWeaponLoweredViewInfo", itemTable, weapon, viewInfo);

	eyeAngles:RotateAroundAxis(eyeAngles:Up(), viewInfo.angles.p * fraction);
	eyeAngles:RotateAroundAxis(eyeAngles:Forward(), viewInfo.angles.y * fraction);
	eyeAngles:RotateAroundAxis(eyeAngles:Right(), viewInfo.angles.r * fraction);

	oldEyePos = oldEyePos + ((eyeAngles:Forward() * viewInfo.origin.y) + (eyeAngles:Right() * viewInfo.origin.x) + (eyeAngles:Up() * viewInfo.origin.z)) * fraction;

	self.Client.cwRaisedFraction = Lerp(FrameTime() * 2, self.Client.cwRaisedFraction or 100, targetValue)

	--Ironsights.
	local viewTable = WEAPON_IRONSIGHTS[weapon:GetClass()] or {};
	
	plugin.Call("GetWeaponIronsightsViewInfo", itemTable, weapon, viewTable);

	local ironAnglesMod = viewTable.angles;
	local ironOriginMod = viewTable.origin or DEFAULT_IRONSIGHTS_ORIGIN;
	local ironTargetValue = 0;

	if ((ironAnglesMod or ironOriginMod) and isIronSights) then
		ironTargetValue = 100;
	end;

	local fraction = (self.ironsights.ironFraction or 100) / 100;
	
	if (ironAnglesMod) then
		eyeAngles:RotateAroundAxis(eyeAngles:Up(), ironAnglesMod.y  * fraction);
		eyeAngles:RotateAroundAxis(eyeAngles:Forward(), ironAnglesMod.z * fraction);
		eyeAngles:RotateAroundAxis(eyeAngles:Right(), ironAnglesMod.x * fraction);
	end;

	if (ironOriginMod) then
		oldEyePos = oldEyePos + ((eyeAngles:Forward() * ironOriginMod.y) + (eyeAngles:Right() * ironOriginMod.x) + (eyeAngles:Up() * ironOriginMod.z)) * fraction;
	end;

	local bLerp = true;

	if (self.ironsights.ironFraction <= 1 and ironTargetValue == 0) then
		bLerp = false;
	end;

	if (bLerp) then
		self.ironsights.ironFraction = Lerp(FrameTime() * 5, self.ironsights.ironFraction or 100, ironTargetValue);
	end;
	
	--Return the edited angle and position.
	return oldEyePos, eyeAngles;
end;

-- Called when the local player's limb damage is received.
function CW:PlayerLimbDamageReceived() end;

-- Called when the local player's limb damage is reset.
function CW:PlayerLimbDamageReset() end;

-- Called when the local player's limb damage is bIsHealed.
function CW:PlayerLimbDamageHealed(hitGroup, amount) end;

-- Called when the local player's limb takes damage.
function CW:PlayerLimbTakeDamage(hitGroup, damage) end;

-- Called when a weapon's lowered view info is needed.
function CW:GetWeaponLoweredViewInfo(itemTable, weapon, viewInfo) end;

local blockedElements = {
	CHudSecondaryAmmo = true,
	CHudVoiceStatus = true,
	CHudSuitPower = true,
	CHudCrosshair = true,
	CHudBattery = true,
	CHudHealth = true,
	CHudAmmo = true,
	CHudChat = true
};

-- Called when a HUD element should be drawn.
function CW:HUDShouldDraw(name)
	if (!IsValid(cwClient) or !cwClient:HasInitialized() or self.kernel:IsChoosingCharacter()) then
		if (name != "CHudGMod") then
			return false;
		end;
	elseif (blockedElements[name]) then
		return false;
	end;
	
	return self.BaseClass:HUDShouldDraw(name);
end

-- Called when the menu is opened.
function CW:MenuOpened()
	for k, v in pairs(self.menu:GetItems()) do
		if (v.panel.OnMenuOpened) then
			v.panel:OnMenuOpened();
		end;
	end;
end;

-- Called when the menu is closed.
function CW:MenuClosed()
	for k, v in pairs(self.menu:GetItems()) do
		if (v.panel.OnMenuClosed) then
			v.panel:OnMenuClosed();
		end;
	end;

	self.kernel:RemoveActiveToolTip();
	self.kernel:CloseActiveDermaMenus();
end;

-- Called when the character screen's faction characters should be sorted.
function CW:CharacterScreenSortFactionCharacters(faction, a, b)
	return a.name < b.name;
end;

-- Called when the scoreboard's class players should be sorted.
function CW:ScoreboardSortClassPlayers(class, a, b)
	local recogniseA = self.player:DoesRecognise(a);
	local recogniseB = self.player:DoesRecognise(b);

	if (recogniseA and recogniseB) then
		return a:Team() < b:Team();
	elseif (recogniseA) then
		return true;
	else
		return false;
	end;
end;

-- Called when the scoreboard's player info should be adjusted.
function CW:ScoreboardAdjustPlayerInfo(info) end;

-- Called when the menu's items should be adjusted.
function CW:MenuItemsAdd(menuItems)
	local attributesName = self.option:GetKey("name_attributes");
	local systemName = self.option:GetKey("name_system");
	local scoreboardName = self.option:GetKey("name_scoreboard");
	local directoryName = self.option:GetKey("name_directory");
	local inventoryName = self.option:GetKey("name_inventory");
	
	menuItems:Add("#Classes", "cwClasses", "#ClassesDesc", self.option:GetKey("icon_data_classes"));
	menuItems:Add("#Settings", "cwSettings", "#SettingsDesc", self.option:GetKey("icon_data_settings"));
	menuItems:Add(systemName, "cwSystem", self.option:GetKey("description_system"), self.option:GetKey("icon_data_system"));
	menuItems:Add(scoreboardName, "cwScoreboard", self.option:GetKey("name_scoreboard"), self.option:GetKey("icon_data_scoreboard"));
	menuItems:Add(inventoryName, "cwInventory", self.option:GetKey("description_inventory"), self.option:GetKey("icon_data_inventory"));
	menuItems:Add(directoryName, "cwDirectory", self.option:GetKey("description_directory"), self.option:GetKey("icon_data_directory"));
	menuItems:Add(attributesName, "cwAttributes", self.option:GetKey("description_attributes"), self.option:GetKey("icon_data_attributes"));

	if (self.config:Get("show_business"):GetBoolean() == true) then
		local businessName = self.option:GetKey("name_business");
		menuItems:Add(businessName, "cwBusiness", self.option:GetKey("description_business"), self.option:GetKey("icon_data_business"));
	end;
end;

-- Called when the menu's items should be destroyed.
function CW:MenuItemsDestroy(menuItems) end;

function CW:HalfSecond()
	local realCurTime = CurTime();
	local curTime = UnPredictedCurTime();
	
	if (!self.NextHandleAttributeBoosts or realCurTime >= self.NextHandleAttributeBoosts) then
		self.NextHandleAttributeBoosts = realCurTime + 3;
		
		for k, v in pairs(self.attributes.boosts) do
			for k2, v2 in pairs(v) do
				if (v2.duration and v2.endTime) then
					if (realCurTime > v2.endTime) then
						self.attributes.boosts[k][k2] = nil;
					else
						local timeLeft = v2.endTime - realCurTime;
						
						if (timeLeft >= 0) then
							if (v2.default < 0) then
								v2.amount = math.min((v2.default / v2.duration) * timeLeft, 0);
							else
								v2.amount = math.max((v2.default / v2.duration) * timeLeft, 0);
							end;
						end;
					end;
				end;
			end;
		end;
	end;
end;

-- Called each tick.
function CW:Tick()
	local font = self.option:GetFont("player_info_text");
	
	if (self.character:IsPanelPolling()) then
		local panel = self.character:GetPanel();

		if (!panel and plugin.Call("ShouldCharacterMenuBeCreated")) then
			self.character:SetPanelPolling(false);
			self.character.isOpen = true;
			self.character.panel = vgui.Create("CW.characterMenu");
			self.character.panel:MakePopup();
			self.character.panel:ReturnToMainMenu();

			plugin.Call("PlayerCharacterScreenCreated", self.character.panel);
		end;
	end;

	if (IsValid(self.Client) and !self.kernel:IsChoosingCharacter()) then
		self.bars.stored = {};
		self.PlayerInfoText.text = {};
		self.PlayerInfoText.width = ScrW() * 0.15;
		self.PlayerInfoText.subText = {};

		self.kernel:DrawHealthBar();
		self.kernel:DrawArmorBar();

		plugin.Call("GetBars", self.bars);
		plugin.Call("DestroyBars", self.bars);
		plugin.Call("GetPlayerInfoText", self.PlayerInfoText);
		plugin.Call("DestroyPlayerInfoText", self.PlayerInfoText);

		table.sort(self.bars.stored, function(a, b)
			if (a.text == "" and b.text == "") then
				return a.priority > b.priority;
			elseif (a.text == "") then
				return true;
			else
				return a.priority > b.priority;
			end;
		end);
		
		table.sort(self.PlayerInfoText.subText, function(a, b)
			return a.priority > b.priority;
		end);
		
		for k, v in pairs(self.PlayerInfoText.text) do
			self.PlayerInfoText.width = self.kernel:AdjustMaximumWidth(font, v.text, self.PlayerInfoText.width);
		end;
		
		for k, v in pairs(self.PlayerInfoText.subText) do
			self.PlayerInfoText.width = self.kernel:AdjustMaximumWidth(font, v.text, self.PlayerInfoText.width);
		end;
		
		self.PlayerInfoText.width = self.PlayerInfoText.width + 16;
		
		if (self.config:Get("fade_dead_npcs"):Get()) then
			for k, v in pairs(ents.FindByClass("class C_ClientRagdoll")) do
				if (!self.entity:IsDecaying(v)) then
					self.entity:Decay(v, 300);
				end;
			end;
		end;
		
		local playedHeartbeatSound = false;
		
		if (cwClient:Alive() and self.config:Get("enable_heartbeat"):Get()) then
			local maxHealth = cwClient:GetMaxHealth();
			local health = cwClient:Health();
			
			if (health < maxHealth) then
				if (!self.HeartbeatSound) then
					self.HeartbeatSound = CreateSound(cwClient, "player/heartbeat1.wav");
				end;
				
				if (!self.NextHeartbeat or CurTime() >= self.NextHeartbeat) then
					self.NextHeartbeat = CurTime() + (0.75 + ((1.25 / maxHealth) * health));
					self.HeartbeatSound:PlayEx(0.75 - ((0.7 / maxHealth) * health), 100);
				end;
				
				playedHeartbeatSound = true;
			end;
		end;
		
		if (!playedHeartbeatSound and self.HeartbeatSound) then
			self.HeartbeatSound:Stop();
		end;
	end;

	if (self.kernel:IsInfoMenuOpen() and !input.IsKeyDown(KEY_F1)) then
		CW.kernel:RemoveBackgroundBlur("InfoMenu");
		CW.kernel:CloseActiveDermaMenus();
		CW.InfoMenuOpen = false;
		
		if (IsValid(self.InfoMenuPanel)) then
			self.InfoMenuPanel:SetVisible(false);
			self.InfoMenuPanel:Remove();
		end;
		
		timer.Simple(FrameTime() * 0.5, function()
			self.kernel:RemoveActiveToolTip();
		end);
	end;
	
	local menuMusic = self.option:GetKey("menu_music");
	
	if (menuMusic != "") then
		if (IsValid(cwClient) and self.character:IsPanelOpen()) then
			if (!self.MusicSound) then
				self.MusicSound = CreateSound(cwClient, menuMusic);
				self.MusicSound:PlayEx(0.3, 100);
				self.MusicFading = false;
			end;
		elseif (self.MusicSound and !self.MusicFading) then
			self.MusicSound:FadeOut(8);
			self.MusicFading = true;
			
			timer.Simple(8, function()
				self.MusicSound = nil;
			end);
		end;
	end;
	
	local worldEntity = game.GetWorld();
	
	for k, v in pairs(self.NetworkProxies) do
		if (IsValid(k) or k == worldEntity) then
			for k2, v2 in pairs(v) do
				local value = nil;
				
				if (k == worldEntity) then
					value = self.kernel:GetSharedVar(k2);
				else
					value = k:GetSharedVar(k2);
				end;
				
				if (value != v2.oldValue) then
					v2.Callback(k, k2, v2.oldValue, value);
					v2.oldValue = value;
				end;
			end;
		else
			self.NetworkProxies[k] = nil;
		end;
	end;
end;

function CW:InitPostEntity()
	self.Client = LocalPlayer();
	cwClient = self.Client;

	if (IsValid(self.Client)) then
		plugin.Call("LocalPlayerCreated");
	end;
end;

-- Called each frame.
function CW:Think()
	self.kernel:CallTimerThink(CurTime());
	self.kernel:CalculateHints();
	
	if (self.kernel:IsCharacterScreenOpen()) then
		local panel = self.character:GetPanel();
		
		if (panel) then
			panel:SetVisible(plugin.Call("GetPlayerCharacterScreenVisible", panel));
			
			if (panel:IsVisible()) then
				self.HasCharacterMenuBeenVisible = true;
			end;
		end;
	end;
end;

-- Called when the character loading HUD should be painted.
function CW:HUDPaintCharacterLoading(alpha) end;

-- Called when the character selection HUD should be painted.
function CW:HUDPaintCharacterSelection() end;

-- Called when the important HUD should be painted.
function CW:HUDPaintImportant() end;

-- Called when the top screen HUD should be painted.
function CW:HUDPaintTopScreen(info) end;

local SCREEN_DAMAGE_OVERLAY = CW.kernel:GetMaterial("clockwork/screendamage.png");
local VIGNETTE_OVERLAY = CW.kernel:GetMaterial("clockwork/vignette.png");

-- Called when the local player's screen damage should be drawn.
function CW:DrawPlayerScreenDamage(damageFraction)
	local scrW, scrH = ScrW(), ScrH();

	surface.SetDrawColor(255, 255, 255, math.Clamp(255 * damageFraction, 0, 255));
	surface.SetMaterial(SCREEN_DAMAGE_OVERLAY);
	surface.DrawTexturedRect(0, 0, scrW, scrH);
end;

--[[
	Called when the entity outlines should be added.
	The "outlines" parameter is a reference to CW.outline.
--]]
function CW:AddEntityOutlines(outlines)
	if (IsValid(self.EntityMenu) and IsValid(self.EntityMenu.entity)) then
		--[[ Maybe this isn't needed. --]]
		self.EntityMenu.entity:DrawModel();
		
		outlines:Add(
			self.EntityMenu.entity, Color(255, 255, 255, 255)
		);
	end;
end;

-- Called when the local player's vignette should be drawn.
function CW:DrawPlayerVignette()
	local curTime = CurTime();
	
	if (!self.cwVignetteAlpha) then
		self.cwVignetteAlpha = 100;
		self.cwVignetteDelta = self.cwVignetteAlpha;
		self.cwVignetteRayTime = 0;
	end;
	
	if (curTime >= self.cwVignetteRayTime) then
		local data = {};
			data.start = cwClient:GetShootPos();
			data.endpos = data.start + (cwClient:GetUp() * 512);
			data.filter = cwClient;
		local trace = util.TraceLine(data);

		if (!trace.HitWorld and !trace.HitNonWorld) then
			self.cwVignetteAlpha = 100;
		else
			self.cwVignetteAlpha = 255;
		end;
		
		self.cwVignetteRayTime = curTime + 1;
	end;

	self.cwVignetteDelta = math.Approach(
		self.cwVignetteDelta, self.cwVignetteAlpha, FrameTime() * 70
	);

	local scrW, scrH = ScrW(), ScrH();
	surface.SetDrawColor(0, 0, 0, self.cwVignetteDelta);
	surface.SetMaterial(VIGNETTE_OVERLAY);
	surface.DrawTexturedRect(0, 0, scrW, scrH);
end;

-- Called when the foreground HUD should be painted.
function CW:HUDPaintForeground()
	local backgroundColor = self.option:GetColor("background");
	local colorWhite = self.option:GetColor("white");
	local info = plugin.Call("GetProgressBarInfo");
	
	if (self.Client:GetRagdollState() == RAGDOLL_FALLENOVER) then
		cdraw.DrawSimpleBlurBox(0, 0, ScrW(), ScrH(), Color(40, 40, 40, 45), 2);
	elseif (self.Client:WaterLevel() >= 3) then
		cdraw.DrawSimpleBlurBox(0, 0, ScrW(), ScrH(), Color(40, 40, 40, 45), 4);
	end;
	
	if (info) then
		local height = 32;
		local width = (ScrW() * 0.5);
		local x = ScrW() * 0.25;
		local y = ScrH() * 0.3;
		
		--cdraw.DrawBox(x, y, width, height, Color(200, 200, 200));
		
		self.kernel:DrawBar(
			x, y, width, height, info.color or self.option:GetColor("information"),
			info.text or "Progress Bar", info.percentage or 100, 100, info.flash, {uniqueID = info.uniqueID}
		);
	else
		info = plugin.Call("GetPostProgressBarInfo");
		
		if (info) then
			local height = 32;
			local width = (ScrW() / 2) - 64;
			local x = ScrW() * 0.25;
			local y = ScrH() * 0.3;
			
			--cdraw.DrawBox(x, y, width, height, Color(200, 200, 200));
			
			self.kernel:DrawBar(
				x, y, width, height, info.color or self.option:GetColor("information"),
				info.text or "Progress Bar", info.percentage or 100, 100, info.flash, {uniqueID = info.uniqueID}
			);
		end;
	end;
	
	if (self.player:IsAdmin(cwClient)) then
		if (plugin.Call("PlayerCanSeeAdminESP")) then
			self.kernel:DrawAdminESP();
		end;
	end;
	
	local screenTextInfo = plugin.Call("GetScreenTextInfo");
	
	if (screenTextInfo) then
		local alpha = screenTextInfo.alpha or 255;
		local y = (ScrH() / 2) - 128;
		local x = ScrW() / 2;
		
		if (screenTextInfo.title) then
			self.kernel:OverrideMainFont(self.option:GetFont("menu_text_small"));
				y = self.kernel:DrawInfo(screenTextInfo.title, x, y, colorWhite, alpha);
			self.kernel:OverrideMainFont(false);
		end;
		
		if (screenTextInfo.text) then
			self.kernel:OverrideMainFont(self.option:GetFont("menu_text_tiny"));
				y = self.kernel:DrawInfo(screenTextInfo.text, x, y, colorWhite, alpha);
			self.kernel:OverrideMainFont(false);
		end;
	end;
	
	local info = {width = ScrW() * self.option:GetKey("top_bar_width_scale"), x = 8, y = 8};
		self.kernel:DrawBars(info, "top");
	plugin.Call("HUDPaintTopScreen", info);
end;

-- Called each frame that an item entity exists.
function CW:ItemEntityThink(itemTable, entity) end;

-- Called when an item entity is drawn.
function CW:ItemEntityDraw(itemTable, entity) end;

-- Called when a cash entity is drawn.
function CW:CashEntityDraw(entity) end;

-- Called when a gear entity is drawn.
function CW:GearEntityDraw(entity) end;

-- Called when a shipment entity is drawn.
function CW:ShipmentEntityDraw(entity) end;

-- Called when an item's network data has been updated.
function CW:ItemNetworkDataUpdated(itemTable, newData)
	if (itemTable.OnNetworkDataUpdated) then
		itemTable:OnNetworkDataUpdated(newData);
	end;
end;

--[[
	@codebase Client
	@details Called when the Clockwork kernel has loaded.
--]]
function CW:ClockworkKernelLoaded() end;

-- Called to get the screen text info.
function CW:GetScreenTextInfo()
	local blackFadeAlpha = self.kernel:GetBlackFadeAlpha();
	
	if (cwClient:GetSharedVar("CharBanned")) then
		return {
			alpha = blackFadeAlpha,
			title = "THIS CHARACTER IS BANNED",
			text = "Go to the characters menu to make a new one."
		};
	end;
end;


-- Called after the VGUI has been rendered.
function CW:PostRenderVGUI()
	local cinematic = self.Cinematics[1];
	
	if (cinematic) then
		self.kernel:DrawCinematic(cinematic, CurTime());
	end;

	local activeMarkupToolTip = self.kernel:GetActiveMarkupToolTip();

	if (activeMarkupToolTip and IsValid(activeMarkupToolTip) and activeMarkupToolTip:IsVisible()) then
		local markupToolTip = activeMarkupToolTip:GetMarkupToolTip();
		local alpha = activeMarkupToolTip:GetAlpha();
		local x, y = gui.MouseX(), gui.MouseY() + 24;
		
		if (markupToolTip) then
			self.kernel:DrawMarkupToolTip(markupToolTip.object, x, y, alpha);
		end;
	end;
end;

-- Called to get whether the local player can see the admin ESP.
function CW:PlayerCanSeeAdminESP()
	return (CW_CONVAR_ADMINESP:GetInt() == 1);
end;

-- Called when the local player attempts to get up.
function CW:PlayerCanGetUp() return true; end;

-- Called when the local player attempts to see the top bars.
function CW:PlayerCanSeeBars(class)
	if (class == "tab") then
		if (CW_CONVAR_TOPBARS) then
			return (CW_CONVAR_TOPBARS:GetInt() == 0 and self.kernel:IsInfoMenuOpen());
		else
			return self.kernel:IsInfoMenuOpen();
		end;
	elseif (class == "top") then
		if (CW_CONVAR_TOPBARS) then
			return CW_CONVAR_TOPBARS:GetInt() == 1;
		else
			return true;
		end;
	else
		return true;
	end;
end;

-- Called when the local player's limb info is needed.
function CW:GetPlayerLimbInfo(info) end;

-- Called when the local player attempts to see the top hints.
function CW:PlayerCanSeeHints()
	return true;
end;

-- Called when the local player attempts to see the center hints.
function CW:PlayerCanSeeCenterHints()
	return true;
end;

-- Called when the local player attempts to see their limb damage.
function CW:PlayerCanSeeLimbDamage()
	return (self.kernel:IsInfoMenuOpen() and self.config:Get("limb_damage_system"):Get());
end;

-- Called when the local player attempts to see the date and time.
function CW:PlayerCanSeeDateTime()
	return self.kernel:IsInfoMenuOpen();
end;

-- Called when the local player attempts to see a class.
function CW:PlayerCanSeeClass(class)
	return true;
end;

-- Called when the local player attempts to see the player info.
function CW:PlayerCanSeePlayerInfo()
	return self.kernel:IsInfoMenuOpen();
end;

--
function CW:AddHint(name, delay)
	if (IsValid(cwClient) and cwClient:HasInitialized()) then
		self.kernel:AddTopHint(
			self.kernel:ParseData("#Hint_"..name), delay
		);
	end;
end;

--
function CW:AddNotify(text, class, length)
	return self.kernel:AddNotify(text, class, length);
end;

-- Called when the target ID HUD should be drawn.
function CW:HUDDrawTargetID()
	local targetIDTextFont = self.option:GetFont("target_id_text");
	local traceEntity = NULL;
	local colorWhite = self.option:GetColor("white");
	
	self.kernel:OverrideMainFont(targetIDTextFont);
	
	if (IsValid(cwClient) and cwClient:Alive() and !IsValid(self.EntityMenu)) then
		if (!cwClient:IsRagdolled(RAGDOLL_FALLENOVER)) then
			local fadeDistance = 196;
			local curTime = UnPredictedCurTime();
			local trace = self.player:GetRealTrace(cwClient);
			
			if (IsValid(trace.Entity) and !trace.Entity:IsEffectActive(EF_NODRAW)) then
				if (!self.TargetIDData or self.TargetIDData.entity != trace.Entity) then
					self.TargetIDData = {
						showTime = curTime + self.config:Get("target_id_delay"):Get(),
						entity = trace.Entity
					};
				end;
				
				if (self.TargetIDData) then
					self.TargetIDData.trace = trace;
				end;
				
				if (!IsValid(traceEntity)) then
					traceEntity = trace.Entity;
				end;
				
				if (curTime >= self.TargetIDData.showTime) then
					if (!self.TargetIDData.fadeTime) then
						self.TargetIDData.fadeTime = curTime + 1;
					end;
					
					local class = trace.Entity:GetClass();
					local entity = self.entity:GetPlayer(trace.Entity);
					
					if (entity) then
						fadeDistance = plugin.Call("GetTargetPlayerFadeDistance", entity);
					end;
					
					local alpha = math.Clamp(self.kernel:CalculateAlphaFromDistance(fadeDistance, cwClient, trace.HitPos) * 1.5, 0, 255);
					
					if (alpha > 0) then
						alpha = math.min(alpha, math.Clamp(1 - ((self.TargetIDData.fadeTime - curTime) / 3), 0, 1) * 255);
					end;
					
					self.TargetIDData.fadeDistance = fadeDistance;
					self.TargetIDData.player = entity;
					self.TargetIDData.alpha = alpha;
					self.TargetIDData.class = class;
					
					if (entity and cwClient != entity) then
						if (plugin.Call("ShouldDrawPlayerTargetID", entity)) then
							if (!self.player:IsNoClipping(entity)) then
								if (cwClient:GetShootPos():Distance(trace.HitPos) <= fadeDistance) then
									if (self.nextCheckRecognises and self.nextCheckRecognises[2] != entity) then
										cwClient:SetSharedVar("TargetKnows", true);
									end;
									
									local flashAlpha = nil;
									local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
									local x, y = toScreen.x, toScreen.y;
									
									if (!self.player:DoesTargetRecognise()) then
										flashAlpha = math.Clamp(math.sin(curTime * 2) * alpha, 0, 255);
									end;
									
									if (self.player:DoesRecognise(entity, RECOGNISE_PARTIAL)) then
										local text = string.Explode("\n", plugin.Call("GetTargetPlayerName", entity));
										local newY;
										
										for k, v in pairs(text) do
											newY = self.kernel:DrawInfo(v, x, y, _team.GetColor(entity:Team()), alpha);
											
											if (flashAlpha) then
												self.kernel:DrawInfo(v, x, y, colorWhite, flashAlpha);
											end;
											
											if (newY) then
												y = newY;
											end;
										end;
									else
										local unrecognisedName, usedPhysDesc = self.player:GetUnrecognisedName(entity);
										local wrappedTable = {unrecognisedName};
										local teamColor = _team.GetColor(entity:Team());
										local result = plugin.Call("PlayerCanShowUnrecognised", entity, x, y, unrecognisedName, teamColor, alpha, flashAlpha);
										local newY;
										
										if (type(result) == "string") then
											wrappedTable = {};
											self.kernel:WrapText(result, targetIDTextFont, math.max(ScrW() / 9, 384), wrappedTable);
										elseif (usedPhysDesc) then
											wrappedTable = {};
											self.kernel:WrapText(unrecognisedName, targetIDTextFont, math.max(ScrW() / 9, 384), wrappedTable);
										end;
										
										if (result == true or type(result) == "string") then
											for k, v in pairs(wrappedTable) do
												newY = self.kernel:DrawInfo(v, x, y, teamColor, alpha);
													
												if (flashAlpha) then
													self.kernel:DrawInfo(v, x, y, colorWhite, flashAlpha);
												end;
												
												if (newY) then
													y = newY;
												end;
											end;
										elseif (tonumber(result)) then
											y = result;
										end;
									end;
									
									self.TargetPlayerText.stored = {};
									
									plugin.Call("GetTargetPlayerText", entity, self.TargetPlayerText);
									plugin.Call("DestroyTargetPlayerText", entity, self.TargetPlayerText);
									
									y = plugin.Call("DrawTargetPlayerStatus", entity, alpha, x, y) or y;
									
									for k, v in pairs(self.TargetPlayerText.stored) do
										if (v.scale) then
											y = self.kernel:DrawInfoScaled(v.scale, v.text, x, y, v.color or colorWhite, alpha);
										else
											y = self.kernel:DrawInfo(v.text, x, y, v.color or colorWhite, alpha);
										end;
									end;
									
									if (!self.nextCheckRecognises or curTime >= self.nextCheckRecognises[1]
									or self.nextCheckRecognises[2] != entity) then
										netstream.Start("GetTargetRecognises", entity);
										
										self.nextCheckRecognises = {curTime + 2, entity};
									end;
								end;
							end;
						end;
					elseif (trace.Entity:IsWeapon()) then
						if (cwClient:GetShootPos():Distance(trace.HitPos) <= fadeDistance) then
							local active = nil;
							for k, v in pairs(_player.GetAll()) do
								if (v:GetActiveWeapon() == trace.Entity) then
									active = true;
								end;
							end;
							
							if (!active) then
								local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
								local x, y = toScreen.x, toScreen.y;

								y = self.kernel:DrawInfo("An unknown weapon", x, y, Color(200, 100, 50, 255), alpha);
								y = self.kernel:DrawInfo("Press use to equip.", x, y, colorWhite, alpha);
							end;
						end;
					elseif (trace.Entity.HUDPaintTargetID) then
						local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
						local x, y = toScreen.x, toScreen.y;
						trace.Entity:HUDPaintTargetID(x, y, alpha);
					else
						local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
						local x, y = toScreen.x, toScreen.y;
						
						hook.Call("HUDPaintEntityTargetID", Clockwork, trace.Entity, {
							alpha = alpha,
							x = x,
							y = y
						});
					end;
				end;
			end;
		end;
	end;

	self.kernel:OverrideMainFont(false);

	if (!IsValid(traceEntity)) then
		if (self.TargetIDData) then
			self.TargetIDData = nil;
		end;
	end;
end;

-- Called when the target's status should be drawn.
function CW:DrawTargetPlayerStatus(target, alpha, x, y)
	local informationColor = self.option:GetColor("information");
	local gender = "He";

	if (target:GetGender() == GENDER_FEMALE) then
		gender = "She";
	end;

	if (!target:Alive()) then
		return self.kernel:DrawInfo(gender.." is clearly deceased.", x, y, informationColor, alpha);
	else
		return y;
	end;
end;

-- Called when the local player's character creation info should be adjusted.
function CW:PlayerAdjustCharacterCreationInfo(panel, info) end;

-- Called when the character panel tool tip is needed.
function CW:GetCharacterPanelToolTip(panel, character)
	if (table.Count(self.faction:GetAll()) > 1) then
		local numPlayers = #self.faction:GetPlayers(character.faction);
		local numLimit = self.faction:GetLimit(character.faction);
		return "There are "..numPlayers.."/"..numLimit.." characters with this faction.";
	end;
end;

-- Called when the character panel weapon model is needed.
function CW:GetCharacterPanelSequence(entity, character) end;

-- Called when the character panel weapon model is needed.
function CW:GetCharacterPanelWeaponModel(panel, character) end;

-- Called when a model selection's weapon model is needed.
function CW:GetModelSelectWeaponModel(model) end;

-- Called when a model selection's sequence is needed.
function CW:GetModelSelectSequence(entity, model) end;

--[[
    @codebase Client
    @details Finds the location of the player and packs together the info for observer ESP.
    @class Clockwork
    @param Table The current table of ESP positions/colors/names to add on to.
--]]
function CW:GetAdminESPInfo(info)
	for k, v in pairs(_player.GetAll()) do
		if (v:HasInitialized()) then			
			local physBone = v:LookupBone("ValveBiped.Bip01_Head1");
			local position = nil;

			if (physBone) then
				local bonePosition = v:GetBonePosition(physBone);
						
				if (bonePosition) then
					position = bonePosition + Vector(0, 0, 16);
				end;
			else
				position = v:GetPos() + Vector(0, 0, 80);
			end;

			local topText = {v:Name()};

			plugin.Call("GetStatusInfo", v, topText);	

			local text = {
				{
					text = table.concat(topText, " "), 
					color = _team.GetColor(v:Team())
				}
			};

			plugin.Call("GetPlayerESPInfo", v, text);

			table.insert(info, {
				position = position,
				text = text
			});
		end;
	end;

	if (CW_CONVAR_SALEESP:GetInt() == 1) then
		for k, v in pairs (ents.GetAll()) do 
			if (v:GetClass() == "cw_salesman") then
				if (v:IsValid()) then
					local position = v:GetPos() + Vector(0, 0, 80);
					local saleName = v:GetNetworkedString("Name");
					local color = Color(255, 150, 0, 255);

					table.insert(info, {
						position = position,
						text = {
							{
								text = "[Salesman]", 
								color = color
							},
							{
								text = saleName, 
								color = color
							}
						}
					});
				end;
			end;
		end;
	end;

	if (CW_CONVAR_ITEMESP:GetInt() == 1) then
		for k, v in pairs (ents.GetAll()) do 
			if (v:GetClass() == "cw_item") then
				if (v:IsValid()) then
					local position = v:GetPos();
					local itemTable = self.entity:FetchItemTable(v);

					if (itemTable) then
						local itemName = itemTable("name");
						local color = Color(0, 255, 255, 255);

						table.insert(info, {
							position = position,
							text = {
								{
									text = "[Item]",
									color = color
								},
								{
									text = itemName,
									color = color
								}
							}
						});
					end;
				end;
			end;
		end;
	end;
end;

-- Called when a player's status info is needed.
function CW:GetStatusInfo(player, text)
	local action = self.player:GetAction(player, true);
	
	if (action) then
		if (!player:IsRagdolled()) then
			if (action == "lock") then
				table.insert(text, "[Locking]");
			elseif (action == "unlock") then
				table.insert(text, "[Unlocking]");
			end;
		elseif (action == "unragdoll") then
			if (player:GetRagdollState() == RAGDOLL_FALLENOVER) then
				table.insert(text, "[Getting Up]");
			else
				table.insert(text, "[Unconscious]");
			end;
		elseif (!player:Alive()) then
			table.insert(text, "[Dead]");
		else
			table.insert(text, "[Performing '"..action.."']");
		end;
	end;
	
	if (player:GetRagdollState() == RAGDOLL_FALLENOVER) then
		local fallenOver = player:GetDTBool(BOOL_FALLENOVER);

		if (fallenOver) then
			table.insert(text, "[Fallen Over]");			
		end;
	end;
end;

-- Called when extra player info is needed.
function CW:GetPlayerESPInfo(player, text)
	if (player:IsValid()) then
		local weapon = player:GetActiveWeapon();
		local health = player:Health();
		local armor = player:Armor();
		local colorWhite = Color(255, 255, 255, 255);
		local colorRed = Color(255, 0, 0, 255);
		local colorHealth = colorWhite;
		local colorArmor = colorWhite;
		
		table.insert(text, {
			text = player:SteamName(), 
			color = Color(170, 170, 170, 255), 
			icon = self.player:GetChatIcon(player)
		});

		if (player:Alive() and health > 0) then
			if (CW_CONVAR_ESPBARS:GetInt() == 0) then
				colorHealth = self:GetValueColor(health);
				colorArmor = self:GetValueColor(armor);
			end;

			table.insert(text, {
				text = "Health: ["..health.."]", 
				color = colorHealth, 
				bar = {
					value = health,
					max = player:GetMaxHealth()
				}
			});
			
			if (player:Armor() > 0) then
				table.insert(text, {
					text = "Armor: ["..armor.."]",
					color = colorArmor, 
					bar = {
						value = armor,
						max = player:GetMaxArmor()
					}, 
					barColor = Color(30, 65, 175, 255)
				});
			end;
		
			if (weapon and IsValid(weapon)) then			
				local raised = self.player:GetWeaponRaised(player);
				local color = colorWhite;

				if (raised == true) then
					color = colorRed;
				end;
				
				if (weapon.GetPrintName) then
					local printName = weapon:GetPrintName();

					if (printName) then
						table.insert(text, {
							text = printName, 
							color = color
						});
					end;
				end;
			end;
		end;
	end;
end;

-- A function to get the color of a value from green to red.
function CW:GetValueColor(value)
	local red = math.floor(255 - (value * 2.55));
	local green = math.floor(value * 2.55);
	
	return Color(red, green, 0, 255);
end;

--[[
    @codebase Client
    @details This function is called after the progress bar info updates.
    @class Clockwork
--]]
function CW:GetPostProgressBarInfo() end;

--[[
    @codebase Client
    @details This function is called when custom character options are needed.
    @class Clockwork
    @param Table The character whose options are needed.
    @param Table The currently available options.
    @param Table The menu itself.
--]]
function CW:GetCustomCharacterOptions(character, options, menu) end;

--[[
    @codebase Client
    @details This function is called when custom character buttons are needed.
    @class Clockwork
    @param Table The character whose buttons are needed.
    @param Table The currently available buttons.
--]]
function CW:GetCustomCharacterButtons(character, buttons) end;

--[[
    @codebase Client
    @details This function is called to figure out the text, percentage and flash of the current progress bar.
    @class Clockwork
    @returns Table The text, flash, and percentage of the progress bar.
--]]
function CW:GetProgressBarInfo()
	local action, percentage = self.player:GetAction(self.Client, true);
	
	if (!self.Client:Alive() and action == "spawn") then
		return {text = "You will be respawned shortly.", percentage = percentage, flash = percentage < 10, isBlocky = true, blocksAmt = 32};
	end;
	
	if (!self.Client:IsRagdolled()) then
		if (action == "lock") then
			return {text = "The entity is being locked.", percentage = percentage, flash = percentage < 10, isBlocky = true, blocksAmt = 32};
		elseif (action == "unlock") then
			return {text = "The entity is being unlocked.", percentage = percentage, flash = percentage < 10, isBlocky = true, blocksAmt = 32};
		end;
	elseif (action == "unragdoll") then
		if (self.Client:GetRagdollState() == RAGDOLL_FALLENOVER) then
			return {text = "You are regaining stability.", percentage = percentage, flash = percentage < 10, isBlocky = true, blocksAmt = 32};
		else
			return {text = "You are regaining conciousness.", percentage = percentage, flash = percentage < 10, isBlocky = true, blocksAmt = 32};
		end;
	elseif (self.Client:GetRagdollState() == RAGDOLL_FALLENOVER) then
		local fallenOver = self.Client:GetDTBool(BOOL_FALLENOVER);
		
		if (fallenOver and plugin.Call("PlayerCanGetUp")) then
			return {text = "Press 'jump' to get up.", percentage = 100, isBlocky = true, blocksAmt = 32};
		end;
	end;
end;

-- Called just before the local player's information is drawn.
function CW:PreDrawPlayerInfo(boxInfo, information, subInformation) end;

-- Called just after the local player's information is drawn.
function CW:PostDrawPlayerInfo(boxInfo, information, subInformation) end;

-- Called just after the date time box is drawn.
function CW:PostDrawDateTimeBox(info) end;

--[[
	@codebase Client
	@details Called after the view model is drawn.
	@param Entity The viewmodel being drawn.
	@param Player The player drawing the viewmodel.
	@param Weapon The weapon table for the viewmodel.
--]]
function CW:PostDrawViewModel(viewModel, player, weapon)
   	if (weapon.UseHands or !weapon:IsScripted()) then
    	local hands = cwClient:GetHands();

      	if IsValid(hands) then 
      		hands:DrawModel();
      	end;
   	end;
end;

--[[
    @codebase Client
    @details This function is called when local player info text is needed and adds onto it (F1 menu).
    @class Clockwork
    @param Table The current table of player info text to add onto.
--]]
function CW:GetPlayerInfoText(playerInfoText)
	local cash = self.player:GetCash() or 0;
	local wages = self.player:GetWages() or 0;
	
	if (self.config:Get("cash_enabled"):Get()) then
		if (cash > 0) then
			playerInfoText:Add("CASH", CW.lang:TranslateText(self.option:GetKey("name_cash")..": "..self.kernel:FormatCash(cash, true)));
		end;
		
		if (wages > 0) then
			playerInfoText:Add("WAGES", CW.lang:TranslateText(cwClient:GetWagesName()..": "..self.kernel:FormatCash(wages)));
		end;
	end;

	playerInfoText:AddSub("NAME", cwClient:Name(), 2);
	playerInfoText:AddSub("CLASS", _team.GetName(cwClient:Team()), 1);
end;

--[[
    @codebase Client
    @details This function is called when the player's fade distance is needed for their target text (when you look at them).
    @class Clockwork
    @param Table The player we are finding the distance for.
    @returns Int The fade distance, defaulted at 4096.
--]]
function CW:GetTargetPlayerFadeDistance(player)
	return 4096;
end;

-- Called when the player info text should be destroyed.
function CW:DestroyPlayerInfoText(playerInfoText) end;

--[[
    @codebase Client
    @details This function is called when the targeted player's target text is needed.
    @class Clockwork
    @param Table The player we are finding the distance for.
    @param Table The player's current target text.
--]]
function CW:GetTargetPlayerText(player, targetPlayerText)
	local targetIDTextFont = self.option:GetFont("target_id_text");
	local physDescTable = {};
	local thirdPerson = "him";
	
	if (player:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
	end;

	if (self.player:DoesRecognise(player, RECOGNISE_PARTIAL)) then
		self.kernel:WrapText(self.player:GetPhysDesc(player), targetIDTextFont, math.max(ScrW() / 9, 384), physDescTable);

		for k, v in pairs(physDescTable) do
			targetPlayerText:Add("PHYSDESC_"..k, v);
		end;
	elseif (player:Alive()) then
		targetPlayerText:Add("PHYSDESC", "You do not recognise "..thirdPerson..".");
	end;
end;

-- Called when the target player's text should be destroyed.
function CW:DestroyTargetPlayerText(player, targetPlayerText) end;

-- Called when a player's scoreboard text is needed.
function CW:GetPlayerScoreboardText(player)
	local thirdPerson = "him";
	
	if (player:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
	end;
	
	if (self.player:DoesRecognise(player, RECOGNISE_PARTIAL)) then
		local physDesc = self.player:GetPhysDesc(player);
		
		if (string.utf8len(physDesc) > 64) then
			return string.utf8sub(physDesc, 1, 61).."...";
		else
			return physDesc;
		end;
	else
		return "You do not recognise "..thirdPerson..".";
	end;
end;

-- Called when the local player's character screen faction is needed.
function CW:GetPlayerCharacterScreenFaction(character)
	return character.faction;
end;

-- Called to get whether the local player's character screen is visible.
function CW:GetPlayerCharacterScreenVisible(panel)
	if (!self.quiz:GetEnabled() or self.quiz:GetCompleted()) then
		return true;
	else
		return false;
	end;
end;

-- Called to get whether the character menu should be created.
function CW:ShouldCharacterMenuBeCreated()
	if (self.ClockworkIntroFadeOut) then
		return false;
	end;
	
	return true;
end;

-- Called when the local player's character screen is created.
function CW:PlayerCharacterScreenCreated(panel)
	if (self.quiz:GetEnabled()) then
		netstream.Start("GetQuizStatus", true);
	end;
end;

-- Called when a player's scoreboard class is needed.
function CW:GetPlayerScoreboardClass(player)
	return _team.GetName(player:Team());
end;

-- Called when a player's scoreboard options are needed.
function CW:GetPlayerScoreboardOptions(player, options, menu)
	local charTakeFlags = self.command:FindByID("CharTakeFlags");
	local charGiveFlags = self.command:FindByID("CharGiveFlags");
	local charGiveItem = self.command:FindByID("CharGiveItem");
	local charSetName = self.command:FindByID("CharSetName");
	local plySetGroup = self.command:FindByID("PlySetGroup");
	local plyDemote = self.command:FindByID("PlyDemote");
	local charBan = self.command:FindByID("CharBan");
	local plyKick = self.command:FindByID("PlyKick");
	local plyBan = self.command:FindByID("PlyBan");

	if (charBan and self.player:HasFlags(self.Client, charBan.access)) then
		options["Ban Character"] = function()
			RunConsoleCommand("cwCmd", "CharBan", player:Name());
		end;
	end;
	
	if (plyKick and self.player:HasFlags(cwClient, plyKick.access)) then
		options["Kick Player"] = function()
			Derma_StringRequest(player:Name(), "What is your reason for kicking them?", nil, function(text)
				self.kernel:RunCommand("PlyKick", player:Name(), text);
			end);
		end;
	end;
	
	if (plyBan and self.player:HasFlags(cwClient, self.command:FindByID("PlyBan").access)) then
		options["Ban Player"] = function()
			Derma_StringRequest(player:Name(), "How many minutes would you like to ban them for?", nil, function(minutes)
				Derma_StringRequest(player:Name(), "What is your reason for banning them?", nil, function(reason)
					self.kernel:RunCommand("PlyBan", player:Name(), minutes, reason);
				end);
			end);
		end;
	end;
	
	if (charGiveFlags and self.player:HasFlags(cwClient, charGiveFlags.access)) then
		options["Give Flags"] = function()
			Derma_StringRequest(player:Name(), "What flags would you like to give them?", nil, function(text)
				self.kernel:RunCommand("CharGiveFlags", player:Name(), text);
			end);
		end;
	end;
	
	if (charTakeFlags and self.player:HasFlags(cwClient,charTakeFlags.access)) then
		options["Take Flags"] = function()
			Derma_StringRequest(player:Name(), "What flags would you like to take from them?", player:GetDTString(STRING_FLAGS), function(text)
				self.kernel:RunCommand("CharTakeFlags", player:Name(), text);
			end);
		end;
	end;
	
	if (charSetName and self.player:HasFlags(cwClient, charSetName.access)) then
		options["Set Name"] = function()
			Derma_StringRequest(player:Name(), "What would you like to set their name to?", player:Name(), function(text)
				self.kernel:RunCommand("CharSetName", player:Name(), text);
			end);
		end;
	end;
	
	if (charGiveItem and self.player:HasFlags(cwClient, charGiveItem.access)) then
		options["Give Item"] = function()
			Derma_StringRequest(player:Name(), "What item would you like to give them?", nil, function(text)
				self.kernel:RunCommand("CharGiveItem", player:Name(), text);
			end);
		end;
	end;
	
	if (plySetGroup and self.player:HasFlags(cwClient, plySetGroup.access)) then
		options["Set Group"] = {};
		options["Set Group"]["Super Admin"] = function()
			self.kernel:RunCommand("PlySetGroup", player:Name(), "superadmin");
		end;
		options["Set Group"]["Admin"] = function()
			self.kernel:RunCommand("PlySetGroup", player:Name(), "admin");
		end;
		options["Set Group"]["Operator"] = function()
			self.kernel:RunCommand("PlySetGroup", player:Name(), "operator");
		end;
	end;
	
	if (plyDemote and self.player:HasFlags(cwClient, plyDemote.access)) then
		options["Demote"] = function()
			self.kernel:RunCommand("PlyDemote", player:Name());
		end;
	end;
	
	local canUwhitelist = false;
	local canWhitelist = false;
	local unwhitelist = self.command:FindByID("PlyUnwhitelist");
	local whitelist = self.command:FindByID("PlyWhitelist");
	
	if (whitelist and self.player:HasFlags(cwClient, whitelist.access)) then
		canWhitelist = true;
	end;
	
	if (unwhitelist and self.player:HasFlags(cwClient, unwhitelist.access)) then
		canUnwhitelist = true;
	end;
	
	if (canWhitelist or canUwhitelist) then
		local areWhitelistFactions = false;
		
		for k, v in pairs(self.faction:GetAll()) do
			if (v.whitelist) then
				areWhitelistFactions = true;
			end;
		end;
		
		if (areWhitelistFactions) then
			if (canWhitelist) then
				options["Whitelist"] = {}; 
			end;
			
			if (canUwhitelist) then
				options["Unwhitelist"] = {};
			end;
			
			for k, v in pairs(self.faction:GetAll()) do
				if (v.whitelist) then
					if (options["Whitelist"]) then
						options["Whitelist"][k] = function()
							self.kernel:RunCommand("PlyWhitelist", player:Name(), k);
						end;
					end;
					
					if (options["Unwhitelist"]) then
						options["Unwhitelist"][k] = function()
							self.kernel:RunCommand("PlyUnwhitelist", player:Name(), k);
						end;
					end;
				end;
			end;
		end;
	end;
end;

-- Called when information about a door is needed.
function CW:GetDoorInfo(door, information)
	local doorCost = self.config:Get("door_cost"):Get();
	local owner = self.entity:GetOwner(door);
	local text = self.entity:GetDoorText(door);
	local name = self.entity:GetDoorName(door);
	
	if (information == DOOR_INFO_NAME) then
		if (self.entity:IsDoorHidden(door)
		or self.entity:IsDoorFalse(door)) then
			return false;
		elseif (name == "") then
			return "Door";
		else
			return name;
		end;
	elseif (information == DOOR_INFO_TEXT) then
		if (self.entity:IsDoorUnownable(door)) then
			if (!self.entity:IsDoorHidden(door)
			and !self.entity:IsDoorFalse(door)) then
				if (text == "") then
					return "This door is unownable.";
				else
					return text;
				end;
			else
				return false;
			end;
		elseif (text != "") then
			if (!IsValid(owner)) then
				if (doorCost > 0) then
					return "This door can be purchased.";
				else
					return "This door can be owned.";
				end;
			else
				return text;
			end;
		elseif (IsValid(owner)) then
			if (doorCost > 0) then
				return "This door has been purchased.";
			else
				return "This door has been owned.";
			end;
		elseif (doorCost > 0) then
			return "This door can be purchased.";
		else
			return "This door can be owned.";
		end;
	end;
end;

-- Called to get whether or not a post process is permitted.
function CW:PostProcessPermitted(class)
	return false;
end;

-- Called just after the translucent renderables have been drawn.
function CW:PostDrawTranslucentRenderables(bDrawingDepth, bDrawingSkybox)
	if (bDrawingSkybox or bDrawingDepth) then return; end;
	
	local colorWhite = self.option:GetColor("white");
	local colorInfo = self.option:GetColor("information");
	local doorFont = self.option:GetFont("large_3d_2d");
	local eyeAngles = EyeAngles();
	local eyePos = EyePos();
	
	if (!self.kernel:IsChoosingCharacter()) then
		cam.Start3D(eyePos, eyeAngles);
			local entities = ents.FindInSphere(eyePos, 256);
			
			for k, v in pairs(entities) do
				if (IsValid(v) and self.entity:IsDoor(v)) then
					self.kernel:DrawDoorText(v, eyePos, eyeAngles, doorFont, colorInfo, colorWhite);
				end;
			end;
		cam.End3D();
	end;
end;

-- Called when screen space effects should be rendered.
function CW:RenderScreenspaceEffects()
	if (IsValid(cwClient)) then
		local frameTime = FrameTime();
		local motionBlurs = {
			enabled = true,
			blurTable = {}
		};
		local color = 1;
		local isDrunk = self.player:GetDrunk();
		
		if (!self.kernel:IsChoosingCharacter()) then
			if (self.limb:IsActive() and self.event:CanRun("blur", "limb_damage")) then
				local headDamage = self.limb:GetDamage(HITGROUP_HEAD);
				motionBlurs.blurTable["health"] = math.Clamp(1 - (headDamage * 0.01), 0, 1);
			elseif (cwClient:Health() <= 75) then
				if (self.event:CanRun("blur", "health")) then
					motionBlurs.blurTable["health"] = math.Clamp(
						1 - ((cwClient:GetMaxHealth() - cwClient:Health()) * 0.01), 0, 1
					);
				end;
			end;
			
			if (cwClient:Alive()) then
				color = math.Clamp(color - ((cwClient:GetMaxHealth() - cwClient:Health()) * 0.01), 0, color);
			else
				color = 0;
			end;
			
			if (self.event:CanRun("blur", "isDrunk")) then
				if (isDrunk and self.DrunkBlur) then
					self.DrunkBlur = math.Clamp(self.DrunkBlur - (frameTime / 10), math.max(1 - (isDrunk / 8), 0.1), 1);					
					DrawMotionBlur(self.DrunkBlur, 1, 0);
				elseif (self.DrunkBlur and self.DrunkBlur < 1) then
					self.DrunkBlur = math.Clamp(self.DrunkBlur + (frameTime / 10), 0.1, 1);
					motionBlurs.blurTable["isDrunk"] = self.DrunkBlur;
				else
					self.DrunkBlur = 1;
				end;
			end;
		end;
		
		if (self.FishEyeTexture and cwClient:WaterLevel() > 2) then
			render.UpdateScreenEffectTexture();
				self.FishEyeTexture:SetFloat("$envmap", 0);
				self.FishEyeTexture:SetFloat("$envmaptint",	0);
				self.FishEyeTexture:SetFloat("$refractamount", 0.1);
				self.FishEyeTexture:SetInt("$ignorez", 1);
			render.SetMaterial(self.FishEyeTexture);
			render.DrawScreenQuad();
		end;
		
		self.ColorModify["$pp_colour_brightness"] = 0;
		self.ColorModify["$pp_colour_contrast"] = 1;
		self.ColorModify["$pp_colour_colour"] = color;
		self.ColorModify["$pp_colour_addr"] = 0;
		self.ColorModify["$pp_colour_addg"] = 0;
		self.ColorModify["$pp_colour_addb"] = 0;
		self.ColorModify["$pp_colour_mulr"] = 0;
		self.ColorModify["$pp_colour_mulg"] = 0;
		self.ColorModify["$pp_colour_mulb"] = 0;
		
		local systemTable = self.system:FindByID("Color Modify")
		local overrideColorMod = systemTable:GetModifyTable();

		if (overrideColorMod and overrideColorMod.enabled) then
			self.ColorModify["$pp_colour_brightness"] = overrideColorMod.brightness;
			self.ColorModify["$pp_colour_contrast"] = overrideColorMod.contrast;
			self.ColorModify["$pp_colour_colour"] = overrideColorMod.color;
			self.ColorModify["$pp_colour_addr"] = overrideColorMod.addr * 0.025;
			self.ColorModify["$pp_colour_addg"] = overrideColorMod.addg * 0.025;
			self.ColorModify["$pp_colour_addb"] = overrideColorMod.addg * 0.025;
			self.ColorModify["$pp_colour_mulr"] = overrideColorMod.mulr * 0.1;
			self.ColorModify["$pp_colour_mulg"] = overrideColorMod.mulg * 0.1;
			self.ColorModify["$pp_colour_mulb"] = overrideColorMod.mulb * 0.1;
		else
			plugin.Call("PlayerSetDefaultColorModify", self.ColorModify);
		end;
		
		plugin.Call("PlayerAdjustColorModify", self.ColorModify);
		plugin.Call("PlayerAdjustMotionBlurs", motionBlurs);
		
		if (motionBlurs.enabled) then
			local addAlpha = nil;
			
			for k, v in pairs(motionBlurs.blurTable) do
				if (!addAlpha or v < addAlpha) then
					addAlpha = v;
				end;
			end;
			
			if (addAlpha) then
				DrawMotionBlur(math.Clamp(addAlpha, 0.1, 1), 1, 0);
			end;
		end;
		
		--[[
			Hotfix for ColorModify issues on OS X.
		--]]
		if (system.IsOSX()) then
			self.ColorModify["$pp_colour_brightness"] = 0;
			self.ColorModify["$pp_colour_contrast"] = 1;
		end;
		
		DrawColorModify(self.ColorModify);
	end;
end;

-- Called when the chat box is opened.
function CW:ChatBoxOpened() end;

-- Called when the chat box is closed.
function CW:ChatBoxClosed(textTyped) end;

-- Called when the chat box text has been typed.
function CW:ChatBoxTextTyped(text)
	if (self.LastChatBoxText) then
		if (self.LastChatBoxText[1] == text) then
			return;
		end;
		
		if (#self.LastChatBoxText >= 25) then
			table.remove(self.LastChatBoxText, 25);
		end;
	else
		self.LastChatBoxText = {};
	end;
	
	table.insert(self.LastChatBoxText, 1, text);
end;

-- Called when the calc view table should be adjusted.
function CW:CalcViewAdjustTable(view) end;

-- Called when the chat box info should be adjusted.
function CW:ChatBoxAdjustInfo(info) end;

-- Called when the chat box text has changed.
function CW:ChatBoxTextChanged(previousText, newText) end;

-- Called when the chat box has had a key code typed in.
function CW:ChatBoxKeyCodeTyped(code, text)
	if (code == KEY_UP) then
		if (self.LastChatBoxText) then
			for k, v in pairs(self.LastChatBoxText) do
				if (v == text and self.LastChatBoxText[k + 1]) then
					return self.LastChatBoxText[k + 1];
				end;
			end;
			
			if (self.LastChatBoxText[1]) then
				return self.LastChatBoxText[1];
			end;
		end;
	elseif (code == KEY_DOWN) then
		if (self.LastChatBoxText) then
			for k, v in pairs(self.LastChatBoxText) do
				if (v == text and self.LastChatBoxText[k - 1]) then
					return self.LastChatBoxText[k - 1];
				end;
			end;
			
			if (#self.LastChatBoxText > 0) then
				return self.LastChatBoxText[#self.LastChatBoxText];
			end;
		end;
	end;
end;

-- Called when a notification should be adjusted.
function CW:NotificationAdjustInfo(info)
	return true;
end;

-- Called when the local player's business item should be adjusted.
function CW:PlayerAdjustBusinessItemTable(itemTable) end;

-- Called when the local player's class model info should be adjusted.
function CW:PlayerAdjustClassModelInfo(class, info) end;

-- Called when the local player's headbob info should be adjusted.
function CW:PlayerAdjustHeadbobInfo(info)
	local bisDrunk = self.player:GetDrunk();
	local scale;
	
	if (CW_CONVAR_HEADBOBSCALE) then
		scale = math.Clamp(CW_CONVAR_HEADBOBSCALE:GetFloat(),0,1) or 1;
	else
		scale = 1;
	end;
	
	if (cwClient:IsRunning()) then
		info.speed = (info.speed * 4) * scale;
		info.roll = (info.roll * 2) * scale;
	elseif (cwClient:IsJogging()) then
		info.speed = (info.speed * 4) * scale;
		info.roll = (info.roll * 1.5) * scale;
	elseif (cwClient:GetVelocity():Length() > 0) then
		info.speed = (info.speed * 3) * scale;
		info.roll = (info.roll * 1) * scale;
	else
		info.roll = info.roll * scale;
	end;
	
	if (isDrunk) then
		info.speed = info.speed * math.min(isDrunk * 0.25, 4);
		info.yaw = info.yaw * math.min(isDrunk, 4);
	end;
end;

-- Called when the local player's motion blurs should be adjusted.
function CW:PlayerAdjustMotionBlurs(motionBlurs) end;

-- Called when the local player's item menu should be adjusted.
function CW:PlayerAdjustMenuFunctions(itemTable, menuPanel, itemFunctions) end;

-- Called when the local player's item functions should be adjusted.
function CW:PlayerAdjustItemFunctions(itemTable, itemFunctions) end;

-- Called when the local player's default colorify should be set.
function CW:PlayerSetDefaultColorModify(colorModify) end;

-- Called when the local player's colorify should be adjusted.
function CW:PlayerAdjustColorModify(colorModify) end;

-- Called to get whether a player's target ID should be drawn.
function CW:ShouldDrawPlayerTargetID(player)
	return true;
end;

-- Called to get whether the local player's screen should fade black.
function CW:ShouldPlayerScreenFadeBlack()
	if (!cwClient:Alive() or cwClient:IsRagdolled(RAGDOLL_FALLENOVER)) then
		if (!plugin.Call("PlayerCanSeeUnconscious")) then
			return true;
		end;
	end;
	
	return false;
end;

-- Called when the menu background blur should be drawn.
function CW:ShouldDrawMenuBackgroundBlur()
	return true;
end;

-- Called when the character background blur should be drawn.
function CW:ShouldDrawCharacterBackgroundBlur()
	return true;
end;

-- Called when the character background should be drawn.
function CW:ShouldDrawCharacterBackground()
	return true;
end;

-- Called when the character fault should be drawn.
function CW:ShouldDrawCharacterFault(fault)
	return true;
end;

-- Called when the score board should be drawn.
function CW:HUDDrawScoreBoard()
	self.BaseClass:HUDDrawScoreBoard(player);
	
	local drawPendingScreenBlack = nil;
	local drawCharacterLoading = nil;
	local hasClientInitialized = cwClient:HasInitialized();
	local introTextSmallFont = self.option:GetFont("intro_text_small");
	local colorWhite = self.option:GetColor("white");
	local curTime = UnPredictedCurTime();
	local scrH = ScrH();
	local scrW = ScrW();
	
	if (self.kernel:IsChoosingCharacter()) then
		if (plugin.Call("ShouldDrawCharacterBackground")) then
			self.kernel:DrawSimpleGradientBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, 255));
		end;
		
		plugin.Call("HUDPaintCharacterSelection");
	elseif (!hasClientInitialized) then
		if (!self.HasCharacterMenuBeenVisible
		and plugin.Call("ShouldDrawCharacterBackground")) then
			drawPendingScreenBlack = true;
		end;
	end;
	
	if (hasClientInitialized) then
		if (!self.CharacterLoadingFinishTime) then
			local loadingTime = plugin.Call("GetCharacterLoadingTime");
			self.CharacterLoadingDelay = loadingTime;
			self.CharacterLoadingFinishTime = curTime + loadingTime;
		end;
		
		if (!self.kernel:IsChoosingCharacter()) then
			self.kernel:CalculateScreenFading();
			
			if (!self.kernel:IsUsingCamera()) then
				plugin.Call("HUDPaintForeground");
			end;
			
			plugin.Call("HUDPaintImportant");
		end;
		
		if (self.CharacterLoadingFinishTime > curTime) then
			drawCharacterLoading = true;
		elseif (!self.CinematicScreenDone) then
			self.kernel:DrawCinematicIntro(curTime);
			self.kernel:DrawCinematicIntroBars();
		end;
	end;
	
	if (plugin.Call("ShouldDrawBackgroundBlurs")) then
		self.kernel:DrawBackgroundBlurs();
	end;

	if (!self.player:HasDataStreamed()) then
		if (!self.DataStreamedAlpha) then
			self.DataStreamedAlpha = 255;
		end;
	elseif (self.DataStreamedAlpha) then
		self.DataStreamedAlpha = math.Approach(self.DataStreamedAlpha, 0, FrameTime() * 100);
		
		if (self.DataStreamedAlpha <= 0) then
			self.DataStreamedAlpha = nil;
		end;
	end;
	
	if (self.ClockworkIntroFadeOut) then
		local duration = 8;
		local introImage = self.option:GetKey("intro_image");
		
		if (introImage != "") then
			duration = 16;
		end;
		
		local timeLeft = math.Clamp(self.ClockworkIntroFadeOut - curTime, 0, duration);
		local material = self.ClockworkIntroOverrideImage or self.ClockworkSplash;
		local sineWave = math.sin(curTime);
		local height = 256;
		local width = 512; --Patched
		local alpha = 384;
		
		if (!self.ClockworkIntroOverrideImage) then
			if (introImage != "" and timeLeft <= 8) then
				self.ClockworkIntroWhiteScreen = curTime + (FrameTime() * 8);
				self.ClockworkIntroOverrideImage = self.kernel:GetMaterial(introImage..".png");
				surface.PlaySound("buttons/combine_button5.wav");
			end;
		end;

		if (timeLeft <= 3) then
			alpha = (255 / 3) * timeLeft;
		end;

		if (timeLeft == 0) then
			self.ClockworkIntroFadeOut = nil;
			self.ClockworkIntroOverrideImage = nil;
		end;

		if (sineWave > 0) then
			width = width - (sineWave * 16);
			height = height - (sineWave * 4);
		end;

		if (curTime <= self.ClockworkIntroWhiteScreen) then
			self.kernel:DrawSimpleGradientBox(0, 0, 0, scrW, scrH, Color(255, 255, 255, alpha));
		else
			local x, y = (scrW / 2) - (width / 2), (scrH * 0.3) - (height / 2);

			self.kernel:DrawSimpleGradientBox(0, 0, 0, scrW, scrH, Color(0, 0, 0, alpha));
			self.kernel:DrawGradient(
				GRADIENT_CENTER, 0, y - 8, scrW, height + 16, Color(100, 100, 100, math.min(alpha, 150))
			);

			material:SetFloat("$alpha", alpha / 255);

			surface.SetDrawColor(255, 255, 255, alpha);
				surface.SetMaterial(material);
			surface.DrawTexturedRect(x, y, width, height);
		end;
		
		drawPendingScreenBlack = nil;
	end;
	
	if (self.kernel:GetSharedVar("NoMySQL") and self.kernel:GetSharedVar("NoMySQL") != "") then
		self.kernel:DrawSimpleGradientBox(0, 0, 0, scrW, scrH, Color(0, 0, 0, 255));
		draw.SimpleText(self.kernel:GetSharedVar("NoMySQL"), introTextSmallFont, scrW / 2, scrH / 2, Color(179, 46, 49, 255), 1, 1);
	elseif (self.DataStreamedAlpha and self.DataStreamedAlpha > 0) then
		local textString = "LOADING...";
		
		self.kernel:DrawSimpleGradientBox(0, 0, 0, scrW, scrH, Color(0, 0, 0, self.DataStreamedAlpha));
		draw.SimpleText(textString, introTextSmallFont, scrW / 2, scrH * 0.75, Color(colorWhite.r, colorWhite.g, colorWhite.b, self.DataStreamedAlpha), 1, 1);
		
		drawPendingScreenBlack = nil;
	end;
	
	if (drawCharacterLoading) then
		plugin.Call("HUDPaintCharacterLoading", math.Clamp((255 / self.CharacterLoadingDelay) * (self.CharacterLoadingFinishTime - curTime), 0, 255));
	elseif (drawPendingScreenBlack) then
		self.kernel:DrawSimpleGradientBox(0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, 255));
	end;
	
	if (self.CharacterLoadingFinishTime) then
		if (!self.CinematicInfoDrawn) then
			self.kernel:DrawCinematicInfo();
		end;
		
		if (!self.CinematicBarsDrawn) then
			self.kernel:DrawCinematicIntroBars();
		end;
	end;
	
	plugin.Call("PostDrawBackgroundBlurs");
end;

-- Called when the background blurs should be drawn.
function CW:ShouldDrawBackgroundBlurs()
	return true;
end;

-- Called just after the background blurs have been drawn.
function CW:PostDrawBackgroundBlurs()
	local introTextSmallFont = self.option:GetFont("intro_text_small");	
	local backgroundColor = self.option:GetColor("background");
	local colorWhite = self.option:GetColor("white");
	local panelInfo = self.CurrentFactionSelected;
	local menuPanel = self.kernel:GetRecogniseMenu();
	
	if (panelInfo and IsValid(panelInfo[1]) and panelInfo[1]:IsVisible()) then
		local factionTable = self.faction:FindByID(panelInfo[2]);
		
		if (factionTable and factionTable.material) then
			if (_file:Exists("materials/"..factionTable.material..".png", "GAME")) then
				if (!panelInfo[3]) then
					panelInfo[3] = self.kernel:GetMaterial(factionTable.material..".png");
				end;
				
				if (self.kernel:IsCharacterScreenOpen(true)) then
					surface.SetDrawColor(255, 255, 255, panelInfo[1]:GetAlpha());
					surface.SetMaterial(panelInfo[3]);
					surface.DrawTexturedRect(panelInfo[1].x, panelInfo[1].y + panelInfo[1]:GetTall() + 16, 512, 256);
				end;
			end;
		end;
	end;
	
	if (self.TitledMenu and IsValid(self.TitledMenu.menuPanel)) then
		local menuTextTiny = self.option:GetFont("menu_text_tiny");
		local menuPanel = self.TitledMenu.menuPanel;
		local menuTitle = self.TitledMenu.title;
		
		self.kernel:DrawSimpleGradientBox(2, menuPanel.x - 4, menuPanel.y - 4, menuPanel:GetWide() + 8, menuPanel:GetTall() + 8, backgroundColor);
		self.kernel:OverrideMainFont(menuTextTiny);
			self.kernel:DrawInfo(menuTitle, menuPanel.x, menuPanel.y, colorWhite, 255, true, function(x, y, width, height)
				return x, y - height - 4;
			end);
		self.kernel:OverrideMainFont(false);
	end;
	
	self.kernel:DrawDateTime();
end;

-- Called just before a bar is drawn.
function CW:PreDrawBar(barInfo) end;

-- Called just after a bar is drawn.
function CW:PostDrawBar(barInfo) end;

-- Called when the top bars are needed.
function CW:GetBars(bars) end;

-- Called when the top bars should be destroyed.
function CW:DestroyBars(bars) end;

-- Called when the cinematic intro info is needed.
function CW:GetCinematicIntroInfo()
	return {
		credits = "A roleplaying game designed by "..Schema:GetAuthor()..".",
		title = Schema:GetName(),
		text = Schema:GetDescription()
	};
end;

-- Called when the character loading time is needed.
function CW:GetCharacterLoadingTime() return 8; end;

-- Called when a player's HUD should be painted.
function CW:HUDPaintPlayer(player) end;

-- Called when the HUD should be painted.
function CW:HUDPaint()
	if (!self.kernel:IsChoosingCharacter() and !self.kernel:IsUsingCamera()) then
		if (self.event:CanRun("view", "damage") and self.Client:Alive()) then
			local maxHealth = self.Client:GetMaxHealth();
			local health = self.Client:Health();

			if (health < maxHealth) then
				plugin.Call("DrawPlayerScreenDamage", 1 - ((1 / maxHealth) * health));
			end;
		end;
		
		if (self.event:CanRun("view", "vignette") and self.config:Get("enable_vignette"):Get() and CW_CONVAR_VIGNETTE:GetInt() == 1) then
			plugin.Call("DrawPlayerVignette");
		end;
		
		local weapon = cwClient:GetActiveWeapon();
		self.BaseClass:HUDPaint();
		
		if (!self.kernel:IsScreenFadedBlack()) then
			for k, v in pairs(_player.GetAll()) do
				if (v:HasInitialized() and v != cwClient) then
					plugin.Call("HUDPaintPlayer", v);
				end;
			end;
		end;
		
		if (!self.kernel:IsUsingTool()) then
			self.kernel:DrawHints();
		end;
		
	--	if ((self.config:Get("enable_crosshair"):Get() or self.kernel:IsDefaultWeapon(weapon))
	--	and (IsValid(weapon) and weapon.DrawCrosshair != false)) then
		if (plugin.Call("CanDrawCrosshair", weapon)) then
			local info = {
				color = Color(255, 255, 255, 255),
				x = ScrW() / 2,
				y = ScrH() / 2
			};
			
			plugin.Call("GetPlayerCrosshairInfo", info);
			self.CustomCrosshair = plugin.Call("DrawPlayerCrosshair", info.x, info.y, info.color);
		else
			self.CustomCrosshair = false;
		end;
	end;
end;

function CW:CanDrawCrosshair(weapon)
	return (self.config:Get("enable_crosshair"):Get() or self.kernel:IsDefaultWeapon(weapon)) 
	and (IsValid(weapon) and weapon.DrawCrosshair != false);
end;

-- Called when the local player's crosshair info is needed.
function CW:GetPlayerCrosshairInfo(info)
	if (self.config:Get("use_free_aiming"):Get()) then
		-- Thanks to BlackOps7799 for this open source example.
		
		local traceLine = util.TraceLine({
			start = cwClient:EyePos(),
			endpos = cwClient:EyePos() + (cwClient:GetAimVector() * 1024 * 1024),
			filter = cwClient
		});
		
		local screenPos = traceLine.HitPos:ToScreen();
		
		info.x = screenPos.x;
		info.y = screenPos.y;
	end;
end;

-- Called when the local player's crosshair should be drawn.
function CW:DrawPlayerCrosshair(x, y, color)
	surface.SetDrawColor(color.r, color.g, color.b, color.a);
	surface.DrawRect(x, y, 2, 2);
	surface.DrawRect(x, y + 9, 2, 2);
	surface.DrawRect(x, y - 9, 2, 2);
	surface.DrawRect(x + 9, y, 2, 2);
	surface.DrawRect(x - 9, y, 2, 2);

	return true;
end;

-- Called when a player starts using voice.
function CW:PlayerStartVoice(player)
	if (self.config:Get("local_voice"):Get()) then
		if (player:IsRagdolled(RAGDOLL_FALLENOVER) or !player:Alive()) then
			return;
		end;
	end;
	
	if (self.BaseClass and self.BaseClass.PlayerStartVoice) then
		self.BaseClass:PlayerStartVoice(player);
	end;
end;

-- Called to check if a player does have an flag.
function CW:PlayerDoesHaveFlag(player, flag)
	if (string.find(self.config:Get("default_flags"):Get(), flag)) then
		return true;
	end;
end;

-- Called to check if a player does recognise another player.
function CW:PlayerDoesRecognisePlayer(player, status, isAccurate, realValue)
	return realValue;
end;

-- Called when a player's name should be shown as unrecognised.
function CW:PlayerCanShowUnrecognised(player, x, y, color, alpha, flashAlpha)
	return true;
end;

-- Called when the target player's name is needed.
function CW:GetTargetPlayerName(player)
	return player:Name();
end;

-- Called when a player begins typing.
function CW:StartChat(team)
	return true;
end;

-- Called when a player says something.
function CW:OnPlayerChat(player, text, teamOnly, playerIsDead)
	if (!IsValid(player)) then
		chatbox.AddText(nil, "[color=red]Console[/color]: "..text, {icon = "icon16/shield.png"});
	end;
	
	return true;
end;

-- Called when chat text is received from the server
function CW:ChatText(index, name, text, class)
	return true;
end;

-- Called when the scoreboard should be created.
function CW:CreateScoreboard() end;

-- Called when the scoreboard should be shown.
function CW:ScoreboardShow()
	if (cwClient:HasInitialized()) then
		if (plugin.Call("CanShowTabMenu")) then
			self.menu:Create();
			self.menu:SetOpen(true);
			self.menu.holdTime = UnPredictedCurTime() + 0.5;
		end;
	end;
end;

-- Called when the scoreboard should be hidden.
function CW:ScoreboardHide()
	if (cwClient:HasInitialized() and self.menu.holdTime) then
		if (UnPredictedCurTime() >= self.menu.holdTime) then
			if (plugin.Call("CanShowTabMenu")) then
				self.menu:SetOpen(false);
			end;
		end;
	end;
end;

-- Called before the tab menu is shown.
function CW:CanShowTabMenu() return true; end;

-- Overriding Garry's "grab ear" animation.
function CW:GrabEarAnimation(player) end;

-- Called before the item entity's target ID is drawn. Return false to stop default draw.
function CW:PaintItemTargetID(x, y, alpha, itemTable) return true; end;

concommand.Add("cwSay", function(player, command, arguments)
	return netstream.Start("PlayerSay", table.concat(arguments, " "));
end);

concommand.Add("cwLua", function(player, command, arguments)
	if (player:IsSuperAdmin()) then
		RunString(table.concat(arguments, " "));
		return;
	end;
	
	print("You do not have access to this command, "..player:Name()..".");
end);

local entityMeta = FindMetaTable("Entity");
local weaponMeta = FindMetaTable("Weapon");
local playerMeta = FindMetaTable("Player");

entityMeta.ClockworkFireBullets = entityMeta.ClockworkFireBullets or entityMeta.FireBullets;
weaponMeta.OldGetPrintName = weaponMeta.OldGetPrintName or weaponMeta.GetPrintName;
playerMeta.SteamName = playerMeta.SteamName or playerMeta.Name;

-- A function to make a player fire bullets.
function entityMeta:FireBullets(bulletInfo)
	if (self:IsPlayer()) then
		plugin.Call("PlayerAdjustBulletInfo", self, bulletInfo);
	end;
	
	plugin.Call("EntityFireBullets", self, bulletInfo);
	return self:ClockworkFireBullets(bulletInfo);
end;

-- A function to get a weapon's print name.
function weaponMeta:GetPrintName()
	local itemTable = CW.item:GetByWeapon(self);
	
	if (itemTable) then
		return itemTable("name");
	else
		return self:OldGetPrintName();
	end;
end;

-- A function to get a player's name.
function playerMeta:Name()
	local name = self:GetDTString(STRING_NAME);
	
	if (!name or name == "") then
		return self:SteamName();
	else
		return name;
	end;
end;

-- A function to get a player's playback rate.
function playerMeta:GetPlaybackRate()
	return self.cwPlaybackRate or 1;
end;

-- A function to get whether a player is noclipping.
function playerMeta:IsNoClipping()
	return CW.player:IsNoClipping(self);
end;

-- A function to get whether a player is running.
function playerMeta:IsRunning(bNoWalkSpeed)
	if (self:Alive() and !self:IsRagdolled() and !self:InVehicle() and !self:Crouching()
	and self:GetDTBool(BOOL_ISRUNNING)) then
		if (self:GetVelocity():Length() >= self:GetWalkSpeed()
		or bNoWalkSpeed) then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to get whether a player is jogging.
function playerMeta:IsJogging(bTestSpeed)
	if (!self:IsRunning() and (self:GetDTBool(BOOL_ISJOGGING) or bTestSpeed)) then
		if (self:Alive() and !self:IsRagdolled() and !self:InVehicle() and !self:Crouching()) then
			if (self:GetVelocity():Length() > 0) then
				return true;
			end;
		end;
	end;
	
	return false;
end;

-- A function to get a player's forced animation.
function playerMeta:GetForcedAnimation()
	local forcedAnimation = self:GetSharedVar("ForceAnim");
	
	if (forcedAnimation != 0) then
		return {
			animation = forcedAnimation,
		};
	end;
end;

-- A function to get whether a player is ragdolled.
function playerMeta:IsRagdolled(exception, entityless)
	return CW.player:IsRagdolled(self, exception, entityless);
end;

-- A function to set a shared variable for a player.
function playerMeta:SetSharedVar(key, value)
	CW.player:SetSharedVar(self, key, value);
end;

-- A function to get a player's shared variable.
function playerMeta:GetSharedVar(key, sharedTable)
	return CW.player:GetSharedVar(self, key, sharedTable);
end;

-- A function to get whether a player has initialized.
function playerMeta:HasInitialized()
	if (IsValid(self)) then
		return self:GetSharedVar("Initialized");
	end;
end;

-- A function to get a player's gender.
function playerMeta:GetGender()
	if (self:GetSharedVar("Gender") == nil) then return GENDER_MALE; end;
	
	if (self:GetSharedVar("Gender") == 1) then
		return GENDER_FEMALE;
	else
		return GENDER_MALE;
	end;
end;

-- A function to get a player's faction.
function playerMeta:GetFaction()
	local index = self:GetSharedVar("Faction");
	
	if (CW.faction:FindByID(index)) then
		return CW.faction:FindByID(index).name;
	else
		return "Unknown";
	end;
end;

-- A function to get a player's wages name.
function playerMeta:GetWagesName()
	return CW.player:GetWagesName(self);
end;

-- A function to get a player's data.
function playerMeta:GetData(key, default)
	local playerData = CW.player.playerData[key];
	
	if (playerData and (!playerData.playerOnly
	or self == cwClient)) then
		return self:GetSharedVar(key);
	end;
	
	return default;
end;

-- A function to get a player's character data.
function playerMeta:GetCharacterData(key, default)
	local characterData = CW.player.characterData[key];
	
	if (characterData and (!characterData.playerOnly
	or self == cwClient)) then
		return self:GetSharedVar(key);
	end;
	
	return default;
end;

-- A function to get a player's maximum armor.
function playerMeta:GetMaxArmor(armor)
	local maxArmor = self:GetSharedVar("MaxAP") or 100;
	
	if (maxArmor > 0) then
		return maxArmor;
	else
		return 100;
	end;
end;

-- A function to get a player's maximum health.
function playerMeta:GetMaxHealth(health)
	local maxHealth = self:GetSharedVar("MaxHP") or 100;
	
	if (maxHealth > 0) then
		return maxHealth;
	else
		return 100;
	end;
end;

-- A function to get a player's ragdoll state.
function playerMeta:GetRagdollState()
	return CW.player:GetRagdollState(self);
end;

-- A function to get a player's ragdoll entity.
function playerMeta:GetRagdollEntity()
	return CW.player:GetRagdollEntity(self);
end;

-- A function to get a player's rank within their faction.
function playerMeta:GetFactionRank(character)
	return CW.player:GetFactionRank(self, character);
end;

-- A function to get a player's chat icon.
function playerMeta:GetChatIcon()
	return CW.player:GetChatIcon(self);
end;

playerMeta.GetName = playerMeta.Name;
playerMeta.Nick = playerMeta.Name;