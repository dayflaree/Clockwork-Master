--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[ 
	Include vON, pON and UTF-8 library 
--]]
if (!von or !string.utf8len or !pon) then
	include("external/utf8.lua");
	
	-- vON is deprecated. It is to be removed in 0.98.
	include("external/von.lua");
	include("external/pon.lua");
end;

--[[
	Include the shared Lua table and
	the Clockwork kernel.
--]]
include("cw.lua");
include("catwork/framework/cl_kernel.lua");

_G["ClockworkClientsideBooted"] = true;
_G["cwSharedBooted"] = true;