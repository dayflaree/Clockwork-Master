--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.option = CW.kernel:NewLibrary("Option");
CW.option.keys = CW.option.keys or {};
CW.option.sounds = CW.option.sounds or {};

-- A function to set a schema key.
function CW.option:SetKey(key, value)
	self.keys[key] = value;
end;

-- A function to get a schema key.
function CW.option:GetKey(key, lowerValue)
	local value = self.keys[key];
	
	if (lowerValue and type(value) == "string") then
		return string.lower(value);
	else
		return value;
	end;
end;

-- A function to set a schema sound.
function CW.option:SetSound(name, sound)
	self.sounds[name] = sound;
end;

-- A function to get a schema sound.
function CW.option:GetSound(name)
	return self.sounds[name];
end;

-- A function to play a schema sound.
function CW.option:PlaySound(name)
	local sound = self:GetSound(name);
	
	if (sound) then
		if (CLIENT) then
			surface.PlaySound(sound);
		else
			CW.player:PlaySound(nil, sound);
		end;
	end;
end;

CW.option:SetKey("default_date", {month = 1, year = 2010, day = 1});
CW.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});
CW.option:SetKey("default_days", {"#Monday", "#Tuesday", "#Wednesday", "#Thursday", "#Friday", "#Saturday", "#Sunday"});
CW.option:SetKey("description_business", "#BusinessDesc");
CW.option:SetKey("description_inventory", "#InventoryDesc");
CW.option:SetKey("description_directory", "#DirectoryDesc");
CW.option:SetKey("description_system", "#SystemDesc");
CW.option:SetKey("description_scoreboard", "#ScoreboardDesc");
CW.option:SetKey("description_attributes", "#AttributesDesc");
CW.option:SetKey("intro_background_url", "");
CW.option:SetKey("intro_logo_url", "");
CW.option:SetKey("model_shipment", "models/items/item_item_crate.mdl");
CW.option:SetKey("model_cash", "models/props_c17/briefcase001a.mdl");
CW.option:SetKey("format_singular_cash", "$%a");
CW.option:SetKey("format_cash", "$%a");
CW.option:SetKey("name_attributes", "#Attributes");
CW.option:SetKey("name_attribute", "#Attribute");
CW.option:SetKey("name_system", "#System");
CW.option:SetKey("name_scoreboard", "#Scoreboard");
CW.option:SetKey("name_directory", "#Directory");
CW.option:SetKey("name_inventory", "#Inventory");
CW.option:SetKey("name_business", "#Business");
CW.option:SetKey("name_destroy", "#Destroy");
CW.option:SetKey("schema_logo", "");
CW.option:SetKey("intro_image", "");
CW.option:SetKey("intro_sound", "music/HL2_song25_Teleporter.mp3");
CW.option:SetKey("menu_music", "music/hl2_song32.mp3");
CW.option:SetKey("name_cash", "#Cash");
CW.option:SetKey("name_drop", "#Drop");
CW.option:SetKey("top_bars", false);
CW.option:SetKey("name_use", "#Use");
CW.option:SetKey("gradient", "gui/gradient_up");

CW.option:SetSound("click_release", "ui/buttonclickrelease.wav");
CW.option:SetSound("rollover", "ui/buttonrollover.wav");
CW.option:SetSound("click", "ui/buttonclick.wav");
CW.option:SetSound("tick", "common/talk.wav");

if (CLIENT) then
	CW.option.fonts = CW.option.fonts or {};
	CW.option.colors = CW.option.colors or {};

	-- A function to set a schema color.
	function CW.option:SetColor(name, color)
		self.colors[name] = color;
	end;

	-- A function to get a schema color.
	function CW.option:GetColor(name)
		return self.colors[name];
	end;

	-- A function to set a schema font.
	function CW.option:SetFont(name, font)
		self.fonts[name] = font;
	end;

	-- A function to get a schema font.
	function CW.option:GetFont(name)
		return self.fonts[name];
	end;

	CW.option:SetColor("columnsheet_shadow_normal", Color(0, 0, 0, 255));
	CW.option:SetColor("columnsheet_text_normal", Color(255, 255, 255, 255));
	CW.option:SetColor("columnsheet_shadow_active", Color(255, 255, 255, 255));
	CW.option:SetColor("columnsheet_text_active", Color(50, 50, 50, 255));
	
	CW.option:SetColor("basic_form_highlight", Color(0, 0, 0, 255));
	CW.option:SetColor("basic_form_color", Color(0, 0, 0, 255));
	
	CW.option:SetKey("icon_data_classes", {path = "", size = nil});
	CW.option:SetKey("icon_data_settings", {path = "", size = nil});
	CW.option:SetKey("icon_data_system", {path = "", size = nil});
	CW.option:SetKey("icon_data_scoreboard", {path = "", size = nil});
	CW.option:SetKey("icon_data_inventory", {path = "", size = nil});
	CW.option:SetKey("icon_data_directory", {path = "", size = nil});
	CW.option:SetKey("icon_data_attributes", {path = "", size = nil});
	CW.option:SetKey("icon_data_business", {path = "", size = nil});
	
	CW.option:SetKey("top_bar_width_scale", 0.3);
	
	CW.option:SetKey("info_text_icon_size", 16);
	CW.option:SetKey("info_text_red_icon", "icon16/exclamation.png");
	CW.option:SetKey("info_text_green_icon", "icon16/tick.png");
	CW.option:SetKey("info_text_orange_icon", "icon16/error.png");
	CW.option:SetKey("info_text_blue_icon", "icon16/information.png");
	
	CW.option:SetColor("scoreboard_name", Color(0, 0, 0, 255));
	CW.option:SetColor("scoreboard_desc", Color(0, 0, 0, 255));
	
	CW.option:SetColor("positive_hint", Color(100, 175, 100, 255));
	CW.option:SetColor("negative_hint", Color(175, 100, 100, 255));
	CW.option:SetColor("background", Color(0, 0, 0, 125));
	CW.option:SetColor("foreground", Color(50, 50, 50, 125));
	CW.option:SetColor("target_id", Color(50, 75, 100, 255));
	CW.option:SetColor("white", Color(255, 255, 255, 255));
	
	CW.option:SetColor("panel_primarycolor", Color(45, 45, 45, 255));
	CW.option:SetColor("panel_primarycolor_blur", Color(45, 45, 45, 160));
	CW.option:SetColor("panel_secondarycolor", Color(255, 108, 34, 255));
	CW.option:SetColor("panel_primarylight", Color(60, 60, 60, 255));
	CW.option:SetColor("panel_primarylighter", Color(70, 70, 70, 255));
	CW.option:SetColor("panel_primarylightest", Color(90, 90, 90, 255));
	CW.option:SetColor("panel_primarydark", Color(39, 39, 39, 255));
	CW.option:SetColor("panel_primarydarker", Color(22, 22, 22, 255));
	CW.option:SetColor("panel_primarydarkest", Color(8, 8, 8, 255));
	CW.option:SetColor("panel_textcolor", Color(240, 240, 240, 255));

	CW.option:SetFont("schema_description", "cwMainText");
	CW.option:SetFont("scoreboard_desc", "cwScoreboardDesc");
	CW.option:SetFont("scoreboard_name", "cwScoreboardName");
	CW.option:SetFont("player_info_text", "cwMainText");
	CW.option:SetFont("intro_text_small", "cwIntroTextSmall");
	CW.option:SetFont("intro_text_tiny", "cwIntroTextTiny");
	CW.option:SetFont("menu_text_small", "CW.menuTextSmall");
	CW.option:SetFont("chat_box_syntax", "cwChatSyntax");
	CW.option:SetFont("menu_text_huge", "CW.menuTextHuge");
	CW.option:SetFont("intro_text_big", "cwIntroTextBig");
	CW.option:SetFont("info_text_font", "cwInfoTextFont");
	CW.option:SetFont("menu_text_tiny", "CW.menuTextTiny");
	CW.option:SetFont("date_time_text", "CW.menuTextSmall");
	CW.option:SetFont("cinematic_text", "cwCinematicText");
	CW.option:SetFont("target_id_text", "cwMainText");
	CW.option:SetFont("auto_bar_text", "cwMainText");
	CW.option:SetFont("menu_text_big", "CW.menuTextBig");
	CW.option:SetFont("chat_box_text", "cwMainText");
	CW.option:SetFont("large_3d_2d", "cwLarge3D2D");
	CW.option:SetFont("hints_text", "cwIntroTextTiny");
	CW.option:SetFont("main_text", "cwMainText");
	CW.option:SetFont("bar_text", "cwMainText");
	CW.option:SetFont("esp_text", "cwESPText");
end;