--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

if (!netstream) then include("sh_netstream.lua"); end;
if (!plugin) then include("sh_plugin.lua"); end;
if (!CW.config) then include("sh_config.lua"); end;
if (!CW.attribute) then include("sh_attribute.lua"); end;
if (!CW.faction) then include("sh_faction.lua"); end;
if (!CW.class) then include("sh_class.lua"); end;
if (!CW.command) then include("sh_command.lua"); end;
if (!CW.attribute) then include("sh_attribute.lua"); end;
if (!CW.option) then include("sh_option.lua"); end;
if (!CW.entity) then include("sh_entity.lua"); end;
if (!CW.item) then include("sh_item.lua"); end;
if (!CW.inventory) then include("sh_inventory.lua"); end;

CW.player = CW.kernel:NewLibrary("Player");

function CW.player:SetSharedVar(player, key, value)
	if (SERVER) then
		if (IsValid(player)) then
			player:SetNetVar(key, value);
		end
	end;
end;

function CW.player:GetSharedVar(player, key)
	if (IsValid(player)) then
		return player:GetNetVar(key);
	end;
end;

if (CLIENT) then

-- A function to get whether the local player can hold a weight.
function CW.player:CanHoldWeight(weight)
	local inventoryWeight = CW.inventory:CalculateWeight(
		CW.inventory:GetClient()
	);
	
	if (inventoryWeight + weight > CW.player:GetMaxWeight()) then
		return false;
	else
		return true;
	end;
end;

-- A function to get whether the local player can fit a space.
function CW.player:CanHoldSpace(space)
	local inventorySpace = CW.inventory:CalculateSpace(
		CW.inventory:GetClient()
	);
	
	if (inventorySpace + space > CW.player:GetMaxSpace()) then
		return false;
	else
		return true;
	end;
end;

-- A function to get the maximum amount of weight the local player can carry.
function CW.player:GetMaxWeight()
	local itemsList = CW.inventory:GetAsItemsList(
		CW.inventory:GetClient()
	);
	
	local weight = CW.Client:GetSharedVar("InvWeight") or CW.config:Get("default_inv_weight"):Get();
	
	for k, v in pairs(itemsList) do
		local addInvWeight = v("addInvSpace");
		
		if (addInvWeight) then
			weight = weight + addInvWeight;
		end;
	end;
	
	return weight;
end;

-- A function to get the maximum amount of space the local player can carry.
function CW.player:GetMaxSpace()
	local itemsList = CW.inventory:GetAsItemsList(
		CW.inventory:GetClient()
	);
	local space = CW.Client:GetSharedVar("InvSpace") or CW.config:GetVal("default_inv_space");
	
	for k, v in pairs(itemsList) do
		local addInvSpace = v("addInvVolume");
		
		if (addInvSpace) then
			space = space + addInvSpace;
		end;
	end;
	
	return space;
end;

-- A function to find a player by an identifier.
function CW.player:FindByID(identifier)
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized() and (v:SteamID() == identifier
		or string.find(string.lower(v:Name()), string.lower(identifier), 1, true))) then
			return v;
		end;
	end;
end;

-- A function to get the local player's clothes data.
function CW.player:GetClothesData()
	return CW.ClothesData;
end;

-- A function to get the local player's accessory data.
function CW.player:GetAccessoryData()
	return CW.AccessoryData;
end;

-- A function to get the local player's clothes item.
function CW.player:GetClothesItem()
	local clothesData = self:GetClothesData();

	if (clothesData.itemID != nil and clothesData.uniqueID != nil) then
		return CW.inventory:FindItemByID(
			CW.inventory:GetClient(),
			clothesData.uniqueID, clothesData.itemID
		);
	end;
end;

-- A function to get whether the local player is wearing clothes.
function CW.player:IsWearingClothes()
	return (self:GetClothesItem() != nil);
end;

-- A function to get whether the local player has an accessory.
function CW.player:HasAccessory(uniqueID)
	local accessoryData = self:GetAccessoryData();
	
	for k, v in pairs(accessoryData) do
		if (string.lower(v) == string.lower(uniqueID)) then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to get whether the local player is wearing an accessory.
function CW.player:IsWearingAccessory(itemTable)
	local accessoryData = self:GetAccessoryData();
	local itemID = itemTable("itemID");
	
	if (accessoryData[itemID]) then
		return true;
	else
		return false;
	end;
end;

-- A function to get whether the local player is wearing an item.
function CW.player:IsWearingItem(itemTable)
	local clothesItem = self:GetClothesItem();
	return (clothesItem and clothesItem:IsTheSameAs(itemTable));
end;

-- A function to get whether a player is noclipping.
function CW.player:IsNoClipping(player)
	if (player:GetMoveType() == MOVETYPE_NOCLIP
	and !player:InVehicle()) then
		return true;
	end;
end;

-- A function to get whether a player is an admin.
function CW.player:IsAdmin(player)
	if (self:HasFlags(player, "o")) then
		return true;
	end;
end;

-- A function to get whether the local player's data has streamed.
function CW.player:HasDataStreamed()
	return CW.DataHasStreamed;
end;

-- A function to get whether a player can hear another player.
function CW.player:CanHearPlayer(player, target, allowance)
	if (CW.config:Get("messages_must_see_player"):Get()) then
		return self:CanSeePlayer(player, target, (allowance or 0.5), true);
	else
		return true;
	end;
end;
	
-- A function to get whether the target recognises the local player.
function CW.player:DoesTargetRecognise()
	if (CW.config:Get("recognise_system"):Get()) then
		return CW.Client:GetSharedVar("TargetKnows");
	else
		return true;
	end;
end;

-- A function to get a player's real trace.
function CW.player:GetRealTrace(player, useFilterTrace)
	if (!IsValid(player)) then
		return;
	end;

	local angles = player:GetAimVector() * 4096;
	local eyePos = EyePos();
	
	if (player != CW.Client) then
		eyePos = player:EyePos();
	end;
	
	local trace = util.TraceLine({
		endpos = eyePos + angles,
		start = eyePos,
		filter = player
	});
	
	local newTrace = util.TraceLine({
		endpos = eyePos + angles,
		filter = player,
		start = eyePos,
		mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
	});
	
	if ((IsValid(newTrace.Entity) and !newTrace.HitWorld and (!IsValid(trace.Entity)
	or string.find(trace.Entity:GetClass(), "vehicle"))) or useFilterTrace) then
		trace = newTrace;
	end;
	
	return trace;
end;

-- A function to get the local player's action.
function CW.player:GetAction(player, percentage)
	local startActionTime = player:GetSharedVar("StartActTime") or 0;
	local actionDuration = player:GetSharedVar("ActDuration") or 0;
	local curTime = CurTime();
	local action = player:GetSharedVar("ActName") or "Unknown";
	
	if (curTime < startActionTime + actionDuration) then
		if (percentage) then
			return action, (100 / actionDuration) * (actionDuration - ((startActionTime + actionDuration) - curTime));
		else
			return action, actionDuration, startActionTime;
		end;
	else
		return "", 0, 0;
	end;
end;

-- A function to get the local player's maximum characters.
function CW.player:GetMaximumCharacters()
	local whitelisted = CW.character:GetWhitelisted();
	local maximum = CW.config:Get("additional_characters"):Get(2);
	
	for k, v in pairs(CW.faction:GetStored()) do
		if (!v.whitelist or table.HasValue(whitelisted, v.name)) then
			maximum = maximum + 1;
		end;
	end;
	
	return maximum;
end;

-- A function to get whether a player's weapon is raised.
function CW.player:GetWeaponRaised(player)
	return player:GetSharedVar("IsWepRaised");
end;

-- A function to get a player's unrecognised name.
function CW.player:GetUnrecognisedName(player)
	local unrecognisedPhysDesc = self:GetPhysDesc(player);
	local unrecognisedName = CW.config:Get("unrecognised_name"):Get();
	local usedPhysDesc;
	
	if (unrecognisedPhysDesc) then
		unrecognisedName = unrecognisedPhysDesc;
		usedPhysDesc = true;
	end;
	
	return unrecognisedName, usedPhysDesc;
end;

function CW.player:GetName(target)
	if (CW.player:DoesRecognise(target)) then
		return target:Name();
	else
		return CW.player:GetUnrecognisedName(target);
	end;
end;

-- A function to get whether a player can see an NPC.
function CW.player:CanSeeNPC(player, target, allowance, ignoreEnts)
	if (player:GetEyeTraceNoCursor().Entity == target) then
		return true;
	else
		local trace = {};
		
		trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER;
		trace.start = player:GetShootPos();
		trace.endpos = target:GetShootPos();
		trace.filter = {player, target};
		
		if (ignoreEnts) then
			if (type(ignoreEnts) == "table") then
				table.Add(trace.filter, ignoreEnts);
			else
				table.Add(trace.filter, ents.GetAll());
			end;
		end;
		
		trace = util.TraceLine(trace);
		
		if (trace.Fraction >= (allowance or 0.75)) then
			return true;
		end;
	end;
end;

-- A function to get whether a player can see a player.
function CW.player:CanSeePlayer(player, target, allowance, ignoreEnts)
	if (player:GetEyeTraceNoCursor().Entity == target) then
		return true;
	elseif (target:GetEyeTraceNoCursor().Entity == player) then
		return true;
	else
		local trace = {};
		
		trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER;
		trace.start = player:GetShootPos();
		trace.endpos = target:GetShootPos();
		trace.filter = {player, target};
		
		if (ignoreEnts) then
			if (type(ignoreEnts) == "table") then
				table.Add(trace.filter, ignoreEnts);
			else
				table.Add(trace.filter, ents.GetAll());
			end;
		end;
		
		trace = util.TraceLine(trace);
		
		if (trace.Fraction >= (allowance or 0.75)) then
			return true;
		end;
	end;
end;

-- A function to get whether a player can see an entity.
function CW.player:CanSeeEntity(player, target, allowance, ignoreEnts)
	if (player:GetEyeTraceNoCursor().Entity == target) then
		return true;
	else
		local trace = {};
		
		trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER;
		trace.start = player:GetShootPos();
		trace.endpos = target:LocalToWorld(target:OBBCenter());
		trace.filter = {player, target};
		
		if (ignoreEnts) then
			if (type(ignoreEnts) == "table") then
				table.Add(trace.filter, ignoreEnts);
			else
				table.Add(trace.filter, ents.GetAll());
			end;
		end;
		
		trace = util.TraceLine(trace);
		
		if (trace.Fraction >= (allowance or 0.75)) then
			return true;
		end;
	end;
end;

-- A function to get whether a player can see a position.
function CW.player:CanSeePosition(player, position, allowance, ignoreEnts)
	local trace = {};
	
	trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER;
	trace.start = player:GetShootPos();
	trace.endpos = position;
	trace.filter = player;
	
	if (ignoreEnts) then
		if (type(ignoreEnts) == "table") then
			table.Add(trace.filter, ignoreEnts);
		else
			table.Add(trace.filter, ents.GetAll());
		end;
	end;
	
	trace = util.TraceLine(trace);
	
	if (trace.Fraction >= (allowance or 0.75)) then
		return true;
	end;
end;

-- A function to get a player's wages name.
function CW.player:GetWagesName(player)
	return CW.class:Query(player:Team(), "wagesName", CW.config:Get("wages_name"):Get());
end;

-- A function to check whether a player is ragdolled
function CW.player:IsRagdolled(player, exception, entityless)
	if (player:GetRagdollEntity() or entityless) then
		if (player:GetDTInt(4) == 0) then
			return false;
		elseif (player:GetDTInt(4) == exception) then
			return false;
		else
			return (player:GetDTInt(4) != RAGDOLL_NONE);
		end;
	end;
end;

-- A function to get whether the local player recognises another player.
function CW.player:DoesRecognise(player, status, isAccurate)
	if (!status) then
		return self:DoesRecognise(player, RECOGNISE_PARTIAL);
	elseif (CW.config:Get("recognise_system"):Get()) then
		local key = self:GetCharacterKey(player);
		local realValue = false;
		
		if (self:GetCharacterKey(CW.Client) == key) then
			return true;
		elseif (CW.RecognisedNames[key]) then
			if (isAccurate) then
				realValue = (CW.RecognisedNames[key] == status);
			else
				realValue = (CW.RecognisedNames[key] >= status);
			end;
		end;
		
		return plugin.Call("PlayerDoesRecognisePlayer", player, status, isAccurate, realValue);
	else
		return true;
	end;
end;

-- A function to get a player's character key.
function CW.player:GetCharacterKey(player)
	if (IsValid(player)) then
		return player:GetSharedVar("Key");
	end;
end;

-- A function to get a player's ragdoll state.
function CW.player:GetRagdollState(player)
	if (player:GetDTInt(4) == 0) then
		return false;
	else
		return player:GetDTInt(4);
	end;
end;

-- A function to get a player's physical description.
function CW.player:GetPhysDesc(player)
	if (!player) then
		player = CW.Client;
	end;
	
	local physDesc = player:GetSharedVar("PhysDesc");
	local team = player:Team();
	
	if (physDesc == "") then
		physDesc = CW.class:Query(team, "defaultPhysDesc", "");
	end;
	
	if (physDesc == "") then
		physDesc = CW.config:Get("default_physdesc"):Get();
	end;
	
	if (!physDesc or physDesc == "") then
		physDesc = "This character has no physical description set.";
	else
		physDesc = CW.kernel:ModifyPhysDesc(physDesc);
	end;
	
	local override = plugin.Call("GetPlayerPhysDescOverride", player, physDesc);
	
	if (override) then
		physDesc = override;
	end;
	
	return physDesc;
end;

-- A function to get the local player's wages.
function CW.player:GetWages()
	return CW.Client:GetSharedVar("Wages");
end;

-- A function to get the local player's cash.
function CW.player:GetCash()
	return CW.Client:GetSharedVar("Cash") or 0;
end;

-- A function to get a player's ragdoll entity.
function CW.player:GetRagdollEntity(player)
	local ragdollEntity = player:GetDTEntity(2);
	
	if (IsValid(ragdollEntity)) then
		return ragdollEntity;
	end;
end;

-- A function to get a player's default skin.
function CW.player:GetDefaultSkin(player)
	local model, skin = CW.class:GetAppropriateModel(player:Team(), player);
	
	return skin;
end;

-- A function to get a player's default model.
function CW.player:GetDefaultModel(player)
	local model, skin = CW.class:GetAppropriateModel(player:Team(), player);
	return model;
end;

-- A function to check if a player has any flags.
function CW.player:HasAnyFlags(player, flags, bByDefault)
	local playerFlags = player:GetSharedVar("Flags")
	
	if (playerFlags != nil and playerFlags != "") then
		if (CW.class:HasAnyFlags(player:Team(), flags) and !bByDefault) then
			return true;
		end;
		
		for i = 1, #flags do
			local flag = string.utf8sub(flags, i, i);
			local bSuccess = true;
			
			if (!bByDefault) then
				local hasFlag = plugin.Call("PlayerDoesHaveFlag", player, flag);
				
				if (hasFlag != false) then
					if (hasFlag) then
						return true;
					end;
				else
					bSuccess = nil;
				end;
			end;
			
			if (bSuccess) then
				if (flag == "s") then
					if (player:IsSuperAdmin()) then
						return true;
					end;
				elseif (flag == "a") then
					if (player:IsAdmin()) then
						return true;
					end;
				elseif (flag == "o") then
					if (player:IsSuperAdmin() or player:IsAdmin()) then
						return true;
					elseif (player:IsUserGroup("operator")) then
						return true;
					end;
				elseif (string.find(playerFlags, flag)) then
					return true;
				end;
			end;
		end;
	end;
end;

-- A function to check if a player has access.
function CW.player:HasFlags(player, flags, bByDefault)
	local playerFlags = player:GetSharedVar("Flags")
	
	if (playerFlags != nil and playerFlags != "") then
		if (CW.class:HasFlags(player:Team(), flags) and !bByDefault) then
			return true;
		end;
		
		for i = 1, #flags do
			local flag = string.utf8sub(flags, i, i);
			local bSuccess;
			
			if (!bByDefault) then
				local hasFlag = plugin.Call("PlayerDoesHaveFlag", player, flag);
				
				if (hasFlag != false) then
					if (hasFlag) then
						bSuccess = true;
					end;
				else
					return;
				end;
			end;
			
			if (!bSuccess) then
				if (flag == "s") then
					if (!player:IsSuperAdmin()) then
						return;
					end;
				elseif (flag == "a") then
					if (!player:IsAdmin()) then
						return;
					end;
				elseif (flag == "o") then
					if (!player:IsSuperAdmin() and !player:IsAdmin()) then
						if (!player:IsUserGroup("operator")) then
							return;
						end;
					end;
				elseif (!string.find(playerFlags, flag)) then
					return false;
				end;
			end;
		end;
		
		return true;
	end;
end;

-- A function to get whether the local player is drunk.
function CW.player:GetDrunk()
	local isDrunk = LocalPlayer():GetSharedVar("IsDrunk") or 0;
	
	if (isDrunk and isDrunk > 0) then
		return isDrunk;
	end;
end;

-- A function to get a player's chat icon.
function CW.player:GetChatIcon(player)
	local icon;
	
	if (!IsValid(player)) then
		return "icon16/user_delete.png";
	end;
	
	for k, v in pairs(CW.icon:GetAll()) do
		if (v.callback(player)) then
			if (!icon) then
				icon = v.path;
			end;
			
			if (v.isPlayer) then
				icon = v.path;
				break;
			end;
		end;
	end;
	
	if (!icon) then
		local faction = player:GetFaction();
		
		icon = "icon16/user.png";
		
		if (faction and CW.faction:GetStored()[faction]) then
			if (CW.faction:GetStored()[faction].whitelist) then
				icon = "icon16/add.png";
			end;
		end;
	end;
	
	return icon;
end;

else -- if (SERVER) then

if (!CW.database) then include("server/sv_database.lua"); end;
if (!chatbox) then include("server/sv_chatbox.lua"); end;
if (!CW.hint) then include("sv_hint.lua"); end;

local cwHint = CW.hint;
local cwDatabase = CW.database;

CW.player.property = CW.player.property or {};
CW.player.stored = CW.player.stored or {};

function CW.player:RestoreData(player, data)
	for k, v in pairs(data) do
		self:UpdatePlayerData(player, k, v);
	end;

	for k, v in pairs(self.playerData) do
		if (data[k] == nil) then
			player:SetData(k, v.default);
		end;
	end;
end;

function CW.player:RestoreCharacterData(player, data)
	for k, v in pairs(data) do
		self:UpdateCharacterData(player, k, v);
	end;

	for k, v in pairs(self.characterData) do
		if (data[k] == nil) then
			player:SetCharacterData(k, v.default);
		end;
	end;
end;

function CW.player:UpdateCharacterData(player, key, value)
	local characterData = self.characterData;

	if (characterData[key]) then
		if (characterData[key].callback) then
			value = characterData[key].callback(player, value);
		end;

		player:SetSharedVar(key, value);
	end;
end;
	
function CW.player:UpdatePlayerData(player, key, value)
	local playerData = self.playerData;

	if (playerData[key]) then
		if (playerData[key].callback) then
			value = playerData[key].callback(player, value);
		end;

		player:SetSharedVar(key, value);
	end;
end;

-- A function to run an inventory action for a player.
function CW.player:InventoryAction(player, itemTable, action)
	return self:RunClockworkCommand(player, "InvAction", action, itemTable("uniqueID"), tostring(itemTable("itemID")));
end;

-- A function to get a player's gear.
function CW.player:GetGear(player, gearClass)
	if (player.cwGearTab and IsValid(player.cwGearTab[gearClass])) then
		return player.cwGearTab[gearClass];
	end;
end;

-- A function to create a character from data.
function CW.player:CreateCharacterFromData(player, data)
	if (player.cwIsCreatingChar) then
		return;
	end;

	local minimumPhysDesc = CW.config:Get("minimum_physdesc"):Get();
	local attributesTable = CW.attribute:GetAll();
	local factionTable = CW.faction:FindByID(data.faction);
	local attributes = nil;
	local info = {};
	
	if (table.Count(attributesTable) > 0) then
		for k, v in pairs(attributesTable) do
			if (v.isOnCharScreen) then
				attributes = true;
				break;
			end;
		end;
	end;
	
	if (!factionTable) then
		return self:SetCreateFault(
			player, "You did not choose a faction, or the faction that you chose is not valid!"
		);
	end;
	
	info.attributes = {};
	info.faction = factionTable.name;
	info.gender = data.gender;
	info.model = data.model;
	info.data = {};
	
	if (data.plugin) then
		for k, v in pairs(data.plugin) do
			info.data[k] = v;
		end;
	end;
	
	local classes = false;
	
	for k, v in pairs(CW.class:GetAll()) do
		if (v.isOnCharScreen and (v.factions
		and table.HasValue(v.factions, factionTable.name))) then
			classes = true;
		end;
	end;
	
	if (classes) then
		local classTable = CW.class:FindByID(data.class);
		
		if (!classTable) then
			return self:SetCreateFault(
				player, "You did not choose a class, or the class that you chose is not valid!"
			);
		else
			info.data["class"] = classTable.name;
		end;
	end;
	
	if (attributes and type(data.attributes) == "table") then
		local maximumPoints = CW.config:Get("default_attribute_points"):Get();
		local pointsSpent = 0;
		
		if (factionTable.attributePointsScale) then
			maximumPoints = math.Round(maximumPoints * factionTable.attributePointsScale);
		end;
		
		if (factionTable.maximumAttributePoints) then
			maximumPoints = factionTable.maximumAttributePoints;
		end;
		
		for k, v in pairs(data.attributes) do
			local attributeTable = CW.attribute:FindByID(k);
			
			if (attributeTable and attributeTable.isOnCharScreen) then
				local uniqueID = attributeTable.uniqueID;
				local amount = math.Clamp(v, 0, attributeTable.maximum);
				
				info.attributes[uniqueID] = {
					amount = amount,
					progress = 0
				};
				
				pointsSpent = pointsSpent + amount;
			end;
		end;
		
		if (pointsSpent > maximumPoints) then
			return self:SetCreateFault(
				player, "You have chosen more "..CW.option:GetKey("name_attribute", true).." points than you can afford to spend!"
			);
		end;
	elseif (attributes) then
		return self:SetCreateFault(
			player, "You did not choose any "..CW.option:GetKey("name_attributes", true).." or the ones that you did are not valid!"
		);
	end;
	
	if (!factionTable.GetName) then
		if (!factionTable.useFullName) then
			if (data.forename and data.surname) then
				data.forename = string.gsub(data.forename, "^.", string.upper);
				data.surname = string.gsub(data.surname, "^.", string.upper);
				
				if (string.find(data.forename, "[%p%s%d]") or string.find(data.surname, "[%p%s%d]")) then
					return self:SetCreateFault(
						player, "Your forename and surname must not contain punctuation, spaces or digits!"
					);
				end;
				
				if (!string.find(data.forename, "[aeiou]") or !string.find(data.surname, "[aeiou]")) then
					return self:SetCreateFault(
						player, "Your forename and surname must both contain at least one vowel!"
					);
				end;
				
				if (string.utf8len(data.forename) < 2 or string.utf8len(data.surname) < 2) then
					return self:SetCreateFault(
						player, "Your forename and surname must both be at least 2 characters long!"
					);
				end;
				
				if (string.utf8len(data.forename) > 16 or string.utf8len(data.surname) > 16) then
					return self:SetCreateFault(
						player, "Your forename and surname must not be greater than 16 characters long!"
					);
				end;
			else
				return self:SetCreateFault(
					player, "You did not choose a name, or the name that you chose is not valid!"
				);
			end;
		elseif (!data.fullName or data.fullName == "") then
			return self:SetCreateFault(
				player, "You did not choose a name, or the name that you chose is not valid!"
			);
		end;
	end;
	
	if (CW.command:FindByID("CharPhysDesc") != nil) then
		if (type(data.physDesc) != "string") then
			return self:SetCreateFault(
				player, "You did not enter a physical description!"
			);
		elseif (string.utf8len(data.physDesc) < minimumPhysDesc) then
			return self:SetCreateFault(
				player, "The physical description must be at least "..minimumPhysDesc.." characters long!"
			);
		end;
		
		info.data["PhysDesc"] = CW.kernel:ModifyPhysDesc(data.physDesc);
	end;
	
	if (!factionTable.GetModel and !info.model) then
		return self:SetCreateFault(
			player, "You did not choose a model, or the model that you chose is not valid!"
		);
	end;
	
	if (!CW.faction:IsGenderValid(info.faction, info.gender)) then
		return self:SetCreateFault(
			player, "You did not choose a gender, or the gender that you chose is not valid!"
		);
	end;
	
	if (factionTable.whitelist and !self:IsWhitelisted(player, info.faction)) then
		return self:SetCreateFault(
			player, "You are not on the "..info.faction.." whitelist!"
		);
	elseif (CW.faction:IsModelValid(factionTable.name, info.gender, info.model)
	or (factionTable.GetModel and !info.model)) then
		local charactersTable = CW.config:Get("mysql_characters_table"):Get();
		local schemaFolder = CW.kernel:GetSchemaFolder();
		local characterID = nil;
		local characters = player:GetCharacters();
		
		if (CW.faction:HasReachedMaximum(player, factionTable.name)) then
			return self:SetCreateFault(
				player, "You cannot create any more characters in this faction."
			);
		end;
		
		for i = 1, self:GetMaximumCharacters(player) do
			if (!characters[i]) then
				characterID = i;
				break;
			end;
		end;
		
		if (characterID) then
			if (factionTable.GetName) then
				info.name = factionTable:GetName(player, info, data);
			elseif (!factionTable.useFullName) then
				info.name = data.forename.." "..data.surname;
			else
				info.name = data.fullName;
			end;
			
			if (factionTable.GetModel) then
				info.model = factionTable:GetModel(player, info, data);
			else
				info.model = data.model;
			end;
			
			if (factionTable.OnCreation) then
				local fault = factionTable:OnCreation(player, info);
				
				if (fault == false or type(fault) == "string") then
					return self:SetCreateFault(
						player, fault or "There was an error creating this character!"
					);
				end;
			end;
			
			for k, v in pairs(characters) do
				if (v.name == info.name) then
					return self:SetCreateFault(
						player, "You already have a character with the name '"..info.name.."'!"
					);
				end;
			end;
			
			local fault = plugin.Call("PlayerAdjustCharacterCreationInfo", player, info, data);
			
			if (fault == false or type(fault) == "string") then
				return self:SetCreateFault(
					player, fault or "There was an error creating this character!"
				);
			end;
			
			local queryObj = cwDatabase:Select(charactersTable);
				queryObj:AddWhere("_Schema = ?", schemaFolder);
				queryObj:AddWhere("_Name = ?", info.name);
				queryObj:SetCallback(function(result)
					if (!IsValid(player)) then return; end;
					
					if (cwDatabase:IsResult(result)) then
						self:SetCreateFault(
							player, "A character with the name '"..info.name.."' already exists!"
						);
						player.cwIsCreatingChar = nil;
					else
						self:LoadCharacter(player, characterID,
							{
								attributes = info.attributes,
								faction = info.faction,
								gender = info.gender,
								model = info.model,
								name = info.name,
								data = info.data
							},
							function()
								CW.kernel:PrintLog(LOGTYPE_MINOR,
									player:SteamName().." has created a "..info.faction.." character called '"..info.name.."'."
								);
								
								netstream.Start(player, "CharacterFinish", {bSuccess = true});
								
								player.cwIsCreatingChar = nil;
								
								local characters = player:GetCharacters();
								
								if (table.Count(characters) == 1) then
									self:UseCharacter(player, characterID);
								end;
							end
						);
					end;
				end);
			queryObj:Pull();
		else
			return self:SetCreateFault(player, "You cannot create any more characters!");
		end;
	else
		return self:SetCreateFault(
			player, "You did not choose a model, or the model that you chose is not valid!"
		);
	end;
end;

-- A function to open the character menu.
function CW.player:SetCharacterMenuOpen(player, bReset)
	if (player:HasInitialized()) then
		netstream.Start(player, "CharacterOpen", (bReset == true));
		
		if (bReset) then
			player.cwCharMenuReset = true;
			player:KillSilent();
		end;
	end;
end;

-- A function to start a sound for a player.
function CW.player:StartSound(player, uniqueID, sound, fVolume)
	if (!player.cwSoundsPlaying) then
		player.cwSoundsPlaying = {};
	end;
	
	if (!player.cwSoundsPlaying[uniqueID]
	or player.cwSoundsPlaying[uniqueID] != sound) then
		player.cwSoundsPlaying[uniqueID] = sound;
		
		netstream.Start(player, "StartSound", {
			uniqueID = uniqueID, sound = sound, volume = (fVolume or 0.75)
		});
	end;
end;

-- A function to stop a sound for a player.
function CW.player:StopSound(player, uniqueID, iFadeOut)
	if (!player.cwSoundsPlaying) then
		player.cwSoundsPlaying = {};
	end;
	
	if (player.cwSoundsPlaying[uniqueID]) then
		player.cwSoundsPlaying[uniqueID] = nil;
		
		netstream.Start(player, "StopSound", {
			uniqueID = uniqueID, fadeOut = (iFadeOut or 0)
		});
	end;
end;

-- A function to remove a player's gear.
function CW.player:RemoveGear(player, gearClass)
	if (player.cwGearTab and IsValid(player.cwGearTab[gearClass])) then
		player.cwGearTab[gearClass]:Remove();
		player.cwGearTab[gearClass] = nil;
	end;
end;

-- A function to strip all of a player's gear.
function CW.player:StripGear(player)
	if (!player.cwGearTab) then return; end;
	
	for k, v in pairs(player.cwGearTab) do
		if (IsValid(v)) then v:Remove(); end;
	end;
	
	player.cwGearTab = {};
end;

-- A function to create a player's gear.
function CW.player:CreateGear(player, gearClass, itemTable, bMustHave)
	if (!player.cwGearTab) then
		player.cwGearTab = {};
	end;
	
	if (IsValid(player.cwGearTab[gearClass])) then
		player.cwGearTab[gearClass]:Remove();
	end;
	
	if (itemTable("isAttachment")) then
		local position = player:GetPos();
		local angles = player:GetAngles();
		local model = itemTable("attachmentModel", itemTable("model"));
		
		player.cwGearTab[gearClass] = ents.Create("cw_gear");
		player.cwGearTab[gearClass]:SetParent(player);
		player.cwGearTab[gearClass]:SetAngles(angles);
		player.cwGearTab[gearClass]:SetModel(model);
		player.cwGearTab[gearClass]:SetPos(position);
		player.cwGearTab[gearClass]:Spawn();
		
		if (itemTable("attachmentMaterial")) then
			player.cwGearTab[gearClass]:SetMaterial(itemTable("attachmentMaterial"));
		end;
		
		if (itemTable("attachmentColor")) then
			player.cwGearTab[gearClass]:SetColor(
				CW.kernel:UnpackColor(itemTable("attachmentColor"))
			);
		else
			player.cwGearTab[gearClass]:SetColor(Color(255, 255, 255, 255));
		end;
		
		if (IsValid(player.cwGearTab[gearClass])) then
			player.cwGearTab[gearClass]:SetOwner(player);
			player.cwGearTab[gearClass]:SetMustHave(bMustHave);
			player.cwGearTab[gearClass]:SetItemTable(gearClass, itemTable);
		end;
	end;
end;

-- A function to get whether a player is noclipping.
function CW.player:IsNoClipping(player)
	if (player:GetMoveType() == MOVETYPE_NOCLIP
	and !player:InVehicle()) then
		return true;
	end;
end;

-- A function to get whether a player is an admin.
function CW.player:IsAdmin(player)
	if (self:HasFlags(player, "o")) then
		return true;
	end;
end;

-- A function to get whether a player can hear another player.
function CW.player:CanHearPlayer(player, target, iAllowance)
	if (CW.config:Get("messages_must_see_player"):Get()) then
		return self:CanSeePlayer(player, target, (iAllowance or 0.5), true);
	else
		return true;
	end;
end;

-- A functon to get all property.
function CW.player:GetAllProperty()
	for k, v in pairs(self.property) do
		if (!IsValid(v)) then
			self.property[k] = nil;
		end;
	end;
	
	return self.property;
end;

-- A function to set a player's action.
function CW.player:SetAction(player, action, duration, priority, Callback)
	local currentAction = self:GetAction(player);
	
	if (type(action) != "string" or action == "") then
		CW.kernel:DestroyTimer("Action"..player:UniqueID());
		
		player:SetSharedVar("StartActTime", 0);
		player:SetSharedVar("ActDuration", 0);
		player:SetSharedVar("ActName", "");
		
		return;
	elseif (duration == false or duration == 0) then
		if (currentAction == action) then
			return self:SetAction(player, false);
		else
			return false;
		end;
	end;
	
	if (player.cwAction) then
		if ((priority and priority > player.cwAction[2])
		or currentAction == "" or action == player.cwAction[1]) then
			player.cwAction = nil;
		end;
	end;

	if (!player.cwAction) then
		local curTime = CurTime();
		
		player:SetSharedVar("StartActTime", curTime);
		player:SetSharedVar("ActDuration", duration);
		player:SetSharedVar("ActName", action);
		
		if (priority) then
			player.cwAction = {action, priority};
		else
			player.cwAction = nil;
		end;
		
		CW.kernel:CreateTimer("Action"..player:UniqueID(), duration, 1, function()
			if (Callback) then
				Callback();
			end;
		end);
	end;
end;

-- A function to set the player's character menu state.
function CW.player:SetCharacterMenuState(player, state)
	netstream.Start(player, "CharacterMenu", state);
end;

-- A function to get a player's action.
function CW.player:GetAction(player, percentage)
	local startActionTime = player:GetSharedVar("StartActTime") or 0;
	local actionDuration = player:GetSharedVar("ActDuration") or 0;
	local curTime = CurTime();
	local action = player:GetSharedVar("ActName") or "Unknown";
	
	if (startActionTime and CurTime() < startActionTime + actionDuration) then
		if (percentage) then
			return action, (100 / actionDuration) * (actionDuration - ((startActionTime + actionDuration) - curTime));
		else
			return action, actionDuration, startActionTime;
		end;
	else
		return "", 0, 0;
	end;
end;

-- A function to run a Clockwork command on a player.
function CW.player:RunClockworkCommand(player, command, ...)
	return CW.command:ConsoleCommand(player, "cwCmd", {command, ...});
end;

-- A function to get a player's wages name.
function CW.player:GetWagesName(player)
	return CW.class:Query(player:Team(), "wagesName", CW.config:Get("wages_name"):Get());
end;

-- A function to get whether a player can see an entity.
function CW.player:CanSeeEntity(player, target, iAllowance, tIgnoreEnts)
	if (player:GetEyeTraceNoCursor().Entity != target) then
		return self:CanSeePosition(player, target:LocalToWorld(target:OBBCenter()), iAllowance, tIgnoreEnts, target);
	else
		return true;
	end;
end;

--[[
	Duplicate functions, keeping them like this for backward compatiblity.
--]]
CW.player.CanSeePlayer = CW.player.CanSeeEntity;
CW.player.CanSeeNPC = CW.player.CanSeeEntity;

-- A function to get whether a player can see a position.
function CW.player:CanSeePosition(player, position, iAllowance, tIgnoreEnts, targetEnt)
	local trace = {};
	
	trace.mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER;
	trace.start = player:GetShootPos();
	trace.endpos = position;
	trace.filter = {player, targetEnt};
	
	if (tIgnoreEnts) then
		if (type(tIgnoreEnts) == "table") then
			table.Add(trace.filter, tIgnoreEnts);
		else
			table.Add(trace.filter, ents.GetAll());
		end;
	end;
	
	trace = util.TraceLine(trace);
	
	if (trace.Fraction >= (iAllowance or 0.75)) then
		return true;
	end;
end;

-- A function to update whether a player's weapon is raised.
function CW.player:UpdateWeaponRaised(player)
	local bIsRaised = self:GetWeaponRaised(player);
	local weapon = player:GetActiveWeapon();
	
	player:SetSharedVar("IsWepRaised", bIsRaised);
	
	if (IsValid(weapon)) then
		CW.kernel:HandleWeaponFireDelay(player, bIsRaised, weapon, CurTime());
	end;
end;

-- A function to get whether a player's weapon is raised.
function CW.player:GetWeaponRaised(player, bIsCached)
	if (bIsCached) then
		return player:GetSharedVar("IsWepRaised") or false;
	end;
	
	local weapon = player:GetActiveWeapon();
	
	if (IsValid(weapon) and !weapon.NeverRaised) then
		if (weapon.GetRaised) then
			local bIsRaised = weapon:GetRaised();
			
			if (bIsRaised != nil) then
				return bIsRaised;
			end;
		end;
		
		return plugin.Call("GetPlayerWeaponRaised", player, weapon:GetClass(), weapon);
	end;
	
	return false;
end;

-- A function to toggle whether a player's weapon is raised.
function CW.player:ToggleWeaponRaised(player)
	self:SetWeaponRaised(player, !player.cwWeaponRaiseClass);
end;

-- A function to set whether a player's weapon is raised.
function CW.player:SetWeaponRaised(player, bIsRaised)
	local weapon = player:GetActiveWeapon();
	
	if (IsValid(weapon)) then
		if (type(bIsRaised) == "number") then
			player.cwAutoWepRaised = weapon:GetClass();
			player:UpdateWeaponRaised();
			
			CW.kernel:CreateTimer("WeaponRaised"..player:UniqueID(), bIsRaised, 1, function()
				if (IsValid(player)) then
					player.cwAutoWepRaised = nil;
					player:UpdateWeaponRaised();
				end;
			end);
		elseif (bIsRaised) then
			if (!player.cwWeaponRaiseClass) then
				if (weapon.OnRaised) then
					weapon:OnRaised();
				end;
			end;
			
			player.cwWeaponRaiseClass = weapon:GetClass();
			player.cwAutoWepRaised = nil;
			player:UpdateWeaponRaised();
		else
			if (player.cwWeaponRaiseClass) then
				if (weapon.OnLowered) then
					weapon:OnLowered();
				end;
			end;
			
			player.cwWeaponRaiseClass = nil;
			player.cwAutoWepRaised = nil;
			player:UpdateWeaponRaised();
		end;
	end;
end;

-- A function to setup a player's remove property delays.
function CW.player:SetupRemovePropertyDelays(player, bAllCharacters)
	local uniqueID = player:UniqueID();
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		local removeDelay = CW.entity:QueryProperty(v, "removeDelay");
		
		if (IsValid(v) and removeDelay) then
			if (uniqueID == CW.entity:QueryProperty(v, "uniqueID")
			and (bAllCharacters or key == CW.entity:QueryProperty(v, "key"))) then
				CW.kernel:CreateTimer("RemoveDelay"..v:EntIndex(), removeDelay, 1, function(entity)
					if (IsValid(entity)) then
						entity:Remove();
					end;
				end, v);
			end;
		end;
	end;
end;

-- A function to disable a player's property.
function CW.player:DisableProperty(player, bCharacterOnly)
	local uniqueID = player:UniqueID();
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		if (IsValid(v) and uniqueID == CW.entity:QueryProperty(v, "uniqueID")
		and (!bCharacterOnly or key == CW.entity:QueryProperty(v, "key"))) then
			CW.entity:SetPropertyVar(v, "owner", NULL);
			
			if (CW.entity:QueryProperty(v, "networked")) then
				v:SetNetworkedEntity("Owner", NULL);
			end;
			
			v:SetOwnerKey(nil);
			v:SetNetworkedBool("Owned", false);
			v:SetNetworkedInt("Key", 0);
			
			if (v.SetPlayer) then
				v:SetVar("Founder", NULL);
				v:SetVar("FounderIndex", 0);
				v:SetNetworkedString("FounderName", "");
			end;
		end;
	end;
end;

-- A function to give property to a player.
function CW.player:GiveProperty(player, entity, networked, removeDelay)
	CW.kernel:DestroyTimer("RemoveDelay"..entity:EntIndex());
	CW.entity:ClearProperty(entity);
	
	entity.cwPropertyTab = {
		key = player:GetCharacterKey(),
		owner = player,
		owned = true,
		uniqueID = player:UniqueID(),
		networked = networked,
		removeDelay = removeDelay
	};
	
	if (entity.SetPlayer) then
		entity:SetPlayer(player);
	end;
	
	if (networked) then
		entity:SetNetworkedEntity("Owner", player);
	end;
	
	entity:SetOwnerKey(player:GetCharacterKey());
	entity:SetNetworkedBool("Owned", true);
	
	if (tonumber(entity.cwPropertyTab.key)) then
		entity:SetNetworkedInt("Key", entity.cwPropertyTab.key);
	end;
	
	self.property[entity:EntIndex()] = entity;
	plugin.Call("PlayerPropertyGiven", player, entity, networked, removeDelay);
end;

-- A function to give property to an offline player.
function CW.player:GivePropertyOffline(key, uniqueID, entity, networked, removeDelay)
	CW.entity:ClearProperty(entity);
	
	if (key and uniqueID) then
		local propertyUniqueID = CW.entity:QueryProperty(entity, "uniqueID");
		local owner = player.GetByUniqueID(uniqueID);
		
		if (IsValid(owner) and owner:GetCharacterKey() == key) then
			self:GiveProperty(owner, entity, networked, removeDelay);
			return;
		else
			owner = nil;
		end;
		
		if (propertyUniqueID) then
			CW.kernel:DestroyTimer("RemoveDelay"..entity:EntIndex().." "..cwPropertyTabUniqueID);
		end;
		
		entity.cwPropertyTab = {
			key = key,
			owner = owner,
			owned = true,
			uniqueID = uniqueID,
			networked = networked,
			removeDelay = removeDelay
		};
		
		if (IsValid(entity.cwPropertyTab.owner)) then
			if (entity.SetPlayer) then
				entity:SetPlayer(entity.cwPropertyTab.owner);
			end;
			
			if (networked) then
				entity:SetNetworkedEntity("Owner", entity.cwPropertyTab.owner);
			end;
		end;
		
		entity:SetNetworkedBool("Owned", true);
		entity:SetNetworkedInt("Key", key);
		entity:SetOwnerKey(key);
		
		self.property[entity:EntIndex()] = entity;
		plugin.Call("PlayerPropertyGivenOffline", key, uniqueID, entity, networked, removeDelay);
	end;
end;

-- A function to take property from an offline player.
function CW.player:TakePropertyOffline(key, uniqueID, entity, bAnyCharacter)
	if (key and uniqueID) then
		local owner = player.GetByUniqueID(uniqueID);
		
		if (IsValid(owner) and owner:GetCharacterKey() == key) then
			self:TakeProperty(owner, entity);
			return;
		end;
		
		if (CW.entity:QueryProperty(entity, "uniqueID") == uniqueID
		and CW.entity:QueryProperty(entity, "key") == key) then
			entity.cwPropertyTab = nil;
			entity:SetNetworkedEntity("Owner", NULL);
			entity:SetNetworkedBool("Owned", false);
			entity:SetNetworkedInt("Key", 0);
			entity:SetOwnerKey(nil);
			
			if (entity.SetPlayer) then
				entity:SetVar("Founder", nil);
				entity:SetVar("FounderIndex", nil);
				entity:SetNetworkedString("FounderName", "");
			end;
			
			self.property[entity:EntIndex()] = nil;
			plugin.Call("PlayerPropertyTakenOffline", key, uniqueID, entity);
		end;
	end;
end;

-- A function to take property from a player.
function CW.player:TakeProperty(player, entity)
	if (CW.entity:GetOwner(entity) == player) then
		entity.cwPropertyTab = nil;
		
		entity:SetNetworkedEntity("Owner", NULL);
		entity:SetNetworkedBool("Owned", false);
		entity:SetNetworkedInt("Key", 0);
		entity:SetOwnerKey(nil);
		
		if (entity.SetPlayer) then
			entity:SetVar("Founder", nil);
			entity:SetVar("FounderIndex", nil);
			entity:SetNetworkedString("FounderName", "");
		end;
		
		self.property[entity:EntIndex()] = nil;
		plugin.Call("PlayerPropertyTaken", player, entity);
	end;
end;

-- A function to set a player to their default skin.
function CW.player:SetDefaultSkin(player)
	player:SetSkin(self:GetDefaultSkin(player));
end;

-- A function to get a player's default skin.
function CW.player:GetDefaultSkin(player)
	return plugin.Call("GetPlayerDefaultSkin", player);
end;

-- A function to set a player to their default model.
function CW.player:SetDefaultModel(player)
	player:SetModel(self:GetDefaultModel(player));
end;

-- A function to get a player's default model.
function CW.player:GetDefaultModel(player)
	return plugin.Call("GetPlayerDefaultModel", player);
end;

-- A function to get whether a player is drunk.
function CW.player:GetDrunk(player)
	if (player.cwDrunkTab) then return #player.cwDrunkTab; end;
end;

-- A function to set whether a player is drunk.
function CW.player:SetDrunk(player, expire)
	local curTime = CurTime();
	
	if (expire == false) then
		player.cwDrunkTab = nil;
	elseif (!player.cwDrunkTab) then
		player.cwDrunkTab = {curTime + expire};
	else
		player.cwDrunkTab[#player.cwDrunkTab + 1] = curTime + expire;
	end;
	
	player:SetSharedVar("IsDrunk", self:GetDrunk(player) or 0);
end;

-- A function to strip a player's default ammo.
function CW.player:StripDefaultAmmo(player, weapon, itemTable)
	if (!itemTable) then
		itemTable = CW.item:GetByWeapon(weapon);
	end;
	
	if (itemTable) then
		local secondaryDefaultAmmo = itemTable("secondaryDefaultAmmo");
		local primaryDefaultAmmo = itemTable("primaryDefaultAmmo");
		
		if (primaryDefaultAmmo) then
			local ammoClass = weapon:GetPrimaryAmmoType();
			
			if (weapon:Clip1() != -1) then
				weapon:SetClip1(0);
			end;
			
			if (type(primaryDefaultAmmo) == "number") then
				player:SetAmmo(
					math.max(player:GetAmmoCount(ammoClass) - primaryDefaultAmmo, 0), ammoClass
				);
			end;
		end;
		
		if (secondaryDefaultAmmo) then
			local ammoClass = weapon:GetSecondaryAmmoType();
			
			if (weapon:Clip2() != -1) then
				weapon:SetClip2(0);
			end;
			
			if (type(secondaryDefaultAmmo) == "number") then
				player:SetAmmo(
					math.max(player:GetAmmoCount(ammoClass) - secondaryDefaultAmmo, 0), ammoClass
				);
			end;
		end;
	end;
end;

-- A function to check if a player is whitelisted for a faction.
function CW.player:IsWhitelisted(player, faction)
	return table.HasValue(player:GetData("Whitelisted"), faction);
end;

-- A function to set whether a player is whitelisted for a faction.
function CW.player:SetWhitelisted(player, faction, isWhitelisted)
	local whitelisted = player:GetData("Whitelisted");
	
	if (isWhitelisted) then
		if (!self:IsWhitelisted(player, faction)) then
			whitelisted[table.Count(whitelisted) + 1] = faction;
		end;
	else
		for k, v in pairs(whitelisted) do
			if (v == faction) then
				whitelisted[k] = nil;
			end;
		end;
	end;
	
	netstream.Start(
		player, "SetWhitelisted", {faction, isWhitelisted}
	);
end;

-- A function to create a Condition timer.
function CW.player:ConditionTimer(player, delay, Condition, Callback)
	local realDelay = CurTime() + delay;
	local uniqueID = player:UniqueID();
	
	if (player.cwConditionTimer) then
		player.cwConditionTimer.Callback(false);
		player.cwConditionTimer = nil;
	end;
	
	player.cwConditionTimer = {
		delay = realDelay,
		Callback = Callback,
		Condition = Condition
	};
	
	CW.kernel:CreateTimer("CondTimer"..uniqueID, 0, 0, function()
		if (!IsValid(player)) then
			CW.kernel:DestroyTimer("CondTimer"..uniqueID);
			Callback(false);
			return;
		end;
		
		if (Condition()) then
			if (CurTime() >= realDelay) then
				Callback(true); player.cwConditionTimer = nil;
				CW.kernel:DestroyTimer("CondTimer"..uniqueID);
			end;
		else
			Callback(false); player.cwConditionTimer = nil;
			CW.kernel:DestroyTimer("CondTimer"..uniqueID);
		end;
	end);
end;

-- A function to create an entity Condition timer.
function CW.player:EntityConditionTimer(player, target, entity, delay, distance, Condition, Callback)
	local realEntity = entity or target;
	local realDelay = CurTime() + delay;
	local uniqueID = player:UniqueID();
	
	if (player.cwConditionEntTimer) then
		player.cwConditionEntTimer.Callback(false);
		player.cwConditionEntTimer = nil;
	end;
	
	player.cwConditionEntTimer = {
		delay = realDelay, target = target,
		entity = realEntity, distance = distance,
		Callback = Callback, Condition = Condition
	};
	
	CW.kernel:CreateTimer("EntityCondTimer"..uniqueID, 0, 0, function()
		if (!IsValid(player)) then
			CW.kernel:DestroyTimer("EntityCondTimer"..uniqueID);
			Callback(false);
			return;
		end;
		
		local traceLine = player:GetEyeTraceNoCursor();
		
		if (IsValid(target) and IsValid(realEntity) and traceLine.Entity == realEntity
		and traceLine.Entity:GetPos():Distance(player:GetShootPos()) <= distance
		and Condition()) then
			if (CurTime() >= realDelay) then
				Callback(true); player.cwConditionEntTimer = nil;
				CW.kernel:DestroyTimer("EntityCondTimer"..uniqueID);
			end;
		else
			Callback(false); player.cwConditionEntTimer = nil;
			CW.kernel:DestroyTimer("EntityCondTimer"..uniqueID);
		end;
	end);
end;

-- A function to get a player's spawn ammo.
function CW.player:GetSpawnAmmo(player, ammo)
	if (ammo) then
		return player.cwSpawnAmmo[ammo];
	else
		return player.cwSpawnAmmo;
	end;
end;

-- A function to get a player's spawn weapon.
function CW.player:GetSpawnWeapon(player, weapon)
	if (weapon) then
		return player.cwSpawnWeps[weapon];
	else
		return player.cwSpawnWeps;
	end;
end;

-- A function to take spawn ammo from a player.
function CW.player:TakeSpawnAmmo(player, ammo, amount)
	if (player.cwSpawnAmmo[ammo]) then
		if (player.cwSpawnAmmo[ammo] < amount) then
			amount = player.cwSpawnAmmo[ammo];
			
			player.cwSpawnAmmo[ammo] = nil;
		else
			player.cwSpawnAmmo[ammo] = player.cwSpawnAmmo[ammo] - amount;
		end;
		
		player:RemoveAmmo(amount, ammo);
	end;
end;

-- A function to give the player spawn ammo.
function CW.player:GiveSpawnAmmo(player, ammo, amount)
	if (player.cwSpawnAmmo[ammo]) then
		player.cwSpawnAmmo[ammo] = player.cwSpawnAmmo[ammo] + amount;
	else
		player.cwSpawnAmmo[ammo] = amount;
	end;
	
	player:GiveAmmo(amount, ammo);
end;

-- A function to take a player's spawn weapon.
function CW.player:TakeSpawnWeapon(player, class)
	player.cwSpawnWeps[class] = nil;
	player:StripWeapon(class);
end;

-- A function to give a player a spawn weapon.
function CW.player:GiveSpawnWeapon(player, class)
	player.cwSpawnWeps[class] = true;
	player:Give(class);
end;

-- A function to give a player an item weapon.
function CW.player:GiveItemWeapon(player, itemTable)
	if (CW.item:IsWeapon(itemTable)) then
		player:Give(itemTable("weaponClass"), itemTable);
		return true;
	end;
end;

-- A function to give a player a spawn item weapon.
function CW.player:GiveSpawnItemWeapon(player, itemTable)
	if (CW.item:IsWeapon(itemTable)) then
		player.cwSpawnWeps[itemTable("weaponClass")] = true;
		player:Give(itemTable("weaponClass"), itemTable);
		
		return true;
	end;
end;

-- A function to give flags to a character.
function CW.player:GiveFlags(player, flags)
	for i = 1, #flags do
		local flag = string.utf8sub(flags, i, i);
		
		if (!string.find(player:GetFlags(), flag)) then
			player:SetCharacterData("Flags", player:GetFlags()..flag, true);
			
			plugin.Call("PlayerFlagsGiven", player, flag);
		end;
	end;
end;

-- A function to give flags to a player.
function CW.player:GivePlayerFlags(player, flags)
	for i = 1, #flags do
		local flag = string.utf8sub(flags, i, i);
		
		if (!string.find(player:GetPlayerFlags(), flag)) then
			player:SetData("Flags", player:GetPlayerFlags()..flag, true);

			plugin.Call("PlayerFlagsGiven", player, flag);
		end;
	end;
end;

-- A function to play a sound to a player.
function CW.player:PlaySound(player, sound)
	netstream.Start(player, "PlaySound",sound);
end;

-- A function to get a player's maximum characters.
function CW.player:GetMaximumCharacters(player)
	local maximum = CW.config:Get("additional_characters"):Get();
	
	for k, v in pairs(CW.faction:GetAll()) do
		if (!v.whitelist or self:IsWhitelisted(player, v.name)) then
			maximum = maximum + 1;
		end;
	end;
	
	return maximum;
end;

-- A function to query a player's character.
function CW.player:Query(player, key, default)
	local character = player:GetCharacter();
	
	if (character) then
		key = CW.kernel:SetCamelCase(key, true);
		
		if (character[key] != nil) then
			return character[key];
		end;
	end;
	
	return default;
end;

-- A function to set a player to a safe position.
function CW.player:SetSafePosition(player, position, filter)
	position = self:GetSafePosition(player, position, filter);
	
	if (position) then
		player:SetMoveType(MOVETYPE_NOCLIP);
		player:SetPos(position);
		
		if (player:IsInWorld()) then
			player:SetMoveType(MOVETYPE_WALK);
		else
			player:Spawn();
		end;
	end;
end;

-- A function to get the safest position near a position.
function CW.player:GetSafePosition(player, position, filter)
	local closestPosition = nil;
	local distanceAmount = 8;
	local directions = {};
	local yawForward = player:EyeAngles().yaw;
	local angles = {
		math.NormalizeAngle(yawForward - 180),
		math.NormalizeAngle(yawForward - 135),
		math.NormalizeAngle(yawForward + 135),
		math.NormalizeAngle(yawForward + 45),
		math.NormalizeAngle(yawForward + 90),
		math.NormalizeAngle(yawForward - 45),
		math.NormalizeAngle(yawForward - 90),
		math.NormalizeAngle(yawForward)
	};
	
	position = position + Vector(0, 0, 32);
	
	if (!filter) then
		filter = {player};
	elseif (type(filter) != "table") then
		filter = {filter};
	end;
	
	if (!table.HasValue(filter, player)) then
		filter[#filter + 1] = player;
	end;
	
	for i = 1, 8 do
		for k, v in pairs(angles) do
			directions[#directions + 1] = {v, distanceAmount};
		end;
		
		distanceAmount = distanceAmount * 2;
	end;
	
	-- A function to get a lower position.
	local function GetLowerPosition(testPosition, ignoreHeight)
		local trace = {
			filter = filter,
			endpos = testPosition - Vector(0, 0, 256),
			start = testPosition
		};
		
		return util.TraceLine(trace).HitPos + Vector(0, 0, 32);
	end;
	
	local trace = {
		filter = filter,
		endpos = position + Vector(0, 0, 256),
		start = position
	};
	
	local safePosition = GetLowerPosition(util.TraceLine(trace).HitPos);
	
	if (safePosition) then
		position = safePosition;
	end;
	
    for k, v in pairs(directions) do
		local angleVector = Angle(0, v[1], 0):Forward();
		local testPosition = position + (angleVector * v[2]);
		
		local trace = {
			filter = filter,
			endpos = testPosition,
			start = position
		};
		
		local traceLine = util.TraceEntity(trace, player);
		
		if (traceLine.Hit) then
			trace = {
				filter = filter,
				endpos = traceLine.HitPos - (angleVector * v[2]),
				start = traceLine.HitPos
			};
			
			traceLine = util.TraceEntity(trace, player);
			
			if (!traceLine.Hit) then
				position = traceLine.HitPos;
			end;
		end;
		
		if (!traceLine.Hit) then
			break;
		end;
    end;
	
    for k, v in pairs(directions) do
		local angleVector = Angle(0, v[1], 0):Forward();
		local testPosition = position + (angleVector * v[2]);
		
		local trace = {
			filter = filter,
			endpos = testPosition,
			start = position
		};
		
		local traceLine = util.TraceEntity(trace, player);
		
		if (!traceLine.Hit) then
			return traceLine.HitPos;
		end;
    end;
	
	return position;
end;

-- Called to convert a player's data to a string.
function CW.player:ConvertDataString(player, data)
	local bSuccess, value = pcall(util.JSONToTable, data);
	
	if (bSuccess and value != nil) then
		return value;
	else
		return {};
	end;
end;

-- A function to return a player's property.
function CW.player:ReturnProperty(player)
	local uniqueID = player:UniqueID();
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		if (IsValid(v)) then
			if (uniqueID == CW.entity:QueryProperty(v, "uniqueID")) then
				if (key == CW.entity:QueryProperty(v, "key")) then
					self:GiveProperty(player, v, CW.entity:QueryProperty(v, "networked"));
				end;
			end;
		end;
	end;
	
	plugin.Call("PlayerReturnProperty", player);
end;

-- A function to take flags from a character.
function CW.player:TakeFlags(player, flags)
	for i = 1, #flags do
		local flag = string.utf8sub(flags, i, i);
		
		if (string.find(player:GetFlags(), flag)) then
			player:SetCharacterData("Flags", string.gsub(player:GetFlags(), flag, ""), true);
			
			plugin.Call("PlayerFlagsTaken", player, flag);
		end;
	end;
end;

-- A function to take flags from a player.
function CW.player:TakePlayerFlags(player, flags)
	for i = 1, #flags do
		local flag = string.utf8sub(flags, i, i);
		
		if (string.find(player:GetPlayerFlags(), flag)) then
			player:SetData("Flags", string.gsub(player:GetFlags(), flag, ""), true);

			plugin.Call("PlayerFlagsTaken", player, flag);
		end;
	end;
end;

-- A function to set whether a player's menu is open.
function CW.player:SetMenuOpen(player, isOpen)
	netstream.Start(player, "MenuOpen", isOpen);
end;

-- A function to set whether a player has intialized.
function CW.player:SetInitialized(player, initialized)
	player:SetSharedVar("Initialized", initialized);
end;

-- A function to check if a player has any flags.
function CW.player:HasAnyFlags(player, flags, bByDefault)
	if (player:GetCharacter()) then
		local playerFlags = player:GetFlags();
		
		if (CW.class:HasAnyFlags(player:Team(), flags) and !bByDefault) then
			return true;
		end;
		
		for i = 1, #flags do
			local flag = string.utf8sub(flags, i, i);
			local bSuccess = true;
			
			if (!bByDefault) then
				local hasFlag = plugin.Call("PlayerDoesHaveFlag", player, flag);
				
				if (hasFlag != false) then
					if (hasFlag) then
						return true;
					end;
				else
					bSuccess = nil;
				end;
			end;
			
			if (bSuccess) then
				if (flag == "s") then
					if (player:IsSuperAdmin()) then
						return true;
					end;
				elseif (flag == "a") then
					if (player:IsAdmin()) then
						return true;
					end;
				elseif (flag == "o") then
					if (player:IsSuperAdmin() or player:IsAdmin()) then
						return true;
					elseif (player:IsUserGroup("operator")) then
						return true;
					end;
				elseif (string.find(playerFlags, flag)) then
					return true;
				end;
			end;
		end;
	end;
end;

-- A function to check if a player has flags.
function CW.player:HasFlags(player, flags, bByDefault)
	if (player:GetCharacter()) then
		local playerFlags = player:GetFlags();
		
		if (CW.class:HasFlags(player:Team(), flags) and !bByDefault) then
			return true;
		end;
		
		for i = 1, #flags do
			local flag = string.utf8sub(flags, i, i);
			local bSuccess;
			
			if (!bByDefault) then
				local hasFlag = plugin.Call("PlayerDoesHaveFlag", player, flag);
				
				if (hasFlag != false) then
					if (hasFlag) then
						bSuccess = true;
					end;
				else
					return;
				end;
			end;
			
			if (!bSuccess) then
				if (flag == "s") then
					if (!player:IsSuperAdmin()) then
						return;
					end;
				elseif (flag == "a") then
					if (!player:IsAdmin()) then
						return;
					end;
				elseif (flag == "o") then
					if (!player:IsSuperAdmin() and !player:IsAdmin()) then
						if (!player:IsUserGroup("operator")) then
							return;
						end;
					end;
				elseif (!string.find(playerFlags, flag)) then
					return;
				end;
			end;
		end;
		
		return true;
	end;
end;

-- A function to use a player's death code.
function CW.player:UseDeathCode(player, commandTable, arguments)
	plugin.Call("PlayerDeathCodeUsed", player, commandTable, arguments);
	
	self:TakeDeathCode(player);
end;

-- A function to get whether a player has a death code.
function CW.player:GetDeathCode(player, authenticated)
	if (player.cwDeathCodeIdx and (!authenticated or player.cwDeathCodeAuth)) then
		return player.cwDeathCodeIdx;
	end;
end;

-- A function to take a player's death code.
function CW.player:TakeDeathCode(player)
	player.cwDeathCodeAuth = nil;
	player.cwDeathCodeIdx = nil;
end;

-- A function to give a player their death code.
function CW.player:GiveDeathCode(player)
	player.cwDeathCodeIdx = math.random(0, 99999);
	player.cwDeathCodeAuth = nil;
	
	netstream.Start(player, "ChatBoxDeathCode", player.cwDeathCodeIdx);
end;

-- A function to take a door from a player.
function CW.player:TakeDoor(player, door, bForce, bThisDoorOnly, bChildrenOnly)
	local doorCost = CW.config:Get("door_cost"):Get();
	
	if (!bThisDoorOnly) then
		local doorParent = CW.entity:GetDoorParent(door);
		
		if (!doorParent or bChildrenOnly) then
			for k, v in pairs(CW.entity:GetDoorChildren(door)) do
				if (IsValid(v)) then
					self:TakeDoor(player, v, true, true);
				end;
			end;
		else
			return self:TakeDoor(player, doorParent, bForce);
		end;
	end;
	
	if (plugin.Call("PlayerCanUnlockEntity", player, door)) then
		door:Fire("Unlock", "", 0);
		door:EmitSound("doors/door_latch3.wav");
	end;
	
	CW.entity:SetDoorText(door, false);
	self:TakeProperty(player, door);
	
	plugin.Call("PlayerDoorTaken", player, door)
	
	if (door:GetClass() == "prop_dynamic") then
		if (!door:IsMapEntity()) then
			door:Remove();
		end;
	end;
	
	if (!force and doorCost > 0) then
		self:GiveCash(player, doorCost / 2, "selling a door");
	end;
end;

-- A function to make a player say text as a radio broadcast.
function CW.player:SayRadio(player, text, check, noEavesdrop)
	local eavesdroppers = {};
	local listeners = {};
	local canRadio = true;
	local info = {listeners = {}, noEavesdrop = noEavesdrop, text = text};
	
	plugin.Call("PlayerAdjustRadioInfo", player, info);
	
	for k, v in pairs(info.listeners) do
		if (typeof(v) == "player") then
			table.insert(listeners, v);
		elseif (typeof(k) == "player") then
			table.insert(listeners, k);
		end;
	end;
	
	if (!info.noEavesdrop) then
		for k, v in ipairs(_player.GetAll()) do
			if (v:HasInitialized() and !table.HasValue(listeners, v)) then
				if (v:GetShootPos():Distance(player:GetShootPos()) <= CW.config:Get("talk_radius"):Get()) then
					table.insert(eavesdroppers, v);
				end;
			end;
		end;
	end;
	
	if (check) then
		canRadio = plugin.Call("PlayerCanRadio", player, info.text, listeners, eavesdroppers);
	end;
	
	if (canRadio) then
		info = chatbox.AddText(listeners, "\""..info.text.."\"", {suffix = " radios: ", sender = player, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(10, 200, 10, 255)});
		
		if (info and IsValid(info.sender)) then
			chatbox.AddText(eavesdroppers, info.text, {suffix = " radios: ", sender = player, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(255, 255, 200, 255)});

			plugin.Call("PlayerRadioUsed", player, info.text, listeners, eavesdroppers);
		end;
	end;
end;

-- A function to get a player's faction table.
function CW.player:GetFactionTable(player)
	return CW.faction:GetAll()[player:GetFaction()];
end;

-- A function to give a door to a player.
function CW.player:GiveDoor(player, door, name, unsellable, override)
	if (CW.entity:IsDoor(door)) then
		local doorParent = CW.entity:GetDoorParent(door);
		
		if (doorParent and !override) then
			self:GiveDoor(player, doorParent, name, unsellable);
		else
			for k, v in pairs(CW.entity:GetDoorChildren(door)) do
				if (IsValid(v)) then
					self:GiveDoor(player, v, name, unsellable, true);
				end;
			end;
			
			door.unsellable = unsellable;
			door.accessList = {};
			
			CW.entity:SetDoorText(door, name or "A purchased door.");
			self:GiveProperty(player, door, true);
			
			plugin.Call("PlayerDoorGiven", player, door)
			
			if (plugin.Call("PlayerCanUnlockEntity", player, door)) then
				door:EmitSound("doors/door_latch3.wav");
				door:Fire("Unlock", "", 0);
			end;
		end;
	end;
end;

-- A function to get a player's real trace.
function CW.player:GetRealTrace(player, useFilterTrace)
	local eyePos = player:EyePos();
	local trace = player:GetEyeTraceNoCursor();
	
	local newTrace = util.TraceLine({
		endpos = eyePos + (player:GetAimVector() * 4096),
		filter = player,
		start = eyePos,
		mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
	});
	
	if ((IsValid(newTrace.Entity) and (!IsValid(trace.Entity)
	or trace.Entity:IsVehicle()) and !newTrace.HitWorld) or useFilterTrace) then
		trace = newTrace;
	end;
	
	return trace;
end;

-- A function to check if a player recognises another player.
function CW.player:DoesRecognise(player, target, status, isAccurate)
	if (!status) then
		return self:DoesRecognise(player, target, RECOGNISE_PARTIAL);
	elseif (CW.config:Get("recognise_system"):Get()) then
		local recognisedNames = player:GetRecognisedNames();
		local realValue = false;
		local key = target:GetCharacterKey();
		
		if (recognisedNames and recognisedNames[key]) then
			if (isAccurate) then
				realValue = (recognisedNames[key] == status);
			else
				realValue = (recognisedNames[key] >= status);
			end;
		end;
		
		return plugin.Call("PlayerDoesRecognisePlayer", player, target, status, isAccurate, realValue);
	else
		return true;
	end;
end;

function CW.player:GetName(player, target)
	if (CW.player:DoesRecognise(player, target)) then
		return target:Name();
	else
		return CW.player:GetUnrecognisedName(target);
	end;
end;

-- A function to send a player a creation fault.
function CW.player:SetCreateFault(player, fault)
	if (!fault) then
		fault = "There has been an unknown error, please contact the administrator!";
	end;
	
	netstream.Start(player, "CharacterFinish", {bSuccess = false, fault = fault});
end;

-- A function to force a player to delete a character.
function CW.player:ForceDeleteCharacter(player, characterID)
	local charactersTable = CW.config:Get("mysql_characters_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local character = player.cwCharacterList[characterID];
	
	if (character) then
		local queryObj = cwDatabase:Delete(charactersTable);
			queryObj:AddWhere("_Schema = ?", schemaFolder);
			queryObj:AddWhere("_SteamID = ?", player:SteamID());
			queryObj:AddWhere("_CharacterID = ?", characterID);
		queryObj:Push();
		
		if (!plugin.Call("PlayerDeleteCharacter", player, character)) then
			CW.kernel:PrintLog(LOGTYPE_GENERIC, player:SteamName().." has deleted the character '"..character.name.."'.");
		end;
		
		player.cwCharacterList[characterID] = nil;
		
		netstream.Start(player, "CharacterRemove", characterID);
	end;
end;

-- A function to delete a player's character.
function CW.player:DeleteCharacter(player, characterID)
	local character = player.cwCharacterList[characterID];
	
	if (character) then
		if (player:GetCharacter() != character) then
			local fault = plugin.Call("PlayerCanDeleteCharacter", player, character);
			
			if (fault == nil or fault == true) then
				self:ForceDeleteCharacter(player, characterID);
				
				return true;
			elseif (type(fault) != "string") then
				return false, "You cannot delete this character!";
			else
				return false, fault;
			end;
		else
			return false, "You cannot delete the character you are using!";
		end;
	else
		return false, "This character does not exist!";
	end;
end;

-- A function to use a player's character.
function CW.player:UseCharacter(player, characterID)
	local isCharacterMenuReset = player:IsCharacterMenuReset();
	local currentCharacter = player:GetCharacter();
	local character = player.cwCharacterList[characterID];
	
	if (!character) then
		return false, "This character does not exist!";
	end;
	
	if (currentCharacter != character or isCharacterMenuReset) then
		local factionTable = CW.faction:FindByID(character.faction);
		local fault = plugin.Call("PlayerCanUseCharacter", player, character);
		
		if (fault == nil or fault == true) then
			local players = #CW.faction:GetPlayers(character.faction);
			local limit = CW.faction:GetLimit(factionTable.name);
			
			if (isCharacterMenuReset and character.faction == currentCharacter.faction) then
				players = players - 1;
			end;
				
			if (plugin.Call("PlayerCanBypassFactionLimit", player, character)) then
				limit = nil;
			end;
			
			if (limit and players == limit) then
				return false, "The "..character.faction.." faction is full ("..limit.."/"..limit..")!";
			else
				if (currentCharacter) then
					local fault = plugin.Call("PlayerCanSwitchCharacter", player, character);
					
					if (fault != nil and fault != true) then
						return false, fault or "You cannot switch to this character!";
					end;
				end;
				
				CW.kernel:PrintLog(LOGTYPE_GENERIC, player:SteamName().." has loaded the character '"..character.name.."'.");
				
				if (isCharacterMenuReset) then
					player.cwCharMenuReset = false;
					player:Spawn();
				else
					self:LoadCharacter(player, characterID);
				end;
				
				return true;
			end;
		else
			return false, fault or "You cannot use this character!";
		end;
	else
		return false, "You are already using this character!";
	end;
end;

-- A function to get a player's character.
function CW.player:GetCharacter(player)
	return player.cwCharacter;
end;

-- A function to get a player's unrecognised name.
function CW.player:GetUnrecognisedName(player, bFormatted)
	local unrecognisedPhysDesc = self:GetPhysDesc(player);
	local unrecognisedName = CW.config:Get("unrecognised_name"):Get();
	local usedPhysDesc = false;
	
	if (unrecognisedPhysDesc != "") then
		unrecognisedName = unrecognisedPhysDesc;
		usedPhysDesc = true;
	end;
	
	if (bFormatted) then
		if (string.utf8len(unrecognisedName) > 24) then
			unrecognisedName = string.utf8sub(unrecognisedName, 1, 21).."...";
		end;
		
		unrecognisedName = "["..unrecognisedName.."]";
	end;
	
	return unrecognisedName, usedPhysDesc;
end;

-- A function to format text based on a relationship.
function CW.player:FormatRecognisedText(player, text, ...)
	local arguments = {...};

	for i = 1, #arguments do
		if (string.find(text, "%%s") and IsValid(arguments[i])) then
			local unrecognisedName = "["..self:GetUnrecognisedName(arguments[i]).."]";
			
			if (self:DoesRecognise(player, arguments[i])) then
				unrecognisedName = arguments[i]:Name();
			end;
			
			text = string.gsub(text, "%%s", unrecognisedName, 1);
		end;
	end;
	
	return text;
end;

-- A function to restore a recognised name.
function CW.player:RestoreRecognisedName(player, target)
	local recognisedNames = player:GetRecognisedNames();
	local key = target:GetCharacterKey();
	
	if (recognisedNames[key]) then
		if (plugin.Call("PlayerCanRestoreRecognisedName", player, target)) then
			self:SetRecognises(player, target, recognisedNames[key], true);
		else
			recognisedNames[key] = nil;
		end;
	end;
end;

-- A function to restore a player's recognised names.
function CW.player:RestoreRecognisedNames(player)
	netstream.Start(player, "ClearRecognisedNames", true);
	
	if (CW.config:Get("save_recognised_names"):Get()) then
		for k, v in pairs(_player.GetAll()) do
			if (v:HasInitialized()) then
				self:RestoreRecognisedName(player, v);
				self:RestoreRecognisedName(v, player);
			end;
		end;
	end;
end;

-- A function to set whether a player recognises a player.
function CW.player:SetRecognises(player, target, status, bForce)
	local recognisedNames = player:GetRecognisedNames();
	local name = target:Name();
	local key = target:GetCharacterKey();
	
	--[[ I have no idea why this would happen. --]]
	if (key == nil) then return end;
	
	if (status == RECOGNISE_SAVE) then
		if (CW.config:Get("save_recognised_names"):Get()) then
			if (!plugin.Call("PlayerCanSaveRecognisedName", player, target)) then
				status = RECOGNISE_TOTAL;
			end;
		else
			status = RECOGNISE_TOTAL;
		end;
	end;
	
	if (!status or bForce or !self:DoesRecognise(player, target, status)) then
		recognisedNames[key] = status or nil;
		
		netstream.Start(player, "RecognisedName", {
			key = key, status = (status or 0)
		});
	end;
end;

-- A function to get a player's physical description.
function CW.player:GetPhysDesc(player)
	local physDesc = player:GetSharedVar("PhysDesc");
	local team = player:Team();
	
	if (physDesc == "") then
		physDesc = CW.class:Query(team, "defaultPhysDesc", "");
	end;
	
	if (physDesc == "") then
		physDesc = CW.config:Get("default_physdesc"):Get();
	end;
	
	if (!physDesc or physDesc == "") then
		physDesc = "This character has no physical description set.";
	else
		physDesc = CW.kernel:ModifyPhysDesc(physDesc);
	end;
	
	local override = plugin.Call("GetPlayerPhysDescOverride", player, physDesc);
	
	if (override) then
		physDesc = override;
	end;
	
	return physDesc;
end;

-- A function to clear a player's recognised names list.
function CW.player:ClearRecognisedNames(player, status, isAccurate)
	if (!status) then
		local character = player:GetCharacter();
		
		if (character) then
			character.recognisedNames = {};
			
			netstream.Start(player, "ClearRecognisedNames", true);
		end;
	else
		for k, v in pairs(_player.GetAll()) do
			if (v:HasInitialized()) then
				if (self:DoesRecognise(player, v, status, isAccurate)) then
					self:SetRecognises(player, v, false);
				end;
			end;
		end;
	end;
	
	plugin.Call("PlayerRecognisedNamesCleared", player, status, isAccurate);
end;

-- A function to clear a player's name from being recognised.
function CW.player:ClearName(player, status, isAccurate)
	for k, v in pairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			if (!status or self:DoesRecognise(v, player, status, isAccurate)) then
				self:SetRecognises(v, player, false);
			end;
		end;
	end;
	
	plugin.Call("PlayerNameCleared", player, status, isAccurate);
end;

-- A function to holsters all of a player's weapons.
function CW.player:HolsterAll(player)
	for k, v in pairs(player:GetWeapons()) do
		local class = v:GetClass();
		local itemTable = CW.item:GetByWeapon(v);
		
		if (itemTable and plugin.Call("PlayerCanHolsterWeapon", player, itemTable, v, true, true)) then
			plugin.Call("PlayerHolsterWeapon", player, itemTable, v, true);
			player:StripWeapon(class);
			player:GiveItem(itemTable, true);
		end;
	end;
	
	player:SelectWeapon("cw_hands");
end;

-- A function to set whether a player's character is banned.
function CW.player:SetBanned(player, banned)
	player:SetCharacterData("CharBanned", banned);
	player:SaveCharacter();
	player:SetSharedVar("CharBanned", banned);
end;

-- A function to set a player's name.
function CW.player:SetName(player, name, saveless)
	local previousName = player:Name();
	local newName = name;
	
	player:SetCharacterData("Name", newName, true);
	player:SetSharedVar("Name", newName);
	
	if (!player.cwFirstSpawn) then
		plugin.Call("PlayerNameChanged", player, previousName, newName);
	end;
	
	if (!saveless) then
		player:SaveCharacter();
	end;
end;

-- A function to get a player's property entities.
function CW.player:GetPropertyEntities(player, class)
	local uniqueID = player:UniqueID();
	local entities = {};
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		if (uniqueID == CW.entity:QueryProperty(v, "uniqueID")) then
			if (key == CW.entity:QueryProperty(v, "key")) then
				if (!class or v:GetClass() == class) then
					entities[#entities + 1] = v;
				end;
			end;
		end;
	end;
	
	return entities;
end;

-- A function to get a player's property count.
function CW.player:GetPropertyCount(player, class)
	local uniqueID = player:UniqueID();
	local count = 0;
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		if (uniqueID == CW.entity:QueryProperty(v, "uniqueID")) then
			if (key == CW.entity:QueryProperty(v, "key")) then
				if (!class or v:GetClass() == class) then
					count = count + 1;
				end;
			end;
		end;
	end;
	
	return count;
end;

-- A function to get a player's door count.
function CW.player:GetDoorCount(player)
	local uniqueID = player:UniqueID();
	local count = 0;
	local key = player:GetCharacterKey();
	
	for k, v in pairs(self:GetAllProperty()) do
		if (CW.entity:IsDoor(v) and !CW.entity:GetDoorParent(v)) then
			if (uniqueID == CW.entity:QueryProperty(v, "uniqueID")) then
				if (player:GetCharacterKey() == CW.entity:QueryProperty(v, "key")) then
					count = count + 1;
				end;
			end;
		end;
	end;
	
	return count;
end;

-- A function to take a player's door access.
function CW.player:TakeDoorAccess(player, door)
	if (door.accessList) then
		door.accessList[player:GetCharacterKey()] = false;
	end;
end;

-- A function to give a player door access.
function CW.player:GiveDoorAccess(player, door, access)
	local key = player:GetCharacterKey();
	
	if (!door.accessList) then
		door.accessList = {
			[key] = access
		};
	else
		door.accessList[key] = access;
	end;
end;

-- A function to check if a player has door access.
function CW.player:HasDoorAccess(player, door, access, isAccurate)
	if (!access) then
		return self:HasDoorAccess(player, door, DOOR_ACCESS_BASIC, isAccurate);
	else
		local doorParent = CW.entity:GetDoorParent(door);
		local key = player:GetCharacterKey();
		
		if (doorParent and CW.entity:DoorHasSharedAccess(doorParent)
		and (!door.accessList or door.accessList[key] == nil)) then
			return plugin.Call("PlayerDoesHaveDoorAccess", player, doorParent, access, isAccurate);
		else
			return plugin.Call("PlayerDoesHaveDoorAccess", player, door, access, isAccurate);
		end;
	end;
end;

-- A function to check if a player can afford an amount.
function CW.player:CanAfford(player, amount)
	if (CW.config:Get("cash_enabled"):Get()) then
		return (player:GetCash() >= amount);
	else
		return true;
	end;
end;

-- A function to give a player an amount of cash.
function CW.player:GiveCash(player, amount, reason, bNoMsg)
	if (CW.config:Get("cash_enabled"):Get()) then
		local positiveHintColor = "positive_hint";
		local negativeHintColor = "negative_hint";
		local roundedAmount = math.Round(amount);
		local cash = math.Round(math.max(player:GetCash() + roundedAmount, 0));
		
		player:SetCharacterData("Cash", cash, true);
		player:SetSharedVar("Cash", cash);
		
		if (roundedAmount < 0) then
			roundedAmount = math.abs(roundedAmount);
			
			if (!bNoMsg) then
				if (reason) then
					cwHint:Send(
						player, "Your character has lost the sum of "..CW.kernel:FormatCash(roundedAmount).." ("..reason..").", 4, negativeHintColor
					);
				else
					cwHint:Send(
						player, "Your character has lost the sum of "..CW.kernel:FormatCash(roundedAmount)..".", 4, negativeHintColor
					);
				end;
			end;
		elseif (roundedAmount > 0) then
			if (!bNoMsg) then
				if (reason) then
					cwHint:Send(
						player, "Your character has gained the sum of  "..CW.kernel:FormatCash(roundedAmount).." ("..reason..").", 4, positiveHintColor
					);
				else
					cwHint:Send(
						player, "Your character has gained the sum of "..CW.kernel:FormatCash(roundedAmount)..".", 4, positiveHintColor
					);
				end;
			end;
		end;
		
		plugin.Call("PlayerCashUpdated", player, roundedAmount, reason, bNoMsg);
	end;
end;

CW.player:AddToMetaTable("Player", "GiveCash");

-- A function to show cinematic text to a player.
function CW.player:CinematicText(player, text, color, barLength, hangTime)
	netstream.Start(player, "CinematicText", {
		text = text,
		color = color,
		barLength = barLength,
		hangTime = hangTime
	});
end;

-- A function to show cinematic text to each player.
function CW.player:CinematicTextAll(text, color, hangTime)
	for k, v in pairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			self:CinematicText(v, text, color, hangTime);
		end;
	end;
end;

-- A function to find a player by an identifier.
function CW.player:FindByID(identifier)
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized() and (v:SteamID() == identifier or v:UniqueID() == identifier
		or string.find(string.lower(v:Name()), string.lower(identifier), 1, true))) then
			return v;
		end;
	end;
end;

-- A function to get if a player is protected.
function CW.player:IsProtected(identifier)
	local steamID = nil;
	local ownerSteamID = CW.config:Get("owner_steamid"):Get();
	local bSuccess, value = pcall(IsValid, identifier);
		
	if (!bSuccess or value == false) then
		local playerObj = self:FindByID(identifier);

		if (IsValid(playerObj)) then
			steamID = playerObj:SteamID();
		end;
	else
		steamID = identifier:SteamID();
	end;
	
	if (string.find(ownerSteamID, ",")) then
		ownerSteamID = string.gsub(ownerSteamID, " ", "");
		ownerSteamID = string.Split(ownerSteamID, ",");

		for k, v in pairs(ownerSteamID) do
			if (steamID and steamID == v) then
				return true;
			end;
		end;
	else
		if (steamID and steamID == ownerSteamID) then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to notify each player in a radius.
function CW.player:NotifyInRadius(text, class, position, radius)
	local listeners = {};
	
	for k, v in pairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			if (position:Distance(v:GetPos()) <= radius) then
				listeners[#listeners + 1] = v;
			end;
		end;
	end;
	
	self:Notify(listeners, text, class);
end;

-- A function to notify each player.
function CW.player:NotifyAll(text, icon)
	self:Notify(nil, text, true, icon);
end;

--[[
	@codebase Server
	@details A function to notify admins by rank.
	@param String The rank and up that will be notified.
	@param String The text that will be sent to each admin.
	@param String The name of the icon that will be used in the message, can be nil.
--]]
function CW.player:NotifyAdmins(adminLevel, text, icon)
	for k, v in pairs(player.GetAll()) do
		if (adminLevel == "operator" or adminLevel == "o") then
			if (v:IsAdmin()) then
				self:Notify(v, text, true, icon);
			end;
		elseif (adminLevel == "admin" or adminLevel == "a") then
			if (v:IsAdmin() and !v:IsUserGroup("operator")) then
				self:Notify(v, text, true, icon);
			end;
		elseif (adminLevel == "superadmin" or adminLevel == "s") then
			if (v:IsSuperAdmin()) then
				self:Notify(v, text, true, icon);
			end;
		end;
	end;
end;

-- A function to notify a player.
function CW.player:Notify(player, text, class, icon)
	if (type(player) == "table") then
		for k, v in pairs(player) do
			self:Notify(v, text, class);
		end;
	elseif (class == true) then
		if (icon) then
			local data = {icon = icon};
			chatbox.AddText(player, text, data);
		else
			chatbox.AddText(player, text);
		end;
	elseif (!class) then
		if (icon) then
			local data = {icon = icon};
			chatbox.AddText(player, text, data);
		else
			chatbox.AddText(player, text);
		end;
	else
		netstream.Start(player, "Notification", {text = text, class = class});
	end;
end;

CW.player:AddToMetaTable("Player", "Notify");

-- A function to set a player's weapons list from a table.
function CW.player:SetWeapons(player, weapons, bForceReturn)
	for k, v in pairs(weapons) do
		if (!player:HasWeapon(v.weaponData["class"])) then
			if (!v.teamIndex or player:Team() == v.teamIndex) then
				player:Give(
					v.weaponData["class"], v.weaponData["itemTable"], bForceReturn
				);
			end;
		end;
	end;
end;

-- A function to give ammo to a player from a table.
function CW.player:GiveAmmo(player, ammo)
	for k, v in pairs(ammo) do player:GiveAmmo(v, k); end;
end;

-- A function to set a player's ammo list from a table.
function CW.player:SetAmmo(player, ammo)
	for k, v in pairs(ammo) do player:SetAmmo(v, k); end;
end;

-- A function to get a player's ammo list as a table.
function CW.player:GetAmmo(player, bDoStrip)
	local spawnAmmo = self:GetSpawnAmmo(player);
	local ammoTypes = {};
	local ammo = {};

	for k, v in pairs(CW.item:GetAll()) do
		if (v.ammoClass) then
			ammoTypes[v.ammoClass] = true;
		end;
	end;

	plugin.Call("AdjustAmmoTypes", ammoTypes);

	if (ammoTypes) then
		for k, v in pairs(ammoTypes) do
			if (v) then
				ammo[k] = player:GetAmmoCount(k);
			end;
		end;
	end;
	
	if (spawnAmmo) then
		for k, v in pairs(spawnAmmo) do
			if (ammo[k]) then
				ammo[k] = math.max(ammo[k] - v, 0);
			end;
		end;
	end;
	
	if (bDoStrip) then
		player:RemoveAllAmmo();
	end;

	return ammo;
end;

-- A function to get a player's weapons list as a table.
function CW.player:GetWeapons(player, bDoKeep)
	local weapons = {};
	
	for k, v in pairs(player:GetWeapons()) do
		local itemTable = CW.item:GetByWeapon(v);
		local teamIndex = player:Team();
		local class = v:GetClass();
		
		if (!self:GetSpawnWeapon(player, class)) then
			teamIndex = nil;
		end;
		
		weapons[#weapons + 1] = {
			weaponData = {
				itemTable = itemTable,
				class = class
			},
			teamIndex = teamIndex
		};
		
		if (!bDoKeep) then
			player:StripWeapon(class);
		end;
	end;
	
	return weapons;
end;

-- A function to get the total weight of a player's equipped weapons.
function CW.player:GetEquippedWeight(player)
	local weight = 0;
	
	for k, v in pairs(player:GetWeapons()) do
		local itemTable = CW.item:GetByWeapon(v);
		
		if (itemTable) then
			weight = weight + itemTable("weight");
		end;
	end;
	
	return weight;
end;

-- A function to get the total space of a player's equipped weapons.
function CW.player:GetEquippedSpace(player)
	local space = 0;
	
	for k, v in pairs(player:GetWeapons()) do
		local itemTable = CW.item:GetByWeapon(v);
		
		if (itemTable) then
			space = space + itemTable("space");
		end;
	end;
	
	return space;
end;

-- A function to get a player's holstered weapon.
function CW.player:GetHolsteredWeapon(player)
	for k, v in pairs(player:GetWeapons()) do
		local itemTable = CW.item:GetByWeapon(v);
		local class = v:GetClass();
		
		if (itemTable) then
			if (self:GetWeaponClass(player) != class) then
				return class;
			end;
		end;
	end;
end;

-- A function to check whether a player is ragdolled.
function CW.player:IsRagdolled(player, exception, bNoEntity)
	if (player:GetRagdollEntity() or bNoEntity) then
		local ragdolled = player:GetDTInt(4);
		
		if (ragdolled == exception) then
			return false;
		else
			return (ragdolled != RAGDOLL_NONE);
		end;
	end;
end;

-- A function to set a player's unragdoll time.
function CW.player:SetUnragdollTime(player, delay)
	player.cwRagdollPaused = nil;
	
	if (delay) then
		self:SetAction(player, "unragdoll", delay, 2, function()
			if (IsValid(player) and player:Alive()) then
				self:SetRagdollState(player, RAGDOLL_NONE);
			end;
		end);
	else
		self:SetAction(player, "unragdoll", false);
	end;
end;

-- A function to pause a player's unragdoll time.
function CW.player:PauseUnragdollTime(player)
	if (!player.cwRagdollPaused) then
		local unragdollTime = self:GetUnragdollTime(player);
		local curTime = CurTime();
		
		if (player:IsRagdolled()) then
			if (unragdollTime > 0) then
				player.cwRagdollPaused = unragdollTime - curTime;
				self:SetAction(player, "unragdoll", false);
			end;
		end;
	end;
end;

-- A function to start a player's unragdoll time.
function CW.player:StartUnragdollTime(player)
	if (player.cwRagdollPaused) then
		if (player:IsRagdolled()) then
			self:SetUnragdollTime(player, player.cwRagdollPaused);
			
			player.cwRagdollPaused = nil;
		end;
	end;
end;

-- A function to get a player's unragdoll time.
function CW.player:GetUnragdollTime(player)
	local action, actionDuration, startActionTime = self:GetAction(player);
	
	if (action == "unragdoll") then
		return startActionTime + actionDuration;
	else
		return 0;
	end;
end;

-- A function to get a player's ragdoll state.
function CW.player:GetRagdollState(player)
	return player:GetDTInt(4);
end;

-- A function to get a player's ragdoll entity.
function CW.player:GetRagdollEntity(player)
	if (player.cwRagdollTab) then
		if (IsValid(player.cwRagdollTab.entity)) then
			return player.cwRagdollTab.entity;
		end;
	end;
end;

-- A function to get a player's ragdoll table.
function CW.player:GetRagdollTable(player)
	return player.cwRagdollTab;
end;

-- A function to do a player's ragdoll decay check.
function CW.player:DoRagdollDecayCheck(player, ragdoll)
	local index = ragdoll:EntIndex();
	
	CW.kernel:CreateTimer("DecayCheck"..index, 60, 0, function()
		local ragdollIsValid = IsValid(ragdoll);
		local playerIsValid = IsValid(player);
		
		if (!playerIsValid and ragdollIsValid) then
			if (!CW.entity:IsDecaying(ragdoll)) then
				local decayTime = CW.config:Get("body_decay_time"):Get();
				
				if (decayTime > 0 and plugin.Call("PlayerCanRagdollDecay", player, ragdoll, decayTime)) then
					CW.entity:Decay(ragdoll, decayTime);
				end;
			else
				CW.kernel:DestroyTimer("DecayCheck"..index);
			end;
		elseif (!ragdollIsValid) then
			CW.kernel:DestroyTimer("DecayCheck"..index);
		end;
	end);
end;

-- A function to set a player's ragdoll immunity.
function CW.player:SetRagdollImmunity(player, delay)
	if (delay) then
		player:GetRagdollTable().immunity = CurTime() + delay;
	else
		player:GetRagdollTable().immunity = 0;
	end;
end;

-- A function to set a player's ragdoll state.
function CW.player:SetRagdollState(player, state, delay, decay, force, multiplier, velocityCallback)
	if (state == RAGDOLL_KNOCKEDOUT or state == RAGDOLL_FALLENOVER) then
		if (player:IsRagdolled()) then
			if (plugin.Call("PlayerCanRagdoll", player, state, delay, decay, player.cwRagdollTab)) then
				self:SetUnragdollTime(player, delay);
					player:SetDTInt(4, state);
					player.cwRagdollTab.delay = delay;
					player.cwRagdollTab.decay = decay;
				plugin.Call("PlayerRagdolled", player, state, player.cwRagdollTab);
			end;
		elseif (plugin.Call("PlayerCanRagdoll", player, state, delay, decay)) then
			local velocity = player:GetVelocity() + (player:GetAimVector() * 128);
			local ragdoll = ents.Create("prop_ragdoll");
			
			ragdoll:SetMaterial(player:GetMaterial());
			ragdoll:SetAngles(player:GetAngles());
			ragdoll:SetColor(player:GetColor());
			ragdoll:SetModel(player:GetModel());
			ragdoll:SetSkin(player:GetSkin());
			ragdoll:SetPos(player:GetPos());
			ragdoll:Spawn();
			
			player.cwRagdollTab = {};
			player.cwRagdollTab.eyeAngles = player:EyeAngles();
			player.cwRagdollTab.immunity = CurTime() + CW.config:Get("ragdoll_immunity_time"):Get();
			player.cwRagdollTab.moveType = MOVETYPE_WALK;
			player.cwRagdollTab.entity = ragdoll;
			player.cwRagdollTab.health = player:Health();
			player.cwRagdollTab.armor = player:Armor();
			player.cwRagdollTab.delay = delay;
			player.cwRagdollTab.decay = decay;
			
			if (!player:IsOnGround()) then
				player.cwRagdollTab.immunity = 0;
			end;
			
			if (IsValid(ragdoll)) then
				local headIndex = ragdoll:LookupBone("ValveBiped.Bip01_Head1");
				
				ragdoll:SetCollisionGroup(COLLISION_GROUP_WEAPON);
				
				for i = 1, ragdoll:GetPhysicsObjectCount() do
					local physicsObject = ragdoll:GetPhysicsObjectNum(i);
					local boneIndex = ragdoll:TranslatePhysBoneToBone(i);
					local position, angle = player:GetBonePosition(boneIndex);
					
					if (IsValid(physicsObject)) then
						physicsObject:SetPos(position);
						physicsObject:SetAngles(angle);
						
						if (!velocityCallback) then
							if (boneIndex == headIndex) then
								physicsObject:SetVelocity(velocity * 1.5);
							else
								physicsObject:SetVelocity(velocity);
							end;
							
							if (force) then
								if (boneIndex == headIndex) then
									physicsObject:ApplyForceCenter(force * 1.5);
								else
									physicsObject:ApplyForceCenter(force);
								end;
							end;
						else
							velocityCallback(physicsObject, boneIndex, ragdoll, velocity, force);
						end;
					end;
				end;
			end;
			
			if (player:Alive()) then
				if (IsValid(player:GetActiveWeapon())) then
					player.cwRagdollTab.weapon = self:GetWeaponClass(player);
				end;
				
				player.cwRagdollTab.weapons = self:GetWeapons(player, true);
				
				if (delay) then
					self:SetUnragdollTime(player, delay);
				end;
			end;
			
			if (player:InVehicle()) then
				player:ExitVehicle();
				player.cwRagdollTab.eyeAngles = Angle(0, 0, 0);
			end;
			
			if (player:IsOnFire()) then
				ragdoll:Ignite(8, 0);
			end;
			
			player:Spectate(OBS_MODE_CHASE);
			player:RunCommand("-duck");
			player:RunCommand("-voicerecord");
			player:SetMoveType(MOVETYPE_OBSERVER);
			player:StripWeapons(true);
			player:SpectateEntity(ragdoll);
			player:CrosshairDisable();
			
			if (player:FlashlightIsOn()) then
				player:Flashlight(false);
			end;
			
			player.cwRagdollPaused = nil;
			
			player:SetDTInt(4, state);
			player:SetDTEntity(2, ragdoll);
			
			if (state != RAGDOLL_FALLENOVER) then
				self:GiveDeathCode(player);
			end;
			
			CW.entity:SetPlayer(ragdoll, player);
			self:DoRagdollDecayCheck(player, ragdoll);
			
			plugin.Call("PlayerRagdolled", player, state, player.cwRagdollTab);
		end;
	elseif (state == RAGDOLL_NONE or state == RAGDOLL_RESET) then
		if (player:IsRagdolled(nil, true)) then
			local ragdollTable = player:GetRagdollTable();
			
			if (plugin.Call("PlayerCanUnragdoll", player, state, ragdollTable)) then
				player:UnSpectate();
				player:CrosshairEnable();
				
				if (state != RAGDOLL_RESET) then
					self:LightSpawn(player, nil, nil, true);
				end;
				
				if (state != RAGDOLL_RESET) then
					if (IsValid(ragdollTable.entity)) then
						local velocity = ragdollTable.entity:GetVelocity();
						local position = CW.entity:GetPelvisPosition(ragdollTable.entity);
						
						if (position) then
							self:SetSafePosition(player, position, ragdollTable.entity);
						end;
						
						player:SetSkin(ragdollTable.entity:GetSkin());
						player:SetColor(ragdollTable.entity:GetColor());
						player:SetMaterial(ragdollTable.entity:GetMaterial());
						
						if (!ragdollTable.model) then
							player:SetModel(ragdollTable.entity:GetModel());
						else
							player:SetModel(ragdollTable.model);
						end;
						
						if (!ragdollTable.skin) then
							player:SetSkin(ragdollTable.entity:GetSkin());
						else
							player:SetSkin(ragdollTable.skin);
						end;
						
						player:SetVelocity(velocity);
					end;
					
					player:SetArmor(ragdollTable.armor);
					player:SetHealth(ragdollTable.health);
					player:SetMoveType(ragdollTable.moveType);
					player:SetEyeAngles(ragdollTable.eyeAngles);
				end;
				
				if (IsValid(ragdollTable.entity)) then
					CW.kernel:DestroyTimer("DecayCheck"..ragdollTable.entity:EntIndex());
					
					if (ragdollTable.decay) then
						if (plugin.Call("PlayerCanRagdollDecay", player, ragdollTable.entity, ragdollTable.decay)) then
							CW.entity:Decay(ragdollTable.entity, ragdollTable.decay);
						end;
					else
						ragdollTable.entity:Remove();
					end;
				end;
				
				if (state != RAGDOLL_RESET) then
					self:SetWeapons(player, ragdollTable.weapons, true);
					
					if (ragdollTable.weapon) then
						player:SelectWeapon(ragdollTable.weapon);
					end;
				end;
				
				self:SetUnragdollTime(player, false);
					player:SetDTInt(4, RAGDOLL_NONE);
					player:SetDTEntity(2, NULL);
				plugin.Call("PlayerUnragdolled", player, state, ragdollTable);
				
				player.cwRagdollPaused = nil;
				player.cwRagdollTab = {};
			end;
		end;
	end;
end;

-- A function to make a player drop their weapons.
function CW.player:DropWeapons(player)
	local ragdollEntity = player:GetRagdollEntity();
	
	if (player:IsRagdolled()) then
		local ragdollWeapons = player:GetRagdollWeapons();
		
		for k, v in pairs(ragdollWeapons) do
			local itemTable = v.weaponData["itemTable"];
			
			if (itemTable and plugin.Call("PlayerCanDropWeapon", player, itemTable, NULL, true)) then
				local info = {
					itemTable = itemTable,
					position = ragdollEntity:GetPos() + Vector(0, 0, math.random(1, 48)),
					angles = Angle(0, 0, 0)
				};
				
				player:TakeItem(info.itemTable, true);
				ragdollWeapons[k] = nil;
				
				if (plugin.Call("PlayerAdjustDropWeaponInfo", player, info)) then
					local entity = CW.entity:CreateItem(player, info.itemTable, info.position, info.angles);
					
					if (IsValid(entity)) then
						plugin.Call("PlayerDropWeapon", player, info.itemTable, entity, NULL);
					end;
				end;
			end;
		end;
	else
		for k, v in pairs(player:GetWeapons()) do
			local itemTable = CW.item:GetByWeapon(v);
			
			if (itemTable and plugin.Call("PlayerCanDropWeapon", player, itemTable, v, true)) then
				local info = {
					itemTable = itemTable,
					position = player:GetPos() + Vector(0, 0, math.random(1, 48)),
					angles = Angle(0, 0, 0)
				};
				
				if (plugin.Call("PlayerAdjustDropWeaponInfo", player, info)) then
					local entity = CW.entity:CreateItem(
						player, info.itemTable, info.position, info.angles
					);
					
					if (IsValid(entity)) then
						plugin.Call("PlayerDropWeapon", player, info.itemTable, entity, v);
						player:StripWeapon(v:GetClass());
						player:TakeItem(info.itemTable, true);
					end;
				end;
			end;
		end;
	end;
end;

-- A function to lightly spawn a player.
function CW.player:LightSpawn(player, weapons, ammo, bForceReturn)
	if (player:IsRagdolled() and !bForceReturn) then
		self:SetRagdollState(player, RAGDOLL_NONE);
	end;
	
	player.cwLightSpawn = true;
	
	local moveType = player:GetMoveType();
	local material = player:GetMaterial();
	local position = player:GetPos();
	local angles = player:EyeAngles();
	local weapon = player:GetActiveWeapon();
	local health = player:Health();
	local armor = player:Armor();
	local model = player:GetModel();
	local color = player:GetColor();	
	local skin = player:GetSkin();
	
	if (ammo) then
		if (type(ammo) != "table") then
			ammo = self:GetAmmo(player, true);
		end;
	end;
	
	if (weapons) then
		if (type(weapons) != "table") then
			weapons = self:GetWeapons(player);
		end;
		
		if (IsValid(weapon)) then
			weapon = weapon:GetClass();
		end;
	end;
	
	player.cwSpawnCallback = function(player, gamemodeHook)
		if (weapons) then
			CW:PlayerLoadout(player);
			
			self:SetWeapons(player, weapons, bForceReturn);
			
			if (type(weapon) == "string") then
				player:SelectWeapon(weapon);
			end;
		end;
		
		if (ammo) then
			self:GiveAmmo(player, ammo);
		end;
		
		player:SetPos(position);
		player:SetSkin(skin);
		player:SetModel(model);
		player:SetColor(color);
		player:SetArmor(armor);
		player:SetHealth(health);
		player:SetMaterial(material);
		player:SetMoveType(moveType);
		player:SetEyeAngles(angles);
		
		if (gamemodeHook) then
			special = special or false;
			
			plugin.Call("PostPlayerLightSpawn", player, weapons, ammo, special);
		end;
		
		player:ResetSequence(
			player:GetSequence()
		);
	end;
	
	player:Spawn();
end;

-- A function to convert a table to camel case.
function CW.player:ConvertToCamelCase(baseTable)
	local newTable = {};
	
	for k, v in pairs(baseTable) do
		local key = CW.kernel:SetCamelCase(string.gsub(k, "_", ""), true);
		
		if (key and key != "") then
			newTable[key] = v;
		end;
	end;
	
	return newTable;
end;

-- A function to get a player's characters.
function CW.player:GetCharacters(player, Callback)
	if (!IsValid(player)) then return; end;
	
	local charactersTable = CW.config:Get("mysql_characters_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local queryObj = cwDatabase:Select(charactersTable);
		queryObj:AddWhere("_Schema = ?", schemaFolder);
		queryObj:AddWhere("_SteamID = ?", player:SteamID());
		queryObj:SetCallback(function(result)
			if (!IsValid(player)) then return; end;
			
			if (cwDatabase:IsResult(result)) then
				local characters = {};
				
				for k, v in pairs(result) do
					characters[k] = self:ConvertToCamelCase(v);
				end;
				
				Callback(characters);
			else
				Callback();
			end;
		end);
	queryObj:Pull();
end;

-- A function to add a character to the character screen.
function CW.player:CharacterScreenAdd(player, character)
	local info = {
		name = character.name,
		model = character.model,
		banned = character.data["CharBanned"],
		faction = character.faction,
		characterID = character.characterID
	};
	
	if (character.data["PhysDesc"]) then
		if (string.utf8len(character.data["PhysDesc"]) > 64) then
			info.details = string.utf8sub(character.data["PhysDesc"], 1, 64).."...";
		else
			info.details = character.data["PhysDesc"];
		end;
	end;
	
	if (character.data["CharBanned"]) then
		info.details = "This character is banned.";
	end;
	
	plugin.Call("PlayerAdjustCharacterScreenInfo", player, character, info);
	netstream.Start(player, "CharacterAdd", info);
end;

-- A function to convert a character's MySQL variables to Lua variables.
function CW.player:ConvertCharacterMySQL(baseTable)
	baseTable.recognisedNames = self:ConvertCharacterRecognisedNamesString(baseTable.recognisedNames);
	baseTable.characterID = tonumber(baseTable.characterID);
	baseTable.attributes = self:ConvertCharacterDataString(baseTable.attributes);
	baseTable.inventory = CW.inventory:ToLoadable(
		self:ConvertCharacterDataString(baseTable.inventory)
	);
	baseTable.cash = tonumber(baseTable.cash);
	baseTable.ammo = self:ConvertCharacterDataString(baseTable.ammo);
	baseTable.data = self:ConvertCharacterDataString(baseTable.data);
	baseTable.key = tonumber(baseTable.key);
end;

-- A function to get a player's character ID.
function CW.player:GetCharacterID(player)
	local character = player:GetCharacter();
	
	if (character) then
		for k, v in pairs(player:GetCharacters()) do
			if (v == character) then
				return k;
			end;
		end;
	end;
end;

-- A function to load a player's character.
function CW.player:LoadCharacter(player, characterID, tMergeCreate, Callback, bForce)
	local character = {};
	local unixTime = os.time();
	
	if (tMergeCreate) then
		character = {};
		character.name = name;
		character.data = {};
		character.ammo = {};
		character.cash = CW.config:Get("default_cash"):Get();
		character.model = "models/police.mdl";
		character.flags = "b";
		character.schema = CW.kernel:GetSchemaFolder();
		character.gender = GENDER_MALE;
		character.faction = FACTION_CITIZEN;
		character.steamID = player:SteamID();
		character.steamName = player:SteamName();
		character.inventory = {};
		character.attributes = {};
		character.onNextLoad = "";
		character.lastPlayed = unixTime;
		character.timeCreated = unixTime;
		character.characterID = characterID;
		character.recognisedNames = {};
		
		if (!player.cwCharacterList[characterID]) then
			table.Merge(character, tMergeCreate);
			
			if (character and type(character) == "table") then
				character.inventory = {};
				plugin.Call(
					"GetPlayerDefaultInventory", player, character, character.inventory
				);
				
				if (!bForce) then
					local fault = plugin.Call("PlayerCanCreateCharacter", player, character, characterID);
					
					if (fault == false or type(fault) == "string") then
						return self:SetCreateFault(player, fault or "You cannot create this character!");
					end;
				end;
				
				self:SaveCharacter(player, true, character, function(key)
					player.cwCharacterList[characterID] = character;
					player.cwCharacterList[characterID].key = key;
					
					plugin.Call("PlayerCharacterCreated", player, character);
					self:CharacterScreenAdd(player, character);
					
					if (Callback) then
						Callback();
					end;
				end);
			end;
		end;
	else
		character = player.cwCharacterList[characterID];
		
		if (character) then
			if (player:GetCharacter()) then
				self:SaveCharacter(player);
				self:UpdateCharacter(player);
				
				plugin.Call("PlayerCharacterUnloaded", player);
			end;
			
			player.cwCharacter = character;
			
			if (player:Alive()) then
				player:KillSilent();
			end;
			
			if (self:SetBasicSharedVars(player)) then
				plugin.Call("PlayerCharacterLoaded", player);
				player:SaveCharacter();
			end;
		end;
	end;
end;

-- A function to set a player's basic shared variables.
function CW.player:SetBasicSharedVars(player)
	local gender = player:GetGender();
	local faction = player:GetFaction();
	
	player:SetSharedVar("Flags", player:GetFlags());
	player:SetSharedVar("Model", self:GetDefaultModel(player));
	player:SetSharedVar("Name", player:Name());
	player:SetSharedVar("Key", player:GetCharacterKey());
	
	if (CW.faction:GetAll()[faction]) then
		player:SetSharedVar("Faction", CW.faction:GetAll()[faction].index);
	end;
	
	if (gender == GENDER_MALE) then
		player:SetSharedVar("Gender", 2);
	else
		player:SetSharedVar("Gender", 1);
	end;
	
	return true;
end;

-- A function to get the character's ammo as a string.
function CW.player:GetCharacterAmmoString(player, character, bRawTable)
	local ammo = table.Copy(character.ammo);
	
	for k, v in pairs(self:GetAmmo(player)) do
		if (v > 0) then
			ammo[k] = v;
		end;
	end;
	
	if (!bRawTable) then
		return util.TableToJSON(ammo);
	else
		return ammo;
	end;
end;

-- A function to get the character's data as a string.
function CW.player:GetCharacterDataString(player, character, bRawTable)
	local data = table.Copy(character.data);
	plugin.Call("PlayerSaveCharacterData", player, data);
	
	if (!bRawTable) then
		return util.TableToJSON(data);
	else
		return data;
	end;
end;

-- A function to get the character's recognised names as a string.
function CW.player:GetCharacterRecognisedNamesString(player, character)
	local recognisedNames = {};
	
	for k, v in pairs(character.recognisedNames) do
		if (v == RECOGNISE_SAVE) then
			recognisedNames[#recognisedNames + 1] = k;
		end;
	end;
	
	return util.TableToJSON(recognisedNames);
end;

-- A function to get the character's inventory as a string.
function CW.player:GetCharacterInventoryString(player, character, bRawTable)
	local inventory = CW.inventory:CreateDuplicate(character.inventory);
	plugin.Call("PlayerAddToSavedInventory", player, character, function(itemTable)
		CW.inventory:AddInstance(inventory, itemTable);
	end);
	
	if (!bRawTable) then
		return util.TableToJSON(CW.inventory:ToSaveable(inventory));
	else
		return inventory;
	end;
end;

-- A function to convert a character's recognised names string to a table.
function CW.player:ConvertCharacterRecognisedNamesString(data)
	local bSuccess, value = pcall(util.JSONToTable, data);
	
	if (bSuccess and value != nil) then
		local recognisedNames = {};
		
		for k, v in pairs(value) do
			recognisedNames[v] = RECOGNISE_SAVE;
		end;
		
		return recognisedNames;
	else
		return {};
	end;
end;

-- A function to convert a character's data string to a table.
function CW.player:ConvertCharacterDataString(data)
	local bSuccess, value = pcall(util.JSONToTable, data);
	
	if (bSuccess and value != nil) then
		return value;
	else
		return {};
	end;
end;

-- A function to load a player's data.
function CW.player:LoadData(player, Callback)
	local playersTable = CW.config:Get("mysql_players_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local unixTime = os.time();
	local steamID = player:SteamID();
	
	local queryObj = cwDatabase:Select(playersTable);
		queryObj:AddWhere("_Schema = ?", schemaFolder);
		queryObj:AddWhere("_SteamID = ?", steamID);
		queryObj:SetCallback(function(result)
			if (!IsValid(player) or player.cwData) then
				return;
			end;
			
			local onNextPlay = "";
			
			if (cwDatabase:IsResult(result)) then
				player.cwTimeJoined = tonumber(result[1]._TimeJoined);
				player.cwLastPlayed = tonumber(result[1]._LastPlayed);
				player.cwUserGroup = result[1]._UserGroup;
				player.cwData = self:ConvertDataString(player, result[1]._Data);
				
				onNextPlay = result[1]._OnNextPlay;
			else
				player.cwTimeJoined = unixTime;
				player.cwLastPlayed = unixTime;
				player.cwUserGroup = "user";
				player.cwData = self:SaveData(player, true);
			end;
			
			if (self:IsProtected(player)) then
				player.cwUserGroup = "superadmin";
			end;
			
			if (!player.cwUserGroup or player.cwUserGroup == "") then
				player.cwUserGroup = "user";
			end;
			
			if (!CW.config:Get("use_own_group_system"):Get()
			and player.cwUserGroup != "user") then
				player:SetUserGroup(player.cwUserGroup);
			end;
			
			plugin.Call("PlayerRestoreData", player, player.cwData);
			
			if (Callback and IsValid(player)) then
				Callback(player);
			end;
			
			if (onNextPlay != "") then
				local updateObj = cwDatabase:Update(playersTable);
					updateObj:SetValue("_OnNextPlay", "");
					updateObj:SetValue("_SteamID", steamID);
					updateObj:SetValue("_Schema", schemaFolder);
				updateObj:Push();
				
				PLAYER = player;
					RunString(onNextPlay);
				PLAYER = nil;
			end;
		end);
	queryObj:Pull();
	
	timer.Simple(2, function()
		if (IsValid(player) and !player.cwData) then
			self:LoadData(player, Callback);
		end;
	end);
end;

-- A function to save a players's data.
function CW.player:SaveData(player, bCreate)
	if (!bCreate) then
		local schemaFolder = CW.kernel:GetSchemaFolder();
		local steamName = cwDatabase:Escape(player:SteamName());
		local ipAddress = player:IPAddress();
		local userGroup = player:GetClockworkUserGroup();
		local steamID = player:SteamID();
		local data = table.Copy(player.cwData);
		
		plugin.Call("PlayerSaveData", player, data);
		
		local playersTable = CW.config:Get("mysql_players_table"):Get();
		local queryObj = cwDatabase:Update(playersTable);
			queryObj:AddWhere("_Schema = ?", schemaFolder);
			queryObj:AddWhere("_SteamID = ?", steamID);
			queryObj:SetValue("_LastPlayed", os.time());
			queryObj:SetValue("_SteamName", steamName);
			queryObj:SetValue("_IPAddress", ipAddress);
			queryObj:SetValue("_UserGroup", userGroup);
			queryObj:SetValue("_SteamID", steamID);
			queryObj:SetValue("_Schema", schemaFolder);
			queryObj:SetValue("_Data", util.TableToJSON(data));
		queryObj:Push();
	else
		local playersTable = CW.config:Get("mysql_players_table"):Get();
		local queryObj = cwDatabase:Insert(playersTable);
			queryObj:SetValue("_Data", "");
			queryObj:SetValue("_Schema", CW.kernel:GetSchemaFolder());
			queryObj:SetValue("_SteamID", player:SteamID());
			queryObj:SetValue("_Donations", "");
			queryObj:SetValue("_UserGroup", "user");
			queryObj:SetValue("_IPAddress", player:IPAddress());
			queryObj:SetValue("_SteamName", player:SteamName());
			queryObj:SetValue("_OnNextPlay", "");
			queryObj:SetValue("_LastPlayed", os.time());
			queryObj:SetValue("_TimeJoined", os.time());
		queryObj:Push();
		
		return {};
	end;
end;

-- A function to update a player's character.
function CW.player:UpdateCharacter(player)
	player.cwCharacter.inventory = self:GetCharacterInventoryString(player, player.cwCharacter, true);
	player.cwCharacter.ammo = self:GetCharacterAmmoString(player, player.cwCharacter, true);
	player.cwCharacter.data = self:GetCharacterDataString(player, player.cwCharacter, true);
end;

-- A function to save a player's character.
function CW.player:SaveCharacter(player, bCreate, character, Callback)
	if (bCreate) then
		local charactersTable = CW.config:Get("mysql_characters_table"):Get();
		local values = "";
		local amount = 1;
		local keys = "";
		
		if (!character or type(character) != "table") then
			character = player:GetCharacter();
		end;
		
		local queryObj = cwDatabase:Insert(charactersTable);
			for k, v in pairs(character) do
				local tableKey = "_"..CW.kernel:SetCamelCase(k, false);
				
				if (k == "recognisedNames") then
					queryObj:SetValue(tableKey, util.TableToJSON(character.recognisedNames));
				elseif (k == "attributes") then
					queryObj:SetValue(tableKey, util.TableToJSON(character.attributes));
				elseif (k == "inventory") then
					queryObj:SetValue(tableKey, util.TableToJSON(CW.inventory:ToSaveable(character.inventory)));
				elseif (k == "ammo") then
					queryObj:SetValue(tableKey, util.TableToJSON(character.ammo));
				elseif (k == "data") then
					queryObj:SetValue(tableKey, util.TableToJSON(v));
				else
					queryObj:SetValue(tableKey, v);
				end;
			end;
			if (system.IsWindows()) then
				queryObj:SetCallback(function(result, status, lastID)
					if (Callback and tonumber(lastID)) then
						Callback(tonumber(lastID));
					end;
				end);
			elseif (system.IsLinux()) then
				queryObj:SetCallback(function(result, status, lastID)
					if (Callback) then
						Callback(tonumber(lastID));
					end;
				end);
			end;
			queryObj:SetFlag(2);
		queryObj:Push();
	elseif (player:HasInitialized()) then
		local currentCharacter = player:GetCharacter();
		local charactersTable = CW.config:Get("mysql_characters_table"):Get();
		local schemaFolder = CW.kernel:GetSchemaFolder();
		local unixTime = os.time();
		local steamID = player:SteamID();
		
		if (!character) then
			character = player:GetCharacter();
		end;
		
		local queryObj = cwDatabase:Update(charactersTable);
			queryObj:AddWhere("_Schema = ?", schemaFolder);
			queryObj:AddWhere("_SteamID = ?", steamID);
			queryObj:AddWhere("_CharacterID = ?", character.characterID);
			queryObj:SetValue("_RecognisedNames", self:GetCharacterRecognisedNamesString(player, character));
			queryObj:SetValue("_Attributes", util.TableToJSON(character.attributes));
			queryObj:SetValue("_LastPlayed", unixTime);
			queryObj:SetValue("_SteamName", player:SteamName());
			queryObj:SetValue("_Faction", character.faction);
			queryObj:SetValue("_Gender", character.gender);
			queryObj:SetValue("_Schema", character.schema);
			queryObj:SetValue("_Model", character.model);
			queryObj:SetValue("_Flags", character.flags);
			queryObj:SetValue("_Cash", character.cash);
			queryObj:SetValue("_Name", character.name);
		
			if (currentCharacter == character) then
				queryObj:SetValue("_Inventory", self:GetCharacterInventoryString(player, character));
				queryObj:SetValue("_Ammo", self:GetCharacterAmmoString(player, character));
				queryObj:SetValue("_Data", self:GetCharacterDataString(player, character));
			else
				queryObj:SetValue("_Inventory", util.TableToJSON(CW.inventory:ToSaveable(character.inventory)));
				queryObj:SetValue("_Ammo", util.TableToJSON(character.ammo));
				queryObj:SetValue("_Data", util.TableToJSON(character.data));
			end;
		queryObj:Push();
		
		--[[ Save the player's data after pushing the update. --]]
		CW.player:SaveData(player);
	end;
end;

-- A function to get the class of a player's active weapon.
function CW.player:GetWeaponClass(player, safe)
	if (IsValid(player:GetActiveWeapon())) then
		return player:GetActiveWeapon():GetClass();
	else
		return safe;
	end;
end;

-- A function to call a player's think hook.
function CW.player:CallThinkHook(player, setSharedVars, curTime)
	local infoTable = player.cwInfoTable;

	infoTable.inventoryWeight = CW.config:Get("default_inv_weight"):Get();
	infoTable.inventorySpace = CW.config:Get("default_inv_space"):Get();
	infoTable.crouchedSpeed = player.cwCrouchedSpeed;
	infoTable.jumpPower = player.cwJumpPower;
	infoTable.walkSpeed = player.cwWalkSpeed;
	infoTable.isRunning = player:IsRunning();
	infoTable.isJogging = player:IsJogging();
	infoTable.runSpeed = player.cwRunSpeed;
	infoTable.wages = CW.class:Query(player:Team(), "wages", 0);
	
	if (!player:IsJogging(true)) then
		infoTable.isJogging = nil;
		player:SetSharedVar("IsJogMode", false);
	end;
	
	if (setSharedVars) then
		plugin.Call("PlayerSetSharedVars", player, curTime);
		player.cwNextSetSharedVars = curTime + 1;
	end;
	
	player.nextPlayerSecond = player.nextPlayerSecond or curTime;
	
	plugin.Call("PlayerThink", player, curTime, infoTable);
	
	if (CurTime() > player.nextPlayerSecond) then
		plugin.Call("OnePlayerSecond", player, curTime, infoTable);
		player.nextPlayerSecond = CurTime() + 1;
	end;
end;

-- A function to get a player's wages.
function CW.player:GetWages(player)
	return player:GetSharedVar("Wages");
end;

-- A function to set a character's flags.
function CW.player:SetFlags(player, flags)
	self:TakeFlags(player, player:GetFlags());
	self:GiveFlags(player, flags);
end;

-- A function to set a player's flags.
function CW.player:SetPlayerFlags(player, flags)
	self:TakePlayerFlags(player, player:GetPlayerFlags());
	self:GivePlayerFlags(player, flags);
end;

-- A function to set a player's rank within their faction.
function CW.player:SetFactionRank(player, rank)
	if (rank) then
		local faction = CW.faction:FindByID(player:GetFaction());

		if (faction and istable(faction.ranks)) then
			for k, v in pairs(faction.ranks) do
				if (k == rank) then
					player:SetCharacterData("factionrank", k);

					if (v.class and CW.class:GetAll()[v.class]) then
						CW.class:Set(player, v.class);
					end;

					if (v.model) then
						player:SetModel(v.model);
					end;

					if (istable(v.weapons)) then
						for k, v in pairs(v.weapons) do
							self:GiveSpawnWeapon(player, v);
						end;
					end;

					break;
				end;
			end;
		end;
	end;
end;

-- A function to get a player's global flags.
function CW.player:GetPlayerFlags(player)
	return player:GetData("Flags") or "";
end;

end;

CW.player.playerData = CW.player.playerData or {};
CW.player.characterData = CW.player.characterData or {};

--[[
	@codebase Shared
	@details Add a new character data type that can be synced over the network.
	@param String The name of the data type (can be pretty much anything.)
	@param Int The type of the object (must be a type of NWTYPE_* enum).
	@param Various The default value of the data type.
	@param Function Alter the value that gets networked.
	@param Bool Whether or not the data is networked to the player only (defaults to false.)
--]]
function CW.player:AddCharacterData(name, nwType, default, playerOnly, callback)
	CW.player.characterData[name] = {
		default = default,
		nwType = nwType,
		callback = callback,
		playerOnly = playerOnly
	};
end;

--[[
	@codebase Shared
	@details Add a new player data type that can be synced over the network.
	@param String The name of the data type (can be pretty much anything.)
	@param Int The type of the object (must be a type of NWTYPE_* enum).
	@param Various The default value of the data type.
	@param Function Alter the value that gets networked.
	@param Bool Whether or not the data is networked to the player only (defaults to false.)
--]]
function CW.player:AddPlayerData(name, nwType, default, playerOnly, callback)
	CW.player.playerData[name] = {
		default = default,
		nwType = nwType,
		callback = callback,
		playerOnly = playerOnly
	};
end;

--[[
	@codebase Shared
	@details A function to get a player's rank within their faction.
	@param Userdata The player whose faction rank you are trying to obtain.
--]]
function CW.player:GetFactionRank(player, character)
	if (character) then
		local faction = CW.faction:FindByID(character.faction);
		
		if (faction and istable(faction.ranks)) then
			local rank;
			
			for k, v in pairs(faction.ranks) do
				if (k == character.data["factionrank"]) then
					rank = v;
					break;
				end;
			end;
			
			return character.data["factionrank"], rank;
		end;
	else
		local faction = CW.faction:FindByID(player:GetFaction());
		
		if (faction and istable(faction.ranks)) then
			local rank;
			
			for k, v in pairs(faction.ranks) do
				if (k == player:GetCharacterData("factionrank")) then
					rank = v;
					break;
				end;
			end;
			
			return player:GetCharacterData("factionrank"), rank;
		end;
	end;
end;

--[[
	@codebase Shared
	@details A function to check if a player can promote the target.
	@param Userdata The player whose permissions you are trying to check.
	@param Userdata The player who may be promoted.
--]]
function CW.player:CanPromote(player, target)
	local stringRank, rank = CW.player:GetFactionRank(player);

	if (rank) then
		if (rank.canPromote) then
			local stringTargetRank, targetRank = CW.player:GetFactionRank(target);
			local highestRank, rankTable = CW.faction:GetHighestRank(player:Faction()).position;

			if (targetRank.position and targetRank.position != rankTable.position) then
				return (rank.canPromote <= targetRank.position);
			end;
		end;
	end;
end;

--[[
	@codebase Shared
	@details A function to check if a player can demote the target.
	@param Userdata The player whose permissions you are trying to check.
	@param Userdata The player who may be demoted.
--]]
function CW.player:CanDemote(player, target)
	local stringRank, rank = CW.player:GetFactionRank(player);

	if (rank) then
		if (rank.canDemote) then
			local stringTargetRank, targetRank = CW.player:GetFactionRank(target);
			local lowestRank, rankTable = CW.faction:GetLowestRank(player:Faction()).position;

			if (targetRank.position and targetRank.position != rankTable.position) then
				return (rank.canDemote <= targetRank.position);
			end;
		end;
	end;
end;