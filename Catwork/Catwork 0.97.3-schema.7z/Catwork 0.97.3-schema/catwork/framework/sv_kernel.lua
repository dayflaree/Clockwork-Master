--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[ Initiate the shared booting process. --]]
include("sh_boot.lua");

--[[ Downloads the content addon for clients. --]]
resource.AddWorkshop("474315121")

--[[
	Derive from Sandbox, because we want the spawn menu and such!
	We also want the base Sandbox entities and weapons.
--]]
DeriveGamemode("sandbox");

--[[
	This is a hack to stop file.Read returning an unnecessary newline
	at the end of each file when using Linux.
--]]
if (system.IsLinux()) then
	ClockworkFileRead = ClockworkFileRead or file.Read;

	function file.Read(fileName, pathName)
		local contents = ClockworkFileRead(fileName, pathName);
		
		if (contents and string.utf8sub(contents, -1) == "\n") then
			contents = string.utf8sub(contents, 1, -2);
		end;
		
		return contents;
	end;
end;

oldFileioWrite = oldFileioWrite or fileio.Write;

function fileio.Write(fileName, content)
	local exploded = string.Explode("/", fileName);
	local curPath = "";
	
	for k, v in ipairs(exploded) do
		if (string.GetExtensionFromFilename(v) != nil) then
			break;
		end;
		
		curPath = curPath..v.."/";
		
		if (!file.Exists(curPath, "GAME")) then
			fileio.MakeDirectory(curPath);
		end;
	end;
	
	oldFileioWrite(fileName, content);
end;

--[[
	@codebase Server
	@details Called when the Clockwork kernel has loaded.
--]]
function CW:ClockworkKernelLoaded() end;

--[[
	@codebase Server
	@details Called when the Clockwork schema has loaded.
--]]
function CW:ClockworkSchemaLoaded() end;

--[[
	@codebase Server
	@details Called when the server has initialized.
--]]
function CW:Initialize()
	self.item:Initialize();
		self.config:Import("gamemodes/catwork/clockwork.cfg");
	plugin.Call("ClockworkKernelLoaded");
	
	local useLocalMachineDate = self.config:Get("use_local_machine_date"):Get();
	local useLocalMachineTime = self.config:Get("use_local_machine_time"):Get();
	local defaultDate = self.option:GetKey("default_date");
	local defaultTime = self.option:GetKey("default_time");
	local defaultDays = self.option:GetKey("default_days");
	local username = self.config:Get("mysql_username"):Get();
	local password = self.config:Get("mysql_password"):Get();
	local database = self.config:Get("mysql_database"):Get();
	local dateInfo = os.date("*t");
	local host = string.gsub(self.config:Get("mysql_host"):Get(), "^http[s]?://", "", 1); -- Matches at beginning of string, matches http:// or https://, no need to check twice
	local port = self.config:Get("mysql_port"):Get();
	
	self.database:Connect(host, username, password, database, port);
	
	if (useLocalMachineTime) then
		self.config:Get("minute_time"):Set(60);
	end;
	
	self.config:SetInitialized(true);
	
	table.Merge(self.time, defaultTime);
	table.Merge(self.date, defaultDate);
	math.randomseed(os.time());
	
	if (useLocalMachineTime) then
		local realDay = dateInfo.wday - 1;
		
		if (realDay == 0) then
			realDay = #defaultDays;
		end;
		
		table.Merge(self.time, {
			minute = dateInfo.min,
			hour = dateInfo.hour,
			day = realDay
		});
		
		self.NextDateTimeThink = SysTime() + (60 - dateInfo.sec);
	else
		table.Merge(self.time, self.kernel:RestoreSchemaData("time"));
	end;
	
	if (useLocalMachineDate) then
		dateInfo.year = dateInfo.year + (defaultDate.year - dateInfo.year);

		table.Merge(self.time, {
			month = dateInfo.month,
			year = dateInfo.year,
			day = dateInfo.yday
		});
	else
		table.Merge(self.date, self.kernel:RestoreSchemaData("date"));
	end;
	
	CW_CONVAR_LOG = self.kernel:CreateConVar("cwLog", 1);
	
	for k, v in pairs(self.config.stored) do
		plugin.Call("ClockworkConfigInitialized", k, v.value);
	end;
	
	plugin.Call("ClockworkInitialized");

	hook.Remove("PlayerTick", "TickWidgets")

	--[[ Hotfix to allow downloads ]]--
	hook.Remove("Think", "exploit.fix");
	RunConsoleCommand("sv_allowdownload", "1");
end;

timer.Create("CW:PlayerWaterChecker", 1, 0, function()
	for k, v in pairs(_player.GetAll()) do
		if (v.submerged) then
			local timeInWater = CurTime() - v.waterStartTime;
			local decrease = 6;
			
			if (timeInWater > 5) then
				v:SetCharacterData("Stamina", math.Clamp(v:GetCharacterData("Stamina") - decrease, 0, 100));
			end;
			
			if (v:GetCharacterData("Stamina") <= 0) then
				v:TakeDamage(7);
			end;
		end;
	end;
end);

-- Called at an interval while a player is connected.
function CW:PlayerThink(player, curTime, infoTable)
	local bPlayerBreathSnd = false;
	local storageTable = player:GetStorageTable();
	
	if (!self.config:Get("cash_enabled"):Get()) then
		player:SetCharacterData("Cash", 0, true);
		infoTable.wages = 0;
	end;
	
	if (player:WaterLevel() >= 3) then
		player.submerged = true;
		player.waterStartTime = player.waterStartTime or curTime;
	else
		player.submerged = false;
		player.waterStartTime = nil;
	end;
	
	if (player.cwReloadHoldTime and curTime >= player.cwReloadHoldTime) then
		self.player:ToggleWeaponRaised(player);
		player.cwReloadHoldTime = nil;
		player.cwNextShootTime = curTime + self.config:Get("shoot_after_raise_time"):Get();
	end;
	
	if (player:IsRagdolled()) then
		player:SetMoveType(MOVETYPE_OBSERVER);
	end;
	
	if (storageTable and plugin.Call("PlayerStorageShouldClose", player, storageTable)) then
		self.storage:Close(player);
	end;
	
	player:SetSharedVar("InvWeight", math.ceil(infoTable.inventoryWeight));
	player:SetSharedVar("InvSpace", math.ceil(infoTable.inventorySpace));
	player:SetSharedVar("Wages", math.ceil(infoTable.wages));
	
	if (self.event:CanRun("limb_damage", "disability")) then
		local leftLeg = self.limb:GetDamage(player, HITGROUP_LEFTLEG, true);
		local rightLeg = self.limb:GetDamage(player, HITGROUP_RIGHTLEG, true);
		local legDamage = math.max(leftLeg, rightLeg);
		
		-- looks like infoTable is necessary here for correct function. ayy...
		if (legDamage > 0) then
			player:SetJumpPower(infoTable.jumpPower / (1 + legDamage), true);
			player:SetRunSpeed(infoTable.runSpeed / (1 + legDamage), true);
		else
			player:SetJumpPower(infoTable.jumpPower, true);
			player:SetRunSpeed(infoTable.runSpeed, true);
		end;
	end;
	
	if (player:KeyDown(IN_BACK)) then
		player:SetRunSpeed(player:GetRunSpeed() * 0.5, true);
	end;
	
	if (player:GetRunSpeed() < player:GetWalkSpeed()) then
		player:SetRunSpeed(player:GetWalkSpeed(), true);
	end;
	
	--[[ Update whether the weapon has fired, or is being raised. --]]
	player:UpdateWeaponFired(); player:UpdateWeaponRaised();
	player:SetSharedVar("IsRunMode", infoTable.isRunning);
	
	local activeWeapon = player:GetActiveWeapon();
	local weaponItemTable = self.item:GetByWeapon(activeWeapon);
	
	if (weaponItemTable and weaponItemTable:IsInstance()) then
		local clipOne = activeWeapon:Clip1();
		local clipTwo = activeWeapon:Clip2();
		
		if (clipOne >= 0) then
			weaponItemTable:SetData("ClipOne", clipOne);
		end;
		
		if (clipTwo >= 0) then
			weaponItemTable:SetData("ClipTwo", clipTwo);
		end;
	end;
	
	if (!player:KeyDown(IN_SPEED)) then return; end;
	
	local traceLine = player:GetEyeTraceNoCursor();
	local velocity = player:GetVelocity():Length();
	local entity = traceLine.Entity;
		
	if (traceLine.HitPos:Distance(player:GetShootPos()) > math.max(48, math.min(velocity, 256))
	or !IsValid(entity)) then
		return;
	end;
	
	if (entity:GetClass() != "prop_door_rotating" or self.player:IsNoClipping(player)) then
		return;
	end;
	
	local doorPartners = self.entity:GetDoorPartners(entity);
	
	for k, v in pairs(doorPartners) do
		if ((!self.entity:IsDoorLocked(v) and self.config:Get("bash_in_door_enabled"):Get())
		and (!v.cwNextBashDoor or curTime >= v.cwNextBashDoor)) then
			self.entity:BashInDoor(v, player);
			
			player:ViewPunch(
				Angle(math.Rand(-32, 32), math.Rand(-80, 80), math.Rand(-16, 16))
			);
		end;
	end;
end;

-- Called when a player fires a weapon.
function CW:PlayerFireWeapon(player, weapon, clipType, ammoType) end;

-- Called when a player has disconnected.
function CW:PlayerDisconnected(player)
	local tempData = player:CreateTempData();
	
	if (player:HasInitialized()) then
		if (plugin.Call("PlayerCharacterUnloaded", player) != true) then
			player:SaveCharacter();
		end;
		
		if (tempData) then
			plugin.Call("PlayerSaveTempData", player, tempData);
		end;
		
		self.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." ("..player:SteamID().." / "..player:IPAddress()..") has disconnected.");
		chatbox.AddText(nil, player:SteamName().." has disconnected from the server.", {filter = "events", icon = "icon16/user_delete.png", textColor = Color(180, 80, 150)});
	end;
end;

-- Called when CloudAuth has been validated.
function CW:CloudAuthValidated() end;

-- Called when CloudAuth has been blacklisted.
function CW:CloudAuthBlacklisted()
	self.Unauthorized = true;
end;

-- Called when Clockwork has initialized.
function CW:ClockworkInitialized()
	local cashName = self.option:GetKey("name_cash");
	
	if (!self.config:Get("cash_enabled"):Get()) then
		self.command:SetHidden("Give"..string.gsub(cashName, "%s", ""), true);
		self.command:SetHidden("Drop"..string.gsub(cashName, "%s", ""), true);
		self.command:SetHidden("StorageTake"..string.gsub(cashName, "%s", ""), true);
		self.command:SetHidden("StorageGive"..string.gsub(cashName, "%s", ""), true);
		
		self.config:Get("scale_prop_cost"):Set(0, nil, true, true);
		self.config:Get("door_cost"):Set(0, nil, true, true);
	end;
	
	if (self.config:Get("use_own_group_system"):Get()) then
		self.command:SetHidden("PlySetGroup", true);
		self.command:SetHidden("PlyDemote", true);
	end;
	
	local gradientTexture = self.option:GetKey("gradient");
	local schemaLogo = self.option:GetKey("schema_logo");
	local introImage = self.option:GetKey("intro_image");

	if (gradientTexture != "gui/gradient_up") then
		self.kernel:AddFile("materials/"..gradientTexture..".png");
	end;

	if (schemaLogo != "") then
		self.kernel:AddFile("materials/"..schemaLogo..".png");
	end;

	if (introImage != "") then
		self.kernel:AddFile("materials/"..introImage..".png");
	end;

	local toolGun = weapons.GetStored("gmod_tool");

	for k, v in pairs(self.tool:GetAll()) do
		toolGun.Tool[v.Mode] = v;
	end;
end;

-- Called when the Clockwork database has connected.
function CW:ClockworkDatabaseConnected()
	self.bans:Load();
end;

-- Called when the Clockwork database connection fails.
function CW:ClockworkDatabaseConnectionFailed()
	self.database:Error(errText);
end;

-- Called when Clockwork should log and event.
function CW:ClockworkLog(text, unixTime) end;

-- Called when a player is banned.
function CW:PlayerBanned(player, duration, reason) end;

-- Called when a player's skin has changed.
function CW:PlayerSkinChanged(player, skin) end;

-- Called when a player's model has changed.
function CW:PlayerModelChanged(player, model)
	local hands = player:GetHands();

	if (IsValid(hands) and hands:IsValid()) then
		self:PlayerSetHandsModel(player, player:GetHands());
	end;
end;

-- Called when a player's saved inventory should be added to.
function CW:PlayerAddToSavedInventory(player, character, Callback)
	for k, v in pairs(player:GetWeapons()) do
		local weaponItemTable = self.item:GetByWeapon(v);
		if (weaponItemTable) then
			Callback(weaponItemTable);
		end;
	end;
end;

-- Called when a player's unlock info is needed.
function CW:PlayerGetUnlockInfo(player, entity)
	if (self.entity:IsDoor(entity)) then
		local unlockTime = self.config:Get("unlock_time"):Get();
		
		if (self.event:CanRun("limb_damage", "unlock_time")) then
			local leftArm = self.limb:GetDamage(player, HITGROUP_LEFTARM, true);
			local rightArm = self.limb:GetDamage(player, HITGROUP_RIGHTARM, true);
			local armDamage = math.max(leftArm, rightArm);
			
			if (armDamage > 0) then
				unlockTime = unlockTime * (1 + armDamage);
			end;
		end;
		
		return {
			duration = unlockTime,
			Callback = function(player, entity)
				entity:Fire("unlock", "", 0);
			end
		};
	end;
end;

-- Called when an Clockwork item has initialized.
function CW:ClockworkItemInitialized(itemTable) end;

--[[
	@codebase Server
	@details Called after Clockwork items have been initialized.
	@param Table The table of items that have been initialized.
--]]
function CW:ClockworkPostItemsInitialized(itemsTable) end;

-- Called when a player's lock info is needed.
function CW:PlayerGetLockInfo(player, entity)
	if (self.entity:IsDoor(entity)) then
		local lockTime = self.config:Get("lock_time"):Get();
		
		if (self.event:CanRun("limb_damage", "lock_time")) then
			local leftArm = self.limb:GetDamage(player, HITGROUP_LEFTARM, true);
			local rightArm = self.limb:GetDamage(player, HITGROUP_RIGHTARM, true);
			local armDamage = math.max(leftArm, rightArm);
			
			if (armDamage > 0) then
				lockTime = lockTime * (1 + armDamage);
			end;
		end;
		
		return {
			duration = lockTime,
			Callback = function(player, entity)
				entity:Fire("lock", "", 0);
			end
		};
	end;
end;

-- Called when a player attempts to fire a weapon.
function CW:PlayerCanFireWeapon(player, bIsRaised, weapon, bIsSecondary)
	local canShootTime = player.cwNextShootTime;
	local curTime = CurTime();
	
	if (player:IsRunning() and self.config:Get("sprint_lowers_weapon"):Get()) then
		return false;
	end;
	
	if (!bIsRaised and !plugin.Call("PlayerCanUseLoweredWeapon", player, weapon, bIsSecondary)) then
		return false;
	end;
	
	if (canShootTime and canShootTime > curTime) then
		return false;
	end;
	
	if (self.event:CanRun("limb_damage", "weapon_fire")) then
		local leftArm = self.limb:GetDamage(player, HITGROUP_LEFTARM, true);
		local rightArm = self.limb:GetDamage(player, HITGROUP_RIGHTARM, true);
		local armDamage = math.max(leftArm, rightArm);
		
		if (armDamage == 0) then return true; end;
		
		if (player.cwArmDamageNoFire) then
			if (curTime >= player.cwArmDamageNoFire) then
				player.cwArmDamageNoFire = nil;
			end;
			
			return false;
		else
			if (!player.cwNextArmDamage) then
				player.cwNextArmDamage = curTime + (1 - (armDamage * 0.5));
			end;
			
			if (curTime >= player.cwNextArmDamage) then
				player.cwNextArmDamage = nil;
				
				if (math.random() <= armDamage * 0.75) then
					player.cwArmDamageNoFire = curTime + (1 + (armDamage * 2));
				end;
			end;
		end;
	end;
	
	return true;
end;

-- Called when a player attempts to use a lowered weapon.
function CW:PlayerCanUseLoweredWeapon(player, weapon, secondary)
	if (secondary) then
		return weapon.NeverRaised or (weapon.Secondary and weapon.Secondary.NeverRaised);
	else
		return weapon.NeverRaised or (weapon.Primary and weapon.Primary.NeverRaised);
	end;
end;

-- Called when a player's recognised names have been cleared.
function CW:PlayerRecognisedNamesCleared(player, status, isAccurate) end;

-- Called when a player's name has been cleared.
function CW:PlayerNameCleared(player, status, isAccurate) end;

-- Called when an offline player has been given property.
function CW:PlayerPropertyGivenOffline(key, uniqueID, entity, networked, removeDelay) end;

-- Called when an offline player has had property taken.
function CW:PlayerPropertyTakenOffline(key, uniqueID, entity) end;

-- Called when a player has been given property.
function CW:PlayerPropertyGiven(player, entity, networked, removeDelay) end;

-- Called when a player has had property taken.
function CW:PlayerPropertyTaken(player, entity) end;

-- Called when a player has been given flags.
function CW:PlayerFlagsGiven(player, flags)
	if (string.find(flags, "p") and player:Alive()) then
		self.player:GiveSpawnWeapon(player, "weapon_physgun");
	end;
	
	if (string.find(flags, "t") and player:Alive()) then
		self.player:GiveSpawnWeapon(player, "gmod_tool");
	end;
	
	player:SetSharedVar("flags", player:GetFlags());
end;

-- Called when a player has had flags taken.
function CW:PlayerFlagsTaken(player, flags)
	if (string.find(flags, "p") and player:Alive()) then
		if (!self.player:HasFlags(player, "p")) then
			self.player:TakeSpawnWeapon(player, "weapon_physgun");
		end;
	end;
	
	if (string.find(flags, "t") and player:Alive()) then
		if (!self.player:HasFlags(player, "t")) then
			self.player:TakeSpawnWeapon(player, "gmod_tool");
		end;
	end;
	
	player:SetSharedVar("flags", player:GetFlags());
end;

-- Called when a player's phys desc override is needed.
function CW:GetPlayerPhysDescOverride(player, physDesc) end;

-- Called when a player's default skin is needed.
function CW:GetPlayerDefaultSkin(player)
	local model, skin = self.class:GetAppropriateModel(player:Team(), player);
	return skin;
end;

-- Called when a player's default model is needed.
function CW:GetPlayerDefaultModel(player)
	local model, skin = self.class:GetAppropriateModel(player:Team(), player);
	return model;
end;

-- Called when a player's default inventory is needed.
function CW:GetPlayerDefaultInventory(player, character, inventory)
	local startingInv = self.faction:FindByID(character.faction).startingInv;
	
	if (istable(startingInv)) then
		for k, v in pairs(startingInv) do
			self.inventory:AddInstance(
				inventory, self.item:CreateInstance(k), v
			);
		end;
	end;
end;

-- Called to get whether a player's weapon is raised.
function CW:GetPlayerWeaponRaised(player, class, weapon)
	if (self.kernel:IsDefaultWeapon(weapon)) then
		return true;
	end;
	
	if (player:IsRunning() and self.config:Get("sprint_lowers_weapon"):Get()) then
		return false;
	end;
	
	if (weapon:GetNetworkedBool("Ironsights")) then
		return true;
	end;
	
	if (weapon:GetNetworkedInt("Zoom") != 0) then
		return true;
	end;
	
	if (weapon:GetNetworkedBool("Scope")) then
		return true;
	end;
	
	if (self.config:Get("raised_weapon_system"):Get()) then
		if (player.cwWeaponRaiseClass == class) then
			return true;
		else
			player.cwWeaponRaiseClass = nil;
		end;
		
		if (player.cwAutoWepRaised == class) then
			return true;
		else
			player.cwAutoWepRaised = nil;
		end;
		
		return false;
	end;
	
	return true;
end;

-- Called when a player's attribute has been updated.
function CW:PlayerAttributeUpdated(player, attributeTable, amount) end;

-- Called to get whether a player can give an item to storage.
function CW:PlayerCanGiveToStorage(player, storageTable, itemTable)
	return true;
end;

-- Called to get whether a player can take an item to storage.
function CW:PlayerCanTakeFromStorage(player, storageTable, itemTable)
	return true;
end;

-- Called when a player has given an item to storage.
function CW:PlayerGiveToStorage(player, storageTable, itemTable)
	if (player:IsWearingItem(itemTable)) then
		player:RemoveClothes();
	end;
	
	if (player:IsWearingAccessory(itemTable)) then
		player:RemoveAccessory(itemTable);
	end;
end;

-- Called when a player has taken an item to storage.
function CW:PlayerTakeFromStorage(player, storageTable, itemTable) end;

-- Called when a player is given an item.
function CW:PlayerItemGiven(player, itemTable, bForce)
	self.storage:SyncItem(player, itemTable);
end;

-- Called when a player has an item taken.
function CW:PlayerItemTaken(player, itemTable)
	self.storage:SyncItem(player, itemTable);
	
	if (player:IsWearingItem(itemTable)) then
		player:RemoveClothes();
	end;
	
	if (player:IsWearingAccessory(itemTable)) then
		player:RemoveAccessory(itemTable);
	end;
end;

-- Called when a player's cash has been updated.
function CW:PlayerCashUpdated(player, amount, reason, bNoMsg)
	self.storage:SyncCash(player);
end;

-- A function to scale damage by hit group.
function CW:PlayerScaleDamageByHitGroup(player, attacker, hitGroup, damageInfo, baseDamage)
	if (attacker:IsVehicle() or (attacker:IsPlayer() and attacker:InVehicle())) then
		damageInfo:ScaleDamage(0.25);
	end;
end;

-- Called when a player switches their flashlight on or off.
function CW:PlayerSwitchFlashlight(player, bIsOn)
	if (player:HasInitialized() and bIsOn
	and player:IsRagdolled()) then
		return false;
	end;
	
	return true;
end;

-- Called when time has passed.
function CW:TimePassed(quantity) end;

-- Called when Clockwork config has initialized.
function CW:ClockworkConfigInitialized(key, value)
	if (key == "cash_enabled" and !value) then
		for k, v in pairs(self.item:GetAll()) do
			v.cost = 0;
		end;
	elseif (key == "local_voice") then
		if (value) then
			RunConsoleCommand("sv_alltalk", "0");
		end;
	end;
end;

-- Called when a Clockwork ConVar has changed.
function CW:ClockworkConVarChanged(name, previousValue, newValue)
	if (name == "local_voice" and newValue) then
		RunConsoleCommand("sv_alltalk", "1");
	end;
end;

-- Called when Clockwork config has changed.
function CW:ClockworkConfigChanged(key, data, previousValue, newValue)
	local plyTable = player.GetAll();

	if (key == "default_flags") then
		for k, v in pairs(plyTable) do
			if (v:HasInitialized() and v:Alive()) then
				if (string.find(previousValue, "p")) then
					if (!string.find(newValue, "p")) then
						if (!self.player:HasFlags(v, "p")) then
							self.player:TakeSpawnWeapon(v, "weapon_physgun");
						end;
					end;
				elseif (!string.find(previousValue, "p")) then
					if (string.find(newValue, "p")) then
						self.player:GiveSpawnWeapon(v, "weapon_physgun");
					end;
				end;
				
				if (string.find(previousValue, "t")) then
					if (!string.find(newValue, "t")) then
						if (!self.player:HasFlags(v, "t")) then
							self.player:TakeSpawnWeapon(v, "gmod_tool");
						end;
					end;
				elseif (!string.find(previousValue, "t")) then
					if (string.find(newValue, "t")) then
						self.player:GiveSpawnWeapon(v, "gmod_tool");
					end;
				end;
			end;
		end;
	elseif (key == "use_own_group_system") then
		if (newValue) then
			self.command:SetHidden("PlySetGroup", true);
			self.command:SetHidden("PlyDemote", true);
		else
			self.command:SetHidden("PlySetGroup", false);
			self.command:SetHidden("PlyDemote", false);
		end;
	elseif (key == "crouched_speed") then
		for k, v in pairs(plyTable) do
			v:SetCrouchedWalkSpeed(newValue);
		end;
	elseif (key == "ooc_interval") then
		for k, v in pairs(plyTable) do
			v.cwNextTalkOOC = nil;
		end;
	elseif (key == "jump_power") then
		for k, v in pairs(plyTable) do
			v:SetJumpPower(newValue);
		end;
	elseif (key == "walk_speed") then
		for k, v in pairs(plyTable) do
			v:SetWalkSpeed(newValue);
		end;
	elseif (key == "run_speed") then
		for k, v in pairs(plyTable) do
			v:SetRunSpeed(newValue);
		end;
	end;
end;

-- Called when a player's name has changed.
function CW:PlayerNameChanged(player, previousName, newName) end;

-- Called when a player attempts to sprays their tag.
function CW:PlayerSpray(player)
	if (!player:Alive() or player:IsRagdolled()) then
		return true;
	elseif (self.event:CanRun("config", "player_spray")) then
		return self.config:Get("disable_sprays"):Get();
	end;
end;

-- Called when a player attempts to use an entity.
function CW:PlayerUse(player, entity)
	if (player:IsRagdolled(RAGDOLL_FALLENOVER)) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player's move data is set up.
function CW:SetupMove(player, moveData)
	local isDrunk = self.player:GetDrunk(player);
	
	if (isDrunk) then
		if (player:Alive() and !player:IsRagdolled()) then
			local frameTime = FrameTime();
			local curTime = CurTime();
			
			if (isDrunk and player.cwDrunkSwerve) then
				player.cwDrunkSwerve = math.Clamp(player.cwDrunkSwerve + frameTime, 0, math.min(isDrunk * 2, 16));
				
				moveData:SetMoveAngles(moveData:GetMoveAngles() + Angle(0, math.cos(curTime) * player.cwDrunkSwerve, 0));
			elseif (player.cwDrunkSwerve and player.cwDrunkSwerve > 1) then
				player.cwDrunkSwerve = math.max(player.cwDrunkSwerve - frameTime, 0);
				
				moveData:SetMoveAngles(moveData:GetMoveAngles() + Angle(0, math.cos(curTime) * player.cwDrunkSwerve, 0));
			elseif (player.cwDrunkSwerve != 1) then
				player.cwDrunkSwerve = 1;
			end;
		end;
	end;
end;

-- Called when a player throws a punch.
function CW:PlayerPunchThrown(player) end;

-- Called when a player knocks on a door.
function CW:PlayerKnockOnDoor(player, door) end;

-- Called when a player attempts to knock on a door.
function CW:PlayerCanKnockOnDoor(player, door) return true; end;

-- Called when a player punches an entity.
function CW:PlayerPunchEntity(player, entity) end;

--[[
	Called when a player orders an item shipment.
	
	If itemTables is set, the order is a shipment. This means that
	you should use the itemTables table, and not the itemTable parameter.
--]]
function CW:PlayerOrderShipment(player, itemTable, entity, itemTables) end;

-- Called when a player holsters a weapon.
function CW:PlayerHolsterWeapon(player, itemTable, weapon, bForce) end;

-- Called when a player attempts to save a recognised name.
function CW:PlayerCanSaveRecognisedName(player, target)
	if (player != target) then return true; end;
end;

-- Called when a player attempts to restore a recognised name.
function CW:PlayerCanRestoreRecognisedName(player, target)
	if (player != target) then return true; end;
end;

-- Called when a player attempts to order an item shipment.
function CW:PlayerCanOrderShipment(player, itemTable)
	local curTime = CurTime();

	if (player.cwNextOrderTime and curTime < player.cwNextOrderTime) then
		return false;
	end;
	
	return true;
end;

-- Called when a player attempts to get up.
function CW:PlayerCanGetUp(player) return true; end;

-- Called when a player knocks out a player with a punch.
function CW:PlayerPunchKnockout(player, target) end;

-- Called when a player attempts to throw a punch.
function CW:PlayerCanThrowPunch(player) return true; end;

-- Called when a player attempts to punch an entity.
function CW:PlayerCanPunchEntity(player, entity) return true; end;

-- Called when a player attempts to knock a player out with a punch.
function CW:PlayerCanPunchKnockout(player, target) return true; end;

-- Called when a player attempts to bypass the faction limit.
function CW:PlayerCanBypassFactionLimit(player, character) return false; end;

-- Called when a player attempts to bypass the class limit.
function CW:PlayerCanBypassClassLimit(player, class) return false; end;

-- Called when a player's pain sound should be played.
function CW:PlayerPlayPainSound(player, gender, damageInfo, hitGroup)
	if (damageInfo:IsBulletDamage() and math.random() <= 0.5) then
		if (hitGroup == HITGROUP_HEAD) then
			return "vo/npc/"..gender.."01/ow0"..math.random(1, 2)..".wav";
		elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_GENERIC) then
			return "vo/npc/"..gender.."01/hitingut0"..math.random(1, 2)..".wav";
		elseif (hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG) then
			return "vo/npc/"..gender.."01/myleg0"..math.random(1, 2)..".wav";
		elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM) then
			return "vo/npc/"..gender.."01/myarm0"..math.random(1, 2)..".wav";
		elseif (hitGroup == HITGROUP_GEAR) then
			return "vo/npc/"..gender.."01/startle0"..math.random(1, 2)..".wav";
		end;
	end;
	
	return "vo/npc/"..gender.."01/pain0"..math.random(1, 9)..".wav";
end;

-- Called when a player has spawned.
function CW:PlayerSpawn(player)
	if (player:HasInitialized()) then
		player:ShouldDropWeapon(false);
		
		if (!player.cwLightSpawn) then
			local FACTION = self.faction:FindByID(player:GetFaction());
			local relation = FACTION.entRelationship;
			local playerRank, rank = player:GetFactionRank();

			self.player:SetWeaponRaised(player, false);
			self.player:SetRagdollState(player, RAGDOLL_RESET);
			self.player:SetAction(player, false);
			self.player:SetDrunk(player, false);
			
			self.attributes:ClearBoosts(player);
			self.limb:ResetDamage(player);
			
			self:PlayerSetModel(player);
			self:PlayerLoadout(player);
			
			if (player:FlashlightIsOn()) then
				player:Flashlight(false);
			end;
			
			player:SetForcedAnimation(false);
			player:SetCollisionGroup(COLLISION_GROUP_PLAYER);
			player:SetMaterial("");
			player:SetMoveType(MOVETYPE_WALK);
			player:Extinguish();
			player:UnSpectate();
			player:GodDisable();
			player:RunCommand("-duck");
			player:SetColor(Color(255, 255, 255, 255));
			player:SetupHands();
			
			player:SetCrouchedWalkSpeed(self.config:Get("crouched_speed"):Get());
			player:SetWalkSpeed(self.config:Get("walk_speed"):Get());
			player:SetJumpPower(self.config:Get("jump_power"):Get());
			player:SetRunSpeed(self.config:Get("run_speed"):Get());
			player:CrosshairDisable();

			player:SetMaxHealth(FACTION.maxHealth or 100);
			player:SetMaxArmor(FACTION.maxArmor or 0);
			player:SetHealth(FACTION.maxHealth or 100);
			player:SetArmor(FACTION.maxArmor or 0);
		
			if (rank) then
				player:SetMaxHealth(rank.maxHealth or player:GetMaxHealth());
				player:SetMaxArmor(rank.maxArmor or player:GetMaxArmor());
				player:SetHealth(rank.maxHealth or player:GetMaxHealth());
				player:SetArmor(rank.maxArmor or player:GetMaxArmor());
			end;
		
			if (istable(FACTION.respawnInv)) then
				local inventory = player:GetInventory();
				local itemQuantity;
			
				for k, v in pairs(FACTION.respawnInv) do
					for i = 1, (v or 1) do
						itemQuantity = table.Count(inventory[k]);
						
						if (itemQuantity < v) then
							player:GiveItem(self.item:CreateInstance(k), true);
						end;
					end;
				end;
			end;
		
			if (prevRelation) then
				for k, v in pairs(ents.GetAll()) do
					if (v:IsNPC()) then
						local prevRelationVal = prevRelation[player:SteamID()][v:GetClass()];
					
						if (prevRelationVal) then
							v:AddEntityRelationship(player, prevRelationVal, 1);
						end;
					end;
				end;
			end;
			
			if (istable(relation)) then
				local relationEnts;
			
				prevRelation = prevRelation or {};
				prevRelation[player:SteamID()] = prevRelation[player:SteamID()] or {};
			
				for k, v in pairs(relation) do
					relationEnts = ents.FindByClass(k);
				
					if (relationEnts) then
						for k2, v2 in pairs(relationEnts) do
							if (string.lower(v) == "like") then
								prevRelation[player:SteamID()][k] = v2:Disposition(player);
								v2:AddEntityRelationship(player, D_LI, 1);
							elseif (string.lower(v) == "fear") then
								prevRelation[player:SteamID()][k] = v2:Disposition(player);
								v2:AddEntityRelationship(player, D_FR, 1);
							elseif (string.lower(v) == "hate") then
								prevRelation[player:SteamID()][k] = v2:Disposition(player);
								v2:AddEntityRelationship(player, D_HT, 1);
							else
								ErrorNoHalt("Attempting to add relationship using invalid relation '"..v.."' towards faction '"..FACTION.name.."'.\r\n");
							end;
						end;
					end;
				end;
			end;

			if (player.cwFirstSpawn) then
				local ammo = player:GetSavedAmmo();
				
				for k, v in pairs(ammo) do
					if (!string.find(k, "p_") and !string.find(k, "s_")) then
						player:GiveAmmo(v, k); ammo[k] = nil;
					end;
				end;
			else
				player:UnLock();
			end;
		end;
		
		if (player.cwLightSpawn and player.cwSpawnCallback) then
			player.cwSpawnCallback(player, true);
			player.cwSpawnCallback = nil;
		end;
		
		plugin.Call("PostPlayerSpawn", player, player.cwLightSpawn, player.cwChangeClass, player.cwFirstSpawn);
		self.player:SetRecognises(player, player, RECOGNISE_TOTAL);
		
		local accessoryData = player:GetAccessoryData();
		local clothesItem = player:GetClothesItem();
		
		if (clothesItem) then
			player:SetClothesData(clothesItem);
		end;
		
		for k, v in pairs(accessoryData) do
			local itemTable = player:FindItemByID(v, k);
			
			if (itemTable) then
				itemTable:OnWearAccessory(player, true);
			else
				accessoryData[k] = nil;
			end;
		end;
		
		player.cwChangeClass = false;
		player.cwLightSpawn = false;
	else
		player:KillSilent();
	end;
end;

-- Choose the model for hands according to their player model.
function CW:PlayerSetHandsModel(player, entity)
	local model = player:GetModel();
	local simpleModel = player_manager.TranslateToPlayerModelName(model)
	local info = self.animation:GetHandsInfo(model) or player_manager.TranslatePlayerHands(simpleModel);

	if (info) then
		entity:SetModel(info.model);
		entity:SetSkin(info.skin);

		local bodyGroups = tostring(info.body);

		if (bodyGroups) then
			bodyGroups = string.Explode("", bodyGroups);

			for k, v in pairs(bodyGroups) do
				local num = tonumber(v);

				if (num) then
					entity:SetBodygroup(k, num);
				end;
			end;
		end;
	end;

	plugin.Call("PostCModelHandsSet", player, model, entity, info);
end;

-- Called every frame.
function CW:Think()
	self.kernel:CallTimerThink(CurTime());
end;

-- Called when a player attempts to connect to the server.
function CW:CheckPassword(steamID, ipAddress, svPassword, clPassword, name)
	steamID = util.SteamIDFrom64(steamID);
	local banTable = self.bans.stored[ipAddress] or self.bans.stored[steamID];
	
	if (banTable) then
		local unixTime = os.time();
		local unbanTime = tonumber(banTable.unbanTime);
		local timeLeft = unbanTime - unixTime;
		local hoursLeft = math.Round(math.max(timeLeft / 3600, 0));
		local minutesLeft = math.Round(math.max(timeLeft / 60, 0));
		
		if (unbanTime > 0 and unixTime < unbanTime) then
			local bannedMessage = self.config:Get("banned_message"):Get();
			
			if (hoursLeft >= 1) then
				hoursLeft = tostring(hoursLeft);
				
				bannedMessage = string.gsub(bannedMessage, "!t", hoursLeft);
				bannedMessage = string.gsub(bannedMessage, "!f", "hour(s)");
			elseif (minutesLeft >= 1) then
				minutesLeft = tostring(minutesLeft);
				
				bannedMessage = string.gsub(bannedMessage, "!t", minutesLeft);
				bannedMessage = string.gsub(bannedMessage, "!f", "minutes(s)");
			else
				timeLeft = tostring(timeLeft);
				
				bannedMessage = string.gsub(bannedMessage, "!t", timeLeft);
				bannedMessage = string.gsub(bannedMessage, "!f", "second(s)");
			end;
			
			return false, bannedMessage;
		elseif (unbanTime == 0) then
			return false, banTable.reason;
		else
			self.bans:Remove(ipAddress);
			self.bans:Remove(steamID);
		end;
	end;
end;

-- Called when the Clockwork data is saved.
function CW:SaveData()
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized()) then
			v:SaveCharacter();
		end;
	end;
	
	if (!self.config:Get("use_local_machine_time"):Get()) then
		self.kernel:SaveSchemaData("time", self.time:GetSaveData());
	end;
	
	if (!self.config:Get("use_local_machine_date"):Get()) then
		self.kernel:SaveSchemaData("date", self.date:GetSaveData());
	end;
end;

function CW:PlayerCanInteractCharacter(player, action, character)
	if (self.quiz:GetEnabled() and !self.quiz:GetCompleted(player)) then
		return false, 'You have not completed the quiz!';
	else
		return true;
	end;
end;

-- Called whe the map entities are initialized.
function CW:InitPostEntity()
	for k, v in pairs(ents.GetAll()) do
		if (IsValid(v)) then
			if (v:GetModel()) then
				self.entity:SetMapEntity(v, true);
				self.entity:SetStartAngles(v, v:GetAngles());
				self.entity:SetStartPosition(v, v:GetPos());
				
				if (self.entity:SetChairAnimations(v)) then
					v:SetCollisionGroup(COLLISION_GROUP_WEAPON);

					local physicsObject = v:GetPhysicsObject();
					
					if (IsValid(physicsObject)) then
						physicsObject:EnableMotion(false);
					end;
				end;
			end;

			if (self.entity:IsDoor(v)) then
				local entIndex = v:EntIndex();
			
				if (!self.entity.DoorEntities) then self.entity.DoorEntities = {}; end;

				local doorEnts = self.entity.DoorEntities;

				if (!doorEnts[entIndex]) then
					doorEnts[entIndex] = v;
				end;
			end;
		end;
	end;

	if (!self.NoMySQL) then
		self.kernel:SetSharedVar("NoMySQL");
	else
		self.kernel:SetSharedVar("NoMySQL", self.NoMySQL);
	end;

	plugin.Call("ClockworkInitPostEntity");
end;

-- Called when a player initially spawns.
function CW:PlayerInitialSpawn(player)
	player.cwCharacterList = player.cwCharacterList or {};
	player.cwHasSpawned = true;
	player.cwSharedVars = player.cwSharedVars or {};
	
	if (IsValid(player)) then
		player:KillSilent();
	end;
	
	if (player:IsBot()) then
		self.config:Send(player);
	end;
	
	if (!player:IsKicked()) then
		self.kernel:PrintLog(LOGTYPE_MINOR, player:SteamName().." ("..player:SteamID().." / "..player:IPAddress()..") has connected.");
		chatbox.AddText(nil, player:SteamName().." has connected to the server.", {filter = "events", icon = "icon16/user_add.png", textColor = Color(150, 80, 210)});
	end;
end;

-- Called every frame while a player is dead.
function CW:PlayerDeathThink(player)
	local action = self.player:GetAction(player);
	
	if (!player:HasInitialized() or player:GetCharacterData("CharBanned")) then
		return true;
	end;
	
	if (player:IsCharacterMenuReset()) then
		return true;
	end;
	
	if (action == "spawn") then
		return true;
	else
	
		player:Spawn();
	end;
end;

-- Called when a player's data has loaded.
function CW:PlayerDataLoaded(player)
	if (self.config:Get("clockwork_intro_enabled"):Get()) then
		if (!player:GetData("ClockworkIntro")) then
			netstream.Start(player, "ClockworkIntro", true);
			player:SetData("ClockworkIntro", true);
		end;
	end;
end;

-- Called when a player attempts to be given a weapon.
function CW:PlayerCanBeGivenWeapon(player, class, itemTable)
	return true;
end;

-- Called when a player has been given a weapon.
function CW:PlayerGivenWeapon(player, class, itemTable)
	self.inventory:Rebuild(player);
	
	if (self.item:IsWeapon(itemTable) and !itemTable:IsFakeWeapon()) then
		if (!itemTable:IsMeleeWeapon() and !itemTable:IsThrowableWeapon()) then
			if (itemTable("weight") <= 2) then
				self.player:CreateGear(player, "Secondary", itemTable);
			else
				self.player:CreateGear(player, "Primary", itemTable);
			end;
		elseif (itemTable:IsThrowableWeapon()) then
			self.player:CreateGear(player, "Throwable", itemTable);
		else
			self.player:CreateGear(player, "Melee", itemTable);
		end;
	end;
end;

-- Called when a player attempts to create a character.
function CW:PlayerCanCreateCharacter(player, character, characterID)
	if (self.quiz:GetEnabled() and !self.quiz:GetCompleted(player)) then
		return "You have not completed the quiz!";
	else
		return true;
	end;
end;

-- Called when a player's bullet info should be adjusted.
function CW:PlayerAdjustBulletInfo(player, bulletInfo) end;

-- Called when an entity fires some bullets.
function CW:EntityFireBullets(entity, bulletInfo) end;

-- Called when a player's fall damage is needed.
function CW:GetFallDamage(player, velocity)
	local ragdollEntity = nil;
	local position = player:GetPos();
	local damage = math.max((velocity - 464) * 0.225225225, 0) * self.config:Get("scale_fall_damage"):Get();
	local filter = {player};
	
	if (self.config:Get("wood_breaks_fall"):Get()) then
		if (player:IsRagdolled()) then
			ragdollEntity = player:GetRagdollEntity();
			position = ragdollEntity:GetPos();
			filter = {player, ragdollEntity};
		end;
		
		local traceLine = util.TraceLine({
			endpos = position - Vector(0, 0, 64),
			start = position,
			filter = filter
		});

		if (IsValid(traceLine.Entity) and traceLine.MatType == MAT_WOOD) then
			if (string.find(traceLine.Entity:GetClass(), "prop_physics")) then
				traceLine.Entity:Fire("Break", "", 0);
				damage = damage * 0.25;
			end;
		end;
	end;
	
	return damage;
end;

-- Called when a player's data stream info has been sent.
function CW:PlayerDataStreamInfoSent(player)
	if (player:IsBot()) then
		self.player:LoadData(player, function(player)
			plugin.Call("PlayerDataLoaded", player);
			
			local factions = table.ClearKeys(self.faction:GetAll(), true);
			local faction = factions[math.random(1, #factions)];
			
			if (faction) then
				local genders = {GENDER_MALE, GENDER_FEMALE};
				local gender = faction.singleGender or genders[math.random(1, #genders)];
				local models = faction.models[string.lower(gender)];
				local model = models[math.random(1, #models)];
				
				self.player:LoadCharacter(player, 1, {
					faction = faction.name,
					gender = gender,
					model = model,
					name = player:Name(),
					data = {}
				}, function()
					self.player:LoadCharacter(player, 1);
				end);
			end;
		end);
	elseif (table.Count(self.faction:GetAll()) > 0) then
		self.player:LoadData(player, function()
			plugin.Call("PlayerDataLoaded", player);
			
			local whitelisted = player:GetData("Whitelisted");
			local steamName = player:SteamName();
			local unixTime = os.time();
			
			self.player:SetCharacterMenuState(player, CHARACTER_MENU_OPEN);
			
			if (whitelisted) then
				for k, v in pairs(whitelisted) do
					if (self.faction:GetStored()[v]) then
						netstream.Start(player, "SetWhitelisted", {v, true});
					else
						whitelisted[k] = nil;
					end;
				end;
			end;
			
			self.player:GetCharacters(player, function(characters)
				if (characters) then
					for k, v in pairs(characters) do
						self.player:ConvertCharacterMySQL(v);
						player.cwCharacterList[v.characterID] = {};
						
						for k2, v2 in pairs(v) do
							if (k2 == "timeCreated") then
								if (v2 == "") then
									player.cwCharacterList[v.characterID][k2] = unixTime;
								else
									player.cwCharacterList[v.characterID][k2] = v2;
								end;
							elseif (k2 == "lastPlayed") then
								player.cwCharacterList[v.characterID][k2] = unixTime;
							elseif (k2 == "steamName") then
								player.cwCharacterList[v.characterID][k2] = steamName;
							else
								player.cwCharacterList[v.characterID][k2] = v2;
							end;
						end;
					end;
					
					for k, v in pairs(player.cwCharacterList) do
						local bDelete = plugin.Call("PlayerAdjustCharacterTable", player, v);
						
						if (!bDelete) then
							self.player:CharacterScreenAdd(player, v);
						else
							self.player:ForceDeleteCharacter(player, k);
						end;
					end;
				end;
				
				self.player:SetCharacterMenuState(player, CHARACTER_MENU_LOADED);
			end);
		end);
	end;
end;

-- Called when a player's data stream info should be sent.
function CW:PlayerSendDataStreamInfo(player)
	netstream.Start(player, "SharedTables", self.SharedTables);

	if (self.OverrideColorMod and self.OverrideColorMod != nil) then
		netstream.Start(player, "SystemColGet", self.OverrideColorMod);
	end;
end;

-- Called when a player's death sound should be played.
function CW:PlayerPlayDeathSound(player, gender)
	return "vo/npc/"..string.lower(gender).."01/pain0"..math.random(1, 9)..".wav";
end;

-- Called when a player's character data should be restored.
function CW:PlayerRestoreCharacterData(player, data)
	if (data["PhysDesc"]) then
		data["PhysDesc"] = self.kernel:ModifyPhysDesc(data["PhysDesc"]);
	end;
	
	if (!data["LimbData"]) then
		data["LimbData"] = {};
	end;
	
	if (!data["Clothes"]) then
		data["Clothes"] = {};
	end;
	
	if (!data["Accessories"]) then
		data["Accessories"] = {};
	end;
	
	self.player:RestoreCharacterData(player, data);
end;

-- Called when a player's limb damage is bIsHealed.
function CW:PlayerLimbDamageHealed(player, hitGroup, amount) end;

-- Called when a player's limb takes damage.
function CW:PlayerLimbTakeDamage(player, hitGroup, damage) end;

-- Called when a player's limb damage is reset.
function CW:PlayerLimbDamageReset(player) end;

-- Called when a player's character data should be saved.
function CW:PlayerSaveCharacterData(player, data)
	if (self.config:Get("save_attribute_boosts"):Get()) then
		self.kernel:SavePlayerAttributeBoosts(player, data);
	end;
	
	data["Health"] = player:Health();
	data["Armor"] = player:Armor();
	
	if (data["Health"] <= 1) then
		data["Health"] = nil;
	end;
	
	if (data["Armor"] <= 1) then
		data["Armor"] = nil;
	end;
end;

-- Called when a player's data should be saved.
function CW:PlayerSaveData(player, data)
	self.player:RestoreData(player, data);
	
	if (data["Whitelisted"] and table.Count(data["Whitelisted"]) == 0) then
		data["Whitelisted"] = nil;
	end;
end;

-- Called when a player's storage should close.
function CW:PlayerStorageShouldClose(player, storageTable)
	local entity = player:GetStorageEntity();
	
	if (player:IsRagdolled() or !player:Alive() or (storageTable.entity and !entity)
	or (storageTable.entity and storageTable.distance
	and player:GetShootPos():Distance(entity:GetPos()) > storageTable.distance)) then
		return true;
	elseif (storageTable.ShouldClose and storageTable.ShouldClose(player, storageTable)) then
		return true;
	end;
end;

-- Called when a player attempts to pickup a weapon.
function CW:PlayerCanPickupWeapon(player, weapon)
	if (player.cwForceGive or (player:GetEyeTraceNoCursor().Entity == weapon and player:KeyDown(IN_USE))) then
		return true;
	else
		return false;
	end;
end;

-- Called to modify the wages interval.
function CW:ModifyWagesInterval(info) end;

-- Called to modify a player's wages info.
function CW:PlayerModifyWagesInfo(player, info) end;

function CW:OneSecond()
	local sysTime = SysTime();
	local curTime = CurTime();
	local plyTable = player.GetAll();
	
	if (!self.NextHint or curTime >= self.NextHint) then
		self.hint:Distribute();
		self.NextHint = curTime + self.config:Get("hint_interval"):Get();
	end;
	
	if (!self.NextWagesTime or curTime >= self.NextWagesTime) then
		self.kernel:DistributeWagesCash();
		
		local info = {
			interval = self.config:Get("wages_interval"):Get();
		};
		
		plugin.Call("ModifyWagesInterval", info);
		
		self.NextWagesTime = curTime + info.interval;
	end;
	
	if (!self.NextDateTimeThink or sysTime >= self.NextDateTimeThink) then
		self.kernel:PerformDateTimeThink();
		self.NextDateTimeThink = sysTime + self.config:Get("minute_time"):Get();
	end;
	
	if (!self.NextSaveData or sysTime >= self.NextSaveData) then
		plugin.Call("PreSaveData");
			plugin.Call("SaveData");
		plugin.Call("PostSaveData");
		
		self.NextSaveData = sysTime + self.config:Get("save_data_interval"):Get();
	end;
	
	if (!self.NextCheckEmpty) then
		self.NextCheckEmpty = sysTime + 1200;
	end;
	
	if (sysTime >= self.NextCheckEmpty) then
		self.NextCheckEmpty = nil;
		
		if (#plyTable == 0) then
			RunConsoleCommand("changelevel", game.GetMap());
		end;
	end;
end;

-- Called each tick.
function CW:Tick()
	local curTime = CurTime();
	
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized()) then
			if (!v.cwNextThink) then
				v.cwNextThink = curTime + 0.1;
				v.cwNextSetSharedVars = curTime + 1;
			end;
			
			if (curTime >= v.cwNextThink) then
				self.player:CallThinkHook(
					v, (curTime >= v.cwNextSetSharedVars), curTime
				);
				
				v.cwNextThink = curTime + (1 / (self.config:GetVal("playerthink_rate") or 8));
			end;
		end;
	end;
end;

-- Called when a player's health should regenerate.
function CW:PlayerShouldHealthRegenerate(player)
	return true;
end;

-- Called to get the entity that a player is holding.
function CW:PlayerGetHoldingEntity(player) end;

-- A function to regenerate a player's health.
function CW:PlayerHealthRegenerate(player, health, maxHealth)
	local curTime = CurTime();
	local maxHealth = player:GetMaxHealth();
	local health = player:Health();
		
	if (player:Alive() and (!player.cwNextHealthRegen or curTime >= player.cwNextHealthRegen)) then
		if (health >= (maxHealth / 2) and (health < maxHealth)) then
			player:SetHealth(math.Clamp(
				health + 2, 0, maxHealth)
			);
				
			player.cwNextHealthRegen = curTime + 5;
		elseif (health > 0) then
			player:SetHealth(
				math.Clamp(health + 2, 0, maxHealth)
			);
				
			player.cwNextHealthRegen = curTime + 10;
		end;
	end;
end;

-- Called when a player's shared variables should be set.
function CW:PlayerSetSharedVars(player, curTime)
	local weaponClass = self.player:GetWeaponClass(player);
	local color = player:GetColor();
	local isDrunk = self.player:GetDrunk(player);
	
	player:HandleAttributeProgress(curTime);
	player:HandleAttributeBoosts(curTime);
	
	player:SetSharedVar("Flags", player:GetFlags());
	player:SetSharedVar("Model", player:GetDefaultModel());
	player:SetSharedVar("Name", player:Name());
	player:SetSharedVar("Cash", player:GetCash());
	
	local clothesItem = player:IsWearingClothes();
	
	if (clothesItem) then
		player:NetworkClothesData();
	else
		player:RemoveClothes();
	end;
	
	if (self.config:Get("health_regeneration_enabled"):Get()
	and plugin.Call("PlayerShouldHealthRegenerate", player)) then
		plugin.Call("PlayerHealthRegenerate", player, health, maxHealth)
	end;
	
	if (color.r == 255 and color.g == 0 and color.b == 0 and color.a == 0) then
		player:SetColor(Color(255, 255, 255, 255));
	end;
	
	for k, v in pairs(player:GetWeapons()) do
		local ammoType = v:GetPrimaryAmmoType();
		
		if (ammoType == "grenade" and player:GetAmmoCount(ammoType) == 0) then
			player:StripWeapon(v:GetClass());
		end;
	end;
	
	if (player.cwDrunkTab) then
		for k, v in pairs(player.cwDrunkTab) do
			if (curTime >= v) then
				table.remove(player.cwDrunkTab, k);
			end;
		end;
	end;
	
	if (isDrunk) then
		player:SetSharedVar("IsDrunk", isDrunk);
	else
		player:SetSharedVar("IsDrunk", 0);
	end;
end;

-- Called when a player picks an item up.
function CW:PlayerPickupItem(player, itemTable, itemEntity, bQuickUse) end;

-- Called when a player uses an item.
function CW:PlayerUseItem(player, itemTable, itemEntity) end;

-- Called when a player drops an item.
function CW:PlayerDropItem(player, itemTable, position, entity) end;

-- Called when a player destroys an item.
function CW:PlayerDestroyItem(player, itemTable) end;

-- Called when a player drops a weapon.
function CW:PlayerDropWeapon(player, itemTable, entity, weapon)
	if (itemTable:IsInstance() and IsValid(weapon)) then
		local clipOne = weapon:Clip1();
		local clipTwo = weapon:Clip2();
		
		if (clipOne > 0) then
			itemTable:SetData("ClipOne", clipOne);
		end;
		
		if (clipTwo > 0) then
			itemTable:SetData("ClipTwo", clipTwo);
		end;
	end;
end;

-- Called when a player's data should be restored.
function CW:PlayerRestoreData(player, data)
	if (!data["Whitelisted"]) then
		data["Whitelisted"] = {};
	end;
end;

-- Called to get whether a player can pickup an entity.
function CW:AllowPlayerPickup(player, entity)
	return false;
end;

-- Called when a player's temporary info should be saved.
function CW:PlayerSaveTempData(player, tempData) end;

-- Called when a player's temporary info should be restored.
function CW:PlayerRestoreTempData(player, tempData) end;

-- Called when a player selects a custom character option.
function CW:PlayerSelectCharacterOption(player, character, option) end;

-- Called when a player attempts to see another player's status.
function CW:PlayerCanSeeStatus(player, target)
	return "# "..target:UserID().." | "..target:Name().." | "..target:SteamName().." | "..target:SteamID().." | "..target:IPAddress();
end;

-- Called when a player attempts to see a player's chat.
function CW:PlayerCanSeePlayersChat(text, teamOnly, listener, speaker)
	return true;
end;

-- Called when a player attempts to hear another player's voice.
function CW:PlayerCanHearPlayersVoice(listener, speaker)
	if (!self.config:Get("voice_enabled"):Get()) then
		return false;
	elseif (speaker:GetData("VoiceBan")) then
		return false;
	end;

	if (speaker:GetActiveChannel() and listener:GetActiveChannel()) then
		local speakerChannel = speaker:GetActiveChannel();

		if (self.voice:IsInChannel(listener, speakerChannel)) then
			return true;
		end;
	end;

	if (self.config:Get("local_voice"):Get()) then
		if (listener:IsRagdolled(RAGDOLL_KNOCKEDOUT) or !listener:Alive()) then
			return false;
		elseif (speaker:IsRagdolled(RAGDOLL_KNOCKEDOUT) or !speaker:Alive()) then
			return false;
		elseif (listener:GetPos():Distance(speaker:GetPos()) > self.config:Get("talk_radius"):Get()) then
			return false;
		end;
	end;
	
	return true, true;
end;

-- Called when a player attempts to delete a character.
function CW:PlayerCanDeleteCharacter(player, character)
	if (self.config:Get("cash_enabled"):Get() and character.cash < self.config:Get("default_cash"):Get()) then
		if (!character.data["CharBanned"]) then
			return "You cannot delete characters with less than "..self.kernel:FormatCash(self.config:Get("default_cash"):Get(), nil, true)..".";
		end;
	end;
end;

-- Called when a player attempts to switch to a character.
function CW:PlayerCanSwitchCharacter(player, character)
	if (!player:Alive() and !player:IsCharacterMenuReset() and !player:GetSharedVar("CharBanned")) then
		return "You cannot switch characters when you are dead!";
	elseif (player:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
		return "You cannot switch characters when you are knocked out!";
	end;
	
	return true;
end;

-- Called when a player attempts to use a character.
function CW:PlayerCanUseCharacter(player, character)
	if (character.data["CharBanned"]) then
		return character.name.." is banned and cannot be used!";
	end;

	local faction = self.faction:FindByID(character.faction);
	local playerRank, rank = player:GetFactionRank(character);
	local factionCount = 0;
	local rankCount = 0;
	
	for k, v in ipairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			if (v:GetFaction() == character.faction) then
				if (player != v) then
					if (rank and v:GetFactionRank() == playerRank) then
						rankCount = rankCount + 1;
					end;
					
					factionCount = factionCount + 1;
				end;
			end;
		end;
	end;
	
	if (faction.playerLimit and factionCount >= faction.playerLimit) then
		return "There are too many characters of this faction online!";
	end;
	
	if (rank and rank.playerLimit and rankCount >= rank.playerLimit) then
		return "There are too many characters of this rank online!";
	end;
end;

-- Called when a player's weapons should be given.
function CW:PlayerGiveWeapons(player)
	local rankName, rank = player:GetFactionRank();
	local faction = self.faction:FindByID(player:GetFaction());

	if (rank and rank.weapons) then
		for k, v in pairs(rank.weapons) do
			self.player:GiveSpawnWeapon(player, v);
		end;
	end;

	if (faction and faction.weapons) then
		for k, v in pairs(faction.weapons) do
			self.player:GiveSpawnWeapon(player, v);
		end;
	end;
end;

-- Called when a player deletes a character.
function CW:PlayerDeleteCharacter(player, character) end;

-- Called when a player's armor is set.
function CW:PlayerArmorSet(player, newArmor, oldArmor)
	if (player:IsRagdolled()) then
		player:GetRagdollTable().armor = newArmor;
	end;
end;

-- Called when a player's health is set.
function CW:PlayerHealthSet(player, newHealth, oldHealth)
	local bIsRagdolled = player:IsRagdolled();
	local maxHealth = player:GetMaxHealth();
	
	if (newHealth > oldHealth) then
		self.limb:HealBody(player, (newHealth - oldHealth) / 2);
	end;
	
	if (newHealth >= maxHealth) then
		self.limb:HealBody(player, 100);
		player:RemoveAllDecals();
		
		if (bIsRagdolled) then
			player:GetRagdollEntity():RemoveAllDecals();
		end;
	end;
	
	if (bIsRagdolled) then
		player:GetRagdollTable().health = newHealth;
	end;
end;

-- Called when a player attempts to own a door.
function CW:PlayerCanOwnDoor(player, door)
	if (self.entity:IsDoorUnownable(door)) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to view a door.
function CW:PlayerCanViewDoor(player, door)
	if (self.entity:IsDoorUnownable(door)) then
		return false;
	end;
	
	return true;
end;

-- Called when a player attempts to holster a weapon.
function CW:PlayerCanHolsterWeapon(player, itemTable, weapon, bForce, bNoMsg)
	if (self.player:GetSpawnWeapon(player, itemTable("weaponClass"))) then
		if (!bNoMsg) then
			self.player:Notify(player, L(player, "CannotHolsterWeapon"));
		end;
		
		return false;
	elseif (itemTable.CanHolsterWeapon) then
		return itemTable:CanHolsterWeapon(player, weapon, bForce, bNoMsg);
	else
		return true;
	end;
end;

-- Called when a player attempts to drop a weapon.
function CW:PlayerCanDropWeapon(player, itemTable, weapon, bNoMsg)
	if (self.player:GetSpawnWeapon(player, itemTable("weaponClass"))) then
		if (!bNoMsg) then
			self.player:Notify(player, L(player, "CannotDropWeapon"));
		end;
		
		return false;
	elseif (itemTable.CanDropWeapon) then
		return itemTable:CanDropWeapon(player, bNoMsg);
	else
		return true;
	end;
end;

-- Called when a player attempts to use an item.
function CW:PlayerCanUseItem(player, itemTable, bNoMsg)
	if (self.item:IsWeapon(itemTable) and self.player:GetSpawnWeapon(player, itemTable("weaponClass"))) then
		if (!bNoMsg) then
			self.player:Notify(player, L(player, "CannotUseWeapon"));
		end;
		
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to drop an item.
function CW:PlayerCanDropItem(player, itemTable, bNoMsg) return true; end;

-- Called when a player attempts to destroy an item.
function CW:PlayerCanDestroyItem(player, itemTable, bNoMsg) return true; end;

-- Called when a player attempts to knockout a player.
function CW:PlayerCanKnockout(player, target) return true; end;

-- Called when a player attempts to use the radio.
function CW:PlayerCanRadio(player, text, listeners, eavesdroppers) return true; end;

-- Called when death attempts to clear a player's name.
function CW:PlayerCanDeathClearName(player, attacker, damageInfo) return false; end;

-- Called when death attempts to clear a player's recognised names.
function CW:PlayerCanDeathClearRecognisedNames(player, attacker, damageInfo) return false; end;

-- Called when a player's ragdoll attempts to take damage.
function CW:PlayerRagdollCanTakeDamage(player, ragdoll, inflictor, attacker, hitGroup, damageInfo)
	if (!attacker:IsPlayer() and player:GetRagdollTable().immunity) then
		if (CurTime() <= player:GetRagdollTable().immunity) then
			return false;
		end;
	end;
	
	return true;
end;

-- Called when the player attempts to be ragdolled.
function CW:PlayerCanRagdoll(player, state, delay, decay, ragdoll)
	return true;
end;

-- Called when the player attempts to be unragdolled.
function CW:PlayerCanUnragdoll(player, state, ragdoll)
	return true;
end;

-- Called when a player has been ragdolled.
function CW:PlayerRagdolled(player, state, ragdoll)
	player:SetSharedVar("FallenOver", false);
end;

-- Called when a player has been unragdolled.
function CW:PlayerUnragdolled(player, state, ragdoll)
	player:SetSharedVar("FallenOver", false);
end;

-- Called to check if a player does have a flag.
function CW:PlayerDoesHaveFlag(player, flag)
	if (string.find(self.config:Get("default_flags"):Get(), flag)) then
		return true;
	end;
end;

-- Called when a player's model should be set.
function CW:PlayerSetModel(player)
	self.player:SetDefaultModel(player);
	self.player:SetDefaultSkin(player);
end;

-- Called to check if a player does have door access.
function CW:PlayerDoesHaveDoorAccess(player, door, access, isAccurate)
	if (self.entity:GetOwner(door) != player) then
		local key = player:GetCharacterKey();
		
		if (door.accessList and door.accessList[key]) then
			if (isAccurate) then
				return door.accessList[key] == access;
			else
				return door.accessList[key] >= access;
			end;
		end;
		
		return false;
	else
		return true;
	end;
end;

-- Called to check if a player does know another player.
function CW:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
	return realValue;
end;

-- Called when a player attempts to lock an entity.
function CW:PlayerCanLockEntity(player, entity)
	if (self.entity:IsDoor(entity)) then
		return self.player:HasDoorAccess(player, entity);
	else
		return true;
	end;
end;

-- Called when a player's class has been set.
function CW:PlayerClassSet(player, newClass, oldClass, noRespawn, addDelay, noModelChange) end;

-- Called when a player attempts to unlock an entity.
function CW:PlayerCanUnlockEntity(player, entity)
	if (self.entity:IsDoor(entity)) then
		return self.player:HasDoorAccess(player, entity);
	else
		return true;
	end;
end;

-- Called when a player attempts to use a door.
function CW:PlayerCanUseDoor(player, door)
	if (self.entity:GetOwner(door) and !self.player:HasDoorAccess(player, door)) then
		return false;
	end;
	
	if (self.entity:IsDoorFalse(door)) then
		return false;
	end;
	
	return true;
end;

-- Called when a player uses a door.
function CW:PlayerUseDoor(player, door) end;

-- Called when a player attempts to use an entity in a vehicle.
function CW:PlayerCanUseEntityInVehicle(player, entity, vehicle)
	if (entity.UsableInVehicle or self.entity:IsDoor(entity)) then
		return true;
	end;
end;

-- Called when a player's ragdoll attempts to decay.
function CW:PlayerCanRagdollDecay(player, ragdoll, seconds)
	return true;
end;

-- Called when a player attempts to exit a vehicle.
function CW:CanExitVehicle(vehicle, player)
	local curTime = CurTime();

	if (player.cwNextExitVehicle and player.cwNextExitVehicle > curTime) then
		return false;
	end;
	
	if (IsValid(player) and player:IsPlayer()) then
		local trace = player:GetEyeTraceNoCursor();
		
		if (IsValid(trace.Entity) and !trace.Entity:IsVehicle()) then
			if (plugin.Call("PlayerCanUseEntityInVehicle", player, trace.Entity, vehicle)) then
				return false;
			end;
		end;
	end;
	
	if (self.entity:IsChairEntity(vehicle) and !IsValid(vehicle:GetParent())) then
		local trace = player:GetEyeTraceNoCursor();
		
		if (trace.HitPos:Distance(player:GetShootPos()) <= 192) then
			trace = {
				start = trace.HitPos,
				endpos = trace.HitPos - Vector(0, 0, 1024),
				filter = {player, vehicle}
			};
			
			player.cwExitVehiclePos = util.TraceLine(trace).HitPos;
			
			player:SetMoveType(MOVETYPE_NOCLIP);
		else
			return false;
		end;
	end;
	
	return true;
end;

-- Called when a player leaves a vehicle.
function CW:PlayerLeaveVehicle(player, vehicle)
	timer.Simple(FrameTime() * 0.5, function()
		if (IsValid(player) and !player:InVehicle()) then
			if (IsValid(vehicle)) then
				if (self.entity:IsChairEntity(vehicle)) then
					local position = player.cwExitVehiclePos or vehicle:GetPos();
					local targetPosition = self.player:GetSafePosition(player, position, vehicle);
					
					if (targetPosition) then
						player:SetMoveType(MOVETYPE_NOCLIP);
						player:SetPos(targetPosition);
					end;
					
					player:SetMoveType(MOVETYPE_WALK);
					player.cwExitVehiclePos = nil;
				end;
			end;
		end;
	end);
end;

-- Called when a player attempts to enter a vehicle.
function CW:CanPlayerEnterVehicle(player, vehicle, role)
	return true;
end;

-- Called when a player enters a vehicle.
function CW:PlayerEnteredVehicle(player, vehicle, class)
	timer.Simple(FrameTime() * 0.5, function()
		if (IsValid(player)) then
			local model = player:GetModel();
			local class = self.animation:GetModelClass(model);
			
			if (IsValid(vehicle) and !string.find(model, "/player/")) then
				if (class == "maleHuman" or class == "femaleHuman") then
					if (self.entity:IsChairEntity(vehicle)) then
						player:SetLocalPos(Vector(16.5438, -0.1642, -20.5493));
					else
						player:SetLocalPos(Vector(30.1880, 4.2020, -6.6476));
					end;
				end;
			end;
			
			player:SetCollisionGroup(COLLISION_GROUP_PLAYER);
		end;
	end);
end;

-- Called when a player attempts to change class.
function CW:PlayerCanChangeClass(player, class)
	local curTime = CurTime();
	
	if (player.cwNextChangeClass and curTime < player.cwNextChangeClass) then
		self.player:Notify(player, L(player, "CannotChangeClassFor",
			math.ceil(player.cwNextChangeClass - curTime))
		);
		
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to earn wages cash.
function CW:PlayerCanEarnWagesCash(player, cash)
	return true;
end;

-- Called when a player is given wages cash.
function CW:PlayerGiveWagesCash(player, cash, wagesName)
	return true;
end;

-- Called when a player earns wages cash.
function CW:PlayerEarnWagesCash(player, cash) end;

-- Called when Clockwork has loaded all of the entities.
function CW:ClockworkInitPostEntity() end;

-- Called when a player attempts to say something in-character.
function CW:PlayerCanSayIC(player, text)
	if ((!player:Alive() or player:IsRagdolled(RAGDOLL_FALLENOVER)) and !self.player:GetDeathCode(player, true)) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to say something out-of-character.
function CW:PlayerCanSayOOC(player, text) return true; end;

-- Called when a player attempts to say something locally out-of-character.
function CW:PlayerCanSayLOOC(player, text) return true; end;

-- Called when attempts to use a command.
function CW:PlayerCanUseCommand(player, commandTable, arguments)
	return true;
end;

-- Called when a player speaks from the client.
function CW:PlayerSay(player, text, bPublic)
	local prefix = self.config:Get("command_prefix"):Get();
	local prefixLength = string.len(prefix);

 	if (string.sub(text, 1, prefixLength) == prefix) then
		local arguments = self.kernel:ExplodeByTags(text, " ", "\"", "\"", true);
		local command = string.sub(arguments[1], prefixLength + 1);
		local realCommand = self.command:GetAlias()[command] or command;

		return string.Replace(text, prefix..command, prefix..realCommand);
 	end;
end;

-- Called when a player attempts to suicide.
function CW:CanPlayerSuicide(player) return false; end;

-- Called when a player attempts to punt an entity with the gravity gun.
function CW:GravGunPunt(player, entity)
	return self.config:Get("enable_gravgun_punt"):Get();
end;

-- Called when a player attempts to pickup an entity with the gravity gun.
function CW:GravGunPickupAllowed(player, entity)
	if (IsValid(entity)) then
		if (!self.player:IsAdmin(player) and !self.entity:IsInteractable(entity)) then
			return false;
		else
			return self.BaseClass:GravGunPickupAllowed(player, entity);
		end;
	end;
	
	return false;
end;

-- Called when a player picks up an entity with the gravity gun.
function CW:GravGunOnPickedUp(player, entity)
	player.cwIsHoldingEnt = entity;
	entity.cwIsBeingHeld = player;
end;

-- Called when a player drops an entity with the gravity gun.
function CW:GravGunOnDropped(player, entity)
	player.cwIsHoldingEnt = nil;
	entity.cwIsBeingHeld = nil;
end;

-- Called when a player attempts to unfreeze an entity.
function CW:CanPlayerUnfreeze(player, entity, physicsObject)
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (self.config:Get("enable_prop_protection"):Get() and !bIsAdmin) then
		local ownerKey = entity:GetOwnerKey();
		
		if (ownerKey and player:GetCharacterKey() != ownerKey) then
			return false;
		end;
	end;
	
	if (!bIsAdmin and !self.entity:IsInteractable(entity)) then
		return false;
	end;
	
	if (entity:IsVehicle()) then
		if (IsValid(entity:GetDriver())) then
			return false;
		end;
	end;
	
	return true;
end;

-- Called when a player attempts to freeze an entity with the physics gun.
function CW:OnPhysgunFreeze(weapon, physicsObject, entity, player)
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (self.config:Get("enable_prop_protection"):Get() and !bIsAdmin) then
		local ownerKey = entity:GetOwnerKey();
		
		if (ownerKey and player:GetCharacterKey() != ownerKey) then
			return false;
		end;
	end;
	
	if (!bIsAdmin and self.entity:IsChairEntity(entity)) then
		local entities = ents.FindInSphere(entity:GetPos(), 64);
		
		for k, v in pairs(entities) do
			if (self.entity:IsDoor(v)) then
				return false;
			end;
		end;
	end;
	
	if (entity:GetPhysicsObject():IsPenetrating()) then
		return false;
	end;
	
	if (!bIsAdmin and entity.PhysgunDisabled) then
		return false;
	end;
	
	if (!bIsAdmin and !self.entity:IsInteractable(entity)) then
		return false;
	else
		return self.BaseClass:OnPhysgunFreeze(weapon, physicsObject, entity, player);
	end;
end;

-- Called when a player attempts to pickup an entity with the physics gun.
function CW:PhysgunPickup(player, entity)
	local bCanPickup = nil;
	local bIsAdmin = self.player:IsAdmin(player);

	if (!self.config:Get("enable_map_props_physgrab"):Get()) then
		if (self.entity:IsMapEntity(entity)) then
			bCanPickup = false;
		end;
	end;
	
	if (!bIsAdmin and !self.entity:IsInteractable(entity)) then
		return false;
	end;
	
	if (!bIsAdmin and self.entity:IsPlayerRagdoll(entity)) then
		return false;
	end;
	
	if (!bIsAdmin and entity:GetClass() == "prop_ragdoll") then
		local ownerKey = entity:GetOwnerKey();
		
		if (ownerKey and player:GetCharacterKey() != ownerKey) then
			return false;
		end;
	end;
	
	if (!bIsAdmin) then
		bCanPickup = self.BaseClass:PhysgunPickup(player, entity);
	else
		bCanPickup = true;
	end;
	
	if (self.entity:IsChairEntity(entity) and !bIsAdmin) then
		local entities = ents.FindInSphere(entity:GetPos(), 256);
		
		for k, v in pairs(entities) do
			if (self.entity:IsDoor(v)) then
				return false;
			end;
		end;
	end;
	
	if (self.config:Get("enable_prop_protection"):Get() and !bIsAdmin) then
		local ownerKey = entity:GetOwnerKey();
		
		if (ownerKey and player:GetCharacterKey() != ownerKey) then
			bCanPickup = false;
		end;
	end;
	
	if (entity:IsPlayer() and entity:InVehicle() or entity.cwObserverMode) then
		bCanPickup = false;
	end;
	
	if (bCanPickup) then
		player.cwIsHoldingEnt = entity;
		entity.cwIsBeingHeld = player;
		
		if (!entity:IsPlayer()) then
			if (self.config:Get("prop_kill_protection"):Get()
			and !entity.cwLastCollideGroup) then
				self.entity:StopCollisionGroupRestore(entity);
				entity.cwLastCollideGroup = entity:GetCollisionGroup();
				entity:SetCollisionGroup(COLLISION_GROUP_WEAPON);
			end;
			
			entity.cwDamageImmunity = CurTime() + 60;
		elseif (!entity.cwMoveType) then
			entity.cwMoveType = entity:GetMoveType();
			entity:SetMoveType(MOVETYPE_NOCLIP);
		end;
		
		return true;
	else
		return false;
	end;
end;

-- Called when a player attempts to drop an entity with the physics gun.
function CW:PhysgunDrop(player, entity)
	if (!entity:IsPlayer() and entity.cwLastCollideGroup) then
		self.entity:ReturnCollisionGroup(
			entity, entity.cwLastCollideGroup
		);
		
		entity.cwLastCollideGroup = nil;
	elseif (entity.cwMoveType) then
		entity:SetMoveType(MOVETYPE_WALK);
		entity.cwMoveType = nil;
	end;
	
	entity.cwDamageImmunity = CurTime() + 60;
	player.cwIsHoldingEnt = nil;
	entity.cwIsBeingHeld = nil;
end;

-- Called when a player attempts to spawn an NPC.
function CW:PlayerSpawnNPC(player, model)
	if (!self.player:HasFlags(player, "n")) then
		return false;
	end;
	
	if (!player:Alive() or player:IsRagdolled()) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		
		return false;
	end;
	
	if (!self.player:IsAdmin(player)) then
		return false;
	else
		return true;
	end;
end;

-- Called when an NPC has been killed.
function CW:OnNPCKilled(entity, attacker, inflictor) end;

-- Called to get whether an entity is being held.
function CW:GetEntityBeingHeld(entity)
	return entity.cwIsBeingHeld or entity:IsPlayerHolding();
end;

-- Called when an entity is removed.
function CW:EntityRemoved(entity)
	if (!self.kernel:IsShuttingDown()) then
		if (IsValid(entity)) then
			if (entity:GetClass() == "prop_ragdoll") then
				if (entity.cwIsBelongings and entity.cwInventory and entity.cwCash
				and (table.Count(entity.cwInventory) > 0 or entity.cwCash > 0)) then
					local belongings = ents.Create("cw_belongings");
						
					belongings:SetAngles(Angle(0, 0, -90));
					belongings:SetData(entity.cwInventory, entity.cwCash);
					belongings:SetPos(entity:GetPos() + Vector(0, 0, 32));
					belongings:Spawn();
						
					entity.cwInventory = nil;
					entity.cwCash = nil;
				end;
			end;

			local allProperty = self.player:GetAllProperty();
			local entIndex = entity:EntIndex();
			
			if (entity.cwGiveRefundTab
			and CurTime() <= entity.cwGiveRefundTab[1]) then
				if (IsValid(entity.cwGiveRefundTab[2])) then
					self.player:GiveCash(entity.cwGiveRefundTab[2], entity.cwGiveRefundTab[3], "Prop Refund");
				end;
			end;
			
			allProperty[entIndex] = nil;
			
			if (entity:GetClass() == "csItem") then
				self.item:RemoveItemEntity(entity);
			end;
		end;
		
		self.entity:ClearProperty(entity);
	end;
end;

-- Called when an entity's menu option should be handled.
function CW:EntityHandleMenuOption(player, entity, option, arguments)
	local class = entity:GetClass();
	
	if (class == "cw_item" and (arguments == "CW.itemTake" or arguments == "CW.itemUse")) then
		if (self.entity:BelongsToAnotherCharacter(player, entity)) then
			self.player:Notify(player, L(player, "DroppedItemsOtherChar"));
			return;
		end;
		
		local itemTable = entity.cwItemTable;
		local bQuickUse = (arguments == "CW.itemUse");
		
		if (itemTable) then
			local bDidPickupItem = true;
			local bCanPickup = (!itemTable.CanPickup or itemTable:CanPickup(player, bQuickUse, entity));
			
			if (bCanPickup != false) then
				player:SetItemEntity(entity);
				
				if (bQuickUse) then
					itemTable = player:GiveItem(itemTable, true);
					
					if (!self.player:InventoryAction(player, itemTable, "use")) then
						player:TakeItem(itemTable, true);
						bDidPickupItem = false;
					else
						player:FakePickup(entity);
					end;
				else
					local bSuccess, fault = player:GiveItem(itemTable);
					
					if (!bSuccess) then
						self.player:Notify(player, fault);
						bDidPickupItem = false;
					else
						player:FakePickup(entity);
					end;
				end;
				
				plugin.Call(
					"PlayerPickupItem", player, itemTable, entity, bQuickUse
				);
				
				if (bDidPickupItem) then
					if (!itemTable.OnPickup or itemTable:OnPickup(player, bQuickUse, entity) != false) then
						entity:Remove();
					end;
				end;

				local pickupSound = itemTable.pickupSound or "physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav"

				if (type(pickupSound) == "table") then
					pickupSound = pickupSound[math.random(1, #pickupSound)];
				end;

				player:EmitSound(pickupSound);
				
				player:SetItemEntity(nil);
			end;
			
		end;
	elseif (class == "cw_item" and arguments == "CW.itemExamine") then
		local itemTable = entity.cwItemTable;
		local examineText = itemTable.description;
			
		if (itemTable.GetEntityExamineText) then
			examineText = itemTable:GetEntityExamineText(entity);
		end;

		self.player:Notify(player, examineText);
	elseif (class == "cw_item" and arguments == "CW.itemAmmo") then
		local itemTable = entity.cwItemTable;
		
		if (self.item:IsWeapon(itemTable)) then
			if (itemTable:HasSecondaryClip() or itemTable:HasPrimaryClip()) then
				local clipOne = itemTable:GetData("ClipOne");
				local clipTwo = itemTable:GetData("ClipTwo");
				
				if (clipTwo > 0) then
					player:GiveAmmo(clipTwo, itemTable("secondaryAmmoClass"));
				end;
				
				if (clipOne > 0) then
					player:GiveAmmo(clipOne, itemTable("primaryAmmoClass"));
				end;
				
				itemTable:SetData("ClipOne", 0);
				itemTable:SetData("ClipTwo", 0);
				
				player:FakePickup(entity);
			end;
		end;
	elseif (class == "cw_item") then
		local itemTable = entity.cwItemTable;

		if (itemTable and itemTable.EntityHandleMenuOption) then
			itemTable:EntityHandleMenuOption(player, entity, option, arguments);
		end;
	elseif (entity:GetClass() == "cw_belongings" and arguments == "cwBelongingsOpen") then
		player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
		
		self.storage:Open(player, {
			name = "Belongings",
			cash = entity.cwCash,
			weight = 100,
			space = 200,
			entity = entity,
			distance = 192,
			inventory = entity.cwInventory,
			isOneSided = true,
			OnGiveCash = function(player, storageTable, cash)
				entity.cwCash = storageTable.cash;
			end,
			OnTakeCash = function(player, storageTable, cash)
				entity.cwCash = storageTable.cash;
			end,
			OnClose = function(player, storageTable, entity)
				if (IsValid(entity)) then
					if ((!entity.cwInventory and !entity.cwCash)
					or (table.Count(entity.cwInventory) == 0 and entity.cwCash == 0)) then
						entity:Explode(entity:BoundingRadius() * 2);
						entity:Remove();
					end;
				end;
			end,
			CanGiveItem = function(player, storageTable, itemTable)
				return false;
			end
		});
	elseif (class == "cw_shipment" and arguments == "cwShipmentOpen") then
		player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
		player:FakePickup(entity);
		
		self.storage:Open(player, {
			name = "Shipment",
			weight = entity.cwWeight,
			space = entity.cwSpace,
			entity = entity,
			distance = 192,
			inventory = entity.cwInventory,
			isOneSided = true,
			OnClose = function(player, storageTable, entity)
				if (IsValid(entity) and self.inventory:IsEmpty(entity.cwInventory)) then
					entity:Explode(entity:BoundingRadius() * 2);
					entity:Remove();
				end;
			end,
			CanGiveItem = function(player, storageTable, itemTable)
				return false;
			end
		});
	elseif (class == "cw_cash" and arguments == "cwCashTake") then
		if (self.entity:BelongsToAnotherCharacter(player, entity)) then
			self.player:Notify(player, L(player, "DroppedCashOtherChar", self.option:GetKey("name_cash", true)));
			return;
		end;
		
		self.player:GiveCash(player, entity.cwAmount, self.option:GetKey("name_cash"));
		player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
		player:FakePickup(entity);
		
		entity:Remove();
	end;
end;

-- Called when a player has spawned a prop.
function CW:PlayerSpawnedProp(player, model, entity)
	if (IsValid(entity)) then
		local scalePropCost = self.config:Get("scale_prop_cost"):Get();
		
		if (scalePropCost > 0) then
			local cost = math.ceil(math.max((entity:BoundingRadius() / 2) * scalePropCost, 1));
			local info = {cost = cost, name = "Prop"};
			
			plugin.Call("PlayerAdjustPropCostInfo", player, entity, info);
			
			if (self.player:CanAfford(player, info.cost)) then
				self.player:GiveCash(player, -info.cost, info.name);
				entity.cwGiveRefundTab = {CurTime() + 10, player, info.cost};
			else
				self.player:Notify(player, L(player, "YouNeedAnother", self.kernel:FormatCash(info.cost - player:GetCash(), nil, true)));
				entity:Remove();
				return;
			end;
		end;
		
		if (IsValid(entity)) then
			self.BaseClass:PlayerSpawnedProp(player, model, entity);
			entity:SetOwnerKey(player:GetCharacterKey());
			
			if (IsValid(entity)) then
				self.kernel:PrintLog(LOGTYPE_URGENT, player:Name().." has spawned '"..tostring(model).."'.");
				
				if (self.config:Get("prop_kill_protection"):Get()) then
					entity.cwDamageImmunity = CurTime() + 60;
				end;
			end;
		end;
	end;
end;

-- Called when a player attempts to spawn a prop.
function CW:PlayerSpawnProp(player, model)
	if (!self.player:HasFlags(player, "e")) then
		return false;
	end;
	
	if (!player:Alive() or player:IsRagdolled()) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		return false;
	end;
	
	if (self.player:IsAdmin(player)) then
		return true;
	end;
	
	return self.BaseClass:PlayerSpawnProp(player, model);
end;

-- Called when a player attempts to spawn a ragdoll.
function CW:PlayerSpawnRagdoll(player, model)
	if (!self.player:HasFlags(player, "r")) then return false; end;
	
	if (!player:Alive() or player:IsRagdolled()) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		
		return false;
	end;
	
	if (!self.player:IsAdmin(player)) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to spawn an effect.
function CW:PlayerSpawnEffect(player, model)
	if (!player:Alive() or player:IsRagdolled()) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		
		return false;
	end;
	
	if (!self.player:IsAdmin(player)) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player attempts to spawn a vehicle.
function CW:PlayerSpawnVehicle(player, model)
	if (!string.find(model, "chair") and !string.find(model, "seat")) then
		if (!self.player:HasFlags(player, "C")) then
			return false;
		end;
	elseif (!self.player:HasFlags(player, "c")) then
		return false;
	end;
	
	if (!player:Alive() or player:IsRagdolled()) then
		self.player:Notify(player, L(player, "CannotActionRightNow"));
		
		return false;
	end;
	
	if (self.player:IsAdmin(player)) then
		return true;
	end;
	
	return self.BaseClass:PlayerSpawnVehicle(player, model);
end;

-- Called when a player attempts to use a tool.
function CW:CanTool(player, trace, tool)
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (IsValid(trace.Entity)) then
		local bPropProtectionEnabled = self.config:Get("enable_prop_protection"):Get();
		local characterKey = player:GetCharacterKey();
		
		if (!bIsAdmin and !self.entity:IsInteractable(trace.Entity)) then
			return false;
		end;
		
		if (!bIsAdmin and self.entity:IsPlayerRagdoll(trace.Entity)) then
			return false;
		end;
		
		if (bPropProtectionEnabled and !bIsAdmin) then
			local ownerKey = trace.Entity:GetOwnerKey();
			
			if (ownerKey and characterKey != ownerKey) then
				return false;
			end;
		end;
		
		if (!bIsAdmin) then
			if (tool == "nail") then
				local newTrace = {};
				
				newTrace.start = trace.HitPos;
				newTrace.endpos = trace.HitPos + player:GetAimVector() * 16;
				newTrace.filter = {player, trace.Entity};
				
				newTrace = util.TraceLine(newTrace);
				
				if (IsValid(newTrace.Entity)) then
					if (!self.entity:IsInteractable(newTrace.Entity) or self.entity:IsPlayerRagdoll(newTrace.Entity)) then
						return false;
					end;
					
					if (bPropProtectionEnabled) then
						local ownerKey = newTrace.Entity:GetOwnerKey();
						
						if (ownerKey and characterKey != ownerKey) then
							return false;
						end;
					end;
				end;
			elseif (tool == "remover" and player:KeyDown(IN_ATTACK2) and !player:KeyDownLast(IN_ATTACK2)) then
				if (!trace.Entity:IsMapEntity()) then
					local entities = constraint.GetAllConstrainedEntities(trace.Entity);
					
					for k, v in pairs(entities) do
						if (v:IsMapEntity() or self.entity:IsPlayerRagdoll(v)) then
							return false;
						end;
						
						if (bPropProtectionEnabled) then
							local ownerKey = v:GetOwnerKey();
							
							if (ownerKey and characterKey != ownerKey) then
								return false;
							end;
						end;
					end
				else
					return false;
				end;
			end
		end;
	end;
	
	if (!bIsAdmin) then
		if (tool == "dynamite" or tool == "duplicator") then
			return false;
		end;
	
		return self.BaseClass:CanTool(player, trace, tool);
	else
		return true;
	end;
end;

-- Called when a player attempts to use the property menu.
function CW:CanProperty(player, property, entity)
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (!player:Alive() or player:IsRagdolled() or !bIsAdmin) then
		return false;
	end;
	
	return self.BaseClass:CanProperty(player, property, entity);
end;

-- Called when a player attempts to use drive.
function CW:CanDrive(player, entity)
	local bIsAdmin = self.player:IsAdmin(player);
	
	if (!player:Alive() or player:IsRagdolled() or !bIsAdmin) then
		return false;
	end;

	return self.BaseClass:CanDrive(player, entity);
end;

-- Called when a player attempts to NoClip.
function CW:PlayerNoClip(player)
	if (player:IsRagdolled()) then
		return false;
	elseif (player:IsSuperAdmin()) then
		return true;
	else
		return false;
	end;
end;

-- Called when a player's character has initialized.
function CW:PlayerCharacterInitialized(player)
	netstream.Start(player, "InvClear", true);
	netstream.Start(player, "AttrClear", true);
	netstream.Start(player, "ReceiveLimbDamage", player:GetCharacterData("LimbData"));
	
	if (!self.class:FindByID(player:Team())) then
		self.class:AssignToDefault(player);
	end;
	
	player.cwAttrProgress = player.cwAttrProgress or {};
	player.cwAttrProgressTime = 0;
	
	for k, v in pairs(self.attribute:GetAll()) do
		player:UpdateAttribute(k);
	end;
	
	for k, v in pairs(player:GetAttributes()) do
		player.cwAttrProgress[k] = math.floor(v.progress);
	end;
	
	local startHintsDelay = 4;
	local starterHintsTable = {
		"Directory",
		"Give Name",
		"Target Recognises",
		"Raise Weapon"
	};
	
	for k, v in pairs(starterHintsTable) do
		local hintTable = self.hint:Find(v);
		
		if (hintTable and !player:GetData("Hint"..k)) then
			if (!hintTable.Callback or hintTable.Callback(player) != false) then
				timer.Simple(startHintsDelay, function()
					if (IsValid(player)) then
						self.hint:Send(player, hintTable.text, 30);
						player:SetData("Hint"..k, true);
					end;
				end);
				
				startHintsDelay = startHintsDelay + 30;
			end;
		end;
	end;
	
	if (startHintsDelay > 4) then
		player.cwViewStartHints = true;
		
		timer.Simple(startHintsDelay, function()
			if (IsValid(player)) then
				player.cwViewStartHints = false;
			end;
		end);
	end;
	
	timer.Simple(FrameTime() * 0.5, function()
		self.inventory:SendUpdateAll(player);
		player:NetworkAccessories();
	end);
	
	netstream.Start(player, "CharacterInit", player:GetCharacterKey());

	local faction = self.faction:FindByID(player:GetFaction());
	local spawnRank = self.faction:GetDefaultRank(player:GetFaction()) or self.faction:GetLowestRank(player:GetFaction());
	
	player:SetFactionRank(player:GetFactionRank() or spawnRank);
	
	if (string.find(player:Name(), "SCN")) then
		player:SetFactionRank("SCN");
	end;
	
	local rankName, rankTable = player:GetFactionRank();
	
	if (rankTable) then
		if (rankTable.class and self.class:GetAll()[rankTable.class]) then

			self.class:Set(player, rankTable.class);
		end;
		
		if (rankTable.model) then
			player:SetModel(rankTable.model);
		end;
	end;
end;

-- Called when a player has used their death code.
function CW:PlayerDeathCodeUsed(player, commandTable, arguments) end;

-- Called when a player has created a character.
function CW:PlayerCharacterCreated(player, character) end;

-- Called when a player's character has unloaded.
function CW:PlayerCharacterUnloaded(player)
	self.player:SetupRemovePropertyDelays(player);
	self.player:DisableProperty(player);
	self.player:SetRagdollState(player, RAGDOLL_RESET);
	self.storage:Close(player, true)
	player:SetTeam(TEAM_UNASSIGNED);
end;

-- Called when a player's character has loaded.
function CW:PlayerCharacterLoaded(player)
	player:SetSharedVar("InvWeight", self.config:Get("default_inv_weight"):Get());
	player:SetSharedVar("InvSpace", self.config:Get("default_inv_space"):Get());
	player.cwCharLoadedTime = CurTime();
	player.cwCrouchedSpeed = self.config:Get("crouched_speed"):Get();
	player.cwClipTwoInfo = {weapon = NULL, ammo = 0};
	player.cwClipOneInfo = {weapon = NULL, ammo = 0};
	player.cwInitialized = true;
	player.cwAttrBoosts = player.cwAttrBoosts or {};
	player.cwRagdollTab = player.cwRagdollTab or {};
	player.cwSpawnWeps = player.cwSpawnWeps or {};
	player.cwFirstSpawn = true;
	player.cwLightSpawn = false;
	player.cwChangeClass = false;
	player.cwInfoTable = player.cwInfoTable or {};
	player.cwSpawnAmmo = player.cwSpawnAmmo or {};
	player.cwJumpPower = self.config:Get("jump_power"):Get();
	player.cwWalkSpeed = self.config:Get("walk_speed"):Get();
	player.cwRunSpeed = self.config:Get("run_speed"):Get();
	
	hook.Call("PlayerRestoreCharacterData", Clockwork, player, player:QueryCharacter("Data"));
	hook.Call("PlayerRestoreTempData", Clockwork, player, player:CreateTempData());
	
	self.player:SetCharacterMenuState(player, CHARACTER_MENU_CLOSE);
	plugin.Call("PlayerCharacterInitialized", player);
	
	self.player:RestoreRecognisedNames(player);
	self.player:ReturnProperty(player);
	self.player:SetInitialized(player, true);
	
	player.cwFirstSpawn = false;
	
	local charactersTable = self.config:Get("mysql_characters_table"):Get();
	local schemaFolder = self.kernel:GetSchemaFolder();
	local characterID = player:GetCharacterID();
	local onNextLoad = player:QueryCharacter("OnNextLoad");
	local steamID = player:SteamID();
	local query = "UPDATE "..charactersTable.." SET _OnNextLoad = \"\" WHERE";
	local playerFlags = player:GetPlayerFlags();
	
	if (onNextLoad != "") then
		local queryObj = self.database:Update(charactersTable);
			queryObj:SetValue("_OnNextLoad", "");
			queryObj:AddWhere("_Schema = ?", schemaFolder);
			queryObj:AddWhere("_SteamID = ?", steamID);
			queryObj:AddWhere("_CharacterID = ?", characterID);
		queryObj:Push();
		
		player:SetCharacterData("OnNextLoad", "", true);
		
		CHARACTER = player:GetCharacter();
			PLAYER = player;
				RunString(onNextLoad);
			PLAYER = nil;
		CHARACTER = nil;
	end;
	
	local itemsList = self.inventory:GetAsItemsList(
		player:GetInventory()
	);
	
	for k, v in pairs(itemsList) do
		if (v.OnRestorePlayerGear) then
			v:OnRestorePlayerGear(player);
		end;
	end;
	
	if (playerFlags) then
		self.player:GiveFlags(player, playerFlags);
	end;
end;

-- Called when a player's property should be restored.
function CW:PlayerReturnProperty(player) end;

-- Called when config has initialized for a player.
function CW:PlayerConfigInitialized(player)
	plugin.Call("PlayerSendDataStreamInfo", player);
	
	if (!player:IsBot()) then
		timer.Simple(FrameTime() * 32, function()
			if (IsValid(player)) then
				netstream.Start(player, "DataStreaming", true);
			end;
		end);
	else
		plugin.Call("PlayerDataStreamInfoSent", player);
	end;
end;

-- Called when a player has used their radio.
function CW:PlayerRadioUsed(player, text, listeners, eavesdroppers) end;

-- Called when a player's drop weapon info should be adjusted.
function CW:PlayerAdjustDropWeaponInfo(player, info)
	return true;
end;

-- Called when a player's character creation info should be adjusted.
function CW:PlayerAdjustCharacterCreationInfo(player, info, data) end;

-- Called when a player's order item should be adjusted.
function CW:PlayerAdjustOrderItemTable(player, itemTable) end;

-- Called when a player's next punch info should be adjusted.
function CW:PlayerAdjustNextPunchInfo(player, info) end;

-- Called when a player uses an unknown item function.
function CW:PlayerUseUnknownItemFunction(player, itemTable, itemFunction) end;

-- Called when a player's character table should be adjusted.
function CW:PlayerAdjustCharacterTable(player, character)
	if (self.faction:GetStored()[character.faction]) then
		if (self.faction:GetStored()[character.faction].whitelist
		and !self.player:IsWhitelisted(player, character.faction)) then
			character.data["CharBanned"] = true;
		end;
	else
		return true;
	end;
end;

-- Called when a player's character screen info should be adjusted.
function CW:PlayerAdjustCharacterScreenInfo(player, character, info)
	local playerRank, rank = player:GetFactionRank();

	if (rank and rank.model) then
		info.model = rank.model;
	end;
end;

-- Called when a player's prop cost info should be adjusted.
function CW:PlayerAdjustPropCostInfo(player, entity, info) end;

-- Called when a player's death info should be adjusted.
function CW:PlayerAdjustDeathInfo(player, info) end;

-- Called when chat box info should be adjusted.
function CW:ChatBoxAdjustInfo(info)
	if (info.class == "ic") then
		self.kernel:PrintLog(LOGTYPE_GENERIC, info.speaker:Name().." says: \""..info.text.."\"");
	elseif (info.class == "looc") then
		self.kernel:PrintLog(LOGTYPE_GENERIC, "[LOOC] "..info.speaker:Name()..": "..info.text);
	end;
end;

-- Called when a player's radio text should be adjusted.
function CW:PlayerAdjustRadioInfo(player, info) end;

-- Called when a player should gain a frag.
function CW:PlayerCanGainFrag(player, victim) return true; end;

-- Called just after a player spawns.
function CW:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)	
	if (firstSpawn) then
		local attrBoosts = player:GetCharacterData("AttrBoosts");
		local health = player:GetCharacterData("Health");
		local armor = player:GetCharacterData("Armor");
		
		if (health and health > 1) then
			player:SetHealth(health);
		end;
		
		if (armor and armor > 1) then
			player:SetArmor(armor);
		end;
		
		if (attrBoosts) then
			for k, v in pairs(attrBoosts) do
				for k2, v2 in pairs(v) do
					self.attributes:Boost(player, k2, k, v2.amount, v2.duration);
				end;
			end;
		end;
	else
		player:SetCharacterData("AttrBoosts", nil);
		player:SetCharacterData("Health", nil);
		player:SetCharacterData("Armor", nil);
	end;
	
	player:Fire("Targetname", player:GetFaction(), 0);
end;

-- Called just before a player would take damage.
function CW:PrePlayerTakeDamage(player, attacker, inflictor, damageInfo) end;

-- Called when a player should take damage.
function CW:PlayerShouldTakeDamage(player, attacker, inflictor, damageInfo)
	return !self.player:IsNoClipping(player);
end;

-- Called when a player is attacked by a trace.
function CW:PlayerTraceAttack(player, damageInfo, direction, trace)
	player.cwLastHitGroup = trace.HitGroup;
	return false;
end;

-- Called just before a player dies.
function CW:DoPlayerDeath(player, attacker, damageInfo)
	self.player:DropWeapons(player, attacker);
	self.player:SetAction(player, false);
	self.player:SetDrunk(player, false);
	
	local deathSound = plugin.Call("PlayerPlayDeathSound", player, player:GetGender());
	local decayTime = self.config:Get("body_decay_time"):Get();

	if (decayTime > 0) then
		self.player:SetRagdollState(player, RAGDOLL_KNOCKEDOUT, nil, decayTime, self.kernel:ConvertForce(damageInfo:GetDamageForce() * 32));
	else
		self.player:SetRagdollState(player, RAGDOLL_KNOCKEDOUT, nil, 600, self.kernel:ConvertForce(damageInfo:GetDamageForce() * 32));
	end;
	
	if (plugin.Call("PlayerCanDeathClearRecognisedNames", player, attacker, damageInfo)) then
		self.player:ClearRecognisedNames(player);
	end;
	
	if (plugin.Call("PlayerCanDeathClearName", player, attacker, damageInfo)) then
		self.player:ClearName(player);
	end;
	
	if (deathSound) then
		player:EmitSound("physics/flesh/flesh_impact_hard"..math.random(1, 5)..".wav", 150);
		
		timer.Simple(FrameTime() * 25, function()
			if (IsValid(player)) then
				player:EmitSound(deathSound);
			end;
		end);
	end;
	
	player:SetForcedAnimation(false);
	player:SetCharacterData("Ammo", {}, true);
	player:StripWeapons();
	player:Extinguish();
	player.cwSpawnAmmo = {};
	player:StripAmmo();
	player:AddDeaths(1);
	player:UnLock();
	
	if (IsValid(attacker) and attacker:IsPlayer() and player != attacker) then
		if (plugin.Call("PlayerCanGainFrag", attacker, player)) then
			attacker:AddFrags(1);
		end;
	end;
end;

-- Called when a player dies.
function CW:PlayerDeath(player, inflictor, attacker, damageInfo)
	self.kernel:CalculateSpawnTime(player, inflictor, attacker, damageInfo);
	
	local ragdoll = player:GetRagdollEntity();

	if (ragdoll) then		
		if (IsValid(inflictor) and inflictor:GetClass() == "prop_combine_ball") then
			if (damageInfo) then
				self.entity:Disintegrate(ragdoll, 3, damageInfo:GetDamageForce() * 32);
			else
				self.entity:Disintegrate(ragdoll, 3);
			end;
		end;
	end;
	
	if (attacker:IsPlayer()) then
		if (IsValid(attacker:GetActiveWeapon())) then
			local weapon = attacker:GetActiveWeapon();
			local itemTable = self.item:GetByWeapon(weapon);
		
			if (IsValid(weapon) and itemTable) then
				self.kernel:PrintLog(LOGTYPE_CRITICAL, attacker:Name().." has dealt "..tostring(math.ceil(damageInfo:GetDamage())).." damage to "..player:Name().." with "..itemTable("name")..", killing them!");
			else
				self.kernel:PrintLog(LOGTYPE_CRITICAL, attacker:Name().." has dealt "..tostring(math.ceil(damageInfo:GetDamage())).." damage to "..player:Name().." with "..CW.player:GetWeaponClass(attacker)..", killing them!");
			end;
		else
			self.kernel:PrintLog(LOGTYPE_CRITICAL, attacker:Name().." has dealt "..tostring(math.ceil(damageInfo:GetDamage())).." damage to "..player:Name()..", killing them!");
		end;
	else
		self.kernel:PrintLog(LOGTYPE_CRITICAL, attacker:GetClass().." has dealt "..tostring(math.ceil(damageInfo:GetDamage())).." damage to "..player:Name()..", killing them!");
	end;
end;

-- Called when an item entity has taken damage.
function CW:ItemEntityTakeDamage(itemEntity, itemTable, damageInfo)
	return true;
end;

-- Called when an item entity has been destroyed.
function CW:ItemEntityDestroyed(itemEntity, itemTable) end;

-- Called when an item's network observers are needed.
function CW:ItemGetNetworkObservers(itemTable, info)
	local uniqueID = itemTable("uniqueID");
	local itemID = itemTable("itemID");
	local entity = self.item:FindEntityByInstance(itemTable);
	
	if (entity) then
		info.sendToAll = true;
		return false;
	end;
	
	for k, v in pairs(player.GetAll()) do
		if (v:HasInitialized()) then
			local inventory = self.storage:Query(v, "inventory");
			
			if ((inventory and inventory[uniqueID]
			and inventory[uniqueID][itemID]) or v:HasItemInstance(itemTable)) then
				info.observers[v] = v;
			elseif (v:HasItemAsWeapon(itemTable)) then
				info.observers[v] = v;
			end;
		end;
	end;
end;

-- Called when a player's weapons should be given.
function CW:PlayerLoadout(player)
	local weapons = self.class:Query(player:Team(), "weapons");
	local ammo = self.class:Query(player:Team(), "ammo");
	
	player.cwSpawnWeps = {};
	player.cwSpawnAmmo = {};
	
	if (self.player:HasFlags(player, "t")) then
		self.player:GiveSpawnWeapon(player, "gmod_tool");
	end
	
	if (self.player:HasFlags(player, "p")) then
		self.player:GiveSpawnWeapon(player, "weapon_physgun");
		
		if (self.config:Get("custom_weapon_color"):Get()) then
			local weaponColor = player:GetInfo("cl_weaponcolor");

			player:SetWeaponColor(Vector(weaponColor));
		end;
	end
	
	self.player:GiveSpawnWeapon(player, "weapon_physcannon");
	
	if (self.config:Get("give_hands"):Get()) then
		self.player:GiveSpawnWeapon(player, "cw_hands");
	end;
	
	if (self.config:Get("give_keys"):Get()) then
		self.player:GiveSpawnWeapon(player, "cw_keys");
	end;
	
	if (weapons) then
		for k, v in pairs(weapons) do
			if (!player:HasItemByID(v)) then
				local itemTable = self.item:CreateInstance(v);
				
				if (!self.player:GiveSpawnItemWeapon(player, itemTable)) then
					player:Give(v);
				end;
			end;
		end;
	end;
	
	if (ammo) then
		for k, v in pairs(ammo) do
			self.player:GiveSpawnAmmo(player, k, v);
		end;
	end;
	
	plugin.Call("PlayerGiveWeapons", player);
	
	if (self.config:Get("give_hands"):Get()) then
		player:SelectWeapon("cw_hands");
	end;
end

-- Called when the server shuts down.
function CW:ShutDown()
	self.ShuttingDown = true;
end;

-- Called when a player presses F1.
function CW:ShowHelp(player)
	netstream.Start(player, "InfoToggle", true);
end;

-- Called when a player presses F2.
function CW:ShowTeam(ply)
	if (!self.player:IsNoClipping(ply)) then
		local doRecogniseMenu = true;
		local entity = ply:GetEyeTraceNoCursor().Entity;
		local plyTable = player.GetAll();
		
		if (IsValid(entity) and self.entity:IsDoor(entity)) then
			if (entity:GetPos():Distance(ply:GetShootPos()) <= 192) then
				if (plugin.Call("PlayerCanViewDoor", ply, entity)) then
					if (plugin.Call("PlayerUse", ply, entity)) then
						local owner = self.entity:GetOwner(entity);
						
						if (IsValid(owner)) then
							if (self.player:HasDoorAccess(ply, entity, DOOR_ACCESS_COMPLETE)) then
								local data = {
									sharedAccess = self.entity:DoorHasSharedAccess(entity),
									sharedText = self.entity:DoorHasSharedText(entity),
									unsellable = self.entity:IsDoorUnsellable(entity),
									accessList = {},
									isParent = self.entity:IsDoorParent(entity),
									entity = entity,
									owner = owner
								};
								
								for k, v in pairs(plyTable) do
									if (v != ply and v != owner) then
										if (self.player:HasDoorAccess(v, entity, DOOR_ACCESS_COMPLETE)) then
											data.accessList[v] = DOOR_ACCESS_COMPLETE;
										elseif (self.player:HasDoorAccess(v, entity, DOOR_ACCESS_BASIC)) then
											data.accessList[v] = DOOR_ACCESS_BASIC;
										end;
									end;
								end;
								
								netstream.Start(ply, "DoorManagement", data);
							end;
						else
							netstream.Start(ply, "PurchaseDoor", entity);
						end;
					end;
				end;
				
				doRecogniseMenu = false;
			end;
		end;
		
		if (self.config:Get("recognise_system"):Get()) then
			if (doRecogniseMenu) then
				netstream.Start(ply, "RecogniseMenu", true);
			end;
		end;
	end;
end;

-- Called when a player selects a custom character option.
function CW:PlayerSelectCustomCharacterOption(player, action, character) end;

-- Called when a player takes damage.
function CW:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
	if (damageInfo:IsBulletDamage() and self.event:CanRun("limb_damage", "stumble")) then
		if (hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG) then
			local rightLeg = self.limb:GetDamage(player, HITGROUP_RIGHTLEG);
			local leftLeg = self.limb:GetDamage(player, HITGROUP_LEFTLEG);
			
			if (rightLeg > 50 and leftLeg > 50 and !player:IsRagdolled()) then
				self.player:SetRagdollState(
					player, RAGDOLL_FALLENOVER, 8, nil, self.kernel:ConvertForce(damageInfo:GetDamageForce() * 32)
				);
				damageInfo:ScaleDamage(0.25);
			end;
		end;
	end;
end;

-- Called when an entity takes damage.
function CW:EntityTakeDamage(entity, damageInfo)
	local inflictor = damageInfo:GetInflictor();
	local attacker = damageInfo:GetAttacker();
	local amount = damageInfo:GetDamage();

	if (self.config:Get("prop_kill_protection"):Get()) then
		local curTime = CurTime();
		
		if ((IsValid(inflictor) and inflictor.cwDamageImmunity and inflictor.cwDamageImmunity > curTime and !inflictor:IsVehicle())
		or (IsValid(attacker) and attacker.cwDamageImmunity and attacker.cwDamageImmunity > curTime)) then
			entity.cwDamageImmunity = curTime + 1;
			
			damageInfo:SetDamage(0);
			return false;
		end;
		
		if (IsValid(attacker) and attacker:GetClass() == "worldspawn"
		and entity.cwDamageImmunity and entity.cwDamageImmunity > curTime) then
			damageInfo:SetDamage(0);
			return false;
		end;
		
		if ((IsValid(inflictor) and inflictor:IsBeingHeld())
		or attacker:IsBeingHeld()) then
			damageInfo:SetDamage(0);
			return false;
		end;
	end;
	
	if (entity:IsPlayer() and entity:InVehicle() and !IsValid(entity:GetVehicle():GetParent())) then
		entity.cwLastHitGroup = self.kernel:GetRagdollHitBone(entity, damageInfo:GetDamagePosition(), HITGROUP_GEAR);
		
		if (damageInfo:IsBulletDamage()) then
			if ((attacker:IsPlayer() or attacker:IsNPC()) and attacker != player) then
				damageInfo:ScaleDamage(10000);
			end;
		end;
	end;
	
	if (damageInfo:GetDamage() == 0) then
		return;
	end;
	
	local isPlayerRagdoll = self.entity:IsPlayerRagdoll(entity);
	local player = self.entity:GetPlayer(entity);
	
	if (player and (entity:IsPlayer() or isPlayerRagdoll)) then
		if (damageInfo:IsFallDamage() or self.config:Get("damage_view_punch"):Get()) then
			player:ViewPunch(
				Angle(math.random(amount, amount), math.random(amount, amount), math.random(amount, amount))
			);
		end;
		
		if (!isPlayerRagdoll) then
			if (damageInfo:IsDamageType(DMG_CRUSH) and damageInfo:GetDamage() < 10) then
				damageInfo:SetDamage(0);
			else
				local lastHitGroup = player:LastHitGroup();
				local killed = nil;
				
				if (player:InVehicle() and damageInfo:IsExplosionDamage()) then
					if (!damageInfo:GetDamage() or damageInfo:GetDamage() == 0) then
						damageInfo:SetDamage(player:GetMaxHealth());
					end;
				end;
				
				self:ScaleDamageByHitGroup(player, attacker, lastHitGroup, damageInfo, amount);
				
				if (damageInfo:GetDamage() > 0) then
					self.kernel:CalculatePlayerDamage(player, lastHitGroup, damageInfo);
					player:SetVelocity(self.kernel:ConvertForce(damageInfo:GetDamageForce() * 32, 200));
					
					if (player:Alive() and player:Health() == 1) then
						player:SetFakingDeath(true);
							hook.Call("DoPlayerDeath", self, player, attacker, damageInfo);
							hook.Call("PlayerDeath", self, player, inflictor, attacker, damageInfo);
							self.kernel:CreateBloodEffects(damageInfo:GetDamagePosition(), 1, player, damageInfo:GetDamageForce());
						player:SetFakingDeath(false, true);
					else
						local bNoMsg = plugin.Call("PlayerTakeDamage", player, inflictor, attacker, lastHitGroup, damageInfo);
						local sound = plugin.Call("PlayerPlayPainSound", player, player:GetGender(), damageInfo, lastHitGroup);
						
						self.kernel:CreateBloodEffects(damageInfo:GetDamagePosition(), 1, player, damageInfo:GetDamageForce());
						
						if (sound and !bNoMsg) then
							player:EmitHitSound(sound);
						end;

						local armor = "!";

						if (player:Armor() > 0) then
							armor = " and "..player:Armor().." armor!"
						end;
						
						if (attacker:IsPlayer()) then
							self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has taken "..tostring(math.ceil(damageInfo:GetDamage())).." damage from "..attacker:Name().." with "..self.player:GetWeaponClass(attacker, "an unknown weapon")..", leaving them at "..player:Health().." health"..armor);
						else
							self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has taken "..tostring(math.ceil(damageInfo:GetDamage())).." damage from "..attacker:GetClass()..", leaving them at "..player:Health().." health"..armor);
						end;
					end;
				end;
				
				damageInfo:SetDamage(0);
				player.cwLastHitGroup = nil;
			end;
		else
			local hitGroup = self.kernel:GetRagdollHitGroup(entity, damageInfo:GetDamagePosition());
			local curTime = CurTime();
			local killed = nil;
			
			self:ScaleDamageByHitGroup(player, attacker, hitGroup, damageInfo, amount);
			
			if (plugin.Call("PlayerRagdollCanTakeDamage", player, entity, inflictor, attacker, hitGroup, damageInfo)
			and damageInfo:GetDamage() > 0) then
				if (!attacker:IsPlayer()) then
					if (attacker:GetClass() == "prop_ragdoll" or self.entity:IsDoor(attacker)
					or damageInfo:GetDamage() < 5) then
						return;
					end;
				end;
				
				if (damageInfo:GetDamage() >= 10 or damageInfo:IsBulletDamage()) then
					self.kernel:CreateBloodEffects(damageInfo:GetDamagePosition(), 1, entity, damageInfo:GetDamageForce());
				end;
				
				self.kernel:CalculatePlayerDamage(player, hitGroup, damageInfo);
				
				if (player:Alive() and player:Health() == 1) then
					player:SetFakingDeath(true);
						player:GetRagdollTable().health = 0;
						player:GetRagdollTable().armor = 0;
						
						hook.Call("DoPlayerDeath", self, player, attacker, damageInfo);
						hook.Call("PlayerDeath", self, player, inflictor, attacker, damageInfo);
					player:SetFakingDeath(false, true);
				elseif (player:Alive()) then
					local bNoMsg = plugin.Call("PlayerTakeDamage", player, inflictor, attacker, hitGroup, damageInfo);
					local sound = plugin.Call("PlayerPlayPainSound", player, player:GetGender(), damageInfo, hitGroup);
					
					if (sound and !bNoMsg) then
						entity:EmitHitSound(sound);
					end;
					
					local armor = "!";

					if (player:Armor() > 0) then
						armor = " and "..player:Armor().." armor!"
					end;

					if (attacker:IsPlayer()) then
						self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has taken "..tostring(math.ceil(damageInfo:GetDamage())).." damage from "..attacker:Name().." with "..self.player:GetWeaponClass(attacker, "an unknown weapon")..", leaving them at "..player:Health().." health"..armor);
					else
						self.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." has taken "..tostring(math.ceil(damageInfo:GetDamage())).." damage from "..attacker:GetClass()..", leaving them at "..player:Health().." health"..armor);
					end;
				end;
			end;
			
			damageInfo:SetDamage(0);
		end;
	elseif (entity:GetClass() == "prop_ragdoll") then
		if (damageInfo:GetDamage() >= 20 or damageInfo:IsBulletDamage()) then
			if (!string.find(entity:GetModel(), "matt") and !string.find(entity:GetModel(), "gib")) then
				local matType = util.QuickTrace(entity:GetPos(), entity:GetPos()).MatType;
				
				if (matType == MAT_FLESH or matType == MAT_BLOODYFLESH) then
					self.kernel:CreateBloodEffects(damageInfo:GetDamagePosition(), 1, entity, damageInfo:GetDamageForce());
				end;
			end;
		end;
		
		if (inflictor:GetClass() == "prop_combine_ball") then
			if (!entity.disintegrating) then
				self.entity:Disintegrate(entity, 3, damageInfo:GetDamageForce());
				
				entity.disintegrating = true;
			end;
		end;
	elseif (entity:IsNPC()) then
		if (attacker:IsPlayer() and IsValid(attacker:GetActiveWeapon())
		and self.player:GetWeaponClass(attacker) == "weapon_crowbar") then
			damageInfo:ScaleDamage(0.25);
		end;
	end;
end;

-- Called when the death sound for a player should be played.
function CW:PlayerDeathSound(player) return true; end;

-- Called when a player attempts to spawn a SWEP.
function CW:PlayerSpawnSWEP(player, class, weapon)
	if (!player:IsSuperAdmin()) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player is given a SWEP.
function CW:PlayerGiveSWEP(player, class, weapon)
	if (!player:IsSuperAdmin()) then
		return false;
	else
		return true;
	end;
end;

-- Called when attempts to spawn a SENT.
function CW:PlayerSpawnSENT(player, class)
	if (!player:IsSuperAdmin()) then
		return false;
	else
		return true;
	end;
end;

-- Called when a player presses a key.
function CW:KeyPress(player, key)
	if (key == IN_USE) then
		local trace = player:GetEyeTraceNoCursor();
		
		if (IsValid(trace.Entity) and trace.HitPos:Distance(player:GetShootPos()) <= 192) then
			if (plugin.Call("PlayerUse", player, trace.Entity)) then
				if (self.entity:IsDoor(trace.Entity) and !trace.Entity:HasSpawnFlags(256)
				and !trace.Entity:HasSpawnFlags(8192) and !trace.Entity:HasSpawnFlags(32768)) then
					if (plugin.Call("PlayerCanUseDoor", player, trace.Entity)) then
						plugin.Call("PlayerUseDoor", player, trace.Entity);
						self.entity:OpenDoor(trace.Entity, 0, nil, nil, player:GetPos());
					end;
				elseif (trace.Entity.UsableInVehicle) then
					if (player:InVehicle()) then
						if (trace.Entity.Use) then
							trace.Entity:Use(player, player);
							
							player.cwNextExitVehicle = CurTime() + 1;
						end;
					end;
				end;
			end;
		end;
	elseif (key == IN_WALK) then
		local velocity = player:GetVelocity():Length();
		
		if (velocity > 0 and !player:KeyDown(IN_SPEED)) then
			if (player:GetSharedVar("IsJogMode") or !self.config:Get("enable_jogging"):Get()) then
				player:SetSharedVar("IsJogMode", false);
			else
				player:SetSharedVar("IsJogMode", true);
			end;
		elseif (velocity == 0 and player:KeyDown(IN_SPEED)) then
			if (player:Crouching()) then
				player:RunCommand("-duck");
			else
				player:RunCommand("+duck");
			end;
		end;
	elseif (key == IN_RELOAD) then
		if (self.player:GetWeaponRaised(player, true)) then
			player.cwReloadHoldTime = CurTime() + 0.75;
		else
			player.cwReloadHoldTime = CurTime() + 0.25;
		end;
	end;
end;

--[[
	@codebase Server
	@details Called when a player presses a button down.
	@param Player The player that is pressing a button.
	@param Enum The button that was pressed.
--]]
function CW:PlayerButtonDown(player, button)
	if (button == KEY_B) then
		local weapon = player:GetActiveWeapon();

		if (self.config:Get("quick_raise_enabled"):GetBoolean()) then
			local bQuickRaise = plugin.Call("PlayerCanQuickRaise", player, weapon);

			if (bQuickRaise) then
				self.player:ToggleWeaponRaised(player);
			end;
		end;
	end;
end;

--[[
	@codebase Server
	@details Called to determine whether or not a player can quickly raise their weapon by pressing the x button.
	@param Player The player that is attempting to quickly raise their weapon.
	@param Weapon The player's current active weapon.
--]]
function CW:PlayerCanQuickRaise(player, weapon) return true end;

-- Called when a player releases a key.
function CW:KeyRelease(player, key)
	if (key == IN_RELOAD and player.cwReloadHoldTime) then
		player.cwReloadHoldTime = nil;
	end;
end;

-- A function to setup a player's visibility.
function CW:SetupPlayerVisibility(player)
	local ragdollEntity = player:GetRagdollEntity();
	
	if (ragdollEntity) then
		AddOriginToPVS(ragdollEntity:GetPos());
	end;
end;

-- Called after a player has spawned an NPC.
function CW:PlayerSpawnedNPC(player, npc)
	local faction;
	local relation;
	
	prevRelation = prevRelation or {};
	prevRelation[player:SteamID()] = prevRelation[player:SteamID()] or {};
	
	for k, v in pairs(_player.GetAll()) do
		faction = self.faction:FindByID(v:GetFaction());
		relation = faction.entRelationship;
		
		if (istable(relation)) then
			for k2, v2 in pairs(relation) do
				if (k2 == npc:GetClass()) then
					if (string.lower(v2) == "like") then
						prevRelation[player:SteamID()][k2] = prevRelation[player:SteamID()][k2] or npc:Disposition(v);
						npc:AddEntityRelationship(v, D_LI, 1);
					elseif (string.lower(v2) == "fear") then
						prevRelation[player:SteamID()][k2] = prevRelation[player:SteamID()][k2] or npc:Disposition(v);
						npc:AddEntityRelationship(v, D_FR, 1);
					elseif (string.lower(v2) == "hate") then
						prevRelation[player:SteamID()][k2] = prevRelation[player:SteamID()][k2] or npc:Disposition(v);
						npc:AddEntityRelationship(v, D_HT, 1);
					else
						ErrorNoHalt("Attempting to add relationship using invalid relation '"..v2.."' towards faction '"..faction.name.."'.\r\n");
					end;
				end;
			end;
		end;
	end;
end;

--[[
	@codebase Server
	@details Called when an attribute is progressed to edit the amount it is progressed by.
	@param Player The player that has progressed the attribute.
	@param Table The attribute table of the attribute being progressed.
	@param Number The amount that is being progressed for editing purposes.
--]]
function CW:OnAttributeProgress(player, attribute, amount)
	amount = amount * self.config:Get("scale_attribute_progress"):Get();
end;

--[[
	@codebase Server
	@details Called to add ammo types to be checked for and saved.
	@param Table The table filled with the current ammo types.
--]]
function CW:AdjustAmmoTypes(ammoTable)
	ammoTable["sniperpenetratedround"] = true;
	ammoTable["striderminigun"] = true;
	ammoTable["helicoptergun"] = true;
	ammoTable["combinecannon"] = true;
	ammoTable["smg1_grenade"] = true;
	ammoTable["gaussenergy"] = true;
	ammoTable["sniperround"] = true;
	ammoTable["ar2altfire"] = true;
	ammoTable["rpg_round"] = true;
	ammoTable["xbowbolt"] = true;
	ammoTable["buckshot"] = true;
	ammoTable["alyxgun"] = true;
	ammoTable["grenade"] = true;
	ammoTable["thumper"] = true;
	ammoTable["gravity"] = true;
	ammoTable["battery"] = true;
	ammoTable["pistol"] = true;
	ammoTable["slam"] = true;
	ammoTable["smg1"] = true;
	ammoTable["357"] = true;
	ammoTable["ar2"] = true;
end;

--[[
	@codebase Server
	@details Called after a player uses a command.
	@param Player The player that used the commmand.
	@param Table The table of the command that is being used.
	@param Table The arguments that have been given with the command, if any.
--]]
function CW:PostCommandUsed(player, command, arguments) end;

-- GetTargetRecognises datastream callback.
netstream.Hook("GetTargetRecognises", function(player, data)
	if (IsValid(data) and data:IsPlayer()) then
		player:SetSharedVar("TargetKnows", CW.player:DoesRecognise(data, player));
	end;
end);

-- EntityMenuOption datastream callback.
netstream.Hook("EntityMenuOption", function(player, data)
	local entity = data[1];
	local option = data[2];
	local shootPos = player:GetShootPos();
	local arguments = data[3];
	local curTime = CurTime();
	
	if (IsValid(entity) and type(option) == "string") then
		if (entity:NearestPoint(shootPos):Distance(shootPos) <= 80) then
			if (plugin.Call("PlayerUse", player, entity)) then
				if (!player.nextEntityHandle or player.nextEntityHandle <= curTime) then
					plugin.Call("EntityHandleMenuOption", player, entity, option, arguments);

					player.nextEntityHandle = curTime + CW.config:Get("entity_handle_time"):Get();
				else
					CW.player:Notify(player, L(player, "EntityOptionWaitTime"));
				end;
			end;
		end;
	end;
end);

-- MenuOption datastream callback.
netstream.Hook("MenuOption", function(player, data)
	local item = data.item;
	local option = data.option;
	local entity = data.entity;
	local data = data.data;
	local shootPos = player:GetShootPos();

	if (type(data) != "table") then
		data = {data};
	end;

	local itemTable = CW.item:FindInstance(item);
	if (itemTable and itemTable:IsInstance() and type(option) == "string") then
		if (itemTable.HandleOptions) then
			if (player:HasItemInstance(itemTable)) then
				itemTable:HandleOptions(option, player, data);
			elseif (IsValid(entity) and entity:GetClass() == "cw_item" and entity:GetItemTable() == itemTable and entity:NearestPoint(shootPos):Distance(shootPos) <= 80) then
				itemTable:HandleOptions(option, player, data, entity);
			end;
		end;
	end;
end);

-- DataStreamInfoSent datastream callback.
netstream.Hook("DataStreamInfoSent", function(player, data)
	if (!player.cwDatastreamInfoSent) then
		plugin.Call("PlayerDataStreamInfoSent", player);
		
		timer.Simple(FrameTime() * 32, function()
			if (IsValid(player)) then
				netstream.Start(player, "DataStreamed", true);
			end;
		end);
		
		player.cwDatastreamInfoSent = true;
	end;
end);

-- LocalPlayerCreated datastream callback.
netstream.Hook("LocalPlayerCreated", function(player, data)
	if (IsValid(player) and !player:HasConfigInitialized()) then
		CW.kernel:CreateTimer("SendCfg"..player:UniqueID(), FrameTime(), 1, function()
			if (IsValid(player)) then
				CW.config:Send(player);
			end;
		end);		
	end;
end);

-- InteractCharacter datastream callback.
netstream.Hook("InteractCharacter", function(player, data)
	local characterID = data.characterID;
	local action = data.action;
	
	if (characterID and action) then
		local character = player:GetCharacters()[characterID];
		
		if (character) then
			local fault = plugin.Call("PlayerCanInteractCharacter", player, action, character);
			
			if (fault == false or type(fault) == "string") then
				return CW.player:SetCreateFault(fault or "You cannot interact with this character!");
			elseif (action == "delete") then
				local bSuccess, fault = CW.player:DeleteCharacter(player, characterID);
				
				if (!bSuccess) then 
					CW.player:SetCreateFault(player, fault);
				end;
			elseif (action == "use") then
				local bSuccess, fault = CW.player:UseCharacter(player, characterID);
				
				if (!bSuccess) then
					CW.player:SetCreateFault(player, fault);
				end;
			else
				plugin.Call("PlayerSelectCustomCharacterOption", player, action, character);
			end;
		end;
	end;
end);

-- GetQuizStatus datastream callback.
netstream.Hook("GetQuizStatus", function(player, data)
	if (!CW.quiz:GetEnabled() or CW.quiz:GetCompleted(player)) then
		netstream.Start(player, "QuizCompleted", true);
	else
		netstream.Start(player, "QuizCompleted", false);
	end; 
end);

-- DoorManagement datastream callback.
netstream.Hook("DoorManagement", function(player, data)
	if (IsValid(data[1]) and player:GetEyeTraceNoCursor().Entity == data[1]) then
		if (data[1]:GetPos():Distance(player:GetPos()) <= 192) then
			if (data[2] == "Purchase") then
				if (!CW.entity:GetOwner(data[1])) then
					if (hook.Call("PlayerCanOwnDoor", Clockwork, player, data[1])) then
						local doors = CW.player:GetDoorCount(player);
						
						if (doors == CW.config:Get("max_doors"):Get()) then
							CW.player:Notify(player, L(player, "CannotPurchaseAnotherDoor"));
						else
							local doorCost = CW.config:Get("door_cost"):Get();
							
							if (doorCost == 0 or CW.player:CanAfford(player, doorCost)) then
								local doorName = CW.entity:GetDoorName(data[1]);
								
								if (doorName == "false" or doorName == "hidden" or doorName == "") then
									doorName = "Door"; 
								end; 
								
								if (doorCost > 0) then
									CW.player:GiveCash(player, -doorCost, doorName);
								end;
								
								CW.player:GiveDoor(player, data[1]);
							else
								local amount = doorCost - player:GetCash();
								
								CW.player:Notify(player, L(player, "YouNeedAnother",
									CW.kernel:FormatCash(amount, nil, true))
								);
							end;
						end;
					end;
				end;
			elseif (data[2] == "Access") then
				if (CW.player:HasDoorAccess(player, data[1], DOOR_ACCESS_COMPLETE)) then
					if (IsValid(data[3]) and data[3] != player and data[3] != CW.entity:GetOwner(data[1])) then
						if (data[4] == DOOR_ACCESS_COMPLETE) then
							if (CW.player:HasDoorAccess(data[3], data[1], DOOR_ACCESS_COMPLETE)) then
								CW.player:GiveDoorAccess(data[3], data[1], DOOR_ACCESS_BASIC);
							else
								CW.player:GiveDoorAccess(data[3], data[1], DOOR_ACCESS_COMPLETE);
							end;
						elseif (data[4] == DOOR_ACCESS_BASIC) then
							if (CW.player:HasDoorAccess(data[3], data[1], DOOR_ACCESS_BASIC)) then
								CW.player:TakeDoorAccess(data[3], data[1]);
							else 
								CW.player:GiveDoorAccess(data[3], data[1], DOOR_ACCESS_BASIC);
							end;
						end;
						
						if (CW.player:HasDoorAccess(data[3], data[1], DOOR_ACCESS_COMPLETE)) then
							netstream.Start(player, "DoorAccess", {data[3], DOOR_ACCESS_COMPLETE});
						elseif (CW.player:HasDoorAccess(data[3], data[1], DOOR_ACCESS_BASIC)) then 
							netstream.Start(player, "DoorAccess", {data[3], DOOR_ACCESS_BASIC});
						else
							netstream.Start(player, "DoorAccess", {data[3]});
						end;
					end;
				end; 
			elseif (data[2] == "Unshare") then
				if (CW.entity:IsDoorParent(data[1])) then
					if (data[3] == "Text") then
						netstream.Start(player, "SetSharedText", false);
						
						data[1].cwDoorSharedTxt = nil;
					else
						netstream.Start(player, "SetSharedAccess", false);
						
						data[1].cwDoorSharedAxs = nil;
					end;
				end;
			elseif (data[2] == "Share") then
				if (CW.entity:IsDoorParent(data[1])) then
					if (data[3] == "Text") then
						netstream.Start(player, "SetSharedText", true);
						
						data[1].cwDoorSharedTxt = true;
					else
						netstream.Start(player, "SetSharedAccess", true); 
						
						data[1].cwDoorSharedAxs = true;
					end;
				end;
			elseif (data[2] == "Text" and data[3] != "") then
				if (CW.player:HasDoorAccess(player, data[1], DOOR_ACCESS_COMPLETE)) then
					if (!string.find(string.gsub(string.lower(data[3]), "%s", ""), "thisdoorcanbepurchased") and string.find(data[3], "%w")) then
						CW.entity:SetDoorText(data[1], string.utf8sub(data[3], 1, 32));
					end;
				end;
			elseif (data[2] == "Sell") then
				if (CW.entity:GetOwner(data[1]) == player) then
					if (!CW.entity:IsDoorUnsellable(data[1])) then
						CW.player:TakeDoor(player, data[1]);
					end;
				end;
			end;
		end;
	end;
end);

-- CreateCharacter datastream callback.
netstream.Hook("CreateCharacter", function(player, data)
	CW.player:CreateCharacterFromData(player, data);
end);

-- RecogniseOption datastream callback.
netstream.Hook("RecogniseOption", function(player, data)
	local recogniseData = data;

	if (CW.config:Get("recognise_system"):Get()) then
		if (type(recogniseData) == "string") then	
			local playSound = false;
			
			if (recogniseData == "look") then
				local target = player:GetEyeTraceNoCursor().Entity;

				if (target:HasInitialized() and !CW.player:IsNoClipping(target) and target != player) then
					CW.player:SetRecognises(target, player, RECOGNISE_SAVE);

					playSound = true;
				end;
			else
				local position = player:GetPos();
				local plyTable = _player.GetAll();
				local talkRadius = CW.config:Get("talk_radius"):Get();

				for k, v in pairs(plyTable) do
					if (v:HasInitialized() and player != v) then
						if (!CW.player:IsNoClipping(v)) then
							local distance = v:GetPos():Distance(position);
							local recognise = false;
							
							if (recogniseData == "whisper") then
								if (distance <= math.min(talkRadius / 3, 80)) then
									recognise = true;
								end;
							elseif (recogniseData == "yell") then
								if (distance <= talkRadius * 2) then 
									recognise = true; 
								end;
							elseif (recogniseData == "talk") then
								if (distance <= talkRadius) then
									recognise = true;
								end;
							end;
							
							if (recognise) then
								CW.player:SetRecognises(v, player, RECOGNISE_SAVE);
								
								if (!playSound) then
									playSound = true;
								end;
							end;
						end;
					end;
				end;
			end;

			if (playSound) then
				CW.player:PlaySound(player, "buttons/button17.wav");
			end;
		end;
	end;
end);

-- QuizCompleted datastream callback.
netstream.Hook("QuizCompleted", function(player, data)
	if (player.cwQuizAnswers and !CW.quiz:GetCompleted(player)) then
		local questionsAmount = CW.quiz:GetQuestionsAmount();
		local correctAnswers = 0;
		local quizQuestions = CW.quiz:GetQuestions();
		
		for k, v in pairs(quizQuestions) do
			if (player.cwQuizAnswers[k]) then
				if (CW.quiz:IsAnswerCorrect(k, player.cwQuizAnswers[k])) then
					correctAnswers = correctAnswers + 1;
				end;
			end;
		end;
		
		if (correctAnswers < math.Round(questionsAmount * (CW.quiz:GetPercentage() / 100))) then
			CW.quiz:CallKickCallback(player, correctAnswers);
		else
			CW.quiz:SetCompleted(player, true);
		end;
	end;
end); 

-- UnequipItem datastream callback.
netstream.Hook("UnequipItem", function(player, data)
	local arguments = data[3];
	local uniqueID = data[1];
	local itemID = data[2];
	
	if (!player:Alive() or player:IsRagdolled()) then
		return;
	end;
	
	local itemTable = player:FindItemByID(uniqueID, itemID);
	
	if (!itemTable) then
		itemTable = player:FindWeaponItemByID(uniqueID, itemID);
	end;
	
	if (itemTable and itemTable.OnPlayerUnequipped and itemTable.HasPlayerEquipped) then
		if (itemTable:HasPlayerEquipped(player, arguments)) then
			itemTable:OnPlayerUnequipped(player, arguments);
			
			player:RebuildInventory();
		end;
	end;
end);

-- QuizAnswer datastream callback.
netstream.Hook("QuizAnswer", function(player, data)
	if (!player.cwQuizAnswers) then
		player.cwQuizAnswers = {};
	end;
	
	local question = data[1];
	local answer = data[2];
	
	if (CW.quiz:GetQuestion(question)) then
		player.cwQuizAnswers[question] = answer;
	end;
end);

local entityMeta = FindMetaTable("Entity");
local playerMeta = FindMetaTable("Player");

playerMeta.ClockworkSetCrouchedWalkSpeed = playerMeta.ClockworkSetCrouchedWalkSpeed or playerMeta.SetCrouchedWalkSpeed;
playerMeta.ClockworkLastHitGroup = playerMeta.ClockworkLastHitGroup or playerMeta.LastHitGroup;
playerMeta.ClockworkSetJumpPower = playerMeta.ClockworkSetJumpPower or playerMeta.SetJumpPower;
playerMeta.ClockworkSetWalkSpeed = playerMeta.ClockworkSetWalkSpeed or playerMeta.SetWalkSpeed;
playerMeta.ClockworkStripWeapons = playerMeta.ClockworkStripWeapons or playerMeta.StripWeapons;
playerMeta.ClockworkSetRunSpeed = playerMeta.ClockworkSetRunSpeed or playerMeta.SetRunSpeed;
entityMeta.ClockworkSetMaterial = entityMeta.ClockworkSetMaterial or entityMeta.SetMaterial;
playerMeta.ClockworkStripWeapon = playerMeta.ClockworkStripWeapon or playerMeta.StripWeapon;
entityMeta.ClockworkFireBullets = entityMeta.ClockworkFireBullets or entityMeta.FireBullets;
playerMeta.ClockworkGodDisable = playerMeta.ClockworkGodDisable or playerMeta.GodDisable;
entityMeta.ClockworkExtinguish = entityMeta.ClockworkExtinguish or entityMeta.Extinguish;
entityMeta.ClockworkWaterLevel = entityMeta.ClockworkWaterLevel or entityMeta.WaterLevel;
playerMeta.ClockworkGodEnable = playerMeta.ClockworkGodEnable or playerMeta.GodEnable;
entityMeta.ClockworkSetHealth = entityMeta.ClockworkSetHealth or entityMeta.SetHealth;
playerMeta.ClockworkUniqueID = playerMeta.ClockworkUniqueID or playerMeta.UniqueID;
entityMeta.ClockworkSetColor = entityMeta.ClockworkSetColor or entityMeta.SetColor;
entityMeta.ClockworkIsOnFire = entityMeta.ClockworkIsOnFire or entityMeta.IsOnFire;
entityMeta.ClockworkSetModel = entityMeta.ClockworkSetModel or entityMeta.SetModel;
playerMeta.ClockworkSetArmor = playerMeta.ClockworkSetArmor or playerMeta.SetArmor;
entityMeta.ClockworkSetSkin = entityMeta.ClockworkSetSkin or entityMeta.SetSkin;
entityMeta.ClockworkAlive = entityMeta.ClockworkAlive or playerMeta.Alive;
playerMeta.ClockworkGive = playerMeta.ClockworkGive or playerMeta.Give;
playerMeta.ClockworkKick = playerMeta.ClockworkKick or playerMeta.Kick;
playerMeta.ClockworkSteamID64 = playerMeta.ClockworkSteamID64 or playerMeta.SteamID64;

playerMeta.SteamName = playerMeta.SteamName or playerMeta.Name;

function playerMeta:SteamID64()
	local value = self:ClockworkSteamID64();
 
	if (value == nil) then
		print("[Catwork] Temporary fix for SteamID64 has been used.");
		return "";
	else
		return value;
	end;
end;

concommand.Add("gm_save", function(ply)
	MsgN("[Catwork] "..ply:Name().." tried to use gm_save -- beware!");
end);

-- A function to get a player's name.
function playerMeta:Name()
	return self:QueryCharacter("Name", self:SteamName());
end;

-- A function to make a player fire bullets.
function entityMeta:FireBullets(bulletInfo)
	if (self:IsPlayer()) then
		plugin.Call("PlayerAdjustBulletInfo", self, bulletInfo);
	end;
	
	plugin.Call("EntityFireBullets", self, bulletInfo);
	return self:ClockworkFireBullets(bulletInfo);
end;

-- A function to get whether a player is alive.
function playerMeta:Alive()
	if (!self.fakingDeath) then
		return self:ClockworkAlive();
	else
		return false;
	end;
end;

-- A function to set whether a player is faking death.
function playerMeta:SetFakingDeath(fakingDeath, killSilent)
	self.fakingDeath = fakingDeath;
	
	if (!fakingDeath and killSilent) then
		self:KillSilent();
	end;
end;

-- A function to save a player's character.
function playerMeta:SaveCharacter()
	CW.player:SaveCharacter(self);
end;

-- A function to give a player an item weapon.
function playerMeta:GiveItemWeapon(itemTable)
	CW.player:GiveItemWeapon(self, itemTable);
end;

-- A function to give a weapon to a player.
function playerMeta:Give(class, itemTable, bForceReturn)
	local iTeamIndex = self:Team();
	
	if (!plugin.Call("PlayerCanBeGivenWeapon", self, class, itemTable)) then
		return;
	end;
	
	if (self:IsRagdolled() and !bForceReturn) then
		local ragdollWeapons = self:GetRagdollWeapons();
		local spawnWeapon = CW.player:GetSpawnWeapon(self, class);
		local bCanHolster = (itemTable and plugin.Call("PlayerCanHolsterWeapon", self, itemTable, true, true));
		
		if (!spawnWeapon) then iTeamIndex = nil; end;
		
		for k, v in pairs(ragdollWeapons) do
			if (v.weaponData["class"] == class
			and v.weaponData["itemTable"] == itemTable) then
				v.canHolster = bCanHolster;
				v.teamIndex = iTeamIndex;
				return;
			end;
		end;
		
		ragdollWeapons[#ragdollWeapons + 1] = {
			weaponData = {
				class = class,
				itemTable = itemTable
			},
			canHolster = bCanHolster,
			teamIndex = iTeamIndex,
		};
	elseif (!self:HasWeapon(class)) then
		self.cwForceGive = true;
			self:ClockworkGive(class);
		self.cwForceGive = nil;
		
		local weapon = self:GetWeapon(class);
		
		if (IsValid(weapon) and itemTable) then
			netstream.Start(self, "WeaponItemData", {
				definition = CW.item:GetDefinition(itemTable, true),
				weapon = weapon:EntIndex()
			});
			
			weapon:SetNetworkedString(
				"ItemID", tostring(itemTable("itemID"))
			);
			weapon.cwItemTable = itemTable;
			
			if (itemTable.OnWeaponGiven) then
				itemTable:OnWeaponGiven(self, weapon);
			end;
		end;
	end;
	
	plugin.Call("PlayerGivenWeapon", self, class, itemTable);
end;

-- A function to get a player's data.
function playerMeta:GetData(key, default)
	if (self.cwData and self.cwData[key] != nil) then
		return self.cwData[key];
	else
		return default;
	end;
end;

-- A function to get a player's playback rate.
function playerMeta:GetPlaybackRate()
	return self.cwPlaybackRate or 1;
end;

-- A function to set an entity's skin.
function entityMeta:SetSkin(skin)
	self:ClockworkSetSkin(skin);
	
	if (self:IsPlayer()) then
		plugin.Call("PlayerSkinChanged", self, skin);
		
		if (self:IsRagdolled()) then
			self:GetRagdollTable().skin = skin;
		end;
	end;
end;

-- A function to set an entity's model.
function entityMeta:SetModel(model)
	self:ClockworkSetModel(model);
	
	if (self:IsPlayer()) then
		plugin.Call("PlayerModelChanged", self, model);
		
		if (self:IsRagdolled()) then
			self:GetRagdollTable().model = model;
		end;
	end;
end;

-- A function to get an entity's owner key.
function entityMeta:GetOwnerKey()
	return self.cwOwnerKey;
end;

-- A function to set an entity's owner key.
function entityMeta:SetOwnerKey(key)
	self.cwOwnerKey = key;
end;

-- A function to get whether an entity is a map entity.
function entityMeta:IsMapEntity()
	return CW.entity:IsMapEntity(self);
end;

-- A function to get an entity's start position.
function entityMeta:GetStartPosition()
	return CW.entity:GetStartPosition(self);
end;

-- A function to emit a hit sound for an entity.
function entityMeta:EmitHitSound(sound)
	self:EmitSound("weapons/crossbow/hitbod2.wav",
		math.random(100, 150), math.random(150, 170)
	);
	
	timer.Simple(FrameTime(), function()
		if (IsValid(self)) then
			self:EmitSound(sound);
		end;
	end);
end;

-- A function to set an entity's material.
function entityMeta:SetMaterial(material)
	if (self:IsPlayer() and self:IsRagdolled()) then
		self:GetRagdollEntity():SetMaterial(material);
	end;
	
	self:ClockworkSetMaterial(material);
end;

-- A function to set an entity's color.
function entityMeta:SetColor(color)
	if (self:IsPlayer() and self:IsRagdolled()) then
		self:GetRagdollEntity():SetColor(color);
	end;
	
	self:ClockworkSetColor(color);
end;

-- A function to get a player's information table.
function playerMeta:GetInfoTable()
	return self.cwInfoTable;
end;

-- A function to set a player's armor.
function playerMeta:SetArmor(armor)
	local oldArmor = self:Armor();
		self:ClockworkSetArmor(armor);
	plugin.Call("PlayerArmorSet", self, armor, oldArmor);
end;

-- A function to set a player's health.
function playerMeta:SetHealth(health)
	local oldHealth = self:Health();
		self:ClockworkSetHealth(health);
	plugin.Call("PlayerHealthSet", self, health, oldHealth);
end;

-- A function to get whether a player is noclipping.
function playerMeta:IsNoClipping()
	return CW.player:IsNoClipping(self);
end;

-- A function to get whether a player is running.
function playerMeta:IsRunning()
	if (self:Alive() and !self:IsRagdolled() and !self:InVehicle()
	and !self:Crouching() and self:KeyDown(IN_SPEED)) then
		if (self:GetVelocity():Length() >= self:GetWalkSpeed()
		or bNoWalkSpeed) then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to get whether a player is jogging.
function playerMeta:IsJogging(bTestSpeed)
	if (!self:IsRunning() and (self:GetSharedVar("IsJogMode") or bTestSpeed)) then
		if (self:Alive() and !self:IsRagdolled() and !self:InVehicle() and !self:Crouching()) then
			if (self:GetVelocity():Length() > 0) then
				return true;
			end;
		end;
	end;
	
	return false;
end;

-- A function to strip a weapon from a player.
function playerMeta:StripWeapon(weaponClass)
	if (self:IsRagdolled()) then
		local ragdollWeapons = self:GetRagdollWeapons();
		
		for k, v in pairs(ragdollWeapons) do
			if (v.weaponData["class"] == weaponClass) then
				weapons[k] = nil;
			end;
		end;
	else
		self:ClockworkStripWeapon(weaponClass);
	end;
end;

-- A function to get the player's target run speed.
function playerMeta:GetTargetRunSpeed()
	return self.cwTargetRunSpeed or self:GetRunSpeed();
end;

-- A function to handle a player's attribute progress.
function playerMeta:HandleAttributeProgress(curTime)
	if (self.cwAttrProgressTime and curTime >= self.cwAttrProgressTime) then
		self.cwAttrProgressTime = curTime + 30;
		
		for k, v in pairs(self.cwAttrProgress) do
			local attributeTable = CW.attribute:FindByID(k);
			
			if (attributeTable) then
				netstream.Start(self, "AttributeProgress", {
					index = attributeTable.index, amount = v
				});
			end;
		end;
		
		if (self.cwAttrProgress) then
			self.cwAttrProgress = {};
		end;
	end;
end;

-- A function to handle a player's attribute boosts.
function playerMeta:HandleAttributeBoosts(curTime)
	for k, v in pairs(self.cwAttrBoosts) do
		for k2, v2 in pairs(v) do
			if (v2.duration and v2.endTime) then
				if (curTime > v2.endTime) then
					self:BoostAttribute(k2, k, false);
				else
					local timeLeft = v2.endTime - curTime;
					
					if (timeLeft >= 0) then
						if (v2.default < 0) then
							v2.amount = math.min((v2.default / v2.duration) * timeLeft, 0);
						else
							v2.amount = math.max((v2.default / v2.duration) * timeLeft, 0);
						end;
					end;
				end;
			end;
		end;
	end;
end;

-- A function to strip a player's weapons.
function playerMeta:StripWeapons(ragdollForce)
	if (self:IsRagdolled() and !ragdollForce) then
		self:GetRagdollTable().weapons = {};
	else
		self:ClockworkStripWeapons();
	end;
end;

-- A function to enable God for a player.
function playerMeta:GodEnable()
	self.godMode = true; self:ClockworkGodEnable();
end;

-- A function to disable God for a player.
function playerMeta:GodDisable()
	self.godMode = nil; self:ClockworkGodDisable();
end;

-- A function to get whether a player has God mode enabled.
function playerMeta:IsInGodMode()
	return self.godMode;
end;

-- A function to update whether a player's weapon is raised.
function playerMeta:UpdateWeaponRaised()
	CW.player:UpdateWeaponRaised(self);
end;

-- A function to update whether a player's weapon has fired.
function playerMeta:UpdateWeaponFired()
	local activeWeapon = self:GetActiveWeapon();
	
	if (IsValid(activeWeapon)) then
		if (self.cwClipOneInfo.weapon == activeWeapon) then
			local clipOne = activeWeapon:Clip1();
			
			if (clipOne < self.cwClipOneInfo.ammo) then
				self.cwClipOneInfo.ammo = clipOne;
				plugin.Call("PlayerFireWeapon", self, activeWeapon, CLIP_ONE, activeWeapon:GetPrimaryAmmoType());
			end;
		else
			self.cwClipOneInfo.weapon = activeWeapon;
			self.cwClipOneInfo.ammo = activeWeapon:Clip1();
		end;
		
		if (self.cwClipTwoInfo.weapon == activeWeapon) then
			local clipTwo = activeWeapon:Clip2();
			
			if (clipTwo < self.cwClipTwoInfo.ammo) then
				self.cwClipTwoInfo.ammo = clipTwo;
				plugin.Call("PlayerFireWeapon", self, activeWeapon, CLIP_TWO, activeWeapon:GetSecondaryAmmoType());
			end;
		else
			self.cwClipTwoInfo.weapon = activeWeapon;
			self.cwClipTwoInfo.ammo = activeWeapon:Clip2();
		end;
	end;
end;

-- A function to get a player's water level.
function playerMeta:WaterLevel()
	if (self:IsRagdolled()) then
		return self:GetRagdollEntity():WaterLevel();
	else
		return self:ClockworkWaterLevel();
	end;
end;

-- A function to get whether a player is on fire.
function playerMeta:IsOnFire()
	if (self:IsRagdolled()) then
		return self:GetRagdollEntity():IsOnFire();
	else
		return self:ClockworkIsOnFire();
	end;
end;

-- A function to extinguish a player.
function playerMeta:Extinguish()
	if (self:IsRagdolled()) then
		return self:GetRagdollEntity():Extinguish();
	else
		return self:ClockworkExtinguish();
	end;
end;

-- A function to get whether a player is using their hands.
function playerMeta:IsUsingHands()
	return CW.player:GetWeaponClass(self) == "cw_hands";
end;

-- A function to get whether a player is using their hands.
function playerMeta:IsUsingKeys()
	return CW.player:GetWeaponClass(self) == "cw_keys";
end;

-- A function to get a player's wages.
function playerMeta:GetWages()
	return CW.player:GetWages(self);
end;

-- A function to get a player's community ID.
function playerMeta:CommunityID()
	local x, y, z = string.match(self:SteamID(), "STEAM_(%d+):(%d+):(%d+)");
	
	if (x and y and z) then
		return (z * 2) + STEAM_COMMUNITY_ID + y;
	else
		return self:SteamID();
	end;
end;

-- A function to get whether a player is ragdolled.
function playerMeta:IsRagdolled(exception, entityless)
	return CW.player:IsRagdolled(self, exception, entityless);
end;

-- A function to get whether a player is kicked.
function playerMeta:IsKicked()
	return self.isKicked;
end;

-- A function to get whether a player has spawned.
function playerMeta:HasSpawned()
	return self.cwHasSpawned;
end;

-- A function to kick a player.
function playerMeta:Kick(reason)
	if (!self:IsKicked()) then
		timer.Simple(FrameTime() * 0.5, function()
			local isKicked = self:IsKicked();
			
			if (IsValid(self) and isKicked) then
				if (self:HasSpawned()) then
					game.ConsoleCommand("kickid "..self:UserID().." "..isKicked.."\n");
				else
					self.isKicked = nil;
					self:Kick(isKicked);
				end;
			end;
		end);
	end;
	
	if (!reason) then
		self.isKicked = "You have been kicked.";
	else
		self.isKicked = reason;
	end;
end;

-- A function to ban a player.
function playerMeta:Ban(duration, reason)
	CW.bans:Add(self:SteamID(), duration * 60, reason);
end;

-- A function to get a player's cash.
function playerMeta:GetCash()
	if (CW.config:Get("cash_enabled"):Get()) then
		return self:QueryCharacter("Cash");
	else
		return 0;
	end;
end;

-- A function to get a character's flags.
function playerMeta:GetFlags() return self:QueryCharacter("Flags"); end;

-- A function to get a player's faction.
function playerMeta:GetFaction() return self:QueryCharacter("Faction"); end;

-- A function to get a player's gender.
function playerMeta:GetGender() return self:QueryCharacter("Gender"); end;

-- A function to get a player's inventory.
function playerMeta:GetInventory() return self:QueryCharacter("Inventory"); end;

-- A function to get a player's attributes.
function playerMeta:GetAttributes() return self:QueryCharacter("Attributes"); end;

-- A function to get a player's saved ammo.
function playerMeta:GetSavedAmmo() return self:QueryCharacter("Ammo"); end;

-- A function to get a player's default model.
function playerMeta:GetDefaultModel() return self:QueryCharacter("Model"); end;

-- A function to get a player's character ID.
function playerMeta:GetCharacterID() return self:QueryCharacter("CharacterID"); end;

-- A function to get the time when a player's character was created.
function playerMeta:GetTimeCreated() return self:QueryCharacter("TimeCreated"); end;

-- A function to get a player's character key.
function playerMeta:GetCharacterKey() return self:QueryCharacter("Key"); end;

-- A function to get a player's recognised names.
function playerMeta:GetRecognisedNames()
	return self:QueryCharacter("RecognisedNames");
end;

-- A function to get a player's character table.
function playerMeta:GetCharacter() return CW.player:GetCharacter(self); end;

-- A function to get a player's storage table.
function playerMeta:GetStorageTable() return CW.storage:GetTable(self); end;
 
-- A function to get a player's ragdoll table.
function playerMeta:GetRagdollTable() return CW.player:GetRagdollTable(self); end;

-- A function to get a player's ragdoll state.
function playerMeta:GetRagdollState() return CW.player:GetRagdollState(self); end;

-- A function to get a player's storage entity.
function playerMeta:GetStorageEntity() return CW.storage:GetEntity(self); end;

-- A function to get a player's ragdoll entity.
function playerMeta:GetRagdollEntity() return CW.player:GetRagdollEntity(self); end;

-- A function to get a player's ragdoll weapons.
function playerMeta:GetRagdollWeapons()
	return self:GetRagdollTable().weapons or {};
end;

-- A function to get whether a player's ragdoll has a weapon.
function playerMeta:RagdollHasWeapon(weaponClass)
	local ragdollWeapons = self:GetRagdollWeapons();
	
	if (ragdollWeapons) then
		for k, v in pairs(ragdollWeapons) do
			if (v.weaponData["class"] == weaponClass) then
				return true;
			end;
		end;
	end;
end;

-- A function to set a player's maximum armor.
function playerMeta:SetMaxArmor(armor)
	self:SetSharedVar("MaxAP", armor);
end;

-- A function to get a player's maximum armor.
function playerMeta:GetMaxArmor(armor)
	local maxArmor = self:GetSharedVar("MaxAP") or 100;
	
	if (maxArmor > 0) then
		return maxArmor;
	else
		return 100;
	end;
end;

-- A function to set a player's maximum health.
function playerMeta:SetMaxHealth(health)
	self:SetSharedVar("MaxHP", health);
end;

-- A function to get a player's maximum health.
function playerMeta:GetMaxHealth(health)
	local maxHealth = self:GetSharedVar("MaxHP") or 100;
	
	if (maxHealth > 0) then
		return maxHealth;
	else
		return 100;
	end;
end;

-- A function to get whether a player is viewing the starter hints.
function playerMeta:IsViewingStarterHints()
	return self.cwViewStartHints;
end;

-- A function to get a player's last hit group.
function playerMeta:LastHitGroup()
	return self.cwLastHitGroup or self:ClockworkLastHitGroup();
end;

-- A function to get whether an entity is being held.
function entityMeta:IsBeingHeld()
	if (IsValid(self)) then
		return plugin.Call("GetEntityBeingHeld", self);
	end;
end;

-- A function to run a command on a player.
function playerMeta:RunCommand(...)
	netstream.Start(self, "RunCommand", {...});
end;

-- A function to run a Clockwork command on a player.
function playerMeta:RunClockworkCmd(command, ...)
	CW.player:RunClockworkCommand(self, command, ...)
end;

-- A function to get a player's wages name.
function playerMeta:GetWagesName()
	return CW.player:GetWagesName(self);
end;

-- A function to create a player'a animation stop delay.
function playerMeta:CreateAnimationStopDelay(delay)
	CW.kernel:CreateTimer("ForcedAnim"..self:UniqueID(), delay, 1, function()
		if (IsValid(self)) then
			local forcedAnimation = self:GetForcedAnimation();
			
			if (forcedAnimation) then
				self:SetForcedAnimation(false);
			end;
		end;
	end);
end;

-- A function to set a player's forced animation.
function playerMeta:SetForcedAnimation(animation, delay, OnAnimate, OnFinish)
	local forcedAnimation = self:GetForcedAnimation();
	local sequence = nil;
	
	if (!animation) then
		self:SetSharedVar("ForceAnim", 0);
		self.cwForcedAnimation = nil;
		
		if (forcedAnimation and forcedAnimation.OnFinish) then
			forcedAnimation.OnFinish(self);
		end;
		
		return false;
	end;
	
	local bIsPermanent = (!delay or delay == 0);
	local bShouldPlay = (!forcedAnimation or forcedAnimation.delay != 0);
	
	if (bShouldPlay) then
		if (type(animation) == "string") then
			sequence = self:LookupSequence(animation);
		else
			sequence = self:SelectWeightedSequence(animation);
		end;
		
		self.cwForcedAnimation = {
			animation = animation,
			OnAnimate = OnAnimate,
			OnFinish = OnFinish,
			delay = delay
		};
		
		if (bIsPermanent) then
			CW.kernel:DestroyTimer(
				"ForcedAnim"..self:UniqueID()
			);
		else
			self:CreateAnimationStopDelay(delay);
		end;
		
		self:SetSharedVar("ForceAnim", sequence);
		
		if (forcedAnimation and forcedAnimation.OnFinish) then
			forcedAnimation.OnFinish(self);
		end;
		
		return true;
	end;
end;

-- A function to set whether a player's config has initialized.
function playerMeta:SetConfigInitialized(initialized)
	self.cwConfigInitialized = initialized;
end;

-- A function to get whether a player's config has initialized.
function playerMeta:HasConfigInitialized()
	return self.cwConfigInitialized;
end;

-- A function to get a player's forced animation.
function playerMeta:GetForcedAnimation()
	return self.cwForcedAnimation;
end;

-- A function to get a player's item entity.
function playerMeta:GetItemEntity()
	if (IsValid(self.itemEntity)) then
		return self.itemEntity;
	end;
end;

-- A function to set a player's item entity.
function playerMeta:SetItemEntity(entity)
	self.itemEntity = entity;
end;

-- A function to create a player's temporary data.
function playerMeta:CreateTempData()
	local uniqueID = self:UniqueID();
	
	if (!CW.TempPlayerData[uniqueID]) then
		CW.TempPlayerData[uniqueID] = {};
	end;
	
	return CW.TempPlayerData[uniqueID];
end;

-- A function to make a player fake pickup an entity.
function playerMeta:FakePickup(entity)
	local entityPosition = entity:GetPos();
	
	if (entity:IsPlayer()) then
		entityPosition = entity:GetShootPos();
	end;
	
	local shootPosition = self:GetShootPos();
	local feetDistance = self:GetPos():Distance(entityPosition);
	local armsDistance = shootPosition:Distance(entityPosition);
	
	if (feetDistance < armsDistance) then
		self:SetForcedAnimation("pickup", 1.2);
	else
		self:SetForcedAnimation("gunrack", 1.2);
	end;
end;

-- A function to set a player's temporary data.
function playerMeta:SetTempData(key, value)
	local tempData = self:CreateTempData();
	
	if (tempData) then
		tempData[key] = value;
	end;
end;

-- A function to set the player's Clockwork user group.
function playerMeta:SetClockworkUserGroup(userGroup)
	if (self:GetClockworkUserGroup() != userGroup) then
		self.cwUserGroup = userGroup;
		self:SetUserGroup(userGroup);
		self:SaveCharacter();

		plugin.Call("OnPlayerUserGroupSet", self, userGroup);
	end;
end;

-- A function to get the player's Clockwork user group.
function playerMeta:GetClockworkUserGroup()
	return self.cwUserGroup;
end;

-- A function to get a player's temporary data.
function playerMeta:GetTempData(key, default)
	local tempData = self:CreateTempData();
	
	if (tempData and tempData[key] != nil) then
		return tempData[key];
	else
		return default;
	end;
end;

-- A function to get a player's items by ID.
function playerMeta:GetItemsByID(uniqueID)
	return CW.inventory:GetItemsByID(
		self:GetInventory(), uniqueID
	);
end;

-- A function to find a player's items by name.
function playerMeta:FindItemsByName(uniqueID, name)
	return CW.inventory:FindItemsByName(
		self:GetInventory(), uniqueID, name
	);
end;

-- A function to get the maximum weight a player can carry.
function playerMeta:GetMaxWeight()
	local itemsList = CW.inventory:GetAsItemsList(self:GetInventory()); 
	local weight = self:GetSharedVar("InvWeight") or 8;
	
	for k, v in pairs(itemsList) do
		local addInvWeight = v("addInvSpace");
		if (addInvWeight) then
			weight = weight + addInvWeight;
		end;
	end;
	
	return weight;
end;

-- A function to get the maximum space a player can carry.
function playerMeta:GetMaxSpace()
	local itemsList = CW.inventory:GetAsItemsList(self:GetInventory()); 
	local space = self:GetSharedVar("InvSpace") or 10;
	
	for k, v in pairs(itemsList) do
		local addInvSpace = v("addInvVolume");
		if (addInvSpace) then
			space = space + addInvSpace;
		end;
	end;
	
	return space;
end;

-- A function to get whether a player can hold a weight.
function playerMeta:CanHoldWeight(weight)
	local inventoryWeight = CW.inventory:CalculateWeight(
		self:GetInventory()
	);
	
	if (inventoryWeight + weight > self:GetMaxWeight()) then
		return false;
	else
		return true;
	end;
end;

-- A function to get whether a player can hold a weight.
function playerMeta:CanHoldSpace(space)
	if (!CW.inventory:UseSpaceSystem()) then
		return true;
	end;

	local inventorySpace = CW.inventory:CalculateSpace(
		self:GetInventory()
	);
	
	if (inventorySpace + space > self:GetMaxSpace()) then
		return false;
	else
		return true;
	end;
end;

-- A function to get a player's inventory weight.
function playerMeta:GetInventoryWeight()
	return CW.inventory:CalculateWeight(self:GetInventory());
end;

-- A function to get a player's inventory weight.
function playerMeta:GetInventorySpace()
	return CW.inventory:CalculateSpace(self:GetInventory());
end;

-- A function to get whether a player has an item by ID.
function playerMeta:HasItemByID(uniqueID)
	return CW.inventory:HasItemByID(
		self:GetInventory(), uniqueID
	);
end;

-- A function to count how many items a player has by ID.
function playerMeta:GetItemCountByID(uniqueID)
	return CW.inventory:GetItemCountByID(
		self:GetInventory(), uniqueID
	);
end;

-- A function to get whether a player has a certain amount of items by ID.
function playerMeta:HasItemCountByID(uniqueID, amount)
	return CW.inventory:HasItemCountByID(
		self:GetInventory(), uniqueID, amount
	);
end;

-- A function to find a player's item by ID.
function playerMeta:FindItemByID(uniqueID, itemID)
	return CW.inventory:FindItemByID(
		self:GetInventory(), uniqueID, itemID
	);
end;

-- A function to get whether a player has an item as a weapon.
function playerMeta:HasItemAsWeapon(itemTable)
	for k, v in pairs(self:GetWeapons()) do
		local weaponItemTable = CW.item:GetByWeapon(v);
		if (itemTable:IsTheSameAs(weaponItemTable)) then
			return true;
		end;
	end;
	
	return false;
end;

-- A function to find a player's weapon item by ID.
function playerMeta:FindWeaponItemByID(uniqueID, itemID)
	for k, v in pairs(self:GetWeapons()) do
		local weaponItemTable = CW.item:GetByWeapon(v);
		if (weaponItemTable and weaponItemTable("uniqueID") == uniqueID
		and weaponItemTable("itemID") == itemID) then
			return weaponItemTable;
		end;
	end;
end;

-- A function to get whether a player has an item instance.
function playerMeta:HasItemInstance(itemTable)
	return CW.inventory:HasItemInstance(
		self:GetInventory(), itemTable
	);
end;

-- A function to get a player's item instance.
function playerMeta:GetItemInstance(uniqueID, itemID)
	return CW.inventory:FindItemByID(
		self:GetInventory(), uniqueID, itemID
	);
end;

-- A function to take a player's item by ID.
function playerMeta:TakeItemByID(uniqueID, itemID)
	local itemTable = self:GetItemInstance(uniqueID, itemID);
	
	if (itemTable) then
		return self:TakeItem(itemTable);
	else
		return false;
	end;
end;

-- A function to get a player's attribute boosts.
function playerMeta:GetAttributeBoosts()
	return self.cwAttrBoosts;
end;

-- A function to rebuild a player's inventory.
function playerMeta:RebuildInventory()
	CW.inventory:Rebuild(self);
end;

-- A function to give an item to a player.
function playerMeta:GiveItem(itemTable, bForce)
	if (type(itemTable) == "string") then
		itemTable = CW.item:CreateInstance(itemTable);
	end;
	
	if (!itemTable or !itemTable:IsInstance()) then
		debug.Trace();
		return false, "ERROR: Trying to give a player a non-instance item!";
	end;
	
	local inventory = self:GetInventory();
	
	if ((self:CanHoldWeight(itemTable("weight"))
	and self:CanHoldSpace(itemTable("space"))) or bForce) then
		if (itemTable.OnGiveToPlayer) then
			itemTable:OnGiveToPlayer(self);
		end;
		
		CW.kernel:PrintLog(LOGTYPE_GENERIC, self:Name().." has gained a "..itemTable("name").." "..itemTable("itemID")..".");
		
		CW.inventory:AddInstance(inventory, itemTable);
			netstream.Start(self, "InvGive", CW.item:GetDefinition(itemTable, true));
		plugin.Call("PlayerItemGiven", self, itemTable, bForce);
		
		return itemTable;
	else
		return false, "You do not have enough inventory space!";
	end;
end;

-- A function to take an item from a player.
function playerMeta:TakeItem(itemTable)
	if (!itemTable or !itemTable:IsInstance()) then
		debug.Trace();
		return false;
	end;
	
	local inventory = self:GetInventory();
	
	if (itemTable.OnTakeFromPlayer) then
		itemTable:OnTakeFromPlayer(self);
	end;
	
	CW.kernel:PrintLog(LOGTYPE_GENERIC, self:Name().." has lost a "..itemTable("name").." "..itemTable("itemID")..".");
	
	plugin.Call("PlayerItemTaken", self, itemTable);
		CW.inventory:RemoveInstance(inventory, itemTable);
	netstream.Start(self, "InvTake", {itemTable("index"), itemTable("itemID")});
	return true;
end;

-- An easy function to give a table of items to a player.
function playerMeta:GiveItems(itemTables)
	for _, itemTable in pairs(itemTables) do
		self:GiveItem(itemTables)
	end
end

-- An easy function to take a table of items from a player.
function playerMeta:TakeItems(itemTables)
	for _, itemTable in pairs(itemTables) do
		self:TakeItem(itemTable)
	end
end

-- A function to update a player's attribute.
function playerMeta:UpdateAttribute(attribute, amount)
	return CW.attributes:Update(self, attribute, amount);
end;

-- A function to progress a player's attribute.
function playerMeta:ProgressAttribute(attribute, amount, gradual)
	return CW.attributes:Progress(self, attribute, amount, gradual);
end;

-- A function to boost a player's attribute.
function playerMeta:BoostAttribute(identifier, attribute, amount, duration)
	return CW.attributes:Boost(self, identifier, attribute, amount, duration);
end;

-- A function to get whether a boost is active for a player.
function playerMeta:IsBoostActive(identifier, attribute, amount, duration)
	return CW.attributes:IsBoostActive(self, identifier, attribute, amount, duration);
end;

-- A function to get a player's characters.
function playerMeta:GetCharacters()
	return self.cwCharacterList;
end;

-- A function to set a player's run speed.
function playerMeta:SetRunSpeed(speed, bClockwork)
	if (!bClockwork) then self.cwRunSpeed = speed; end;
	self:ClockworkSetRunSpeed(speed);
end;

-- A function to set a player's walk speed.
function playerMeta:SetWalkSpeed(speed, bClockwork)
	if (!bClockwork) then self.cWalkSpeed = speed; end;
	self:ClockworkSetWalkSpeed(speed);
end;

-- A function to set a player's jump power.
function playerMeta:SetJumpPower(power, bClockwork)
	if (!bClockwork) then self.cwJumpPower = power; end;
	self:ClockworkSetJumpPower(power);
end;

-- A function to set a player's crouched walk speed.
function playerMeta:SetCrouchedWalkSpeed(speed, bClockwork)
	if (!bClockwork) then self.cwCrouchedSpeed = speed; end;
	self:ClockworkSetCrouchedWalkSpeed(speed);
end;

-- A function to get whether a player has initialized.
function playerMeta:HasInitialized()
	return self.cwInitialized;
end;

-- A function to query a player's character table.
function playerMeta:QueryCharacter(key, default)
	if (self:GetCharacter()) then
		return CW.player:Query(self, key, default);
	else
		return default;
	end;
end;

-- A function to get a player's shared variable.
function playerMeta:GetSharedVar(key)
	return self:GetNetVar(key);
end;

-- A function to set a shared variable for a player.
function playerMeta:SetSharedVar(key, value, sharedTable)
	self:SetNetVar(key, value);
end;

-- A function to get a player's character data.
function playerMeta:GetCharacterData(key, default)
	if (self:GetCharacter()) then
		local data = self:QueryCharacter("Data");
		
		if (data[key] != nil) then
			return data[key];
		end;
	end;
	
	return default;
end;

-- A function to get a player's time joined.
function playerMeta:TimeJoined()
	return self.cwTimeJoined or os.time();
end;

-- A function to get when a player last played.
function playerMeta:LastPlayed()
	return self.cwLastPlayed or os.time();
end;

-- A function to get a player's clothes data.
function playerMeta:GetClothesData()
	local clothesData = self:GetCharacterData("Clothes");

	if (type(clothesData) != "table") then
		clothesData = {};
	end;
	
	return clothesData;
end;

-- A function to get a player's accessory data.
function playerMeta:GetAccessoryData()
	local accessoryData = self:GetCharacterData("Accessories");

	if (type(accessoryData) != "table") then
		accessoryData = {};
	end;
	
	return accessoryData;
end;

-- A function to remove a player's clothes.
function playerMeta:RemoveClothes(bRemoveItem)
	self:SetClothesData(nil);
	
	if (bRemoveItem) then
		local clothesItem = self:GetClothesItem();
		
		if (clothesItem) then
			self:TakeItem(clothesItem);
			return clothesItem;
		end;
	end;
end;

-- A function to get the player's clothes item.
function playerMeta:GetClothesItem()
	local clothesData = self:GetClothesData();
	
	if (type(clothesData) == "table") then
		if (clothesData.itemID != nil and clothesData.uniqueID != nil) then
			return self:FindItemByID(
				clothesData.uniqueID, clothesData.itemID
			);
		end;
	end;
end;

-- A function to get whether a player is wearing clothes.
function playerMeta:IsWearingClothes()
	return (self:GetClothesItem() != nil);
end;

-- A function to get whether a player is wearing an item.
function playerMeta:IsWearingItem(itemTable)
	local clothesItem = self:GetClothesItem();
	return (clothesItem and clothesItem:IsTheSameAs(itemTable));
end;

-- A function to network the player's clothes data.
function playerMeta:NetworkClothesData()
	local clothesData = self:GetClothesData();

	if (clothesData.uniqueID and clothesData.itemID) then
		self:SetSharedVar("Clothes", clothesData.uniqueID.." "..clothesData.itemID);
	else
		self:SetSharedVar("Clothes", "");
	end;
end;

-- A function to set a player's clothes data.
function playerMeta:SetClothesData(itemTable)
	local clothesItem = self:GetClothesItem();
	
	if (itemTable) then
		local model = CW.class:GetAppropriateModel(self:Team(), self, true);
		
		if (!model) then
			if (clothesItem and itemTable != clothesItem) then
				clothesItem:OnChangeClothes(self, false);
			end;
			
			itemTable:OnChangeClothes(self, true);
			
			local clothesData = self:GetClothesData();
				clothesData.itemID = itemTable("itemID");
				clothesData.uniqueID = itemTable("uniqueID");
			self:NetworkClothesData();
		end;
	else
		local clothesData = self:GetClothesData();
			clothesData.itemID = nil;
			clothesData.uniqueID = nil;
		self:NetworkClothesData();
		
		if (clothesItem) then
			clothesItem:OnChangeClothes(self, false);
		end;
	end;
end;

-- A function to get the entity a player is holding.
function playerMeta:GetHoldingEntity()
	return plugin.Call("PlayerGetHoldingEntity", self) or self.cwIsHoldingEnt;
end;

-- A function to get whether a player's character menu is reset.
function playerMeta:IsCharacterMenuReset()
	return self.cwCharMenuReset;
end;

-- A function to get the player's active voice channel.
function playerMeta:GetActiveChannel()
	return CW.voice:GetActiveChannel(self);
end;

-- A function to check if a player can afford an amount.
function playerMeta:CanAfford(amount)
	return CW.player:CanAfford(self, amount);
end;

-- A function to get a player's rank within their faction.
function playerMeta:GetFactionRank(character)
	return CW.player:GetFactionRank(self, character);
end;

-- A function to set a player's rank within their faction.
function playerMeta:SetFactionRank(rank)
	return CW.player:SetFactionRank(self, rank);
end;

-- A function to get a player's global flags.
function playerMeta:GetPlayerFlags()
	return CW.player:GetPlayerFlags(self);
end;

playerMeta.GetName = playerMeta.Name;
playerMeta.Nick = playerMeta.Name;

concommand.Add("cwStatus", function(player, command, arguments)
	local plyTable = player.GetAll();

	if (IsValid(player)) then
		if (CW.player:IsAdmin(player)) then
			player:PrintMessage(2, "# User ID | Name | Steam Name | Steam ID | IP Address");

			for k, v in pairs(plyTable) do
				if (v:HasInitialized()) then
					local status = plugin.Call("PlayerCanSeeStatus", player, v);
					
					if (status) then
						player:PrintMessage(2, status);
					end;
				end;
			end;
		else
			player:PrintMessage(2, "You do not have access to this command, "..player:Name()..".");
		end;
	else
		print("# User ID | Name | Steam Name | Steam ID | IP Address");
		
		for k, v in pairs(plyTable) do
			if (v:HasInitialized()) then
				print("# "..v:UserID().." | "..v:Name().." | "..v:SteamName().." | "..v:SteamID().." | "..v:IPAddress());
			end;
		end;
	end;
end);

-- The most awfully written function in CW.
-- Allows you to call certain commands from server console.
-- ToDo: Rewrite everything to be shorter;
concommand.Add("cwc", function(player, command, arguments)
	-- Yep, it's awfully written, but it's not meant to be edited, so...
	local cmdTable = {
		sg  = "setgroup",
		d   = "demote",
		sc  = "setcash",
		w   = "whitelist",
		uw  = "unwhitelist",
		b   = "ban",
		k   = "kick",
		sn  = "setname",
		sm  = "setmodel",
		r   = "restart",
		gf  = "giveflags",
		tf  = "takeflags"
	};
	
	--  if called from console
	if (!IsValid(player)) then
		-- PlySetGroup
		if (arguments[1] == cmdTable.sg) then
			local target = CW.player:FindByID(arguments[2]);
			local userGroup = arguments[3];
			
			if (userGroup != "superadmin" and userGroup != "admin" and userGroup != "operator") then
				MsgC(Color(255, 100, 0, 255), "The user group must be superadmin, admin or operator!\n");
				
				return;
			end;
			
			if (target) then
				if (!CW.player:IsProtected(target)) then
					print("Console has set "..target:Name().."'s user group to "..userGroup..".");
					CW.player:NotifyAll("Console has set "..target:Name().."'s user group to "..userGroup..".");
						target:SetClockworkUserGroup(userGroup);
					CW.player:LightSpawn(target, true, true);
				else
					MsgC(Color(255, 100, 0, 255), target:Name().." is protected!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid player!\n");
			end;
			
			return;
		-- PlyDemote
		elseif (arguments[1] == cmdTable.d) then
			local target = CW.player:FindByID(arguments[2]);
			
			if (target) then
				if (!CW.player:IsProtected(target)) then
					local userGroup = target:GetClockworkUserGroup();
					
					if (userGroup != "user") then
						print("Console has demoted "..target:Name().." from "..userGroup.." to user.");
						CW.player:NotifyAll("Console has demoted "..target:Name().." from "..userGroup.." to user.");
							target:SetClockworkUserGroup("user");
						CW.player:LightSpawn(target, true, true);
					else
						MsgC(Color(255, 100, 0, 255), "This player is only a user and cannot be demoted!\n");
					end;
				else
					MsgC(Color(255, 100, 0, 255), target:Name().." is protected!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid player!\n");
			end;
			
			return;
		-- SetCash
		elseif (arguments[1] == cmdTable.sc) then
			local target = CW.player:FindByID(arguments[2])
			local cash = math.floor(tonumber((arguments[3] or 0)));
			
			if (target) then
				if (cash and cash >= 1) then
					local playerName = "Console";
					local targetName = target:Name();
					local giveCash = cash - target:GetCash();
					
					CW.player:GiveCash(target, giveCash);
					
					print("Console has set "..targetName.."'s cash to "..CW.kernel:FormatCash(cash, nil, true)..".");
					CW.player:Notify(target, "Your cash was set to "..CW.kernel:FormatCash(cash, nil, true).." by "..playerName..".");
				else
					MsgC(Color(255, 100, 0, 255), "This is not a valid amount!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid player!\n");
			end;
			
			return;
		-- PlyWhitelist
		elseif (arguments[1] == cmdTable.w) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				local factionTable = CW.faction:FindByID(table.concat(arguments, " ", 3));
				
				if (factionTable) then
					if (factionTable.whitelist) then
						if (!CW.player:IsWhitelisted(target, factionTable.name)) then
							CW.player:SetWhitelisted(target, factionTable.name, true);
							CW.player:SaveCharacter(target);
							
							print("Console has added "..target:Name().." to the "..factionTable.name.." whitelist.");
							CW.player:NotifyAll("Console has added "..target:Name().." to the "..factionTable.name.." whitelist.");
						else
							MsgC(Color(255, 100, 0, 255), target:Name().." is already on the "..factionTable.name.." whitelist!\n");
						end;
					else
						MsgC(Color(255, 100, 0, 255), factionTable.name.." does not have a whitelist!\n");
					end;
				else
					MsgC(Color(255, 100, 0, 255), table.concat(arguments, " ", 3).." is not a valid faction!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid player!\n");
			end;
			
			return;
		-- PlyUnWhitelist
		elseif (arguments[1] == cmdTable.uw) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				local factionTable = CW.faction:FindByID(table.concat(arguments, " ", 3));
				
				if (factionTable) then
					if (factionTable.whitelist) then
						if (CW.player:IsWhitelisted(target, factionTable.name)) then
							CW.player:SetWhitelisted(target, factionTable.name, false);
							CW.player:SaveCharacter(target);
							
							print("Console has removed "..target:Name().." from the "..factionTable.name.." whitelist.");
							CW.player:NotifyAll("Console has removed "..target:Name().." from the "..factionTable.name.." whitelist.");
						else
							MsgC(Color(255, 100, 0, 255), target:Name().." is not on the "..factionTable.name.." whitelist!\n");
						end;
					else
						MsgC(Color(255, 100, 0, 255), factionTable.name.." does not have a whitelist!\n");
					end;
				else
					MsgC(Color(255, 100, 0, 255), factionTable.name.." is not a valid faction!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid player!\n");
			end;
			
			return;
		-- PlyBan
		elseif (arguments[1] == cmdTable.b) then
			local schemaFolder = CW.kernel:GetSchemaFolder();
			local duration = tonumber(arguments[3]);
			local reason = table.concat(arguments, " ", 4);
			
			if (!reason or reason == "") then
				reason = nil;
			end;
			
			if (!CW.player:IsProtected(arguments[2])) then
				if (duration) then
					CW.bans:Add(arguments[2], duration * 60, reason, function(steamName, duration, reason)
						if (IsValid(player)) then
							if (steamName) then
								if (duration > 0) then
									local hours = math.Round(duration / 3600);
									
									if (hours >= 1) then
										print("Console has banned '"..steamName.."' for "..hours.." hour(s) ("..reason..").");
										CW.player:NotifyAll("Console has banned '"..steamName.."' for "..hours.." hour(s) ("..reason..").");
									else
										print("Console has banned '"..steamName.."' for "..math.Round(duration / 60).." minute(s) ("..reason..").");
										CW.player:NotifyAll("Console has banned '"..steamName.."' for "..math.Round(duration / 60).." minute(s) ("..reason..").");
									end;
								else
									print("Console has banned '"..steamName.."' permanently ("..reason..").");
									CW.player:NotifyAll("Console has banned '"..steamName.."' permanently ("..reason..").");
								end;
							else
								MsgC(Color(255, 100, 0, 255), "This is not a valid identifier!\n");
							end;
						end;
					end);
				else
					MsgC(Color(255, 100, 0, 255), "This is not a valid duration!\n");
				end;
			else
				local target = CW.player:FindByID(arguments[2]);
				
				if (target) then
					MsgC(Color(255, 100, 0, 255), target:Name().." is protected!\n");
				else
					MsgC(Color(255, 100, 0, 255), "This player is protected!\n");
				end;
			end;
			
			return;
		-- PlyKick
		elseif (arguments[1] == cmdTable.k) then
			local target = CW.player:FindByID(arguments[2]);
			local reason = table.concat(arguments, " ", 3);
			
			if (!reason or reason == "") then
				reason = "N/A";
			end;
			
			if (target) then
				if (!CW.player:IsProtected(arguments[2])) then
					print("Console has kicked '"..target:Name().."' ("..reason..").");
					CW.player:NotifyAll("Console has kicked '"..target:Name().."' ("..reason..").");
						target:Kick(reason);
					target.kicked = true;
				else
					MsgC(Color(255, 100, 0, 255), target:Name().." is protected!\n");
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[1].." is not a valid player!\n");
			end;
			
			return;
		-- CharSetName
		elseif (arguments[1] == cmdTable.sn) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				if (arguments[3] == "nil") then
					MsgC(Color(255, 100, 0, 255), "You have to specify the name as the last argument, it also has to be 'quoted'.\n");
					
					return;
				else
					local name = table.concat(arguments, " ", 3);
					
					print("Console has set "..target:Name().."'s name to "..name..".");
					CW.player:NotifyAll("Console has set "..target:Name().."'s name to "..name..".");
					
					CW.player:SetName(target, name);
				end;
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid character!\n");
			end;
			
			return;
		-- CharSetModel
		elseif (arguments[1] == cmdTable.sm) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				local model = table.concat(arguments, " ", 3);
				
				target:SetCharacterData("Model", model, true);
				target:SetModel(model);
				
				print("Console has set "..target:Name().."'s model to "..model..".");
				CW.player:NotifyAll("Console has set "..target:Name().."'s model to "..model..".");
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid character!\n");
			end;
			
			return;
		-- MapRestart
		elseif (arguments[1] == cmdTable.r) then
			local delay = tonumber(arguments[2]) or 10;
			
			if (type(arguments[2]) == "number") then
				delay = arguments[2];
			end;

			print("Console is restarting the map in "..delay.." seconds!");
			CW.player:NotifyAll("Console is restarting the map in "..delay.." seconds!");
			
			timer.Simple(delay, function()
				RunConsoleCommand("changelevel", game.GetMap());
			end);
			
			return;
		-- GiveFlags
		elseif (arguments[1] == cmdTable.gf) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				if (string.find(arguments[3], "a") or string.find(arguments[3], "s") or string.find(arguments[3], "o")) then
					MsgC(Color(255, 100, 0, 255), "You cannot give 'o', 'a' or 's' flags!\n");
					
					return;
				end;
				
				if (!arguments[3]) then print("You haven't entered any flags!"); return; end;
				
				CW.player:GiveFlags(target, arguments[3]);
				
				print("Console gave "..target:Name().." '"..arguments[3].."' flags.");
				CW.player:NotifyAll("Console gave "..target:Name().." '"..arguments[3].."' flags.");
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid character!\n");
			end;
	
			return;
		-- TakeFlags
		elseif (arguments[1] == cmdTable.tf) then
			local target = CW.player:FindByID(arguments[2])
			
			if (target) then
				if (string.find(arguments[3], "a") or string.find(arguments[3], "s") or string.find(arguments[3], "o")) then
					CW.player:Notify(player, "You cannot take 'o', 'a' or 's' flags!");
					
					return;
				end;
				
				if (!arguments[3]) then print("You haven't entered any flags!"); return; end;
				
				CW.player:TakeFlags(target, arguments[3]);
				
				print("Console took '"..arguments[3].."' flags from "..target:Name()..".");
				CW.player:NotifyAll("Console took '"..arguments[3].."' flags from "..target:Name()..".");
			else
				MsgC(Color(255, 100, 0, 255), arguments[2].." is not a valid character!\n");
			end;
	
			return;
		-- Everything else
		else
			MsgC(Color(255, 100, 0, 255), "'"..arguments[1].. "' command not found!\n");
		end;
	-- if not too bad, players are not allowed to use this swag
	else
		CW.player.Notify(player, "You are not allowed to use server-side commands!");
	end;
end);

concommand.Add("cwDeathCode", function(player, command, arguments)
	if (player.cwDeathCodeIdx) then
		if (arguments and tonumber(arguments[1]) == player.cwDeathCodeIdx) then
			player.cwDeathCodeAuth = true;
		end;
	end;
end);

--[[ Accessories --]]
local playerMeta = FindMetaTable("Player");
function playerMeta:NetworkAccessories()
 local accessoryData = self:GetAccessoryData();
 netstream.Start(self, "AllAccessories", accessoryData);
end;
function playerMeta:RemoveAccessory(itemTable)
 if (not self:IsWearingAccessory(itemTable)) then return; end;
 
 local accessoryData = self:GetAccessoryData();
 local uniqueID = itemTable("uniqueID");
 local itemID = itemTable("itemID");
 
 accessoryData[itemID] = nil;
 netstream.Start(
 self, "RemoveAccessory", {itemID = itemID}
 );
 
 if (itemTable.OnWearAccessory) then
 itemTable:OnWearAccessory(self, false);
 end;
end;

function playerMeta:HasAccessory(uniqueID)
 local accessoryData = self:GetAccessoryData();
 
 for k, v in pairs(accessoryData) do
 if (string.lower(v) == string.lower(uniqueID)) then
 return true;
 end;
 end;
 
 return false;
end;

function playerMeta:IsWearingAccessory(itemTable)
 local accessoryData = self:GetAccessoryData();
 local itemID = itemTable("itemID");
 
 if (accessoryData[itemID]) then
 return true;
 else
 return false;
 end;
end;

function playerMeta:WearAccessory(itemTable)
 if (self:IsWearingAccessory(itemTable)) then return; end;
 
 local accessoryData = self:GetAccessoryData();
 local uniqueID = itemTable("uniqueID");
 local itemID = itemTable("itemID");
 
 accessoryData[itemID] = itemTable("uniqueID");
 netstream.Start(
 self, "AddAccessory", {itemID = itemID, uniqueID = uniqueID}
 );
 
 if (itemTable.OnWearAccessory) then
 itemTable:OnWearAccessory(self, true);
 end;
end;

--[[ Character Data and Player Data --]]
-- Called when a player's character data has changed.
function CW:PlayerCharacterDataChanged(player, key, oldValue, newValue)
 self.player:UpdateCharacterData(player, key, newValue);
end;

-- Called when a player's data has changed.
function CW:PlayerDataChanged(player, key, oldValue, newValue)
 self.player:UpdatePlayerData(player, key, newValue);
end;

-- A function to set a player's character data.
function playerMeta:SetCharacterData(key, value, bFromBase)
 local character = self:GetCharacter();
 
 if (!character) then return; end;
 
 if (bFromBase) then
 key = CW.kernel:SetCamelCase(key, true);
 
 if (character[key] != nil) then
 character[key] = value;
 end;
 else
 local oldValue = character.data[key];
 character.data[key] = value;
 
 if (value ~= oldValue) then
 plugin.Call("PlayerCharacterDataChanged", self, key, oldValue, value);
 end;
 end;
end;

-- A function to set a player's data.
function playerMeta:SetData(key, value)
 if (self.cwData) then
 local oldValue = self.cwData[key];
 self.cwData[key] = value;
 
 if (value ~= oldValue) then
 plugin.Call("PlayerDataChanged", self, key, oldValue, value);
 end;
 end;
end;

local phrases = {
	"Sending your private info to kurozael",
	"Hacking your bank accounts",
	"Stealing your cat",
	"Installing Windows 10 spyware",
	"Sending your private info to Microsoft",
	"Do not wait",
	"Using your server to DDoS LemonPunch",
	"Using your server to mine bitcoins",
	"Crashing your server",
	"Adding extra 7 seconds to boot times",
	"Sending a DMCA notice to Alex Grist",
	"Starting a lawsuit against you for using Standalone",
	"Installing backdoors",
	"Giving kurozael owner",
	"Banning your whole playerbase",
	"You are not authorized by CloudAuthX to use Standalone",
	"Making kittens cry",
	"Installing an update that breaks everything",
	"Loading your CPU core to 100%",
	"Crying about that extra space in the serial file",
	"Attempting to explode your server for using Standalone",
	"CloudAuthX is not installed",
	"Downloading porn",
	"Opening kuro's favorite PH category (gay porn)",
	"Reporting you to NSA",
	"Banning random people",
	"Attempting to install legit CW... ERROR",
	"Transferring all your money to kurozael",
	"Transferring $30 to kurozael",
	"#kurobucks, #kurobank",
	"Throwing all the errors at you",
	"Downloading internet",
	"Sending your server IP to Anonymous",
	"Taking over your community",
	"Turning your cat into a dog",
	"Turning your dog into a cat",
	"Suing you for using Standalone",
	"Generating shit ton of Alex Grist drama",
	"Burning your CPU",
	"Stealing your CS:GO items",
	"Stealing your TF2 hats",
	"Downloading ponies",
	"Generating Lua Errors",
	"Something is creating script errors",
	"Banning people for thinking about NutScript",
	"Installing NutScript",
	"Ripping off NutScript",
	"Stealing TARDIS",
	"Installing winlocker",
	"Hacking your Apple ID"
}

MsgC(Color(0, 255, 255, 255), "[CloudAuthX] "..table.Random(phrases)..", please wait...\n");
