--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.config:AddToSystem("Take Physcannon", "take_physcannon", "Whether or not the player is stripped of the physics cannon.");