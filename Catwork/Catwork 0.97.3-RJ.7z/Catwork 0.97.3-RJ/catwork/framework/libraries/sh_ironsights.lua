--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[ 
	We need the datastream and plugin libraries. 
--]]
if (!netstream) then include("sh_netstream.lua"); end;
if (!plugin) then include("sh_plugin.lua"); end;
if (!CW.player) then include("sh_player.lua"); end;

CW.ironsights = CW.ironsights or CW.kernel:NewLibrary("CW Ironsights");

local nextIronSights = nil;

function CW.ironsights:GetIronSights(player)
	if (CW.config:Get("enable_ironsights"):Get()) then
		if (CLIENT) then
			return plugin.Call("PlayerCanSeeIronSights", CW.Client, CW.Client.cwIronSights);
		else
			return player.cwIronSights;
		end;
	else
		return false;
	end;
end;

function CW.ironsights:SetIronSights(player, bValue)
	player.cwIronSights = bValue;

	if (SERVER) then
		netstream.Start(player, "SetClockworkIronSights", {bValue});
	else
		netstream.Start("SetClockworkIronSights", {bValue});
	end;
end;

function CW.ironsights:ToggleIronSights(player)
	if (SERVER) then
		if (IsValid(player) and player:IsValid()) then
			local bIronSights = self:GetIronSights(player);

			if (CW.config:Get("enable_ironsights"):Get() and plugin.Call("PlayerCanToggleIronSights", player, bIronSights)) then
				local curTime = CurTime();

				if (!nextIronSights or nextIronSights <= curTime) then
					self:SetIronSights(player, !bIronSights);
					nextIronSights = curTime + 0.4;
				end;
			end;
		end;
	else
		netstream.Start("ToggleClockworkIronSights");
	end;
end;

function CW.ironsights:PlayerCanToggleIronSights(player, bIronSights)
	return (CW.player:GetWeaponRaised(player) or bIronSights);
end;

function CW.ironsights:EntityFireBullets(player, bulletInfo)
	if (IsValid(player) and player:IsValid() and player:IsPlayer()) then
		if (self:GetIronSights(player)) then
			local spread = bulletInfo.Spread;
			local spreadReduction = CW.config:Get("ironsights_spread"):Get() or 1;

			bulletInfo.Spread = Vector(spread.x * spreadReduction, spread.y * spreadReduction, spread.z * spreadReduction);

			return true;
		end;
	end;
end;

if (SERVER) then
	netstream.Hook("ToggleClockworkIronSights", function(player)
		CW.ironsights:ToggleIronSights(player);
	end);

	netstream.Hook("SetClockworkIronSights", function(player, data)
		player.cwIronSights = data[1];
	end);

	function CW.ironsights:PlayerThink(player, curTime, infoTable)
		if (self:GetIronSights(player) and CW.player:GetWeaponRaised(player)) then
			infoTable.walkSpeed = infoTable.walkSpeed * CW.config:Get("ironsights_slow"):Get() or 0.5;
		end;
	end;

	function CW.ironsights:PlayerSwitchWeapon(player, oldWep, newWep)
		self:SetIronSights(player, false);
	end;
else
	--[[
		Ironsights hooks.
	--]]
	netstream.Hook("SetClockworkIronSights", function(data)
		CW.Client.cwIronSights = data[1];
	end);

	CW.ironsights.ironFraction = 0;

	function CW.ironsights:PlayerCanSeeIronSights(player, bIronSights)
		if (bIronSights) then
			return !player:IsRunning() and CW.player:GetWeaponRaised(player);
		end;

		return false;
	end;

	function CW.ironsights:PlayerAdjustHeadbobInfo(info)
		if (self:GetIronSights()) then
			info.speed = 0;
			info.yaw = 0;
			info.roll = 0;
		end;
	end;

	function CW.ironsights:CanDrawCrosshair(weapon)
		if (!CW.config:Get("enable_crosshair"):Get()) then
			if (self:GetIronSights() and CW.Client:GetThirdPerson()) then
				return true;
			end;
		end;
	end;

	function CW.ironsights:PlayerBindPress(ply, bind, bPressed)
		if (bind == "+reload") then
			self:SetIronSights(CW.Client, false);
		end;
	end;

	function CW.ironsights:PlayerButtonDown(ply, key)
		if (key == MOUSE_MIDDLE) then
			self:ToggleIronSights(CW.Client);
		end;
	end;

	function CW.ironsights:GetWeaponIronsightsViewInfo(itemTable, weapon, viewTable)
		if (weapon) then
			local pos = weapon.IronSightsPos or weapon.SightsPos;
			local ang = weapon.IronSightsAng or weapon.SightsAng;

			if (pos) then
				viewTable.origin = pos;
			end;

			if (ang) then
				viewTable.angles = ang;
			end;
		end;

		if (itemTable) then
			local pos = itemTable.IronSightsPos;
			local ang = itemTable.IronSightsAng;

			if (pos) then
				viewTable.origin = pos;
			end;

			if (ang) then
				viewTable.angles = ang;
			end;
		end;
	end;

	function CW.ironsights:CalcViewAdjustTable(view)
		if (CW.ironsights:GetIronSights() or CW.ironsights.ironFraction > 1) then
			view.fov = view.fov - (10 * (CW.ironsights.ironFraction/100));
		end;
	end;

	concommand.Add("cwToggleIronSights", function(ply, cmd, args, argStr)
		CW.ironsights:ToggleIronSights();
	end);
end;

plugin.Add("Ironsights_Module", CW.ironsights);