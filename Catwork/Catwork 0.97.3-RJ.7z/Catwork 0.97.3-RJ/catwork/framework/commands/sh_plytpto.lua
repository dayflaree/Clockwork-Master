--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyTeleportTo");
COMMAND.tip = "Teleport a player to another player.";
COMMAND.text = "<string Target> <string Name> <bool isSilent>";
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"PlyTPTo", "TPTo"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local ply = CW.player:FindByID(arguments[2]);
	local isSilent = CW.kernel:ToBool(arguments[3]);

	if (target) then
		if (ply) then
			CW.player:SetSafePosition(target, ply:GetPos());

			if (!isSilent) then
				CW.player:NotifyAll(player:Name().." has teleported "..target:Name().." to "..ply:Name()..".");
			end;
		else
			CW.player:Notify(player, arguments[2].." is not a valid player!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();