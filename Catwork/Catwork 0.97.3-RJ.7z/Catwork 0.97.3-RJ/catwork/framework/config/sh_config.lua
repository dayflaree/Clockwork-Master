--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.config:ShareKey("use_opens_entity_menus");
CW.config:ShareKey("target_id_delay");
CW.config:ShareKey("additional_characters");
CW.config:ShareKey("raised_weapon_system");
CW.config:ShareKey("use_own_group_system");
CW.config:ShareKey("default_inv_weight");
CW.config:ShareKey("default_inv_space");
CW.config:ShareKey("limb_damage_system");
CW.config:ShareKey("unrecognised_name");
CW.config:ShareKey("enable_crosshair");
CW.config:ShareKey("recognise_system");
CW.config:ShareKey("max_chat_length");
CW.config:ShareKey("use_free_aiming");
CW.config:ShareKey("enable_heartbeat");
CW.config:ShareKey("cash_enabled");
CW.config:ShareKey("default_physdesc");
CW.config:ShareKey("enable_vignette");
CW.config:ShareKey("cash_weight");
CW.config:ShareKey("cash_space");
CW.config:ShareKey("block_inv_binds");
CW.config:ShareKey("fade_dead_npcs");
CW.config:ShareKey("enable_headbob");
CW.config:ShareKey("command_prefix");
CW.config:ShareKey("default_flags");
CW.config:ShareKey("minute_time");
CW.config:ShareKey("local_voice");
CW.config:ShareKey("talk_radius");
CW.config:ShareKey("wages_name");
CW.config:ShareKey("door_cost");
CW.config:ShareKey("enable_space_system");
CW.config:ShareKey("draw_intro_bars");
CW.config:ShareKey("show_business");
CW.config:ShareKey("chat_multiplier");
CW.config:ShareKey("enable_looc_icons");