local PLUGIN = PLUGIN;

CW.kernel:IncludePrefixed("sh_schema.lua");