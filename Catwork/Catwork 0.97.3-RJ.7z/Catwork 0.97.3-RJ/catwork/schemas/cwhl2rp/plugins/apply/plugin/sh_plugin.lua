--[[
	© 2014 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

PLUGIN = PLUGIN;

CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");