--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- We keep the table for utility.
CloudAuthX = CloudAuthX or {};

function CloudAuthX.External()
	return;
end;

local startTime = os.clock();

if (Clockwork and CW.kernel) then
	MsgC(Color(0, 255, 100, 255), "[Catwork] Change detected! Refreshing...\n");
else
	MsgC(Color(0, 255, 100, 255), "[Catwork] Framework is initializing...\n");
end;

if (system.IsLinux()) then
	require("mysqloo");
else
	require("tmysql4");
end;

require("fileio");

if (!CloudAuthX.WatchDogAvailable) then
	if (file.Exists("lua/bin/gmsv_watchdog_win32.dll", "GAME")) then
		print("[Catwork] Loading Watch Dog file monitoring tools...");
		require("watchdog");

		timer.Create("WatchDogUpdater", (1 / 64), 0, function()
			WatchdogUpdate();
		end);

		hook.Add("WatchDogFileChanged", "Printer", function(fileName)
			-- fileName is relative to garrysmod/gamemodes/
			print("[Watchdog] "..fileName);
		end);
		
		-- lmao
		CloudAuthX.WatchDogAvailable = true;
	end;
end;

function IsWatchdogAvailable()
	return CloudAuthX.WatchDogAvailable;
end;

CW_SCRIPT_SHARED = CW_SCRIPT_SHARED or {
	schemaFolder = engine.ActiveGamemode()
};

-- No need to include the stuff that doesn't change twice.
if (!von or !string.utf8len) then
	AddCSLuaFile("external/utf8.lua");
	AddCSLuaFile("external/von.lua");
end;

AddCSLuaFile("cl_init.lua");

--[[
	Include Vercas's serialization library 
	and the Clockwork kernel. --]]
if (!von or !string.utf8len) then
	include("external/utf8.lua");
	include("external/von.lua");
end;

include("catwork/framework/sv_kernel.lua");

if (CW and cwBootComplete) then
	MsgC(Color(0, 255, 100, 255), "[Catwork] AutoRefresh handled serverside in "..math.Round(os.clock() - startTime, 3).. " second(s)\n");
else
	local version = CW.kernel:GetVersionBuild();
	
	MsgC(Color(0, 255, 100, 255), "[Catwork] Framework version ["..version.."] loading took "..math.Round(os.clock() - startTime, 3).. " second(s)\n");
end;

_G["cwBootComplete"] = true;
_G["cwSharedBooted"] = true;