ITEM.baseItem = "weapon_base"
ITEM.name = "Knife"
ITEM.PrintName = "Нож"
ITEM.cost = 70
ITEM.model = "models/weapons/w_knife_ct.mdl"
ITEM.weight = 0.2
ITEM.category = "Холодное оружие"
ITEM.uniqueID = "weapon_knife"
ITEM.business = true
ITEM.spawnValue = 5
ITEM.spawnType = "misc"
ITEM.description = "Острый нож."
ITEM.isAttachment = false
ITEM.hasFlashlight = false
ITEM.loweredOrigin = Vector(3, 0, -4)
ITEM.isMeleeWeapon = true

