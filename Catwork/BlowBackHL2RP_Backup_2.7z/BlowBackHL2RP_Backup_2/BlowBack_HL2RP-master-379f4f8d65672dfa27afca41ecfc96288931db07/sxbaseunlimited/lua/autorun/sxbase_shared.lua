AddCSLuaFile("autorun/sxbase_shared.lua")
AddCSLuaFile("autorun/client/sxbase_clientmenu.lua")

game.AddParticles("particles/hl2rp_muzzles.pcf")
game.AddParticles("particles/fas2_shared.pcf")
game.AddParticles("particles/sxbase_add.pcf")
game.AddParticles("particles/muzzleflashes_test.pcf")
game.AddParticles("particles/muzzleflashes_test_b.pcf")
game.AddParticles("particles/impact_fx_fas.pcf")

local ups = util.PrecacheSound

PrecacheParticleSystem("muzzleflash_ar2")
PrecacheParticleSystem("muzzleflash_pistol_deagle")
PrecacheParticleSystem("muzzleflash_pistol")
PrecacheParticleSystem("muzzleflash_shotgun")
PrecacheParticleSystem("muzzleflash_smg")
PrecacheParticleSystem("muzzleflash_m14")
PrecacheParticleSystem("sxbase_smoke")

local sadd = sound.Add

local FAS_RS = {}
FAS_RS["MagPouch_Pistol"] = "weapons/handling/generic_magpouch_pistol1.wav"
FAS_RS["Weapon.COAR2.Reload"] = "weapons/coirifle/ar2_reload.wav"
FAS_RS["Weapon.COAR2.Push"] = "weapons/coirifle/ar2_reload_push.wav"
FAS_RS["Weapon.COAR2.Rotate"] = "weapons/coirifle/ar2_reload_rotate.wav"
FAS_RS["Weapon.UspMatch.Cloth"] = "weapons/uspmatch/usp_cloth.wav"
FAS_RS["Weapon.UspMatch.SlideBack"] = "weapons/uspmatch/usp_slideback2.wav"
FAS_RS["Weapon.UspMatch.SlideRelease"] = "weapons/uspmatch/usp_sliderelease.wav"
FAS_RS["Weapon.UspMatch.ClipOut"] = "weapons/uspmatch/usp_clipout.wav"
FAS_RS["Weapon.UspMatch.ClipIn"] = "weapons/uspmatch/usp_clipin.wav"
FAS_RS["Weapon_M9.PistolDraw"] = "weapons/universal/uni_pistol_draw_01.wav" 
FAS_RS["Weapon_M9.PistolHolster"] = "weapons/universal/uni_pistol_holster.wav" 
FAS_RS["Weapon_M9.Magrelease"] = "weapons/m9/handling/m9_magrelease.wav"
FAS_RS["Weapon_M9.Magout"] = "weapons/m9/handling/m9_magout.wav"
FAS_RS["Weapon_M9.Magin"] = "weapons/m9/handling/m9_magin.wav"
FAS_RS["Weapon_M9.MagHit"] = "weapons/m9/handling/m9_maghit.wav"
FAS_RS["Weapon_M9.Boltrelease"] = "weapons/m9/handling/m9_boltrelease.wav"
FAS_RS["Weapon_M9.Empty"] = "weapons/m9/handling/m9_empty.wav"
FAS_RS["Weapon_m40a1.Draw"] = "weapons/universal/uni_pistol_draw_01.wav" 
FAS_RS["Weapon_m40a1.Holster"] = "weapons/universal/uni_pistol_holster.wav" 
FAS_RS["Weapon_m40a1.BoltRelease"] = "weapons/m40a1/handling/m40a1_boltrelease.wav"
FAS_RS["Weapon_m40a1.Boltback"] = "weapons/m40a1/handling/m40a1_boltback.wav"
FAS_RS["Weapon_m40a1.BoltLatch"] = "weapons/m40a1/handling/m40a1_boltlatch.wav"
FAS_RS["Weapon_m40a1.Boltforward"] = "weapons/m40a1/handling/m40a1_boltforward.wav"
FAS_RS["Weapon_m40a1.Empty"] = "weapons/m40a1/handling/m40a1_empty.wav"
FAS_RS["Weapon_M40A1.Roundin"] = "weapons/m40a1/handling/m40a1_bulletin_1.wav"
FAS_RS["Universal.Draw"] = "weapons/universal/uni_pistol_draw_01.wav" 
FAS_RS["Universal.Holster"] = "weapons/universal/uni_pistol_holster.wav" 
FAS_RS["Weapon_AK74.Empty"] = "weapons/ak74/handling/ak74_empty.wav"
FAS_RS["Weapon_AK74.ROF"] = "weapons/ak74/handling/ak74_fireselect_1.wav"
FAS_RS["Weapon_AK74.MagRelease"] = "weapons/ak74/handling/ak74_magrelease.wav"
FAS_RS["Weapon_AK74.Magout"] = "weapons/ak74/handling/ak74_magout.wav"
FAS_RS["Weapon_AK74.MagoutRattle"] = "weapons/ak74/handling/ak74_magout_rattle.wav"
FAS_RS["Weapon_AK74.Magin"] = "weapons/ak74/handling/ak74_magin.wav"
FAS_RS["Weapon_AK74.Rattle"] = "weapons/ak74/handling/ak74_rattle.wav"
FAS_RS["Weapon_AK74.Boltback"] = "weapons/ak74/handling/ak74_boltback.wav"
FAS_RS["Weapon_AK74.Boltrelease"] = "weapons/ak74/handling/ak74_boltrelease.wav"
FAS_RS["Weapon_MP7.MagOut"] = "weapons/mp7/handling/mp7_magout.wav"
FAS_RS["Weapon_MP7.MagIn"] = "weapons/mp7/handling/mp7_magin.wav"
FAS_RS["Weapon_MP7.MagRelease"] = "weapons/mp7/handling/mp7_magrelease.wav"
FAS_RS["Weapon_MP7.BoltLock"] = "weapons/mp7/handling/mp7_boltlock.wav"
FAS_RS["Weapon_MP7.BoltRelease"] = "weapons/mp7/handling/mp7_boltrelease.wav"
FAS_RS["Weapon_MP7.BoltBack"] = "weapons/mp7/handling/mp7_boltback.wav"
FAS_RS["Weapon_MP7.Empty"] = "weapons/mp7/handling/mp7_empty.wav"
FAS_RS["Weapon_DEAGLE.MagOut"] = "weapons/deserteagle/de_magout.wav"
FAS_RS["Weapon_DEAGLE.MagOutEmpty"] = "weapons/deserteagle/de_magout_empty.wav"
FAS_RS["Weapon_DEAGLE.MagIn"] = "weapons/deserteagle/de_magin.wav"
FAS_RS["Weapon_DEAGLE.MagInPartial"] = "weapons/deserteagle/de_magin_partial.wav"
FAS_RS["Weapon_DEAGLE.MagInNomen"] = "weapons/deserteagle/de_magin_nomen.wav"
FAS_RS["Weapon_DEAGLE.SlideStop"] = "weapons/deserteagle/de_sliderelease.wav"

local tbl = {channel = CHAN_STATIC,
	volume = 1,
	level = 65,
	pitchstart = 100,
	pitchend = 100}

for k, v in pairs(FAS_RS) do
	tbl.name = k
	tbl.sound = v
		
	sadd(tbl)
	
	if type(v) == "table" then
		for k2, v2 in pairs(v) do
			ups(v2)
		end
	else
		ups(v)
	end
end	

local FAS_FS = {}
FAS_FS["Weapon.COAR2.Fire"] = "weapons/coirifle/fire1.wav"
FAS_FS["Weapon.COAR2.Empty"] = "weapons/coirifle/ar2_empty.wav"
FAS_FS["Weapon.UspMatch.Fire"] = "weapons/uspmatch/usp_fire.wav"
FAS_FS["Weapon_AK74.Fire"] = "weapons/ak74/ak74_fp.wav"
FAS_FS["Weapon_M9.Fire"] = "weapons/m9/m9_fp.wav"
FAS_FS["Weapon_M40A1.Fire"] = "weapons/m40a1/m40a1_fp.wav"
FAS_FS["Weapon_MP7.Fire"] = "weapons/mp7/mp7_fp.wav"
FAS_FS["Weapon_DEAGLE.Fire"] = "weapons/deserteagle/de_fire1.wav"

local FAS_FSS = {}
FAS_FSS["Weapon_M9.FireSupp"] = "weapons/m9/m9_suppressed_fp.wav"
FAS_FSS["Weapon_M40A1.FireSupp"] = "weapons/m40a1/m40a1_suppressed_fp.wav"
FAS_FSS["Weapon_AK74.FireSupp"] = "weapons/ak74/ak74_suppressed_fp.wav"
FAS_FSS["Weapon_MP7.FireSupp"] = "weapons/mp7/mp7_suppressed_fp.wav"
local tbl = {channel = CHAN_STATIC,
	volume = 1,
	level = 100,
	pitchstart = 92,
	pitchend = 112}

for k, v in pairs(FAS_FS) do
	tbl.name = k
	tbl.sound = v
		
	sadd(tbl)
	
	if type(v) == "table" then
		for k2, v2 in pairs(v) do
			ups(v2)
		end
	else
		ups(v)
	end
end	

local tbl = {channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitchstart = 92,
	pitchend = 112}

for k, v in pairs(FAS_FSS) do
	tbl.name = k
	tbl.sound = v
		
	sadd(tbl)
	
	if type(v) == "table" then
		for k2, v2 in pairs(v) do
			ups(v2)
		end
	else
		ups(v)
	end
end	

local ply, vm
function SXBASE_PlayAnim(wep, anim, speed, cyc, time)
	speed = speed and speed or 1
	cyc = cyc and cyc or 0
	time = time or 0

	if type(anim) == "table" then
		anim = table.Random(anim)
	end

	if wep.Sounds[anim] then
		wep.CurSoundTable = wep.Sounds[anim]
		wep.CurSoundEntry = 1
		wep.SoundSpeed = speed
		wep.SoundTime = CurTime() + time
	end

	--[[if SERVER then
		ply = wep.Owner
		if ply then
			umsg.Start("SXBASEANIM", ply)
				umsg.String(anim)
				umsg.Float(speed)
				umsg.Float(cyc)
				umsg.Entity(wep)
			umsg.End()
		end
	end]]
		
	if CLIENT then
		vm = wep.ViewModelEnt
		
		wep.CurAnim = string.lower(anim)
		
		if vm then
			vm:SetCycle(cyc)
			vm:SetSequence(anim)
			vm:SetPlaybackRate(speed)
		end
	end
end

function SXBASE_Move(p, m)
	if p:Alive() then
		wep = p:GetActiveWeapon()
		
		if IsValid(wep) then
			if wep.IsSXBASEWeapon then
				if not p:KeyDown(IN_SPEED) then
					if wep.dt.Status == FAS_STAT_ADS then
						if p:Crouching() then
							m:SetMaxSpeed(p:GetWalkSpeed() * p:GetCrouchedWalkSpeed())
						else
							m:SetMaxSpeed(p:GetWalkSpeed() * 0.7)
						end
					end
				end
			end
		end
	end
end
hook.Add("Move", "SXBASE_Move", SXBASE_Move)

--[[SXBASE_Attachments = {}

function SXBASE_AddAttachment(t)
	SXBASE_Attachments[t.key] = {key = t.key, nameshort = t.nameshort, namefull = t.namefull, namemenu = t.namemenu, aimpos = t.aimpos, aimang = t.aimang, attfunc = t.attfunc, deattfunc = t.deattfunc, displaytexture = t.displaytexture, desc = t.desc, clattfunc = t.clattfunc, cldeattfunc = t.cldeattfunc}
	
	if SERVER then
		CreateConVar("sxbase_att_" .. t.key, "0",  {FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_NOTIFY})
		FAS2AutoAtt["sxbase_att_" .. t.key] = t.key
	else
		CreateClientConVar("sxbase_att_" .. t.key .. "_cl", "0", true, true)
	end
end

tbl = {}

tbl.key = "suppressor"
tbl.nameshort = "Suppress"
tbl.namefull = "Suppressor"
tbl.desc = {[1] = {t = "Decreases firing noise.", c = Color(202, 255, 163, 255)},
	[2] = {t = "Decreases recoil by 15%", c = Color(202, 255, 163, 255)},
	[3] = {t = "Decreases damage by 10%", c = Color(255, 137, 119, 255)}}

if CLIENT then
	tbl.displaytexture = surface.GetTextureID("VGUI/fas2atts/suppressor")
end

tbl.attfunc = function(ply, wep)
	wep.dt.Suppressed = true
	wep.Recoil = wep.Recoil * 0.85
	wep.ViewKick = wep.ViewKick * 0.85
	wep.Damage = math.Round(wep.Damage * 0.9, 0)
end

tbl.clattfunc = function(ply, wep)
	wep.Recoil = wep.Recoil * 0.85
	wep.ViewKick = wep.ViewKick * 0.85
	wep.Damage = math.Round(wep.Damage * 0.9, 0)
end

tbl.deattfunc = function(ply, wep)
	wep.dt.Suppressed = false
	wep.Recoil = wep.Recoil / 0.85
	wep.ViewKick = wep.ViewKick / 0.85
	wep.Damage = math.Round(wep.Damage / 0.9, 0)
end

tbl.cldeattfunc = function(ply, wep)
	wep.Recoil = wep.Recoil / 0.85
	wep.ViewKick = wep.ViewKick / 0.85
	wep.Damage = math.Round(wep.Damage / 0.9, 0)
end

SXBASE_AddAttachment(tbl)
--]]

if CLIENT then
	--[[local function SXBASE_NoAttachments()
		SXBASEAttOnMe = {}
	end

	usermessage.Hook("SXBASE_NOATTS", SXBASE_NoAttachments)
	
	net.Receive("SXBASE_SENDATTACHMENTS", function(l, c)
		SXBASEAttOnMe = net.ReadTable()
	end)]]

	//local ADSR = {a = 0, d = 0, s = 0, r = 0, current = 0, target = 0, time = 0, state = 4} 
	local SXBASERecoil = {amt = 0, target = 0, rate = 0, delay = 0}
	CreateClientConVar("sxbase_nohud", "0", true, true)
	CreateClientConVar("sxbase_customhud", "1", true, true)
	CreateClientConVar("sxbase_differentorigins", "0", true, true)
	CreateClientConVar("sxbase_handrig", "0", true, true)
	CreateClientConVar("sxbase_holdtoaim", "0", true, true)
	CreateClientConVar("sxbase_alternatebipod", "1", true, true)
	CreateClientConVar("sxbase_handskin", "1", true, true)
	CreateClientConVar("sxbase_gloveskin", "1", true, true)
	CreateClientConVar("sxbase_sleeveskin", "1", true, true)
	CreateClientConVar("sxbase_headbob_intensity", "1", true, true)
	CreateClientConVar("sxbase_textsize", "1", true, true)

	SXBASEShells = {}
	SXBASEShells["9x19"] = {m = "models/shells/9x19mm.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	SXBASEShells["9x18"] = {m = "models/shells/9x18mm.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	SXBASEShells["smg1"] = {m = "models/weapons/shell.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	SXBASEShells["buckshot"] = {m = "models/weapons/shotgun_shell.mdl", s = {"weapons/fx/tink/shotgun_shell1.wav", "weapons/fx/tink/shotgun_shell2.wav", "weapons/fx/tink/shotgun_shell3.wav"}}
	SXBASEShells["7.62x51"] = {m = "models/shells/7_62x51mm.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	SXBASEShells["5.45x39"] = {m = "models/shells/5_45x39mm.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	SXBASEShells["50ae"] = {m = "models/shells/50ae.mdl", s = {"player/pl_shell1.wav", "player/pl_shell2.wav", "player/pl_shell3.wav"}}
	
	function SXBASE_MakeFakeShell(shell, pos, ang, vel, time, removetime)
		if not shell or not pos or not ang then
			return
		end
		
		local t = SXBASEShells[shell]
		
		if not t then
			return
		end
		
		vel = vel or Vector(0, 0, -100)
		vel = vel + VectorRand() * 5
		time = time or 0.5
		removetime = removetime or 5
		
		local ent = ClientsideModel(t.m, RENDERGROUP_BOTH) 
		ent:SetPos(pos)
		ent:PhysicsInitBox(Vector(-0.5, -0.15, -0.5), Vector(0.5, 0.15, 0.5))
		ent:SetAngles(ang)
		ent:SetMoveType(MOVETYPE_VPHYSICS) 
		ent:SetSolid(SOLID_VPHYSICS) 
		ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		
		local phys = ent:GetPhysicsObject()
		phys:SetMaterial("gmod_silent")
		phys:SetMass(10)
		phys:SetVelocity(vel)
		
		timer.Simple(time, function()
			if t.s then
				ent:EmitSound(table.Random(t.s), 35, 100)
			end
		end)
		
		SafeRemoveEntityDelayed(ent, removetime)
	end
	
	local function SXBase_InitPostEntity()
		ply = LocalPlayer()
		
		for k, v in pairs(weapons.GetList()) do
			if v.VM then
				util.PrecacheModel(v.VM)
			end
		end
		
		for k, v in pairs(SXBASEShells) do
			util.PrecacheModel(v.m)
		end
	end
	hook.Add("InitPostEntity", "SXBase_InitPostEntity", SXBase_InitPostEntity)

	local function SXBase_HUDShouldDraw(n)
		if GetConVarNumber("sxbase_customhud") > 0 then
			ply = LocalPlayer()
			
			if IsValid(ply) and ply:Alive() then
				wep = ply:GetActiveWeapon()
				
				if IsValid(wep) and wep.IsSXBASEWeapon then
					if n == "CHudAmmo" or n == "CHudSecondaryAmmo" then
						return false
					end
				end
			end
		end
	end
	hook.Add("HUDShouldDraw", "SXBase_HUDShouldDraw", SXBase_HUDShouldDraw)
	
	local function SXBASE_RenderScene()
		ply = LocalPlayer()
		wep = ply:GetActiveWeapon()
		
		if IsValid(wep) and wep.IsSXBASEWeapon and wep.DrawRenderTarget then
			wep:DrawRenderTarget()
		end
	end
	hook.Add("RenderScene", "SXBASE_RenderScene", SXBASE_RenderScene)
	
	local EA, dif
	local function SXBASE_CreateMove(c)
		ang = c:GetViewAngles()
		CT = CurTime()
		
		ply = LocalPlayer()
		wep = ply:GetActiveWeapon()
		
		if IsValid(wep) and wep.IsSXBASEWeapon then
			if wep.dt.Bipod and wep.DeployAngle then
				EA = ply:EyeAngles()
				dif = math.AngleDifference(EA.y, wep.DeployAngle.y)
				
				if dif >= wep.BipodAngleLimitYaw then
					ang.y = wep.DeployAngle.y + wep.BipodAngleLimitYaw
				elseif dif <= -wep.BipodAngleLimitYaw then
					ang.y = wep.DeployAngle.y - wep.BipodAngleLimitYaw
				end
				
				dif = math.AngleDifference(EA.p, wep.DeployAngle.p)
				
				if dif >= wep.BipodAngleLimitPitch then
					ang.p = wep.DeployAngle.p + wep.BipodAngleLimitPitch
				elseif dif <= -wep.BipodAngleLimitPitch then
					ang.p = wep.DeployAngle.p - wep.BipodAngleLimitPitch
				end

				c:SetViewAngles(ang)
			end
		end
	end
	hook.Add("CreateMove", "SXBASE_CreateMove", SXBASE_CreateMove)
	
	
	local PLY = debug.getregistry().Player
	local found
	function PLY:HasWeapon(s)
		found = false
		
		for k, v in pairs(self:GetWeapons()) do
			if v:GetClass() == s then
				found = true
				break
			end
		end
		
		return found
	end
end

function AddAmmoType(name, text)
	game.AddAmmoType({name = name,
	dmgtype = DMG_BULLET})
	
	if CLIENT then
		language.Add(name .. "_ammo", text)
	end
end

AddAmmoType("9x19MM", "9x19MM Ammo")
AddAmmoType("9x18MM", "9x18MM Ammo")
AddAmmoType("10x25MM", "10x25MM Ammo")
AddAmmoType("7.62x51MM", "7.62x51MM Ammo")
AddAmmoType("7.62x54MMR", "7.62x54MMR Ammo")
AddAmmoType("5.56x45MM", "5.56x45MM Ammo")
AddAmmoType("5.45x39MM", "5.45x39MM Ammo")
AddAmmoType("7.62x39MM", "7.62x39MM Ammo")
AddAmmoType(".357 SIG", ".357 SIG Ammo")
AddAmmoType(".380 ACP", ".380 ACP Ammo")
AddAmmoType(".45 ACP", ".45 ACP Ammo")
AddAmmoType(".44 Magnum", ".44 Magnum Ammo")
AddAmmoType(".454 Casull", ".454 Casull Ammo")
AddAmmoType(".50 AE", ".50 AE Ammo")
AddAmmoType(".50 BMG", ".50 BMG Ammo")
AddAmmoType("12 Gauge", "12 Gauge Ammo")
AddAmmoType("23x75MMR", "23x75MMR Ammo")

AddAmmoType("40MM HE", "40MM HE Ammo")
AddAmmoType("40MM Smoke", "40MM Smoke Ammo")
AddAmmoType("M67 Grenades", "M67 Grenades")
AddAmmoType("Ammoboxes", "Ammoboxes")

AddAmmoType("Bandages", "Bandages")
AddAmmoType("Quikclots", "Quikclots")
AddAmmoType("Hemostats", "Hemostats")

game.BuildAmmoTypes()