local function SXBASE_ClientsidePanel(panel)
	panel:ClearControls()
	
	panel:AddControl("Label", {Text = "Control"})
	panel:AddControl("CheckBox", {Label = "Disable HUD elements?", Command = "sxbase_nohud"})
	panel:AddControl("CheckBox", {Label = "Use hold-to-aim?", Command = "sxbase_holdtoaim"})
end

local function SXBASE_PopulateToolMenu()
	spawnmenu.AddToolMenuOption("Utilities", "SXBASE SWEPs", "SXBASE Client", "Client", "", "", SXBASE_ClientsidePanel)
end

hook.Add("PopulateToolMenu", "SXBASE_PopulateToolMenu", SXBASE_PopulateToolMenu)