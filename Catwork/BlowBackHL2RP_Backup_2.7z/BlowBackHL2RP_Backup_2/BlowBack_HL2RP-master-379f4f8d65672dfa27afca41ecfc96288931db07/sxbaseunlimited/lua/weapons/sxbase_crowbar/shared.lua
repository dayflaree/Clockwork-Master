﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "Crowbar"
    SWEP.Slot = 0
    SWEP.SlotPos = 3
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3.082,-8,0.85)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.SprintPos = Vector(1, -10, 5)
	SWEP.SprintAng = Vector(0, 0, 10)
	SWEP.MoveType = 2
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.NoShowAimCrossshair = true

	SWEP.RifleSafePos = Vector(0.324, -3, -0.621)
	SWEP.RifleSafeAng = Vector(-20, 5, -24)
end

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Hit = {"hitcenter1", "hitcenter2", "hitcenter3"}
SWEP.Anims.Hit_miss = {"misscenter1", "misscenter2"}
SWEP.Anims.Idle = "idle01"

SWEP.Sounds = {}

SWEP.FireModes = {"auto"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Instructions = "Primary Fire: Swing attack."
SWEP.Purpose = "A crowbar."
SWEP.Contact = ""
SWEP.Author	= "SchwarzKruppzo"
SWEP.HoldType = "melee"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 85
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_crowbar.mdl"
SWEP.WM = "models/weapons/w_crowbar.mdl"
SWEP.WorldModel   = "models/weapons/w_crowbar.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = -1
SWEP.Primary.DefaultClip    = -1
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = ""
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.5

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.12
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon.UspMatch.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.035
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.035
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.75
SWEP.Recoil = 0.6

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.IsHL2Melee = true

local vm, t, a
local SP = game.SinglePlayer()
local reg = debug.getregistry()
local GetVelocity = reg.Entity.GetVelocity
local Length = reg.Vector.Length
local GetAimVector = reg.Player.GetAimVector

function SWEP:DoHitEffects()
	self:EmitSound("weapons/iceaxe/iceaxe_swing1.wav")
	local trace = {}
	trace.start = self.Owner:GetShootPos()
	trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 82
	trace.maxs = Vector(3,3,3)
	trace.mins = Vector(-1,-1,-1)
	trace.filter = self.Owner
	local trace = util.TraceHull( trace )

		
	if ( (trace.Hit or trace.HitWorld) and self.Owner:GetPos():Distance(trace.HitPos) <= 82 ) then
		SXBASE_PlayAnim(self, self.Anims.Hit, 1)
		if IsValid(trace.Entity) and ( trace.Entity:IsPlayer() or trace.Entity:IsNPC() ) then
			local effectData = EffectData()
			effectData:SetStart(trace.HitPos)
			effectData:SetOrigin(trace.HitPos)
			effectData:SetNormal(trace.HitNormal)
			util.Effect("BloodImpact", effectData, true, true)
		elseif IsValid(trace.Entity) and Clockwork.entity:GetPlayer(trace.Entity) then
			local effectData = EffectData()
			effectData:SetStart(trace.HitPos)
			effectData:SetOrigin(trace.HitPos)
			effectData:SetNormal(trace.HitNormal)
			util.Effect("BloodImpact", effectData, true, true)
		end
		self.Owner:FireBullets({
			Attacker = nil,
			Callback = nil,
			Damage = 0,
			Force = 0,
			Distance = 82,
			Tracer = 0,
			Src = trace.HitPos,
			Dir = -trace.HitNormal,
		})
	else
		SXBASE_PlayAnim(self, self.Anims.Hit_miss, 1)
		self.NextResetIdle = CurTime() + 0.6
	end
end

function SWEP:Think()
	cr = self.Owner:Crouching()
	CT, vel = CurTime(), Length(GetVelocity(self.Owner))
	
	if (SP and SERVER) or not SP then -- if it's SP, then we run it only on the server (otherwise shit gets fucked); if it's MP we predict it
		if self.dt.Bipod or self.DeployAngle then
			if not self:CanDeployBipod() then
				self.dt.Bipod = false
				self.DeployAngle = nil
				
				if not self.ReloadDelay then
					if CT > self.BipodDelay then
						self:PlayBipodUnDeployAnim()
						self.BipodDelay = CT + self.BipodUndeployTime
						self:SetNextPrimaryFire(CT + self.BipodUndeployTime)
						self:SetNextSecondaryFire(CT + self.BipodUndeployTime)
						self.ReloadWait = CT + self.BipodUndeployTime
					else
						self.BipodUnDeployPost = true
					end
				else
					self.BipodUnDeployPost = true
				end
			end
		end
	end

	if self.dt.Status != FAS_STAT_HOLSTER_START and self.dt.Status != FAS_STAT_HOLSTER_END and self.dt.Status != FAS_STAT_QUICKGRENADE then
		if self.Owner:OnGround() then
			if self.Owner:KeyDown(IN_SPEED) and vel >= self.Owner:GetWalkSpeed() * 1.3 then
				if self.dt.Status != FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_SPRINT
				end
			else
				if self.dt.Status == FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_IDLE
					
					if CT > self.SprintDelay and not self.ReloadDelay then
						self:SetNextPrimaryFire(CT + 0.2)
						self:SetNextSecondaryFire(CT + 0.2)
					end
				end
			end
		else
			if self.dt.Status != FAS_STAT_IDLE then
				self.dt.Status = FAS_STAT_IDLE
				
				if CT > self.SprintDelay and not self.ReloadDelay then
					self:SetNextPrimaryFire(CT + 0.2)
					self:SetNextSecondaryFire(CT + 0.2)
				end
			end
		end
	end

	if self.NextResetIdle and CT > self.NextResetIdle then
		SXBASE_PlayAnim(self, self.Anims.Idle)
		self.NextResetIdle = nil
	end

	if self.CurSoundTable then
		t = self.CurSoundTable[self.CurSoundEntry]
		
		if CLIENT then
			if self.ViewModelEnt:SequenceDuration() * self.ViewModelEnt:GetCycle() >= t.time / self.SoundSpeed then
				self:EmitSound(t.sound, 70, 100)
				
				if self.CurSoundTable[self.CurSoundEntry + 1] then
					self.CurSoundEntry = self.CurSoundEntry + 1
				else
					self.CurSoundTable = nil
					self.CurSoundEntry = nil
					self.SoundTime = nil
				end
			end
		else
			if CT >= self.SoundTime + t.time / self.SoundSpeed then
				self:EmitSound(t.sound, 70, 100)
				
				if self.CurSoundTable[self.CurSoundEntry + 1] then
					self.CurSoundEntry = self.CurSoundEntry + 1
				else
					self.CurSoundTable = nil
					self.CurSoundEntry = nil
					self.SoundTime = nil
				end
			end
		end
	end

	for k, v in pairs(self.Events) do
		if CT > v.time then
			v.func()
			table.remove(self.Events, k)
		end
	end
end

local td, CT = {}, nil
function SWEP:PrimaryAttack()
	if not IsFirstTimePredicted() then
		return
	end

	if self.Cooking or self.FuseTime then
		return
	end

	if self.FireMode == "safe" then
		if IsFirstTimePredicted() then
			self:CycleFiremodes()
		end
		
		return
	end

	td.start = self.Owner:GetShootPos()
	td.endpos = td.start + self.Owner:GetAimVector() * 30
	td.filter = self.Owner
			
	tr = util.TraceLine(td)
		
	if tr.Hit then
		return
	end
		
	CT = CurTime() 

	self:SetNextPrimaryFire(CT + 0.45)
	self:SetNextSecondaryFire(CT + 0.45)
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	if SERVER then
		if self.Owner.LagCompensation then
			self.Owner:LagCompensation(true)
		end
		self:CallOnClient("DoHitEffects")
		local trace = {} //self.Owner:GetEyeTraceNoCursor();
		trace.start = self.Owner:GetShootPos()
		trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 82
		trace.maxs = Vector(3,3,3)
		trace.mins = Vector(-1,-1,-1)
		trace.filter = self.Owner
		local trace = util.TraceHull( trace )
		if (self.Owner:GetShootPos():Distance(trace.HitPos) <= 82) then
			if (IsValid(trace.Entity)) then
				local player = Clockwork.entity:GetPlayer(trace.Entity);
				local strength = Clockwork.attributes:Fraction(self.Owner, ATB_STRENGTH, 3, 1.5);
					
				if (trace.Entity:IsPlayer() or trace.Entity:IsNPC()) then
					local normal = ( trace.Entity:GetPos() - self.Owner:GetPos() ):GetNormal();
					local push = 64 * normal;
						
					trace.Entity:SetVelocity(push);
						
					trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(math.random(10,15) + (strength * 3), self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
				elseif (IsValid( trace.Entity:GetPhysicsObject() )) then
					trace.Entity:GetPhysicsObject():ApplyForceOffset(self.Owner:GetAimVector() * 150, trace.HitPos);
						
					trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(math.random(10,15) + (strength * 2), self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
				end
			end
		end
		if self.Owner.LagCompensation then
			self.Owner:LagCompensation(false)
		end
	end
	self.dt.Status = FAS_STAT_IDLE
end

function SWEP:SecondaryAttack()
end