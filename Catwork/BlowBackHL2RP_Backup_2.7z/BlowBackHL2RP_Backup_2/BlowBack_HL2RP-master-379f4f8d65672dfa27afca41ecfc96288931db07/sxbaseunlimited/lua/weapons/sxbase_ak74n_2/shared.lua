if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "AK-74N w/ Foregrip & Aimpoint & Suppressor"
    SWEP.Slot = 3
    SWEP.SlotPos = 4
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-2.315,-4,-0.5)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = "5.45x39"
	SWEP.ShellEjector = "shell"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = false
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.PitchMod = 0.3
	SWEP.YawMod = 0.3

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "5.45x39мм"

	SWEP.VModels = {
		["foregrip"] = { model = "models/weapons/attachments/a_foregrip_ak74n.mdl", ent = NULL },
		["eotech"] = { model = "models/weapons/attachments/a_optic_aimpoint.mdl", ent = NULL },
		["suppressor"] = { model = "models/weapons/attachments/a_suppressor_ak.mdl", ent = NULL },
	}
end

SWEP.MuzzleEffect = nil
SWEP.MuzzleLight = Color(0,0,0)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_AK74.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "foregrip_draw"
SWEP.Anims.Draw = "foregrip_draw"
SWEP.Anims.Holster = "foregrip_holster"
SWEP.Anims.Fire = "foregrip_fire"
SWEP.Anims.Fire_Aiming = "foregrip_iron_fire"
SWEP.Anims.Idle = "foregrip_idle"
SWEP.Anims.Idle_Aim = "foregrip_idle"
SWEP.Anims.Reload = "foregrip_reload"
SWEP.Anims.Reload_Empty = "foregrip_reloadempty"

SWEP.Sounds = {}
SWEP.Sounds["foregrip_draw"] = {
	[1] = {time = 0, sound = Sound( "Universal.Draw" )},
}
SWEP.Sounds["foregrip_holster"] = {
	[1] = {time = 0, sound = Sound( "Universal.Holster" )},
}
SWEP.Sounds["foregrip_reload"] = {
	[1] = {time = 0.566, sound = Sound( "Weapon_AK74.MagRelease" )},
	[2] = {time = 0.666, sound = Sound( "Weapon_AK74.Magout" )},
	[3] = {time = 0.966, sound = Sound( "Weapon_AK74.MagoutRattle" )},
	[4] = {time = 2.1, sound = Sound( "Weapon_AK74.Magin" )},
	[5] = {time = 2.666, sound = Sound( "Weapon_AK74.Rattle" )},
}
SWEP.Sounds["foregrip_reloadempty"] = {
	[1] = {time = 0.566, sound = Sound( "Weapon_AK74.MagRelease" )},
	[2] = {time = 0.666, sound = Sound( "Weapon_AK74.Magout" )},
	[3] = {time = 0.966, sound = Sound( "Weapon_AK74.MagoutRattle" )},
	[4] = {time = 2.1, sound = Sound( "Weapon_AK74.Magin" )},
	[5] = {time = 2.666, sound = Sound( "Weapon_AK74.Rattle" )},
	[6] = {time = 3.2, sound = Sound( "Weapon_AK74.Boltback" )},
	[7] = {time = 3.4, sound = Sound( "Weapon_AK74.Boltrelease" )},
}

SWEP.FireModes = {"semi","auto"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "smg"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_ak74n.mdl"
SWEP.WM = "models/weapons/w_ak74n_2.mdl"
SWEP.WorldModel   = "models/weapons/w_ak74n_2.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 30
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "5.45x39MM"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.5
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.1
SWEP.Damage = 21
SWEP.FireSound = Sound( "Weapon_AK74.FireSupp" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.030
SWEP.AimCone = 0.003
SWEP.SpreadPerShot = 0.007
SWEP.MaxSpreadInc = 0.03
SWEP.SpreadCooldown = 0.18
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.6
SWEP.Recoil = 0.5

-- Reload related
SWEP.ReloadTime = 1.4
SWEP.ReloadTime_Empty = 1.4
SWEP.SilencedGun = true

function SWEP:getDifferenceToAimPos(pos, ang, vertDependance, horDependance, dependMod)
	dependMod = dependMod or 1
	vertDependance = vertDependance or 1
	horDependance = horDependance or 1
	
	local sway = (self.AngleDelta.p * 0.65 * vertDependance + self.AngleDelta.y * 0.75 * horDependance) * 0.05 * dependMod
	local pos = self.BlendPos - pos
	local ang = self.BlendAng/20 - ang
	ang.z = 0
	
	pos = pos:Length()
	ang = math.abs(ang:Length())

	local dependance = pos + ang
	
	return 1 - dependance
end

local displayIcon = Material("models/weapons/optics/aimpoint_reticule_holo")
function SWEP:reticleDraw( vm )
	local diff = self:getDifferenceToAimPos(self.AimPos, self.AimAng, 1)

	if diff > 0.3 and diff < 1.3 then
		cam.IgnoreZ(true)
			render.SetMaterial(displayIcon)
			local dist = math.Clamp(math.Distance(1, 1, diff, diff), 0, 0.5)
					
			local EA = self.Owner:EyeAngles() + self.Owner:GetPunchAngle()
					
			local renderColor = Color(255,180,180)
			renderColor.a = (0.5 - dist) / 0.5 * 255

			local pos = EyePos() + EA:Forward() * 100
					
			for i = 1, 2 do
				render.DrawSprite(pos, 1.25, 1.25, renderColor)
			end
		cam.IgnoreZ(false)
	end
end
