if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "Combine Overwatch Impulse Rifle Mk.2"
    SWEP.Slot = 3
    SWEP.SlotPos = 0
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3,-2,0.4)
	SWEP.AimAng = Vector(0.264, 0, 0)
	
	SWEP.SprintPos = Vector(2, 0, 0)
	SWEP.SprintAng = Vector(-10, 8, 0)
	
	SWEP.Shell = ""
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobOffset = Angle(0,0,90)
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = true

	SWEP.MagText = "ЗАРЯД: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "Impulse Energy Cell"
end
SWEP.MuzzleEffect = "muzzleflash_ar2"
SWEP.MuzzleLight = Color(0,150,255)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon.COAR2.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "ir_draw"
SWEP.Anims.Draw = "ir_draw"
SWEP.Anims.Holster = "ir_holster"
SWEP.Anims.Fire = "ir_fire"
SWEP.Anims.Fire_Aiming = "ir_fire"
SWEP.Anims.Idle = "ir_idle"
SWEP.Anims.Idle_Aim = "ir_idle"
SWEP.Anims.Reload = "ir_reload"
SWEP.Anims.Reload_Nomen = "ir_reload"
SWEP.Anims.Reload_Empty = "ir_reload"
SWEP.Anims.Reload_Empty_Nomen = "ir_reload"

SWEP.Sounds = {}
SWEP.Sounds["ir_reload"] = {
	[1] = {time = 0, sound = Sound( "Weapon.COAR2.Reload" )},
	[2] = {time = 0.1, sound = Sound( "Weapon.COAR2.Rotate" )},
	[3] = {time = 0.6, sound = Sound( "Weapon.COAR2.Push" )}
}

SWEP.FireModes = {"semi","auto","3burst"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""

SWEP.ViewModelFOV    = 60
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_ar2.mdl"
SWEP.WM = "models/weapons/w_ar2.mdl"
SWEP.WorldModel   = "models/weapons/w_ar2.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 50
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "AR2"
SWEP.Primary.TracerName         = "AR2Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.1
SWEP.Damage = 20
SWEP.FireSound = Sound( "Weapon.COAR2.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.03
SWEP.AimCone = 0.005
SWEP.SpreadPerShot = 0.003
SWEP.MaxSpreadInc = 0.05
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.1
SWEP.AimFOV = 15

-- Recoil related
SWEP.ViewKick = 0.7
SWEP.Recoil = 0.7

-- Reload related
SWEP.ReloadTime = 1.3
SWEP.ReloadTime_Nomen = 1.3
SWEP.ReloadTime_Empty = 1.3
SWEP.ReloadTime_Empty_Nomen = 1.3