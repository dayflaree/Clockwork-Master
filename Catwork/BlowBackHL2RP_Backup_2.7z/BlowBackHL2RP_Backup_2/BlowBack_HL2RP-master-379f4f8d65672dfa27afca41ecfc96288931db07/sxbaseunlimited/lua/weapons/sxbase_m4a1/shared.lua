if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
    SWEP.PrintName = "M4A1"
    SWEP.Slot = 3
    SWEP.SlotPos = 0
	
	SWEP.AimPos = Vector(-2.044, -4.2, 0.446)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DSize = 0.01
	SWEP.Text3DRight = -2
	SWEP.Text3DForward = -5
	SWEP.AmmoText = "5.56x45мм"
	
	SWEP.ReloadBobDisabled = false
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false
	
	SWEP.Shell = "5.56x45"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)
	
	SWEP.HideWorldModel = true
end
SWEP.MuzzleEffect = "muzzleflash_6"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleOffset = -10
SWEP.MuzzleWorldID = 1

SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.56
SWEP.CaseLength = 45
SWEP.EmptySound = Sound("weapons/empty_assaultrifles.wav")

SWEP.Anims = {}
SWEP.Anims.Draw_First = "deploy_first"
SWEP.Anims.Draw = "deploy"
SWEP.Anims.Draw_Empty = "deploy_empty"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster_empty"
SWEP.Anims.Fire = {"shoot", "shoot2", "shoot3"}
SWEP.Anims.Fire_Last = "shoot_last"
SWEP.Anims.Fire_Aiming = {"shoot1_scoped", "shoot2_scoped", "shoot3_scoped"}
SWEP.Anims.Fire_Aiming_Last = "shoot_last_scoped"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Idle_Aim = "idle_scoped"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Nomen = "reload_nomen"
SWEP.Anims.Reload_Empty = "reload_empty"
SWEP.Anims.Reload_Empty_Nomen = "reload_empty_nomen"

SWEP.Sounds = {}

SWEP.Sounds["deploy_first"] = {[1] = {time = 0.9, sound = Sound("Weapon_M4A1.StockPull")},
	[2] = {time = 1.5, sound = Sound("Weapon_M4A1.ChargeBack")},
	[3] = {time = 1.65, sound = Sound("Weapon_M4A1.ReleaseHandle")},
	[4] = {time = 2.2, sound = Sound("Weapon_M4A1.Check")},
	[5] = {time = 3.6, sound = Sound("Weapon_M4A1.Forwardassist")},
	[6] = {time = 4.05, sound = Sound("Weapon_M4A1.DustCover")},
	[7] = {time = 4.8, sound = Sound("Weapon_M4A1.Switch")}}
	
SWEP.Sounds["reload"] = {[1] = {time = 0.7, sound = Sound("Weapon_M4A1.Magout")},
	[2] = {time = 1.5, sound = Sound("MagPouch_AR")},
	[3] = {time = 2.05, sound = Sound("Weapon_M4A1.Magin")}}
	
SWEP.Sounds["reload_nomen"] = {[1] = {time = 0.3, sound = Sound("MagPouch_AR")},
	[2] = {time = 0.8, sound = Sound("Weapon_M4A1.Magout")},
	[3] = {time = 1.1, sound = Sound("Weapon_M4A1.Magin")}}
	
SWEP.Sounds["reload_empty"] = {[1] = {time = 0.7, sound = Sound("Weapon_M4A1.MagoutEmpty")},
	[2] = {time = 1.15, sound = Sound("MagPouch_AR")},
	[3] = {time = 1.7, sound = Sound("Weapon_M4A1.Magin")},
	[4] = {time = 2.3, sound = Sound("Weapon_M4A1.Boltcatch")}}
	
SWEP.Sounds["reload_empty_nomen"] = {[1] = {time = 0.4, sound = Sound("MagPouch_AR")},
	[2] = {time = 0.7, sound = Sound("Weapon_M4A1.MagoutEmpty")},
	[3] = {time = 1.1, sound = Sound("Weapon_M4A1.Magin")},
	[4] = {time = 1.6, sound = Sound("Weapon_M4A1.Boltcatch")}}
	
SWEP.FireModes = {"auto", "3burst", "semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "AleXXX_007"
SWEP.Instructions    = ""
SWEP.Contact        = ""
SWEP.Purpose        = ""

SWEP.ViewModelFOV    = 70
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/view/rifles/m4a1.mdl"
SWEP.WM = "models/weapons/w_m4.mdl"
SWEP.WorldModel   = "models/weapons/w_rif_m4a1.mdl"
SWEP.HoldType = "smg"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 30
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "5.56x45MM"
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 5.3
SWEP.DeployTime = 0.6
SWEP.DeployAnimSpeed = 0.7
SWEP.HolsterTime = 0.3

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.0666
SWEP.Damage = 27
SWEP.FireSound = Sound("FAS2_M4A1")
SWEP.FireSound_Suppressed = Sound("FAS2_M4A1_S")

-- Accuracy related
SWEP.HipCone = 0.047
SWEP.AimCone = 0.004
SWEP.SpreadPerShot = 0.009
SWEP.MaxSpreadInc = 0.03
SWEP.SpreadCooldown = 0.15
SWEP.VelocitySensitivity = 1.55
SWEP.AimFOV = 5

-- Recoil related
SWEP.ViewKick = 1.1
SWEP.Recoil = 0.4

-- Reload related
SWEP.ReloadTime = 2.6
SWEP.ReloadTime_Nomen = 1.9
SWEP.ReloadTime_Empty = 2.7
SWEP.ReloadTime_Empty_Nomen = 1.9