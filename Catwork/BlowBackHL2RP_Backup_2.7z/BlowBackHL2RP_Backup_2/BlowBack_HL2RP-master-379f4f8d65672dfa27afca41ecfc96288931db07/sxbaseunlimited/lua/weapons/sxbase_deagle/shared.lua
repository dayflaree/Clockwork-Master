﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "IMI Desert Eagle"
    SWEP.Slot = 2
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-2.42, -0.755, 0.715)
	SWEP.AimAng = Vector(0.7, 0, 0)
	
	SWEP.SprintPos = Vector(1, -7, -4.69)
	SWEP.SprintAng = Vector(58.433, 0, 0)
	SWEP.MoveType = 2
	SWEP.Shell = "9x19"
	SWEP.ShellEjector = "eject"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.75)

	SWEP.ReloadBobDisabled = false
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "ОБОЙМА: " 
	SWEP.Text3DForward = -3.3
	SWEP.Text3DRight = -1
	SWEP.Text3DSize = 0.008
	SWEP.AmmoText = ".50 AE"
end

SWEP.MuzzleEffect = "muzzleflash_m14"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 12.7
SWEP.CaseLength = 32.6
SWEP.EmptySound = Sound( "Weapon_Pistol.Empty" )


SWEP.Anims = {}
SWEP.Anims.Draw_First = "deploy"
SWEP.Anims.Draw = "deploy"
SWEP.Anims.Draw_Empty = "deploy_empty"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster_empty"
SWEP.Anims.Fire = {"fire1", "fire2", "fire3", "fire4"}
SWEP.Anims.Fire_Last = "fire_last"
SWEP.Anims.Fire_Aiming = "fire_iron"
SWEP.Anims.Fire_Aiming_Last = "fire_iron_last"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Idle_Aim = "idle_scoped"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Nomen = "reload_nomen"
SWEP.Anims.Reload_Empty = "reload_empty"
SWEP.Anims.Reload_Empty_Nomen = "reload_nomen_empty"

SWEP.Sounds = {}
SWEP.Sounds["reload"] = {[1] = {time = 0.5, sound = Sound("Weapon_DEAGLE.MagOut")},
	[2] = {time = 0.9, sound = Sound("MagPouch_Pistol")},
	[3] = {time = 1.4, sound = Sound("Weapon_DEAGLE.MagInPartial")},
	[4] = {time = 1.55, sound = Sound("Weapon_DEAGLE.MagIn")}}
	
SWEP.Sounds["reload_nomen"] = {[1] = {time = 0.3, sound = Sound("Weapon_DEAGLE.MagOut")},
	[2] = {time = 0.5, sound = Sound("MagPouch_Pistol")},
	[3] = {time = 0.95, sound = Sound("Weapon_DEAGLE.MagInPartial")},
	[4] = {time = 1.1, sound = Sound("Weapon_DEAGLE.MagInNomen")}}
	
SWEP.Sounds["reload_empty"] = {[1] = {time = 0.6, sound = Sound("Weapon_DEAGLE.MagOutEmpty")},
	[2] = {time = 0.9, sound = Sound("MagPouch_Pistol")},
	[3] = {time = 1.4, sound = Sound("Weapon_DEAGLE.MagInPartial")},
	[4] = {time = 1.55, sound = Sound("Weapon_DEAGLE.MagIn")},
	[5] = {time = 2.3, sound = Sound("Weapon_DEAGLE.SlideStop")}}
	
SWEP.Sounds["reload_nomen_empty"] = {[1] = {time = 0.3, sound = Sound("Weapon_DEAGLE.MagOut")},
	[2] = {time = 0.5, sound = Sound("MagPouch_Pistol")},
	[3] = {time = 0.95, sound = Sound("Weapon_DEAGLE.MagInPartial")},
	[4] = {time = 1.1, sound = Sound("Weapon_DEAGLE.MagInNomen")},
	[5] = {time = 1.6, sound = Sound("Weapon_DEAGLE.SlideStop")}}

SWEP.FireModes = {"semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "CombineFodder"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "pistol"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/view/pistols/deagle.mdl"
SWEP.WM = "models/weapons/w_deserteagle.mdl"
SWEP.WorldModel = "models/weapons/w_pist_deagle.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 7
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = ".50 AE"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.45
SWEP.DeployTime = 0.45

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.25
SWEP.Damage = 55
SWEP.FireSound = Sound( "Weapon_DEAGLE.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.04
SWEP.AimCone = 0.009
SWEP.SpreadPerShot = 0.02
SWEP.MaxSpreadInc = 0.055
SWEP.SpreadCooldown = 0.4
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 0

-- Recoil related
SWEP.ViewKick = 3.7
SWEP.Recoil = 3.2

-- Reload related
SWEP.ReloadTime = 2.1
SWEP.ReloadTime_Nomen = 1.3
SWEP.ReloadTime_Empty = 2.7
SWEP.ReloadTime_Empty_Nomen = 1.7

SWEP.ServersideSounds = false