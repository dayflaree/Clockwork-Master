if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "Combine Overwatch Impulse Rifle Mk.1"
    SWEP.Slot = 3
    SWEP.SlotPos = 0
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3,-2,0.4)
	SWEP.AimAng = Vector(0.264, 0, 0)
	
	SWEP.SprintPos = Vector(2, 0, 0)
	SWEP.SprintAng = Vector(-10, 8, 0)
	
	SWEP.Shell = ""
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobOffset = Angle(0,0,90)
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = true

	SWEP.MagText = "ЗАРЯД: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "Impulse Energy Cell"
end
SWEP.MuzzleEffect = "muzzleflash_ar2"
SWEP.MuzzleLight = Color(255,150,100)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HoldType = "shotgun"

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 3
SWEP.CaseLength = 2
SWEP.PenAdd = 1
SWEP.EmptySound = Sound( "Weapon_IRifle.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "ir_draw"
SWEP.Anims.Draw = "ir_draw"
SWEP.Anims.Holster = "ir_holster"
SWEP.Anims.Fire = "ir_fire"
SWEP.Anims.Fire_Aiming = "ir_fire"
SWEP.Anims.Idle = "ir_idle"
SWEP.Anims.Idle_Aim = "ir_idle"
SWEP.Anims.Reload = "ir_reload"
SWEP.Anims.Reload_Nomen = "ir_reload"
SWEP.Anims.Reload_Empty = "ir_reload"
SWEP.Anims.Reload_Empty_Nomen = "ir_reload"

SWEP.Sounds = {}
SWEP.Sounds["ir_reload"] = {
	[1] = {time = 0, sound = Sound( "Weapon_AR2.Reload" )},
	[2] = {time = 0.1, sound = Sound( "Weapon_AR2.Reload_Rotate" )},
	[3] = {time = 0.6, sound = Sound( "Weapon_AR2.Reload_Push" )}
}

SWEP.FireModes = {"semi","auto","3burst"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""

SWEP.ViewModelFOV    = 60
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_irifle.mdl"
SWEP.WM = "models/weapons/w_irifle.mdl"
SWEP.WorldModel   = "models/weapons/w_irifle.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 30
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "AR2"
SWEP.Primary.TracerName         = "AR2Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.105
SWEP.Damage = 24
SWEP.FireSound = Sound( "Weapon_AR2.NPC_Single" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.03
SWEP.AimCone = 0.015
--SWEP.ClumpSpread = 0.06
SWEP.SpreadPerShot = 0.0025
SWEP.MaxSpreadInc = 0.1
SWEP.SpreadCooldown = 0.1
SWEP.VelocitySensitivity = 0.3
SWEP.AimFOV = 15

-- Recoil related
SWEP.ViewKick = 0.5
SWEP.Recoil = 0.3

-- Reload related
SWEP.ReloadTime = 1.3
SWEP.ReloadTime_Nomen = 1.3
SWEP.ReloadTime_Empty = 1.3
SWEP.ReloadTime_Empty_Nomen = 1.3

if CLIENT then
	local function SXBASE_WorldMuzzle( um )
		local ent = um:ReadEntity()
		if !IsValid(ent) then return end
		if !IsValid(ent.Owner) then return end

		if ent.Owner == LocalPlayer() then
			if !LocalPlayer():ShouldDrawLocalPlayer() then
				local weapon = ent.ViewModelEnt
				local muz = weapon:GetAttachment( weapon:LookupAttachment( "muzzle" ) )
				local data = EffectData()
				data:SetEntity(weapon) 
				data:SetOrigin(muz.Pos - muz.Ang:Forward() * 20) 
				data:SetAngles(muz.Ang)
				data:SetScale(1)
				data:SetAttachment(weapon:LookupAttachment( "muzzle" ))
				data:SetFlags(1)
				util.Effect( "MuzzleEffect", data )
				return
			end
		end

		local weapon = ent.Weapon
		local muz = weapon:GetAttachment( weapon:LookupAttachment( "muzzle" ) )
		if muz then
			
			local data = EffectData()
			data:SetEntity(weapon) 
			data:SetOrigin(muz.Pos + muz.Ang:Forward() * 20) 
			data:SetAngles(muz.Ang)
			data:SetScale(1)
			data:SetAttachment(weapon:LookupAttachment( "muzzle" ))
			data:SetFlags(5)
			util.Effect( "MuzzleFlash", data )
			
			
			local data = EffectData()
			data:SetEntity(weapon) 
			data:SetOrigin(muz.Pos) 
   			data:SetStart(muz.Pos)
   			data:SetAngles(muz.Ang)
			data:SetScale(0.25)
   			data:SetMagnitude(0.25)
			data:SetAttachment(weapon:LookupAttachment( "muzzle" ))
			util.Effect( "AirboatMuzzleFlash", data )
			
		end
	end
	usermessage.Hook("SXBASE_WORLDMUZZLE_AR2", SXBASE_WorldMuzzle)
end

local mod, cr, tr, aim
local td = {}

function SWEP:PrimaryAttack()
	if self.FireMode == "safe" then
		if IsFirstTimePredicted() then
			self:CycleFiremodes()
		end
		
		return
	end
	
	if IsFirstTimePredicted() then
		if self.BurstAmount > 0 and self.dt.Shots >= self.BurstAmount then
			return
		end
		
		if self.ReloadState != 0 then
			self.ReloadState = 3
			return
		end
		
		if self.dt.Status == FAS_STAT_CUSTOMIZE then
			return
		end
		
		if self.Cooking or self.FuseTime then
			return
		end
	
		--[[
		if self.Owner:KeyDown(IN_USE) then
			if self:CanThrowGrenade() then
				self:InitialiseGrenadeThrow()
				return
			end
		end
		]]
		
		if self.dt.Status == FAS_STAT_SPRINT or self.dt.Status == FAS_STAT_QUICKGRENADE then
			return
		end
		
		td.start = self.Owner:GetShootPos()
		td.endpos = td.start + self.Owner:GetAimVector() * 30
		td.filter = self.Owner
			
		tr = util.TraceLine(td)
		
		if tr.Hit then
			return
		end
		
		mag = self:Clip1()
		CT = CurTime()
		
		if mag <= 0 or self.Owner:WaterLevel() >= 3 then
			self:EmitSound(self.EmptySound, 60, 100)
			self:SetNextPrimaryFire(CT + 0.2)
			//self:EmitSound("SXBASE_DRYFIRE", 70, 100)
			return
		end
	
		if self.CockAfterShot and not self.Cocked then
			if SERVER then
				if SP then
					SendUserMessage("SXBASE_COCKREMIND", self.Owner) -- wow okay
				end
			else
				self.CockRemindTime = CurTime() + 1
			end
			
			return
		end
			
		self:FireBullet()
		
		if CLIENT then
			--self:CreateMuzzle()
		else
			umsg.Start("SXBASE_WORLDMUZZLE_AR2")
				umsg.Entity(self)
			umsg.End()
		end
		self:CreateWorldMuzzle()
		
		
		mod = self.Owner:Crouching() and 0.75 or 1
		
		if CLIENT then
			self:PlayFireAnim(mag)
		end
			
		if self.dt.Status == FAS_STAT_ADS then
			if self.BurstAmount > 0 then
				if self.DelayedBurstRecoil then
					if self.dt.Shots == self.ShotToDelayUntil then
						self:AimRecoil(self.BurstRecoilMod)
					end
				else
					self:AimRecoil(self.BurstRecoilMod)
				end
			else
				self:AimRecoil()
			end
		else
			if self.BurstAmount > 0 then
				if self.DelayedBurstRecoil then
					if self.dt.Shots == self.ShotToDelayUntil then
						self:HipRecoil(self.BurstRecoilMod)
					end
				else
					self:HipRecoil(self.BurstRecoilMod)
				end
			else
				self:HipRecoil()
			end
		end
		
		self.SpreadWait = CT + self.SpreadCooldown
		
		if self.BurstAmount > 0 then
			self.AddSpread = math.Clamp(self.AddSpread + self.SpreadPerShot * mod * 0.5, 0, self.MaxSpreadInc)
			self.AddSpreadSpeed = math.Clamp(self.AddSpreadSpeed - 0.2 * mod * 0.5, 0, 1)
		else
			self.AddSpread = math.Clamp(self.AddSpread + self.SpreadPerShot * mod, 0, self.MaxSpreadInc)
			self.AddSpreadSpeed = math.Clamp(self.AddSpreadSpeed - 0.2 * mod, 0, 1)
		end
		
		if self.CockAfterShot then
			self.Cocked = false
		end
	
		if SERVER and SP then
			SendUserMessage("SXBASESPREAD", self.Owner)
		end
		
		if CLIENT then
			self.CheckTime = 0
		end

		self:EmitSound(self.FireSound, 105, 100)

		self.Owner:SetAnimation(PLAYER_ATTACK1)
		
		self.ReloadWait = CT + 0.3
	end
	
	if self.BurstAmount > 0 then
		self.dt.Shots = self.dt.Shots + 1
		self:SetNextPrimaryFire(CT + self.FireDelay * self.BurstFireDelayMod)
	else
		self:SetNextPrimaryFire(CT + self.FireDelay)
	end
	
	self:TakePrimaryAmmo(1)
	
	return 
end
