﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "357 Magnum"
    SWEP.Slot = 2
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-4.67,-6,0.7)
	SWEP.AimAng = Vector(-0.38, -0.17, 1.01)
	
	SWEP.SprintPos = Vector(1.2, -12, -10)
	SWEP.SprintAng = Vector(55, 0, 0)
	SWEP.MoveType = 2
	SWEP.Shell = "9x19"
	SWEP.ShellEjector = "eject"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = true
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "БАРАБАН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "357 Magnum"
end

SWEP.MuzzleEffect = "muzzleflash_m14"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_Pistol.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster"
SWEP.Anims.Fire = "fire"
SWEP.Anims.Fire_Empty = "fire"
SWEP.Anims.Fire_Aiming = "fire"
SWEP.Anims.Idle = "idle01"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reload"

SWEP.Sounds = {}
SWEP.Sounds["reload"] = {
	[1] = {time = 0.93, sound = Sound( "Weapon_357.OpenLoader" )},
	[2] = {time = 1.3, sound = Sound( "Weapon_357.RemoveLoader" )},
	[3] = {time = 2.23, sound = Sound( "Weapon_357.ReplaceLoader" )},
	[4] = {time = 3.06, sound = Sound( "Weapon_357.Spin" )}
}


SWEP.FireModes = {"semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "pistol"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_357.mdl"
SWEP.WM = "models/weapons/w_357.mdl"
SWEP.WorldModel   = "models/weapons/w_357.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 6
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "357"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.5

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.75
SWEP.Damage = 50
SWEP.FireSound = Sound( "Weapon_357.Single" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.035
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.035
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 8
SWEP.Recoil = 6

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.ServersideSounds = false