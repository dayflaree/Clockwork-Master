if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "MP7 w/ Barska & AN/PEQ-15"
    SWEP.Slot = 3
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	--SWEP.AimPos = Vector(-2.454,0,0.9)
	--SWEP.AimAng = Vector(0.05, 0, 0)
	SWEP.AimPos = Vector(-2.44,-1,0.19)
	SWEP.AimAng = Vector(0.05, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = "smg1"
	SWEP.ShellEjector = "shell"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = true
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "4.6x30мм"
	SWEP.VModels = {
		["eotech"] = { model = "models/weapons/attachments/a_optic_barska.mdl", ent = NULL },
		["laser"] = { model = "models/weapons/attachments/a_laser_peq.mdl", ent = NULL },
	}
	SWEP.WModels = {
		["eotech"] = { model = "models/weapons/attachments/w_optic_barska.mdl", ent = NULL },
		["laser"] = { model = "models/weapons/attachments/w_laser_anpeq.mdl", ent = NULL },
	}
end
SWEP.HasLaserSight = true

SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleOffset = -9
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_MP7.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "draw_empty"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster"
SWEP.Anims.Fire = "fire"
SWEP.Anims.Fire_Aiming = "iron_fire"
SWEP.Anims.Fire_Empty = "dryfire"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reloadempty"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Universal.Draw" )},
	[2] = {time = 0.700, sound = Sound( "Weapon_MP7.BoltBack" )},
	[3] = {time = 0.908, sound = Sound( "Weapon_MP7.BoltRelease" )},
	[4] = {time = 0.933, sound = Sound( "Weapon_MP7.BoltLock" )},
}
SWEP.Sounds["holster"] = {
	[1] = {time = 0, sound = Sound( "Universal.Holster" )},
}
SWEP.Sounds["reloadempty"] = {
	[1] = {time = 0.4, sound = Sound( "Weapon_MP7.MagRelease" )},
	[2] = {time = 0.553, sound = Sound( "Weapon_MP7.MagOut" )},
	[3] = {time = 1.866, sound = Sound( "Weapon_MP7.MagIn" )},
	[4] = {time = 2.8, sound = Sound( "Weapon_MP7.BoltBack" )},
	[5] = {time = 2.96, sound = Sound( "Weapon_MP7.BoltRelease" )},
	[6] = {time = 3, sound = Sound( "Weapon_MP7.BoltLock" )},
	[7] = {time = 3.413, sound = Sound( "Weapon_AK74.Rattle" )},
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0.4, sound = Sound( "Weapon_MP7.MagRelease" )},
	[2] = {time = 0.553, sound = Sound( "Weapon_MP7.MagOut" )},
	[3] = {time = 1.866, sound = Sound( "Weapon_MP7.MagIn" )},
	[4] = {time = 2.466, sound = Sound( "Weapon_AK74.Rattle" )},
}


SWEP.FireModes = {"semi","auto"}

SWEP.Category = "SXBase Weapons [MP7]"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "smg"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_hkmp7.mdl"
SWEP.WM = "models/weapons/w_hkmp7.mdl"
SWEP.WorldModel   = "models/weapons/w_hkmp7.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 45
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "smg1"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.75
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.25

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.075
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon_MP7.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.04
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 5
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.65
SWEP.Recoil = 0.5

-- Reload related
SWEP.ReloadTime = 2.5
SWEP.ReloadTime_Empty = 3.5


function SWEP:getDifferenceToAimPos(pos, ang, vertDependance, horDependance, dependMod)
	dependMod = dependMod or 1
	vertDependance = vertDependance or 1
	horDependance = horDependance or 1
	
	local sway = (self.AngleDelta.p * 0.65 * vertDependance + self.AngleDelta.y * 0.75 * horDependance) * 0.05 * dependMod
	local pos = self.BlendPos - pos
	local ang = self.BlendAng/20 - ang
	ang.z = 0
	
	pos = pos:Length()
	ang = math.abs(ang:Length())

	local dependance = pos + ang
	
	return 1 - dependance
end

local displayIcon = Material("models/weapons/optics/barska/barska_reticule_holo")
function SWEP:reticleDraw( vm )
	local diff = self:getDifferenceToAimPos(self.AimPos, self.AimAng, 1)

	if diff > 0.3 and diff < 1.3 then
		cam.IgnoreZ(true)
			render.SetMaterial(displayIcon)
			local dist = math.Clamp(math.Distance(1, 1, diff, diff), 0, 0.5)
					
			local EA = self.Owner:EyeAngles() + self.Owner:GetPunchAngle()
					
			local renderColor = Color(255,180,180)
			renderColor.a = (0.5 - dist) / 0.5 * 255

			local pos = EyePos() + EA:Forward() * 100
					
			for i = 1, 2 do
				render.DrawSprite(pos, 5, 5, renderColor)
			end
		cam.IgnoreZ(false)
	end
end


if CLIENT then
	function SWEP:attachmentDrawVM( vm )
		local laserattach = self.VModels[ "laser" ]
		if !IsValid(laserattach.ent) then return end
		if !self.dt.LaserSight then 
			if self.Owner.VMLaserAttachmentHandleLastPos then self.Owner.VMLaserAttachmentHandleLastPos = nil end
			return 
		end
		--if self.Owner == LocalPlayer() and hook.Call("ShouldDrawLocalPlayer", self.Owner) == true then return end

		local attach = laserattach.ent:GetAttachment(laserattach.ent:LookupAttachment("Laser"))
		local endpos = attach.Ang:Forward()*2000

		local tr = {}
		tr.start = self.Owner:GetShootPos()
		tr.endpos = self.Owner:GetShootPos() + endpos
		tr.filter = {self.Owner, self.Owner:GetViewModel()}
		local trace = util.TraceLine( tr )
		
		
		local pos = trace.HitPos

		if not self.Owner.VMLaserAttachmentHandleLastPos then
			self.Owner.VMLaserAttachmentHandleLastPos = pos
		end

		local vNorm = pos - EyePos()
		local Distance = vNorm:Length()
		local size = math.Clamp( ( (Distance/200)), 1, 40 )
		Distance = math.Clamp( Distance, 32, 800 )
		local alpha = math.Clamp( (1500 - Distance), 0, 255 )

		render.SetMaterial(Material("sprites/light_glow02_add"))
		render.DrawBeam(self.Owner.VMLaserAttachmentHandleLastPos, pos, size/2, 0, 1, Color(255,0,0,alpha))
		render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
		render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
		
		self.Owner.VMLaserAttachmentHandleLastPos = pos

		render.SetMaterial(Material("effects/laser1"))
		render.StartBeam( 3 )
			render.AddBeam( attach.Pos, 0.3, 0, Color(255,0,0))
			render.AddBeam( attach.Pos + attach.Ang:Forward()*5, 0.3, 0, Color(180,0,0))
			render.AddBeam( attach.Pos + attach.Ang:Forward()*15, 0.3, 0, Color(0,0,0))
		render.EndBeam()
	end
	
	function SXBASE_DrawLaserSightsWorld( ply )
		local weapon = ply:GetActiveWeapon()

		if !ply:Alive() then return end
		if !IsValid(weapon) then return end
		if !weapon.IsSXBASEWeapon then return end

		local laserattach = weapon.WModels["laser"]

		if !laserattach then return end
		if !IsValid(laserattach.ent) then return end

		if !weapon.dt.LaserSight then 
			if ply.LaserAttachmentHandleLastPos then ply.LaserAttachmentHandleLastPos = nil end
			if ply.LaserAttachmentHandleLastPosNext then ply.LaserAttachmentHandleLastPosNext = nil end
			return 
		end

		--if ply == LocalPlayer() then return end
		
		local pos = ply:GetEyeTrace().HitPos

		if not ply.LaserAttachmentHandleLastPos then
			ply.LaserAttachmentHandleLastPos = pos
		end
		if not ply.LaserAttachmentHandleLastPosNext then
			ply.LaserAttachmentHandleLastPosNext = CurTime() + 0.05
		end

		local vNorm = pos - EyePos()
		local Distance = vNorm:Length()
		vNorm:Normalize()
		local vDot = 1
		ply.LaserHandle = ply.LaserHandle or util.GetPixelVisibleHandle()
		
		if vDot >= 0 then
			local vis = util.PixelVisible( pos, 1, ply.LaserHandle )	
			if !vis then return end
			
			local size = math.Clamp( ( (Distance/75)) * (2 - vis) * vDot, 1, 40 )
			Distance = math.Clamp( Distance, 32, 800 )
			local alpha = math.Clamp( (1500 - Distance) * vis * vDot, 0, 255 )
				
			render.SetMaterial(Material("sprites/light_ignorez"))

			render.DrawBeam(ply.LaserAttachmentHandleLastPos, pos, size/2, 0, 0.99, Color(255,0,0,alpha))
			render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
			render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
		end

		if ply.LaserAttachmentHandleLastPosNext and CurTime() >= ply.LaserAttachmentHandleLastPosNext then
			ply.LaserAttachmentHandleLastPos = LerpVector(FrameTime() * 50,ply.LaserAttachmentHandleLastPos,pos)
			if ply.LaserAttachmentHandleLastPos:Distance(pos) > 0 then
				ply.LaserAttachmentHandleLastPosNext = CurTime() + 0.05
			end
		end

		local laser = laserattach.ent:GetAttachment(laserattach.ent:LookupAttachment("laserbeam"))
		local pos = laser.Pos 
		local lNorm = laser.Ang:Forward()
		local vNorm = pos - EyePos()
		local Distance = vNorm:Length()
		local Distance2 = vNorm:Length()
		vNorm:Normalize()
		local vDot = vNorm:Dot( lNorm * -1 )
		ply.LaserAttachmentHandle = ply.LaserAttachmentHandle or util.GetPixelVisibleHandle()
			

			
		if vDot >= 0 then
			local vis = util.PixelVisible( pos, 3, ply.LaserAttachmentHandle )	
			if vis < 0.3 then return end
			if !vis then return end
			local size1 = math.Clamp( Distance * vis * vDot * 2, 0, 2 )
			local size = math.Clamp( Distance * vis * vDot * 2, 0, 4 )
			local size2 = math.Clamp( Distance * vis * vDot * 2, 0, 32 )
			Distance = math.Clamp( Distance, 32, 800 )
			local alpha = math.Clamp( (1000 - Distance) * vis * vDot, 0, 255 )
			render.SetMaterial(Material("sprites/light_ignorez"))
			render.DrawSprite( pos, size1, size1, Color(255,200,200,alpha))
			render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
			render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
			render.DrawSprite( pos, size2, size, Color(255,0,0,alpha))
			
			
			Distance = Distance / 6
			local size3 = math.Clamp( Distance * vis * vDot * 2, 0, 256 )
			local size4 = math.Clamp( Distance * vis * vDot * 2, 0, 32 )
			local size5 = math.Clamp( Distance * vis * vDot * 2, 0, 8 )
			Distance = math.Clamp( Distance, 0, 1000 )
			local alpha = math.Clamp( (1000 - Distance) * vis * vDot, 0, 255 )
			render.DrawSprite( pos, size4, size4/3, Color(255,225,225,alpha))
			render.DrawSprite( pos, size3, size4/3, Color(255,125,125,alpha))
			render.DrawSprite( pos, size3, size4, Color(255,0,0,alpha))
			Distance2 = Distance2/6
			local size32 = math.Clamp( Distance2 * vis * vDot * 2, 0, 512 )
			local size42 = math.Clamp( Distance2 * vis * vDot / 2 , 0, 156 )
			Distance2 = math.Clamp( Distance2, 0, 10000 )
			local alpha = math.Clamp( (10000 - Distance2) * vis * vDot, 0, 255 )
			render.DrawSprite( pos, size32, size42, Color(255,0,0,alpha))
		end

	end

	hook.Add("PostDrawOpaqueRenderables","SXBASE_DrawLaserSightsWorld",function()
		for k,v in pairs( player.GetAll() ) do 
			if (v != LocalPlayer()) then
				SXBASE_DrawLaserSightsWorld( v )
			end
		end
	end)
end
if SERVER then
	concommand.Add("sxbase_use_attach", function(ply)
		local weapon = ply:GetActiveWeapon()
		if IsValid(weapon) then
			if weapon.IsSXBASEWeapon then
				if weapon.HasLaserSight then
					if CurTime() > weapon:GetNextPrimaryFire() then
						weapon.dt.LaserSight = !weapon.dt.LaserSight
						weapon:SetNextPrimaryFire(CurTime() + 0.15)
						weapon:EmitSound(Sound("weapons/ak74/handling/ak74_fireselect_1.wav"),40,100,1,CHAN_ITEM)
					end
				end
			end
		end
	end)
end