if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "MP7 w/ AN/PEQ-15"
    SWEP.Slot = 3
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-2.454,0,0.9)
	SWEP.AimAng = Vector(0.05, 0, 0)

	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = "smg1"
	SWEP.ShellEjector = "shell"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = true
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "4.6x30мм"
	SWEP.VModels = {
		["laser"] = { model = "models/weapons/attachments/a_laser_peq.mdl", ent = NULL },
	}
	SWEP.WModels = {
		["laser"] = { model = "models/weapons/attachments/w_laser_anpeq.mdl", ent = NULL },
	}
end
SWEP.HasLaserSight = true

SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleOffset = -9
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_MP7.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "draw_empty"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster"
SWEP.Anims.Fire = "fire"
SWEP.Anims.Fire_Aiming = "iron_fire"
SWEP.Anims.Fire_Empty = "dryfire"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reloadempty"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Universal.Draw" )},
	[2] = {time = 0.700, sound = Sound( "Weapon_MP7.BoltBack" )},
	[3] = {time = 0.908, sound = Sound( "Weapon_MP7.BoltRelease" )},
	[4] = {time = 0.933, sound = Sound( "Weapon_MP7.BoltLock" )},
}
SWEP.Sounds["holster"] = {
	[1] = {time = 0, sound = Sound( "Universal.Holster" )},
}
SWEP.Sounds["reloadempty"] = {
	[1] = {time = 0.4, sound = Sound( "Weapon_MP7.MagRelease" )},
	[2] = {time = 0.553, sound = Sound( "Weapon_MP7.MagOut" )},
	[3] = {time = 1.866, sound = Sound( "Weapon_MP7.MagIn" )},
	[4] = {time = 2.8, sound = Sound( "Weapon_MP7.BoltBack" )},
	[5] = {time = 2.96, sound = Sound( "Weapon_MP7.BoltRelease" )},
	[6] = {time = 3, sound = Sound( "Weapon_MP7.BoltLock" )},
	[7] = {time = 3.413, sound = Sound( "Weapon_AK74.Rattle" )},
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0.4, sound = Sound( "Weapon_MP7.MagRelease" )},
	[2] = {time = 0.553, sound = Sound( "Weapon_MP7.MagOut" )},
	[3] = {time = 1.866, sound = Sound( "Weapon_MP7.MagIn" )},
	[4] = {time = 2.466, sound = Sound( "Weapon_AK74.Rattle" )},
}


SWEP.FireModes = {"semi","auto"}

SWEP.Category = "SXBase Weapons [MP7]"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "smg"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_hkmp7.mdl"
SWEP.WM = "models/weapons/w_hkmp7.mdl"
SWEP.WorldModel   = "models/weapons/w_hkmp7.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 45
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "smg1"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.75
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.25

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.075
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon_MP7.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.04
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 5
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.65
SWEP.Recoil = 0.5

-- Reload related
SWEP.ReloadTime = 2.5
SWEP.ReloadTime_Empty = 3.5

if CLIENT then
	function SWEP:attachmentDrawVM( vm )
		local laserattach = self.VModels[ "laser" ]
		if !IsValid(laserattach.ent) then return end
		if !self.dt.LaserSight then 
			if self.Owner.VMLaserAttachmentHandleLastPos then self.Owner.VMLaserAttachmentHandleLastPos = nil end
			return 
		end
		if self.Owner == LocalPlayer() and hook.Call("ShouldDrawLocalPlayer", self.Owner) == true then return end

		local attach = laserattach.ent:GetAttachment(laserattach.ent:LookupAttachment("Laser"))
		local endpos = attach.Ang:Forward()*2000

		local tr = {}
		tr.start = self.Owner:GetShootPos()
		tr.endpos = self.Owner:GetShootPos() + endpos
		tr.filter = {self.Owner, self.Owner:GetViewModel()}
		local trace = util.TraceLine( tr )
		
		
		local pos = trace.HitPos

		if not self.Owner.VMLaserAttachmentHandleLastPos then
			self.Owner.VMLaserAttachmentHandleLastPos = pos
		end

		local vNorm = pos - EyePos()
		local Distance = vNorm:Length()
		local size = math.Clamp( ( (Distance/200)), 1, 40 )
		Distance = math.Clamp( Distance, 32, 800 )
		local alpha = math.Clamp( (1500 - Distance), 0, 255 )

		render.SetMaterial(Material("sprites/light_glow02_add"))
		render.DrawBeam(self.Owner.VMLaserAttachmentHandleLastPos, pos, size/2, 0, 1, Color(255,0,0,alpha))
		render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
		render.DrawSprite( pos, size, size, Color(255,0,0,alpha))
		
		self.Owner.VMLaserAttachmentHandleLastPos = pos

		render.SetMaterial(Material("effects/laser1"))
		render.StartBeam( 3 )
			render.AddBeam( attach.Pos, 0.3, 0, Color(255,0,0))
			render.AddBeam( attach.Pos + attach.Ang:Forward()*5, 0.3, 0, Color(180,0,0))
			render.AddBeam( attach.Pos + attach.Ang:Forward()*15, 0.3, 0, Color(0,0,0))
		render.EndBeam()
	end
end