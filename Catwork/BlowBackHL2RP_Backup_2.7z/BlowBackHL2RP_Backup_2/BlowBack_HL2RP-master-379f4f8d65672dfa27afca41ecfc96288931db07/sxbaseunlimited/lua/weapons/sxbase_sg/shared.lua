﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "M7A3 Smoke"
    SWEP.Slot = 4
    SWEP.SlotPos = 2
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3.412, -6.4, -2.238)
	SWEP.AimAng = Vector(7.353, 0, 0)
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(2, -3, 0.25)
	
	SWEP.SprintPos = Vector(0, 0, 0)
	SWEP.SprintAng = Vector(0, 0, 0)
	SWEP.MoveType = 3

	SWEP.ReloadBobOffset = Angle(0,0,0)
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.PistolSafePos = Vector(0, 0, 0)
	SWEP.PistolSafeAng = Vector(0, 0, 0)
	SWEP.RifleSafePos = Vector(0, 0, 0)
	SWEP.RifleSafeAng = Vector(-5, 0, 0)
	
	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DRight = -1
	SWEP.Text3DForward = -5
	SWEP.Text3DSize = 0.01
	SWEP.AmmoText = "9mm патрон"
end

SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.HoldType = "grenade"
SWEP.NoProficiency = true
SWEP.BulletLength = 7.62
SWEP.CaseLength = 39
SWEP.EmptySound = Sound("weapons/empty_assaultrifles.wav")
SWEP.NoAttachmentMenu = true

SWEP.Anims = {}
SWEP.Anims.Draw_First = "deploy"
SWEP.Anims.Draw = "deploy"
SWEP.Anims.Draw_Empty = "deploy_empty"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Idle_Empty = "empty_idle"
SWEP.Anims.Holster = "holster"

SWEP.Sounds = {}

SWEP.FireModes = {"semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "grenade"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 82
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/cstrike/c_eq_smokegrenade.mdl"
SWEP.WM = "mmodels/weapons/w_eq_smokegrenade.mdl"
SWEP.WorldModel   = "models/weapons/w_eq_smokegrenade.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = -1
SWEP.Primary.DefaultClip    = 1
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "grenade"
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 1
SWEP.DeployTime = 1
SWEP.HolsterTime = 0.1
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 0.1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.17
SWEP.Damage = 20
SWEP.FireSound = Sound( "Weapon_M9.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.037
SWEP.AimCone = 0.017
SWEP.SpreadPerShot = 0.01
SWEP.MaxSpreadInc = 0.040
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.75
SWEP.Recoil = 0.72

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.ServersideSounds = false

local nade, EA, pos, mag, CT, tr, force, phys, pos, vel
local td = {}

function SWEP:Reload()
	return
end

function SWEP:PlayDeployAnim()
	if self.Owner:GetAmmoCount(self.Primary.Ammo) <= 0 then
		SXBASE_PlayAnim(self, self.Anims.Draw_Empty, self.DeployAnimSpeed)
	else
		SXBASE_PlayAnim(self, self.Anims.Draw, self.DeployAnimSpeed)
	end
end


function SWEP:Holster(wep)
	if self.ThrowInitiated then
		return
	end
	if self == wep then
		return
	end
	self:RemoveShit()
	
	if self.dt.Status == FAS_STAT_HOLSTER_END then
		self.dt.Status = FAS_STAT_IDLE
		self.ReloadDelay = nil
		return true
	end
	
	if self.ReloadDelay or CurTime() < self.ReloadWait then
		return false
	end
	
	if IsValid(wep) and self.dt.Status != FAS_STAT_HOLSTER_START then
		CT = CurTime()

		self:SetNextPrimaryFire(CT + (self.HolsterTime and self.HolsterTime * 2 or 0.75))
		self:SetNextSecondaryFire(CT + (self.HolsterTime and self.HolsterTime * 2 or 0.75))
		self.ReloadWait = CT + (self.HolsterTime and self.HolsterTime * 2 or 0.75)
		self.SprintDelay = CT + (self.HolsterTime and self.HolsterTime * 2 or 0.75)
		
		self.ChosenWeapon = wep:GetClass()
		
		if self.dt.Status != FAS_STAT_HOLSTER_END then
			timer.Simple((self.HolsterTime and self.HolsterTime or 0.45), function()
				if IsValid(self) and IsValid(self.Owner) and self.Owner:Alive() then
					self.dt.Status = FAS_STAT_HOLSTER_END
					self.dt.Bipod = false
					if SERVER then
						self.Owner:SelectWeapon(self.ChosenWeapon)
					end
				end
			end)
		end
		
		self.dt.Status = FAS_STAT_HOLSTER_START
		self:PlayHolsterAnim()
	end

	
	if CLIENT then
		self.CurSoundTable = nil
		self.CurSoundEntry = nil
		self.SoundTime = nil
		self.SoundSpeed = 1
	end
	
	if SERVER and SP then
		SendUserMessage("SXBASE_ENDSOUNDS", self.Owner)
	end

	return false
end

function SWEP:Think()
	CT = CurTime()
	
	vel = self.Owner:GetVelocity():Length()
	
	if self.dt.Status != FAS_STAT_HOLSTER_START and self.dt.Status != FAS_STAT_HOLSTER_END and self.dt.Status != FAS_STAT_QUICKGRENADE then
		if self.Owner:OnGround() then
			if self.Owner:KeyDown(IN_SPEED) and vel >= self.Owner:GetWalkSpeed() * 1.3 then
				if self.dt.Status != FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_SPRINT
				end
			else
				if self.dt.Status == FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_IDLE
				end
			end
		else
			if self.dt.Status != FAS_STAT_IDLE then
				self.dt.Status = FAS_STAT_IDLE
			end
		end
	end
	
	if self.ThrowInitiated then
		if not self.Owner:KeyDown(IN_ATTACK) and not self.Owner:KeyDown(IN_ATTACK2) then
			if CT > self.TimeToThrow then
				if SERVER then 
					SXBASE_PlayAnim(self, "throw", 1)
				end

				self.Owner:SetAnimation(PLAYER_ATTACK1)
				
				timer.Simple(0.15, function()
					if IsValid(self) and IsValid(self.Owner) and self.Owner:Alive() then
						if SERVER then
							local nade = ents.Create("ent_smokegrenade")
							EA =  self.Owner:EyeAngles()
							pos = self.Owner:GetShootPos()
							pos = pos + EA:Right() * 5 - EA:Up() * 4 + EA:Forward() * 8
							
							nade:SetPos(pos)
							nade:SetAngles(Angle(math.random(0, 360), math.random(0, 360), math.random(0, 360)))
							nade:Spawn()
							nade:Activate()
							nade:SetOwner(self.Owner)
								
							nade:SetDetonateTimerLength( 3 )
							
							phys = nade:GetPhysicsObject()
							
							if IsValid(phys) then
								force = 1000
									
								if self.Owner:KeyDown(IN_FORWARD) and ong then
									force = force + self.Owner:GetVelocity():Length()
								end
								
								phys:SetVelocity(EA:Forward() * force * self.ThrowPower + Vector(0, 0, 100))
								phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
							end
						end
						
						self.FuseTime = nil
					end
				end)
				
				timer.Simple(0.6, function()
					if IsValid(self) and IsValid(self.Owner) and self.Owner:Alive() then
						if self.Owner:GetAmmoCount(self.Primary.Ammo) > 0 then
							if SERVER then 
								SXBASE_PlayAnim(self, "deploy", 1)
							end
						else
							self.MonitorGrenades = true
						end
					end
				end)
				
				self:TakePrimaryAmmo(1)
				self.ThrowInitiated = false
				self:SetNextPrimaryFire(CT + 1.25)
				self:SetNextSecondaryFire(CT + 1.25)
			end
		else
			if CT > self.TimeToThrow then
				self.ThrowPower = math.Approach(self.ThrowPower, 1, FrameTime())
			end
		end
	end
	
	if self.MonitorGrenades then
		if self.Owner:GetAmmoCount(self.Primary.Ammo) > 0 then
			if SERVER then 
				SXBASE_PlayAnim(self, "deploy", 1)
			end
			self.MonitorGrenades = false
			self:SetNextPrimaryFire(CT + 0.6)
			self:SetNextSecondaryFire(CT + 0.6)
		end
	end
	
	if self.CurSoundTable then
		t = self.CurSoundTable[self.CurSoundEntry]
		
		if CT >= self.SoundTime + t.time / self.SoundSpeed then
			self:EmitSound(t.sound, 70, 100)
			
			if self.CurSoundTable[self.CurSoundEntry + 1] then
				self.CurSoundEntry = self.CurSoundEntry + 1
			else
				self.CurSoundTable = nil
				self.CurSoundEntry = nil
				self.SoundTime = nil
			end
		end
	end
end

function SWEP:PrimaryAttack()	
	if not IsFirstTimePredicted() then
		return
	end
	
	if self.ThrowInitiated or self.FuseTime then
		return
	end
	
	if self.Owner:GetAmmoCount(self.Primary.Ammo) == 0 then
		return
	end

	td.start = self.Owner:GetShootPos()
	td.endpos = td.start + self.Owner:GetAimVector() * 30
	td.filter = self.Owner
		
	tr = util.TraceLine(td)
	
	if tr.Hit then
		return
	end
	
	CT = CurTime()
	
	self.ThrowInitiated = true
	self.ThrowType = "prime"
	self.ThrowPower = 0.5
	if SERVER then 
		SXBASE_PlayAnim(self, "pullpin", 1)
	end
	self.TimeToThrow = CT + 0.8
end

function SWEP:SecondaryAttack()	
	return
end

if CLIENT then
	local x, y, x2, y2

	function SWEP:DrawHUD()
		if GetConVarNumber("sxbase_nohud") > 0 then
			return
		end
		
		FT, CT, x, y = FrameTime(), CurTime(), ScrW(), ScrH()
		x2, y2 = math.Round(x * 0.5), math.Round(y * 0.5)

		draw.ExtText(self.Owner:GetAmmoCount(self.Primary.Ammo) .. "x M7A3 Smoke", "SXBASE_HUD24", x / 2, y / 2 + 200, Color(100, 220, 255, 255), Color(0, 0, 0, 255), 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end
