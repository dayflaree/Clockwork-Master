﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "Fireaxe"
    SWEP.Slot = 0
    SWEP.SlotPos = 4
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3.082,-8,0.85)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.SprintPos = Vector(5, 5, 0)
	SWEP.SprintAng = Vector(0, 0, 20)
	SWEP.MoveType = 2
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.NoShowAimCrossshair = true

	SWEP.RifleSafePos = Vector(0.324, -3, -0.621)
	SWEP.RifleSafeAng = Vector(-20, 5, -24)
end

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Swing = {"swing", "swing2", "swing3"}
SWEP.Anims.Stab = "stab"
SWEP.Anims.Idle = "idle"

SWEP.Sounds = {}

SWEP.FireModes = {"auto"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Instructions = "Primary Fire: Swing attack.\nSecondary Fire: Stab attack."
SWEP.Purpose = "A fireaxe."
SWEP.Contact = ""
SWEP.Author	= "SchwarzKruppzo"
SWEP.HoldType = "melee"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 90
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_fireaxe.mdl"
SWEP.WM = "models/weapons/w_fireaxe.mdl"
SWEP.WorldModel   = "models/weapons/w_fireaxe.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = -1
SWEP.Primary.DefaultClip    = -1
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = ""
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.5

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.12
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon.UspMatch.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.035
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.035
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.75
SWEP.Recoil = 0.6

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.IsHL2Melee = true

local vm, t, a
local SP = game.SinglePlayer()
local reg = debug.getregistry()
local GetVelocity = reg.Entity.GetVelocity
local Length = reg.Vector.Length
local GetAimVector = reg.Player.GetAimVector

function SWEP:DoHitEffects()
	SXBASE_PlayAnim(self, self.Anims.Swing, 1)
	self:EmitSound("weapons/fireaxe/axe_swing_miss"..math.random(1, 2)..".wav")
	timer.Simple(0.3, function()
		if !IsValid( self ) then return end
		if !IsValid( self.Owner ) then return end
		if !self.Owner:Alive() then return end

		local trace = {}
		trace.start = self.Owner:GetShootPos()
		trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 72
		trace.maxs = Vector(0.5,10,0.5)
		trace.mins = Vector(0,-10,0)
		trace.filter = self.Owner
		local trace = util.TraceHull( trace )

		
		if ( (trace.Hit or trace.HitWorld) and self.Owner:GetPos():Distance(trace.HitPos) <= 70 ) then
			if IsValid(trace.Entity) and ( trace.Entity:IsPlayer() or trace.Entity:IsNPC() ) then
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
				local effectData = EffectData()
				effectData:SetStart(trace.HitPos)
				effectData:SetOrigin(trace.HitPos)
				effectData:SetNormal(trace.HitNormal)
				util.Effect("BloodImpact", effectData, true, true)
			elseif IsValid(trace.Entity) and Clockwork.entity:GetPlayer(trace.Entity) then
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
				local effectData = EffectData()
				effectData:SetStart(trace.HitPos)
				effectData:SetOrigin(trace.HitPos)
				effectData:SetNormal(trace.HitNormal)
				util.Effect("BloodImpact", effectData, true, true)
			else
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
			end
		end
	end)
end
function SWEP:DoStabEffects()
	SXBASE_PlayAnim(self, self.Anims.Stab, 1)
	self:EmitSound("weapons/fireaxe/axe_swing_miss"..math.random(1, 2)..".wav")
	timer.Simple(0.5, function()
		if !IsValid( self ) then return end
		if !IsValid( self.Owner ) then return end
		if !self.Owner:Alive() then return end

		local trace = {}
		trace.start = self.Owner:GetShootPos()
		trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 72
		trace.maxs = Vector(1,1,1)
		trace.mins = Vector(-1,-1,-1)
		trace.filter = self.Owner
		local trace = util.TraceHull( trace )

		
		if ( (trace.Hit or trace.HitWorld) and self.Owner:GetPos():Distance(trace.HitPos) <= 67 ) then
			if IsValid(trace.Entity) and ( trace.Entity:IsPlayer() or trace.Entity:IsNPC() ) then
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
				local effectData = EffectData()
				effectData:SetStart(trace.HitPos)
				effectData:SetOrigin(trace.HitPos)
				effectData:SetNormal(trace.HitNormal)
				util.Effect("BloodImpact", effectData, true, true)
			elseif IsValid(trace.Entity) and Clockwork.entity:GetPlayer(trace.Entity) then
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
				local effectData = EffectData()
				effectData:SetStart(trace.HitPos)
				effectData:SetOrigin(trace.HitPos)
				effectData:SetNormal(trace.HitNormal)
				util.Effect("BloodImpact", effectData, true, true)
			else
				self:EmitSound("weapons/fireaxe/axe_impact_world"..math.random(1, 2)..".wav")
			end
		end
	end)
end

function SWEP:Think()
	cr = self.Owner:Crouching()
	CT, vel = CurTime(), Length(GetVelocity(self.Owner))
	
	if (SP and SERVER) or not SP then -- if it's SP, then we run it only on the server (otherwise shit gets fucked); if it's MP we predict it
		if self.dt.Bipod or self.DeployAngle then
			if not self:CanDeployBipod() then
				self.dt.Bipod = false
				self.DeployAngle = nil
				
				if not self.ReloadDelay then
					if CT > self.BipodDelay then
						self:PlayBipodUnDeployAnim()
						self.BipodDelay = CT + self.BipodUndeployTime
						self:SetNextPrimaryFire(CT + self.BipodUndeployTime)
						self:SetNextSecondaryFire(CT + self.BipodUndeployTime)
						self.ReloadWait = CT + self.BipodUndeployTime
					else
						self.BipodUnDeployPost = true
					end
				else
					self.BipodUnDeployPost = true
				end
			end
		end
	end

	if self.dt.Status != FAS_STAT_HOLSTER_START and self.dt.Status != FAS_STAT_HOLSTER_END and self.dt.Status != FAS_STAT_QUICKGRENADE then
		if self.Owner:OnGround() then
			if self.Owner:KeyDown(IN_SPEED) and vel >= self.Owner:GetWalkSpeed() * 1.3 then
				if self.dt.Status != FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_SPRINT
				end
			else
				if self.dt.Status == FAS_STAT_SPRINT then
					self.dt.Status = FAS_STAT_IDLE
					
					if CT > self.SprintDelay and not self.ReloadDelay then
						self:SetNextPrimaryFire(CT + 0.2)
						self:SetNextSecondaryFire(CT + 0.2)
					end
				end
			end
		else
			if self.dt.Status != FAS_STAT_IDLE then
				self.dt.Status = FAS_STAT_IDLE
				
				if CT > self.SprintDelay and not self.ReloadDelay then
					self:SetNextPrimaryFire(CT + 0.2)
					self:SetNextSecondaryFire(CT + 0.2)
				end
			end
		end
	end

	if self.CurSoundTable then
		t = self.CurSoundTable[self.CurSoundEntry]
		
		if CLIENT then
			if self.ViewModelEnt:SequenceDuration() * self.ViewModelEnt:GetCycle() >= t.time / self.SoundSpeed then
				self:EmitSound(t.sound, 70, 100)
				
				if self.CurSoundTable[self.CurSoundEntry + 1] then
					self.CurSoundEntry = self.CurSoundEntry + 1
				else
					self.CurSoundTable = nil
					self.CurSoundEntry = nil
					self.SoundTime = nil
				end
			end
		else
			if CT >= self.SoundTime + t.time / self.SoundSpeed then
				self:EmitSound(t.sound, 70, 100)
				
				if self.CurSoundTable[self.CurSoundEntry + 1] then
					self.CurSoundEntry = self.CurSoundEntry + 1
				else
					self.CurSoundTable = nil
					self.CurSoundEntry = nil
					self.SoundTime = nil
				end
			end
		end
	end

	for k, v in pairs(self.Events) do
		if CT > v.time then
			v.func()
			table.remove(self.Events, k)
		end
	end
end

local td, CT = {}, nil
function SWEP:PrimaryAttack()
	if not IsFirstTimePredicted() then
		return
	end

	if self.Cooking or self.FuseTime then
		return
	end

	if self.FireMode == "safe" then
		if IsFirstTimePredicted() then
			self:CycleFiremodes()
		end
		
		return
	end

	td.start = self.Owner:GetShootPos()
	td.endpos = td.start + self.Owner:GetAimVector() * 30
	td.filter = self.Owner
			
	tr = util.TraceLine(td)
		
	if tr.Hit then
		return
	end
		
	CT = CurTime() 

	self:SetNextPrimaryFire(CT + 0.8)
	self:SetNextSecondaryFire(CT + 1.2)
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	if SERVER then
		self:CallOnClient("DoHitEffects")
		timer.Simple(0.3, function()
			if !IsValid( self ) then return end
			if !IsValid( self.Owner ) then return end
			if !self.Owner:Alive() then return end

			if self.Owner.LagCompensation then
				self.Owner:LagCompensation(true)
			end
			local trace = {} //self.Owner:GetEyeTraceNoCursor();
			trace.start = self.Owner:GetShootPos()
			trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 70
			trace.maxs = Vector(0.5,10,0.5)
			trace.mins = Vector(0,-10,0)
			trace.filter = self.Owner
			local trace = util.TraceHull( trace )
			if (self.Owner:GetShootPos():Distance(trace.HitPos) <= 70) then
				if (IsValid(trace.Entity)) then
					local player = Clockwork.entity:GetPlayer(trace.Entity);
					local strength = Clockwork.attributes:Fraction(self.Owner, ATB_STRENGTH, 3, 1.5);
					
					if (trace.Entity:IsPlayer() or trace.Entity:IsNPC()) then
						local normal = ( trace.Entity:GetPos() - self.Owner:GetPos() ):GetNormal();
						local push = 64 * normal;
						
						trace.Entity:SetVelocity(push);
						
						trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(20 + (strength * 2), self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
					elseif (IsValid( trace.Entity:GetPhysicsObject() )) then
						trace.Entity:GetPhysicsObject():ApplyForceOffset(self.Owner:GetAimVector() * 150, trace.HitPos);
						
						trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(41 + (strength * 2), self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
					end
				end
			end
			if self.Owner.LagCompensation then
				self.Owner:LagCompensation(false)
			end
		end)
	end
	self.dt.Status = FAS_STAT_IDLE
end
function SWEP:SecondaryAttack()
	if not IsFirstTimePredicted() then
		return
	end

	if self.Cooking or self.FuseTime then
		return
	end

	if self.FireMode == "safe" then
		if IsFirstTimePredicted() then
			self:CycleFiremodes()
		end
		
		return
	end


	td.start = self.Owner:GetShootPos()
	td.endpos = td.start + self.Owner:GetAimVector() * 30
	td.filter = self.Owner
			
	tr = util.TraceLine(td)
		
	if tr.Hit then
		return
	end
		
	CT = CurTime() 

	self:SetNextPrimaryFire(CT + 1)
	self:SetNextSecondaryFire(CT + 1)
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	if SERVER then
		self:CallOnClient("DoStabEffects")
		timer.Simple(0.5, function()
			if !IsValid( self ) then return end
			if !IsValid( self.Owner ) then return end
			if !self.Owner:Alive() then return end

			if self.Owner.LagCompensation then
				self.Owner:LagCompensation(true)
			end
			local trace = {}
			trace.start = self.Owner:GetShootPos()
			trace.endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 67
			trace.maxs = Vector(1,1,1)
			trace.mins = Vector(-1,-1,-1)
			trace.filter = self.Owner
			local trace = util.TraceHull( trace )
			if (self.Owner:GetShootPos():Distance(trace.HitPos) <= 67) then
				if (IsValid(trace.Entity)) then
					local player = Clockwork.entity:GetPlayer(trace.Entity);
					local strength = Clockwork.attributes:Fraction(self.Owner, ATB_STRENGTH, 3, 1.5);
					
					if (trace.Entity:IsPlayer() or trace.Entity:IsNPC()) then
						local normal = ( trace.Entity:GetPos() - self.Owner:GetPos() ):GetNormal();
						local push = 32 * normal;
						
						trace.Entity:SetVelocity(push);
						
						trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(30 + strength, self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
					elseif (IsValid( trace.Entity:GetPhysicsObject() )) then
						trace.Entity:GetPhysicsObject():ApplyForceOffset(self.Owner:GetAimVector() * 150, trace.HitPos);
						
						trace.Entity:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(50 + (strength * 4), self, self.Owner, trace.HitPos, DMG_CLUB, 2) );
					end
				end
			end
			if self.Owner.LagCompensation then
				self.Owner:LagCompensation(false)
			end
		end)
	end
	self.dt.Status = FAS_STAT_IDLE
end