﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = false
end

if CLIENT then
    SWEP.PrintName = "M9"
    SWEP.Slot = 2
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3.145,-2,0.67)
	SWEP.AimAng = Vector(-0.2, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, -7, -6.69)
	SWEP.SprintAng = Vector(55, 0, 0)
	SWEP.MoveType = 2
	SWEP.Shell = "9x19"
	SWEP.ShellEjector = "shell"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobOffset = Angle(0,0,0)
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.PitchMod = 0.3
	SWEP.YawMod = 0.3
	
	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DRight = -2
	SWEP.Text3DForward = -6
	SWEP.Text3DSize = 0.015
	SWEP.AmmoText = "9x19мм"
end

SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 9
SWEP.CaseLength = 19
SWEP.EmptySound = Sound( "Weapon_M9.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "empty_draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "empty_holster"
SWEP.Anims.Fire = {"fire1","fire2"}
SWEP.Anims.Fire_Aiming = "iron_fire"
SWEP.Anims.Fire_Last = "firelast"
SWEP.Anims.Fire_Aiming_Last = "iron_firelast"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Idle_Empty = "empty_idle"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reloadempty"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Weapon_M9.PistolDraw" )},
}
SWEP.Sounds["holster"] = {
	[1] = {time = 0, sound = Sound( "Weapon_M9.PistolHolster" )}
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0, sound = Sound( "Weapon_M9.Magrelease" )},
	[2] = {time = 0.23, sound = Sound( "Weapon_M9.Magout" )},
	[3] = {time = 1.16, sound = Sound( "Weapon_M9.Magin" )},
	[4] = {time = 1.93, sound = Sound( "Weapon_M9.MagHit" )},
}
SWEP.Sounds["reloadempty"] = {
	[1] = {time = 0, sound = Sound( "Weapon_M9.Magrelease" )},
	[2] = {time = 0.23, sound = Sound( "Weapon_M9.Magout" )},
	[3] = {time = 1.16, sound = Sound( "Weapon_M9.Magin" )},
	[4] = {time = 1.93, sound = Sound( "Weapon_M9.MagHit" )},
	[5] = {time = 2.36, sound = Sound( "Weapon_M9.Boltrelease" )},
}

SWEP.FireModes = {"semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "pistol"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 95
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_m9beretta.mdl"
SWEP.WM = "models/weapons/w_m9beretta.mdl"
SWEP.WorldModel   = "models/weapons/w_m9beretta.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 15
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "9x19mm"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.65
SWEP.DeployAnimSpeed = 1.5
SWEP.HolsterAnimSpeed = 1.5

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.17
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon_M9.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.037
SWEP.AimCone = 0.017
SWEP.SpreadPerShot = 0.01
SWEP.MaxSpreadInc = 0.040
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.75
SWEP.Recoil = 0.72

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.ServersideSounds = false