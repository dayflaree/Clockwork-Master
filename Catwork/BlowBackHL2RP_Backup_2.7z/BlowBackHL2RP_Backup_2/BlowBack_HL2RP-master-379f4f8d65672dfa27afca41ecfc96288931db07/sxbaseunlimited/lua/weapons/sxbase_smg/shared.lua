if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = false
end

if CLIENT then
    SWEP.PrintName = "MP7A1"
    SWEP.Slot = 3
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-6.441, 0, 1.039)
	SWEP.AimAng = Vector(0, 0, 0)

	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = "smg1"
	SWEP.ShellEjector = "1"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = true
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "4.6x30мм"
end
SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleOffset = -9
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_MP7.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster"
SWEP.Anims.Fire = "fire01"
SWEP.Anims.Fire_Aiming = "fire01"
SWEP.Anims.Fire_Empty = "fire01"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reload"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Universal.Draw" )},
}
SWEP.Sounds["holster"] = {
	[1] = {time = 0, sound = Sound( "Universal.Holster" )},
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0, sound = Sound( "weapons/smg1/smg1_reload.wav" )},
}


SWEP.FireModes = {"semi","auto"}

SWEP.Category = "SXBase Weapons [MP7]"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "smg"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 70
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_smg1.mdl"
SWEP.WM = "models/weapons/w_smg1.mdl"
SWEP.WorldModel   = "models/weapons/w_smg1.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 45
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "smg1"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.75
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.25

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.075
SWEP.Damage = 18
SWEP.FireSound = Sound( "weapons/smg1/smg1_fire1.wav" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.04
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 5
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.65
SWEP.Recoil = 0.5

-- Reload related
SWEP.ReloadTime = 1
SWEP.ReloadTime_Empty = 1
