if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
    SWEP.PrintName = "M40A1"
    SWEP.Slot = 4
    SWEP.SlotPos = 1
	
	SWEP.AimPos = Vector(-2.86, -6.8, 0.3)
	SWEP.AimAng = Vector(0.01, 0, 0)
	
	SWEP.YawMod = 0.1
	SWEP.ReloadCycleTime = 0.985

	
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3.2, 0.25)

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DSize = 0.022
	SWEP.Text3DRight = -3
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "7.62x51мм"
	SWEP.BoltReminderText = "[R] - ВЗВЕСТИ"
	SWEP.ShellEjector = "1"
	
	SWEP.SprintPos = Vector(5, -1, 1)
	SWEP.SprintAng = Vector(-15, 17.729, 0)

	SWEP.ReloadBobOffset = Angle(0,0,0)
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false


	SWEP.VModels = {
		["optic_standard"] = { model = "models/weapons/attachments/a_standard_m40.mdl", ent = NULL },
	}
	SWEP.WModels = {
		["optic_standard"] = { model = "models/weapons/attachments/w_flipup_m40.mdl", ent = NULL },
	}
end

SWEP.MuzzleEffect = "muzzleflash_m14"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 7.62
SWEP.CaseLength = 51
SWEP.EmptySound = Sound("Weapon_M40A1.Empty")

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Fire = "fire_start"
SWEP.Anims.Cock = "fire_end"
SWEP.Anims.Idle = "idle"
SWEP.Anims.Reload_Start = "reload_start"
SWEP.Anims.Reload_Insert = "reload_insert"
SWEP.Anims.Reload_End = "reload_end"
SWEP.Anims.Fire_Aiming = "iron_fire_start"
SWEP.Anims.Cock_Aim = "iron_fire_end"
SWEP.Anims.Idle_Aim = "idle"

SWEP.Sounds = {}
SWEP.Sounds["fire_end"] = {
	[1] = {time = 0.23, sound = Sound("Weapon_m40a1.BoltRelease")},
	[2] = {time = 0.43, sound = Sound("Weapon_m40a1.Boltback")},
	[3] = {time = 0.8, sound = Sound("Weapon_m40a1.Boltforward")},
	[4] = {time = 0.93, sound = Sound("Weapon_m40a1.BoltLatch")},
}
SWEP.Sounds["reload_start"] = {
	[1] = {time = 0.16, sound = Sound("Weapon_m40a1.BoltRelease")},
	[2] = {time = 0.36, sound = Sound("Weapon_m40a1.Boltback")},
}
SWEP.Sounds["reload_insert"] = {
	[1] = {time = 0.4, sound = Sound("Weapon_M40A1.Roundin")},
}
SWEP.Sounds["reload_end"] = {
	[1] = {time = 0.2, sound = Sound("Weapon_m40a1.Boltforward")},
	[2] = {time = 0.36, sound = Sound("Weapon_m40a1.BoltLatch")},
}
SWEP.Sounds["reload_end_empty"] = {
	[1] = {time = 0.2, sound = Sound("Weapon_m40a1.Boltforward")},
	[2] = {time = 0.36, sound = Sound("Weapon_m40a1.BoltLatch")},
}
SWEP.Sounds["iron_fire_end"] = {
	[1] = {time = 0.26, sound = Sound("Weapon_m40a1.BoltRelease")},
	[2] = {time = 0.46, sound = Sound("Weapon_m40a1.Boltback")},
	[3] = {time = 0.8, sound = Sound("Weapon_m40a1.Boltforward")},
	[4] = {time = 0.96, sound = Sound("Weapon_m40a1.BoltLatch")},
}

SWEP.FireModes = {"bolt"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "smg"

SWEP.ViewModelFOV    = 80
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_m40a1.mdl"
SWEP.WM = "models/weapons/w_m40a1.mdl"
SWEP.WorldModel   = "models/weapons/w_m40a1.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 5
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "7.62x51MM"
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.45
SWEP.DeployTime = 0.45
SWEP.HolsterTime = 0.5

SWEP.ReloadState = 0
SWEP.ReloadStateWait = 0

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.2
SWEP.Damage = 25
SWEP.FireSound = Sound("Weapon_M40A1.Fire")
SWEP.UseHands = true
SWEP.CockAfterShot = true
SWEP.Cocked = true

-- Accuracy related
SWEP.HipCone = 0.06
SWEP.AimCone = 0.0005
SWEP.SpreadPerShot = 0.015
SWEP.MaxSpreadInc = 0.045
SWEP.SpreadCooldown = 0.5
SWEP.VelocitySensitivity = 2.2
SWEP.AimFOV = 5

-- Recoil related
SWEP.ViewKick = 1.8
SWEP.Recoil = 2

-- Reload related
SWEP.InsertEmpty = 3
SWEP.InsertTime = 0.7
SWEP.ReloadStartTime = 0.55
SWEP.ReloadAdvanceTimeEmpty = 1.4
SWEP.ReloadAdvanceTimeLast = 1.1
SWEP.ReloadEndTime = 0.5
SWEP.ReloadAbortTime = 0.7
SWEP.CantChamber = true
SWEP.CockAfterShot = true
SWEP.Cocked = true
SWEP.CockTime = 1.25
SWEP.CockTime_Nomen = 1

SWEP.CockTime_Bipod = 1
SWEP.CockTime_Bipod_Nomen = 0.75

local CT, mag, ammo

function SWEP:Reload()
	CT = CurTime()
	
	if CT < self.ReloadWait then
		return
	end
	
	if self.ReloadDelay and CT < self.ReloadDelay then
		return
	end

	if self.Owner:KeyDown(IN_USE) then
		self:CycleFiremodes()
		return
	end

	if self.ReloadState != 0 then
		return
	end
	
	if self.CockAfterShot and not self.Cocked then
		if self.dt.Status == FAS_STAT_ADS then
			SXBASE_PlayAnim(self, self.Anims.Cock_Aim)
			self.Cocked = true
		else
			SXBASE_PlayAnim(self, self.Anims.Cock)
			self.Cocked = true
		end
		if CLIENT then
			self:BoltShellEject()
		end

		self:SetNextPrimaryFire(CT + self.CockTime)
		self:SetNextSecondaryFire(CT + self.CockTime)
		self.SprintWait = CT + self.CockTime
		self.ReloadWait = CT + self.CockTime
		self.BipodDelay = CT + self.CockTime
	
		return
	end
	
	mag = self:Clip1()
	
	if mag >= self.Primary.ClipSize or self.Owner:GetAmmoCount(self.Primary.Ammo) == 0 then
		if SERVER and game.SinglePlayer() then
			SendUserMessage("SXBASE_CHECKWEAPON", self.Owner)
		end
		
		if CLIENT then
			self.CheckTime = CT + 0.5
		end
		
		return
	end
	
	self.dt.Status = FAS_STAT_IDLE

	self.ReloadState = 1
	self.ReloadStateWait = CT + self.ReloadStartTime
	mag = self:Clip1()
	ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
	
	if mag < self.Primary.ClipSize and ammo > 0 then
		CT = CurTime()
		self.dt.Status = FAS_STAT_IDLE
		
		SXBASE_PlayAnim(self, self.Anims.Reload_Start, 1, 0)
		self:DelayMe(CT + self.ReloadStartTime)
		self.ReloadStateWait = CT + self.ReloadStartTime
		self.ReloadState = 2

		self.Owner:SetAnimation(PLAYER_RELOAD)
	end
end

function SWEP:InsertAmmo(amt)
	amt = amt or 1
	self:SetClip1(self:Clip1() + amt)
	self.Owner:RemoveAmmo(amt, self.Primary.Ammo)
end

function SWEP:ShotgunThink()
	if IsFirstTimePredicted() then
		CT = CurTime()
		
		if CT > self.ReloadStateWait then
			if self.ReloadState == 2 then
				mag = self:Clip1()
				ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
				
				if mag < self.Primary.ClipSize and ammo > 0 then
					SXBASE_PlayAnim(self, self.Anims.Reload_Insert, 1, 0)
					self.ReloadStateWait = CT + self.InsertTime
					
					self:InsertAmmo()
					if SERVER then self.Owner:RestartGesture(PLAYER_RELOAD) end
				else
					self.ReloadState = 3
				end
			elseif self.ReloadState == 3 then
				SXBASE_PlayAnim(self, self.Anims.Reload_End, 1, 0)
				self:DelayMe(CT + self.ReloadEndTime)
				self.ReloadStateWait = CT + self.ReloadEndTime

				self.ReloadState = 0
			elseif self.ReloadState == 4 then
				SXBASE_PlayAnim(self, self.Anims.Reload_Start, 1, 0)
				self.ReloadStateWait = CT + self.ReloadStartTime
				
				self.ReloadState = 2
			end
		end
	end
end

if CLIENT then
	function SWEP:BoltShellEject()
		timer.Simple(0.25, function()
			if IsValid(self) then
				att = self.ViewModelEnt:GetAttachment(self.ViewModelEnt:LookupAttachment("shell"))
				dir = att.Ang:Forward()
				ang = EyeAngles()
	
				SXBASE_MakeFakeShell("7.62x51", att.Pos + att.Ang:Right() * 4, ang, dir * 100 + self.Owner:GetVelocity(), 0.5, 5)
			end
		end)
	end
end