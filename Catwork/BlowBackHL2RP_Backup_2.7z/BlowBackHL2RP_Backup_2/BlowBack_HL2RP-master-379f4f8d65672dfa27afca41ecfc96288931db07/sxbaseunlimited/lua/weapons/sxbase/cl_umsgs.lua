local ply, wep, anim, speed, CT, class, Mode, t, t2, mod, group, att, cyc, amt, ang

local function SXBASE_Animate(um)
	anim = um:ReadString()
	speed = um:ReadFloat()
	cyc = um:ReadFloat()
	wep = um:ReadEntity()
	ply = LocalPlayer()

	if IsValid(wep) and wep.IsSXBASEWeapon then
		SXBASE_PlayAnim(wep, anim, speed, cyc)
	end
end

usermessage.Hook("SXBASEANIM", SXBASE_Animate)

local function SXBASE_EndSounds()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		wep.CurSoundTable = nil
		wep.CurSoundEntry = nil
		wep.SoundTime = nil
		wep.SoundSpeed = 1
	end
end

usermessage.Hook("SXBASE_ENDSOUNDS", SXBASE_EndSounds)

local function SXBASE_WorldMuzzle( um )
	local ent = um:ReadEntity()
	if !IsValid(ent) then return end
	if !IsValid(ent.Owner) then return end

	if ent.Owner == LocalPlayer() then
		if !LocalPlayer():ShouldDrawLocalPlayer() then
			return
		end
	end

	local weapon, muz
	if not ent.HideWorldModel then
		weapon = ent.Weapon
	else
		weapon = ent.W_Wep
	end
	weapon:StopParticles()

	muz = weapon:GetAttachment(ent.MuzzleWorldID)
	
	if ent.MuzzleEffect then
		if ent.dt.Suppressed then
			ParticleEffectAttach(ent.MuzzleEffectSuppressed, PATTACH_POINT_FOLLOW, weapon, ent.MuzzleWorldID)
		else
			ParticleEffectAttach(ent.MuzzleEffect, PATTACH_POINT_FOLLOW, weapon, ent.MuzzleWorldID)
		end
	end
	
	if not ent.dt.Suppressed and muz then
		dlight = DynamicLight(ent:EntIndex())
		
		dlight.r = ent.MuzzleLight.r
		dlight.g = ent.MuzzleLight.g
		dlight.b = ent.MuzzleLight.b
		dlight.Brightness = 4
		dlight.Pos = muz.Pos + weapon:GetForward() * 3
		dlight.Size = 96
		dlight.Decay = 128
		dlight.DieTime = CurTime() + FrameTime()
	end
end
usermessage.Hook("SXBASE_WORLDMUZZLE", SXBASE_WorldMuzzle)

local function SXBASE_HitMarker()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		wep.HitMarkerTime = CurTime() + 0.2
		wep.HitMarkerAlpha = 255
	end
end

usermessage.Hook("SXBASE_HITMARKER", SXBASE_HitMarker)

local function SXBASE_Attach(um)
	group = um:ReadShort()
	att = um:ReadString()
	
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		t = wep.Attachments[group]
		
		t.active = att
		t.last[att] = true
		t2 = SXBASE_Attachments[att]
		
		if t2.aimpos then
			wep.AimPos = wep[t2.aimpos]
			wep.AimAng = wep[t2.aimang]
			wep.AimPosName = t2.aimpos
			wep.AimAngName = t2.aimang
		end
		
		if t.lastdeattfunc then
			t.lastdeattfunc(ply, wep)
		end
		
		if t2.clattfunc then
			t2.clattfunc(ply, wep)
		end
		
		t.lastdeattfunc = t2.cldeattfunc
		
		wep:AttachBodygroup(att)
		surface.PlaySound("cstm/attach.wav")
	end
end

usermessage.Hook("SXBASE_ATTACH", SXBASE_Attach)

local function SXBASE_Detach(um)
	group = um:ReadShort()
	
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		t = wep.Attachments[group]
		t.last = {}
		
		if t.sight then
			wep.AimPos = wep.AimPos_Orig
			wep.AimAng = wep.AimAng_Orig
			wep.AimPosName = "AimPos"
			wep.AimAngName = "AimAng"
		end

		if t.lastdeattfunc then
			t.lastdeattfunc(ply, wep)
		end
		
		t.lastdeattfunc = nil
		
		wep:DetachBodygroup(group)
		t.active = nil
		surface.PlaySound("cstm/detach.wav")
	end
end

usermessage.Hook("SXBASE_DETACH", SXBASE_Detach)

local function SXBASE_UpdateSpread()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		CT = CurTime()
		mod = ply:Crouching() and 0.75 or 1
		
		//SXBASE_StartRecoil(wep.ViewKick * 0.5, 0, 0.2)
		//SXBASE_StartADSR(0.1, 0.1, 0.1, 0.1, 0, wep.ViewKick)
			
		wep.CheckTime = 0
		wep.SpreadWait = CT + wep.SpreadCooldown
		
		if wep.BurstAmount > 0 then
			wep.AddSpread = math.Clamp(wep.AddSpread + wep.SpreadPerShot * mod * 0.5, 0, wep.MaxSpreadInc)
			wep.AddSpreadSpeed = math.Clamp(wep.AddSpreadSpeed - 0.2 * mod * 0.5, 0, 1)
		else
			wep.AddSpread = math.Clamp(wep.AddSpread + wep.SpreadPerShot, 0, wep.MaxSpreadInc)
			wep.AddSpreadSpeed = math.Clamp(wep.AddSpreadSpeed - 0.2, 0, 1)
		end
		
		if wep.CockAfterShot then
			wep.Cocked = false
		end
		
		wep:CreateMuzzle()
	
		if wep.Shell and wep.CreateShell then
			wep:CreateShell()
		end
	end
end

usermessage.Hook("SXBASESPREAD", SXBASE_UpdateSpread)

local function SXBASE_MuzzleFlash()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		wep:CreateMuzzle()
	end
end

usermessage.Hook("SXBASEMUZZLE", SXBASE_MuzzleFlash)

local function SXBASE_CockRemind()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		wep.CockRemindTime = CurTime() + 1
	end
end

usermessage.Hook("SXBASE_COCKREMIND", SXBASE_CockRemind)

local function SXBASE_DeployAngle(um)
	ang = um:ReadAngle()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(wep) and wep.IsSXBASEWeapon then
		wep.DeployAngle = ang
	end
end

usermessage.Hook("SXBASE_DEPLOYANGLE", SXBASE_DeployAngle)

local function SXBASE_ReceiveFireMode(um)
	ply = um:ReadEntity()
	Mode = um:ReadString()
	
	if not IsValid(ply) then
		return
	end
	
	wep = ply:GetActiveWeapon()
	
	wep.FireMode = Mode
	
	if IsValid(ply) and IsValid(wep) then
		if wep.FireModeNames then
			t = wep.FireModeNames[Mode]
			
			wep.Primary.Automatic = t.auto
			wep.BurstAmount = t.burstamt
			wep.FireModeDisplay = t.display
			wep.CheckTime = CurTime() + 2
			wep.FireModeSwitchTime = CurTime() + 0.6
			
			if ply == LocalPlayer() then
				ply:EmitSound("SXBASE_Switch", 70, 100)
			end
		end
	end
end

usermessage.Hook("SXBASE_FIREMODE", SXBASE_ReceiveFireMode)

local function SXBASE_CheckWeapon()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(ply) and IsValid(wep) then
		wep.CheckTime = CurTime() + 0.5
	end
end

usermessage.Hook("SXBASE_CHECKWEAPON", SXBASE_CheckWeapon)

local function SXBASE_M24BoltShellEject()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	if IsValid(ply) and IsValid(wep) then
		timer.Simple(0.25, function()
			wep:CreateShell("7.62x51")
		end)
	end
end

usermessage.Hook("SXBASE_M24BOLTSHELLEJECT", SXBASE_M24BoltShellEject)

local function SXBASE_MakeLiveSKSRounds(um)
	t = um:ReadFloat()
	amt = um:ReadShort()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	wep:MakeLiveSKSRounds(t, amt)
end

usermessage.Hook("SXBASE_MAKELIVESKSROUNDS", SXBASE_MakeLiveSKSRounds)

local function SXBASE_SKSStripper(um)
	t = um:ReadFloat()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	wep:MakeSKSStripper(t)
end

usermessage.Hook("SXBASE_SKSSTRIPPER", SXBASE_SKSStripper)

local function SXBASE_EjectFromCylinder(um)
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	amt = 5 - wep:Clip1()
	
	wep:EjectFromCylinder(amt, wep["EjectTime_" .. amt])
end

usermessage.Hook("SXBASE_EJECTFROMCYLINDER", SXBASE_EjectFromCylinder)

local function SXBASE_EjectFromCylinderNomen(um)
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	amt = 5 - wep:Clip1()
	
	wep:EjectFromCylinder(amt, wep["EjectTime_" .. amt .. "_Nomen"])
end

usermessage.Hook("SXBASE_EJECTFROMCYLINDERNOMEN", SXBASE_EjectFromCylinderNomen)

local function SXBASE_MakePumpShell(um)
	t = um:ReadFloat()
	ply = LocalPlayer()
	wep = ply:GetActiveWeapon()
	
	wep:MakePumpShell()
end

usermessage.Hook("SXBASE_MAKEPUMPSHELL", SXBASE_MakePumpShell)

local function SXBASE_PullPin()
	SXBASE_PullGrenadePin() -- 2 separate funcs, don't get confused yo
end

usermessage.Hook("SXBASE_PULLPIN", SXBASE_PullPin)

local function SXBASE_ThrowNade()
	SXBASE_ThrowGrenade() -- same as before
end

usermessage.Hook("SXBASE_THROWGRENADE", SXBASE_ThrowNade)

local function SXBASE_DeployGrenade()
	SXBASE_DrawGrenade() -- and again
end

usermessage.Hook("SXBASE_DRAWGRENADE", SXBASE_DeployGrenade)