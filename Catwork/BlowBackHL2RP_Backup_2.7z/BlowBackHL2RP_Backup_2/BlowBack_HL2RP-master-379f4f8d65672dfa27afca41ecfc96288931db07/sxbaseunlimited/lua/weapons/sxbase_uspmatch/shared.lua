﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = false
end

if CLIENT then
    SWEP.PrintName = "USP Match"
    SWEP.Slot = 2
    SWEP.SlotPos = 0
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-3.082,-2,0.85)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, -7, -6.69)
	SWEP.SprintAng = Vector(55, 0, 0)
	SWEP.MoveType = 2
	SWEP.Shell = "9x19"
	SWEP.ShellEjector = "eject"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobOffset = Angle(0,0,0)
	SWEP.NoShowAimCrossshair = true

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.AmmoText = "9x19мм"
end

SWEP.MuzzleEffect = "muzzleflash_pistol"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon.COAR2.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "draw_empty"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Holster_Empty = "holster_empty"
SWEP.Anims.Fire = {"fire1","fire2","fire3"}
SWEP.Anims.Fire_Aiming = "iron_fire1"
SWEP.Anims.Fire_Last = "firelast"
SWEP.Anims.Fire_Aiming_Last = "iron_firelast"
SWEP.Anims.Idle = "iron_idle"
SWEP.Anims.Idle_Empty = "iron_idle_empty"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reload_empty"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Weapon.UspMatch.Cloth" )},
	[2] = {time = 0.55, sound = Sound( "Weapon.UspMatch.SlideBack" )},
	[3] = {time = 0.63, sound = Sound( "Weapon.UspMatch.SlideRelease" )},
}
SWEP.Sounds["draw_empty"] = {
	[1] = {time = 0, sound = Sound( "Weapon.UspMatch.Cloth" )}
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0, sound = Sound( "Weapon.UspMatch.Cloth" )},
	[2] = {time = 0.55, sound = Sound( "Weapon.UspMatch.ClipOut" )},
	[3] = {time = 0.63, sound = Sound( "Weapon.UspMatch.ClipIn" )},
	[4] = {time = 0.9, sound = Sound( "Weapon.UspMatch.Cloth" )}
}
SWEP.Sounds["reload_empty"] = {
	[1] = {time = 0, sound = Sound( "Weapon.UspMatch.Cloth" )},
	[2] = {time = 0.55, sound = Sound( "Weapon.UspMatch.ClipOut" )},
	[3] = {time = 0.63, sound = Sound( "Weapon.UspMatch.ClipIn" )},
	[4] = {time = 1.45, sound = Sound( "Weapon.UspMatch.SlideRelease" )}
}

SWEP.FireModes = {"semi"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "pistol"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 90
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_uspmatch.mdl"
SWEP.WM = "models/weapons/w_uspmatch.mdl"
SWEP.WorldModel   = "models/weapons/w_uspmatch.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 18
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "9x19mm"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1.5

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.12
SWEP.Damage = 16
SWEP.FireSound = Sound( "Weapon.UspMatch.Fire" )
SWEP.UseHands = true
-- Accuracy related
SWEP.HipCone = 0.035
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.035
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.4
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.75
SWEP.Recoil = 0.6

-- Reload related
SWEP.ReloadTime = 1.9
SWEP.ReloadTime_Empty = 1.9

SWEP.ServersideSounds = true