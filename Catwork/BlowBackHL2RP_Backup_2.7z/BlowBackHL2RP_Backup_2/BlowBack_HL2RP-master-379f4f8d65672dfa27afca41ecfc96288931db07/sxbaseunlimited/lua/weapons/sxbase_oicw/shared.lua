﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = false
end

if CLIENT then
    SWEP.PrintName = "XM29 OICW"
    SWEP.Slot = 3
    SWEP.SlotPos = 2
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-2.315,-6,0.37)
	SWEP.AimAng = Vector(0.24, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = "7.62x51"
	SWEP.ShellEjector = "1"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = false
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.PitchMod = 0.3
	SWEP.YawMod = 0.3

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DForward = -7
	SWEP.Text3DSize = 0.03
	SWEP.AmmoText = "5.56x45мм"
	
	SWEP.RenderMaterial = Material("models/weapons/optics/lense_rt")
	SWEP.RenderTarget = GetRenderTarget( "_lense_rt", 1000 - 12, 1000 - 12, false )
	SWEP.RenderMaterial:SetTexture("$basetexture", SWEP.RenderTarget)

	SWEP.AimBreathingIntensity = 1
	SWEP.CurBreatheIntensity = 1
	SWEP.BreathLeft = 1
	SWEP.BreathRegenRate = 0.125
	SWEP.BreathDrainRate = 0.1
	SWEP.BreathIntensityDrainRate = 1
	SWEP.BreathIntensityRegenRate = 2
	SWEP.BreathHoldVelocityMinimum = 30 -- if our velocity surpasses this, we can't hold our breath
	SWEP.BreathDelay = 0.8
	SWEP.BreathRegenDelay = 0.5
	SWEP.MinimumBreathPercentage = 0.5 -- we can only hold our breath if our breath meter surpasses this
	SWEP.BreathIntensityOnRest = 0.5
	SWEP.BreathIntensityOnBipod = 0.2
	SWEP.BreathIntensitySwitchRate = 2 -- speed at which it switches from regular state to resting-weapon-on-something state (resting weapon/deployed bipod)
	SWEP.breathWait = 0
	SWEP.breathRegenWait = 0
	SWEP.breathReleaseWait = 0
end

SWEP.HasScope = true
SWEP.MuzzleEffect = "muzzleflash_smg"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_AK74.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Fire = "fire01"
SWEP.Anims.Fire_Aiming = "fire01"
SWEP.Anims.Idle = "idle01"
SWEP.Anims.Idle_Aim = "idle01"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reload"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Universal.Draw" )},
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0.001, sound = Sound("weapons/1oicw/ar2_reload2.wav")},
}

SWEP.FireModes = {"semi","auto","2burst"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "AleXXX_007"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "ar2"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 60
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/leakwep/v_o1c4.mdl"
SWEP.WM = "models/leakwep/w_o1c4.mdl"
SWEP.WorldModel   = "models/leakwep/w_o1c4.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 30
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "5.56x45MM"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.HolsterTime = 0.5
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.075
SWEP.Damage = 30
SWEP.FireSound = "weapons/1oicw/ar1_1.wav"
SWEP.UseHands = false

-- Accuracy related
SWEP.HipCone = 0.05
SWEP.AimCone = 0.01
SWEP.SpreadPerShot = 0.01
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadCooldown = 0.1
SWEP.VelocitySensitivity = 1.8
SWEP.AimFOV = 25

-- Recoil related
SWEP.ViewKick = 0.5
SWEP.Recoil = 0.025

-- Reload related
SWEP.ReloadTime = 2
SWEP.ReloadTime_Empty = 2

if CLIENT then
	function SWEP:reduceBreathAmount(recoilMod, regenTime)
		recoilMod = recoilMod or 0.2
		regenTime = regenTime or self.BreathRegenDelay
		
		self.breathRegenWait = CurTime() + regenTime
		self.BreathLeft = math.Clamp(self.BreathLeft - self.Recoil * recoilMod * 0.25, 0, 1)
	end

	function SWEP:stopHoldingBreath(time, regenTime, recoilMod)
		if self.holdingBreath then
			time = time or self.BreathDelay
			regenTime = regenTime or self.BreathRegenDelay
			
			self.holdingBreath = false
			self.breathWait = CurTime() + time
			self:reduceBreathAmount(recoilMod) -- if we're aiming, reduce it by using the recoilMod variable passed on to us
			surface.PlaySound("ins2/focus_inhale.wav")
		else
			self.breathRegenWait = CurTime() + 0.2
		end
	end

	function SWEP:BoltShellEject()
		timer.Simple(0.25, function()
			if IsValid(self) then
				att = self.ViewModelEnt:GetAttachment(self.ViewModelEnt:LookupAttachment("shell"))
				dir = att.Ang:Forward()
				ang = EyeAngles()
	
				SXBASE_MakeFakeShell("7.62x51", att.Pos + att.Ang:Right() * 4, ang, dir * 100 + self.Owner:GetVelocity(), 0.5, 5)
			end
		end)
	end

	local FT, CT, vm, att, cyc, seq, vel, cos1, cos2, intensity
	local Ang0, curang, curviewbob = Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0)

	SWEP.LerpBackSpeed = 10

	function SWEP:CalcView(ply, pos, ang, fov)
		fov = fov or GetConVarNumber("fov_desired")
		
		FT, CT = FrameTime(), CurTime()
		vm = self.ViewModelEnt
		att = vm:GetAttachment(vm:LookupAttachment((self.MuzzleName and self.MuzzleName or "muzzle")))
		seq = vm:GetSequenceName(vm:GetSequence())
		cyc = vm:GetCycle()
		intensity = GetConVarNumber("sxbase_headbob_intensity")
		
		if !self.ReloadBobDisabled then
			if att then
				if self.CurAnim and (self.CurAnim:find("reload") or self.AnimOverride and self.AnimOverride[self.CurAnim]) then
					if cyc <= 0.9 then
						self.LerpBackSpeed = 1
						ang = ang * 1
						curang = LerpAngle(FT * 10, curang, (ang - (att.Ang - self.ReloadBobOffset)) * 0.1)
					else
						self.LerpBackSpeed = math.Approach(self.LerpBackSpeed, 10, FT * 50)
						curang = LerpAngle(FT * self.LerpBackSpeed, curang, Ang0)
					end
				else
					curang = LerpAngle(FT * 10, curang, Ang0)
				end
			
				ang:RotateAroundAxis(ang:Right(), curang.p * self.PitchMod)
				ang:RotateAroundAxis(ang:Up(), curang.r * self.YawMod)
			end
		end
		
		if self.dt.Status == FAS_STAT_ADS then
			local fov_mod = self.AimFOV

			if CurTime() > self:GetNextScopeTime() then
				if !self.DrawVMScope then
					self.DrawVMScope = true
				end
				if self:GetScopeZoom() == 1 then
					fov_mod = (fov - 33.3)
				elseif self:GetScopeZoom() == 2 then
					fov_mod = (fov - 10)
				elseif self:GetScopeZoom() == 0 then
					if self.DrawVMScope then
						self.DrawVMScope = false
					end
				end
			end

			self.CurFOVMod = Lerp(FT * 10, self.CurFOVMod, fov_mod)
		else
			self.CurFOVMod = Lerp(FT * 10, self.CurFOVMod, 0)
			if self.DrawVMScope then
				self.DrawVMScope = false
			end
		end
		
		fov = fov - self.CurFOVMod
		
		if intensity > 0 then -- don't calculate shit that's not on to save performance
			vel = self.Owner:GetVelocity():Length()

			if self.Owner:OnGround() and vel > self.Owner:GetWalkSpeed() * 0.3 then
				if vel < self.Owner:GetWalkSpeed() * 1.2 then
					cos1 = math.cos(CT * 15)
					cos2 = math.cos(CT * 12)
					curviewbob.p = cos1 * 0.15 * intensity
					curviewbob.y = cos2 * 0.1 * intensity
				else
					cos1 = math.cos(CT * 20)
					cos2 = math.cos(CT * 15)
					curviewbob.p = cos1 * 0.25 * intensity
					curviewbob.y = cos2 * 0.15 * intensity
				end
			else
				curviewbob = LerpAngle(FT * 10, curviewbob, Ang0)
			end
		end
		
		return pos, ang + curviewbob, fov
	end

	function SWEP:AdjustMouseSensitivity()
		if self.dt.Status == FAS_STAT_ADS then
			if self.Peeking then
				return 0.5
			end

			local var = { [0] = 1 * self.MouseSensMod * (self.dt.Bipod and 0.7 or 1), [1] = 0.444, [2] = 0.133 }
			return var[self:GetScopeZoom()] or 1
		end
			
		return 1 * self.MouseSensMod * (self.dt.Bipod and 0.7 or 1)
	end

	local scope_arc = Material("scope_arc.png","unlitgeneric")
	local scope_arc_ne = Material("scope_arc_ne.png","unlitgeneric")
	local scope_arc_nw = Material("scope_arc_nw.png","unlitgeneric")
	local scope_arc_sw = Material("scope_arc_sw.png","unlitgeneric")

	function SWEP:DrawHUD()
		if self.Owner == LocalPlayer() and !self.Owner:ShouldDrawLocalPlayer() then
			if self.dt.Status == FAS_STAT_ADS then
				if CurTime() > self:GetNextScopeTime() then
					local size = ScreenScale( 128 + 32 )
					local offset = 6
					surface.SetDrawColor( Color( 0, 100, 0, 100 ) )
					surface.DrawRect( 0, 0, ScrW(), ScrH() )

					surface.SetDrawColor( Color( 100, 255, 100, 255 ) )
					surface.SetMaterial( Material("effects/reticle") )
					surface.DrawTexturedRect( ScrW() / 2 - size / 8, ScrH() / 2 - size / 8, size / 4, size / 4 )
					
					surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
					surface.SetMaterial( scope_arc )
					surface.DrawTexturedRect( ScrW() / 2 - offset, ScrH() / 2 - offset, size, size )
					
					surface.SetMaterial( scope_arc_ne )
					surface.DrawTexturedRect( ScrW() / 2 - offset, ScrH() / 2 - size + offset, size, size )

					surface.SetMaterial( scope_arc_nw )
					surface.DrawTexturedRect( ScrW() / 2 - size + offset, ScrH() / 2 - size + offset, size, size )
					
					surface.SetMaterial( scope_arc_sw )
					surface.DrawTexturedRect( ScrW() / 2 - size + offset, ScrH() / 2 - offset, size, size )

					surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
					surface.DrawRect( ScrW() / 2 + size - offset, 0, ScrW() / 2 - size + offset, ScrH() )
					surface.DrawRect( 0 , 0, ScrW()/2 - size + offset, ScrH() )
					surface.DrawRect( ScrW() / 2 - size + offset, 0, ScrW() / 2 - offset + size, ScrH() / 2 + offset - size )
					surface.DrawRect( ScrW() / 2 - size + offset, ScrH() / 2 + size - offset, ScrW() / 2 - offset + size, ScrH() / 2 + offset - size )
				end
			end
		end
	end

	local old, x, y

	local function SX_RenderTarget()
		local ply = LocalPlayer()
		local wep = ply:GetActiveWeapon()
		if IsValid(wep) then
			if wep.HasScope then
				x, y = ScrW(), ScrH()
				render.SetViewPort( 0, 0, 1000 - 12, 1000 - 12 )
					render.SetRenderTarget( wep.RenderTarget )
						render.Clear( 0, 0, 0, 255 )
					render.SetRenderTarget( old )
				render.SetViewPort( 0, 0, x, y )

				if wep.RenderMaterial then
					wep.RenderMaterial:SetTexture("$basetexture", wep.RenderTarget)
				end
			end
		end
	end

	hook.Add("HUDPaint", "SX_RenderTarget", SX_RenderTarget)
end

function SWEP:SecondaryAttack()
	local CT = CurTime()
	if self.FireMode == "safe" then
		return
	end
	
	if not self.Owner:OnGround() then
		return
	end

	if self.ReloadState != 0 then
		return
	end
	
	if self.Owner:KeyDown(IN_USE) then
		return
	end
	
	if self.dt.Status == FAS_STAT_SPRINT or self.dt.Status == FAS_STAT_CUSTOMIZE or self.dt.Status == FAS_STAT_QUICKGRENADE then
		return
	end
	
	if self.dt.Status != FAS_STAT_ADS then
		self.dt.Status = FAS_STAT_ADS
		self:SetNextScopeTime( CurTime() + 0.05 )
		self:SetScopeZoom( 1 )
	else
		self:SetNextScopeTime( CurTime() - 0.05 )
		self.dt.Status = FAS_STAT_IDLE
		self:SetScopeZoom( 0 )
	end

	self:SetNextSecondaryFire(CT + 0.1)
	self.ReloadWait = CT + 0.3
	
	return 
end
