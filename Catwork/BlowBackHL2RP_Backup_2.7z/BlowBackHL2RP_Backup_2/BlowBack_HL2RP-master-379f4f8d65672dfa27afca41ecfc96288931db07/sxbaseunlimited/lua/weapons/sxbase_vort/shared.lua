﻿if SERVER then
	AddCSLuaFile("shared.lua")
	SWEP.CantChamber = true
end

if CLIENT then
    SWEP.PrintName = "Vortigaunt Magic"
    SWEP.Slot = 1
    SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	
	SWEP.AimPos = Vector(-6.42,-6,1)
	SWEP.AimAng = Vector(0, 0, 0)
	
	SWEP.SprintPos = Vector(1.2, 1, 0)
	SWEP.SprintAng = Vector(-12, 8, 0)
	SWEP.MoveType = 1
	SWEP.Shell = ""
	SWEP.ShellEjector = "1"
		
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3, 0.25)

	SWEP.ReloadBobDisabled = true
	SWEP.NoShowAimCrossshair = true
	SWEP.ShowAimCrossshairADS = false

	SWEP.MagText = "" 
	SWEP.Text3DForward = -3
	SWEP.Text3DRight = -3
	SWEP.Text3DSize = 0.025
	SWEP.AmmoText = ""
end
game.AddParticles("particles/Vortigaunt_FX.pcf")
PrecacheParticleSystem("vortigaunt_beam")
PrecacheParticleSystem("vortigaunt_beam_b")
PrecacheParticleSystem("vortigaunt_charge_token")
PrecacheParticleSystem("vortigaunt_beam_charge")

SWEP.MuzzleEffect = "muzzleflash_smg"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5.45
SWEP.CaseLength = 39
SWEP.EmptySound = Sound( "Weapon_SMG1.Empty" )

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Draw_Empty = "draw"
SWEP.Anims.Holster = "idletolow"
SWEP.Anims.Holster_Empty = "idletolow"
SWEP.Anims.Fire = {"fire01","fire02","fire03"}
SWEP.Anims.Fire_Aiming = {"fire01","fire02","fire03"}
//SWEP.Anims.Fire_Last = "firelast"
//SWEP.Anims.Fire_Aiming_Last = "iron_firelast"
SWEP.Anims.Idle = "idle01"
SWEP.Anims.Reload = "reload"
SWEP.Anims.Reload_Empty = "reload"

SWEP.Sounds = {}
SWEP.Sounds["draw"] = {
	[1] = {time = 0, sound = Sound( "Weapon.UspMatch.Cloth" )},
}
SWEP.Sounds["reload"] = {
	[1] = {time = 0, sound = Sound( "Weapon_SMG1.Reload" )},
}

SWEP.FireModes = {"vortshoot","vortregen"}
SWEP.FireModeNames = {["vortshoot"] = {display = "BEAM ATTACK", auto = false, burstamt = 0},
	["vortregen"] = {display = "HEALTH REGENERATION", auto = true, burstamt = 0},
	["safe"] = {display = "ОПУЩЕН", auto = false, burstamt = 0}}	


SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "fist"
SWEP.RunHoldType = "normal"

SWEP.ViewModelFOV    = 50
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_pistol.mdl"
SWEP.WM = "models/weapons/w_smg1.mdl"
SWEP.WorldModel   = "models/weapons/w_smg1.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = -1
SWEP.Primary.DefaultClip    = -1
SWEP.Primary.Automatic       = true    
SWEP.Primary.Ammo             = "none"
SWEP.Primary.TracerName         = "Tracer"

-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.8
SWEP.DeployTime = 0.8
SWEP.DeployAnimSpeed = 1
SWEP.HolsterAnimSpeed = 1

-- Firing related
SWEP.Shots = 1
SWEP.FireDelay = 0.075
SWEP.Damage = 18
SWEP.FireSound = Sound( "Weapon_SMG1.Single" )
SWEP.UseHands = false
-- Accuracy related
SWEP.HipCone = 0.04
SWEP.AimCone = 0.015
SWEP.SpreadPerShot = 0.008
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadCooldown = 0.2
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 10

-- Recoil related
SWEP.ViewKick = 0.85
SWEP.Recoil = 0.75

-- Reload related
SWEP.ReloadTime = 1.4
SWEP.ReloadTime_Empty = 1.4

if SERVER then
	util.AddNetworkString("SXBASE_VORT_ANIM")
	util.AddNetworkString("SXBASE_VORT_BEAM")
	util.AddNetworkString("SXBASE_VORT_ARMBEAM")
else
	net.Receive("SXBASE_VORT_ANIM", function(len)
		local plyc = tonumber(net.ReadString())
		local ply = Entity(plyc)

		if IsValid(ply) then
			if ply:Alive() then
				ply:AddVCDSequenceToGestureSlot( GESTURE_SLOT_CUSTOM, ply:LookupSequence( "zapattack1" ), 0, true )
			end
		end
	end)
	net.Receive("SXBASE_VORT_BEAM", function(len)
		local ply = net.ReadEntity()
		local vec = net.ReadVector()

		if IsValid(ply) then
			if ply:Alive() then
				local attachment = ply:GetAttachment(ply:LookupAttachment("leftclaw"))
				local attachment2 = ply:GetAttachment(ply:LookupAttachment("rightclaw"))
				if attachment then
					util.ParticleTracerEx("vortigaunt_beam", attachment.Pos, vec, true, ply:EntIndex(), ply:LookupAttachment("leftclaw"))
				end
				if attachment2 then
					util.ParticleTracerEx("vortigaunt_beam", attachment2.Pos, vec, true, ply:EntIndex(), ply:LookupAttachment("rightclaw"))
				end
			end
		end
	end)
	net.Receive("SXBASE_VORT_ARMBEAM", function(len)
		local ply = net.ReadEntity()
		local vec = net.ReadVector()
		local vec2 = net.ReadVector()
		local att = tonumber(net.ReadString())

		if IsValid(ply) then
			if ply:Alive() then
				util.ParticleTracerEx("vortigaunt_beam_charge",vec,vec2,true,ply:EntIndex(),(att == 1) and ply:LookupAttachment("rightclaw") or ply:LookupAttachment("leftclaw"))
			end
		end
	end)
end

function SWEP:ArmBeam( side )
	local tr
	local flDist = 1.0
	local forward, right, up = self.Owner:GetForward(), self.Owner:GetRight(), self.Owner:GetUp()
	local vecSrc = self.Owner:GetPos() + up * 36 + right * side * 16 + forward * 32;

	for i = 1, 3 do
		local vecAim = forward * math.Rand( -1, 1 ) + right * side * math.Rand( 0, 1 ) + up * math.Rand( -1, 1 )
		local tr1 = util.TraceLine({
			start = vecSrc,
			endpos = vecSrc + vecAim * (10*12),
			filter = self.Owner,
			mask = MASK_SOLID
		})
				
		if tr1.HitSky then continue end

		if flDist > tr1.Fraction then
			tr = tr1
			flDist = tr.Fraction
		end
	end
	if flDist != 1.0 then
		local attachment = (side == 1) and self.Owner:GetAttachment(self.Owner:LookupAttachment("rightclaw")) or self.Owner:GetAttachment(self.Owner:LookupAttachment("leftclaw"))
		net.Start("SXBASE_VORT_ARMBEAM")
			net.WriteEntity(self.Owner)
			net.WriteVector(attachment.Pos)
			net.WriteVector(tr.HitPos)
			net.WriteString(tostring(side))
		net.Broadcast()
	end
end

local td, CT = {}, nil
function SWEP:PrimaryAttack()
	if not IsFirstTimePredicted() then
		return
	end

	if self.Cooking or self.FuseTime then
		return
	end

	if self.FireMode == "safe" then
		if IsFirstTimePredicted() then
			self:CycleFiremodes()
		end
		
		return
	end
	if !self.Owner:OnGround() then
		return
	end

	CT = CurTime() 

	self:SetNextPrimaryFire(CT + 3.1)
	self:SetNextSecondaryFire(CT + 3)

	ParticleEffectAttach("vortigaunt_charge_token", PATTACH_POINT_FOLLOW, self.Owner, self.Owner:LookupAttachment("leftclaw"))
	ParticleEffectAttach("vortigaunt_charge_token", PATTACH_POINT_FOLLOW, self.Owner, self.Owner:LookupAttachment("rightclaw"))

	if SERVER then
		self:ArmBeam( 1 )
		self:ArmBeam( -1 )

		self.Owner:Freeze( true)

		self.sndVortRC = CreateSound( self, Sound("NPC_Vortigaunt.ZapPowerup") )
		self.sndVortRC:Play()

		net.Start("SXBASE_VORT_ANIM")
			net.WriteString(self.Owner:EntIndex())
		net.Broadcast()
	end

	self.NextShootMagic = CurTime() + 1.5

	self.dt.Status = FAS_STAT_IDLE
end

function SWEP:ShotgunThink()
	if IsFirstTimePredicted() then
		local CT = CurTime()
		
		if self.NextShootMagic and CT > self.NextShootMagic then
			local tr = self.Owner:GetEyeTrace()

			self.Owner:StopParticles()

			if SERVER then
				self.sndVortRC:Stop()
				self.Owner:EmitSound(Sound("NPC_Vortigaunt.ClawBeam"))

				net.Start("SXBASE_VORT_BEAM")
					net.WriteEntity(self.Owner)
					net.WriteVector(tr.HitPos)
				net.Broadcast()

				local eff = EffectData()
				eff:SetOrigin(tr.HitPos)
				eff:SetMagnitude(0.3)
				eff:SetScale(2)
				eff:SetRadius(5)
				util.Effect("Sparks",eff)
				
				sound.Play( "npc/vort/vort_explode"..math.random(1,2)..".wav", tr.HitPos, 120, math.random(100,110), 0.9 )
				 
				util.BlastDamage(self.Owner, self.Owner, tr.HitPos, 10, 400)
			end
			self.NextShootMagic = nil
			self.NextShootMagicEnd = CurTime() + 1.25
		end
		if self.NextShootMagicEnd and CT > self.NextShootMagicEnd then
			if IsValid(self.Owner) then
				self.Owner:Freeze( false )
			end
			self.NextShootMagicEnd = nil
		end
	end
end

if CLIENT then
	local vm, EP, EA, FT, CT, TargetPos, TargetAng, cos1, cos2, sin1, sin2, vel, att, ang, delta, tan, mod, tr, dist, move, rs, pos, ang, wm, ong, iv, dif1, dif2, VM, ws, x, y
	local BlendSpeed, BlendType, ApproachSpeed = 8, 1, 10
	local AngMod, PosMod, Vec0, VecDown, BipodVec = Vector(0, 0, 0), Vector(0, 0, 0), Vector(0, 0, 0), Vector(0, 0, -10), Vector(1, 4, -1)
	local PeekVec
	local SprintPos, SprintAng, AngDif, AngleTable = Vector(4, -2.09, -0.24), Vector(-12.968, 47.729, 0), Angle(0, 0, 0), Angle(0, 0, 0)
	local td = {}
	local NadeTargetPos, NadeTargetAng
	local TargetPos, TargetAng = Vector(0, 0, 0), Vector(0, 0, 0)
	local Ang0 = Angle(0, 0, 0)

	SWEP.PSO1Glass = Material("models/weapons/view/accessories/Lens_EnvSolid")
	SWEP.ScopeRT = GetRenderTarget("sxbase_scope_rt", 512, 512, false)
	SWEP.AngleDelta2 = Angle(0, 0, 0)

	local math, draw, surface, cam, render = math, draw, surface, cam, render -- local look-ups are faster than global look-ups, saves a couple of milliseconds, M-MUH PERFORMANCE
	local ps2 = render.SupportsPixelShaders_2_0()

	local _Material			= Material("pp/toytown-top")
	_Material:SetTexture("$fbtexture", render.GetScreenEffectTexture())

	local reg = debug.getregistry()
	local Right = reg.Angle.Right
	local Up = reg.Angle.Up
	local Forward = reg.Angle.Forward
	local RotateAroundAxis = reg.Angle.RotateAroundAxis
	local GetBonePosition = reg.Entity.GetBonePosition
	local GetSequence = reg.Entity.GetSequence
	local GetSequenceName = reg.Entity.GetSequenceName

	local trace

	local Lerp, LerpVector, LerpAngle, EyePos, EyeAngles, FrameTime, CurTime, GetConVarNumber = Lerp, LerpVector, LerpAngle, EyePos, EyeAngles, FrameTime, CurTime, GetConVarNumber
	local blur = Material("pp/bokehblur")
	SWEP.BlurDist = 0
	SWEP.BlurStrength = 0
		
	function SWEP:PreDrawViewModel()
		render.SetBlend(0)
	end

	local veldepend = {pitch = 0, yaw = 0, roll = 0}
	local len
		
	function SWEP:PostDrawViewModel()
		render.SetBlend(0)
		VM, EP, EA, FT, CT = self.Owner:GetViewModel(), EyePos(), EyeAngles(), FrameTime(), CurTime()
		vel, ong = self.Owner:GetVelocity(), self.Owner:OnGround()
		len = vel:Length()
		
		AngleTable.p = EA.P
		AngleTable.y = EA.Y
		delta = AngleTable - self.OldDelta
			
		self.OldDelta.p = EA.p
		self.OldDelta.y = EA.y
		
		if not self.dt.Bipod then
			if self.SwayInterpolation == "linear" then
				self.AngleDelta = LerpAngle(math.Clamp(FT * 15, 0, 1), self.AngleDelta, delta)
				self.AngleDelta.y = math.Clamp(self.AngleDelta.y, -15, 15)
			else
				delta.p = math.Clamp(delta.p, -5, 5)
				self.AngleDelta2 = LerpAngle(math.Clamp(FT * 12, 0, 1), self.AngleDelta2, self.AngleDelta)
				AngDif.x = (self.AngleDelta.p - self.AngleDelta2.p)
				AngDif.y = (self.AngleDelta.y - self.AngleDelta2.y)
				self.AngleDelta = LerpAngle(math.Clamp(FT * 15, 0, 1), self.AngleDelta, delta + AngDif)
				self.AngleDelta.y = math.Clamp(self.AngleDelta.y, -25, 25)
			end
		else
			self.AngleDelta = LerpAngle(math.Clamp(FT * 15, 0, 1), self.AngleDelta, Ang0)
		end
		
		vm = self.ViewModelEnt
		
		EP, EA = EyePos(), EyeAngles() -- fresh eye angles and shit because we're going to modify shit
			
		if IsValid(vm) then
			iv = self.Owner.InVehicle and self.Owner:InVehicle() -- what retard overrides or removes InVehicle?
			
			if self.FirstDeploy then
				SXBASE_PlayAnim(self, self.Anims.Draw_First, 1, 0)
				self.FirstDeploy = false
			end
			
			if self.Owner.CurClass then
				if self.Owner.CurClass != self.Class then
					if not self.FirstDeploy then
						if GetSequenceName(vm, GetSequence(vm)) != self.Anims.Draw_First then
							self:PlayDeployAnim()
						end
					end
				end
			end
			
			self.Owner.CurClass = self.Class
			
			if iv then
				if not self.Vehicle then
					self:PlayHolsterAnim()
					self.Vehicle = true
					self:EmitSound("weapons/weapon_holster" .. math.random(1, 3) .. ".wav", 50, 100)
				end
			else
				if self.Vehicle then
					self:PlayDeployAnim()
					self.Vehicle = false
				end
			end
			
			if self.dt.Status == FAS_STAT_ADS then
				self.ViewModelFOV = Lerp(FT * 10, self.ViewModelFOV, self.TargetViewModelFOV)
			else
				self.ViewModelFOV = Lerp(FT * 10, self.ViewModelFOV, self.ViewModelFOV_Orig)
			end	
			
			if self.dt.Status != FAS_STAT_SPRINT then
				TargetPos = Vec0 * 1
				TargetAng = Vec0 * 1
				ApproachSpeed = 10
			end
			
			self.NearWall = false
			
			if self.dt.Status == FAS_STAT_ADS then
				if self.CanPeek and self.Peeking then
					if self.dt.Bipod then
						if self[self.AimPosName .. "_Bipod"] then
							TargetPos = (self[self.AimPosName .. "_Bipod"] + BipodVec) *1
						else
							TargetPos = (self.AimPos + BipodVec) * 1
						end
					else
						TargetPos = (self.AimPos + BipodVec) * 1
					end
				else
					TargetPos = (self.dt.Bipod and self[self.AimPosName .. "_Bipod"] or self.AimPos) * 1
				end
				
				TargetAng = (self.dt.Bipod and self[self.AimAngName .. "_Bipod"] or self.AimAng) * 1
				
				BlendSpeed = Lerp(FT * 3, BlendSpeed, 15)
				self.SlowDownBlend = true
				move = math.Clamp(len / self.Owner:GetWalkSpeed(), 0, 1)
				
				if len > 30 and ong then
					cos1, sin1 = math.cos(CT * 8), math.sin(CT * 8)
					tan = math.atan(cos1 * sin1, cos1 * sin1)
					
					TargetAng[1] = TargetAng[1] + tan * 0.5 * move 
					TargetAng[2] = TargetAng[2] + cos1 * 0.25 * move 
					TargetAng[3] = TargetAng[3] + sin1 * 0.25 * move 
							
					TargetPos[1] = TargetPos[1] + sin1 * 0.05 * move 
					TargetPos[2] = TargetPos[2] + tan * 0.1 * move 
					TargetPos[3] = TargetPos[3] + tan * 0.05 * move 
				end
				
				AngMod = LerpVector(FT * 10, AngMod, Vec0)
				PosMod = LerpVector(FT * 10, PosMod, Vec0)
			elseif self.dt.Status == FAS_STAT_QUICKGRENADE then
				BlendSpeed = 2
				TargetPos = VecDown * 1
				TargetAng = Vec0 * 1
			elseif self.dt.Status == FAS_STAT_SPRINT then
				if self.SlowDownBlend then
					self.SlowDownBlend = false
					BlendSpeed = 5
				end
				
				rs = 250
				
				if self.FireMode == "safe" then
					cos1, sin1 = math.cos(CT * (8 + rs / 100)), math.sin(CT * (8 + rs / 100))
				else
					if self.MagCheck then
						cos1, sin1 = math.cos(CT * (8 + rs / 100)), math.sin(CT * (8 + rs / 100))
					else
						if self.MoveType == 2 or self.MoveType == 3 then
							cos1, sin1 = math.cos(CT * (8 + rs / 100)), math.sin(CT * (8 + rs / 100))
						else
							cos1, sin1 = math.cos(CT * (7 + rs / 100)), math.sin(CT * (7 + rs / 100))
						end
					end
				end
				
				move = math.Clamp(len / rs, 0, 1)
				
				if self.MagCheck then
					BlendSpeed = Lerp(FT * 3, BlendSpeed, 5)
					tan = math.atan(cos1 * sin1, cos1 * sin1)
					
					TargetPos = Vec0 * 1
					TargetAng = Vec0 * 1
					ApproachSpeed = 10

					TargetAng[1] = TargetAng[1] + tan * 4 * move
					TargetAng[2] = TargetAng[2] + cos1 * 5 * move
					TargetAng[3] = TargetAng[3] + sin1 * 4 * move
					
					TargetPos[1] = TargetPos[1] + sin1 * 0.75 * move
					TargetPos[2] = TargetPos[2] + tan * 0.6 * move
					TargetPos[3] = TargetPos[3] + tan * move
				else
					BlendSpeed = Lerp(FT * 3, BlendSpeed, 9)
					
					--TargetPos = (self.SprintPos and self.SprintPos or Vector(4, -2.09, -0.24)) * 1
					--TargetAng = (self.SprintAng and self.SprintAng or Vector(-12.968, 47.729, 0)) * 1
					
					if self.FireMode == "safe" and !self.IsHL2Melee then
						tan = math.atan(cos1 * sin1, cos1 * sin1)
						AngMod[1] = Lerp(FT * 15, AngMod[1], tan * 7.5 * move)
						AngMod[2] = Lerp(FT * 15, AngMod[2], sin1 * 3 * move)
						AngMod[3] = Lerp(FT * 15, AngMod[3], tan * -5 * move)
						PosMod[1] = Lerp(FT * 15, PosMod[1], tan * 2.5 * move)
						PosMod[2] = Lerp(FT * 15, PosMod[2], sin1 * 2 * move)
						PosMod[3] = Lerp(FT * 15, PosMod[3], math.atan(cos1, sin1) * 5 * move)
							
						if self.SafePosType == "pistol" then
							TargetPos = self.PistolSafePos * 1
							TargetAng = self.PistolSafeAng * 1
						else
							TargetPos = self.RifleSafePos * 1
							TargetAng = self.RifleSafeAng * 1
						end
					else
						if self.MoveType == 2 then
							tan = math.atan(cos1 * sin1, cos1 * sin1)
							
							AngMod[1] = Lerp(FT * 15, AngMod[1], tan * 6 * move)
							AngMod[2] = Lerp(FT * 15, AngMod[2], cos1 * 1.5 * move)
							AngMod[3] = Lerp(FT * 15, AngMod[3], cos1 * -4 * move)
							PosMod[1] = Lerp(FT * 15, PosMod[1], tan * 4 * move)
							PosMod[2] = Lerp(FT * 15, PosMod[2], cos1 * 2 * move)
							PosMod[3] = Lerp(FT * 15, PosMod[3], math.atan(cos1, sin1) * 5 * move)
						elseif self.MoveType == 3 then
							tan = math.atan(cos1 * sin1, cos1 * sin1)
							AngMod[1] = Lerp(FT * 15, AngMod[1], tan * 4 * move)
							AngMod[2] = Lerp(FT * 15, AngMod[2], sin1 * 1.5 * move)
							AngMod[3] = Lerp(FT * 15, AngMod[3], tan * -4 * move)
							PosMod[1] = Lerp(FT * 15, PosMod[1], tan * 2 * move)
							PosMod[2] = Lerp(FT * 15, PosMod[2], sin1 * 2 * move)
							PosMod[3] = Lerp(FT * 15, PosMod[3], math.atan(cos1, sin1) * 5 * move)
						else
							AngMod[1] = Lerp(FT * 15, AngMod[1], cos1 * -2.5 * move)
							AngMod[2] = Lerp(FT * 15, AngMod[2], sin1 * -1.5 * move)
							AngMod[3] = Lerp(FT * 15, AngMod[3], sin1 * -1.5 * move)
							PosMod[1] = Lerp(FT * 15, PosMod[1], math.atan(cos1, sin1) * 3 * move)
							PosMod[2] = Lerp(FT * 15, PosMod[2], cos1 * 5 * move)
							PosMod[3] = Lerp(FT * 15, PosMod[3], sin1 * cos1 * 9 * move)
						end

						if self.MoveType == 1 then
							TargetPos[1] = math.Approach(TargetPos[1], (self.SprintPos and self.SprintPos[1] or 4), FT * 25 + math.Clamp(tan, -0.4, 0.1))
							TargetPos[2] = math.Approach(TargetPos[2], (self.SprintPos and self.SprintPos[2] or -2.09), FT * 25 + math.Clamp(cos1, 0, 0.2))
							TargetPos[3] = math.Approach(TargetPos[3], (self.SprintPos and self.SprintPos[3] or -0.24), FT * 25 + math.Clamp(cos1, 0, 0.4))
						
							TargetAng[1] = math.Approach(TargetAng[1], (self.SprintAng and self.SprintAng[1] or -12.968), FT * ApproachSpeed)
							TargetAng[2] = math.Approach(TargetAng[2], (self.SprintAng and self.SprintAng[2] or 47.729), FT * ApproachSpeed)
							TargetAng[3] = math.Approach(TargetAng[3], (self.SprintAng and self.SprintAng[3] or 0), FT * ApproachSpeed)
							ApproachSpeed = math.Approach(ApproachSpeed, 100, FT * 200)
						elseif self.MoveType == 2 then
							TargetPos[1] = math.Approach(TargetPos[1], (self.SprintPos and self.SprintPos[1] or 4), FT * 15)
							TargetPos[2] = math.Approach(TargetPos[2], (self.SprintPos and self.SprintPos[2] or -2.09), FT * 15)
							TargetPos[3] = math.Approach(TargetPos[3], (self.SprintPos and self.SprintPos[3] or -0.24), FT * 21)
						
							TargetAng[1] = math.Approach(TargetAng[1], (self.SprintAng and self.SprintAng[1] or -12.968), FT * ApproachSpeed)
							TargetAng[2] = math.Approach(TargetAng[2], (self.SprintAng and self.SprintAng[2] or 47.729), FT * ApproachSpeed)
							TargetAng[3] = math.Approach(TargetAng[3], (self.SprintAng and self.SprintAng[3] or 0), FT * ApproachSpeed)
							ApproachSpeed = math.Approach(ApproachSpeed, 300, FT * 600)
						else
							TargetPos = (self.SprintPos and self.SprintPos or SprintPos) * 1
							TargetAng = (self.SprintAng and self.SprintAng or SprintAng) * 1
						end
					end
					
					//AngMod[1] = Lerp(FT * 15, AngMod[1], cos1 * -2.5)
					//AngMod[2] = Lerp(FT * 15, AngMod[2], sin1 * -1.5)
					//AngMod[3] = Lerp(FT * 15, AngMod[3], sin1 * -1.5)
					//PosMod[1] = Lerp(FT * 15, PosMod[1], math.atan(cos1, sin1) * 3)
					//PosMod[2] = Lerp(FT * 15, PosMod[2], cos1 * 5)
					//PosMod[3] = Lerp(FT * 15, PosMod[3], sin1 * cos1 * 9)
				end
			else
				if self.dt.Status == FAS_STAT_CUSTOMIZE then
					TargetPos = self.CustomizePos * 1
					TargetAng = self.CustomizeAng * 1
				else
					if self.FireMode == "safe" then
						if self.SafePosType == "pistol" then
							TargetPos = self.PistolSafePos * 1
							TargetAng = self.PistolSafeAng * 1
						else
							TargetPos = self.RifleSafePos * 1
							TargetAng = self.RifleSafeAng * 1
						end
					else
						if GetConVarNumber("sxbase_differentorigins") > 0 then
							TargetPos[1] = TargetPos[1] - 0.5
							TargetPos[3] = TargetPos[3] + 0.25
						end
					end
				end
				
				if self.dt.Status != FAS_STAT_CUSTOMIZE and not self.NoNearWall and self.FireMode != "safe" then
					td.start = self.Owner:GetShootPos()
					td.endpos = td.start + self.Owner:GetAimVector() * 30
					td.filter = self.Owner
					
					tr = util.TraceLine(td)
					
					if tr.Hit then
						self.NearWall = true
						dist = tr.HitPos:Distance(td.start)
						
						TargetAng[1] = TargetAng[1] - math.Clamp((30 - dist), 0, 10)
						TargetAng[2] = TargetAng[2] + math.Clamp((30 - dist) * 2, 0, 20)
						TargetPos[2] = TargetPos[2] + math.Clamp((30 - dist) * 0.1, 0, 1)
					end
				end
				
				BlendSpeed = Lerp(FT * 3, BlendSpeed, 12)
				
				if len > 30 and ong then
					move = math.Clamp(len / self.Owner:GetWalkSpeed(), 0, 1)
					
					if self.Owner:Crouching() then
						cos1, sin1 = math.cos(CT * 6), math.sin(CT * 6)
						tan = math.atan(cos1 * sin1, cos1 * sin1)
					else
						cos1, sin1 = math.cos(CT * 8.5), math.sin(CT * 8.5)
						tan = math.atan(cos1 * sin1, cos1 * sin1)
					end
					
					TargetAng[1] = TargetAng[1] + tan * 2 * move
					TargetAng[2] = TargetAng[2] + cos1 * move
					TargetAng[3] = TargetAng[3] + sin1 * move
							
					TargetPos[1] = TargetPos[1] + sin1 * 0.1 * move
					TargetPos[2] = TargetPos[2] + tan * 0.2 * move
					TargetPos[3] = TargetPos[3] + tan * 0.1 * move
					
					/*AngMod[1] = Lerp(FT * 15, AngMod[1], cos1 * sin1 * 0.5)
					AngMod[2] = Lerp(FT * 15, AngMod[2], math.atan(cos1, sin1) * 0.35)
					AngMod[3] = Lerp(FT * 15, AngMod[3], cos1 * -0.5)
					PosMod[1] = Lerp(FT * 15, PosMod[1], cos1 * sin1)
					PosMod[2] = Lerp(FT * 15, PosMod[2], cos1)
					PosMod[3] = Lerp(FT * 15, PosMod[3], cos1 * 0.5)*/
				else
					if self.dt.Status != FAS_STAT_ADS and not self.dt.Bipod then
						cos1, sin1 = math.cos(CT), math.sin(CT)
						tan = math.atan(cos1 * sin1, cos1 * sin1)
							
						TargetAng[1] = TargetAng[1] + tan * 1.15
						TargetAng[2] = TargetAng[2] + cos1 * 0.4
						TargetAng[3] = TargetAng[3] + tan
							
						TargetPos[2] = TargetPos[2] + tan * 0.2
					end
				end
				
				AngMod = LerpVector(FT * 10, AngMod, Vec0)
				PosMod = LerpVector(FT * 10, PosMod, Vec0)
			end
			
			mod = 1
			
			if self.dt.Status == FAS_STAT_ADS then
				mod = 0.25
			end
			
			if ong and (self.Owner:Crouching() or self.Owner:KeyDown(IN_DUCK)) and self.dt.Status != FAS_STAT_ADS and self.dt.Status != FAS_STAT_CUSTOMIZE then
				TargetPos[3] = TargetPos[3] - 0.5
				TargetPos[1] = TargetPos[1] - 0.5
				TargetPos[2] = TargetPos[2] - 0.5
			end
			
			dif1, dif2 = 0, 0
			
			if GetConVarNumber("sxbase_alternatebipod") > 0 then
				if self.dt.Bipod and self.DeployAngle and self.dt.Status == FAS_STAT_IDLE then
					dif1 = math.AngleDifference(self.DeployAngle.y, EA.y)
					dif2 = math.AngleDifference(self.DeployAngle.p, EA.p)
					TargetPos[3] = TargetPos[3] - 1
					TargetPos[2] = TargetPos[2] + 2
					
					if CT < self.BipodMoveTime then
						self.BipodPos[1] = math.Approach(self.BipodPos[1], dif1 * 0.3, FT * 50)
						self.BipodPos[3] = math.Approach(self.BipodPos[3], dif2 * 0.3 --[[+ 1]], FT * 50)
						
						self.BipodAng[1] = math.Approach(self.BipodAng[1], dif1 * 0.1, FT * 50)
						self.BipodAng[3] = math.Approach(self.BipodAng[3], dif2 * 0.1, FT * 50)
					else
						self.BipodPos[1] = dif1 * 0.3
						self.BipodPos[3] = dif2 * 0.3 // + 1
						
						self.BipodAng[1] = dif1 * 0.1
						self.BipodAng[3] = dif2 * 0.1
					end
				else
					self.BipodPos = LerpVector(FT * 10, self.BipodPos, Vec0)
					self.BipodAng = LerpVector(FT * 10, self.BipodAng, Vec0)
					self.BipodMoveTime = CT + 0.2
				end
			else
				self.BipodPos[1] = 0
				self.BipodPos[3] = 0
						
				self.BipodAng[1] = 0
				self.BipodAng[3] = 0
			end
			
			veldepend.roll = math.Clamp((vel:DotProduct(EA:Right()) * 0.04) * len / self.Owner:GetWalkSpeed(), -5, 5)
			
			self.BlendPos[1] = Lerp(FT * BlendSpeed, self.BlendPos[1], TargetPos[1] + self.AngleDelta.y * (0.15 * mod))
			self.BlendPos[2] = Lerp(FT * BlendSpeed * 0.6, self.BlendPos[2], TargetPos[2])
			self.BlendPos[3] = Lerp(FT * BlendSpeed * 0.75, self.BlendPos[3], TargetPos[3] + self.AngleDelta.p * (0.2 * mod) + math.abs(self.AngleDelta.y) * (0.02 * mod))
				
			self.BlendAng[1] = Lerp(FT * BlendSpeed * 0.75, self.BlendAng[1], TargetAng[1] + AngMod[1] - self.AngleDelta.p * (1.5 * mod))
			self.BlendAng[2] = Lerp(FT * BlendSpeed, self.BlendAng[2], TargetAng[2] + AngMod[2] + self.AngleDelta.y * (0.3 * mod))
			self.BlendAng[3] = Lerp(FT * BlendSpeed, self.BlendAng[3], TargetAng[3] + AngMod[3] + self.AngleDelta.y * (0.6 * mod) + veldepend.roll)
			
			EA = EA * 1
			RotateAroundAxis(EA, Right(EA), self.BlendAng[1] + PosMod[1] + self.BipodAng[3])
			RotateAroundAxis(EA, Up(EA), self.BlendAng[2] + PosMod[2] - self.BipodAng[1])
			RotateAroundAxis(EA, Forward(EA), self.BlendAng[3] + PosMod[3])
			
			EP = EP + (self.BlendPos[1] - self.BipodPos[1]) * Right(EA)  
			EP = EP + self.BlendPos[2] * Forward(EA)
			EP = EP + (self.BlendPos[3] - self.BipodPos[3]) * Up(EA)
			
			/*EA:RotateAroundAxis(EA:Right(), self.BlendAng[1] + PosMod[1] + (self.dt.Bipod and math.AngleDifference(self.DeployAngle.p, EA.p) or 0) * 0.1)
			EA:RotateAroundAxis(EA:Up(), self.BlendAng[2] + PosMod[2] - (self.dt.Bipod and math.AngleDifference(self.DeployAngle[2], EA[2]) or 0) * 0.1)
			EA:RotateAroundAxis(EA:Forward(), self.BlendAng[3] + PosMod[3])
			
			EP = EP + (self.BlendPos[1] - (self.dt.Bipod and math.AngleDifference(self.DeployAngle[2], EA[2]) or 0) * 0.3) * EA:Right()  
			EP = EP + self.BlendPos[2] * EA:Forward()
			EP = EP + (self.BlendPos[3] - (self.dt.Bipod and math.AngleDifference(self.DeployAngle.p, EA.p) or 0) * 0.3) * EA:Up()*/
			
			vm:SetRenderOrigin(EP)
			vm:SetRenderAngles(EA)
			vm:FrameAdvance(FT)
			vm:SetupBones()
			vm:AddEffects( EF_BONEMERGE )
			vm:SetParent(VM)
			if !self.DrawVMScope then
				vm:DrawModel()
			end

			if LocalPlayer() == self.Owner and self.ViewModelHands then
				if self.lastPlayerModel != LocalPlayer():GetModel() then
					local handsInfo = self:GetHandsModelNew()
					self.ViewModelHands:SetModel(handsInfo.model)
					self.ViewModelHands:SetSkin(handsInfo.skin)
					self.ViewModelHands:SetBodyGroups(handsInfo.body)
					self.lastPlayerModel = LocalPlayer():GetModel()
				end
			end

			self.ViewModelHands:SetRenderOrigin(EP)
			self.ViewModelHands:SetRenderAngles(EA)
			self.ViewModelHands:SetupBones()
			self.ViewModelHands:AddEffects( EF_BONEMERGE )
			self.ViewModelHands:SetParent(vm)
			if !self.DrawVMScope then
				self.ViewModelHands:DrawModel()
			end

			if self.VModels then
				for z, x in pairs( self.VModels ) do
					if !self.VModels[ z ].model then continue end
					if !IsValid( self.VModels[ z ].ent ) then self:CreateVModels() end
					if !self.DrawVMScope then
						self.VModels[ z ].ent:DrawModel()
					end
				end
			end
			if !self.DrawVMScope then
				self:Draw3D2DCamera()
			end
			self:SXBaseViewModelDrawn( vm )
		end
	end
	function SWEP:DrawWorldModel()

	end

	local grad = surface.GetTextureID("VGUI/sxbase/gradient")
	local compm4_reticle = Material("models/weapons/view/accessories/aimpoint_reticle")
	local eotech_reticle = Material("sprites/sxbase/eotech_reddot")
	local seq, cyc, att, t, tex, x, y, y2, diff, mag, dir, dist, namefound
	local YOff, XOff = 0
	local White, Black, Grey, Red, Green = Color(255, 255, 255, 255), Color(0, 0, 0, 255), Color(200, 200, 200, 255), Color(255, 137, 119, 255), Color(202, 255, 163, 255)
	local MagTextColor = {r = 50, g = 150, b = 200}
	local MagTextColorLight = {r = 50, g = 200, b = 220}

	local GetAttachment = reg.Entity.GetAttachment
	local LookupAttachment = reg.Entity.LookupAttachment
	local ShadowText

	timer.Simple(1, function()
		ShadowText = draw.ExtText
	end)

	function SWEP:Draw3D2DCamera()
		vm = self.ViewModelEnt
		att = GetAttachment(vm, LookupAttachment(vm, "muzzle"))
		
		if att then
			self.TracePos = att.Pos
		end
		
		if not att then
			return
		end
		
		if self.dt.Status == FAS_STAT_ADS then
			if self.AimPos == self.CompM4Pos then
				diff = (self.BlendPos[1] + self.BlendPos[3]) / (self.CompM4Pos[1] + self.CompM4Pos[3])
					
				if diff > 0.9 and diff < 1.1 then
					cam.IgnoreZ(true)
						render.SetMaterial(compm4_reticle)
						dist = math.Clamp(math.Distance(1, 1, diff, diff), 0, 0.13)
						
						render.DrawSprite(EyePos() + EyeAngles():Forward() * 100, 0.7, 0.7, Color(255, 255, 255, (0.13 - dist) / 0.13 * 255))
					cam.IgnoreZ(false)
				end
			elseif self.AimPos == self.EoTechPos then
				diff = (self.BlendPos[1] + self.BlendPos[3]) / (self.EoTechPos[1] + self.EoTechPos[3])
				
				if diff > 0.9 and diff < 1.1 then
					cam.IgnoreZ(true)
						render.SetMaterial(eotech_reticle)
						dist = math.Clamp(math.Distance(1, 1, diff, diff), 0, 0.1)
						
						render.DrawSprite(EyePos() + EyeAngles():Forward() * 100, 4, 4, Color(255, 255, 255, (0.13 - dist) / 0.1 * 255))
					cam.IgnoreZ(false)
				end
			end
		end
		
		vm = self.ViewModelEnt
		seq = GetSequenceName(vm, GetSequence(vm))
		cyc = vm:GetCycle()
				
		FT = FrameTime()
		animfound = self.CurAnim:find("reload")
		
		if (animfound or self.AnimOverride and self.AnimOverride[self.CurAnim]) and cyc <= self.ReloadCycleTime and self.dt.Status != FAS_STAT_ADS or (self.Owner:KeyDown(IN_RELOAD) and self.dt.Status == FAS_STAT_ADS) then
			self.MagCheckAlpha = math.Approach(self.MagCheckAlpha, 255, FT * 500)

			if not self.NoBlurOnPump or animfound then
				self.BlurAmount = math.Approach(self.BlurAmount, 10, FT * 20)
			end
			
			self.CheckTime = CT + 1
			self.MagCheck = true
		else
			CT = CurTime()
				
			if (CT < self.CheckTime and self.dt.Status != FAS_STAT_ADS) or CT < self.FireModeSwitchTime then
				self.MagCheckAlpha = math.Approach(self.MagCheckAlpha, 255, FT * 500)
			else
				self.MagCheckAlpha = math.Approach(self.MagCheckAlpha, 0, FT * 500)
			end
			
			if self.dt.Status != FAS_STAT_ADS and self.dt.Status != FAS_STAT_CUSTOMIZE then
				self.BlurAmount = math.Approach(self.BlurAmount, 0, FT * 20)
			end
			
			self.MagCheck = false
		end
		
		if GetConVarNumber("sxbase_nohud") <= 0 and GetConVarNumber("sxbase_customhud") > 0 then
			if self.CockRemindTime > CT then
				self.CockRemindAlpha = math.Approach(self.CockRemindAlpha, 255, FT * 500)
			else	
				self.CockRemindAlpha = math.Approach(self.CockRemindAlpha, 0, FT * 500)
			end
			
			if self.MagCheckAlpha > 0 or self.CockRemindAlpha > 0 then
				att = GetAttachment(vm, LookupAttachment(vm, (self.MuzzleName and self.MuzzleName or "muzzle")))
				ang = self.Owner:EyeAngles()
				RotateAroundAxis(ang, Right(ang), 90)
				RotateAroundAxis(ang, Up(ang), -90)
				RotateAroundAxis(ang, Forward(ang), 0)
				
				if att then
					cam.Start3D2D(att.Pos + Forward(ang) * self.Text3DForward + Right(ang) * self.Text3DRight, ang, self.Text3DSize * GetConVarNumber("sxbase_textsize"))
						cam.IgnoreZ(true)
							if self.CockRemindAlpha > 0 then
								ShadowText(self.BoltReminderText, "SXBASE_HUD48", 0, -40, Color(255, 255, 255, self.CockRemindAlpha), Color(0, 0, 0, self.CockRemindAlpha), 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
							end
						
							if self.MagCheckAlpha > 0 then
								mag = self:Clip1()
								
								if mag <= self.Primary.ClipSize * 0.3 then
									MagTextColor.r = Lerp(FT * 5, MagTextColor.r, 250)
									MagTextColor.g = Lerp(FT * 5, MagTextColor.g, 100)
									MagTextColor.b = Lerp(FT * 5, MagTextColor.b, 100)
								else
									MagTextColor.r = Lerp(FT * 5, MagTextColor.r, 20)
									MagTextColor.g = Lerp(FT * 5, MagTextColor.g, 180)
									MagTextColor.b = Lerp(FT * 5, MagTextColor.b, 255)
								end

								ShadowText( ( self.FireMode != "safe" and ("РЕЖИМ: " .. self.FireModeDisplay) or self.FireModeDisplay ), "SXBASE_HUD24", 0, 115, Color(150, 200, 255, self.MagCheckAlpha), Color(0, 0, 0, self.MagCheckAlpha), 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
								ShadowText("ЭНЕРГИЯ", "SXBASE_HUD24", 0, 140, Color(150, 200, 255, self.MagCheckAlpha), Color(0, 0, 0, self.MagCheckAlpha), 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
								ShadowText(self.PrintName, "SXBASE_HUD24", 0, 165, Color(150, 200, 255, self.MagCheckAlpha), Color(0, 0, 0, self.MagCheckAlpha), 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
							
								if self.MagCheck then
									if animfound and cyc < 0.99 then
										surface.SetDrawColor(0, 0, 0, self.MagCheckAlpha)
										surface.DrawRect(3, 200, 270, 10)
											
										surface.SetDrawColor(0, 200, 255, self.MagCheckAlpha)
										surface.DrawRect(2, 200, 300 * cyc, 8)
									end
								end
							end
						cam.IgnoreZ(false)
					cam.End3D2D()
				end
			end
		end
	end

	function SWEP:GetViewModelPosition(pos, ang)
		pos = pos + ang:Up() * 100
		return pos, ang
	end

	local pos, dir

	function SWEP:GetTracerOrigin()
		if self.TracePos then
			return self.TracePos
		end
		
		pos = self.Owner:GetShootPos()
		dir = self.Owner:EyeAngles()
		pos = pos + Forward(dir) * 10
		pos = pos + Right(dir) * 5

		return 
	end
end