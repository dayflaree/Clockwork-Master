if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
    SWEP.PrintName = "Combine Overwatch SPAS-12A"
    SWEP.Slot = 4
    SWEP.SlotPos = 0
	
	SWEP.AimPos = Vector(-5, -4.935, 3)
	SWEP.AimAng = Vector(0, 0.15, 0)
	
	SWEP.YawMod = 0.1
	SWEP.ReloadCycleTime = 0.985

	
	SWEP.WMAng = Vector(0, 180, 180)
	SWEP.WMPos = Vector(1, -3.2, 0.25)

	SWEP.MagText = "МАГАЗИН: " 
	SWEP.Text3DSize = 0.025
	SWEP.Text3DRight = -4
	SWEP.Text3DForward = -10
	SWEP.AmmoText = "Дробь 12 калибра"
	SWEP.BoltReminderText = "[R] - ВЗВЕСТИ"
	
	SWEP.ShellEjector = "1"
	SWEP.AnimOverride = {["pump"] = true}
	
	SWEP.SprintPos = Vector(8, -1, 1)
	SWEP.SprintAng = Vector(-10, 17.729, 0)

	SWEP.ReloadBobOffset = Angle(0,0,0)
	SWEP.NoShowAimCrossshair = false
	SWEP.ShowAimCrossshairADS = true
end

SWEP.MuzzleEffect = "muzzleflash_shotgun"
SWEP.MuzzleLight = Color(255,218,74)
SWEP.MuzzleName = "muzzle"
SWEP.MuzzleWorldID = 1

SWEP.HideWorldModel = false
SWEP.Attachments = {}
SWEP.NoAttachmentMenu = true

SWEP.BulletLength = 5
SWEP.CaseLength = 5.2
SWEP.EmptySound = Sound("Weapon_Shotgun.Empty")

SWEP.Anims = {}
SWEP.Anims.Draw_First = "draw"
SWEP.Anims.Draw = "draw"
SWEP.Anims.Holster = "holster"
SWEP.Anims.Fire = "fire01"
SWEP.Anims.Cock = "pump"
SWEP.Anims.Idle = "idle01"
SWEP.Anims.Reload_Start = "reload1"
SWEP.Anims.Reload_Insert = "reload2"
SWEP.Anims.Reload_End = "reload3"
SWEP.Anims.Fire_Aiming = "fire01"
SWEP.Anims.Cock_Aim = "pump"
SWEP.Anims.Idle_Aim = "idle01"

SWEP.Sounds = {}
SWEP.Sounds["pump"] = {[1] = {time = 0, sound = Sound("Weapon_Shotgun.Special1")}}
SWEP.Sounds["reload2"] = {[1] = {time = 0, sound = Sound("Weapon_Shotgun.Reload")}}	
	
SWEP.FireModes = {"pump"}

SWEP.Category = "SXBase Weapons"
SWEP.Base = "sxbase_shotgun"
SWEP.Author            = "SchwarzKruppzo"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.HoldType = "shotgun"

SWEP.ViewModelFOV    = 60
SWEP.ViewModelFlip    = false

SWEP.Spawnable            = true
SWEP.AdminSpawnable        = true

SWEP.VM = "models/weapons/c_shotgun.mdl"
SWEP.WM = "models/weapons/w_shotgun.mdl"
SWEP.WorldModel   = "models/weapons/w_shotgun.mdl"

-- Primary Fire Attributes --
SWEP.Primary.ClipSize        = 8
SWEP.Primary.DefaultClip    = 0
SWEP.Primary.Automatic       = false    
SWEP.Primary.Ammo             = "buckshot"
 
-- Secondary Fire Attributes --
SWEP.Secondary.ClipSize        = -1
SWEP.Secondary.DefaultClip    = -1
SWEP.Secondary.Automatic       = false
SWEP.Secondary.Ammo         = "none"

-- Deploy related
SWEP.FirstDeployTime = 0.45
SWEP.DeployTime = 0.45
SWEP.HolsterTime = 0.3

-- Firing related
SWEP.Shots = 12
SWEP.FireDelay = 0.2
SWEP.Damage = 8
SWEP.FireSound = Sound("Weapon_Shotgun.Single")
SWEP.UseHands = true
SWEP.CockAfterShot = true
SWEP.Cocked = true

-- Accuracy related
SWEP.HipCone = 0.035
SWEP.AimCone = 0.005
SWEP.ClumpSpread = 0.032
SWEP.SpreadPerShot = 0.02
SWEP.MaxSpreadInc = 0.055
SWEP.SpreadCooldown = 0.4
SWEP.VelocitySensitivity = 1.5
SWEP.AimFOV = 5

-- Recoil related
SWEP.ViewKick = 3.7
SWEP.Recoil = 3

-- Reload related
SWEP.InsertEmpty = 3
SWEP.InsertTime = 0.45
SWEP.ReloadStartTime = 0.5
SWEP.ReloadAdvanceTimeEmpty = 1.4
SWEP.ReloadAdvanceTimeLast = 1.1
SWEP.ReloadEndTime = 0.5
SWEP.ReloadAbortTime = 0.7
SWEP.CockTime = 0.4

local mag, ammo, CT

function SWEP:ReloadStartLogic()
	mag = self:Clip1()
	ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
	
	if mag < self.Primary.ClipSize and ammo > 0 then
		CT = CurTime()
		self.dt.Status = FAS_STAT_IDLE
		
		SXBASE_PlayAnim(self, self.Anims.Reload_Start, 1, 0)
		self:DelayMe(CT + self.ReloadStartTime)
		self.ReloadStateWait = CT + self.ReloadStartTime
		self.ReloadState = 2
	end
end

if CLIENT then
	function SWEP:MakePumpShell()
		self:AddEvent(0.15, function()
			self:CreateShell("buckshot")
		end)
	end
end