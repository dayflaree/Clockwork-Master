ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = "5.56x45MM Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 90
ENT.ResupplyAmount = 30
ENT.Caliber = "5.56x45MM"
ENT.Model = "models/Items/BoxMRounds.mdl"