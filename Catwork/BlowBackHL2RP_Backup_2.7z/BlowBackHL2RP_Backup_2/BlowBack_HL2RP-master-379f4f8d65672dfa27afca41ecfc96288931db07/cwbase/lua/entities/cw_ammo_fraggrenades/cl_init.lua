include("shared.lua")

ENT.upOffset = Vector(0, 0, 28)