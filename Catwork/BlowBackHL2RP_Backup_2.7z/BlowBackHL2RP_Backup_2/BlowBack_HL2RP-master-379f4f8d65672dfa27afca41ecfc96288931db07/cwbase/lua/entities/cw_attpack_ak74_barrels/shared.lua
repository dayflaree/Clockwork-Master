ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AK-74 - barrel package"
ENT.PackageText = "AK-74 Barrels"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"bg_ak74_ubarrel", "bg_ak74_rpkbarrel"}