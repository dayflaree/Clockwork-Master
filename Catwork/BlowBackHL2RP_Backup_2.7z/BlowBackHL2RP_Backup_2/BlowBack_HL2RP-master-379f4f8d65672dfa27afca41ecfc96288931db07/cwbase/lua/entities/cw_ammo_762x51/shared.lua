ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = "7.62x51MM Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 60
ENT.ResupplyAmount = 20
ENT.Caliber = "7.62x51MM"
ENT.Model = "models/Items/BoxMRounds.mdl"