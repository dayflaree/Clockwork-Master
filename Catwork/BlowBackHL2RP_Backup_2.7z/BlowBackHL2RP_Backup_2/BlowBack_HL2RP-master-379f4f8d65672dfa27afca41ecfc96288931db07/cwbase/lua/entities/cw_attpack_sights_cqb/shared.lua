ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Sights - CQB"
ENT.PackageText = "Close range sights"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"md_kobra", "md_aimpoint", "md_microt1", "md_eotech"}