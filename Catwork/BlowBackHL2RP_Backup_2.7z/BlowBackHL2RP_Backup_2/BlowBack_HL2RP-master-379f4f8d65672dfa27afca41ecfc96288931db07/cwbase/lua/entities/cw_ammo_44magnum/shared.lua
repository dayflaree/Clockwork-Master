ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = ".44 Magnum Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 30
ENT.ResupplyAmount = 6
ENT.Caliber = ".44 Magnum"
ENT.Model = "models/Items/BoxSRounds.mdl"