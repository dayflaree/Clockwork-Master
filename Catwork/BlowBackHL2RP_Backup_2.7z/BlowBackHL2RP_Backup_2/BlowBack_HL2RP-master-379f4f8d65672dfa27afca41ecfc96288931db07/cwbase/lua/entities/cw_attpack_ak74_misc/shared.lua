ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "AK-74 - miscellaneous"
ENT.PackageText = "AK-74 Miscellaneous"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"md_pbs1", "bg_ak74rpkmag"}