ENT.Type = "anim"
ENT.Base = "cw_ammo_ent_base"
ENT.PrintName = ".50 AE Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "CW 2.0 Ammo"

ENT.CaliberSpecific = true
ENT.AmmoCapacity = 28
ENT.ResupplyAmount = 7
ENT.Caliber = ".50 AE"
ENT.Model = "models/Items/BoxSRounds.mdl"