ENT.Type = "anim"
ENT.Base = "cw_attpack_base"
ENT.PrintName = "Sights - long range"
ENT.PackageText = "Long range sights"
ENT.Category = "CW 2.0 Attachments"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 

ENT.attachments = {"md_acog", "bg_sg1scope", "md_pso1"}