TEAM_RED = 1
TEAM_BLUE = 2

team.SetUp(TEAM_RED, "Team Red", Color(255, 126, 112, 255), true)
team.SetUp(TEAM_BLUE, "Team Blue", Color(109, 145, 255, 255), true)