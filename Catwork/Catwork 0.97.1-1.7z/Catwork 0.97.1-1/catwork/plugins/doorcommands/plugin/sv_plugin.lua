--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local IsDoorLocked = CW.entity.IsDoorLocked;
local GetDoorState = CW.entity.GetDoorState;

CW.config:Add("default_doors_hidden", true, nil, nil, nil, nil, true);
CW.config:Add("doors_save_state", true, nil, nil, nil, nil, true);

-- A function to load the parent data.
function cwDoorCmds:LoadParentData()
	self.parentData = self.parentData or {};
	
	local parentData = CW.kernel:RestoreSchemaData("plugins/parents/"..game.GetMap());
	local positions = {};
	
	for k, v in pairs(CW.entity:GetDoorEntities()) do
		if (IsValid(v)) then
			local position = v:GetPos();
			
			if (position) then
				positions[tostring(position)] = v;
			end;
		end;
	end;
	
	for k, v in pairs(parentData) do
		local parent = positions[tostring(v.parentPosition)];
		local entity = positions[tostring(v.position)];
		
		if (IsValid(entity) and IsValid(parent) and !self.parentData[entity]) then
			if (CW.entity:IsDoor(entity) and CW.entity:IsDoor(parent)) then
				CW.entity:SetDoorParent(entity, parent);
				
				self.parentData[entity] = parent;
			end;
		end;
	end;
end;

-- A function to load the door data.
function cwDoorCmds:LoadDoorData()
	self.doorData = self.doorData or {};
	
	local positions = {};
	local doorData = CW.kernel:RestoreSchemaData("plugins/doors/"..game.GetMap());
	
	for k, v in pairs(CW.entity:GetDoorEntities()) do
		if (IsValid(v)) then
			local position = v:GetPos();
			
			if (position) then
				positions[tostring(position)] = v;
			end;
		end;
	end;
	
	for k, v in pairs(doorData) do
		local entity = positions[tostring(v.position)];
		
		if (IsValid(entity) and !self.doorData[entity]) then
			if (CW.entity:IsDoor(entity)) then
				local data = {
					customName = v.customName,
					position = v.position,
					entity = entity,
					name = v.name,
					text = v.text
				};
				
				if (!data.customName) then
					CW.entity:SetDoorUnownable(data.entity, true);
					CW.entity:SetDoorName(data.entity, data.name);
					CW.entity:SetDoorText(data.entity, data.text);
				else
					CW.entity:SetDoorName(data.entity, data.name);
				end;
				
				self.doorData[data.entity] = data;
			end;
		end;
	end;
	
	if (CW.config:Get("default_doors_hidden"):Get()) then
		for k, v in pairs(positions) do
			if (!self.doorData[v]) then
				CW.entity:SetDoorHidden(v, true);
			end;
		end;
	end;
end;

-- A function to save the parent data.
function cwDoorCmds:SaveParentData()
	local parentData = {};
	
	for k, v in pairs(self.parentData) do
		if (IsValid(k) and IsValid(v)) then
			parentData[#parentData + 1] = {
				parentPosition = v:GetPos(),
				position = k:GetPos()
			};
		end;
	end;
	
	CW.kernel:SaveSchemaData("plugins/parents/"..game.GetMap(), parentData);
end;

-- A function to save the door data.
function cwDoorCmds:SaveDoorData()
	local doorData = {};
	
	for k, v in pairs(self.doorData) do
		local data = {
			customName = v.customName,
			position = v.position,
			name = v.name,
			text = v.text
		};
		
		doorData[#doorData + 1] = data;
	end;
	
	CW.kernel:SaveSchemaData("plugins/doors/"..game.GetMap(), doorData);
end;

function cwDoorCmds:SaveDoorStates()
	local doorTable = {};

	for k, v in pairs(CW.entity:GetDoorEntities()) do
		if (v:IsValid()) then
			doorTable[#doorTable + 1] = {
				position = v:GetPos(),
				bLocked = IsDoorLocked(CW.entity, v),
				state = GetDoorState(CW.entity, v)
			};
		end;
	end;

	CW.kernel:SaveSchemaData("plugins/doorstates/"..game.GetMap(), doorTable);
end;

function cwDoorCmds:LoadDoorStates()
	local doorTable = CW.kernel:RestoreSchemaData("plugins/doorstates/"..game.GetMap());
	local positions = {};

	for k, v in pairs(CW.entity:GetDoorEntities()) do
		if (IsValid(v)) then
			local position = v:GetPos();
			
			if (position) then
				positions[tostring(position)] = v;
			end;
		end;
	end;
	
	for k, v in pairs(doorTable) do
		local entity = positions[tostring(v.position)];

		if (IsValid(entity) and CW.entity:IsDoor(entity)) then

			if (v.state == 1 or v.state == 2) then
				CW.entity:OpenDoor(entity, 0);
			end;

			if (v.bLocked) then
				entity:Fire("Lock", "", 0);
			end;
		end;
	end;
end;