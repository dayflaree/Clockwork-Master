--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("DoorSetAllUnownable");
COMMAND.tip = "Set all doors unownable.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	good_doors = 0;
	for k,v in pairs(ents.GetAll()) do
		if(IsValid(v) and CW.entity:IsDoor(v)) then
			local data = {
				position = v:GetPos(),
				entity = v,
				text = arguments[2],
				name = arguments[1]
			};
			
			CW.entity:SetDoorName(data.entity, data.name);
			CW.entity:SetDoorText(data.entity, data.text);
			CW.entity:SetDoorUnownable(data.entity, true);
			
			cwDoorCmds.doorData[data.entity] = data;
			cwDoorCmds:SaveDoorData();
			good_doors = good_doors + 1;
		end
	end
	CW.player:Notify(player, good_doors.." doors have been set unownable.");
	CW.player:Notify(player, "Remember: This is ALL Doors!");
	
end;

COMMAND:Register();