--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

-- Called when the salesman's target ID is painted.
function cwSalesmen:SalesmanTargetID(entity, x, y, alpha) end;

netstream.Hook("Salesmenu", function(data)
	CW.salesmenu.buyInShipments = data.buyInShipments;
	CW.salesmenu.priceScale = data.priceScale;
	CW.salesmenu.factions = data.factions;
	CW.salesmenu.buyRate = data.buyRate;
	CW.salesmenu.classes = data.classes;
	CW.salesmenu.entity = data.entity;
	CW.salesmenu.sells = data.sells;
	CW.salesmenu.stock = data.stock;
	CW.salesmenu.cash = data.cash;
	CW.salesmenu.text = data.text;
	CW.salesmenu.buys = data.buys;
	CW.salesmenu.name = data.name;
	
	CW.salesmenu.panel = vgui.Create("cwSalesmenu");
	CW.salesmenu.panel:Rebuild();
	CW.salesmenu.panel:MakePopup();
end);

netstream.Hook("SalesmenuRebuild", function(data)
	local cash = data;
	
	if (CW.salesmenu:IsSalesmenuOpen()) then
		CW.salesmenu.cash = cash;
		CW.salesmenu.panel:Rebuild();
	end;
end);

netstream.Hook("SalesmanPlaySound", function(data)
	if (data[2] and data[2]:IsValid()) then
		data[2]:EmitSound(data[1]);
	end;
end);

netstream.Hook("SalesmanAdd", function(data)
	if (CW.salesman:IsSalesmanOpen()) then
		CloseDermaMenus();
		
		CW.salesman.panel:Close();
		CW.salesman.panel:Remove();
	end;
	
	Derma_StringRequest("Name", "What do you want the salesman's name to be?", "", function(text)
		CW.salesman.name = text;
		
		gui.EnableScreenClicker(true);
		
		CW.salesman.showChatBubble = true;
		CW.salesman.buyInShipments = true;
		CW.salesman.priceScale = 1;
		CW.salesman.physDesc = "";
		CW.salesman.factions = {};
		CW.salesman.buyRate = 100;
		CW.salesman.classes = {};
		CW.salesman.stock = -1;
		CW.salesman.sells = {};
		CW.salesman.model = "models/humans/group01/male_0"..math.random(1, 9)..".mdl";
		CW.salesman.items = {};
		CW.salesman.cash = -1;
		CW.salesman.text = {
			doneBusiness = {},
			cannotAfford = {},
			needMore = {},
			noStock = {},
			noSale = {},
			start = {}
		};
		CW.salesman.buys = {};
		CW.salesman.name = CW.salesman.name;
		
		for k, v in pairs(CW.item:GetAll()) do
			if (!v("isBaseItem")) then
				CW.salesman.items[k] = v;
			end;
		end;
		
		CW.salesman.panel = vgui.Create("cwSalesman");
		CW.salesman.panel:Rebuild();
		CW.salesman.panel:MakePopup();
	end);
end);

netstream.Hook("SalesmanEdit", function(data)
	if (CW.salesman:IsSalesmanOpen()) then
		CloseDermaMenus();
		
		CW.salesman.panel:Close();
		CW.salesman.panel:Remove();
	end;
	
	Derma_StringRequest("Name", "What do you want to change the salesman's name to?", data.name, function(text)
		CW.salesman.showChatBubble = data.showChatBubble;
		CW.salesman.buyInShipments = data.buyInShipments;
		CW.salesman.priceScale = data.priceScale;
		CW.salesman.factions = data.factions;
		CW.salesman.physDesc = data.physDesc;
		CW.salesman.buyRate = data.buyRate;
		CW.salesman.classes = data.classes;
		CW.salesman.stock = -1;
		CW.salesman.sells = data.sellTab;
		CW.salesman.model = data.model;
		CW.salesman.items = {};
		CW.salesman.cash = data.cash;
		CW.salesman.text = data.textTab;
		CW.salesman.buys = data.buyTab;
		CW.salesman.name = text;
		
		for k, v in pairs(CW.item:GetAll()) do
			if (!v("isBaseItem")) then
				CW.salesman.items[k] = v;
			end;
		end;
		
		gui.EnableScreenClicker(true);
		
		local scrW = ScrW();
		local scrH = ScrH();
		
		CW.salesman.panel = vgui.Create("cwSalesman");
		CW.salesman.panel:SetSize(scrW * 0.5, scrH * 0.75);
		CW.salesman.panel:SetPos(
			(scrW / 2) - (CW.salesman.panel:GetWide() / 2),
			(scrH / 2) - (CW.salesman.panel:GetTall() / 2)
		);
		CW.salesman.panel:Rebuild();
		CW.salesman.panel:MakePopup();
	end);
end);