--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("PlyGoTo");
COMMAND.tip = "Goto a player's location.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"GoTo"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (target) then
		CW.player:SetSafePosition(player, target:GetPos());
		CW.player:NotifyAll(player:Name().." has gone to "..target:Name().."'s location.");
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();
