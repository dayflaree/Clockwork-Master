--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

--[[ 
	Never edit this file! All config editing should be done
	either through the .cfg files provided or through the
	in-game config editing systems.
--]]

CW.config:Add("mysql_bans_table", "bans", nil, nil, true, true, true);
CW.config:Add("mysql_characters_table", "characters", nil, nil, true, true, true);
CW.config:Add("mysql_players_table", "players", nil, nil, true, true, true);
CW.config:Add("mysql_username", "", nil, nil, true, true, true);
CW.config:Add("mysql_password", "", nil, nil, true, true, true);
CW.config:Add("mysql_database", "", nil, nil, true, true, true);
CW.config:Add("mysql_host", "", nil, nil, true, true, true);
CW.config:Add("mysql_port", 3306, nil, nil, true, true, true);
CW.config:Add("scale_attribute_progress", 1);
CW.config:Add("messages_must_see_player", false, true);
CW.config:Add("bash_in_door_enabled", false);
CW.config:Add("default_attribute_points", 30, true);
CW.config:Add("health_regeneration_enabled", true);
CW.config:Add("enable_prop_protection", true);
CW.config:Add("use_local_machine_date", false, nil, nil, nil, nil, true);
CW.config:Add("use_local_machine_time", false, nil, nil, nil, nil, true);
CW.config:Add("use_opens_entity_menus", true, true);
CW.config:Add("shoot_after_raise_time", 1);
CW.config:Add("save_recognised_names", true);
CW.config:Add("save_attribute_boosts", false);
CW.config:Add("ragdoll_immunity_time", 0.5);
CW.config:Add("additional_characters", 2, true);
CW.config:Add("change_class_interval", 180);
CW.config:Add("raised_weapon_system", true, true);
CW.config:Add("prop_kill_protection", true);
CW.config:Add("clockwork_intro_enabled", true);
CW.config:Add("sprint_lowers_weapon", true);
CW.config:Add("use_own_group_system", false, true);
CW.config:Add("enable_gravgun_punt", true);
CW.config:Add("default_inv_weight", 20, true);
CW.config:Add("default_inv_space", 100, true);
CW.config:Add("custom_weapon_color", true);
CW.config:Add("save_data_interval", 180);
CW.config:Add("damage_view_punch", true);
CW.config:Add("enable_heartbeat", true, true);
CW.config:Add("unrecognised_name", "Somebody you do not recognise.", true);
CW.config:Add("scale_fall_damage", 1);
CW.config:Add("limb_damage_system", true, true);
CW.config:Add("enable_vignette", true, true);
CW.config:Add("use_free_aiming", true, true, true);
CW.config:Add("default_cash", 100, nil, nil, nil, nil, nil, true);
CW.config:Add("armor_chest_only", false);
CW.config:Add("minimum_physdesc", 32, true);
CW.config:Add("wood_breaks_fall", true);
CW.config:Add("enable_crosshair", false, true, true);
CW.config:Add("recognise_system", true, true);
CW.config:Add("max_chat_length", 256, true, true);
CW.config:Add("cash_enabled", true, true, nil, nil, nil, true);
CW.config:Add("default_physdesc", "", true);
CW.config:Add("scale_chest_dmg", 1);
CW.config:Add("body_decay_time", 600);
CW.config:Add("banned_message", "You are still banned for !t more !f.");
CW.config:Add("wages_interval", 360);
CW.config:Add("scale_prop_cost", 1);
CW.config:Add("fade_dead_npcs", true, true);
CW.config:Add("cash_weight", 0.001, true);
CW.config:Add("cash_space", 0.001, true);
CW.config:Add("scale_head_dmg", 3);
CW.config:Add("block_inv_binds", true, true);
CW.config:Add("target_id_delay", 0.5, true);
CW.config:Add("scale_limb_dmg", 0.5);
CW.config:Add("enable_headbob", true, true);
CW.config:Add("command_prefix", "/", true);
CW.config:Add("crouched_speed", 25);
CW.config:Add("default_flags", "", true);
CW.config:Add("disable_sprays", true);
CW.config:Add("owner_steamid", "STEAM_0:0:0000000", nil, nil, true, true, true);
CW.config:Add("hint_interval", 30);
CW.config:Add("ooc_interval", 120);
CW.config:Add("minute_time", 60, true);
CW.config:Add("voice_enabled", true);
CW.config:Add("unlock_time", 3);
CW.config:Add("local_voice", true, true);
CW.config:Add("talk_radius", 384, true);
CW.config:Add("wages_name", "Wages", true);
CW.config:Add("give_hands", true);
CW.config:Add("give_keys", true);
CW.config:Add("jump_power", 160);
CW.config:Add("spawn_time", 60);
CW.config:Add("walk_speed", 100);
CW.config:Add("run_speed", 225);
CW.config:Add("door_cost", 10, true);
CW.config:Add("lock_time", 2);
CW.config:Add("max_doors", 5);
CW.config:Add("enable_space_system", false, true);
CW.config:Add("draw_intro_bars", true, true);
CW.config:Add("enable_jogging", false, true, true);
CW.config:Add("enable_looc_icons", true, true, true);
CW.config:Add("show_business", true, true);
CW.config:Add("chat_multiplier", true, true, true);
CW.config:Add("steam_api_key", "");
CW.config:Add("enable_map_props_physgrab", false);
CW.config:Add("translate_api_key", "");
CW.config:Add("entity_handle_time", 0.1);
CW.config:Add("player_should_smooth_sprint", true);
CW.config:Add("quick_raise_enabled", true);
CW.config:Add("force_entity_menus", 1, true);
CW.config:Add("modify_themes", true, true);
CW.config:Add("default_theme", "Schema", true);
CW.config:Add("playerthink_rate", 8);

CW.config:Add("enable_ironsights", true, true);
CW.config:Add("ironsights_spread", 0.5, true);
CW.config:Add("ironsights_slow", 0.5, true);