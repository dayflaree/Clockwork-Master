--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = CW.class:New("Civil Worker's Union");
	CLASS.color = Color(240, 220, 100, 255);
	CLASS.factions = {FACTION_CWU};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "A civil worker's union worker.";
	CLASS.defaultPhysDesc = "Wearing clothes. wow.";
CLASS_CWU = CLASS:Register();