--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "Strength";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "str";
	ATTRIBUTE.description = "Affects your overall strength, e.g: how hard you punch.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_STRENGTH = CW.attribute:Register(ATTRIBUTE);