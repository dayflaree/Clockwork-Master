--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

include("shared.lua");

-- Called when the target ID HUD should be painted.
function ENT:HUDPaintTargetID(x, y, alpha)
	local colorTargetID = CW.option:GetColor("target_id");
	local colorWhite = CW.option:GetColor("white");
	
	y = CW.kernel:DrawInfo("Paper", x, y, colorTargetID, alpha);
	
	if (self:GetDTBool(0)) then
		y = CW.kernel:DrawInfo("It has been written on.", x, y, colorWhite, alpha);
	else
		y = CW.kernel:DrawInfo("It is blank.", x, y, colorWhite, alpha);
	end;
end;

-- Called when the entity should draw.
function ENT:Draw()
	self:DrawModel();
end;