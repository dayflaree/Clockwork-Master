--[[
	� 2014 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

local COMMAND = CW.command:New("ApplySay");
COMMAND.tip = "Says your Name and CID informally.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player)
	local citizenID = player:GetSharedVar("citizenID");
	local name = player:Name();
    local radius = CW.config:Get("talk_radius"):Get();
    
	if (!Schema:PlayerIsCombine(player)) then
		chatbox.AddText(nil, '"My name is '..name..', and my CID is #'..citizenID..'."', {sender = player, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)});
    else
        CW.player:Notify(player, "Sorry, but you do not have a CID. Use /Name instead!");
    end;

	for k, v in pairs(_player.GetAll()) do
	    if (v:GetPos():Distance(player:GetPos()) <= radius 
		and CW.config:Get("apply_recognise_enable"):Get() 
		and IsValid(v) and v:HasInitialized()) then
			CW.player:SetRecognises(v, player, RECOGNISE_TOTAL);
		end;
	end;
end;

COMMAND:Register();