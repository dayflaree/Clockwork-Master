#define GMMODULE

#include <iostream>
#include <string>

#ifndef _WIN32
	#include <sys/stat.h>
	#include <sys/types.h>
	#include <unistd.h>
	#define GetCurrentDir getcwd
#else
	#include <direct.h>
	#define GetCurrentDir _getcwd
#endif

#include <Bootil/Bootil.h>
#include <GarrysMod/Lua/Interface.h>

using namespace std;
using namespace Bootil;
using namespace GarrysMod::Lua;

ILuaBase* g_Lua;

namespace Table {
	int Create()
	{
		int iTableReference;
		g_Lua->CreateTable();

		iTableReference = g_Lua->ReferenceCreate();

		return iTableReference;
	}

	void Add(int iTableReference, const string &key, int iTable)
	{
		g_Lua->ReferencePush(iTableReference);
		g_Lua->PushString(key.c_str());
		g_Lua->ReferencePush(iTable);
		g_Lua->SetTable(-3);

		g_Lua->ReferenceFree(iTable);
	}

	void Insert(int iTableReference, const string &key, CFunc value)
	{
		g_Lua->ReferencePush(iTableReference);
		g_Lua->PushString(key.c_str());
		g_Lua->PushCFunction(value);
		g_Lua->SetTable(-3);
	}

	void Insert(int iTableReference, const string &key, int value)
	{
		g_Lua->ReferencePush(iTableReference);
		g_Lua->PushString(key.c_str());
		g_Lua->PushNumber(value);
		g_Lua->SetTable(-3);
	}

	void Insert(int iTableReference, const string &key, string value)
	{
		g_Lua->ReferencePush(iTableReference);
		g_Lua->PushString(key.c_str());
		g_Lua->PushString(value.c_str());
		g_Lua->SetTable(-3);
	}

	void Insert(int iTableReference, int key, string value)
	{
		g_Lua->ReferencePush(iTableReference);
		g_Lua->PushNumber(key);
		g_Lua->PushString(value.c_str());
		g_Lua->SetTable(-3);
	}
}

void StringReplace(string &str, const string &strPattern, const string &strReplace)
{
	size_t found;

	found = str.find(strPattern);

	while (found != string::npos)
	{
		str.replace(found, strPattern.size(), strReplace);

		found = str.find(strPattern);
	};
}

void GetRelativePath(string &strFilePath)
{
	char currentPath[FILENAME_MAX];

	GetCurrentDir(currentPath, sizeof(currentPath));

	ostringstream strStream;

	strStream << currentPath << "/garrysmod/" << strFilePath;
	strFilePath = strStream.str();

	StringReplace(strFilePath, "\\", "/");
}

int g_Write(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING) && LUA->IsType(2, Type::STRING))
	{
		BString strFileName = LUA->GetString(1);
		BString strContents = LUA->GetString(2);

		if ((strFileName.find("settings/") == std::string::npos && strFileName.find("logs/") == std::string::npos) || strFileName.find(".lua") != std::string::npos || strFileName.find("..") != std::string::npos) {
			LUA->PushBool(false);

			return 1;
		}

		GetRelativePath(strFileName);

		bool bStatus = File::Write(strFileName, strContents);

		LUA->PushBool(bStatus);

		return 1;
	}

	LUA->PushBool(false);

	return 1;
}

int g_Read(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strFileName = LUA->GetString(1);

		if (strFileName.find("cfg/") != std::string::npos || strFileName.find("..") != std::string::npos) {
			LUA->PushBool(false);

			return 1;
		}

		GetRelativePath(strFileName);

		BString strFileContents;

		if (!File::Read(strFileName, strFileContents))
		{
			LUA->PushBool(false);

			return 1;
		}

		LUA->PushString(strFileContents.c_str());

		return 1;
	}

	LUA->PushBool(false);

	return 1;
}

int g_Append(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING) && LUA->IsType(2, Type::STRING))
	{
		string strFileName = LUA->GetString(1);
		string strContents = LUA->GetString(2);

		if ((strFileName.find("settings/") == std::string::npos && strFileName.find("logs/") == std::string::npos) || strFileName.find(".lua") != std::string::npos || strFileName.find("..") != std::string::npos) {
			LUA->PushBool(false);

			return 1;
		}

		GetRelativePath(strFileName);

		ofstream file(strFileName.c_str(), ios::out | ios::app);

		if (file.is_open())
		{
			file << strContents;
			file.close();
			LUA->PushBool(true);
		}
		else
		{
			LUA->PushBool(false);
		}

		return 1;
	}

	LUA->PushBool(false);

	return 1;
}

int g_Delete(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strPath = LUA->GetString(1);

		if (strPath.find("settings/") == std::string::npos || strPath == "settings" || strPath == "settings/" || strPath.find("..") != std::string::npos || strPath.find(".") == std::string::npos) {
			LUA->PushBool(false);

			return 1;
		}

		GetRelativePath(strPath);

		bool bStatus;

		if (File::IsFolder(strPath))
		{
			bStatus = File::RemoveFolder(strPath, true);
		}
		else
		{
			bStatus = File::RemoveFile(strPath);
		}

		LUA->PushBool(bStatus);

		return 1;
	}

	LUA->PushBool(false);

	return 1;
}

int g_MakeDirectory(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strPath = LUA->GetString(1);

		if ((strPath.find("settings/") == std::string::npos && strPath.find("logs/") == std::string::npos) || strPath.find("..") != std::string::npos) {
			LUA->PushBool(false);

			return 1;
		}

		GetRelativePath(strPath);

		bool bStatus = File::CreateFolder(strPath);

		LUA->PushBool(bStatus);

		return 1;
	}

	LUA->PushBool(false);

	return 1;
}

int g_Initialize(lua_State* state)
{
	LUA->PushSpecial(SPECIAL_GLOB);
		LUA->GetField(-1, "item");
		LUA->GetField(-1, "Initialize");
		LUA->Call(0, 0);
	LUA->Pop(2);

	LUA->PushSpecial(SPECIAL_GLOB);
		LUA->GetField(-1, "config");
		LUA->GetField(-1, "Import");
		LUA->PushString("gamemodes/catwork/clockwork.cfg");
		LUA->Call(1, 0);
	LUA->Pop(2);

	LUA->PushSpecial(SPECIAL_GLOB);
		LUA->GetField(-1, "config");
		LUA->GetField(-1, "SetInitialized");
		LUA->PushBool(true);
		LUA->Call(1, 0);
	LUA->Pop(2);

	return 0;
}

int g_WriteCWLua(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strData = LUA->GetString(1);
		BString strFileData = "CW_SCRIPT_SHARED = [[" + strData + "]]";
		BString strFile = "lua/cw.lua";

		GetRelativePath(strFile);
		File::Write(strFile, strFileData);

		LUA->PushSpecial(SPECIAL_GLOB);
			LUA->GetField(-1, "AddCSLuaFile");
			LUA->PushString("cw.lua");
			LUA->Call(1, 0);
		LUA->Pop();

		return 0;
	}

	return 0;
}

int g_MD5(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strToMD5 = LUA->GetString(1);
		BString MD5 = Hasher::MD5::String(strToMD5);

		LUA->PushString(MD5.c_str());

		return 1;
	}

	LUA->PushString("");

	return 1;
}

int g_base64Encode(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strToEncode = LUA->GetString(1);

		String::Encode::Base64(strToEncode);

		LUA->PushString(strToEncode.c_str());

		return 1;
	}

	LUA->PushString("");

	return 1;
}

int g_base64Decode(lua_State* state)
{
	if (LUA->IsType(1, Type::STRING))
	{
		BString strToDecode = LUA->GetString(1);

		String::Decode::Base64(strToDecode);

		LUA->PushString(strToDecode.c_str());

		return 1;
	}

	LUA->PushString("");

	return 1;
}

GMOD_MODULE_OPEN()
{
	g_Lua = LUA;

	int iGlobalTable;
	LUA->PushSpecial(SPECIAL_GLOB);
	iGlobalTable = LUA->ReferenceCreate();

	int iCatioTable = Table::Create();
	Table::Insert(iCatioTable, "Write", g_Write);
	Table::Insert(iCatioTable, "Read", g_Read);

	Table::Insert(iCatioTable, "Append", g_Append);
	Table::Insert(iCatioTable, "Delete", g_Delete);
	Table::Insert(iCatioTable, "MakeDirectory", g_MakeDirectory);
	Table::Insert(iCatioTable, "Initialize", g_Initialize);
	Table::Insert(iCatioTable, "WriteCWLua", g_WriteCWLua);
	Table::Insert(iCatioTable, "md5", g_MD5);
	Table::Add(iGlobalTable, "catio", iCatioTable);

	int ibase64Table = Table::Create();
	Table::Insert(ibase64Table, "encode", g_base64Encode);
	Table::Insert(ibase64Table, "decode", g_base64Decode);
	Table::Add(iGlobalTable, "base64", ibase64Table);

	LUA->ReferenceFree(iGlobalTable);

	return 0;
}

GMOD_MODULE_CLOSE()
{
	return 0;
}