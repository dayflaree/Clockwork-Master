#pragma once

namespace Bootil
{
	namespace Time
	{
		BOOTIL_EXPORT unsigned long long	UnixTimestamp();
		BOOTIL_EXPORT Bootil::BString		UnixTimestampAsString();
	}

}