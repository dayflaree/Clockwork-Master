#pragma once
#include "Bootil/Bootil.h"

namespace Bootil
{
	namespace Threads
	{
		BOOTIL_EXPORT unsigned long long CurrentThreadID();
	}
}

