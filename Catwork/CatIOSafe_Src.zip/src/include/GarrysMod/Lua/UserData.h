
#ifndef GARRYSMOD_LUA_USERDATA_H
#define GARRYSMOD_LUA_USERDATA_H

namespace GarrysMod 
{
	namespace Lua
	{
		struct UserData
		{
			void*			data;
			unsigned char	type;
		};
	}
}

#endif 

