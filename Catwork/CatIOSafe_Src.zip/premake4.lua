solution "gmsv_catio_safe"
	language "C++"
	location (_WORKING_DIR.."/"..(_ACTION or ""))
	flags { "Symbols", "NoEditAndContinue", "NoPCH", "StaticRuntime", "EnableSSE", "OptimizeSpeed", "FloatFast" }
	targetdir ( "Release/" .. os.get() )
	includedirs { "src/include/" } 
	libdirs { "lib" }
	links { "bootil_static" }

	if (os.is("linux") or os.is("macosx")) then
		buildoptions {"-std=c++0x","-fpermissive","-fPIC"}
	end

	configurations
	{ 
		"Release"
	}
	
	configuration "Release"

	project "gmsv_catio_safe"
		defines { "GMMODULE" }
		files { "src/**.*", "src/include/**.*" }
		kind "SharedLib"

		targetname( "gmsv_catio_safe" )

		if (os.is("Windows")) then
			targetsuffix "_win32"
		elseif (os.is("linux")) then
			targetsuffix "_linux"
		end;
