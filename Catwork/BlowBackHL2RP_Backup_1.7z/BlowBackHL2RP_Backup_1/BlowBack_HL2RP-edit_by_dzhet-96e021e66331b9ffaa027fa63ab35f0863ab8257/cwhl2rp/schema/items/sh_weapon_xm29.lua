--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

ITEM.baseItem = "weapon_base"
ITEM.name = "XM29"
ITEM.PrintName = "XM29 OICW"
ITEM.cost = 400
ITEM.model = "models/leakwep/w_o1c4.mdl"
ITEM.weight = 4
ITEM.classes = {CLASS_EOW}
ITEM.uniqueID = "sxbase_oicw"
ITEM.business = true
ITEM.description = "Экспериментальный оружейный комплекс калибра <color=red>5.56х45мм</color>."
ITEM.isAttachment = true
ITEM.loweredOrigin = Vector(3, 0, -4)
ITEM.loweredAngles = Angle(0, 45, 0)
ITEM.attachmentBone = "ValveBiped.Bip01_Spine"
ITEM.attachmentOffsetAngles = Angle(0, 0, 0)
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97)
