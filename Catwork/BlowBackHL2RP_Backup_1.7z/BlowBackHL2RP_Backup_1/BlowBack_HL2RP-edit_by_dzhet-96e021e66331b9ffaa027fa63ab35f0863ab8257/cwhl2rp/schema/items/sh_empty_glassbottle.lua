
ITEM.name = "Empty Glass Bottle"
ITEM.PrintName = "Пустая бутылка"
ITEM.uniqueID = "empty_glass_bottle"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl"
ITEM.weight = 0.3
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая стеклянная бутылка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

