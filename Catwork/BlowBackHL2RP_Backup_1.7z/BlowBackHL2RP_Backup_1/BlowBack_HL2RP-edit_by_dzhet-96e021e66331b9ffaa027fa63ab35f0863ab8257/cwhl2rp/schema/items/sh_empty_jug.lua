
ITEM.name = "Empty Jug"
ITEM.PrintName = "Пустая бутыль"
ITEM.uniqueID = "empty_jug"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_milkcarton001a.mdl"
ITEM.weight = 0.38
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая бутыль."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

