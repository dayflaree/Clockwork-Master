
ITEM.name = "Empty Cardboard box"
ITEM.PrintName = "Пустая коробка"
ITEM.uniqueID = "empty_cardboard"
ITEM.cost = 0
ITEM.model = "models/bioshockinfinite/hext_cereal_box_cornflakes.mdl"
ITEM.weight = 0.1
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая коробка из под рациона."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

 