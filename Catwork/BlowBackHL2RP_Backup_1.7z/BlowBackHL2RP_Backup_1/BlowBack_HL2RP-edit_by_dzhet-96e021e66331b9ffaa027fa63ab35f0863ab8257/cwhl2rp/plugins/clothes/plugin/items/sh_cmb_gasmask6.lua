--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "gasmask6";
ITEM.PrintName = "Маска CmD";
ITEM.cost = 150;
ITEM.model = "models/half_life2/jnstudio/props/gasmask_6.mdl";
ITEM.plural = "Маски CmD";
ITEM.weight = 1;
ITEM.uniqueID = "cmb_gasmask6";
ITEM.business = false;
ITEM.bodyGroup = 2;
ITEM.bodyGroupVal = 6;
ITEM.description = "";
ITEM.isCombine = true;
ITEM.requiredBG = {5, 1};
