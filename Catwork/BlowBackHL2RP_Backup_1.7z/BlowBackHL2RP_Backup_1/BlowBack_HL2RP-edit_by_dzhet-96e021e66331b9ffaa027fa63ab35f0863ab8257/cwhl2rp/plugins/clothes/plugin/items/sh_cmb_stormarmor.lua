--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "stormarmor";
ITEM.PrintName = "Усиленный бронежилет";
ITEM.model = "models/half_life2/jnstudio/props/armor.mdl";
ITEM.plural = "Усиленные бронежилеты";
ITEM.weight = 5;
ITEM.uniqueID = "cmb_stormarmor";
ITEM.business = false;
ITEM.bodyGroup = 3;
ITEM.bodyGroupVal = 2;
ITEM.description = "";
ITEM.isCombine = true;
ITEM.protection = 25;
