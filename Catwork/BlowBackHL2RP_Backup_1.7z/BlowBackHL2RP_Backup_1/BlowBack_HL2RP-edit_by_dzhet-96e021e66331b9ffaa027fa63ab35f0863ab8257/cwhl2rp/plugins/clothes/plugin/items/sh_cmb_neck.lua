--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "vorotnik";
ITEM.PrintName = "Защитный воротник";
ITEM.cost = 100;
ITEM.model = "models/half_life2/jnstudio/props/neck.mdl";
ITEM.plural = "Защитные воротники";
ITEM.weight = 1;
ITEM.uniqueID = "cmb_vorotnik";
ITEM.business = false;
ITEM.bodyGroup = 5;
ITEM.bodyGroupVal = 1;
ITEM.description = "";
ITEM.isCombine = true;
ITEM.protection = 30;
