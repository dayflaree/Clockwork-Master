--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "gasmask2";
ITEM.PrintName = "Маска подразделения STORM";
ITEM.cost = 150;
ITEM.model = "models/half_life2/jnstudio/props/gasmask_2.mdl";
ITEM.plural = "Маски подразделения STORM";
ITEM.weight = 0.5;
ITEM.uniqueID = "cmb_gasmask2";
ITEM.business = false;
ITEM.bodyGroup = 2;
ITEM.bodyGroupVal = 2;
ITEM.description = "";
ITEM.isCombine = true;
ITEM.requiredBG = {5, 1};
