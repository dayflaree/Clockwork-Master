--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "citikrukaf"
ITEM.PrintName = "Гражданская униформа с коротким рукавом"
ITEM.cost = 80
ITEM.model = "models/tnb/items/shirt_citizen2.mdl"
ITEM.plural = "Гражданские униформы с коротким рукавом"
ITEM.weight = 0.4
ITEM.uniqueID = "cit_uniform_2"
ITEM.business = false
ITEM.bodyGroup = 1
ITEM.bodyGroupVal = 1
ITEM.description = "Обычная униформа, но с отрезанными рукавами."
