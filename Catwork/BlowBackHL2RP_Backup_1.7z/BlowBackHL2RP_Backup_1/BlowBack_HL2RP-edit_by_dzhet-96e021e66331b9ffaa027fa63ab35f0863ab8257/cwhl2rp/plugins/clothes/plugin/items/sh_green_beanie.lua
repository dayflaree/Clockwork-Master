--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "Green Beanie"
ITEM.PrintName = "#ITEM_Green_Beanie_Name"
ITEM.cost = 40
ITEM.model = "models/tnb/items/beaniewrap.mdl"
ITEM.plural = "#ITEM_Green_Beanie_Name_Plural"
ITEM.weight = 0.4
ITEM.uniqueID = "green_beanie"
ITEM.business = false
ITEM.bodyGroup = 4
ITEM.bodyGroupVal = 4
ITEM.description = "#ITEM_Green_Beanie_Desc"
