--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "Overwatch Unit Vest"
ITEM.PrintName = "Бронежилет ОТА Сопротивления"
ITEM.model = "models/tnb/items/shirt_rebeloverwatch.mdl"
ITEM.plural = "Бронежилеты ОТА Сопротивления"
ITEM.weight = 4
ITEM.uniqueID = "kevlar_ota"
ITEM.business = false
ITEM.bodyGroup = 1
ITEM.bodyGroupVal = 13
ITEM.description = "Бронежилет, снятый с солдата сверхнадзора."
ITEM.protection = 35
