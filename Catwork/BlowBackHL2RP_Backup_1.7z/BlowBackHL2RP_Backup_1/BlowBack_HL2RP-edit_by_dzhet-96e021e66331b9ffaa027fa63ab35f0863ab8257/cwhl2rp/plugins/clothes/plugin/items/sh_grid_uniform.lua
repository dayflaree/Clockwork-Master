--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "skin_base"
ITEM.name = "GRID Uniform";
ITEM.PrintName = "Униформа GRID";
ITEM.model = "models/half_life2/jnstudio/props/sheet_1.mdl";
ITEM.plural = "Униформы GRID";
ITEM.weight = 2;
ITEM.uniqueID = "grid_uniform";
ITEM.business = false;
ITEM.playerSkin = 1;
ITEM.description = "Чистая и новая униформа отряда GRID.";
ITEM.protection = 10;
ITEM.isCombine = true;
