--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "Black Jeans"
ITEM.PrintName = "#ITEM_Black_Legs_Name"
ITEM.cost = 75
ITEM.model = "models/tnb/items/pants_citizen.mdl"
ITEM.skin = 3
ITEM.plural = "#ITEM_Black_Legs_Plural"
ITEM.weight = 0.5
ITEM.uniqueID = "loyalist_legs"
ITEM.business = false
ITEM.bodyGroup = 2
ITEM.bodyGroupVal = 3
ITEM.description = "#ITEM_Black_Legs_Desc"
