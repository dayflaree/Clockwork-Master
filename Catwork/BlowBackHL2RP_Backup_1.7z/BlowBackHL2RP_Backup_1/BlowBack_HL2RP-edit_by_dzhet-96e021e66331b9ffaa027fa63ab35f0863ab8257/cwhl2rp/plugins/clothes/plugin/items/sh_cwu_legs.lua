--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "Bright Jeans"
ITEM.PrintName = "#ITEM_CWU_Legs_Name"
ITEM.cost = 60
ITEM.model = "models/tnb/items/pants_citizen.mdl"
ITEM.skin = 1
ITEM.plural = "#ITEM_CWU_Legs_Plural"
ITEM.weight = 0.5
ITEM.uniqueID = "cwu_legs"
ITEM.business = false
ITEM.bodyGroup = 2
ITEM.bodyGroupVal = 1
ITEM.description = "#ITEM_CWU_Legs_Desc"
