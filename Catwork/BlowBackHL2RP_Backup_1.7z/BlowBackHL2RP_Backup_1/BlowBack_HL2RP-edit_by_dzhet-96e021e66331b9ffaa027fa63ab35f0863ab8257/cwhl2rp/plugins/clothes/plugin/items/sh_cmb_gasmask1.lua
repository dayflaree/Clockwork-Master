--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

ITEM.baseItem = "bodygroup_base"
ITEM.name = "gasmask1";
ITEM.PrintName = "Маска Юнита ГО";
ITEM.cost = 150;
ITEM.model = "models/half_life2/jnstudio/props/coat.mdl";
ITEM.plural = "Маски Юнитов ГО";
ITEM.weight = 0.5;
ITEM.uniqueID = "cmb_gasmask1";
ITEM.business = false;
ITEM.bodyGroup = 2;
ITEM.bodyGroupVal = 1;
ITEM.description = "";
ITEM.isCombine = true;
ITEM.requiredBG = {5, 1};
