local PLUGIN = PLUGIN
local CW = CW

util.Include("sv_plugin.lua");