﻿local PLUGIN = PLUGIN
local Clockwork = Clockwork

local weapons = {"sxbase_", "weapon_"}
local function checkWeapon(weapon)
	for k, v in pairs(weapons) do
		if string.find(weapon,v) then
			return true
		end
	end
end

util.Include("cl_plugin.lua")

if SERVER then
	util.AddNetworkString("CP_Spotted")
	util.AddNetworkString("CP_SpottedSend")

	local spottedVoices = {
		["player"] = {
			[1] = {
				text = "Вижу его! Подозреваемый на моём 10-20!",
				sound = "gothimagainsuspect10-20at.wav"
			},
			[2] = {
				text = "Вижу его.",
				sound = "acquiringonvisual.wav"
			},
			[3] = {
				text = "Здесь подозреваемый.",
				sound = "gotsuspect1here.wav"
			},
			[4] = {
				text = "Вот он! На моё 10-20.",
				sound = "hesupthere.wav"
			},
			[5] = {
				text = "Объект подходит по ориентировке.",
				sound = "matchonapblikeness.wav"
			},
			[6] = {
				text = "Возможно здесь 404.",
				sound = "possible404here.wav"
			},
			[7] = {
				text = "Нарушитель с оружием! На моём 10-20.",
				sound = "shotsfiredhostilemalignants.wav",
				hasweapon = true
			},
			[8] = {
				text = "Объект, код 505!",
				sound = "subjectis505.wav",
				hasweapon = true
			},
			[9] = {
				text = "Он убегает!",
				sound = "hesrunning.wav",
				running = true
			},
			[10] = {
				text = "Уходит, 148!",
				sound = "hesgone148.wav",
				running = true
			},
		},
		["npc_headcrab"] = {
			[1] = {
				text = "Паразиты!",
				sound = "looseparasitics.wav"
			}
		},
		["npc_headcrab_black"] = {
			[1] = {
				text = "Паразиты!",
				sound = "looseparasitics.wav"
			}
		},
		["npc_headcrab_fast"] = {
			[1] = {
				text = "Паразиты!",
				sound = "looseparasitics.wav"
			}
		},
		["npc_barnacle"] = {
			[1] = {
				text = "Паразиты!",
				sound = "looseparasitics.wav"
			}
		},
		["npc_zombie"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_poisonzombie"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_zombie_torso"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_fastzombie"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_fastzombie_torso"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_zombine"] = {
			[1] = {
				text = "Нежить!",
				sound = "necrotics.wav"
			}
		},
		["npc_antlion"] = {
			[1] = {
				text = "Жуки!",
				sound = "bugs.wav"
			}
		},
		["npc_antlion_grub"] = {
			[1] = {
				text = "Жуки!",
				sound = "bugs.wav"
			}
		},
		["npc_antlion_worker"] = {
			[1] = {
				text = "Жуки!",
				sound = "bugs.wav"
			}
		},
		["npc_antlionguard"] = {
			[1] = {
				text = "Неподконтрольные жуки!",
				sound = "bugsontheloose.wav"
			}
		},
		["npc_antlionguardian"] = {
			[1] = {
				text = "Неподконтрольные жуки!",
				sound = "bugsontheloose.wav"
			}
		}
	}

	net.Receive("CP_Spotted", function(len, ply)
		if ply.nextSpotted and ply.nextSpotted > CurTime() then return end

		local ent = net.ReadString()
		ent = Entity(tonumber(ent))

		if Schema:PlayerIsCombine(ply) then
			if ent:IsPlayer() or ent:IsNPC() then
				if ent:IsPlayer() then
					if Schema:PlayerIsCombine(ent) then return end
				end

				for k, v in pairs(player.GetAll()) do
					if !Schema:PlayerIsCombine(v) then continue end

					net.Start("CP_SpottedSend")
						net.WriteString(ent:EntIndex())
						net.WriteString("25")
					net.Send(v)
				end

				local voice = spottedVoices[ent:GetClass()]
				if !voice then
					voice = spottedVoices["player"]
				end

				local weapon = ent:GetActiveWeapon()
				if IsValid(weapon) and checkWeapon(weapon:GetClass()) then
					local voices = {}
					for k, v in pairs(voice) do
						if !v.hasweapon then continue end
						if checkWeapon(weapon:GetClass()) then
							local t = {
								text = v.text,
								sound = v.sound
							}
							table.insert(voices, t)
						end
					end
					local selected = table.Random(voices)
					--cw.command:ConsoleCommand(ply, "r", {"r",selected.text})
					ply:CombineRequestSay(selected.text)
					--chatbox.AddText(nil, selected.text, {suffix = " говорит в рацию: ", sender = ply, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(75, 150, 50, 255), data = {radio = true}})
					ply:EmitSound("npc/metropolice/vo/" .. selected.sound)
				else
					local voices = {}
					if ent:IsPlayer() then
						local running = ent:IsRunning()
						for k, v in pairs(voice) do
							if v.hasweapon then continue end
							if !running then
								if v.running then continue end
							else
								if !v.running then continue end
							end
							local t = {
								text = v.text,
								sound = v.sound
							}
							table.insert(voices, t)
						end
					else
						for k, v in pairs(voice) do
							if v.hasweapon then continue end
							if v.running then continue end
							local t = {
								text = v.text,
								sound = v.sound
							}
							table.insert(voices, t)
						end
					end

					local selected = table.Random(voices)
					--cw.command:ConsoleCommand(ply, "r", {"r",selected.text})
					ply:CombineRequestSay(selected.text)
					--chatbox.AddText(nil, selected.text, {suffix = " говорит в рацию: ", sender = ply, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(75, 150, 50, 255), data = {radio = true}})
					ply:EmitSound("npc/metropolice/vo/" .. selected.sound)
				end
			end
			ply.nextSpotted = CurTime() + 2.1
		end
	end)

	local function checkConvar(qcop)
		if qcop != chat or qcop != "y" or qcop != "w" then
			return true
		end
	end

	local meta = FindMetaTable("Player")
	function meta:HandleMenu_Radio1(typ, sector, code)
		if !Schema:PlayerIsCombine(self) then return end
		if !self:Alive() then return end
		if self:GetRagdollState() == RAGDOLL_FALLENOVER then return end
		if self.m_flRadioTime and self.m_flRadioTime > CurTime() then return end

		self.m_flRadioTime = CurTime() + 1.5

		local gender = self:GetGender()
		local uniqueID = string.Right(self:GetName(), 3)
		local e = tonumber(string.sub(uniqueID,#uniqueID,#uniqueID))
		local article = ""

		if gender == GENDER_MALE then
			if e == 1 or e == 9 or e == 4 or e == 5 or e== 0 then
				article = "-ый"
			elseif e == 3 then
				article = "-ий"
			else
				article = "-ой"
			end
		elseif gender == GENDER_FEMALE then
			if e == 3 then
				article = "-ья"
			else
				article = "-ая"
			end
		end

		local text = "Это "..uniqueID..article

		if typ == "my1020" then
			text = text .. ". Моё 10-20: "..sector.. ". Код 12, 100."
		elseif typ == "404" then
			text = text .. ". У меня тут возможно есть 404, код 3. Моё 10-20: " .. sector .. "."
		elseif typ == "biotics" then
			text = text .. ". На моё 10-20 возможны биотики или нежить, код 3. Моё 10-20: " .. sector .. "."
		elseif typ == "backup" then
			text = text .. "! Запрашиваю поддержку! Моё 10-20: " .. sector .. ". Код "..code.."."
			for k, v in pairs(player.GetAll()) do
				if !Schema:PlayerIsCombine(v) then continue end

				net.Start("CP_SpottedSend")
					net.WriteString(self:EntIndex())
					net.WriteString("70")
				net.Send(v)
			end
		elseif typ == "leave" then
			text = text .. ". Покидаю свою позицию в 10-20: " .. sector .. "."
		elseif typ == "r_doc_health" then
			local armor = self:Armor()
			local armorstatus = math.Round((armor / 150) * 100)

			local health = self:Health()
			local healthstatus = "Здоров"
			if health > 65 and health < 98 then
				healthstatus = "Слабо ранен"
			elseif health > 30 and health < 65 then
				healthstatus = "Серьёзно ранен"
			elseif health < 30 then
				healthstatus = "При смерти"
			end

			text = text .. ". Состояние здоровья: "..healthstatus..". Состояние бронежитета: "..armorstatus.."%."
		elseif typ == "r_doc_status" then
			text = text .. "."

			local units = {}
			local cit = 0
			local cwu = 0
			local vortigaunt = 0
			for k, v in pairs(ents.FindInSphere(self:GetPos(),200)) do
				if !v:IsPlayer() then continue end
				if v == self then continue end
				if Schema:PlayerIsCombine(v) then
					if v:IsLineOfSightClear(self:EyePos()) then
						table.insert(units, string.Right(v:GetName(),3))
					end
				else
					if v:GetFaction() == FACTION_CITIZEN then
						cit = cit + 1
					elseif v:GetFaction() == FACTION_CWU then
						cwu = cwu + 1
					elseif v:GetFaction() == FACTION_VORT then
						vortigaunt = vortigaunt + 1
					end
				end
			end
			text = text .. " Со мной "
			if #units != 0 then
				text = text .. "юнит" .. ((#units > 1) and "ы: " or " ")
				for k, v in pairs(units) do
					text = text .. v .. (k != #units and "," or "")
				end
			end
			if cit != 0 then
				text = text .. cit .. " граждан" .. ((cit > 1) and "" or "ин")
			end
			if cwu != 0 then
				text = text .. cwu .. " сотрудник" .. ((cwu > 1) and "ов " or " ") .. "ГСР"
			end
			if vortigaunt != 0 then
				text = text .. vortigaunt .. " вортигонт" .. ((vortigaunt > 1) and "ов" or "")
			end
			if #units == 0 and cit == 0 and cwu == 0 and vortigaunt == 0 then
				text = text .. "никого"
			end
		end

		self:CombineRequestSay(text)
	end

	function meta:HandleMenu_Radio2(slot)
		if !Schema:PlayerIsCombine(self) then return end
		if !self:Alive() then return end
		if self:GetRagdollState() == RAGDOLL_FALLENOVER then return end
		if self.m_flRadioTime and self.m_flRadioTime > CurTime() then return end
		local chat = self:GetInfo("cl_qcop_radio")
		local radius = config.GetVal("talk_radius")

		self.m_flRadioTime = CurTime() + 1.5

		if chat != "say" then
			if slot == 1 then
				cw.command:ConsoleCommand(self, chat, {chat,"Citizen"})
				return
			elseif slot == 2 then
				cw.command:ConsoleCommand(self, chat, {chat,"Don't Move!"})
				self:EmitSound("npc/metropolice/vo/dontmove.wav")
				return
			elseif slot == 3 then
				cw.command:ConsoleCommand(self, chat, {chat,"Escapee"})
				return
			elseif slot == 4 then
				cw.command:ConsoleCommand(self, chat, {chat,"Anti-Citizen"})
				return
			elseif slot == 5 then
				cw.command:ConsoleCommand(self, chat, {chat,"Judgement"})
				return
			elseif slot == 6 then
				cw.command:ConsoleCommand(self, chat, {chat,"Amputate Ready"})
				return
			elseif slot == 7 then
				cw.command:ConsoleCommand(self, chat, {chat,"Amputate"})
				return
			elseif slot == 8 then
				cw.command:ConsoleCommand(self, chat, {chat,"Hardpoint"})
				return
			elseif slot == 9 then
				cw.command:ConsoleCommand(self, chat, {chat,"Move Along"})
				return
			end
		else
			if slot == 1 then
				--self:ConCommand("cwSay Citizen")
				chatbox.AddText(nil, "Citizen", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 2 then
				--self:ConCommand("cwSay Don't Move!")
				chatbox.AddText(nil, "Don't Move!", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				self:EmitSound("npc/metropolice/vo/dontmove.wav")
				return
			elseif slot == 3 then
				--self:ConCommand("cwSay Escapee")
				chatbox.AddText(nil, "Escapee", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 4 then
				--self:ConCommand("cwSay Anti-Citizen")
				chatbox.AddText(nil, "Anti-Citizen", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 5 then
				--self:ConCommand("cwSay Judgement")
				chatbox.AddText(nil, "Judgement", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 6 then
				--self:ConCommand("cwSay Amputate Ready")
				chatbox.AddText(nil, "Amputate Ready", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 7 then
				--self:ConCommand("cwSay Amputate")
				chatbox.AddText(nil, "Amputate", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 8 then
				--self:ConCommand("cwSay Hardpoint")
				chatbox.AddText(nil, "Hardpoint", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 9 then
				--self:ConCommand("cwSay Move Along")
				chatbox.AddText(nil, "Move Along", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			end			
		end
	end
	function meta:HandleMenu_Radio3(slot)
		if !Schema:PlayerIsCombine(self) then return end
		if !self:Alive() then return end
		if self:GetRagdollState() == RAGDOLL_FALLENOVER then return end
		if self.m_flRadioTime and self.m_flRadioTime > CurTime() then return end
		local chat = self:GetInfo("cl_qcop_radio")
		local radius = config.GetVal("talk_radius")

		self.m_flRadioTime = CurTime() + 1.5
		if chat != "say" then
			if slot == 1 then
				cw.command:ConsoleCommand(self, chat, {chat,"Go Sharp"})
				return
			elseif slot == 2 then
				cw.command:ConsoleCommand(self, chat, {chat,"Heavy Resistance"})
				return
			elseif slot == 3 then
				cw.command:ConsoleCommand(self, chat, {chat,"Minor Hits"})
				return
			elseif slot == 4 then
				cw.command:ConsoleCommand(self, chat, {chat,"Necrotics"})
				return
			elseif slot == 5 then
				cw.command:ConsoleCommand(self, chat, {chat,"505"})
				return
			elseif slot == 6 then
				cw.command:ConsoleCommand(self, chat, {chat,"Inject"})
				return
			elseif slot == 7 then
				cw.command:ConsoleCommand(self, chat, {chat,"Cleaned"})
				return
			elseif slot == 8 then
				cw.command:ConsoleCommand(self, chat, {chat,"Backup"})
				return
			elseif slot == 9 then
				cw.command:ConsoleCommand(self, chat, {chat,"Move In"})
				return
			end
		else
			if slot == 1 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Go Sharp", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 2 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Heavy Resistance", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 3 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Minor Hits", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 4 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Necrotics", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 5 then
				--self:ConCommand("cwSay 505")
				chatbox.AddText(nil, "505", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 6 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Inject", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 7 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Cleaned", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 8 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Backup", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			elseif slot == 9 then
				--self:ConCommand("cwSay ")
				chatbox.AddText(nil, "Move In", {sender = self, isPlayerMessage = true, filter = "ic", radius = radius, textColor = Color(255, 255, 200, 255)})
				return
			end
		end		
	end

	concommand.Add("r_doc_my1020_gp", function(ply) ply:HandleMenu_Radio1("my1020", "ГП") end)
	concommand.Add("r_doc_my1020_cwu", function(ply) ply:HandleMenu_Radio1("my1020", "Офис ГСР") end)
	concommand.Add("r_doc_my1020_block_a", function(ply) ply:HandleMenu_Radio1("my1020", "Жилой Блок A") end)
	concommand.Add("r_doc_my1020_block_b", function(ply) ply:HandleMenu_Radio1("my1020", "Жилой Блок B") end)
	concommand.Add("r_doc_my1020_block_c", function(ply) ply:HandleMenu_Radio1("my1020", "Жилой Блок C") end)
	concommand.Add("r_doc_my1020_d1", function(ply) ply:HandleMenu_Radio1("my1020", "D-1") end)
	concommand.Add("r_doc_my1020_d2", function(ply) ply:HandleMenu_Radio1("my1020", "D-2") end)
	concommand.Add("r_doc_my1020_d3", function(ply) ply:HandleMenu_Radio1("my1020", "D-3") end)
	concommand.Add("r_doc_my1020_d4", function(ply) ply:HandleMenu_Radio1("my1020", "D-4") end)
	concommand.Add("r_doc_my1020_d5", function(ply) ply:HandleMenu_Radio1("my1020", "D-5") end)
	concommand.Add("r_doc_my1020_d6", function(ply) ply:HandleMenu_Radio1("my1020", "D-6") end)
	concommand.Add("r_doc_404_gp", function(ply) ply:HandleMenu_Radio1("404", "ГП") end)
	concommand.Add("r_doc_404_cwu", function(ply) ply:HandleMenu_Radio1("404", "Офис ГСР") end)
	concommand.Add("r_doc_404_block_a", function(ply) ply:HandleMenu_Radio1("404", "Жилой Блок A") end)
	concommand.Add("r_doc_404_block_b", function(ply) ply:HandleMenu_Radio1("404", "Жилой Блок B") end)
	concommand.Add("r_doc_404_block_c", function(ply) ply:HandleMenu_Radio1("404", "Жилой Блок C") end)
	concommand.Add("r_doc_404_d1", function(ply) ply:HandleMenu_Radio1("404", "D-1") end)
	concommand.Add("r_doc_404_d2", function(ply) ply:HandleMenu_Radio1("404", "D-2") end)
	concommand.Add("r_doc_404_d3", function(ply) ply:HandleMenu_Radio1("404", "D-3") end)
	concommand.Add("r_doc_404_d4", function(ply) ply:HandleMenu_Radio1("404", "D-4") end)
	concommand.Add("r_doc_404_d5", function(ply) ply:HandleMenu_Radio1("404", "D-5") end)
	concommand.Add("r_doc_404_d6", function(ply) ply:HandleMenu_Radio1("404", "D-6") end)
	concommand.Add("r_doc_status", function(ply) ply:HandleMenu_Radio1("r_doc_status") end)
	concommand.Add("r_doc_health", function(ply) ply:HandleMenu_Radio1("r_doc_health") end)
	concommand.Add("r_doc_biotics_gp", function(ply) ply:HandleMenu_Radio1("biotics", "ГП") end)
	concommand.Add("r_doc_biotics_cwu", function(ply) ply:HandleMenu_Radio1("biotics", "Офис ГСР") end)
	concommand.Add("r_doc_biotics_block_a", function(ply) ply:HandleMenu_Radio1("biotics", "Жилой Блок A") end)
	concommand.Add("r_doc_biotics_block_b", function(ply) ply:HandleMenu_Radio1("biotics", "Жилой Блок B") end)
	concommand.Add("r_doc_biotics_block_c", function(ply) ply:HandleMenu_Radio1("biotics", "Жилой Блок C") end)
	concommand.Add("r_doc_biotics_d1", function(ply) ply:HandleMenu_Radio1("biotics", "D-1") end)
	concommand.Add("r_doc_biotics_d2", function(ply) ply:HandleMenu_Radio1("biotics", "D-2") end)
	concommand.Add("r_doc_biotics_d3", function(ply) ply:HandleMenu_Radio1("biotics", "D-3") end)
	concommand.Add("r_doc_biotics_d4", function(ply) ply:HandleMenu_Radio1("biotics", "D-4") end)
	concommand.Add("r_doc_biotics_d5", function(ply) ply:HandleMenu_Radio1("biotics", "D-5") end)
	concommand.Add("r_doc_biotics_d6", function(ply) ply:HandleMenu_Radio1("biotics", "D-6") end)
	concommand.Add("r_doc_backup_gp_1", function(ply) ply:HandleMenu_Radio1("backup", "ГП", 1) end)
	concommand.Add("r_doc_backup_cwu_1", function(ply) ply:HandleMenu_Radio1("backup", "Офис ГСР", 1) end)
	concommand.Add("r_doc_backup_block_a_1", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок A", 1) end)
	concommand.Add("r_doc_backup_block_b_1", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок B", 1) end)
	concommand.Add("r_doc_backup_block_c_1", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок C", 1) end)
	concommand.Add("r_doc_backup_d1_1", function(ply) ply:HandleMenu_Radio1("backup", "D-1", 1) end)
	concommand.Add("r_doc_backup_d2_1", function(ply) ply:HandleMenu_Radio1("backup", "D-2", 1) end)
	concommand.Add("r_doc_backup_d3_1", function(ply) ply:HandleMenu_Radio1("backup", "D-3", 1) end)
	concommand.Add("r_doc_backup_d4_1", function(ply) ply:HandleMenu_Radio1("backup", "D-4", 1) end)
	concommand.Add("r_doc_backup_d5_1", function(ply) ply:HandleMenu_Radio1("backup", "D-5", 1) end)
	concommand.Add("r_doc_backup_d6_1", function(ply) ply:HandleMenu_Radio1("backup", "D-6", 1) end)
	concommand.Add("r_doc_backup_gp_2", function(ply) ply:HandleMenu_Radio1("backup", "ГП", 2) end)
	concommand.Add("r_doc_backup_cwu_2", function(ply) ply:HandleMenu_Radio1("backup", "Офис ГСР", 2) end)
	concommand.Add("r_doc_backup_block_a_2", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок A", 2) end)
	concommand.Add("r_doc_backup_block_b_2", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок B", 2) end)
	concommand.Add("r_doc_backup_block_c_2", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок C", 2) end)
	concommand.Add("r_doc_backup_d1_2", function(ply) ply:HandleMenu_Radio1("backup", "D-1", 2) end)
	concommand.Add("r_doc_backup_d2_2", function(ply) ply:HandleMenu_Radio1("backup", "D-2", 2) end)
	concommand.Add("r_doc_backup_d3_2", function(ply) ply:HandleMenu_Radio1("backup", "D-3", 2) end)
	concommand.Add("r_doc_backup_d4_2", function(ply) ply:HandleMenu_Radio1("backup", "D-4", 2) end)
	concommand.Add("r_doc_backup_d5_2", function(ply) ply:HandleMenu_Radio1("backup", "D-5", 2) end)
	concommand.Add("r_doc_backup_d6_2", function(ply) ply:HandleMenu_Radio1("backup", "D-6", 2) end)
	concommand.Add("r_doc_backup_gp_3", function(ply) ply:HandleMenu_Radio1("backup", "ГП", 3) end)
	concommand.Add("r_doc_backup_cwu_3", function(ply) ply:HandleMenu_Radio1("backup", "Офис ГСР", 3) end)
	concommand.Add("r_doc_backup_block_a_3", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок A", 3) end)
	concommand.Add("r_doc_backup_block_b_3", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок B", 3) end)
	concommand.Add("r_doc_backup_block_c_3", function(ply) ply:HandleMenu_Radio1("backup", "Жилой Блок C", 3) end)
	concommand.Add("r_doc_backup_d1_3", function(ply) ply:HandleMenu_Radio1("backup", "D-1", 3) end)
	concommand.Add("r_doc_backup_d2_3", function(ply) ply:HandleMenu_Radio1("backup", "D-2", 3) end)
	concommand.Add("r_doc_backup_d3_3", function(ply) ply:HandleMenu_Radio1("backup", "D-3", 3) end)
	concommand.Add("r_doc_backup_d4_3", function(ply) ply:HandleMenu_Radio1("backup", "D-4", 3) end)
	concommand.Add("r_doc_backup_d5_3", function(ply) ply:HandleMenu_Radio1("backup", "D-5", 3) end)
	concommand.Add("r_doc_backup_d6_3", function(ply) ply:HandleMenu_Radio1("backup", "D-6", 3) end)
	concommand.Add("r_doc_leave_gp", function(ply) ply:HandleMenu_Radio1("leave", "ГП") end)
	concommand.Add("r_doc_leave_cwu", function(ply) ply:HandleMenu_Radio1("leave", "Офис ГСР") end)
	concommand.Add("r_doc_leave_block_a", function(ply) ply:HandleMenu_Radio1("leave", "Жилой Блок A") end)
	concommand.Add("r_doc_leave_block_b", function(ply) ply:HandleMenu_Radio1("leave", "Жилой Блок B") end)
	concommand.Add("r_doc_leave_block_c", function(ply) ply:HandleMenu_Radio1("leave", "Жилой Блок C") end)
	concommand.Add("r_doc_leave_d1", function(ply) ply:HandleMenu_Radio1("leave", "D-1") end)
	concommand.Add("r_doc_leave_d2", function(ply) ply:HandleMenu_Radio1("leave", "D-2") end)
	concommand.Add("r_doc_leave_d3", function(ply) ply:HandleMenu_Radio1("leave", "D-3") end)
	concommand.Add("r_doc_leave_d4", function(ply) ply:HandleMenu_Radio1("leave", "D-4") end)
	concommand.Add("r_doc_leave_d5", function(ply) ply:HandleMenu_Radio1("leave", "D-5") end)
	concommand.Add("r_doc_leave_d6", function(ply) ply:HandleMenu_Radio1("leave", "D-6") end)

	concommand.Add("r_citizen", function(ply) ply:HandleMenu_Radio2(1) end)
	concommand.Add("r_dontmove", function(ply) ply:HandleMenu_Radio2(2) end)
	concommand.Add("r_escape", function(ply) ply:HandleMenu_Radio2(3) end)
	concommand.Add("r_anticitizen", function(ply) ply:HandleMenu_Radio2(4) end)
	concommand.Add("r_judge", function(ply) ply:HandleMenu_Radio2(5) end)
	concommand.Add("r_amputateready", function(ply) ply:HandleMenu_Radio2(6) end)
	concommand.Add("r_amputate", function(ply) ply:HandleMenu_Radio2(7) end)
	concommand.Add("r_hardpoint", function(ply) ply:HandleMenu_Radio2(8) end)
	concommand.Add("r_movealong", function(ply) ply:HandleMenu_Radio2(9) end)

	concommand.Add("r_gosharp", function(ply) ply:HandleMenu_Radio3(1) end)
	concommand.Add("r_heavyresist", function(ply) ply:HandleMenu_Radio3(2) end)
	concommand.Add("r_minorhits", function(ply) ply:HandleMenu_Radio3(3) end)
	concommand.Add("r_necrotics", function(ply) ply:HandleMenu_Radio3(4) end)
	concommand.Add("r_505", function(ply) ply:HandleMenu_Radio3(5) end)
	concommand.Add("r_inject", function(ply) ply:HandleMenu_Radio3(6) end)
	concommand.Add("r_cleaned", function(ply) ply:HandleMenu_Radio3(7) end)
	concommand.Add("r_backup", function(ply) ply:HandleMenu_Radio3(8) end)
	concommand.Add("r_movein", function(ply) ply:HandleMenu_Radio3(9) end)
end
