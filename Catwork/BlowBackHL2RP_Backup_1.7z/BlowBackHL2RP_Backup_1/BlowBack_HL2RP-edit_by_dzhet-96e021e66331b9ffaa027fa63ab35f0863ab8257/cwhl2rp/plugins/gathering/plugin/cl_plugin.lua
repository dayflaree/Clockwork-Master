--[[
	Catwork � 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

config.AddToSystem("Nodes Respawn Delay", "nodes_respawn_delay", "Rate at which the Gather spawn point respawns (in seconds).", 0, 3600)