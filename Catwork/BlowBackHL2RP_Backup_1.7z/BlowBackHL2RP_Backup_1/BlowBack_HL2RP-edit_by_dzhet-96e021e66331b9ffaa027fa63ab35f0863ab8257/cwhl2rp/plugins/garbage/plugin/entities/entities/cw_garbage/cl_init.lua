--[[
	Catwork � 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:Initialize()

end

function ENT:Think()

end

