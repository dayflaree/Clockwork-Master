ENT.Base = "base_gmodentity"
ENT.Type = "anim"

ENT.PrintName = "Check monitor"
ENT.Category = "HL2RP"
ENT.Author = "DrodA, AleXXX_007, CYKA AAAAAAAAAAAAAA"

ENT.Contact			= ""
ENT.Purpose 		= ""
ENT.Instructions 	= ""

ENT.Spawnable			= true
ENT.AdminSpawnable		= true

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.Model = "models/props_combine/combine_smallmonitor001.mdl"