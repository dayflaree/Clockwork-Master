--[[
	© 2017 TeslaCloud Studios.
	Do not share, re-distribute or sell.
--]]

netstream.Hook("Application::PDA::Controller::CitizenStatus", function(player, target, status)
	if (!util.Validate(player, target)) then return end
	
	local isCombine = Schema:PlayerIsCombine(player)
	local isCWU = (isCombine or (player:GetFaction() == FACTION_CWU))

	if ((status == "Unverified" or status == "Citizen") and !isCWU) then
		cw.player:Notify(player, "You are not a Civil Worker's Union worker or the Combine!")

		return
	end

	if ((status == "AntiCitizen" or status == "NoData") and !isCombine) then
		cw.player:Notify(player, "You are not the Combine!")

		return
	end

	Schema:SetCitizenStatus(target, status)

	cw.player:Notify(player, "You have set "..target:Name().."'s citizen status to #Status_"..status..":;.")
end)

netstream.Hook("Application::PDA::Controller::Residence", function(player, target, address)
	if (!util.Validate(player, target)) then return end
	
	if (Schema:PlayerIsCombine(player) or player:GetFaction() == FACTION_CWU) then
		Schema:SetResidence(target, address)

		cw.player:Notify(player, target:Name().."'s residential address was set to "..address)
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::Job", function(player, target, job)
	if (!util.Validate(player, target)) then return end
	
	if (Schema:PlayerIsCombine(player) or player:GetFaction() == FACTION_CWU) then
		Schema:SetJob(target, job)

		cw.player:Notify(player, target:Name().."'s job was set to "..job)
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::LP", function(player, target, value)
	if (!util.Validate(player, target)) then return end

	if (Schema:PlayerIsCombine(player)) then
		value = math.Clamp(tonumber(value), 0, 10)

		Schema:AddLP(target, value)

		cw.player:Notify(player, "Issued "..value.." loyalty points to "..target:Name()..".")
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::CP", function(player, target, value)
	if (!util.Validate(player, target)) then return end

	if (Schema:PlayerIsCombine(player)) then
		value = math.Clamp(tonumber(value), 0, 20)

		Schema:AddCP(target, value)

		cw.player:Notify(player, "Issued "..value.." crime points to "..target:Name()..".")
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::WP", function(player, target, value)
	if (!util.Validate(player, target)) then return end

	if (Schema:PlayerIsCombine(player) or player:GetFaction() == FACTION_CWU) then
		value = math.Clamp(tonumber(value), 0, 20)

		Schema:AddWorkPoints(target, value)

		cw.player:Notify(player, "Issued "..value.." work points to "..target:Name()..".")
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::Jail", function(player, target)
	if (!util.Validate(player, target)) then return end

	if (Schema:PlayerIsCombine(player)) then
		Schema:SetJailed(target, true)

		cw.player:Notify(player, "Isolation order for "..target:Name().." has been successfully executed!")
		cw.player:Notify(target, "You are now under isolation!")
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)

netstream.Hook("Application::PDA::Controller::Unjail", function(player, target)
	if (!util.Validate(player, target)) then return end

	if (Schema:PlayerIsCombine(player)) then
		Schema:SetJailed(target, false)

		cw.player:Notify(player, "Isolation order for "..target:Name().." has been successfully removed!")
		cw.player:Notify(target, "You are no longer under isolation!")
	else
		cw.player:Notify(player, "You are not the Combine!")
	end
end)