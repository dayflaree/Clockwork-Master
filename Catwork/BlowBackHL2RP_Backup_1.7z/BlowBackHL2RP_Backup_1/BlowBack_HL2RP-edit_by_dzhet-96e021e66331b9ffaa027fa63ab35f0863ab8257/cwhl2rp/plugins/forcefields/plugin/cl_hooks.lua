local PLUGIN = PLUGIN;

function PLUGIN:PlayerCanGetUp()
	local entities = ents.FindInSphere(cw.client:GetPos(), 200);

	for k, v in pairs(entities) do
		if (v:GetClass() == "cw_forcefield") then
			return false
		end;
	end;
end;