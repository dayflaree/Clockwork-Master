include("shared.lua");

function ENT:Draw()
	self:DrawModel();
end;

function ENT:Initialize()
	local soundLoop = Sound("combine.sheild_loop");
	self.soundLoop = {};
	self.soundLoop.sound = CreateSound(self, soundLoop);
	self.soundLoop.status = false;

	local soundTouch = Sound("combine.sheild_touch");
	self.soundTouch = {};
	self.soundTouch.sound = CreateSound(self, soundTouch);
	self.soundTouch.status = false;
end;

function ENT:Think()
	if (IsValid(cw.client)) then
		if (self:GetPos():Distance(cw.client:GetPos()) < 250) then
			if (!self.soundLoop.status) then
				self.soundLoop.sound:Play();
				self.soundLoop.status = true;
			end;
		else
			if (self.soundLoop.status) then
				self.soundLoop.sound:Stop();
				self.soundLoop.status = false;
			end;
		end;
		if (!Schema:PlayerIsCombine(cw.client)) then
			if (self:GetPos():Distance(cw.client:GetPos()) < 105) then
				if (!self.soundTouch.status) then
					self.soundTouch.sound:Play();
					self.soundTouch.status = true;
				end;
			else
				if (self.soundTouch.status) then
					self.soundTouch.sound:FadeOut(2);
					self.soundTouch.status = false;
				end;
			end;
		end;
	end;
end;