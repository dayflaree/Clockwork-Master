--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

ITEM.baseItem = "seeds_base"
ITEM.name = "Banana Seeds"
ITEM.PrintName = "Семена банана"
ITEM.description = "Коробочка с семенами банана внутри."
ITEM.uniqueID = "seed_banana"
ITEM.PlantModel = "models/props/cs_office/plant01_p1.mdl"
ITEM.PlantName = "Банан"
ITEM.GrowTime = {2800, 3000}
ITEM.Harvest = {"seed_banana", "banana"}


