--[[
	© 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

CW.config:Add("hunger_tick", 3600, true);
CW.config:Add("hunger_default_refill", 25, true);