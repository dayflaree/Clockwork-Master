CW.config:AddToSystem("#GeneratorInterval", "generator_interval", "#GeneratorIntervalDesc", 0, 7200);

function PLUGIN:GetEntityMenuOptions(entity, options)
	local generator = self.generator:FindByID(entity:GetClass());
	
	if (generator) then
		if (!entity.CanSupply or entity:CanSupply()) then
			options["Supply"] = "cwGeneratorSupply";
		end;
	end;
end;

-- Called when a generator's target ID is drawn.
function PLUGIN:DrawGeneratorTargetID(entity, info) end;

-- Called when a generator entity is drawn.
function PLUGIN:GeneratorEntityDraw(entity) end;

-- ripped from cl_kernel CW:HUDDrawTargetID().
-- still need to figure where to put it but it's 1:30AM so sorry
--[[
					elseif (self.generator:FindByID(class)) then
						if (cwClient:GetShootPos():Distance(trace.HitPos) <= fadeDistance) then
							local generator = self.generator:FindByID(class);
							local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
							local power = trace.Entity:GetPower();
							local name = generator.name;
							local x, y = toScreen.x, toScreen.y;
							
							y = CW.kernel:DrawInfo(name, x, y, Color(150, 150, 100, 255), alpha);
							
							local info = {
								showPower = true,
								generator = generator,
								x = x,
								y = y
							};
							
							CW.plugin:Call("DrawGeneratorTargetID", trace.Entity, info);
							
							if (info.showPower) then
								if (power == 0) then
									info.y = CW.kernel:DrawInfo("Press Use to re-supply", info.x, info.y, Color(255, 255, 255, 255), alpha);
								else
									info.y = CW.kernel:DrawBar(
										info.x - 80, info.y, 160, 16, CW.option:GetColor("information"), generator.powerPlural,
										power, generator.power, power < (generator.power / 5), {uniqueID = class}
									);
								end;
							end;
						end;
--]]