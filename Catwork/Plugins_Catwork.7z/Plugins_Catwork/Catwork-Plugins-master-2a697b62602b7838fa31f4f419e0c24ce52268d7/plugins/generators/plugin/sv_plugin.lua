CW.config:Add("generator_interval", 540);

-- Called to modify the generator interval.
function PLUGIN:ModifyGeneratorInterval(info) end;

function PLUGIN:Tick()
	if (!CW.NextGeneratorTime or curTime >= CW.NextGeneratorTime) then
		CW.kernel:DistributeGeneratorCash();
		
		local info = {
			interval = CW.config:Get("generator_interval"):Get();
		};
		
		CW.plugin:Call("ModifyGeneratorInterval", info);
		
		CW.NextGeneratorTime = curTime + info.interval;
	end;
end;

-- Called when a player charges generator.
function PLUGIN:PlayerChargeGenerator(player, entity, generator) end;

-- Called when a player destroys generator.
function PLUGIN:PlayerDestroyGenerator(player, entity, generator) end;

-- Called when a player attempts to destroy generator.
function PLUGIN:PlayerCanDestroyGenerator(player, entity, generator) return true; end;

-- Called when a player attempts to earn generator cash.
function PLUGIN:PlayerCanEarnGeneratorCash(player, info, cash)
	return true;
end;

-- Called when a player earns generator cash.
function PLUGIN:PlayerEarnGeneratorCash(player, info, cash) end;

-- Called when a player's earn generator info should be adjusted.
function PLUGIN:PlayerAdjustEarnGeneratorInfo(player, info) end;

-- Called when an entity's menu option should be handled.
function PLUGIN:EntityHandleMenuOption(player, entity, option, arguments)
	local generator = CW.generator:FindByID(entity:GetClass());

	if (generator and arguments == "cwGeneratorSupply") then
		if (entity:GetPower() < generator.power) then
			if (!entity.CanSupply or entity:CanSupply(player, generator)) then
				CW.plugin:Call("PlayerChargeGenerator", player, entity, generator);
				
				entity:SetDTInt(0, generator.power);
				player:FakePickup(entity);
				
				if (entity.OnSupplied) then
					entity:OnSupplied(player);
				end;
				
				entity:Explode();
			end;
		end;
	end;
end;