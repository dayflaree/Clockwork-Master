--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

--[[
	You don't have to do this, but I think it's nicer.
	Alternatively, you can simply use the PLUGIN variable.
--]]

PLUGIN:SetGlobalAlias("cwGenerators");

CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");

-- A function to distribute generator cash.
function CW.kernel:DistributeGeneratorCash()
	local generatorEntities = {};
	
	for k, v in pairs(CW.generator:GetAll()) do
		table.Add(generatorEntities, ents.FindByClass(k));
	end;
	
	for k, v in pairs(generatorEntities) do
		local generator = CW.generator:FindByID(v:GetClass());
		local player = v:GetPlayer();
		
		if (IsValid(player) and v:GetPower() != 0) then
			local info = {
				generator = generator,
				entity = v,
				cash = generator.cash,
				name = "Generator"
			};
			
			v:SetDTInt(0, math.max(v:GetPower() - 1, 0));
			CW.plugin:Call("PlayerAdjustEarnGeneratorInfo", player, info);
			
			if (CW.plugin:Call("PlayerCanEarnGeneratorCash", player, info, info.cash)) then
				if (v.OnEarned) then
					local result = v:OnEarned(player, info.cash);
					
					if (type(result) == "number") then
						info.cash = result;
					end;
					
					if (result != false) then
						if (result != true) then
							CW.player:GiveCash(k, info.cash, info.name);
						end;
						
						CW.plugin:Call("PlayerEarnGeneratorCash", player, info, info.cash);
					end;
				else
					CW.player:GiveCash(k, info.cash, info.name);
					CW.plugin:Call("PlayerEarnGeneratorCash", player, info, info.cash);
				end;
			end;
		end;
	end;
end;

-- A function to get a player's generator count.
function CW.player:GetGeneratorCount(player)
	local generators = CW.generator:GetAll();
	local count = 0;
	
	for k, v in pairs(generators) do
		count = count + self:GetPropertyCount(player, k);
	end;
	
	return count;
end;

--[[
	@codebase Server
	@details A function to create generator.
	@param Entity:Table The owner(s) of the generator being created.
	@param String Entity class for the generator to be assigned to.
	@param Vector Position the generator is set to.
	@param Angle Optional: Angles the generator is set to.
	@returns Entity Reference to the generator created.
--]]
function CW.entity:CreateGenerator(ownerObj, class, position, angles)
	local entity = ents.Create(class);

	if (!angles) then
		angles = Angle(0, 0, 0);
	end;

	if (type(ownerObj) == "table") then
		if (ownerObj.key and ownerObj.uniqueID) then
			CW.player:GivePropertyOffline(ownerObj.key, ownerObj.uniqueID, entity, true);
		end;
	elseif (IsValid(ownerObj) and ownerObj:IsPlayer()) then
		CW.player:GiveProperty(ownerObj, entity, true);
	end;

	entity:SetAngles(angles);
	entity:SetPos(position);
	entity:Spawn();

	return entity;
end;