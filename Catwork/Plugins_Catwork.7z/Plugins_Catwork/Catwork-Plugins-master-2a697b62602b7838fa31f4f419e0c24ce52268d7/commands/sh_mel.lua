--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("MeL");
COMMAND.tip = "Speak in third person to others in a large area around you.";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");
	
	if (text == "") then
		CW.player:Notify(player, L(player, "NotEnoughText"));
		
		return;
	end;

	CW.chatBox:AddInTargetRadius(player, "mel", string.gsub(text, "^.", string.lower), player:GetPos(),
		CW.config:Get("talk_radius"):Get() * 4);
end;

COMMAND:Register();