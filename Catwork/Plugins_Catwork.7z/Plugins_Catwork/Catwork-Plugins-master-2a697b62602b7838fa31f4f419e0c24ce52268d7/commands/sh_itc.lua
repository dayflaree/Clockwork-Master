--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("ItC");
COMMAND.tip = "Describe a close-range local action or event.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");
	
	if (string.utf8len(text) < 8) then
		CW.player:Notify(player, L(player, "NotEnoughText"));
		
		return;
	end;

	CW.chatBox:AddInTargetRadius(player, "itc", text, player:GetPos(), 
		math.min(CW.config:Get("talk_radius"):Get() / 3, 80));
end;

COMMAND:Register();