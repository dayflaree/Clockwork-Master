--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("PlyRespawnTP");
COMMAND.tip = "Respawn a player and teleport them to your target location.";
COMMAND.text = "<string Target> <bool isSilent>";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"PlyRTP", "RespawnTP"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local isSilent = CW.kernel:ToBool(arguments[2]);
	local trace = player:GetEyeTraceNoCursor();

	if (target) then
		CW.player:LightSpawn(target, true, true, true);
		CW.player:SetSafePosition(target, trace);
		CW.player:Notify(player, target:GetName().." was respawned and teleported to your target position.");
	else
		CW.player:Notify(player, arguments[2].." is not a valid target!");
	end;
end;

COMMAND:Register();