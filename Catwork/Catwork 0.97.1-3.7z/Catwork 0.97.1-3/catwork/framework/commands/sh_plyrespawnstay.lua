--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("PlyRespawnStay");
COMMAND.tip = "Respawn a player at their position of death.";
COMMAND.text = "<string Target>";
COMMAND.arguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"PlyRStay", "RespawnStay"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (target) then
		CW.player:LightSpawn(target, true, true, false);
		CW.player:Notify(player, target:GetName().." was respawned at their position of death.");
	else
		CW.player:Notify(player, arguments[1].." is not a valid target!");
	end;
end;

COMMAND:Register();