--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("PluginUnload");
COMMAND.tip = "Attempt to unload a plugin.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local plugin = plugin.FindByID(arguments[1]);
	
	if (!plugin) then
		CW.player:Notify(player, "This plugin is not valid!");
		return;
	end;
	
	local unloadTable = CW.command:FindByID("PluginLoad");
	local loadTable = CW.command:FindByID("PluginLoad");
	
	if (!plugin.IsDisabled(plugin.name)) then
		local bSuccess = plugin.SetUnloaded(plugin.name, true);
		local recipients = {};
		
		if (bSuccess) then
			CW.player:NotifyAll(player:Name().." has unloaded the "..plugin.name.." plugin for the next restart.");
			
			for k, v in pairs(cwPlayer.GetAll()) do
				if (v:HasInitialized()) then
					if (CW.player:HasFlags(v, loadTable.access)
					or CW.player:HasFlags(v, unloadTable.access)) then
						recipients[#recipients + 1] = v;
					end;
				end;
			end;
			
			if (#recipients > 0) then
				netstream.Start(recipients, "SystemPluginSet", {plugin.name, true});
			end;
		else
			CW.player:Notify(player, "This plugin could not be unloaded!");
		end;
	else
		CW.player:Notify(player, "This plugin depends on another plugin!");
	end;
end;

COMMAND:Register();