--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = CW.command:New("PKModeOff");
COMMAND.tip = "Turn PK mode off and cancel the timer.";
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	CW.kernel:SetSharedVar("PKMode", 0);
	CW.kernel:DestroyTimer("pk_mode");
	
	CW.player:NotifyAll(player:Name().." has turned off perma-kill mode, you are safe now.");
end;

COMMAND:Register();