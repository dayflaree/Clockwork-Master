--[[
	(C) 2016 TeslaCloud Studios
	Please do not re-use.
--]]

library.New("karma", Schema);

