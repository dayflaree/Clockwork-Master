--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

config.AddToSystem("Remove Map Physics", "remove_map_physics", "Whether or not physics entities should be removed when the map is loaded.");