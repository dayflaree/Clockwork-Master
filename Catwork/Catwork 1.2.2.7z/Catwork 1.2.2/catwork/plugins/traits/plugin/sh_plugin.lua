PLUGIN:SetGlobalAlias("cwTraits")

util.Include("cl_plugin.lua")
util.Include("cl_gui.lua")

cwTraits.Traits = {
	["lucky"] = {
		name = "Везунчик",
		desc = "Фортуна всегда на вашей стороне. Вы удачливы абсолютно во всём, пользуйтесь этим.",
		desc2 = "+5 к роллу\nБлокирует особенность 'Неудачник'",
		icon = "",
		cost = -3,
		p = true,
		block = "unlucky",
	},
	["unlucky"] = {
		name = "Неудачник",
		desc = "Вам явно не стоит играть в азартные игры. Вы крайне невезучи, будьте осторожнее.",
		desc2 = "-5 к роллу\nБлокирует особенность 'Везунчик'",
		icon = "",
		cost = 2,
		p = false,
		block = "lucky",
	},
	["rifleman"] = {
		name = "Меткий стрелок",
		desc = "Вы большое количество времени провели наедине с оружием. С вами действительно сложно спорить в перестрелке.",
		desc2 = "+12 к роллу с оружием\n+25% к точности огнестрельного оружия\n+15% к урону огнестрельного оружия\nБлокирует особенности 'Пацифист'",
		icon = "",
		cost = -8,
		p = true,
		block = "pacifist",
	},
	["pacifist"] = {
		name = "Пацифист",
		desc = "Мир вашему дому. Пусть сражается кто-либо другой, вы же предпочтете хорошую газету и вечное рабство.",
		desc2 = "-12 к роллу с оружием\n-25% к точности огнестрельного оружия\n-15% к урону огнестрельного оружия\n-15% к урону оружия ближнего боя\nБлокирует особенности 'Меткий стрелок', 'Хулиган'",
		icon = "",
		cost = 9,
		p = false,
		block = {"rifleman","badman"},
	},
	["athlet"] = {
		name = "Атлет",
		desc = "Похоже, ваша жизнь была очень богата на бег и прыжки. С чем же это связано?",
		desc2 = "+10% к скорости бега\n+10% к выносливости\n+5% к высоте прыжка\nБлокирует особенность 'Плохая координация'",
		icon = "",
		cost = -4,
		p = true,
		block = "badcoord",
	},
	["badcoord"] = {
		name = "Плохая координация",
		desc = "А вы можете устоять на месте не падая?",
		desc2 = "-15% к скорости бега\n-5% к выносливости\n-10% к высоте прыжка\nБлокирует особенность 'Атлет'",
		icon = "",
		cost = 4,
		p = false,
		block = "athlet",
	},
	["badman"] = {
		name = "Хулиган",
		desc = "У вас очень радикальное мнение по многим вопросам.",
		desc2 = "+20% к урону оружия ближнего боя.\nБлокирует особенность 'Пацифист'",
		icon = "",
		cost = -5,
		p = true,
		block = "pacifist",
	},
	["eagleeye"] = {
		name = "Орлиный глаз",
		desc = "У Вас действительно очень хорошее зрение. Вы можете заметить то, что другие замечают не сразу.",
		desc2 = "Вещи подсвечиваются\nБлокирует особенность 'Слабое зрение'",
		icon = "",
		cost = -5,
		p = true,
		block = "badeye",
	},
	["badeye"] = {
		name = "Слабое зрение",
		desc = "Окулист - ваш друг. Только он вам может выдать справку, что вы хоть что-то видите. Хороший человек, правда вылечить ваш недуг он не сможет.",
		desc2 = "Вы не можете видеть описания других людей и названия вещей.\nБлокирует особенность 'Орлиный глаз'",
		icon = "",
		cost = 6,
		p = false,
		block = "eagleeye",
	},
	["thirst"] = {
		name = "Повышенная жажда",
		desc = "'Как же хочется пить..'",
		desc2 = "+15% к скорости понижения жажды\nБлокирует особенность 'Пониженная жажда'",
		icon = "",
		cost = 2,
		p = false,
		block = "nothirst",
	},
	["nothirst"] = {
		name = "Пониженная жажда",
		desc = "Кажется, вы - верблюд.",
		desc2 = "-15% к скорости понижения жажды\nБлокирует особенность 'Повышенная жажда'",
		icon = "",
		cost = -2,
		p = true,
		block = "thirst",
	},
	["hunger"] = {
		name = "Голодный",
		desc = "'Я голодный как собака..'",
		desc2 = "+15% к скорости понижения голода\nБлокирует особенность 'Плохой аппетит'",
		icon = "",
		cost = 2,
		p = false,
		block = "smallappetite",
	},
	["smallappetite"] = {
		name = "Плохой аппетит",
		desc = "У вас был дед-доед.",
		desc2 = "-15% к скорости понижения голода\nБлокирует особенность 'Голодный'",
		icon = "",
		cost = -2,
		p = true,
		block = "hunger",
	},
	["bodriy"] = {
		name = "Бодрый",
		desc = "Пока все спят - вы не спите. Чудесно.",
		desc2 = "-25% к скорости понижения бодрости\nБлокирует особенность 'Хроническая усталость'",
		icon = "",
		cost = -3,
		p = true,
		block = "ustalost",
	},
	["ustalost"] = {
		name = "Хроническая усталость",
		desc = "Вступайте в клуб сонь!",
		desc2 = "+25% к скорости понижения бодрости\n-5% к скорости передвижения и бега\nБлокирует особенность 'Бодрый'",
		icon = "",
		cost = 4,
		p = false,
		block = "bodriy",
	},
	["organizovan"] = {
		name = "Организованный",
		desc = "Вы настоящий перфекционист в плане разложения вещей. Вам всегда удаётся найти чуть больше места у себя в рюкзаке.",
		desc2 = "+25% к общей вместимости инвентаря\nБлокирует особенность 'Неорганизованный'",
		icon = "",
		cost = -4,
		p = true,
		block = "neorganizovan",
	},
	["neorganizovan"] = {
		name = "Неорганизованный",
		desc = "Трудно быть Вами. Вам постоянно требуется много сумок, чтобы уместить все свои вещи.",
		desc2 = "-30% к общей вместимости инвентаря\nБлокирует особенность 'Организованный'",
		icon = "",
		cost = 5,
		p = false,
		block = "organizovan",
	},
}

function PLUGIN:AdjustRollNumber(player, roll, max, target)
	if (player:HasTrait("lucky")) then
		return 5
	elseif (player:HasTrait("unlucky")) then
		return -5
	end
end

local playerMeta = FindMetaTable("Player")

if SERVER then
	function playerMeta:GetTraits()
		local traits = {}
		local traitsData = self:QueryCharacter("Traits", {})

		for k, v in pairs(traitsData) do
			if (type(v) == "table") then
				for k2, v2 in pairs(v) do
					traits[#traits + 1] = v2
				end
			end
		end

		return traits
	end

	function playerMeta:HasTrait(uniqueID)
		local traits = self:GetTraits()

		return table.HasValue(traits, uniqueID)
	end

	function cwTraits:PlayerCharacterInitialized(player)
		netstream.Start(player, "TraitReset")

		for k, v in pairs(player:GetTraits()) do
			netstream.Start(player, "TraitAdd", {uid = v})
		end
	end
else
	local buffer = {}

	function playerMeta:GetTraits()
		return buffer
	end

	function playerMeta:HasTrait(uniqueID)
		return table.HasValue(buffer,uniqueID)
	end

	netstream.Hook("TraitReset", function(data)
		buffer = {}
	end)

	netstream.Hook("TraitAdd", function(data)
		local uniqueID = data.uid

		if cwTraits.Traits[uniqueID] then
			buffer[#buffer + 1] = uniqueID
		end
	end)

	netstream.Hook("TraitRemove", function(data)
		local uniqueID = data.uid

		if (cw.client:HasTrait(uniqueID)) then
			for k, v in pairs(buffer) do
				if v == uniqueID then
					buffer[k] = nil
				end
			end
		end
	end)

	function cwTraits:PreDrawHalos()
		if LocalPlayer():HasTrait("eagleeye") then
			halo.Add(ents.FindByClass("cw_item"), Color(20, 140, 255), 3, 3, 4)
			halo.Add(ents.FindByClass("cw_cash"), Color(20, 140, 255), 3, 3, 4)
		end
	end
end