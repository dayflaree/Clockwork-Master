surface.CreateFont("TraitsTitle", {font = "Trebuchet MS", size = 22, weight = 500, blursize = 0, antialias = true, shadow = false})
surface.CreateFont("TraitsText", {font = "Verdana", size = 16, weight = 500, blursize = 0, antialias = true, shadow = false})
surface.CreateFont("TraitsText2", {font = "Consolas", size = 16, weight = 1000, blursize = 0, antialias = true, shadow = false})
surface.CreateFont("TraitsText3", {font = "Verdana", size = 13, weight = 500, blursize = 0, antialias = false, shadow = false})

TRAIT_ACTIVE_BUTTON = nil

local PANEL = {}
function PANEL:Init()
	self:SetText("")

	self.name = "Lucky"
	self.cost = "0"
	self.enabled = true
end
function PANEL:Paint(w, h)
	local textColor = self.positive and Color(0, 255, 0, 255) or Color(255, 0, 0, 255)
	local prefix = self.positive and "-" or "+"
	surface.SetDrawColor(0, 0, 0, 200)
	surface.DrawOutlinedRect(0, 0, w, h)

	//surface.SetDrawColor(0, 0, 0, 255)
	//surface.DrawRect(6, 6, 20, 20)

	draw.SimpleTextOutlined(self.name, "TraitsText2", 10, 6, textColor, 0, 0, 1, Color(0,0,0,230))
	draw.SimpleTextOutlined(prefix..self.cost, "TraitsText2", 256 - 37, 6, textColor, 0, 0, 1, Color(0,0,0,230))

	if self.active then
		surface.SetDrawColor(0, 32, 0, 64)
		surface.DrawRect(0, 0, w, h)
	end
	if !self.enabled then
		surface.SetDrawColor(255, 0, 0, 64)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w, h)
		surface.SetDrawColor(255, 100, 0, 255)
		surface.DrawOutlinedRect(1, 1, w - 2, h - 2)
	end
end
function PANEL:DoClick()
	if TRAIT_ACTIVE_BUTTON then
		TRAIT_ACTIVE_BUTTON.active = false
	end
	TRAIT_ACTIVE_BUTTON = self
	self.active = true
end
function PANEL:Think()
	self:InvalidateLayout(true)
end
function PANEL:PerformLayout(w, h)
	self:SetTall(32)
end
vgui.Register("cwTraitsButton", PANEL, "DButton")


local PANEL = {}
function PANEL:Init()
	self.titleLabel = vgui.Create("DLabel",self)
	self.titleLabel:SetText("")
	self.titleLabel:Dock(TOP)
	self.titleLabel:SetFont("TraitsTitle")
	self.titleLabel:SetTextColor(Color(0,0,0))
	self.titleLabel:SizeToContents()
	self:Add(self.titleLabel)

	surface.SetFont("TraitsTitle")
	local text_w, text_h = surface.GetTextSize("A")

	self.descLabel = vgui.Create("DLabel",self)
	self.descLabel:SetText("Описание")
	self.descLabel:SetPos(0,text_h)
	self.descLabel:SetFont("TraitsText")
	self.descLabel:SetTextColor(Color(0,0,0))
	self.descLabel:SizeToContents()
	self:Add(self.descLabel)

	surface.SetFont("TraitsText")
	local text_w2, text_h2 = surface.GetTextSize("Cost")

	self.costLabel = vgui.Create("DLabel",self)
	self.costLabel:SetText("Цена")
	self.costLabel:SetPos(256 - text_w2 - 10,text_h)
	self.costLabel:SetFont("TraitsText")
	self.costLabel:SetTextColor(Color(0,0,0))
	self.costLabel:SizeToContents()
	self:Add(self.costLabel)

	self.panelList = vgui.Create("DPanelList",self)
	self.panelList:Dock(FILL)
	self.panelList:DockMargin(0,text_h2 + 1,0,0)
	self.panelList:SetSpacing(1)
	self.panelList:EnableHorizontal(false)
	self.panelList:EnableVerticalScrollbar(true)
	self.panelList.Paint = function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(230,230,230))
	end
	self:Add(self.panelList)
end
function PANEL:Set_title(text)
	self.titleLabel:SetText(text)
end
function PANEL:Paint(w, h) end
function PANEL:Think()
	self:InvalidateLayout(true)
end
function PANEL:PerformLayout(w, h)
	self:SetSize(256,360)
end
vgui.Register("cwTraitsPanel", PANEL, "Panel")

local PANEL = {}
function PANEL:CreateTraitButton(uniqueID)
	local positive = cwTraits.Traits[uniqueID]
	local button
	if positive then
		local informationColor = cw.option:GetColor("information")

		local pnl = vgui.Create("cwTraitsButton",self)
 		pnl.name = positive.name
 		pnl.cost = math.abs(positive.cost)
 		pnl.uid = uniqueID
 		pnl.positive = positive.p
 		cw.core:CreateMarkupToolTip(pnl)
 		
 		local info = cw.core:MarkupTextWithColor("[Описание]", informationColor)
		info = cw.core:AddMarkupLine(info, positive.desc)
		info = cw.core:AddMarkupLine(info, positive.desc2, positive.p and Color(100, 255, 100) or Color(255, 100, 100))
		pnl:SetMarkupToolTip(info)

 		return pnl
 	end
end
function PANEL:Init()
	self.Buttons = {}

 	self.panel1 = vgui.Create("cwTraitsPanel",self)
 	self.panel1:Set_title("Доступные")
 	self.panel1:Dock(LEFT)
	self.panel2 = vgui.Create("cwTraitsPanel",self)
	self.panel2:Set_title("Выбранные")
 	self.panel2:Dock(RIGHT)
 	
 	for k, v in pairs(cwTraits.Traits) do
 		local button = self:CreateTraitButton(k)
		self.panel1.panelList:AddItem(button)
 		self.Buttons[k] = {button = button, panel = self.panel1}
 	end

 	self.buttonAdd = vgui.Create("DButton",self)
 	self.buttonAdd:SetText("Добавить")
 	self.buttonAdd:SetSize(64,32)
 	self.buttonAdd:SetPos(580/2 - 32, 400/2 - 32 - 1)
 	self.buttonAdd.DoClick = function()
 		if !TRAIT_ACTIVE_BUTTON then return end

 		local uid = TRAIT_ACTIVE_BUTTON.uid
 		local button = self:CreateTraitButton(uid)
 		button.choosen = true
 		self.panel2.panelList:AddItem(button)

 		self.Buttons[uid].button:Remove()
		self.Buttons[uid].button = button
 		self.Buttons[uid].panel = self.panel2

 		TRAIT_ACTIVE_BUTTON = nil
 	end
 	self.buttonRemove = vgui.Create("DButton",self)
 	self.buttonRemove:SetText("Убрать")
 	self.buttonRemove:SetSize(64,32)
 	self.buttonRemove:SetPos(580/2 - 32, 400/2 + 1)
 	self.buttonRemove.DoClick = function()
 		if !TRAIT_ACTIVE_BUTTON then return end

 		local uid = TRAIT_ACTIVE_BUTTON.uid
 		local button = self:CreateTraitButton(uid)
 		button.choosen = false
 		self.panel1.panelList:AddItem(button)

 		self.Buttons[uid].button:Remove()
		self.Buttons[uid].button = button
 		self.Buttons[uid].panel = self.panel1

 		TRAIT_ACTIVE_BUTTON = nil
 	end
end

-- Called when the next button is pressed.
function PANEL:OnNext()

end

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	if !TRAIT_ACTIVE_BUTTON then
		self.buttonAdd:SetEnabled(false)
		self.buttonRemove:SetEnabled(false)
	elseif self.Buttons[TRAIT_ACTIVE_BUTTON.uid].panel == self.panel1 then
		self.buttonAdd:SetEnabled(true)
		self.buttonRemove:SetEnabled(false)
	elseif self.Buttons[TRAIT_ACTIVE_BUTTON.uid].panel == self.panel2 then
		self.buttonAdd:SetEnabled(false)
		self.buttonRemove:SetEnabled(true)
	end

	local blocked = {}
 	for k, v in pairs(self.Buttons) do
		if !v.button.choosen then continue end
		local traitTable = cwTraits.Traits[v.button.uid]
		if type(traitTable.block) == "string" then
			blocked[#blocked + 1] = traitTable.block
		elseif type(traitTable.block) == "table" then
			for z, x in pairs(traitTable.block) do
				blocked[#blocked + 1] = x
			end
		end
	end
	for k, v in pairs(self.Buttons) do
		if v.button.choosen then continue end
		local block = false
		for z, x in pairs(blocked) do
			if x == v.button.uid then
				block = true
			end
		end
		if block then
			v.button:SetEnabled(false)
			v.button.enabled = false
		else
			v.button:SetEnabled(true)
			v.button.enabled = true
		end
	end
end
function PANEL:Think()
	self:InvalidateLayout(true)
end
function PANEL:PerformLayout(w, h)
	self:SetSize(580, 360)
end

vgui.Register("cwTraitsMainPanel", PANEL, "EditablePanel")

local PANEL = {}
function PANEL:Init()
	self.info = cw.character:GetCreationInfo()
	self.Points = 0
	self.attributesForm = vgui.Create("DForm")
	self.attributesForm:SetName("Особенности")
	self.attributesForm:SetPadding(4)

	self.categoryList = vgui.Create("DCategoryList", self)
 	self.categoryList:SetPadding(2)
 	self.categoryList:SizeToContents()

	self.textLabel = vgui.Create("DLabel",self.attributesForm)
	self.textLabel:Dock(TOP)
	self.textLabel:DockMargin(16,5,16,0)
	self.textLabel:SetAutoStretchVertical(true)
	self.textLabel:SetWrap(true)
	self.textLabel:SetText("Особенности это модификаторы для персонажа, положительные и отрицательные, доступные Вам.\n\nОбщая сумма очков особенностей должна быть равна 0 (или больше нуля) чтобы завершить создание персонажа. Таким образом если Вы выберете положительные особенности, вам также потребуется выбрать и отрицательные особенности для компенсации общей суммы.\n")
	self.textLabel:SetFont("TraitsText3")
	self.textLabel:SetTextColor(Color(0,0,0))
	self.textLabel:SizeToContents()

	self.pointLabel = vgui.Create("Panel",self.attributesForm)
	self.pointLabel:Dock(TOP)
	self.pointLabel:DockMargin(16,0,0,0)
	self.pointLabel:SetTall(14)
	self.pointLabel.Paint = function(s,w,h)
		local textColor = self.Points >= 0 and Color(0, 255, 0, 255) or Color(255, 0, 0, 255)
		surface.SetFont("TraitsText3")

		local x = 0
		local y = 0

		surface.SetTextColor(0, 0, 0, 255)
		surface.SetTextPos(x, y)
		surface.DrawText("Очки для траты: ")
		local text_w, text_h = surface.GetTextSize("Очки для траты: ")
		x = x + text_w
		surface.SetFont("TraitsText2")
		surface.SetTextColor(textColor)
		surface.SetTextPos(x, y)
		surface.DrawText(self.Points)
	end

	self.mainPanel = vgui.Create("cwTraitsMainPanel",self.attributesForm)
	self.mainPanel:Dock(TOP)
	self.mainPanel:DockMargin(16,2,0,0)
	self.maximumPoints = maximumPoints
	self.categoryList:AddItem(self.attributesForm)

	self.info.traits = {}
	self.info.traits.positive = {}
	self.info.traits.negative = {}
end

-- Called when the next button is pressed.
function PANEL:OnNext()

end

-- Called when the panel is painted.
function PANEL:Paint(w, h) end

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255))

			if (animation.Finished) then
				panel:SetVisible(false)
			end

			if (animation.Finished and Callback) then
				Callback()
			end
		end)

		if (self.animation) then
			self.animation:Start(speed)
		end

		cw.option:PlaySound("rollover")
	else
		self:SetVisible(false)
		self:SetAlpha(0)

		if (Callback) then
			Callback()
		end
	end
end

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetVisible(true)
			panel:SetAlpha(delta * 255)

			if (animation.Finished) then
				self.animation = nil
			end

			if (animation.Finished and Callback) then
				Callback()
			end
		end)

		if (self.animation) then
			self.animation:Start(speed)
		end

		cw.option:PlaySound("click_release")
	else
		self:SetVisible(true)
		self:SetAlpha(255)

		if (Callback) then
			Callback()
		end
	end
end

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true)

	self.Points = 0
	self.info.traits.positive = {}
	self.info.traits.negative = {}
	if self.mainPanel then
		if self.mainPanel.Buttons then
			for k,v in pairs(self.mainPanel.Buttons) do
				if v.button then
					if v.button.choosen then
						if cwTraits.Traits[v.button.uid] then
							if cwTraits.Traits[v.button.uid].p then
								self.info.traits.positive[#self.info.traits.positive + 1] = v.button.uid
							elseif !cwTraits.Traits[v.button.uid].p then
								self.info.traits.negative[#self.info.traits.negative + 1] = v.button.uid
							end
							self.Points = self.Points + cwTraits.Traits[v.button.uid].cost
						end
					end
				end
			end
		end
	end

	if (self.animation) then
		self.animation:Run()
	end
end

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	self.categoryList:StretchToParent(0, 0, 0, 0)
	self:SetSize(616, math.min(self.categoryList.pnlCanvas:GetTall() + 11, ScrH() * 0.7))
end
vgui.Register("cwTraitsSelect", PANEL, "EditablePanel")

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetSize(cw.menu:GetWidth(), cw.menu:GetHeight())

	self.panelList = vgui.Create("cwPanelList", self)
 	self.panelList:SetPadding(2)
 	self.panelList:SetSpacing(2)

	cwTraits.panel = self
	cwTraits.panel.boosts = {}
	cwTraits.panel.progress = {}
	cwTraits.panel.attributes = {}

	self:Rebuild()
end

-- A function to rebuild the panel.
function PANEL:Rebuild()
	self.panelList:Clear()

	for k, v in pairs(LocalPlayer():GetTraits()) do
		local positive = cwTraits.Traits[v]
		if positive then
			local informationColor = cw.option:GetColor("information")

			local pnl = vgui.Create("cwTraitsButton",self)
	 		pnl.name = positive.name
	 		pnl.cost = math.abs(positive.cost)
	 		pnl.uid = v
	 		pnl.positive = positive.p
	 		cw.core:CreateMarkupToolTip(pnl)
	 		
	 		local info = cw.core:MarkupTextWithColor("[Описание]", informationColor)
			info = cw.core:AddMarkupLine(info, positive.desc)
			info = cw.core:AddMarkupLine(info, positive.desc2, positive.p and Color(100, 255, 100) or Color(255, 100, 100))
			pnl:SetMarkupToolTip(info)
			self.panelList:AddItem(pnl)
		end
	end

	self.panelList:InvalidateLayout(true)
end

-- Called when the menu is opened.
function PANEL:OnMenuOpened()
	if (cw.menu:IsPanelActive(self)) then
		self:Rebuild()
	end
end

-- Called when the panel is selected.
function PANEL:OnSelected() self:Rebuild(); end

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	self.panelList:StretchToParent(4, 28, 4, 4)
	self:SetSize(w, math.min(self.panelList.pnlCanvas:GetTall() + 32, ScrH() * 0.75))
end

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	return true
end

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true)
end

vgui.Register("cwTraits", PANEL, "EditablePanel");