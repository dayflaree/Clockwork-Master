﻿include("shared.lua")

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

function ENT:Initialize()
	self:SetModel(self.Model)

	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetSolid(SOLID_VPHYSICS)

	local physicsObject = self:GetPhysicsObject()
	physicsObject:SetMass(120)
	if (IsValid(physicsObject)) then
		physicsObject:Wake()
		physicsObject:EnableMotion(true)
	end
end

function ENT:SpawnFunction(player, trace, class)
	local ent = ents.Create(class)

	ent:SetPos(trace.HitPos + Vector(0, 0, 25))
	ent:SetAngles(Angle(0, 180, 0))
	ent:Spawn()

	return ent
end

function ENT:Think()
	if !IsValid(self.activePlayer) then
		self.activePlayer = nil
	else
		if !self.activePlayer:Alive() then
			netstream.Start(self.activePlayer, "CraftCloseMenu_", nil)
			self.activePlayer.activeCraftTable = nil
			self.activePlayer = nil
		else
			if self.activePlayer:GetPos():Distance(self:GetPos()) > 70 then
				netstream.Start(self.activePlayer, "CraftCloseMenu_", nil)
				self.activePlayer.activeCraftTable = nil
				self.activePlayer = nil
			end
		end
	end

	self:NextThink(CurTime())
end

function ENT:Use(activator)
	if activator:GetPos():Distance(self:GetPos()) < 70 then
		if self.activePlayer then
			cw.player:Notify(activator, "Верстак уже используется другим персонажем!")
			return
		else
			self.activePlayer = activator
			activator.activeCraftTable = self
			netstream.Start(activator, "CraftOpenMenu", nil , self:GetClass(), self.PrintName)
		end
	end
end

function ENT:GetCraftPos()
	return self:GetPos() + self:GetUp() * 35
end

function ENT:CanTool(player, trace, tool)
	return true
end

netstream.Hook("CraftCloseMenu", function(player, data)
	if !IsValid(player) then return end
	if IsValid(player.activeCraftTable) then
		if player.activeCraftTable.activePlayer == player then
			player.activeCraftTable.activePlayer = nil
			player.activeCraftTable = nil
		else
			player.activeCraftTable = nil
		end
	end
end)
