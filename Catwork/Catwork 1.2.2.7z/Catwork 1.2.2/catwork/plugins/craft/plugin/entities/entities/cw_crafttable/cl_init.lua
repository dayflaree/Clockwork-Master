include("shared.lua")

function ENT:HUDPaintTargetID(x, y, alpha)
	local colorTargetID = cw.option:GetColor("target_id")
	local colorWhite = cw.option:GetColor("white")

	y = cw.core:DrawInfo(self.PrintName, x, y, colorTargetID, alpha)
end

function ENT:Draw()
	self:DrawModel()
end

netstream.Hook("CraftOpenMenu", function(data, class, name)
	if CRAFT_TABLE_MENU then
		CRAFT_TABLE_MENU:Remove()
		CRAFT_TABLE_MENU = nil
	end
	CRAFT_TABLE_MENU = vgui.Create("cwCraft")
	CRAFT_TABLE_MENU:MakePopup()
	CRAFT_TABLE_MENU:Center()
	CRAFT_TABLE_MENU.class = class
	CRAFT_TABLE_MENU.name = name
end)

netstream.Hook("CraftTime", function(data)
	cw.CraftCooldown = data

	if CRAFT_TABLE_MENU then
		if CRAFT_TABLE_MENU.Rebuild then
			CRAFT_TABLE_MENU:Rebuild()
		end
	end
end)

netstream.Hook("CraftCloseMenu_", function(data)
	if CRAFT_TABLE_MENU then
		CRAFT_TABLE_MENU:Remove()
		CRAFT_TABLE_MENU = nil
	end
end)
