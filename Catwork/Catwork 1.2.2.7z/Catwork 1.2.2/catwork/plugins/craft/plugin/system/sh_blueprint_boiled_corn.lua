local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Вареная кукуруза"
BLUEPRINT.uniqueID = "blueprint_boiled_corn"
BLUEPRINT.model = "models/bioshockinfinite/porn_on_cob.mdl"
BLUEPRINT.category = "Еда"
BLUEPRINT.description = "Бросить початок в воду и отварить."
BLUEPRINT.craftplace = "cw_craft_cook"
BLUEPRINT.reqatt = {}
BLUEPRINT.updatt = {
	{"cook", 10}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"corn", 1},
}
BLUEPRINT.finish = {
	{"boiled_corn", 1}
}
BLUEPRINT:Register();