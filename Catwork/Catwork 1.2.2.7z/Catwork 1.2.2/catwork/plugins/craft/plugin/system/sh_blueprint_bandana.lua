local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Бандана"
BLUEPRINT.uniqueID = "blueprint_bandana"
BLUEPRINT.model = "models/tnb/items/facewrap.mdl"
BLUEPRINT.category = "Одежда"
BLUEPRINT.description = "Сшить из ткани устрашающую бандану."
BLUEPRINT.required = {}
BLUEPRINT.updatt = {
	{"cloth", 15}
}
BLUEPRINT.recipe = {
	{"cloth", 1},
}
BLUEPRINT.finish = {
	{"bandana", 1}
}
BLUEPRINT:Register();