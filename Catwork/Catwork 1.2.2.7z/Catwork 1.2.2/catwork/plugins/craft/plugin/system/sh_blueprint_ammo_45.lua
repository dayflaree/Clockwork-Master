local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Патроны .45"
BLUEPRINT.uniqueID = "blueprint_ammo_45"
BLUEPRINT.model = "models/items/boxsrounds.mdl"
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "Коробка патронов калибра .45."
BLUEPRINT.craftplace = "cw_craft_bullet"
BLUEPRINT.reqatt = {
	{"rem", 25}
}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 1},
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"ammo_45", 1}
}
BLUEPRINT:Register();