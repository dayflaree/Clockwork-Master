local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Патроны 7.62х51мм"
BLUEPRINT.uniqueID = "blueprint_ammo_762x51"
BLUEPRINT.model = "models/items/357ammo.mdl"
BLUEPRINT.category = "Боеприпасы"
BLUEPRINT.description = "Коробка патронов 7.62х51мм."
BLUEPRINT.craftplace = "cw_craft_bullet"
BLUEPRINT.reqatt = {
	{"rem", 30}
}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.recipe = {
	{"bullet_casings", 1},
	{"gunpowder", 2},
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"ammo_762x51", 1}
}
BLUEPRINT:Register();