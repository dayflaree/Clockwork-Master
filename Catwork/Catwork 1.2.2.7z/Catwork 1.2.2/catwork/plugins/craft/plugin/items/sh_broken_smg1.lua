

ITEM.name = "Broken MP7A1"
ITEM.PrintName = "Поломанный пистолет-пулемет"
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.description = "Компактное оружие, покрытое царапинами, ржавчиной и грязью. Оно сломано."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

