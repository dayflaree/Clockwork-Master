

ITEM.name = "Welding tool"
ITEM.PrintName = "Сварочный аппарат"
ITEM.model = "models/props_vehicles/carparts_muffler01a.mdl"
ITEM.weight = 1.5
ITEM.category = "Materials"
ITEM.description = "Этим можно сварить что-либо с чем-либо."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

