

ITEM.name = "Screw Driver"
ITEM.PrintName = "Отвертка"
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl"
ITEM.weight = 0.6
ITEM.category = "Tools"
ITEM.description = "Используется для заворачивания винтов."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

