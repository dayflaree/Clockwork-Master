

ITEM.name = "Broken M1911"
ITEM.PrintName = "Поломанный M1911"
ITEM.model = "models/weapons/w_1911_1.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Пистолет М1911, покрытый ржавчиной."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

