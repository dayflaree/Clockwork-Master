

ITEM.name = "Wrench"
ITEM.PrintName = "Гаечный ключ"
ITEM.model = "models/props_c17/tools_wrench01a.mdl"
ITEM.weight = 1
ITEM.category = "Tools"
ITEM.description = "Используется для заворачивания болтов."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

