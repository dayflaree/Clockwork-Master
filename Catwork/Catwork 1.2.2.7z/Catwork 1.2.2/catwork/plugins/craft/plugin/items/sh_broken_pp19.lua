

ITEM.name = "Broken PP19"
ITEM.PrintName = "Поломанный 'Бизон'"
ITEM.model = "models/weapons/w_smg_biz.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.description = "Компактное оружие, покрытое царапинами, ржавчиной и грязью. Оно сломано."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

