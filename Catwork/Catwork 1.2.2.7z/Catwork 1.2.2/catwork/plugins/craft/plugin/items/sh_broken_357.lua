

ITEM.name = "Broken 357 Magnum"
ITEM.PrintName = "Поломанный револьвер"
ITEM.model = "models/weapons/w_357.mdl"
ITEM.weight = 2
ITEM.category = "Materials"
ITEM.description = "Довоенный блестящий револьвер."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

