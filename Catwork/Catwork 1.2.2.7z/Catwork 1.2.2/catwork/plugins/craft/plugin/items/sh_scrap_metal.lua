

ITEM.name = "Scrap Metal"
ITEM.PrintName = "Металлолом"
ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.weight = 0.8
ITEM.category = "Materials"
ITEM.description = "Из этого вряд ли выйдет что-то путное."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

