

ITEM.name = "Box of Screws"
ITEM.PrintName = "Коробка винтов"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Маленькая коробка, наполненная винтами."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

