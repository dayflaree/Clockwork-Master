--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- We keep the table for utility.
CloudAuthX = CloudAuthX or {};

function CloudAuthX.External()
	return;
end;

do
	local startTime = os.clock();

	local function SafeRequire(mod)
		local success, value = pcall(require, mod);

		if (!success) then
			ErrorNoHalt("[Catwork] Critical Error - Failed to open '"..mod.."' module!");

			return false;
		end;

		return true;
	end;

	if (Clockwork and CW.kernel) then
		MsgC(Color(0, 255, 100, 255), "[Catwork] Change detected! Refreshing...\n");
	else
		MsgC(Color(0, 255, 100, 255), "[Catwork] Framework is initializing...\n");
	end;

	if (system.IsLinux()) then
		SafeRequire("mysqloo");
	else
		SafeRequire("tmysql4");
	end;

	if (!SafeRequire("fileio")) then
		ErrorNoHalt("[Catwork] fileio module has failed to load!\nAborting startup...\n");
		return;
	end;

	if (!CloudAuthX.WatchDogAvailable and system.IsWindows()) then
		if (file.Exists("lua/bin/gmsv_watchdog_win32.dll", "GAME")) then
			print("[Catwork] Loading Watch Dog file monitoring tools...");

			local success = SafeRequire("watchdog");

			if (success) then
				timer.Create("WatchDogUpdater", (1 / 16), 0, function()
					WatchdogUpdate();
				end);

				hook.Add("WatchDogFileChanged", "Printer", function(fileName)
					-- fileName is relative to garrysmod/gamemodes/
					print("[Watchdog] "..fileName);
				end);

				-- lmao
				CloudAuthX.WatchDogAvailable = true;
			else
				ErrorNoHalt("[Catwork] Failed to load Watchdog!\nYou do not appear to have MS Visual C++ 2015 installed!\n");
			end;
		end;
	end;

	function IsWatchdogAvailable()
		return CloudAuthX.WatchDogAvailable;
	end;

	CW_SCRIPT_SHARED = CW_SCRIPT_SHARED or {
		schemaFolder = engine.ActiveGamemode()
	};

	-- No need to include the stuff that doesn't change twice.
	if (!string.utf8len or !pon) then
		AddCSLuaFile("external/utf8.lua");
		AddCSLuaFile("external/pon.lua");
	end;

	AddCSLuaFile("cl_init.lua");

	--[[
		Include pON and UTF-8 library.
	--]]
	if (!string.utf8len or !pon) then
		include("external/utf8.lua");
		include("external/pon.lua");
	end;

	-- Start serverside boot sequence.
	include("catwork/framework/sv_kernel.lua");

	if (CW and cwBootComplete) then
		MsgC(Color(0, 255, 100, 255), "[Catwork] AutoRefresh handled serverside in "..math.Round(os.clock() - startTime, 3).. " second(s)\n");
	else
		local version = CW.kernel:GetVersionBuild();

		MsgC(Color(0, 255, 100, 255), "[Catwork] Framework version ["..version.."] loading took "..math.Round(os.clock() - startTime, 3).. " second(s)\n");

		-- For benchmarking.
		CloudAuthX.LastBootTime = startTime;
	end;
end;

_G["cwBootComplete"] = true;
_G["cwSharedBooted"] = true;