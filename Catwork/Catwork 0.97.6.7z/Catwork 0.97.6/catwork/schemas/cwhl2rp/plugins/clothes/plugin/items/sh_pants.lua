--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Armored Pants";
	ITEM.PrintName = "Штаны с металлическими вставками";
	ITEM.cost = 40;
	ITEM.model = "models/tnb/items/pants_citizen.mdl";
	ITEM.plural = "Штаны с металлическими вставками";
	ITEM.weight = 1;
	ITEM.uniqueID = "pants_2";
	ITEM.business = false;
	ITEM.bodyGroup = 2;
	ITEM.bodyGroupVal = 4;
	ITEM.description = "Бронированные штаны для защиты ваших ценностей.";
	ITEM.protection = 5;
ITEM:Register();