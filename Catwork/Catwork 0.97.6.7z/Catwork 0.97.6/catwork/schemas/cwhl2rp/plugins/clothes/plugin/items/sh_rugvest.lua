--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Rebel Kevlar";
	ITEM.PrintName = "Униформа Повстанца (Рюкзак)";
	ITEM.model = "models/tnb/items/shirt_rebelbag.mdl";
	ITEM.plural = "Униформs Сопротивления (Рюкзак)";
	ITEM.weight = 3;
	ITEM.uniqueID = "rebel_kevlar";
	ITEM.business = false;
	ITEM.bodyGroup = 1;
	ITEM.bodyGroupVal = 12;
	ITEM.description = "Форма сопротивления с рюкзаком.";
	ITEM.protection = 20;
ITEM:Register();