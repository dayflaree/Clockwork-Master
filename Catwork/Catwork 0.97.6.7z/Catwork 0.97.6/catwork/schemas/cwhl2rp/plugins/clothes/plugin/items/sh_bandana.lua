--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Bandana";
	ITEM.PrintName = "Бандана";
	ITEM.cost = 30;
	ITEM.model = "models/tnb/items/facewrap.mdl";
	ITEM.plural = "Банданы";
	ITEM.weight = 0.5;
	ITEM.uniqueID = "bandana";
	ITEM.business = false;
	ITEM.bodyGroup = 4;
	ITEM.bodyGroupVal = 1;
	ITEM.description = "Кусок тряпки, который можно использовать как защиту лица.";
ITEM:Register();