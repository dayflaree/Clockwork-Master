--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "gasmask3";
	ITEM.PrintName = "Маска подразделения HELIX/GRID";
	ITEM.cost = 150;
	ITEM.model = "models/half_life2/jnstudio/props/gasmask_3.mdl";
	ITEM.plural = "Маски подразделения HELIX/GRID";
	ITEM.weight = 1;
	ITEM.uniqueID = "cmb_gasmask3";
	ITEM.business = false;
	ITEM.bodyGroup = 2;
	ITEM.bodyGroupVal = 3;
	ITEM.description = "";
	ITEM.isCombine = true;
	ITEM.requiredBG = {5, 1};
ITEM:Register();