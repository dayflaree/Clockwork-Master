--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Pants";
	ITEM.PrintName = "Штаны";
	ITEM.cost = 15;
	ITEM.model = "models/tnb/items/pants_citizen.mdl";
	ITEM.plural = "Штаны";
	ITEM.weight = 0.5;
	ITEM.uniqueID = "pants";
	ITEM.business = false;
	ITEM.bodyGroup = 2;
	ITEM.bodyGroupVal = 4;
	ITEM.description = "Штаны.";
ITEM:Register();