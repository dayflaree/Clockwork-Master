--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Modified Rebel Vest";
	ITEM.PrintName = "Улучшенный Бронежилет Сопротивления";
	ITEM.cost = 300;
	ITEM.model = "models/tnb/items/shirt_rebel_molle.mdl";
	ITEM.plural = "Улучшенные Бронежилеты Сопротивления";
	ITEM.weight = 5;
	ITEM.uniqueID = "rebel_vest_upgrade";
	ITEM.business = false;
	ITEM.bodyGroup = 1;
	ITEM.bodyGroupVal = 15;
	ITEM.description = "Улучшенная униформа сопротивления с керамическими бронепластинами.";
	ITEM.protection = 30;
ITEM:Register();