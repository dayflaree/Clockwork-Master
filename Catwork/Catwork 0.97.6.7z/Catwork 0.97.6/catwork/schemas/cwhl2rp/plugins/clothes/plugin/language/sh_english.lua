--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("en");

lang["#ITEM_Wear"] = "Wear";
lang["#ITEM_Cat_Clothing"] = "Clothing";
lang["#ITEM_ErrCantWear"] = "You cannot wear this!";
lang["#ITEM_IsWearingYes"] = "Is Wearing: Yes";
lang["#ITEM_IsWearingNo"] = "Is Wearing: No";

lang["#ITEM_RebUni_Name"] = "Rebel Clothes";
lang["#ITEM_RebUni_Name_Plural"] = "Rebel Clothings";
lang["#ITEM_RebUni_Description"] = "A pack of rebel clothing. It has reinforced armor plates with some rags tied around them.";

lang["#ITEM_Bandana_Name"] = "Bandana";
lang["#ITEM_Bandana_Name_Plural"] = "Bandanas";
lang["#ITEM_Bandana_Description"] = "Small piece of cloth to cover the lower half of your face.";