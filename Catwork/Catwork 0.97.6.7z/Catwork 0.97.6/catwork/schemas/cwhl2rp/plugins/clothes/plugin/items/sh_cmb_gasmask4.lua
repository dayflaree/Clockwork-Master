--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "gasmask4";
	ITEM.PrintName = "Маска подразделения VICE";
	ITEM.cost = 150;
	ITEM.model = "models/half_life2/jnstudio/props/gasmask_4.mdl";
	ITEM.plural = "Маски подразделения VICE";
	ITEM.weight = 1;
	ITEM.uniqueID = "cmb_gasmask4";
	ITEM.business = false;
	ITEM.bodyGroup = 2;
	ITEM.bodyGroupVal = 4;
	ITEM.description = "";
	ITEM.isCombine = true;
	ITEM.requiredBG = {5, 1};
ITEM:Register();