--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Bandana Hat";
	ITEM.PrintName = "Бандана с шапкой";
	ITEM.cost = 30;
	ITEM.model = "models/tnb/items/beaniewrap.mdl";
	ITEM.plural = "Банданы с шапками";
	ITEM.weight = 0.5;
	ITEM.uniqueID = "bandana_hat";
	ITEM.business = false;
	ITEM.bodyGroup = 4;
	ITEM.bodyGroupVal = 4;
	ITEM.description = "Шапка и бандана. Мы чтоль идём банк грабить?";
ITEM:Register();