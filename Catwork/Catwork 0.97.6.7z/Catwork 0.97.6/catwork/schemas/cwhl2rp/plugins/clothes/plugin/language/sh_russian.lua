--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("ru");

lang["#ITEM_Wear"] = "Одеть";
lang["#ITEM_Cat_Clothing"] = "Одежда";
lang["#ITEM_ErrCantWear"] = "Вы не можете одеть эту одежду!";
lang["#ITEM_IsWearingYes"] = "Эта одежда надета на вас";
lang["#ITEM_IsWearingNo"] = " Эта одежда не надета на вас ";

lang["#ITEM_RebUni_Name"] = "Униформа Повстанца";
lang["#ITEM_RebUni_Name_Plural"] = "Униформы Повстанца";
lang["#ITEM_RebUni_Description"] = "Набор униформы сопротивления. Имеет легкие металлические вставки, обвязанные всяким тряпьём.";

lang["#ITEM_Bandana_Name"] = "Бандана";
lang["#ITEM_Bandana_Name_Plural"] = "Бандан";
lang["#ITEM_Bandana_Description"] = "Небольшой кусок ткани, закрывающий нижнюю часть вашего лица.";