--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("skin_base");
	ITEM.name = "HELIX Uniform";
	ITEM.PrintName = "Униформа HELIX";
	ITEM.model = "models/half_life2/jnstudio/props/sheet_2.mdl";
	ITEM.plural = "Униформы HELIX";
	ITEM.weight = 2;
	ITEM.uniqueID = "helix_uniform";
	ITEM.business = false;
	ITEM.playerSkin = 2;
	ITEM.description = "Чистая и новая униформа отряда HELIX.";
	ITEM.protection = 10;
	ITEM.isCombine = true;
ITEM:Register();