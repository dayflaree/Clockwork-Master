--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("skin_base");
	ITEM.name = "CmD Uniform";
	ITEM.PrintName = "Униформа CmD";
	ITEM.model = "models/half_life2/jnstudio/props/sheet_5.mdl";
	ITEM.plural = "Униформы CmD";
	ITEM.weight = 2;
	ITEM.uniqueID = "cmd_uniform";
	ITEM.business = false;
	ITEM.playerSkin = 5;
	ITEM.description = "Униформа командира отделения Г.О.";
	ITEM.protection = 20;
	ITEM.isCombine = true;
ITEM:Register();