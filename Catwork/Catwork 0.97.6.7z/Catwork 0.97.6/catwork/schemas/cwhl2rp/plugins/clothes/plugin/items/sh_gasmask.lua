--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Gas Mask";
	ITEM.PrintName = "Противогаз";
	ITEM.cost = 85;
	ITEM.model = "models/tnb/items/gasmask.mdl";
	ITEM.plural = "Противогазы";
	ITEM.weight = 0.7;
	ITEM.uniqueID = "gas_mask";
	ITEM.business = false;
	ITEM.bodyGroup = 4;
	ITEM.bodyGroupVal = 2;
	ITEM.description = "Защитная маска с воздушным фильтром.";
	ITEM.protection = 5;
ITEM:Register();