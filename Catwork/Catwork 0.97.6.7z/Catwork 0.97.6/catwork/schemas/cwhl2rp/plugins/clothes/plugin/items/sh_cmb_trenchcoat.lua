--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Officer's Trenchcoat";
	ITEM.PrintName = "Офицерский полуплащ";
	ITEM.cost = 100;
	ITEM.model = "models/half_life2/jnstudio/props/coat.mdl";
	ITEM.plural = "Офицерские полуплащи";
	ITEM.weight = 2;
	ITEM.uniqueID = "cmb_ofc_trenchcoat";
	ITEM.business = false;
	ITEM.bodyGroup = 4;
	ITEM.bodyGroupVal = 1;
	ITEM.description = "";
	ITEM.isCombine = true;
	ITEM.protection = 35;
ITEM:Register();