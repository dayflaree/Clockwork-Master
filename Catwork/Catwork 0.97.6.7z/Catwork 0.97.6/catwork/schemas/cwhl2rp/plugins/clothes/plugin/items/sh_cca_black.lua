--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("skin_base");
	ITEM.name = "Black CCA Uniform";
	ITEM.PrintName = "Черная Униформа CCA";
	ITEM.model = "models/half_life2/jnstudio/props/sheet_4.mdl";
	ITEM.plural = "Черные Униформы CCA";
	ITEM.weight = 2;
	ITEM.uniqueID = "black_cca_uniform";
	ITEM.business = false;
	ITEM.playerSkin = 4;
	ITEM.description = "Черная и блестящая униформа CCA.";
	ITEM.protection = 10;
	ITEM.isCombine = true;
ITEM:Register();