--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("skin_base");
	ITEM.name = "VICE Uniform";
	ITEM.PrintName = "Униформа VICE";
	ITEM.model = "models/half_life2/jnstudio/props/sheet_6.mdl";
	ITEM.plural = "Униформы VICE";
	ITEM.weight = 2;
	ITEM.uniqueID = "vice_uniform";
	ITEM.business = false;
	ITEM.playerSkin = 6;
	ITEM.description = "Чистая и новая униформа отряда VICE.";
	ITEM.protection = 10;
	ITEM.isCombine = true;
ITEM:Register();