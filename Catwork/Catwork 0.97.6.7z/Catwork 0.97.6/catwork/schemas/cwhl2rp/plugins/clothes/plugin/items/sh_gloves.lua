--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "Gloves";
	ITEM.PrintName = "Перчатки";
	ITEM.cost = 25;
	ITEM.model = "models/tnb/items/gloves.mdl";
	ITEM.plural = "Перчатки";
	ITEM.weight = 0.5;
	ITEM.uniqueID = "gloves";
	ITEM.business = false;
	ITEM.bodyGroup = 3;
	ITEM.bodyGroupVal = 1;
	ITEM.description = "Шерстяные перчатки";
ITEM:Register();