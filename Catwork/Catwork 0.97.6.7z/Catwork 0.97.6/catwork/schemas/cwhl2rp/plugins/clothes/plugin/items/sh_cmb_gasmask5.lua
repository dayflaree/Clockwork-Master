--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "gasmask5";
	ITEM.PrintName = "Офицерская маска";
	ITEM.cost = 150;
	ITEM.model = "models/half_life2/jnstudio/props/gasmask_5.mdl";
	ITEM.plural = "Офицерские маски";
	ITEM.weight = 1;
	ITEM.uniqueID = "cmb_gasmask5";
	ITEM.business = false;
	ITEM.bodyGroup = 2;
	ITEM.bodyGroupVal = 5;
	ITEM.description = "";
	ITEM.isCombine = true;
	ITEM.requiredBG = {5, 1};
ITEM:Register();