--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base");
	ITEM.name = "razgruz";
	ITEM.PrintName = "Разгрузочный жилет";
	ITEM.cost = 100;
	ITEM.model = "models/half_life2/jnstudio/props/gear.mdl";
	ITEM.plural = "Разгрузочные жилеты";
	ITEM.weight = 3;
	ITEM.uniqueID = "cmb_razgruz";
	ITEM.business = false;
	ITEM.bodyGroup = 3;
	ITEM.bodyGroupVal = 1;
	ITEM.description = "";
	ITEM.isCombine = true;
	ITEM.protection = 25;
ITEM:Register();