--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New(nil, true);
ITEM.name = "Alcohol Base";
ITEM.useText = "Drink";
ITEM.category = "Consumables";
ITEM.useSound = {"npc/barnacle/barnacle_gulp1.wav", "npc/barnacle/barnacle_gulp2.wav"};
ITEM.expireTime = 120;
ITEM.attributes = {};

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	for k, v in pairs(self("attributes")) do
		player:BoostAttribute(self("PrintName"), k, v, self("expireTime"));
	end;

	CW.player:SetDrunk(player, self("expireTime"));

	if (self.OnDrink) then
		self:OnDrink(player);
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

CW.item:Register(ITEM);