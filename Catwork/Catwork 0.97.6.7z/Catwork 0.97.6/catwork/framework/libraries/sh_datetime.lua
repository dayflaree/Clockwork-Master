--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.time = CW.kernel:NewLibrary("Time");
CW.date = CW.kernel:NewLibrary("Date");

-- A function to get the time minute.
function CW.time:GetMinute()
	if (CLIENT) then
		return netvars.GetNetVar("Minute");
	else
		return self.minute;
	end;
end;

-- A function to get the time hour.
function CW.time:GetHour()
	if (CLIENT) then
		return netvars.GetNetVar("Hour");
	else
		return self.hour;
	end;
end;

-- A function to get the time day.
function CW.time:GetDay()
	if (CLIENT) then
		return netvars.GetNetVar("Day");
	else
		return self.day;
	end;
end;

-- A function to get the day name.
function CW.time:GetDayName()
	local defaultDays = CW.option:GetKey("default_days");

	if (defaultDays) then
		return defaultDays[self:GetDay()] or "Unknown";
	end;
end;

if (SERVER) then
	function CW.time:GetSaveData()
		return {
			minute = self:GetMinute(),
			hour = self:GetHour(),
			day = self:GetDay()
		};
	end;

	-- A function to get the date save data.
	function CW.date:GetSaveData()
		return {
			month = self:GetMonth(),
			year = self:GetYear(),
			day = self:GetDay()
		};
	end;

	-- A function to get the date year.
	function CW.date:GetYear()
		return self.year;
	end;

	-- A function to get the date month.
	function CW.date:GetMonth()
		return self.month;
	end;

	-- A function to get the date day.
	function CW.date:GetDay()
		return self.day;
	end;
else
	function CW.date:GetString()
		return netvars.GetNetVar("Date");
	end;

	-- A function to get the time as a string.
	function CW.time:GetString()
		--[[
		local minute = CW.kernel:ZeroNumberToDigits(self:GetMinute(), 2);
		local hour = CW.kernel:ZeroNumberToDigits(self:GetHour(), 2);

		if (CW_CONVAR_TWELVEHOURCLOCK:GetInt() == 1) then
			print(hour);
			hour = tonumber(hour);
			print(hour);
			print(minute);
			print(CW.kernel:ZeroNumberToDigits(hour, 2));

			if (hour >= 12) then
				if (hour > 12) then
					hour = hour - 12;
				end;
				print(hour);

				return CW.kernel:ZeroNumberToDigits(hour, 2)..":"..minute.."pm";
			else
				return CW.kernel:ZeroNumberToDigits(hour, 2)..":"..minute.."am";
			end;
		else
			return hour..":"..minute;
		end;
		--]]

		--This is bugged, seems like an issue with hour SharedVar not being sent to client.
		return "";
	end;
end;