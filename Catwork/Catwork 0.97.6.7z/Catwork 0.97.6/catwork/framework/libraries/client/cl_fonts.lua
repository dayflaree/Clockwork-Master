--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CreateFont = CreateFont or surface.CreateFont;

function surface.CreateFont(...)
	CW.fonts:Add(...);
end;

CW.fonts = CW.kernel:NewLibrary("Fonts");
CW.fonts.stored = CW.fonts.stored or {};
CW.fonts.sizes = CW.fonts.sizes or {};

-- A function to add a new font to the system.
function CW.fonts:Add(name, fontTable)
	if (self.stored[name]) then return; end;

	fontTable.extended = true; -- Force the font to load all characters.
	self.stored[name] = fontTable;
	CreateFont(name, self.stored[name]);
end;

-- A function to find a font by name.
function CW.fonts:FindByName(name)
	return self.stored[name];
end;

-- A function to grab a font by size (creating what doesn't exist.)
function CW.fonts:GetSize(name, size)
	local fontKey = name..size;

	if (self.sizes[fontKey]) then
		return fontKey;
	end;

	if (!self.stored[name]) then
		return name;
	end;

	self.sizes[fontKey] = table.Copy(self.stored[name]);
	self.sizes[fontKey].size = size;

	CreateFont(fontKey, self.sizes[fontKey]);
	return fontKey;
end;

-- A function to grab a font by multiplier.
function CW.fonts:GetMultiplied(name, multiplier)
	local fontTable = self:FindByName(name);
	if (fontTable == nil) then return name; end;

	return self:GetSize(name, fontTable.size * multiplier);
end;

CW.fonts:Add("cwMainText", 
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(7),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwESPText", 
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(5.5),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("cwTooltip", 
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(5),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("CW.menuTextBig",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(18),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("CW.menuTextTiny",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(7),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwInfoTextFont",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(6),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("CW.menuTextHuge",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(30),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("CW.menuTextSmall",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(10),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwIntroTextBig",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(18),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwIntroTextTiny",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(9),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwIntroTextSmall",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(7),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended	= true
});
CW.fonts:Add("cwLarge3D2D",
{
	font		= "Arial",
	size		= CW.kernel:GetFontSize3D(),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("cwScoreboardName",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(7),
	weight		= 600,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("cwScoreboardDesc",
{
	font		= "Arial",
	size		= CW.kernel:FontScreenScale(5),
	weight		= 600,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("cwCinematicText",
{
	font		= "Trebuchet",
	size		= CW.kernel:FontScreenScale(8),
	weight		= 700,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
CW.fonts:Add("cwChatSyntax",
{
	font		= "Courier New",
	size		= CW.kernel:FontScreenScale(7),
	weight		= 600,
	antialiase	= true,
	additive 	= false,
	extended 	= true
});
