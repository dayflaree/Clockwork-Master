--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.quickmenu = CW.kernel:NewLibrary("QuickMenu");
CW.quickmenu.stored = CW.quickmenu.stored or {};
CW.quickmenu.categories = CW.quickmenu.categories or {};

-- A function to add a quick menu callback.
function CW.quickmenu:AddCallback(name, category, GetInfo, OnCreateMenu)
	if (category) then
		if (!self.categories[category]) then
			self.categories[category] = {};
		end;

		self.categories[category][name] = {
			OnCreateMenu = OnCreateMenu,
			GetInfo = GetInfo,
			name = name
		};
	else
		self.stored[name] = {
			OnCreateMenu = OnCreateMenu,
			GetInfo = GetInfo,
			name = name
		};
	end;

	return name;
end;

-- A function to add a command quick menu callback.
function CW.quickmenu:AddCommand(name, category, command, options)
	return self:AddCallback(name, category, function()
		local commandTable = CW.command:FindByID(command);

		if (commandTable) then
			return {
				toolTip = commandTable.tip,
				Callback = function(option)
					CW.kernel:RunCommand(command, option);
				end,
				options = options
			};
		else
			return false;
		end;
	end);
end;

CW.quickmenu:AddCallback("Fall Over", nil, function()
	local commandTable = CW.command:FindByID("CharFallOver");

	if (commandTable) then
		return {
			toolTip = commandTable.tip,
			Callback = function(option)
				CW.kernel:RunCommand("CharFallOver");
			end
		};
	else
		return false;
	end;
end);

CW.quickmenu:AddCallback("Description", nil, function()
	local commandTable = CW.command:FindByID("CharPhysDesc");

	if (commandTable) then
		return {
			toolTip = commandTable.tip,
			Callback = function(option)
				CW.kernel:RunCommand("CharPhysDesc");
			end
		};
	else
		return false;
	end;
end);