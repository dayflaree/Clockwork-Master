--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Provides limited backwards compatibility with old Clockwork plugins.

CW.datastream = CW.datastream or {};
CW.plugin = CW.plugin or {};
CW.config = CW.config or {};

function CW.datastream:Start(...)
	return netstream.Start(...);
end;

function CW.datastream:Hook(...)
	return netstream.Hook(...);
end;

function CW.datastream:Split(...)
	return netstream.Split(...);
end;

function CW.plugin:Call(...)
	return plugin.Call(...);
end;

function CW.config:Get(...)
	return config.Get(...);
end;

function CW.config:GetVal(...)
	return config.GetVal(...);
end;

if (SERVER) then
	function CW.config:Add(...)
		return config.Add(...)
	end;
else
	function CW.config:AddToSystem(...)
		return config.AddToSystem(...);
	end;
end;

function CW.config:ShareKey(...)
	return config.ShareKey(...);
end;