--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	@codebase Server
	@details Provides an interface to the hints system.
	@field stored A table containing a list of stored hints.
--]]
CW.hint = CW.kernel:NewLibrary("Hint");
local stored = CW.hint.stored or {};
CW.hint.stored = stored;

--[[
	@codebase Server
	@details Add a new hint to the list.
	@param String A unique identifier.
	@param String The body of the hint.
	@param Function A callback with the player as an argument, return false to hide.
--]]
function CW.hint:Add(name, text, Callback)
	stored[name] = {
		Callback = Callback,
		text = text
	};
end;

--[[
	@codebase Server
	@details Remove an existing hint from the list.
	@param String A unique identifier.
--]]
function CW.hint:Remove(name)
	stored[name] = nil;
end;

--[[
	@codebase Server
	@details Find a hint by its identifier.
	@param String A unique identifier.
	@returns Table The hint table matching the identifier.
--]]
function CW.hint:Find(name)
	return stored[name];
end;

--[[
	@codebase Server
	@details Distribute a hint to each player.
--]]
function CW.hint:Distribute()
	local hintText, Callback = self:Get();
	local hintInterval = config.Get("hint_interval"):Get();

	if (!hintText) then return; end;

	for k, v in ipairs(_player.GetAll()) do
		if (v:HasInitialized() and v:GetInfoNum("cwShowHints", 1) == 1
		and !v:IsViewingStarterHints()) then
			if (!Callback or Callback(v) != false) then
				self:Send(v, hintText, 6, nil, true);
			end;
		end;
	end;
end;

--[[
	@codebase Server
	@details Send customized and centered hint text to a player.
	@param Player The recipient(s).
	@param String The hint text to send.
	@param Float The delay before it fades.
	@param Color The color of the hint text.
	@option Bool:String Specify a custom sound or false for no sound.
	@option Bool Specify wether to display duplicates of this hint.
--]]
function CW.hint:SendCenter(player, text, delay, color, bNoSound, showDuplicated)
	netstream.Start(player, "Hint", {
		text = CW.kernel:ParseData(text),
		delay = delay,
		color = color,
		center = true,
		noSound = bNoSound,
		showDuplicates = showDuplicated
	});
end;

--[[
	@codebase Server
	@details Send customized and centered hint text to all players.
	@param String The hint text to send.
	@param Float The delay before it fades.
	@param Color The color of the hint text.
--]]
function CW.hint:SendCenterAll(text, delay, color)
	for k, v in ipairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			self:SendCenter(v, text, delay, color);
		end;
	end;
end;

--[[
	@codebase Server
	@details Send customized hint text to a player.
	@param Player The recipient(s).
	@param String The hint text to send.
	@param Float The delay before it fades.
	@param Color The color of the hint text.
	@option Bool:String Specify a custom sound or false for no sound.
	@option Bool Specify wether to display duplicates of this hint.
--]]
function CW.hint:Send(player, text, delay, color, bNoSound, showDuplicated)
	netstream.Start(player, "Hint", {
		text = CW.kernel:ParseData(text), delay = delay, color = color, noSound = bNoSound, showDuplicates = showDuplicated
	});
end;

--[[
	@codebase Server
	@details Send customized hint text to all players.
	@param String The hint text to send.
	@param Float The delay before it fades.
	@param Color The color of the hint text.
--]]
function CW.hint:SendAll(text, delay, color)
	for k, v in ipairs(_player.GetAll()) do
		if (v:HasInitialized()) then
			self:Send(v, text, delay, color);
		end;
	end;
end;

--[[
	@codebase Server
	@details Pick a random hint from the list.
	@returns String The random hint text.
	@returns Function The random hint callback.
--]]
function CW.hint:Get()
	local hints = {};

	for k, v in pairs(stored) do
		if (!v.Callback or v.Callback() != false) then
			hints[#hints + 1] = v;
		end;
	end;

	if (#hints > 0) then
		local hint = hints[math.random(1, #hints)];

		if (hint) then
			return hint.text, hint.Callback;
		end;
	end;
end;

CW.hint:Add("OOC", "Type // before your message to talk out-of-character.");
CW.hint:Add("LOOC", "Type .// or [[ before your message to talk out-of-character locally.");
CW.hint:Add("Ducking", "Toggle ducking by holding :+speed: and pressing :+walk: while standing still.");
CW.hint:Add("Jogging", "Toggle jogging by pressing :+walk: while moving.");
CW.hint:Add("Directory", "Hold down :+showscores: and click *name_directory* to get help.");
CW.hint:Add("F1 Hotkey", "Hold :gm_showhelp: to view your character and roleplay information.");
CW.hint:Add("F2 Hotkey", "Press :gm_showteam: while looking at a door to view the door menu.");
CW.hint:Add("Tab Hotkey", "Press :+showscores: to view the main menu, or hold :+showscores: to temporarily view it.");

CW.hint:Add("Context Menu", "Hold :+menu_context: and click on an entity to open its menu.", function(player)
	return !config.Get("use_opens_entity_menus"):Get();
end);
CW.hint:Add("Entity Menu", "Press :+use: on an entity to open its menu.", function(player)
	return config.Get("use_opens_entity_menus"):Get();
end);
CW.hint:Add("Phys Desc", "Change your character's physical description by typing $command_prefix$CharPhysDesc.", function(player)
	return CW.command:FindByID("CharPhysDesc") != nil;
end);
CW.hint:Add("Give Name", "Press :gm_showteam: to allow characters within a specific range to recognise you.", function(player)
	return config.Get("recognise_system"):Get();
end);
CW.hint:Add("Raise Weapon", "Hold :+reload: to raise or lower your weapon.", function(player)
	return config.Get("raised_weapon_system"):Get();
end);
CW.hint:Add("Target Recognises", "A character's name will flash white if they do not recognise you.", function(player)
	return config.Get("recognise_system"):Get();
end);