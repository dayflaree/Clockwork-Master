--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("ru");

lang.name = "Русский язык";

-- Config Print
lang["#ConfigVariablesPrinted"] = "Значения конфигурации были выведены в консоль.";

-- Various Error Messages
lang["#CannotPurchaseAnotherDoor"] = "Вы не можете приобрести еще одну дверь!";
lang["#EntityOptionWaitTime"] = "Вы не можете использовать это настолько быстро!";
lang["#YouNeedAnother"] = "Вам необходимо еще #1!";
lang["#NotEnoughText"] = "Вы не ввели достаточное количество текста!";
lang["#NotValidMap"] = "На сервере нет карты #1!"
lang["#CannotChangeClassFor"] = "Вы не можете сменить класс еще #1 секунд!";
lang["#CannotActionRightNow"] = "Вы не можете сделать это сейчас!";
lang["#DroppedItemsOtherChar"] = "Нельзя подбирать предметы, принадлежащие другому вашему персонажу!";
lang["#DroppedCashOtherChar"] = "Нельзя подобрать #1, принадлежащий другому вашему персонажу!";
lang["#NotValidCharacter"] = "Персонажа '#1' не существует!";
lang["#NotValidPlayer"] = "Игрока '#1' не существует!";
lang["#NotValidAmount"] = "Введенное вами количество не подходит!";

-- Roll Message
lang["#HasRolled"] = "#1'у выпало #2 из #3.";
lang["#LogHasRolled"] = "#1 выпало #2 из #3!";

-- Cash Set Messages
lang ["CashSetTarget"] = "#3 установил ваши #1 на #2."
lang ["CashSetPlayer"] = "Вы установили #2 #1 на #3."

-- Storage Error Messages
lang["#StorageNoInstance"] = "Данного предмета нет в этом хранилище!";
lang["#StorageNotOpen"] = "Вы не можете открыть это хранилище!";
lang["#StorageCannotGive"] = "Вы не можете хранить предметы здесь!";
lang["#StoragePlayerNoInstance"] = "У вас нет данного предмета!";

-- Class Error Messages
lang["#ClassNoAccess"] = "Вы не имеете доступа к этому классу!";
lang["#ClassTooMany"] = "Слишком много персонажей в этом классом!";
lang["#ClassNotValid"] = "Такого класса не существует!";

-- Voicemail Notifies
lang["#VoicemailRemoved"] = "Вы удалили своб голосовую почту.";
lang["#VoicemailSet"] = "Вы установили свою голосовую почту на '#1'.";

-- Weapon Error Messages
lang["#CannotHolsterWeapon"] = "Вы не можете опустить это оружие!";
lang["#CannotDropWeapon"] = "Вы не можете выкинуть это оружие!";
lang["#CannotUseWeapon"] = "Вы не можете использовать это оружие!";

-- Config Error Messages
lang["#ConfigUnableToSet"] = "Невозможно установить значение конфигурации '#1'!";
lang["#ConfigIsStaticKey"] = "#1 является статическим значением конфигурации!";
lang["#ConfigKeyNotValid"] = "Значение конфигурации '#1' не существует!";

-- Settings Categories
lang["#Framework"] = "Игровой режим";
lang["#ChatBox"] = "Чат";
lang["#Theme"] = "Оформление";
lang["#AdminESP"] = "ESP Администратора";

-- Settings Info Text
lang["#SettingsInfoText"] = "Данные настройки позволяют вам персонализировать внешний вид Clockwork'а.";
lang["#NoSettingsInfoText"] = "К-сожалению, у вас нету доступа к каким-либо настройкам!";

-- Settings Descriptions
lang["#ThemeDesc"] = "Выбранное оформление для интерфейса пользователя.";
lang["#EnableAdminESPDesc"] = "Включить/выключить радар (ESP).";
lang["#DrawESPBarsDesc"] = "Отрисовывать полоски прогресса для некоторых значений.";
lang["#ShowItemEntitiesDesc"] = "Показывать предметы на радаре.";
lang["#ShowSalesmenEntitiesDesc"] = "Показывать NPC продавцов на радаре.";
lang["#ESPIntervalDesc"] = "Интервал между обновлениями радара.";
lang["#TwelveHourClockDesc"] = "Показывать время в 12-часовом формате.";
lang["#ShowBarsDesc"] = "Показывать полоски в верхнем углу экрана.";
lang["#EnableHintsDesc"] = "Показывать подсказки.";
lang["#LangDesc"] = "Выбранный язык.";
lang["#EnableVignetteDesc"] = "Отрисовывать виньетку по краям экрана.";
lang["#ShowTimestampsDesc"] = "Показывать время возле сообщений в чате.";
lang["#ShowCWMessagesDesc"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessagesDesc"] = "Показывать сообщения сервера.";
lang["#ShowOOCMessagesDesc"] = "Показывать глобальные (OOC) сообщения.";
lang["#ShowICMessagesDesc"] = "Показывать сообщения персонажей (IC чат).";
lang["#HeadbobAmountDesc"] = "Множитель качки (пошатанывания) головы.";
lang["#ChatLinesDesc"] = "Количество строк чата, которые можно увидеть за раз.";
lang["#EnableConsoleLogDesc"] = "Показывать логи администратора.";
lang["#TextColorDesc"] = "Цвет, используемый по большей части для текстов оформления.";
lang["#BGColorDesc"] = "Цвет фона.";
lang["#TabMenuXDesc"] = "Позиция TAB-меню по оси X.";
lang["#TabMenuYDesc"] = "Позиция TAB-меню по оси Y.";
lang["#BackMenuXDesc"] = "Позиция фона по оси X.";
lang["#BackMenuYDesc"] = "Позиция фона по оси Y.";
lang["#BackMenuWDesc"] = "Ширина фона.";
lang["#BackMenuHDesc"] = "Высота фона.";
lang["#FadePanelsDesc"] = "Использовать переливание панелей из одну в другую при смене вкладок TAB-меню.";
lang["#ShowMaterialDesc"] = "Отрисовывать материал на фоне меню.";
lang["#ShowGradientDesc"] = "Отрисовывать градиент (блюр) на фоне меню.";
lang["#MenuMaterialDesc"] = "Материал, используемый как фон для TAB-меню.";

-- Settings Names
lang["#EnableAdminESP"] = "Включить Админ ESP.";
lang["#DrawESPBars"] = "Показывать полоски.";
lang["#ShowSpawnPoints"] = "Показывать точки возрождения.";
lang["#ShowStaticEnts"] = "Показывать статичные объекты.";
lang["#ShowItemEntities"] = "Показывать предметы.";
lang["#ShowSalesmenEntities"] = "Показывать продавцов.";
lang["#ESPInterval"] = "Интервал обновления радара:";
lang["#TwelveHourClock"] = "Включить 12-часовой формат времени.";
lang["#ShowBars"] = "Показывать полоски в верхней части экрана.";
lang["#EnableHints"] = "Включить подсказки.";
lang["#Language"] = "Язык";
lang["#EnableVignette"] = "Показывать виньетку";
lang["#ShowTimestamps"] = "Показывать время сообщений в чате.";
lang["#ShowCWMessages"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessages"] = "Показывать сообщения от сервера.";
lang["#ShowOOCMessages"] = "Показывать OOC чат.";
lang["#ShowICMessages"] = "Показывать IC чат.";
lang["#HeadbobAmount"] = "Амплитуда пошатывания головы:";
lang["#ChatLines"] = "Количество строк чата:";
lang["#EnableConsoleLog"] = "Включить логи администратора.";
lang["#TextColor"] = "Цвет текста:";
lang["#BGColor"] = "Цвет фона:";
lang["#TabMenuX"] = "Позиция TAB-меню по оси X:";
lang["#TabMenuY"] = "Позиция TAB-меню по оси Y:";
lang["#BackMenuX"] = "Позиция фона по оси X:";
lang["#BackMenuY"] = "Позиция фона по оси Y:";
lang["#BackMenuW"] = "Ширина фона:";
lang["#BackMenuH"] = "Высота фона:";
lang["#FadePanels"] = "Переливать панели:";
lang["#ShowMaterial"] = "Показывать материал:";
lang["#ShowGradient"] = "Показывать блюр-фон:";
lang["#MenuMaterial"] = "Материал:";

-- Settings Descriptions
lang["#ThemeDesc"] = "Выбранное оформление для интерфейса пользователя.";
lang["#EnableAdminESPDesc"] = "Включить/выключить радар администратора.";
lang["#DrawESPBarsDesc"] = "Отрисовывать полоски прогресса для некоторых значений.";
lang["#ShowItemEntitiesDesc"] = "Показывать предметы на радаре.";
lang["#ShowSalesmenEntitiesDesc"] = "Показывать NPC-продавцов на радаре.";
lang["#ESPIntervalDesc"] = "Интервал между обновлениями радара.";
lang["#TwelveHourClockDesc"] = "Использовать 12-часовые часы.";
lang["#ShowBarsDesc"] = "Показывать полоски в верхнем углу экрана.";
lang["#EnableHintsDesc"] = "Показывать подсказки.";
lang["#LangDesc"] = "Выбранный язык.";
lang["#EnableVignetteDesc"] = "Отрисовывать виньетку по краям экрана.";
lang["#ShowTimestampsDesc"] = "Показывать время возле сообщений в чате.";
lang["#ShowCWMessagesDesc"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessagesDesc"] = "Показывать сообщения сервера.";
lang["#ShowOOCMessagesDesc"] = "Показывать глобальные (OOC) сообщения.";
lang["#ShowICMessagesDesc"] = "Показывать сообщения персонажей (IC чат).";
lang["#HeadbobAmountDesc"] = "Множитель качки (шатания) головы.";
lang["#ChatLinesDesc"] = "Количество строк чата, которые можно увидеть за раз.";
lang["#EnableConsoleLogDesc"] = "Показывать логи администратора.";
lang["#TextColorDesc"] = "Цвет, используемый по большей части для текстов оформления.";
lang["#BGColorDesc"] = "Цвет фона.";
lang["#TabMenuXDesc"] = "Позиция TAB-меню по оси X.";
lang["#TabMenuYDesc"] = "Позиция TAB-меню по оси Y.";
lang["#BackMenuXDesc"] = "Позиция фона по оси X.";
lang["#BackMenuYDesc"] = "Позиция фона по оси Y.";
lang["#BackMenuWDesc"] = "Ширина фона.";
lang["#BackMenuHDesc"] = "Высота фона.";
lang["#FadePanelsDesc"] = "Использовать переливание панелей из одну в другую при смене вкладок TAB-меню.";
lang["#ShowMaterialDesc"] = "Отрисовывать материал на фоне меню.";
lang["#ShowGradientDesc"] = "Отрисовывать градиент (блюр) на фоне меню.";
lang["#MenuMaterialDesc"] = "Материал, используемый как фон для TAB-меню.";

-- Settings Names
lang["#EnableAdminESP"] = "Включить радар администратора.";
lang["#DrawESPBars"] = "Показывать полоски.";
lang["#ShowSpawnPoints"] = "Показывать точки возрождения.";
lang["#ShowStaticEnts"] = "Показывать статичные объекты.";
lang["#ShowItemEntities"] = "Показывать предметы.";
lang["#ShowSalesmenEntities"] = "Показывать продавцов.";
lang["#ESPInterval"] = "Интервал обновления радара:";
lang["#TwelveHourClock"] = "Включить 12-часовые часы.";
lang["#ShowBars"] = "Показывать полоски в верхней части экрана.";
lang["#EnableHints"] = "Включить подсказки.";
lang["#Language"] = "Язык";
lang["#EnableVignette"] = "Показывать виньетку";
lang["#ShowTimestamps"] = "Показывать время сообщений в чате.";
lang["#ShowCWMessages"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessages"] = "Показывать сообщения от сервера.";
lang["#ShowOOCMessages"] = "Показывать OOC чат.";
lang["#ShowICMessages"] = "Показывать IC чат.";
lang["#HeadbobAmount"] = "Амплитуда шатания головы:";
lang["#ChatLines"] = "Количество строк чата:";
lang["#EnableConsoleLog"] = "Включить логи администратора.";
lang["#TextColor"] = "Цвет текста:";
lang["#BGColor"] = "Цвет фона:";
lang["#TabMenuX"] = "Позиция TAB-меню по оси X:";
lang["#TabMenuY"] = "Позиция TAB-меню по оси Y:";
lang["#BackMenuX"] = "Позиция фона по оси X:";
lang["#BackMenuY"] = "Позиция фона по оси Y:";
lang["#BackMenuW"] = "Ширина фона:";
lang["#BackMenuH"] = "Высота фона:";
lang["#FadePanels"] = "Переливать панели:";
lang["#ShowMaterial"] = "Показывать материал:";
lang["#ShowGradient"] = "Показывать блюр-фон:";
lang["#MenuMaterial"] = "Материал:";

--[[
	You don't HAVE to translate the config, but I feel like it'd be 
	easier for server owners / SAs who have trouble with English.
--]]

--[[
	I just took a look at the amount of text.
	no.
	nopls.
	i'm out.
	nonononono.
	no way.
	no thanks.
	i'm good.

	maybe later.
	~meow
--]]

-- Config Descriptions
lang["#AttributeProgressionScaleDesc"] = "Множитель прогресса аттрибутов.";
lang["#MessagesMustSeePlayerDesc"] = "Должен ли говорящий игрок находиться в поле зрения другого игрока, чтобы быть услышанным.";
lang["#StartingAttributePointsDesc"] = "Количество очков аттрибутов, которые игрок имеет сначала.";
lang["#ClockworkIntroEnabledDesc"] = "Включить заставку при первоначальном заходе на сервер.";
lang["#HealthRegenerationEnabledDesc"] = "Включить постепенную регенерацию здоровья.";
lang["#PropProtectionEnabledDesc"] = "Включить защиту объектов (пропов).";
lang["#UseLocalMachineDateDesc"] = "Использовать дату сервера при загрузке карты.";
lang["#UseLocalMachineTimeDesc"] = "Использовать время сервера при загрузке карты.";
lang["#UseKeyOpensEntityMenusDesc"] = "Открывает ли клавиша 'использовать' контекстные меню объектов.";
lang["#ShootAfterRaiseDelayDesc"] = "При приведении оружия в боевую готовность, сколько времени должен ждать игрок\nпрежде чем он сможет начать стрельбу.\nЗначение '0' убирает эту задержку.";
lang["#UseClockworkAdminSystemDesc"] = "Используется ли на сервере какая-либо другая админка, чем встроенная в Clockwork.";
lang["#SavedRecognisedNamesDesc"] = "Включить сохранение знакомых имён персонажей.";
lang["#SaveAttributeBoostsDesc"] = "Включить сохранение увеличения аттрибутов.";
lang["#RagdollDamageImmunityTimeDesc"] = "Время в секундах пока рэгдолл игрока не получает никакого урона.";
lang["#AdditionalCharacterCountDesc"] = "Количество дополнительных персонажей, которое игрок может создать.";
lang["#ClassChangingIntervalDesc"] = "Время, которое игрок должен подождать между сменами классов (в секундах).";
lang["#SprintingLowersWeaponDesc"] = "Опускается ли оружие при беге.";
lang["#WeaponRaisingSystemDesc"] = "Включить систему опускания оружия.";
lang["#PropKillProtectionDesc"] = "Включить защиту от убийства объектами";
lang["#GeneratorIntervalDesc"] = "Сколько времени требуется генератору, чтобы произвести деньги (в секундах).";
lang["#GravityGunPuntDesc"] = "Включить возможность гравипушки толкать предметы.";
lang["#DefaultInventoryWeightDesc"] = "Вес, который игрок может переносить в инвентаре (килограммы).";
lang["#DefaultInventorySpaceDesc"] = "Объем, который игрок может переносить в инвентаре (литры).";
lang["#DataSaveIntervalDesc"] = "Интервал сохранения данных сервером в секундах.";
lang["#ViewPunchOnDamageDesc"] = "Искажается ли экран при ударе в игрока.";
lang["#UnrecognisedNameDesc"] = "Описание неизвестных личностей.";
lang["#LimbDamageSystemDesc"] = "Включена ли система урона по конечностям.";
lang["#FallDamageScaleDesc"] = "Множитель урона падение.";
lang["#StartingCurrencyDesc"] = "Сумма по умолчанию, с которой начинает игрок.";
lang["#ArmorAffectsChestDesc"] = "Влияет ли броня только на район груди.";
lang["#MinimumPhysicalDescriptionDesc"] = "Минимальное количество символов в описании.";
lang["#WoodBreaksFallDesc"] = "Ломаются ли деревянные пропы при взаимодействии с игроком.";
lang["#VignetteEnabledDesc"] = "Использовать виньетку.";
lang["#HeartbeatSoundsDesc"] = "Использовать сердцебиение .";
lang["#CrosshairEnabledDesc"] = "Использовать прицел.";
lang["#FreeAimingDesc"] = "Использовать свободное прицеливание.";
lang["#RecogniseSystemDesc"] = "Использовать систему знакомств.";
lang["#CurrencyEnabledDesc"] = "Использовать денежную систему.";
lang["#DefaultPhysicalDescriptionDesc"] = "Физическое описание по умолчанию.";
lang["#ChestDamageScaleDesc"] = "Множитель урона в грудь.";
lang["#CorpseDecayTimeDesc"] = "Время, за которое растворяется рэгдолл игрока.";
lang["#BannedDisconnectMessageDesc"] = "Сообщение, показывающееся заблокированным пользователям.\n!t для оставшегося времени, !f для формата времени.";
lang["#WagesIntervalDesc"] = "Промежуток времени между зарплатой. (секунды).";
lang["#PropCostScaleDesc"] = "Множитель цен на пропы.\0 - бесплатные пропы.";
lang["#FadeNPCCorpsesDesc"] = "Растворять рэгдоллы мертвых НПЦ.";
lang["#CashWeightDesc"] = "Вес валюты(кг).";
lang["#CashSpaceDesc"] = "Объем валюты(литры)).";
lang["#HeadDamageScaleDesc"] = "Множитель урона в голову.";
lang["#BlockInventoryBindsDesc"] = "Заблокировать бинды инвентаря.";
lang["#LimbDamageScaleDesc"] = "Множитель урона в конечности.";
lang["#TargetIDDelayDesc"] = "Задержка перед выводом информации об энтити";
lang["#HeadbobEnabledDesc"] = "Использовать качание головы.";
lang["#ChatCommandPrefixDesc"] = "Префикс для чат комманд.";
lang["#CrouchWalkSpeedDesc"] = "Скорость ползка по умолчанию.";
lang["#MaximumChatLengthDesc"] = "Максимальное количество символов, разрешенное для написания в чат.";
lang["#StartingFlagsDesc"] = "Стартовые флаги по умолчанию.";
lang["#PlayerSprayDesc"] = "Могут ли игроки использовать спрей.";
lang["#HintIntervalDesc"] = "Промежуток времени между подсказками.";
lang["#OOCChatIntervalDesc"] = "Промежуток времени между сообщениями в чат OOC.";
lang["#MinuteTimeDesc"] = "Сколько длится минута на сервера (в секундах).";
lang["#DoorUnlockIntervalDesc"] = "Сколько секунд открывается дверь.";
lang["#VoiceChatEnabledDesc"] = "Использовать голосовой чат.";
lang["#LocalVoiceChatDesc"] = "Использовать локальный голосовой чат.";
lang["#TalkRadiusDesc"] = "Радиус разговора по умолчанию.";
lang["#GiveHandsDesc"] = "Давать ли кулаки игрокам по умолчанию.";
lang["#CustomWeaponColorDesc"] = "Использовать кастомизированные цвета вещей.";
lang["#GiveKeysDesc"] = "Давать ли ключи игрокам по умолчанию.";
lang["#WagesNameDesc"] = "Название зарплаты по умолчанию.";
lang["#JumpPowerDesc"] = "Высота прыжка по умолчанию.";
lang["#RespawnDelayDesc"] = "Длительность воскрешения игрока.";
lang["#MaximumWalkSpeedDesc"] = "Скорость ходьбы по умолчанию.";
lang["#MaximumRunSpeedDesc"] = "Скорость бега по умолчанию..";
lang["#DoorPriceDesc"] = "Стоимость двери по умолчанию.";
lang["#DoorLockIntervalDesc"] = "Сколько секунд закрывается дверь.";
lang["#MaximumOwnableDoorsDesc"] = "Максимальное количество дверей, которыми может владеть один игрок.";
lang["#EnableSpaceSystemDesc"] = "Использовать ли объемную систему инвентаря?.";
lang["#DrawIntroBarsDesc"] = "Использовать кинематографичные полоски при заходе в игру.";
lang["#EnableJoggingDesc"] = "Использовать быстрый бег.";
lang["#EnableLOOCIconsDesc"] = "Разрешить иконки в LOOC чате.";
lang["#ShowBusinessMenuDesc"] = "Включить бизнес меню.";
lang["#EnableChatMultiplierDesc"] = "Менять ли размер текста взависимости от использованной команды(крик, шепот).";
lang["#SteamAPIKeyDesc"] = "Некоторые функции могут требовать Steam API.\nhttp://steamcommunity.com/dev/apikey";
lang["#MapPropsPhysgrabDesc"] = "Разрешить игрокам манипулировать пропами карты, используя физган.";
lang["#EntityUseCooldownDesc"] = "Промежуток времени между использованием энтити.";
lang["#EnableSmoothSprintDesc"] = "Использование плавного перехода в бег.";
lang["#EnableQuickRaiseDesc"] = "Могут ли игроки быстро поднимать оружие.";
lang["#PlayersChangeThemesDesc"] = "Могут ли игроки самостоятельно менять тему схемы.";
lang["#DefaultThemeDesc"] = "Тема по умолчанию.";
lang["#EnableIronsightsDesc"] = "Могут ли игроки использовать прицел на оружии.";
lang["#IronsightsSpreadReductionDesc"] = "Насколько прицел уменьшит разброс от оружия.";
lang["#IronsightsSlowAmountDesc"] = "Насколько прицел уменьшит скорость игрока.";

-- Config Names
lang["#AttributeProgressionScale"] = "Attribute Progression Scale";
lang["#MessagesMustSeePlayer"] = "Messages Must See Player";
lang["#StartingAttributePoints"] = "Starting Attribute Points";
lang["#ClockworkIntroEnabled"] = "Clockwork Introduction Enabled";
lang["#HealthRegenerationEnabled"] = "Health Regeneration Enabled";
lang["#PropProtectionEnabled"] = "Prop Protection Enabled";
lang["#UseLocalMachineDate"] = "Use Local Machine Date";
lang["#UseLocalMachineTime"] = "Use Local Machine Time";
lang["#UseKeyOpensEntityMenus"] = "Use Key Opens Entity Menus";
lang["#ShootAfterRaiseDelay"] = "Shoot After Raise Delay";
lang["#UseClockworkAdminSystem"] = "Use Clockwork's Admin System";
lang["#SavedRecognisedNames"] = "Saved Recognised Names";
lang["#SaveAttributeBoosts"] = "Save Attribute Boosts";
lang["#RagdollDamageImmunityTime"] = "Ragdoll Damage Immunity Time";
lang["#AdditionalCharacterCount"] = "Additional Character Count";
lang["#ClassChangingInterval"] = "Class Changing Interval";
lang["#SprintingLowersWeapon"] = "Sprinting Lowers Weapon";
lang["#WeaponRaisingSystem"] = "Weapon Raising System Enabled";
lang["#PropKillProtection"] = "Prop Kill Protection Enabled";
lang["#SmoothServerRates"] = "Use Smooth Server Rates";
lang["#MediumServerRates"] = "Use Medium Performance Server Rates";
lang["#LagFreeServerRates"] = "Use Lag Free Server Rates";
lang["#GeneratorInterval"] = "Generator Interval";
lang["#GravityGunPunt"] = "Gravity Gun Punt Enabled";
lang["#DefaultInventoryWeight"] = "Default Inventory Weight";
lang["#DefaultInventorySpace"] = "Default Inventory Space";
lang["#DataSaveInterval"] = "Data Save Interval";
lang["#ViewPunchOnDamage"] = "View Punch On Damage";
lang["#UnrecognisedName"] = "Unrecognised Name";
lang["#LimbDamageSystem"] = "Limb Damage System Enabled";
lang["#FallDamageScale"] = "Fall Damage Scale";
lang["#StartingCurrency"] = "Starting Currency";
lang["#ArmorAffectsChest"] = "Armor Affects Chest Only";
lang["#MinimumPhysicalDescription"] = "Minimum Physical Description Length";
lang["#WoodBreaksFall"] = "Wood Breaks Fall";
lang["#VignetteEnabled"] = "Vignette Enabled";
lang["#HeartbeatSounds"] = "Heartbeat Sounds Enabled"; //Day 132. Still converting strings..
lang["#CrosshairEnabled"] = "Crosshair Enabled";
lang["#FreeAiming"] = "Free Aiming Enabled";
lang["#RecogniseSystem"] = "Recognise System Enabled";
lang["#CurrencyEnabled"] = "Currency Enabled";
lang["#DefaultPhysicalDescription"] = "Default Physical Description";
lang["#ChestDamageScale"] = "Chest Damage Scale";
lang["#CorpseDecayTime"] = "Corpse Decay Time";
lang["#BannedDisconnectMessage"] = "Banned Disconnect Message";
lang["#WagesInterval"] = "Wages Interval";
lang["#PropCostScale"] = "Prop Cost Scale";
lang["#FadeNPCCorpses"] = "Fade NPC Corpses";
lang["#CashWeight"] = "Cash Weight";
lang["#CashSpace"] = "Cash Space";
lang["#HeadDamageScale"] = "Head Damage Scale";
lang["#BlockInventoryBinds"] = "Block Inventory Binds";
lang["#LimbDamageScale"] = "Limb Damage Scale";
lang["#TargetIDDelay"] = "Target ID Delay";
lang["#HeadbobEnabled"] = "Headbob Enabled";
lang["#ChatCommandPrefix"] = "Chat Command Prefix";
lang["#CrouchWalkSpeed"] = "Crouch Walk Speed";
lang["#MaximumChatLength"] = "Maximum Chat Length";
lang["#StartingFlags"] = "Starting Flags";
lang["#PlayerSpray"] = "Player Spray Enabled";
lang["#HintInterval"] = "Hint Interval";
lang["#OOCChatInterval"] = "Out-Of-Character Chat Interval";
lang["#MinuteTime"] = "Minute Time";
lang["#DoorUnlockInterval"] = "Door Unlock Interval";
lang["#VoiceChatEnabled"] = "Voice Chat Enabled";
lang["#LocalVoiceChat"] = "Local Voice Chat";
lang["#TalkRadius"] = "Talk Radius";
lang["#GiveHands"] = "Give Hands";
lang["#CustomWeaponColor"] = "Custom Weapon Color";
lang["#GiveKeys"] = "Give Keys";
lang["#WagesName"] = "Wages Name";
lang["#JumpPower"] = "Jump Power";
lang["#RespawnDelay"] = "Respawn Delay"; // Send help...
lang["#MaximumWalkSpeed"] = "Maximum Walk Speed";
lang["#MaximumRunSpeed"] = "Maximum Run Speed";
lang["#DoorPrice"] = "Door Price";
lang["#DoorLockInterval"] = "Door Lock Interval";
lang["#MaximumOwnableDoors"] = "Maximum Ownable Doors";
lang["#EnableSpaceSystem"] = "Enable Space System";
lang["#DrawIntroBars"] = "Draw Intro Bars";
lang["#EnableJogging"] = "Enable Jogging";
lang["#EnableLOOCIcons"] = "Enable LOOC Icons";
lang["#ShowBusinessMenu"] = "Show Business Menu";
lang["#EnableChatMultiplier"] = "Enable Chat Multiplier";
lang["#SteamAPIKey"] = "Steam API Key";
lang["#MapPropsPhysgrab"] = "Enable Map Props Physgrab";
lang["#EntityUseCooldown"] = "Entity Use Cooldown";
lang["#EnableSmoothSprint"] = "Enable Smooth Sprint";
lang["#EnableQuickRaise"] = "Enable Quick Raise";
lang["#PlayersChangeThemes"] = "Players Change Themes";
lang["#DefaultTheme"] = "Default Theme";
lang["#EnableIronsights"] = "Enable Ironsights";
lang["#IronsightsSpreadReduction"] = "Ironsights Spread Reduction";
lang["#IronsightsSlowAmount"] = "Ironsights Slow Amount"; // omg finally i can sleep now

-- Days
lang["#Monday"] = "Поденельник";
lang["#Tuesday"] = "Вторник";
lang["#Wednesday"] = "Среда";
lang["#Thursday"] = "Четверг";
lang["#Friday"] = "Пятница";
lang["#Saturday"] = "Суббота";
lang["#Sunday"] = "Воскресенье";

-- Tab Menu Descriptions
lang["#BusinessDesc"] = "Покупайте предметы для вашего бизнеса.";
lang["#InventoryDesc"] = "Управление предметами в вашем инвентаре.";
lang["#DirectoryDesc"] = "Документация команд, а также различная информация.";
lang["#SystemDesc"] = "Доступ к различным настройкам сервера.";
lang["#ScoreboardDesc"] = "Список игроков на сервере.";
lang["#AttributesDesc"] = "Статус ваших аттрибутов.";
lang["#SettingsDesc"] = "Настройте то, как Clockwork работает у вас.";
lang["#ClassesDesc"] = "Выбор класса вашего персонажа.";
lang["#CharactersDesc"] = "Нажмите эту кнопку, чтобы перейти в меню выбора персонажей.";
lang["#CloseMenuDesc"] = "Нажмите эту кнопку, чтобы закрыть это меню.";

-- Tab Menu Names
lang["#Attributes"] = "Аттрибуты";
lang["#Attribute"] = "Аттрибут";
lang["#System"] = "Админка";
lang["#Settings"] = "Настройки";
lang["#Classes"] = "Классы";
lang["#Scoreboard"] = "Игроки";
lang["#Directory"] = "Помощь";
lang["#Inventory"] = "Инвентарь";
lang["#Business"] = "Бизнес";
lang["#Characters"] = "ПЕРСОНАЖИ";
lang["#CloseMenu"] = "ЗАКРЫТЬ";

-- MainMenu
lang["#MainMenu_New"] = "СОЗДАТЬ";
lang["#MainMenu_Load"] = "ЗАГРУЗИТЬ";
lang["#MainMenu_Leave"] = "ОТКЛЮЧИТЬСЯ";
lang["#MainMenu_DevelopedBy"] = "РАЗРАБОТЧИК: #1";

-- Quiz panel
lang["#QuizPanel_Continue"] = "ПРОДОЛЖИТЬ";
lang["#QuizPanel_Disconnect"] = "ОТКЛЮЧИТЬСЯ";
lang["#QuizPanel_Language"] = "Язык";
lang["#QuizPanel_Questions"] = "Вопросы";
lang["#QuizPanel_KickReason"] = "Вы ответили на один или несколько вопросов неправильно!";
lang["#QuizPanel_Warning"] = "Если вы дадите неверные ответы - вас может отключить с сервера.";

-- Character Creation
lang["#CharCreation_Previous"] = "НАЗАД";
lang["#CharCreation_Next"] = "ДАЛЕЕ";
lang["#CharCreation_Cancel"] = "ОТМЕНА";
lang["#CharCreation_CannotCreateMoreChars"] = "Вы не можете создать еще одного персонажа!";

-- Business Menu
lang["#BusinessMenu_NoAccess"] = "У вас нет доступа к #1 меню!";
lang["#BusinessMenu_Free"] = "Бесплатно";

-- Attributes Menu
lang["#AttributesMenu_NoAccess"] = "У вас нет доступа ни к каким аттрибутам!"; -- i assume #1 here is 'attributes'

-- Classes Menu
lang["#ClassesMenu_NoStay"] = "Выбранные вами классы не будут прикреплены к вашему персонажу.";
lang["#ClassesMenu_NoAccess"] = "У вас нет доступа ни к каким классам!";
lang["#ClassesMenu_CurrentPlayers"] = "В данном классе #1 из #2 персонажей.";

-- Scoreboard
lang["#Scoreboard_Tip"] = "Нажатие на модельку игрока открывает меню действий.";

-- Donations Menu
lang["#DonationsMenu_Title"] = "Пожертвования";
lang["#DonationsMenu_SomeSubsExpire"] = "Некоторые подписки истекают и их необходимо будет продлить.";
lang["#DonationsMenu_NoActiveSubs"] = "У вас нет ни одной активной подписки!";
lang["#DonationsMenu_NoExpire"] = "Эта подписка не истекает.";
lang["#DonationsMenu_Expired"] = "Эта подписка истекла!";
lang["#DonationsMenu_ExpiresIn"] = "Подписка истекает через #1 секунд.";

-- Command syntax highlighter.
lang["#CMDDesc_Aliases"] = "Другие написания:";
lang["#CMDDesc_Usage"] = "Синтаксис:";

-- F1 Menu
lang["#InfoMenu_Title"] = "ИНФОРМАЦИЯ О ПЕРСОНАЖЕ";
lang["#InfoMenu_SelectOption"] = "БЫСТРЫЕ ДЕЙСТВИЯ";

-- Command Descriptions,
lang["#Commands_RollDesc"] = "Выдает случайное число между 0 и вашим числом.";
lang["#Commands_MeDesc"] = "Описывает ваше действие в третьем лице.";
lang["#Commands_YDesc"] = "Крик персонажам вокруг вас.";
lang["#Commands_WDesc"] = "Шепот персонажам вокруг вас.";
lang["#Commands_PMDesc"] = "Написать приватное сообщение.";
lang["#Commands_RDesc"] = "Отправить радиосообщение.";
lang["#Commands_FDesc"] = "Упасть на землю.";

-- Chat suffixes and prefixes.
lang["#Suffix_Whisper"] = "шепчет:";
lang["#Suffix_Yell"] = "кричит:";

-- Typing display.
lang["#TD_Yelling"] = "Кричит...";
lang["#TD_Whispering"] = "Шепчет...";
lang["#TD_Typing"] = "Печатает...";
lang["#TD_Talking"] = "Говорит...";
lang["#TD_Radioing"] = "Говорит по рации...";
lang["#TD_Performing"] = "Выполняет действие...";

-- Misc Terms
lang["#Destroy"] = "Уничтожить";
lang["#Cash"] = "Деньги";
lang["#Drop"] = "Выбросить";
lang["#Use"] = "Использовать";

lang["#Bars_Health"] = "ЗДОРОВЬЕ";
lang["#Bars_Armor"] = "БРОНЯ";
lang["#Bars_Stamina"] = "ВЫНОСЛИВОСТЬ";
lang["#Bars_Hunger"] = "ГОЛОД";
lang["#Bars_Thirst"] = "ЖАЖДА";