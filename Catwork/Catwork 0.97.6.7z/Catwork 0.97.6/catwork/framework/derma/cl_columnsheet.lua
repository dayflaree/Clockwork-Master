--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local PANEL = {};

-- A function to add a new sheet.
function PANEL:AddSheet(label, panel, material)
	if (!IsValid(panel)) then
		return;
	end;

	local newSheet = {};

	if (self.ButtonOnly) then
		newSheet.Button = vgui.Create("DImageButton", self.Navigation);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 1, 0, 0);
	else
		newSheet.Button = vgui.Create("cwIconButton", self.Navigation);

		local size = CW.fonts:GetSize(CW.option:GetFont("menu_text_tiny"), 20);

		newSheet.Button:SetTall(32);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 0, 0, 8);
		newSheet.Button:SetFont(size);

		function newSheet.Button:Paint(width, height)
			cdraw.DrawBox(0, 0, width, height, Color(255, 255, 255, 150));
		end;
	end;

	newSheet.Button:SetImage(material);
	newSheet.Button.Target = panel;
	newSheet.Button:SetText(label);
	newSheet.Button.DoClick = function()
		self:SetActiveButton(newSheet.Button)
	end;

	newSheet.Panel = panel;
	newSheet.Panel:SetParent(self.Content);
	newSheet.Panel:SetVisible(false);

	if (self.ButtonOnly) then
		newSheet.Button:SizeToContents();
	end;

	newSheet.Button:SetColor(CW.option:GetColor("columnsheet_text_normal"));
	newSheet.Button:SetExpensiveShadow(1, CW.option:GetColor("columnsheet_shadow_normal"));

	table.insert(self.Items, newSheet)

	if (!IsValid(self.ActiveButton)) then
		self:SetActiveButton(newSheet.Button);
	end;
end;

-- A function to set the active button.
function PANEL:SetActiveButton(active)
	if (self.ActiveButton == active) then
		return;
	end;

	if (self.ActiveButton && self.ActiveButton.Target) then	
		self.ActiveButton.Target:SetVisible(false)
		self.ActiveButton:SetSelected(false)
		self.ActiveButton:SetColor(CW.option:GetColor("columnsheet_text_normal"));
		self.ActiveButton:SetExpensiveShadow(1, CW.option:GetColor("columnsheet_shadow_normal"));
	end

	self.ActiveButton = active;

	active.Target:SetVisible(true);
	active:SetSelected(true);
	active:SetColor(CW.option:GetColor("columnsheet_text_active"));
	active:SetExpensiveShadow(1, CW.option:GetColor("columnsheet_shadow_active"));

	self.Content:InvalidateLayout();
end

vgui.Register("cwColumnSheet", PANEL, "DColumnSheet");