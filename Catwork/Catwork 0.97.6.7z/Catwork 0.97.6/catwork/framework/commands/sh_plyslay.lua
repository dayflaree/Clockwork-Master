--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlySlay");

COMMAND.tip = "Slay another player.";
COMMAND.text = "<string Target> <bool isSilent>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"Slay", "Kill", "PlyKill"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local isSilent = CW.kernel:ToBool(arguments[2]);

	if (target) then
		target:Kill();

		if (!isSilent) then
			CW.player:Notify(target:Name().." was slain by "..player:Name()..".");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid target!");
	end;
end;

COMMAND:Register();
