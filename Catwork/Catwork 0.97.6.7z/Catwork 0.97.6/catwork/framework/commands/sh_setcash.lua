--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("Set"..string.gsub(NAME_CASH, "%s", ""));
COMMAND.tip = "Set a character's "..string.lower(NAME_CASH)..".";
COMMAND.text = "<string Name> <number "..string.gsub(NAME_CASH, "%s", "")..">";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])
	local cash = math.floor(tonumber((arguments[2] or 0)));

	if (target) then
		if (cash and cash >= 1) then
			local playerName = player:Name();
			local targetName = target:Name();
			local giveCash = cash - target:GetCash();
			local cashName = string.gsub(NAME_CASH, "%s", "");

			CW.player:GiveCash(target, giveCash);

			CW.player:Notify(player, L("CashSetPlayer", targetName, cashName, CW.kernel:FormatCash(cash, nil, true)));
			CW.player:Notify(target, L("CashSetTarget", cashName, CW.kernel:FormatCash(cash, nil, true), playerName));
		else
			CW.player:Notify(player, L("NotValidAmount"));
		end;
	else
		CW.player:Notify(player, L("NotValidPlayer", arguments[1]));
	end;
end;

COMMAND:Register();