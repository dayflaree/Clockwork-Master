--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlySetGroup");
COMMAND.tip = "Set a player's user group.";
COMMAND.text = "<string Name> <string UserGroup>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.alias = {"SetGroup"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local userGroup = arguments[2];

	if (userGroup != "superadmin" and userGroup != "admin"
	and userGroup != "operator") then
		CW.player:Notify(player, "The user group must be superadmin, admin or operator!");

		return;
	end;

	if (target) then
		if (!CW.player:IsProtected(target)) then
			CW.player:NotifyAll(player:Name().." has set "..target:Name().."'s user group to "..userGroup..".");
				target:SetClockworkUserGroup(userGroup);
			CW.player:LightSpawn(target, true, true);
		else
			CW.player:Notify(player, target:Name().." is protected!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();