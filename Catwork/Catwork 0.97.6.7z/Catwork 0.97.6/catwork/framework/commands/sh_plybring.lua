--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyBring");

COMMAND.tip = "Bring a player to your crosshair position.";
COMMAND.text = "<string Target> <bool isSilent>";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"Bring"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local trace = player:GetEyeTraceNoCursor();
	local isSilent = CW.kernel:ToBool(arguments[2]);

	if (target) then
		CW.player:SetSafePosition(target, trace.HitPos);

		if (!isSilent) then
			CW.player:NotifyAll(player:Name().." has brought "..target:Name().." to their target location.");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();