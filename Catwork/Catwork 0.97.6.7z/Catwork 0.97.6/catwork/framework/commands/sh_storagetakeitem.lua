--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("StorageTakeItem");
COMMAND.tip = "Take an item from storage.";
COMMAND.text = "<string uniqueID> <string ItemID>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local storageTable = player:GetStorageTable();
	local uniqueID = arguments[1];
	local itemID = tonumber(arguments[2]);

	if (storageTable and (!storageTable.entity or IsValid(storageTable.entity))) then
		local itemTable = CW.inventory:FindItemByID(
			storageTable.inventory, uniqueID, itemID
		);

		if (!itemTable) then
			CW.player:Notify(player, L("StorageNoInstance"));
			return;
		end;

		CW.storage:TakeFrom(player, itemTable);
	else
		CW.player:Notify(player, L("StorageNotOpen"));
	end;
end;

COMMAND:Register();