--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyUnwhitelist");
COMMAND.tip = "Remove a player from a whitelist.";
COMMAND.text = "<string Name> <string Faction>";
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.alias = {"UnWhitelist", "DeWhitelist"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if (target) then
		local factionTable = CW.faction:FindByID(table.concat(arguments, " ", 2));

		if (factionTable) then
			if (factionTable.whitelist) then
				if (CW.player:IsWhitelisted(target, factionTable.name)) then
					CW.player:SetWhitelisted(target, factionTable.name, false);
					CW.player:SaveCharacter(target);

					CW.player:NotifyAll(player:Name().." has removed "..target:Name().." from the "..factionTable.name.." whitelist.");
				else
					CW.player:Notify(player, target:Name().." is not on the "..factionTable.name.." whitelist!");
				end;
			else
				CW.player:Notify(player, factionTable.name.." does not have a whitelist!");
			end;
		else
			CW.player:Notify(player, factionTable.name.." is not a valid faction!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();