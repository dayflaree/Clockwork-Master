--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Me");
COMMAND.tip = "#Commands_MeDesc";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;
COMMAND.alias = {"Perform"};
COMMAND.cooldown = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = "";

	for k, v in ipairs(arguments) do
		text = text..v.." ";
	end;

	if (text == "") then
		CW.player:Notify(player, L(player, "NotEnoughText"));

		return;
	end;

	text = player:Name().." "..text;

	chatbox.AddText(nil, text, {position = player:GetPos(), textColor = Color("#89D235"), filter = "player_events", icon = false});
end;

COMMAND:Register();