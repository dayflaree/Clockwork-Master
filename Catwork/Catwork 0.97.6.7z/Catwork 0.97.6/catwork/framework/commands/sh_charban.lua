--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharBan");
COMMAND.tip = "Ban a character from being used.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(table.concat(arguments, " "));

	if (target) then
		if (!CW.player:IsProtected(target)) then
			CW.player:SetBanned(target, true);
			CW.player:NotifyAll(player:Name().." banned the character '"..target:Name().."'.");

			target:KillSilent();
		else
			CW.player:Notify(player, target:Name().." is protected!");
		end;
	else
		CW.player:Notify(player, L(player, "NotValidCharacter", arguments[1]));
	end;
end;

COMMAND:Register();