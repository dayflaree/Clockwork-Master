--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.kernel:IncludePrefixed("shared.lua")

-- Called when the target ID HUD should be painted.
function ENT:HUDPaintTargetID(x, y, alpha)
	if (plugin.Call("SalesmanTargetID", self, x, y, alpha)) then
		local colorTargetID = CW.option:GetColor("target_id");
		local colorWhite = CW.option:GetColor("white");
		local physDesc = self:GetNetworkedString("PhysDesc");
		local name = self:GetNetworkedString("Name");

		y = CW.kernel:DrawInfo(name, x, y, colorTargetID, alpha);

		if (physDesc != "") then
			y = CW.kernel:DrawInfo(physDesc, x, y, colorWhite, alpha);
		end;
	end;
end;

-- Called when the entity initializes.
function ENT:Initialize()
	self.AutomaticFrameAdvance = true;
end;

-- Called every frame.
function ENT:Think()
	self:FrameAdvance(FrameTime());
	self:NextThink(CurTime());
end;