--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Just do the fucking restart after delay --]]
if ( table.Count( player.GetAll() ) == 0 or nil ) then
    RunConsoleCommand("bot")
else
    RunConsoleCommand("kick", "bot")
end

timer.Create( "RestartTheServerDaily", 86000, 1, function()
    local content = " Restarted on " ..tostring(os.date("%T")).. " |"
	local map = game.GetMap().. ".bsp"
	
    if file.Exists("restarts.txt", "DATA") then
	    file.Append("restarts.txt", content)
	else
	    file.Write("restarts.txt", content)
	end
	
	RunConsoleCommand("changelevel", map)
end)