--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
	This file initializes Event Framework's booting process.
	Do not remove this file, otherwise the framework will not load.
--]]

--[[ Include Alex Grist's Net Wrapper and Penguin's Object Notation --]]
AddCSLuaFile("external/pon.lua");
AddCSLuaFile("external/netstream.lua");
include("external/netstream.lua");
include("external/pon.lua");

--[[ Include Events Framework Loader --]]
AddCSLuaFile("eframework/sh_loader.lua")
include("eframework/sh_loader.lua")

if (SERVER) then
	include("eframework/sv_loader.lua");
end;