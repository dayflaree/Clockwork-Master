--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
    This is a Framework loader. This is used to activate the needed network strings for menu and chat.
    Never remove this file, otherwise the Framework will not work!
--]]

util.AddNetworkString("efPrintMessage")
util.AddNetworkString("efToggleMenu")
util.AddNetworkString("efRunString")