--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Events Library ]]--
Events.boot:DevMessage("[Events Framework] Events library loaded", SERVER)

-- A function to Launch Event.
function Events.Launch(ply, args)
	if not gamemode.Get( "terrortown" ) then
		for k, v in pairs( player.GetAll() ) do
			v:efAddToPlayer( "TTT Events can only be launched while in gamemode \"terrortown\"!", "red" )
		end
		return
	end
	
	local amount = Events.framework:Count("events", true)
    local chance = math.random(1, amount)  --  Random selection of event
	Events.Launched = 1
	
	local event_id = tonumber( args[1] ) or Events.default_event_id or 0  --  We set the event number that'll be run to the number of event admin want to run, or 0 to do it randomly.
	local num_delay = tonumber( args[2] ) or Events.default_delay or 20  --  We set the delay to the number admin entered or to 20
	local silent = tonumber( args[3] ) or Events.default_silent or 0  --  If admin wants to run an event silently - then let's do it!
	local event_string = ""
	local devprint = ""
	
	--[[ Event Selection System ]]--
	if ( event_id == 0 ) then 
        if ( chance != 0 ) then
	        event_string = "Events.doEvent" ..tostring(chance).. "()"
	        devprint = "Selected Event " ..chance.. "."
	    else
	        event_string = "Events.doEvent1()"
		    devprint = "Something went wrong! But selected event 1."   -- If chance system is somehow broken - select event 1!
	    end
	elseif (event_id != 0 and event_id < amount + 1) then
	    event_string = "Events.doEvent" ..tostring(event_id).. "()"
	    devprint = "Manually Selected Event " ..event_id.. "."
	else
	    event_string = "Events.doEvent1()"
	    devprint = "Invalid Event Number! Selected Event 1"
		if ply then
			ply:efAddToPlayer( L.invalidnum, "blue" )
		end
	end
	
	Events.boot:DevMessage( "[Events Framework] " .. devprint, SERVER )
	
	-- We want to launch the event after a little delay.
    timer.Simple( num_delay, function()
		RunString( event_string )
	end )
	
	-- Let people know that there's an event going!
	if ( silent != 1 ) then
		for k,v in pairs(player.GetAll()) do
			v:efAddToPlayer( L.adminlaunched .. num_delay .. L.seconds .. "!", "blue" )
			timer.Simple( 0.001, function()
				v:efAddToPlayer( "And remember that you'll be rewarded if you win the event!", "blue" )
			end )
		end
	end
end

-- A function to Stop Event.
function Events.Stop(ply)
	if not gamemode.Get( "terrortown" ) then
		for k, v in pairs( player.GetAll() ) do
			v:efAddToPlayer( "TTT Events can only be stopped while in gamemode \"terrortown\"!", "red" )
		end
		return
	end
	
    if ( Events.Launched == 1 ) then
		Events.Launched = 0
   	    RunConsoleCommand("sv_gravity", "600")
		timer.Destroy( "EventsZombieKingLive" )
	
		function WEPS.DropNotifiedWeapon(ply, wep, death_drop)
			ply:DropWeapon(wep)
		end
	
  		for k, v in pairs( player.GetAll() ) do
			v:SetHealth( 100 )
			v:SetRole(ROLE_INNOCENT)
			SendFullStateUpdate()
		end
			
  		hook.Remove( "PlayerCanPickupWeapon", "EventsCanPickupWeapons" )
		hook.Remove( "TTTEndRound", "EventsGiveRewards" )
		
		for k, v in pairs(player.GetAll()) do
			v:efAddToPlayer( L.eventstopped, "blue" )
		end
	else
		ply:efAddToPlayer( L.noeventsrunning, "blue" )
	end
end