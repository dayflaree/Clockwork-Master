--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Functions Library ]]--
Events.boot:DevMessage("[Events Framework] Functions library loaded", SERVER)

-- A function to check for win.
function Events.funcs:CheckForWin()
    if GAMEMODE.MapWin == WIN_TRAITOR or GAMEMODE.MapWin == WIN_INNOCENT then
        local mw = GAMEMODE.MapWin
        GAMEMODE.MapWin = WIN_NONE
        return mw
    end

    local traitor_alive = false
    local innocent_alive = false
    for k,v in pairs(player.GetAll()) do
        if v:Alive() and v:IsTerror() then
            if v:GetTraitor() then
            traitor_alive = true
        else
            innocent_alive = true
        end
    end

    if traitor_alive and innocent_alive then
        return WIN_NONE
    end

    if traitor_alive and not innocent_alive then
        return WIN_TRAITOR
    elseif not traitor_alive and innocent_alive then
        return WIN_INNOCENT
    elseif not innocent_alive then
      -- ultimately if no one is alive, traitors win
        return WIN_TRAITOR
    end

    return WIN_NONE
end
end

-- A function to kill Zombie King.
function Events.funcs:KillZombieKing()
	if Events.event4_launched == 1 then
        if traitor_alive and not innocent_alive then
			for k, v in pairs( player.GetAll() ) do
				v:efAddToPlayer( L.zombiekilledall, "blue" )
			end
    	else
			for k, v in pairs( player.GetAll() ) do
				v:efAddToPlayer( L.zombiedied, "blue" )
			end
			
	        for i=1, uid do
	    	    local v = chosen
	    		v:Kill()
	    	end
	    end
	end
end

-- A hook to clear events data after new round.
hook.Add("TTTEndRound", "EventsClearData", function()
    val = false
	Events.Launched = 0
    RunConsoleCommand("sv_gravity", "600")
	timer.Destroy( "EventsZombieKingLive" )
	
	function WEPS.DropNotifiedWeapon(ply, wep, death_drop)
	    ply:DropWeapon(wep)
	end
	
    for k, v in pairs( player.GetAll() ) do
	    v:SetHealth( 100 )
	end

    hook.Remove( "PlayerCanPickupWeapon", "EventsCanPickupWeapons" )
end)

-- A hook to clear events data after new round.
hook.Add("TTTPrepareRound", "EventsClearData", function()
    hook.Remove( "TTTEndRound", "EventsGiveRewards" )
end)