--[[
	(C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Chatbox Library ]]--
Events.boot:DevMessage("[Events Framework] Chat library loaded", CLIENT)

-- Prints a colored message to players.
function Events.chat:PrintToPlayer( text, color )
	if color == "red" then
		color = Color( 255, 51, 51, 255 )
	elseif color == "green" then
		color = Color( 51, 255, 51, 255 )
	elseif color == "blue" then
		color = Color( 51, 51, 255, 255 )
	elseif color == "white" then
		color = Color( 255, 255, 255, 255 )
	else
		color = Color( 51, 51, 51, 255 )
	end
	
	if istable( players ) then
		for k, v in pairs( players ) do
			chat.AddText( color, text, v )
		end
	else
		chat.AddText( color, text, players )
	end
end

netstream.Hook("efPrintMessage", function(data)
	text = data.text;
	color = data.color;
	Events.chat:PrintToPlayer(text, color);
end);
