--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Language Library ]]--
Events.boot:DevMessage("[Events Framework] Language library loaded", SERVER)

-- A function to check if language exists.
function Events.language:Exists(lang)
    if file.Exists( "lua/eframework/lang/" ..lang.. ".lua", "GAME" ) then
	    return true
	else
	    return false
	end
end

-- A function to include the default language file.
function Events.framework:GetDefaultLang()
    if Events.language:Exists(Events.defaultlang) then
        include( "eframework/lang/" ..Events.defaultlang.. ".lua")
        Events.boot:DevMessage("[Events Framework] Included " ..Events.defaultlang.." language file...", SERVER)
	else
	    include( "eframework/lang/english.lua")
        Events.boot:DevMessage("[Events Framework] Something went wrong. Included English language...", SERVER)
    end
end