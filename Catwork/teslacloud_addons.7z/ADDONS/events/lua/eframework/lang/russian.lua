--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Russian Language File ]]--
Events.lang = Events.lang or {}
local Events = Events
L = L or {}

L.invalidnum        = "Введен неверный номер Ивента! Выбран Ивент 1!"
L.adminlaunched     = "Админ запустил Ивент, начало через "
L.seconds           = " секунд"
L.nopermission      = "У вас нет прав на использование этой команды!"
L.yourambo          = "Вы - Рэмбо! Убейте всех!"
L.youwarrior        = "Вы - воин! Убейте Рэмбо!"
L.winnoone          = "Ивент окончен! Никто не победил!"
L.winrambo          = "Ивент окончен! Рэмбо победил!"
L.winwarrior        = "Ивент окончен! Воины победили!"
L.pleasenotedrop    = "Заметьте, что вы не сможете подбирать или бросать оружие до конца Ивента!"
L.yousheriff        = "Вы - Шериф! Убейте бандитов!"
L.youbandit         = "Вы Бандит! Убейте Шерифа!"
L.winbandit         = "Ивент окончен! Бандиты победили и получили награду!"
L.winsheriff        = "Ивент окончен! Шериф победил и получил награду!"
L.youspacemarine    = "Вы Космодесантник! Убейте пришельцев!"
L.youalien          = "YВы пришелец! Убейте Космодесантника!"
L.winspace          = "Ивент окончен! Космодесантник победил!"
L.winalien          = "Ивент окончен! Пришельцы победили!"
L.youzombie         = "Вы король зомби! У Вас есть 2.5 минуты чтобы управлять своей армией пока вы не умрете!"
L.yousurvivor       = "Вы попали в Уомби-апокалипсис! Выживайте!"
L.zombiekilledall   = "Король Зомби всех убил!"
L.zombiedied        = "Король Зомби умер, потому что кто-то остался вживых!"
L.winsurvivors      = "Ивент окончен! Выжившие победили и получили награду!"
L.winzombie         = "Ивент окончен! Король зомби победил и получил награду!"
L.youhacker         = "Ты труъ Хацкер! Завали всех нубов!"
L.youplayer         = "Ты честный игрок! Завали читераста!"
L.winhacker         = "Ивент окончен! Хацкер выиграл (Читар драный)!"
L.winplayers        = "Ивент окончен! Честные игроки победили (и правильно)!"