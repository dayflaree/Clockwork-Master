--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

local PANEL = {}
local ChangePhraseDelay = 10 -- Delay in seconds
local ChangePhrase = math.Round( os.clock(), 1 ) + ChangePhraseDelay -- Calculate first time changing the phrase
local RandomPhrase = "by TeslaCloud Studios" -- Random phrase initialisation with default one

local function GetRandomPhrase()
	local phrases = {
		one = "by TeslaCloud Studios",
		two = "Some Sort of Admin CP...",
		three = "WUT DOES DAT MENU DO?",
		four = "Sexy!",
		five = "It's Alive!",
		six = "I can't count, lol.",
		seven = "THERE'S A BUG!!!111ONEONEONE",
		eight = "Made in Russia.",
		nine = "y u no die??!",
		ten = "loves you.",
		eleven = "Why have you ever opened this menu?",
		twelve = "DAT IS RANDOM PHRASE LOL",
		thirteen = "Powered by candies.",
		fourteen = "PUPPIES!!!111",
		fifteen = "There was supposed to be clever thing, but nope.",
		sixteen = "Really?"
	}
	local chance = math.random(1, 16)
	
	if math.Round( os.clock(), 6 ) > ChangePhrase then
		if (chance == 1) then
			RandomPhrase = phrases.one
		elseif (chance == 2) then
			RandomPhrase = phrases.two
		elseif (chance == 3) then
			RandomPhrase = phrases.three
		elseif (chance == 4) then
			RandomPhrase = phrases.four
		elseif (chance == 5) then
			RandomPhrase = phrases.five
		elseif (chance == 6) then
			RandomPhrase = phrases.six
		elseif (chance == 7) then
			RandomPhrase = phrases.seven
		elseif (chance == 8) then
			RandomPhrase = phrases.eight
		elseif (chance == 9) then
			RandomPhrase = phrases.nine
		elseif (chance == 10) then
			RandomPhrase = phrases.ten
		elseif (chance == 11) then
			RandomPhrase = phrases.eleven
		elseif (chance == 12) then
			RandomPhrase = phrases.twelve
		elseif (chance == 13) then
			RandomPhrase = phrases.thirteen
		elseif (chance == 14) then
			RandomPhrase = phrases.fourteen
		elseif (chance == 15) then
			RandomPhrase = phrases.fifteen
		elseif (chance == 16) then
			RandomPhrase = phrases.sixteen
		end
	
		ChangePhrase = math.Round(os.clock(), 1) + ChangePhraseDelay
	end
	
	return RandomPhrase
end

function PANEL:Init()
	local scrW = ScrW()
	local scrH = ScrH()
	local panelW = scrW * 0.7
	local panelH = scrH * 0.7
	local panelX = scrW / 2 - panelW / 2
	local panelY = scrH / 2 - panelH / 2
	
	self:SetPos(panelX, panelY)
	self:SetSize(panelW, panelH)
	self:SetDrawOnTop(false)
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)
	
	-- The white "CLOSE" button to close the menu
	self.closeMenuLabel = vgui.Create( "efButton", self )
	self.closeMenuLabel:SetFont( "Trebuchet24" )
	self.closeMenuLabel:SetText( "CLOSE" )
	self.closeMenuLabel:SetToolTip( "Click here to close the menu." )
	self.closeMenuLabel:SetSize( scrW / 20, scrH / 34 )
	self.closeMenuLabel:SetPos( panelW - self.closeMenuLabel:GetWide() - 10, panelH - self.closeMenuLabel:GetTall() - 10 )
	self.closeMenuLabel:OverrideTextColor( Color(255, 0, 0) )
	self.closeMenuLabel:SetMouseInputEnabled( true )
	self.closeMenuLabel:SetCallback(function()
		Events.derma:ToggleMenu()
	end)
	
	-- The big green "Launch Random Event" button
    self.launchRandomButton = vgui.Create( "efMenuButton", self, "launchRandom" )
	self.launchRandomButton:SetText( "Launch Random Event" )
	self.launchRandomButton:SetSize( scrW / 11, scrH / 16 )
	self.launchRandomButton:SetPos( panelW - self.launchRandomButton:GetWide() - 10, 10 )
	self.launchRandomButton:SetButton( true )
	self.launchRandomButton:SetInfoColor( "green" )
	self.launchRandomButton:SetCallback(function()
		netstream.Start("efRunString", "Events.Launch(nil, {0, 20, 0})");
		Events.derma:ToggleMenu()
	end)
	
	-- The big red "Stop Running Event" button
    self.stopRunningButton = vgui.Create( "efMenuButton", self, "stopRunning" )
	self.stopRunningButton:SetText( "Stop Running Event" )
	self.stopRunningButton:SetSize( scrW / 11, scrH / 16 )
	self.stopRunningButton:SetPos( panelW - self.stopRunningButton:GetWide() - 10,  10 + self.launchRandomButton:GetTall() + 2 )
	self.stopRunningButton:SetButton( true )
	self.stopRunningButton:SetInfoColor( "red" )
	self.stopRunningButton:SetCallback(function()
		netstream.Start("efRunString", "Events.Stop(nil)");
		Events.derma:ToggleMenu()
	end)
end

function PANEL:Paint()
	Derma_DrawBackgroundBlur(self)
	
	draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(0, 195, 255, 200))
	
	draw.SimpleText("Events Framework", "Trebuchet24", 10, 10, color_white)
	draw.SimpleText(GetRandomPhrase(), "Trebuchet24", 10, 30, color_white)
end

vgui.Register("efFrameworkMenu", PANEL, "EditablePanel")