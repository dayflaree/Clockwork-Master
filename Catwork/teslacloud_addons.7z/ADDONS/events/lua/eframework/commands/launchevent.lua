--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

local Events = Events

--[[ LaunchEvent ]]--
local dev = Events.devmode or 0  --  Set this to 0 after beta test and to 1 if there are any errors.
local L = Events.lang

------------------------------ LaunchEvent ------------------------------
concommand.Add( "launchevent", function( num_delay, event_id, silent )
    if LocalPlayer():IsSuperAdmin() then
        local chance = math.random(1, 4)  --  Random selection of event
	    Events.launched = 1
	
	    num_delay = num_delay or Events.default_delay or 10  --  We set the delay to the number admin entered or to 10
	    event_id = event_id or Events.default_event_id or 0  --  We set the event number that'll be run to the number of event admin want to run, or 0 to do it randomly.
	    silent = silent or Events.default_silent or 0  --  If admin want to run an event silently - then let's do it!
	
	    --[[ Event Selection System ]]--
	    if ( event_id == 0 ) then 
            if (chance == 1) then
	            event = Events.doEvent1
	        	devprint = "Selected Event 1"
            elseif (chance == 2) then
	            event = Events.doEvent2
	        	devprint = "Selected Event 2"
            elseif (chance == 3) then
	            event = Events.doEvent3
		        devprint = "Selected Event 3"
            elseif (chance == 4) then
	            event = Events.doEvent4
		        devprint = "Selected Event 4"
	        else
	            event = Events.doEvent1
		        devprint = "Something went wrong! But selected event 1"   -- If chance system is somehow broken - select event 1!
	        end
	    elseif (event_id == 1) then
	        event = Events.doEvent1
	        devprint = "Manually Selected Event 1"
	    elseif (event_id == 2) then
	        event = Events.doEvent2
	        devprint = "Manually Selected Event 2"
    	elseif (event_id == 3) then
	        event = Events.doEvent3
	        devprint = "Manually Selected Event 3"
	    elseif (event_id == 4) then
	        event = Events.doEvent4
	        devprint = "Manually Selected Event 4"
	    else
	        event = Events.doEvent1
	        devprint = "Invalid Event Number! Selected Event 1"
	        LocalPlayer( ):PrintMessage( HUD_PRINTTALK, L.invalidnum )
	    end
	
	    --[[ Developer Console Log ]]--
	    if (dev == 1) then
	        print( "(DEBUG): "..devprint.."!" )
	    else
	        return false
	    end
	
	    -- We want to launch the event after a little delay.
        timer.Create( "EventsFrameworkLaunchTimer", num_delay, 1, event )

	    -- Let people know that there's an event going!
	    if ( silent == 0 ) then
	        player.GetAll():PrintMessage( HUD_PRINTTALK, L.adminlaunched .. num_delay.. " seconds!" )
	        player.GetAll():PrintMessage( HUD_PRINTTALK, "And remember that you'll be rewarded if you win the event!" )
	    else
	        -- If admin want so, let's run the event without notifying players!
	        LocalPlayer():PrintMessage( HUD_PRINTTALK, L.adminlaunched.. "" ..num_delay.. "" ..L.seconds.. "!" )
	    end
	else
	    LocalPlayer():PrintMessage( HUD_PRINTTALK, L.nopermission )
		return false
	end
end )