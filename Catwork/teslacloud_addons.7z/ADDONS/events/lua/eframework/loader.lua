--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]
local Events = Events

--[[ Include Shared Framework Loader and a configs file]]--
include("loader_shared.lua")
include("config.lua")

if Events.devmode == 1 then
    print("[Events System] Booting process initialized...")
end