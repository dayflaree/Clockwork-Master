--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Default Functions Library ]]--
local Events = Events
local L = Events.lang

-- A function to do Event Number Three.
function Events.doEvent3()
    local amountply = table.Count( player.GetAll() )
    local randomply = math.random(1, #player.GetAll())
    local chosen = player.GetAll()[randomply]
	local uid = chosen:UserID()
	local allply = player.GetAll()
	local val = false
	Events.event3_launched = 1
	
	player.GetAll():PrintMessage( HUD_PRINTTALK, L.pleasenotedrop )
	function WEPS.DropNotifiedWeapon(ply, wep, death_drop)
	    if IsValid(ply) then return false end
	end
	
	RunConsoleCommand("sv_gravity", Events.event3_gravity)
	for i=1, uid do
		local v = chosen
		v:StripWeapons()
		v:SetRole(ROLE_TRAITOR)
	    v:SetCredits(Events.event_credits)
		v:SetHealth( amountply * 125 )
		v:Give(Events.event1_weapon)
		v:SetModel( "models/player/leet.mdl" )
	    SendFullStateUpdate()
	    while val != true do
            v:PrintMessage( HUD_PRINTTALK, L.youspacemarine )
			val = true
		end
	end
	
    for k, v in pairs(allply) do
		if v != chosen then
		    v:StripWeapons()
		    v:SetRole(ROLE_DETECTIVE)
	        v:SetCredits(Events.event_credits)
		    v:Give(Events.event3_weapon_b)
	        SendFullStateUpdate()
	        while val != true do
		        v:PrintMessage( HUD_PRINTTALK, L.youalien )
			    val = true
			end
		end
	end
	
    hook.Add( "PlayerCanPickupWeapon", "EventsCanPickupWeapons", function( ply, wep )
	    return false
    end )
	
	-- A hook to give a reward for winner!
	if Events.event3_launched == 1 then
		hook.Add("TTTEndRound", "EventsGiveRewards", function()
	 	    given = 0
	 	    if ( Events.launched == 1 ) then
	    	    if ( GetRoundState() == ROUND_ACTIVE ) then
			        if ( Events.funcs:CheckForWin() == WIN_TRAITOR ) then
					    if given == 0 then
		 		   	        player.GetAll():PrintMessage( HUD_PRINTTALK, L.winspace )
				            if given == 0 then
		    		            for i=1, uid do
								    given = 1
		    	                    local v = chosen
		    			            v:PS_GivePoints(Events.event3_reward)
		   		 	    	    end
							end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_INNOCENT ) then
					    if given == 0 then
		    		        player.GetAll():PrintMessage( HUD_PRINTTALK, L.winalien )
				
		    	 	        for k, v in pairs(allply) do
		          	            if v != chosen then
								    given = 1
		    			            v:PS_GivePoints(Events.event3_reward)
		    		   		 	end
		    		  	    end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_NONE ) then
			    	    player.GetAll():PrintMessage( HUD_PRINTTALK, L.winnoone )
		    		end
		  	    end
			end
		end)
	end
end