--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Default Functions Library ]]--
local Events = Events
local L = Events.lang

-- A function to do Event Number One.
function Events.doEvent1()
    local amountply = table.Count( player.GetAll() )
    local randomply = math.random(1, #player.GetAll())
    local chosen = player.GetAll()[randomply]
	local uid = chosen:UserID()
	local allply = player.GetAll()
	local val = false
	Events.event1_launched = 1
	
	for i=1, uid do
		local v = chosen
		v:StripWeapons()
		v:SetRole(ROLE_DETECTIVE)
	    v:SetCredits(Events.event_credits)
        v:SetHealth( amountply * 100 )
		v:Give(Events.event1_weapon )
	    SendFullStateUpdate()
	    while val != true do
            v:PrintMessage( HUD_PRINTTALK, L.yourambo )
			val = true
		end
	end
	
    for k, v in pairs(allply) do
		if v != chosen then
		    v:SetRole(ROLE_TRAITOR)
	        v:SetCredits(Events.event_credits)
	        SendFullStateUpdate()
	        while val != true do
		        v:PrintMessage( HUD_PRINTTALK, L.youwarrior )
				val = true
			end
		end
	end
	
	-- A hook to give a reward for winner!
	if Events.event1_launched == 1 then
		hook.Add("TTTEndRound", "EventsGiveRewards", function()
	 	    given = 0
	 	    if ( Events.launched == 1 ) then
	    	    if ( GetRoundState() == ROUND_ACTIVE ) then
			        if ( Events.funcs:CheckForWin() == WIN_INNOCENT ) then
					    if given == 0 then
		 		   	        player.GetAll():PrintMessage( HUD_PRINTTALK, L.winrambo )
				            if given == 0 then
		    		            for i=1, uid do
								    given = 1
		    	                    local v = chosen
		    			            v:PS_GivePoints(Events.event1_reward)
		   		 	    	    end
							end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_TRAITOR ) then
					    if given == 0 then
		    		        player.GetAll():PrintMessage( HUD_PRINTTALK, L.winwarrior )
				
		    	 	        for k, v in pairs(allply) do
		          	            if v != chosen then
								    given = 1
		    			            v:PS_GivePoints(Events.event1_reward)
		    		   		 	end
		    		  	    end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_NONE ) then
			    	    player.GetAll():PrintMessage( HUD_PRINTTALK, L.winnoone )
		    		end
		  	    end
			end
		end)
	end
end