--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Configs file :D ]]--

-- Framework Config
Events.defaultlang       = "english" -- Default language to use. Available languages: "english", "russian", "german".
Events.devmode           = 1  --  Print developer notes in console.

Events.disallowpickup    = 1 -- Whether or not disallow picking up weapons while events are on.

Events.randomevents      = 1 -- Whether or not do events randomly.
Events.randomchance      = 8 -- Chance of random event to happen (in %) (default 8%)

-- Events Commands Config
Events.MenuChatCmds      = { "!eventsmenu", "/eventsmenu" }
Events.MenuConCmds       = { "eventsmenu" }

Events.LaunchChatCmds    = { "!launchevent", "/launchevent" }
Events.LaunchConCmds     = { "launchevent" }

Events.StopChatCmds      = { "!stopevent", "/stopevent" }
Events.StopConCmds       = { "stopevent" }

-- Events Config
Events.default_delay     = 10  --  Default delay before the event starts.
Events.default_event_id  = 0  --  Default Event ID to select. Set to 0 if you want it to be random.
Events.default_silent    = 0  --  Set this to 0 if you WANT to notify players about the event.

--Events Credits
Events.event2_credits    = 7  --  How many credits do we give to Sheriff in Event 2?
Events.event2_credits_b  = 0  --  How many credits do we give to Bandits in Event 2?
Events.event_credits     = 5  --  Default amount of credits to give to the player when he becomes detective/traitor on event.

-- Events Rewards
Events.event1_reward     = 500  --  How much points to give when someone wins Event 1?
Events.event2_reward     = 300  --  How much points to give when someone wins Event 2?
Events.event3_reward     = 350  --  How much points to give when someone wins Event 3?
Events.event4_reward     = 400  --  How much points to give when someone wins Event 4?
Events.event5_reward     = 400  --  How much points to give when someone wins Event 5?

-- Events Weapons
Events.event1_weapon     = "weapon_events_stungun" --  Weapon that we give to Rambo in Event 1.
Events.event2_weapon     = "weapon_events_m4"  --  Weapon that we give to sheriff in Event 2.
Events.event2_weapon_b   = "weapon_events_pistol"  --  Weapon that we give to hostile bandits in Event 2.
Events.event3_weapon     = "weapon_events_stungun" --  Weapon that we give to good player in Event 3.
Events.event3_weapon_b   = "weapon_events_surv_m4" --  Weapon that we give to hostiles in Event 3.
Events.event4_weapon     = "weapon_events_zombspawn" --  Weapon that we give to a Zombie King in Event 4.
Events.event4_weapon_b   = "weapon_events_surv_m4" --  Weapon that we give to survivors in Event 4.
Events.event5_weapon     = "weapon_events_hack_m4" --  Weapon that we give to Hack3r in Event 5.
Events.event5_weapon_b   = "weapon_events_stungun" --  Weapon that we give to Player in Event 5.

-- Misc. Events Config
Events.event3_gravity    = 300 -- Value of gravity in Event 3. (default gravity is 600)
Events.event4_z_timer    = 150 -- How many seconds to give to Zombie King before he dies?

--[[There are no Easter eggs]]--