Thank you for buying my Event Framework Add-on! I hope you enjoy it!

Hello everyone! This is my very first script that I sell here. I really hope you like it!

Quick guide:

--------------
This addon no longer requires ULX to function! POINTSHOP IS OPTIONAL, BUT USED TO GIVE REWARDS.
--------------

This one adds Events GUI to the server admins.
It picks a random event from, yet, 5 events. 
This makes events fair and fun. 
Because usually admins who make events, pick themselves as a main hero of event and it's usually not fun because they cheat, and this command solves the problem.

Features list:

- Randomized and not randomized events, your choice.
- Rewards for completing events.
- Ability to launch the event silently.
- Configs, to let you decide how the script will run.
- Comfortable Filesystem to let you modify the script however you want.
- Easy-to-Use GUI, so, just click what you want to do!
- But if you're not comfortable with GUI - there are commands too!

Event list:
ID 1:

ONE CHOSEN PLAYER BECOMES RAMBO AND HIS MISSION IS TO KILL EVERYONE. 
HE WILL RECEIVE LOTS OF HEALTH AND A POWERFUL GUN. 
EVERYBODY ELSE BECOMES TRAITORS AND THEIR MISSION IS TO KILL RAMBO.

ID 2:

THERE IS ONLY ONE DETECTIVE WITH LOTS OF HEALTH. 
OTHERS ARE TRAITORS. 
DETECTIVE RECEIVES M16, AND SOME HP AND ARMOR. 
TRAITORS RECEIVE PISTOL.

ID 3:

ONE PLAYER BECOMES A SPACE MARINE WITH A LOT OF HEALTH, OTHERS ARE ALIENS. 
THE SPACE MARINE RECEIVES A STUN GUN, OTHERS GET M4. 
GRAVITY IS SET TO 1/2.

ID 4:

ONE PLAYER BECOMES A ZOMBIE KING AND RECEIVES THE ABILITY TO SPAWN ZOMBIES. 
OTHERS ARE SURVIVORS. 
THE ZOMBIE KING IS GODDED, BUT HE WILL DIE IF HE DOESN'T KILL EVERYONE IN 2.5 MINUTES. 
THE SURVIVORS TASK IS SIMPLER: SURVIVE.

ID 5:

One Player becomes a H4ck3 and his mission to kill everyone else, using HAX (speedhack and H4ck3d M4).
Everyone else are honest players with ANTI-HAX weapon, that kill H4ck3r by 3 hits.
Hacker has 75 Health, and honest player's gun deals 25 damage per shot.

Installation:
JUST DROP THE FOLDER FROM ARCHIVE TO ADDONS FOLDER.

To Do List:

- ADD BADASS WAY TO OPEN THE DOORS BY SHOOTING THE LOCK.
- MORE EVENTS!
- EVEN MORE EVENTS!

MORE EVENTS ARE COMING SOON!

POST YOUR OWN EVENTS IDEAS IN COMMENTS!

CREDITS:

TheGarry =D - Lead Coder, Lead Designer, Ideas, Testing.
lordtobi909 - Coding, Testing.
GoldWolf (Scal) - Author of the Idea.
Phil, the cat - Inspiration.

Special Thanks:

- Wolf, for a NPC spawner gun.

IF YOU NEED ANY SUPPORT:
	FEEL FREE TO ADD TheGarry ON STEAM: http://steamcommunity.com/id/TheGarry
	OR TO ADD lordtobi909 ON STEAM: http://steamcommunity.com/id/lordtobi909