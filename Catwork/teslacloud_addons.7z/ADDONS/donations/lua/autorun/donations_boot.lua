--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
	This file initializes Event Framework's booting process.
	Do not remove this file, otherwise the framework will not load.
--]]

--[[ Include Alex Grist's Net Wrapper and Penguin's Object Notation --]]
AddCSLuaFile("external/pon.lua");
AddCSLuaFile("external/netstream.lua");
include("external/netstream.lua");
include("external/pon.lua");

--[[ Include Needed Files --]]
local startTime = os.clock();
local curGamemode = string.lower(GetConVarString("gamemode"));
local cwGamemode = string.Left(curGamemode, 2);

print("[TGC Donations API] Booting process initialized...");

if (cwGamemode == "cw") then
	include("tgcdonate/sv_clockwork.lua");
	
	printGM = "Clockwork";
else
	include("tgcdonate/sv_ulx.lua");
	
	printGM = "ULX";
end;

print("[TGC Donations API] Loaded donation API in "..math.Round(os.clock() - startTime, 3).. " second(s) for "..printGM..".")