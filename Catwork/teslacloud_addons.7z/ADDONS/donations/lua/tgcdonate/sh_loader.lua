--[[
    (C) 2014 TeslaCloud Studios LLC
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
    This is a Shared Framework loader. In this file boot functions are stored.
	This file also contains all the Framework's globals.
    Never remove this file, otherwise the Framework will not work!
--]]

--[[ Shared Loader ]]--

TGC = TGC or {}
