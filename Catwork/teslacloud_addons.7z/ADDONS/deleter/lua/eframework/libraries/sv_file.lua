--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
	
	This library is based on Alex Grist's fileio module.
	This library also allows us to manipulate any file on the server.
--]]

--[[ File Library ]]--
Events.boot:DevMessage("[Events Framework] File library loaded", SERVER)

-- A function to read a file.
function Events.file:Read(filePath)
	return fileio.Read(filePath)
end

-- A function to write a file.
function Events.file:Write(filePath, fileData)
	return fileio.Write(filePath, fileData)
end

-- A function to delete a file.
function Events.file:Delete(filePath)
	return fileio.Delete(filePath)
end

-- A function to make directory.
function Events.file:MakeDirectory(directory)
	return fileio.MakeDirectory(directory)
end

-- A function to append a file.
function Events.file:Append(filePath, fileData)
	return fileio.Append(filePath, fileData)
end

-- A function to check if file exists.
function Events.file:Exists(filePath)
	return file.Exists(filePath, "GAME")
end