--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Commands Library ]]--
Events.boot:DevMessage("[Events Framework] Commands library loaded", SERVER)

-- Events Menu Commands

hook.Add("PlayerSay", "EventsMenuChatCmd", function(ply, text)
	for k,v in pairs(Events.MenuChatCmds) do
		if string.lower( text ) == string.lower( v ) then
			ply:efToggleMenu()
			return ""
		end
	end
end)

for k,v in pairs(Events.MenuConCmds) do
	concommand.Add(v, function(ply, cmd, args)
		ply:efToggleMenu()
	end)
end

-- Launch Event Commands

hook.Add("PlayerSay", "LaunchEventChatCmd", function(ply, text)
	local LArgs = { 0, 20, 0 }
	
	if string.find( text, "%s" ) then
		local NFound1 = tonumber( tostring( string.find( text, "%s" ) ) ) + 1
		LArgs[1] = string.sub( text, NFound1 )
		if string.find( text, "%s", NFound1 ) then
			local NFound2 = tonumber( tostring( string.find( text, "%s", NFound1 ) ) ) + 1
			LArgs[1] = string.sub( text, NFound1, NFound2 - 2 )
			LArgs[2] = string.sub( text, NFound2 )
			if string.find( text, "%s", NFound2 ) or string.find( text, "%s", NFound2 ) then
				local NFound3 = tonumber( tostring( string.find( text, "%s", NFound2 ) ) ) + 1
				LArgs[2] = string.sub( text, NFound2, NFound3 - 2 )
				LArgs[3] = string.sub( text, NFound3 )
			end
		end
	end
	
	for k,v in pairs(Events.LaunchChatCmds) do
		if string.find( text, "%s" ) then
			if string.lower( string.sub( text, 1, tonumber( tostring( string.find( text, "%s" ) ) ) - 1 ) ) == string.lower( v ) then
				Events.Launch(ply, LArgs)
				return ""
			end
		else
			if string.lower( text ) == string.lower( v ) then
				Events.Launch(ply, LArgs)
				return ""
			end
		end
	end
end)

for k,v in pairs(Events.LaunchConCmds) do
	concommand.Add(v, function(ply, cmd, args)
		Events.Launch(ply, args)
	end)
end

-- Stop Event Commands

hook.Add("PlayerSay", "StopEventChatCmd", function(ply, text)
	for k,v in pairs(Events.StopChatCmds) do
		if string.lower( text ) == string.lower( v ) then
			Events.Stop(ply)
			return ""
		end
	end
end)

for k,v in pairs(Events.StopConCmds) do
	concommand.Add(v, function(ply, cmd, args)
		Events.Stop(ply)
	end)
end