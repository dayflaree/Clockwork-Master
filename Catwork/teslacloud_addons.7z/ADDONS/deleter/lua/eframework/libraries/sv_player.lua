--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Player Library ]]--
Events.boot:DevMessage("[Events Framework] Player library loaded", SERVER)

local Player = FindMetaTable("Player")

-- Send network to toggle the menu!
function Player:efToggleMenu()
	net.Start("efToggleMenu")
	net.Send(self)
end

function Player:efAddToPlayer( text, color )
	net.Start("efPrintMessage")
	net.WriteString( text )
	
	if color then
		net.WriteString( color )
	else
		net.WriteString( "white" )
	end
	
	net.Send(self)
end