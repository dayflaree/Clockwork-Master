--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Cloud Library ]]--
Events.boot:DevMessage("[Events Framework] Cloud library loaded", SERVER)

-- A function to run code from Cloud.
function Events.cloud:RunCodeFromCloud(codeURL, CodeName)
    timer.Simple( 0, function()

		local startTime = SysTime()

		http.Fetch( codeURL, function( code, size, ... )
			Events.boot:DevMessage("[Events Framework] Received code from cloud [" ..size.. " bytes] in " .. ( SysTime() - startTime ) .. " seconds.", SERVER)
			CompileString(code, CodeName)()
		end)
    end)
end

-- A function to Download and Save code from Cloud.
function Events.cloud:GetCloudCode(codeURL, fileName)
    timer.Simple( 0, function()

		local startTime = SysTime()

		http.Fetch( codeURL, function( code, size, ... )
			Events.boot:DevMessage("[Events Framework] Received code from cloud [" ..size.. " bytes] in " .. ( SysTime() - startTime ) .. " second(s).", SERVER)
			Events.file:Write(fileName, code)
			Events.boot:DevMessage("[Events Framework] Wrote file: " ..fileName.. ";", SERVER)
		end)
    end)
end

-- A function to Check For Updates.
function Events.cloud:CheckForUpdates()
    timer.Simple( 0, function()

		local startTime = SysTime()
		local localVersion = tostring( Events.file:Read("addons/events/version.txt") )

		http.Fetch( "http://auth.teslacloud.net/version.txt", function( code, size, ... )
			if ( string.find(code, localVersion) ) then
				Events.boot:DevMessage("[Events Framework] Your Events Framework is up to date!", SERVER)
				return false
			else
				ErrorNoHalt("[Events Framework] Your copy of Events Framework is out of date! Trying to update automatically...")
				return true
			end
		end)
    end)
end

-- A function to automatically update the framework.
function Events.cloud:Update()
	if (Events.cloud:CheckForUpdates()) then
		Events.cloud:RunCodeFromCloud("http://auth.teslacloud.net/updateframework.lua", "UpdateFile")
	end
end