--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Config Library ]]--
Events.boot:DevMessage("[Events Framework] Config library loaded", SERVER)

-- A function to check for a default config file.
function Events.config:CheckDefaultConfig()
	if Events.file:Exists("lua/eframework/sh_config.lua.default") then
		return true
	else
		ErrorNoHalt("[Events Framework] Default configs file doesn't exists! Have you deleted the sh_config.lua.default file?")
		return false
	end
end

-- A function to reset config to default.
function Events.config:ResetToDefault()
	if Events.config:CheckDefaultConfig() then
		local prevData = Events.file:Read("lua/eframework/sh_config.lua")
		local defaultData = Events.file:Read("lua/eframework/sh_config.lua.default")
		
		-- We're smart enough to make a backup of config file for the case of emergency.
		Events.file:Write("lua/eframework/sh_config.lua.backup", prevData)
		
		-- And after a delay - get rid of that shit.
		timer.Simple( 3, function()
			Events.file:Write("lua/eframework/sh_config.lua", defaultData)
		end )
	end
end