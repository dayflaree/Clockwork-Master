--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Derma Library ]]--
Events.boot:DevMessage("[Events Framework] Derma library loaded", CLIENT)

Events.menu = nil

-- A function to toggle the Framework Menu.
function Events.derma:ToggleMenu()
	if not Events.menu then
		Events.menu = vgui.Create("efFrameworkMenu")
		Events.menu:SetVisible(false)
	end
	
	if Events.menu:IsVisible() then
		Events.menu:Hide()
		gui.EnableScreenClicker(false)
	else
		Events.menu:Show()
		gui.EnableScreenClicker(true)
	end
end

net.Receive("efToggleMenu", function( len, ply )	
	Events.derma:ToggleMenu()
end)