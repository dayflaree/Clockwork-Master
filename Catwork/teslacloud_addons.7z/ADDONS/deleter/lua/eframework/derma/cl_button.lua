--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

local PANEL = {}

-- A function to set whether the panel is disabled.
function PANEL:SetDisabled(disabled)
	self.Disabled = disabled
end

-- A function to get whether the panel is disabled.
function PANEL:GetDisabled()
	return self.Disabled
end

-- A function to set whether the panel is depressed.
function PANEL:SetDepressed(depressed)
	self.Depressed = depressed
end

-- A function to get whether the panel is depressed.
function PANEL:GetDepressed()
	return self.Depressed
end

-- A function to set whether the panel is hovered.
function PANEL:SetHovered(hovered)
	self.Hovered = hovered
end

-- A function to get whether the panel is hovered.
function PANEL:GetHovered()
	return self.Hovered
end

-- Called when the cursor has entered the panel.
function PANEL:OnCursorEntered()
	if (!self:GetDisabled()) then
		self:SetHovered(true)
	end
	
	DLabel.ApplySchemeSettings(self)
end

-- Called when the cursor has exited the panel.
function PANEL:OnCursorExited()
	self:SetHovered(false)
	DLabel.ApplySchemeSettings(self)
end

-- Called when the mouse is pressed.
function PANEL:OnMousePressed(code)
	self:MouseCapture(true)
	self:SetDepressed(true)
end

-- Called when the mouse is released.
function PANEL:OnMouseReleased(code)
	self:MouseCapture(false)
	
	if (!self:GetDepressed()) then
		return
	end
	
	self:SetDepressed(false)
	
	if (!self:GetHovered()) then
		return
	end
	
	if (code == MOUSE_LEFT and self.DoClick and !self:GetDisabled()) then
		self.DoClick(self)
	end
end

-- A function to override the text color.
function PANEL:OverrideTextColor(color)
	if (color) then
		self.OverrideColorNormal = color
		self.OverrideColorHover = Color(math.max(color.r - 50, 0), math.max(color.g - 50, 0), math.max(color.b - 50, 0), color.a)
	else
		self.OverrideColorNormal = nil
		self.OverrideColorHover = nil
	end
end

function PANEL:Paint(w, h) end

-- Called every frame.
function PANEL:Think()
	if (self.animation) then
		self.animation:Run()
	end
	
	local colorWhite = Color(255, 255, 255)
	local colorDisabled = Color(
		math.max(colorWhite.r - 50, 0),
		math.max(colorWhite.g - 50, 0),
		math.max(colorWhite.b - 50, 0),
		255
	)
	
	if (self:GetDisabled()) then
		self:SetTextColor(colorDisabled)
	else
		self:SetTextColor(colorWhite)
	end
end

-- A function to set the panel's Callback.
function PANEL:SetCallback(Callback)
	self.DoClick = function(button)
		Callback(button)
	end
end

vgui.Register("efButton", PANEL, "DButton")