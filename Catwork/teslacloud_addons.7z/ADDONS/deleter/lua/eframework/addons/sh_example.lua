--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Example Events Framework Addon --]]
local Events = Events

Events.boot:DevMessage("[Events Framework] Example add-on loaded", SERVER)
