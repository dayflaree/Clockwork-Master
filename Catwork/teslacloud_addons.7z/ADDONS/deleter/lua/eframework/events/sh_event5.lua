--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Default Functions Library ]]--
local Events = Events
local L = Events.lang

Events.boot:DevMessage("[Events Framework] Event 5 Loaded", SERVER)

-- A function to do Event Number Five.
function Events.doEvent5()
    local amountply = table.Count( player.GetAll() )
    local randomply = math.random(1, #player.GetAll())
    local chosen = player.GetAll()[randomply]
	local uid = chosen:UserID()
	local allply = player.GetAll()
	local val = false
	Events.event5_launched = 1
	
	for k, v in pairs( allply ) do
		v:efAddToPlayer( L.pleasenotedrop, "green" )
	end
	
	function WEPS.DropNotifiedWeapon(ply, wep, death_drop)
	    if IsValid(ply) then return false end
	end
	
	for i=1, uid do
		local v = chosen
		v:StripWeapons()
		v:SetRole(ROLE_TRAITOR)
		v:SetHealth( 75 )
		v:Give(Events.event5_weapon)
		v:SetModel( "models/player/leet.mdl" )
	    SendFullStateUpdate()
	    while val != true do
            v:efAddToPlayer( L.youhacker, "blue" )
			val = true
		end
	end
	
    for k, v in pairs(allply) do
		if v != chosen then
		    v:StripWeapons()
		    v:SetRole(ROLE_INNOCENT)
		    v:Give(Events.event5_weapon_b)
	        SendFullStateUpdate()
	        while val != true do
		        v:efAddToPlayer( L.youplayer, "blue" )
			    val = true
			end
		end
	end
	
	if ( Events.disallowpickup == 1 ) then
		hook.Add( "PlayerCanPickupWeapon", "EventsCanPickupWeapons", function( ply, wep )
			return false
		end)
	end
	
	-- A hook to give a reward for winner!
	if Events.event5_launched == 1 then
		hook.Add("TTTEndRound", "EventsGiveRewards", function()
	 	    given = 0
	 	    if ( Events.Launched == 1 ) then
	    	    if ( GetRoundState() == ROUND_ACTIVE ) then
			        if ( Events.funcs:CheckForWin() == WIN_TRAITOR ) then
					    if given == 0 then
		 		   	        for k, v in pairs( allply ) do
								v:efAddToPlayer( L.winhacker, "blue" )
							end
							
				            if given == 0 then
		    		            for i=1, uid do
								    given = 1
		    	                    local v = chosen
		    			            v:PS_GivePoints(Events.event5_reward)
		   		 	    	    end
							end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_INNOCENT ) then
					    if given == 0 then
							for k, v in pairs( allply ) do
								v:efAddToPlayer( L.winplayers, "blue" )
							end
				
		    	 	        for k, v in pairs(allply) do
		          	            if v != chosen then
								    given = 1
		    			            v:PS_GivePoints(Events.event5_reward)
		    		   		 	end
		    		  	    end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_NONE ) then
						for k, v in pairs( allply ) do
							v:efAddToPlayer( L.winnoone, "red" )
						end
		    		end
		  	    end
			end
		end)
	end
end