--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Default Functions Library ]]--
local Events = Events
local L = Events.lang

Events.boot:DevMessage("[Events Framework] Event 1 Loaded", SERVER)

-- A function to do Event Number One.
function Events.doEvent1()	
    local amountply = table.Count( player.GetAll() )
    local randomply = math.random(1, #player.GetAll())
    local chosen = player.GetAll()[randomply]
	local uid = chosen:UserID()
	local allply = player.GetAll()
	local val = false
	Events.event1_launched = 1
	
	for i=1, uid do
		local v = chosen
		v:StripWeapons()
		v:SetRole(ROLE_DETECTIVE)
	    v:SetCredits(Events.event_credits)
        v:SetHealth( amountply * 100 )
		v:Give(Events.event1_weapon )
	    SendFullStateUpdate()
	    while val != true do
            v:efAddToPlayer( L.yourambo, "blue" )
			val = true
		end
	end
	
    for k, v in pairs(allply) do
		if v != chosen then
		    v:SetRole(ROLE_TRAITOR)
	        v:SetCredits(Events.event_credits)
	        SendFullStateUpdate()
	        while val != true do
		        v:efAddToPlayer( L.youwarrior, "blue" )
				val = true
			end
		end
	end
	
	-- A hook to give a reward for winner!
	if Events.event1_launched == 1 then
		hook.Add("TTTEndRound", "EventsGiveRewards", function()
			given = 0
	 	    if ( Events.Launched == 1 ) then
	    	    if ( GetRoundState() == ROUND_ACTIVE ) then
			        if ( Events.funcs:CheckForWin() == WIN_INNOCENT ) then
					    if given == 0 then
							for k, v in pairs(allply) do
								v:efAddToPlayer( L.winrambo, "blue" )
							end
							given = 1
		    			    chosen:PS_GivePoints(Events.event1_reward)
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_TRAITOR ) then
					    if given == 0 then
		    	 	        for k, v in pairs(allply) do
								v:efAddToPlayer( L.winwarrior, "blue" )
		          	            if v != chosen then
								    given = 1
		    			            v:PS_GivePoints(Events.event1_reward)
		    		   		 	end
		    		  	    end
						end
		    		elseif ( Events.funcs:CheckForWin() == WIN_NONE ) then
						for k, v in pairs(allply) do
							v:efAddToPlayer( L.winnoone, "red" )
						end
		    		end
		  	    end
			end
		end)
	end
end