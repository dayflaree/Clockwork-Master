--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

local Events = Events

--[[ Configs file :D ]]--
Events.defaultlang              = "english" -- Default language to use.
Events.devmode           = 1  --  Print developer notes in console.

Events.default_delay     = 10  --  Default delay before the event starts.
Events.default_event_id  = 0  --  Default Event ID to select. Set to 0 if you want it to be random.
Events.default_silent    = 0  --  Set this to 0 if you WANT to notify players about the event.
Events.event_credits     = 5  --  Default amount of credits to give to the player when he becomes detective/traitor on event.
Events.event1_reward     = 500  --  How much points to give when someone wins Event 1? Rewards are coming soon...
Events.event2_reward     = 300  --  How much points to give when someone wins Event 2? Rewards are coming soon...
Events.event3_reward     = 350  --  How much points to give when someone wins Event 3? Rewards are coming soon...
Events.event4_reward     = 400  --  How much points to give when someone wins Event 4? Rewards are coming soon...
Events.event1_weapon     = "weapon_ttt_stungun" --  Weapon that we give to Rambo in Event 1.
Events.event2_weapon     = "weapon_ttt_m16"  --  Weapon that we give to sheriff in Event 2.
Events.event2_weapon_b   = "weapon_zm_pistol"  --  Weapon that we give to hostile bandits in Event 2.
Events.event3_weapon     = "weapon_ttt_stungun" --  Weapon that we give to good player in Event 3.
Events.event3_weapon_b   = "weapon_ttt_m16" --  Weapon that we give to hostiles in Event 3.
Events.event3_gravity    = 300 -- Value of gravity in Event 3. (default gravity is 600)
Events.event4_weapon     = "weapon_tg_zombiespawner" --  Weapon that we give to a Zombie King in Event 4.
Events.event4_weapon_b   = "weapon_ttt_m16" --  Weapon that we give to survivors in Event 4.
Events.event4_z_timer    = 150 -- How many seconds to give to Zombie King before he dies?
Events.event2_credits    = 7  --  How many credits do we give to Sheriff in Event 2?
Events.event2_credits_b  = 0  --  How many credits do we give to Bandits in Event 2?

--[[There is no easter eggs]]--