--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ English Language File ]]--
Events.lang = Events.lang or {}
local Events = Events
L = L or {}

L.invalidnum        = "Invalid number selected! Selected Event 1!"
L.noeventsrunning   = "Event is not running! Nothing to stop!"
L.eventstopped      = "Event was stopped! Round ended!"
L.adminlaunched     = "Admin Launched the Event! Starting in "
L.seconds           = " seconds"
L.nopermission      = "You have no permission to use this command!"
L.yourambo          = "You are The Rambo! Kill everybody!"
L.youwarrior        = "You are a Warrior! Kill Rambo!"
L.winnoone          = "Event is over! No one wins!"
L.winrambo          = "Event is over! Rambo wins!"
L.winwarrior        = "Event is over! Warriors won and got the reward!"
L.pleasenotedrop    = "Please note, that you won't be able to drop or pick up weapons until this round ends!"
L.yousheriff        = "You are The Sheriff! Kill all Bandits!"
L.youbandit         = "You are a Bandit! Kill The Sheriff!"
L.winbandit         = "Event is over! Bandits won and got the reward!"
L.winsheriff        = "Event is over! Sheriff won and got the reward!"
L.youspacemarine    = "You are The Space Marine. Kill everyone!"
L.youalien          = "You are alien. Kill The Space Marine!"
L.winspace          = "Event is over! The Space Marine wins and gets the reward!"
L.winalien          = "Event is over! Aliens won and got the reward!"
L.youzombie         = "You are a Zombie King! Rule your undead army! You have got 2.5 minutes before you die!"
L.yousurvivor       = "You are in a Zombie Apocalypse! Survive!"
L.unablezombie      = "Unable to spawn a zombie there! Aim at the ground!"
L.zombiekilledall   = "Zombie king killed everyone!"
L.zombiedied        = "Zombie king died because some survivors didn't die!"
L.winsurvivors      = "Event is over! Survivors won and got the reward!"
L.winzombie         = "Event is over! The Zombie King wins and gets the reward!"
L.youhacker         = "You are The H4ck3r! Kill all N00bs!"
L.youplayer         = "You are a Good Player. Kill the one who uses HAX!"
L.winhacker         = "Event is over! H4ck3r won (dammit cheater)!"
L.winplayers        = "Event is over! Honest players won (and this feels just right)!"