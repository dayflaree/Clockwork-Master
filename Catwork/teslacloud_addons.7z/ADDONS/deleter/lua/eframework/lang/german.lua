--[[
	(C) 2014 TeslaCloud Studios Ltd. & lordtobi909
	The code is made by lordtobi909
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author
--]]

--[[ German Language File by lordtobi909 ]]--
Events.lang = Events.lang or {}
local Events = Events
L = L or {}

L.invalidnum		= "Ungültige Nummer gewählt! Event 1 wurde gewählt!"
L.adminlaunched		= "Ein Admin startete ein Event! Beginn in "
L.seconds			= " Sekunden"
L.nopermission		= "Du hast keine Brechtigung um diesen Befehl zu nutzen!"
L.yourambo			= "Du bist Rambo! Töte jeden!"
L.youwarrior		= "Du bist ein Krieger! Töte Rambo!"
L.winnoone			= "Event ist vorbei! Niemand gewinnt!"
L.winrambo			= "Event ist vorbei! Rambo gewinnt!"
L.winwarrior		= "Event ist vorbei! Die Krieger gewinnen und bekommen eine Belohnung!"
L.pleasenotedrop	= "Bitte beachte, dass es dir nicht möglich ist Waffen abzuwerfen oder aufzunehmen bis das Event vorbei ist!"
L.yousheriff		= "Du bist der Sheriff! Töte alle Banditen!"
L.youbandit			= "Du bist ein Bandit! Töte den Sheriff!"
L.winbandit			= "Event ist vorbei! Die Banditen gewinnen und bekommen eine Belohnung!"
L.winsheriff		= "Event ist vorbei! Sheriff gewinnt und bekommt eine Belohnung!"
L.youspacemarine	= "Du bist der Space Marine! Töte alle Außerirdische!"
L.youalien			= "Du bist ein Außerirdischer! Töten den Space Marine!"
L.winspace			= "Event ist vorbei! Der Space Marine gewinnt und bekommt eine Belohnung!"
L.winalien			= "Event ist vorbei! Die Außerirdischen gewinnen und bekommen eine Belohnung!"
L.youzombie			= "Du bist der Zombiekönig! Herrsche über deine Untotenarmee! Du hast 2,5 Minuten bevor du stribst!"
L.yousurvivor		= "Du bist in einer Zombie-Apokalypse! Überlebe!"
L.zombiekilledall	= "Der Zombiekönig töte jeden!"
L.zombiedied		= "Der Zombiekönig starb, weil ein paar Menschen überlebten!"
L.winsurvivors		= "Event ist vorbei! Die Menschen gewinnen und bekommen eine Belohnung!"
L.winzombie			= "Event ist vorbei! Der Zombiekönig gewinnt und bekommt eine Belohnung!"
L.youhacker         = "Du bist der H4ck3r! Töte alle N00bs!"
L.youplayer         = "Du bist ein guter Spieler! Töte den, der HAX benutzt!"
L.winhacker         = "Event ist zuende! Der H4ck3r gewinnt (drecks Cheater)!"
L.winplayers        = "Event ist zuende! Die ehrlichen Spieler gewinnen (und es fühlt sich gut an)!"