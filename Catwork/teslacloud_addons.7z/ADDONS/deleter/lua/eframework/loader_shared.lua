--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Default Functions Library ]]--
local Events = Events

Events = Events or {}
Events.boot = Events.boot or {}
Events.framework = Events.framework or {}

--A Function to get Libraries Storage Folder.
function Events.boot:GetLibrariesFolder(libFolderName)
	if (libFolderName) then
		return (string.gsub(Events.LibrariesFolder, "lua/", "").."/eframework/"..libFolderName)
	else
		return (string.gsub(Events.LibrariesFolder, "lua/eframework/libraries", ""))
	end;
end;

--A function to get Framework Folder
function Events.boot:GetFrameworkFolder()
	return (string.gsub(Events.FrameworkFolder, "lua/", ""))
end

-- A function to get Framework Path
function Events.boot:GetFrameworkPath()
	return (string.gsub(Events.FrameworkFolder, "lua/", "").."/eframework")
end


-- A function to include all libraries.
function Events.boot:iLibrary()
    local files = file.Find( "eframework/libraries/*", "LUA" )
	
	include(files)
end

-- A function to include all commands.
function Events.boot:iCommand()
    local files = file.Find( "eframework/commands/*", "LUA" )
	
	include(files)
end

-- A function to include all Framework Addons.
function Events.boot:iCommand()
    local files = file.Find( "eframework/addons/*", "LUA" )
	
	include(files)
end

-- A function to include all events.
function Events.boot:iEvent()
    local files = file.Find( "eframework/events/*", "LUA" )
	
	include(files)
end

-- A function to check if Library Exists and print it.
function Events.boot:CheckLibExists(libName)
    local files = file.Find( "eframework/libraries/" ..libName, "LUA" )
	
	if file.Exists( files, "LUA" ) then
	    print("Library " ..libName.. " does exists in your Libraries Directory!")
		return true
	else
	    print("Library " ..libName.. " is not found in your Libraries Directory!")
		return false
	end
end

-- A function to check if Library Exists.
function Events.boot:LibExists(libName)
    local files = file.Find( "eframework/libraries/" ..libName.. ".lua", "LUA" )
	
	if file.Exists( files, "LUA" ) then
	    return true
	else
	    return false
	end
end

if Events.devmode == 1 then
    print("[Events System] Shared booting complete!")
end