--[[
    (C) 2014 TeslaCloud Studios Ltd. & Wolf
	The code is made by Wolf
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author
--]]

--[[ Default Functions Library ]]--
local Events = Events
local L = Events.lang

if SERVER then
AddCSLuaFile( "shared.lua" )
end

SWEP.HoldType = "pistol"

if CLIENT then

SWEP.PrintName = "Zombie Shooter"
SWEP.Slot = 2

SWEP.ViewModelFOV = 54
SWEP.ViewModelFlip = false

SWEP.Icon = "VGUI/ttt/icon_flare"
end

SWEP.Base = "weapon_tttbase"
SWEP.Primary.Recoil	= 4
SWEP.Primary.Damage = 0
SWEP.Primary.Delay = 1.7
SWEP.Primary.Cone = 0.01
SWEP.Primary.ClipSize = 40
SWEP.Primary.Automatic = false
SWEP.Primary.DefaultClip = 40
SWEP.Primary.ClipMax = 40

SWEP.Kind = WEAPON_EQUIP
--SWEP.CanBuy = {ROLE_TRAITOR,ROLE_DETECTIVE} -- only traitors can buy
--SWEP.LimitedStock = true -- only buyable once
SWEP.WeaponID = AMMO_NPCGUN

-- if I run out of ammo types, this weapon is one I could move to a custom ammo
-- handling strategy, because you never need to pick up ammo for it
SWEP.Primary.Ammo = "AR2AltFire"

SWEP.UseHands	 = true
SWEP.ViewModel	= Model("models/weapons/c_357.mdl")
SWEP.WorldModel	= Model("models/weapons/w_357.mdl")

SWEP.Primary.Sound = Sound( "Weapon_USP.SilencedShot" )

SWEP.Tracer = "AR2Tracer"

function SWEP:PrimaryAttack()
--self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )

    if not self:CanPrimaryAttack() then return end

    self.Weapon:EmitSound( self.Primary.Sound )
    self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
    self:TakePrimaryAmmo( 1 )

    if IsValid(self.Owner) then
        self.Owner:SetAnimation( PLAYER_ATTACK1 )

        self.Owner:ViewPunch( Angle( math.Rand(-0.2,-0.1) * self.Primary.Recoil, math.Rand(-0.1,0.1) *self.Primary.Recoil, 0 ) )

        if SERVER then
            if self.Owner:GetEyeTrace().HitWorld then
                local hitpos = self.Owner:GetEyeTrace().HitPos
                hitpos:Add(Vector(0,0,10))
	    	
                local randint = math.random(1,3)
                local entname = "npc_zombie"
	    	
                if randint == 1 then 
	        	    entname = "npc_zombie"
                elseif randint == 2 then 
	    	        entname = "npc_fastzombie"
                elseif randint == 3 then
	    	        entname = "npc_poisonzombie"
                end
		
                local ent = ents.Create(entname)
		
                ent:SetPos(hitpos)
                ent:Spawn()
            else
                self.Owner:efAddToPlayer( L.unablezombie, "blue" )
            end
		end
	end
	
    if ( (game.SinglePlayer() && SERVER) || CLIENT ) then
        self.Weapon:SetNetworkedFloat( "LastShootTime", CurTime() )
    end
end

function SWEP:SecondaryAttack()
end

-- I give full permission to TheGarry =D to use this code ONLY for his TTT Events System. ~Wolf