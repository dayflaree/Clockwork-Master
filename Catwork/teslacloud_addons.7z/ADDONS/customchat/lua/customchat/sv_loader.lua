--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]
local startTime = os.clock()

-- Our own global var, just for us :)
CustomChat = CustomChat or {}

-- Send theese files to client. Nessesary.
if SERVER then
	AddCSLuaFile("cl_chatbox.lua")
	AddCSLuaFile("sh_config.lua")
end

-- Include theese files.
include("cl_chatbox.lua")
include("sh_config.lua")

print("[Custom ChatBox] Addon Took "..math.Round(os.clock() - startTime, 3).. " second(s) to load.")