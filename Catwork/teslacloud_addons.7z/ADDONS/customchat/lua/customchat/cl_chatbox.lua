--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
	
	Author has no permission to share or re-distribute the code
	without the permission 
	of purchaser of the code ( http://steamcommunity.com/id/wolfwaffles/ )
--]]

local CustomChat = CustomChat

-- A table containing colors. Just easier-to-use.
local cColor = {
	white = Color(255, 255, 255, 255),
	black = Color(0, 0, 0, 255),
	red = Color(255, 0, 0, 255),
	darkRed = Color(175, 0, 0, 255),
	darkerRed = Color(125, 0, 0, 255),
	lightRed = Color(255, 100, 100, 255),
	green = Color(0, 255, 0, 255),
	darkGreen = Color(0, 150, 0, 255),
	darkerGreen = Color(0, 100, 0, 255),
	lightGreen = Color(100, 255, 100, 255),
	blue = Color(0, 0, 255, 255),
	darkBlue = Color(0, 0, 150, 255),
	darkerBlue = Color(0, 0, 100, 255),
	lightBlue = Color(140, 230, 255, 255),
	yellow = Color(255, 255, 0, 255),
	darkYellow = Color(185, 185, 0, 255),
	orange = Color(255, 150, 0, 255),
	darkOrange = Color(255, 100, 0, 255),
	purple = Color(180, 0, 255, 255),
	darkPurple = Color(105, 0, 150, 255),
	pink = Color(255, 0, 255, 255),
	lightPink = Color(255, 90, 255, 255)
}

-- A function to transfer a config into a color.
function GetCustomGroupColor(color)
	if ( string.len(color) > 0 ) then
		return cColor.color
	else
		return cColor.white
	end
end

-- A Table containing tags. I do not recommend changing this one.
local tags = {
--[[ Usergroup:     Tag:                             Color:                       Icon:  ]]--
	{"admin", CustomChat.admin, GetCustomGroupColor(CustomChat.adminColor), CustomChat.adminIcon },
	{"coder", CustomChat.coder, GetCustomGroupColor(CustomChat.coderColor), CustomChat.coderIcon },
	{"staff manager", CustomChat.staffmanager, GetCustomGroupColor(CustomChat.staffmanagerColor), CustomChat.staffmanagerIcon },
	{"co-owner", CustomChat.coowner, GetCustomGroupColor(CustomChat.coownerColor), CustomChat.coownerIcon },
	{"respected", CustomChat.respected, GetCustomGroupColor(CustomChat.respectedColor), CustomChat.respectedIcon },
	{"moderator", CustomChat.moderator, GetCustomGroupColor(CustomChat.moderatorColor), CustomChat.moderatorIcon },
	{"senior staff", CustomChat.seniorstaff, GetCustomGroupColor(CustomChat.seniorstaffColor), CustomChat.seniorstaffIcon },
	{"superadmin", CustomChat.superadmin, GetCustomGroupColor(CustomChat.superadminColor), CustomChat.superadminIcon },
	{"owner", CustomChat.owner, GetCustomGroupColor(CustomChat.ownerColor), CustomChat.ownerIcon }
}

-- A hook to replace several Chat elements with the ones we want.
hook.Add("OnPlayerChat", "CustomChatBox", function(ply, strText, bTeamOnly)
	for k,v in pairs(tags) do
		if ply:IsUserGroup(v[1]) then
			
			if !bTeamOnly then
				chat.AddText(v[3], v[2], v[4], ply:Nick(), cColor.white, ": ", cColor.white, strText)
				return true
			else
				chat.AddText(v[3], v[2], v[4], "(TEAM) ", ply:Nick(), cColor.white, ": ", cColor.white, strText)
				return true
			end
		elseif ( ply:IsUserGroup("user") and CustomChat.showusertitle == 1 ) then
			chat.AddText(GetCustomGroupColor(CustomChat.userColor), CustomChat.user, ply:Nick(), cColor.white, ": ", cColor.white, strText)
		end
	end
end)