--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[ Everyone likes configs :D ]]--
--[[ Took a while to make though, phew ]]--

-- General.
CustomChat.showusertitle      = 0 -- Either or not show title for usergroup "User".
CustomChat.devmode            = 0 -- Developer mode. Prints useful for developer notes in console.

-- Titles.
CustomChat.user         	  = "[Player] "  -- Title for group user.
CustomChat.respected    	  = "[Respected] "  -- Title for group respected.
CustomChat.moderator    	  = "[Moderator] "  -- Title for group moderator.
CustomChat.coder        	  = "[Coder] "  -- Title for group coder.
CustomChat.admin        	  = "[Admin] "  -- Title for group admin.
CustomChat.seniorstaff  	  = "[Senior Staff] "  -- Title for group senior staff.
CustomChat.superadmin   	  = "[Super Admin] "  -- Title for group superadmin.
CustomChat.coowner      	  = "[Co-Owner] "  -- Title for group co-owner.
CustomChat.staffmanager 	  = "[Staff Manager] "  -- Title for group staffmanager.
CustomChat.owner              = "[Owner] "  -- Title for group owner.

-- Colors.
CustomChat.userColor          = white  -- Color for group user.
CustomChat.respectedColor     = pink  -- Color for group respected.
CustomChat.moderatorColor     = darkGreen  -- Color for group moderator.
CustomChat.coderColor         = blue  -- Color for group coder.
CustomChat.adminColor         = darkerRed  -- Color for group admin.
CustomChat.seniorstaffColor   = darkRed  -- Color for group senior staff.
CustomChat.superadminColor    = red  -- Color for group superadmin.
CustomChat.coownerColor       = darkPurple  -- Color for group co-owner.
CustomChat.staffmanagerColor  = lightBlue  -- Color for group staffmanager.
CustomChat.ownerColor         = purple  -- Color for group owner.

-- Icons.
CustomChat.userIcon           = "customchat/icons32/user.png"  -- Icon for group user.
CustomChat.respectedIcon      = "customchat/icons32/respected.png"  -- Icon for group respected.
CustomChat.moderatorIcon      = "customchat/icons32/mod.png"  -- Icon for group moderator.
CustomChat.coderIcon          = "customchat/icons32/coder.png"  -- Icon for group coder.
CustomChat.adminIcon          = "customchat/icons32/admin.png"  -- Icon for group admin.
CustomChat.seniorstaffIcon    = "customchat/icons32/senior.png"  -- Icon for group senior staff.
CustomChat.superadminIcon     = "customchat/icons32/superadmin.png"  -- Icon for group superadmin.
CustomChat.coownerIcon        = "customchat/icons32/coowner.png"  -- Icon for group co-owner.
CustomChat.staffmanagerIcon   = "customchat/icons32/staffmanager.png"  -- Icon for group staffmanager.
CustomChat.ownerIcon          = "customchat/icons32/owner.png"  -- Icon for group owner.