--[[
    (C) 2014 TeslaCloud Studios Ltd.
	The code is made by TheGarry =D (Founder of TeslaCloud Studios)
	
	You can edit and use this code, but you have no permission to
	share or re-distribute the code without the permission
	of it's author (thegarry@teslacloud.net)
--]]

--[[
    About this file:
	This file initializes Custom ChatBox's booting process.
	Do not remove this file, otherwise the addon will not load.
--]]

--[[ Include Custom ChatBox Loader --]]
if SERVER then
    include("customchat/sv_loader.lua")
end