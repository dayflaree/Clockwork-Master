--[[
	� 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

local PLUGIN = PLUGIN;

function PLUGIN:GetBars(bars)
	local hunger = CW.Client:GetSharedVar("Hunger") or 100;
	
	if (hunger < 90 and CW.Client:Alive()) then
		bars:Add("HUNGER", Color(100, 175, 175, 255), "", hunger, 100, hunger < 10);
	end
end;
