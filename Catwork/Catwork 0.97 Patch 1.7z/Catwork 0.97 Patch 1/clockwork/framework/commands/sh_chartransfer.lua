--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("CharTransfer");
COMMAND.tip = "Transfer a character to a faction.";
COMMAND.text = "<string Name> <string Faction> [string Data]";
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Transfer"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])
	
	if (target) then
		local faction = arguments[2];
		local name = target:Name();
		
		if (!CW.faction.stored[faction]) then
			CW.player:Notify(player, faction.." is not a valid faction!");
			return;
		end;
		
		if (!CW.faction.stored[faction].whitelist or CW.player:IsWhitelisted(target, faction)) then
			local targetFaction = target:GetFaction();
			
			if (targetFaction == faction) then
				CW.player:Notify(player, target:Name().." is already the "..faction.." faction!");
				return;
			end;
			
			if (!CW.faction:IsGenderValid(faction, target:GetGender())) then
				CW.player:Notify(player, target:Name().." is not the correct gender for the "..faction.." faction!");
				return;
			end;
			
			if (!CW.faction.stored[faction].OnTransferred) then
				CW.player:Notify(player, target:Name().." cannot be transferred to the "..faction.." faction!");
				return;
			end;
			
			local bSuccess, fault = CW.faction.stored[faction]:OnTransferred(target, CW.faction.stored[targetFaction], arguments[3]);
			
			if (bSuccess != false) then
				target:SetCharacterData("Faction", faction, true);
				
				CW.player:LoadCharacter(target, CW.player:GetCharacterID(target));
				CW.player:NotifyAll(player:Name().." has transferred "..name.." to the "..faction.." faction.");
			else
				CW.player:Notify(player, fault or target:Name().." could not be transferred to the "..faction.." faction!");
			end;
		else
			CW.player:Notify(player, target:Name().." is not on the "..faction.." whitelist!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();