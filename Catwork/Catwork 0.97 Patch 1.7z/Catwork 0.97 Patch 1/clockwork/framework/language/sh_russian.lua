--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

--[[
	If you need to, just discard what I had so far and
	copy paste the English language file over and then just run through it
	without worrying about merging the two or worrying if you missed anything.

	- NA <3
--]]

local lang = CW.lang:GetTable("ru");

lang.name = "Русский язык";

-- Config Print
lang["#ConfigVariablesPrinted"] = "Значения конфигурации были выведены в консоль.";

-- Various Error Messages
lang["#CannotPurchaseAnotherDoor"] = "Вы не можете приобрести еще одну дверь!";
lang["#EntityOptionWaitTime"] = "Вы не можете использовать это настолько быстро!";
lang["#YouNeedAnother"] = "Вам необходимо еще #1!";
lang["#NotEnoughText"] = "Вы не ввели достаточное количество текста!";
lang["#NotValidMap"] = "На сервере нет карты #1!"
lang["#CannotChangeClassFor"] = "Вы не можете сменить класс еще #1 секунд!";
lang["#CannotActionRightNow"] = "Вы не можете сделать это сейчас!";
lang["#DroppedItemsOtherChar"] = "Нельзя подбирать предметы, принадлежащие другому вашему персонажу!";
lang["#DroppedCashOtherChar"] = "Нельзя подобрать #1, принадлежащий другому вашему персонажу!";
lang["#NotValidCharacter"] = "Персонажа '#1' не существует!";
lang["#NotValidPlayer"] = "Игрока '#1' не существует!";
lang["#NotValidAmount"] = "Введенное вами количество не подходит!";

-- Roll Message
lang["#HasRolled"] = "#1'у выпало #2 из #3.";
lang["#LogHasRolled"] = "#1 выпало #2 из #3!";

-- Cash Set Messages
lang ["CashSetTarget"] = "#3 установил ваши #1 на #2."
lang ["CashSetPlayer"] = "Вы установили #2 #1 на #3."

-- Storage Error Messages
lang["#StorageNoInstance"] = "Данного предмета нет в этом хранилище!";
lang["#StorageNotOpen"] = "Вы не можете открыть это хранилище!";
lang["#StorageCannotGive"] = "Вы не можете хранить предметы здесь!";
lang["#StoragePlayerNoInstance"] = "У вас нет данного предмета!";

-- Class Error Messages
lang["#ClassNoAccess"] = "Вы не имеете доступа к этому классу!";
lang["#ClassTooMany"] = "Слишком много персонажей в этом классом!";
lang["#ClassNotValid"] = "Такого класса не существует!";

-- Voicemail Notifies
lang["#VoicemailRemoved"] = "Вы удалили своб голосовую почту.";
lang["#VoicemailSet"] = "Вы установили свою голосовую почту на '#1'.";

-- Weapon Error Messages
lang["#CannotHolsterWeapon"] = "Вы не можете опустить это оружие!";
lang["#CannotDropWeapon"] = "Вы не можете выкинуть это оружие!";
lang["#CannotUseWeapon"] = "Вы не можете использовать это оружие!";

-- Config Error Messages
lang["#ConfigUnableToSet"] = "Невозможно установить значение конфигурации '#1'!";
lang["#ConfigIsStaticKey"] = "#1 является статическим значением конфигурации!";
lang["#ConfigKeyNotValid"] = "Значение конфигурации '#1' не существует!";

-- Settings Categories
lang["#Framework"] = "Игровой режим";
lang["#ChatBox"] = "Чат";
lang["#Theme"] = "Оформление";
lang["#AdminESP"] = "ESP Администратора";
	
-- Settings Info Text
lang["#SettingsInfoText"] = "Данные настройки позволяют вам персонализировать внешний вид Clockwork'а.";
lang["#NoSettingsInfoText"] = "К-сожалению, у вас нету доступа к каким-либо настройкам!";

-- Settings Descriptions
lang["#ThemeDesc"] = "Выбранное оформление для интерфейса пользователя.";
lang["#EnableAdminESPDesc"] = "Включить/выключить радар (ESP).";
lang["#DrawESPBarsDesc"] = "Отрисовывать полоски прогресса для некоторых значений.";
lang["#ShowItemEntitiesDesc"] = "Показывать предметы на радаре.";
lang["#ShowSalesmenEntitiesDesc"] = "Показывать NPC продавцов на радаре.";
lang["#ESPIntervalDesc"] = "Интервал между обновлениями радара.";
lang["#TwelveHourClockDesc"] = "Показывать время в 12-часовом формате.";
lang["#ShowBarsDesc"] = "Показывать полоски в верхнем углу экрана.";
lang["#EnableHintsDesc"] = "Показывать подсказки.";
lang["#LangDesc"] = "Выбранный язык.";
lang["#EnableVignetteDesc"] = "Отрисовывать виньетку по краям экрана.";
lang["#ShowTimestampsDesc"] = "Показывать время возле сообщений в чате.";
lang["#ShowCWMessagesDesc"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessagesDesc"] = "Показывать сообщения сервера.";
lang["#ShowOOCMessagesDesc"] = "Показывать глобальные (OOC) сообщения.";
lang["#ShowICMessagesDesc"] = "Показывать сообщения персонажей (IC чат).";
lang["#HeadbobAmountDesc"] = "Множитель качки (пошатанывания) головы.";
lang["#ChatLinesDesc"] = "Количество строк чата, которые можно увидеть за раз.";
lang["#EnableConsoleLogDesc"] = "Показывать логи администратора.";
lang["#TextColorDesc"] = "Цвет, используемый по большей части для текстов оформления.";
lang["#BGColorDesc"] = "Цвет фона.";
lang["#TabMenuXDesc"] = "Позиция TAB-меню по оси X.";
lang["#TabMenuYDesc"] = "Позиция TAB-меню по оси Y.";
lang["#BackMenuXDesc"] = "Позиция фона по оси X.";
lang["#BackMenuYDesc"] = "Позиция фона по оси Y.";
lang["#BackMenuWDesc"] = "Ширина фона.";
lang["#BackMenuHDesc"] = "Высота фона.";
lang["#FadePanelsDesc"] = "Использовать переливание панелей из одну в другую при смене вкладок TAB-меню.";
lang["#ShowMaterialDesc"] = "Отрисовывать материал на фоне меню.";
lang["#ShowGradientDesc"] = "Отрисовывать градиент (блюр) на фоне меню.";
lang["#MenuMaterialDesc"] = "Материал, используемый как фон для TAB-меню.";

-- Settings Names
lang["#EnableAdminESP"] = "Включить Админ ESP.";
lang["#DrawESPBars"] = "Показывать полоски.";
lang["#ShowSpawnPoints"] = "Показывать точки возрождения.";
lang["#ShowStaticEnts"] = "Показывать статичные объекты.";
lang["#ShowItemEntities"] = "Показывать предметы.";
lang["#ShowSalesmenEntities"] = "Показывать продавцов.";
lang["#ESPInterval"] = "Интервал обновления радара:";
lang["#TwelveHourClock"] = "Включить 12-часовой формат времени.";
lang["#ShowBars"] = "Показывать полоски в верхней части экрана.";
lang["#EnableHints"] = "Включить подсказки.";
lang["#Language"] = "Язык";
lang["#EnableVignette"] = "Показывать виньетку";
lang["#ShowTimestamps"] = "Показывать время сообщений в чате.";
lang["#ShowCWMessages"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessages"] = "Показывать сообщения от сервера.";
lang["#ShowOOCMessages"] = "Показывать OOC чат.";
lang["#ShowICMessages"] = "Показывать IC чат.";
lang["#HeadbobAmount"] = "Амплитуда пошатывания головы:";
lang["#ChatLines"] = "Количество строк чата:";
lang["#EnableConsoleLog"] = "Включить логи администратора.";
lang["#TextColor"] = "Цвет текста:";
lang["#BGColor"] = "Цвет фона:";
lang["#TabMenuX"] = "Позиция TAB-меню по оси X:";
lang["#TabMenuY"] = "Позиция TAB-меню по оси Y:";
lang["#BackMenuX"] = "Позиция фона по оси X:";
lang["#BackMenuY"] = "Позиция фона по оси Y:";
lang["#BackMenuW"] = "Ширина фона:";
lang["#BackMenuH"] = "Высота фона:";
lang["#FadePanels"] = "Переливать панели:";
lang["#ShowMaterial"] = "Показывать материал:";
lang["#ShowGradient"] = "Показывать блюр-фон:";
lang["#MenuMaterial"] = "Материал:";

-- Settings Descriptions
lang["#ThemeDesc"] = "Выбранное оформление для интерфейса пользователя.";
lang["#EnableAdminESPDesc"] = "Включить/выключить радар администратора.";
lang["#DrawESPBarsDesc"] = "Отрисовывать полоски прогресса для некоторых значений.";
lang["#ShowItemEntitiesDesc"] = "Показывать предметы на радаре.";
lang["#ShowSalesmenEntitiesDesc"] = "Показывать NPC-продавцов на радаре.";
lang["#ESPIntervalDesc"] = "Интервал между обновлениями радара.";
lang["#TwelveHourClockDesc"] = "Использовать 12-часовые часы.";
lang["#ShowBarsDesc"] = "Показывать полоски в верхнем углу экрана.";
lang["#EnableHintsDesc"] = "Показывать подсказки.";
lang["#LangDesc"] = "Выбранный язык.";
lang["#EnableVignetteDesc"] = "Отрисовывать виньетку по краям экрана.";
lang["#ShowTimestampsDesc"] = "Показывать время возле сообщений в чате.";
lang["#ShowCWMessagesDesc"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessagesDesc"] = "Показывать сообщения сервера.";
lang["#ShowOOCMessagesDesc"] = "Показывать глобальные (OOC) сообщения.";
lang["#ShowICMessagesDesc"] = "Показывать сообщения персонажей (IC чат).";
lang["#HeadbobAmountDesc"] = "Множитель качки (шатания) головы.";
lang["#ChatLinesDesc"] = "Количество строк чата, которые можно увидеть за раз.";
lang["#EnableConsoleLogDesc"] = "Показывать логи администратора.";
lang["#TextColorDesc"] = "Цвет, используемый по большей части для текстов оформления.";
lang["#BGColorDesc"] = "Цвет фона.";
lang["#TabMenuXDesc"] = "Позиция TAB-меню по оси X.";
lang["#TabMenuYDesc"] = "Позиция TAB-меню по оси Y.";
lang["#BackMenuXDesc"] = "Позиция фона по оси X.";
lang["#BackMenuYDesc"] = "Позиция фона по оси Y.";
lang["#BackMenuWDesc"] = "Ширина фона.";
lang["#BackMenuHDesc"] = "Высота фона.";
lang["#FadePanelsDesc"] = "Использовать переливание панелей из одну в другую при смене вкладок TAB-меню.";
lang["#ShowMaterialDesc"] = "Отрисовывать материал на фоне меню.";
lang["#ShowGradientDesc"] = "Отрисовывать градиент (блюр) на фоне меню.";
lang["#MenuMaterialDesc"] = "Материал, используемый как фон для TAB-меню.";

-- Settings Names
lang["#EnableAdminESP"] = "Включить радар администратора.";
lang["#DrawESPBars"] = "Показывать полоски.";
lang["#ShowSpawnPoints"] = "Показывать точки возрождения.";
lang["#ShowStaticEnts"] = "Показывать статичные объекты.";
lang["#ShowItemEntities"] = "Показывать предметы.";
lang["#ShowSalesmenEntities"] = "Показывать продавцов.";
lang["#ESPInterval"] = "Интервал обновления радара:";
lang["#TwelveHourClock"] = "Включить 12-часовые часы.";
lang["#ShowBars"] = "Показывать полоски в верхней части экрана.";
lang["#EnableHints"] = "Включить подсказки.";
lang["#Language"] = "Язык";
lang["#EnableVignette"] = "Показывать виньетку";
lang["#ShowTimestamps"] = "Показывать время сообщений в чате.";
lang["#ShowCWMessages"] = "Показывать сообщения игрового режима.";
lang["#ShowServerMessages"] = "Показывать сообщения от сервера.";
lang["#ShowOOCMessages"] = "Показывать OOC чат.";
lang["#ShowICMessages"] = "Показывать IC чат.";
lang["#HeadbobAmount"] = "Амплитуда шатания головы:";
lang["#ChatLines"] = "Количество строк чата:";
lang["#EnableConsoleLog"] = "Включить логи администратора.";
lang["#TextColor"] = "Цвет текста:";
lang["#BGColor"] = "Цвет фона:";
lang["#TabMenuX"] = "Позиция TAB-меню по оси X:";
lang["#TabMenuY"] = "Позиция TAB-меню по оси Y:";
lang["#BackMenuX"] = "Позиция фона по оси X:";
lang["#BackMenuY"] = "Позиция фона по оси Y:";
lang["#BackMenuW"] = "Ширина фона:";
lang["#BackMenuH"] = "Высота фона:";
lang["#FadePanels"] = "Переливать панели:";
lang["#ShowMaterial"] = "Показывать материал:";
lang["#ShowGradient"] = "Показывать блюр-фон:";
lang["#MenuMaterial"] = "Материал:";

--[[
	You don't HAVE to translate the config, but I feel like it'd be 
	easier for server owners / SAs who have trouble with English.
--]]

--[[
	I just took a look at the amount of text.
	no.
	nopls.
	i'm out.
	nonononono.
	no way.
	no thanks.
	i'm good.
	
	maybe later.
	~meow
--]]

-- Config Descriptions
lang["#AttributeProgressionScaleDesc"] = "Множитель прогресса аттрибутов.";
lang["#MessagesMustSeePlayerDesc"] = "Должен ли говорящий игрок находиться в поле зрения другого игрока, чтобы быть услышанным.";
lang["#StartingAttributePointsDesc"] = "Количество очков аттрибутов, которые игрок имеет сначала.";
lang["#ClockworkIntroEnabledDesc"] = "Включить заставку при первоначальном заходе на сервер.";
lang["#HealthRegenerationEnabledDesc"] = "Включить постепенную регенерацию здоровья.";
lang["#PropProtectionEnabledDesc"] = "Включить защиту объектов (пропов).";
lang["#UseLocalMachineDateDesc"] = "Использовать дату сервера при загрузке карты.";
lang["#UseLocalMachineTimeDesc"] = "Использовать время сервера при загрузке карты.";
lang["#UseKeyOpensEntityMenusDesc"] = "Открывает ли клавиша 'использовать' контекстные меню объектов.";
lang["#ShootAfterRaiseDelayDesc"] = "При приведении оружия в боевую готовность, сколько времени должен ждать игрок\nпрежде чем он сможет начать стрельбу.\nЗначение '0' убирает эту задержку.";
lang["#UseClockworkAdminSystemDesc"] = "Используется ли на сервере какая-либо другая админка, чем встроенная в Clockwork.";
lang["#SavedRecognisedNamesDesc"] = "Включить сохранение знакомых имён персонажей.";
lang["#SaveAttributeBoostsDesc"] = "Включить сохранение увеличения аттрибутов.";
lang["#RagdollDamageImmunityTimeDesc"] = "Время в секундах пока рэгдолл игрока не получает никакого урона.";
lang["#AdditionalCharacterCountDesc"] = "Количество дополнительных персонажей, которое игрок может создать.";
lang["#ClassChangingIntervalDesc"] = "Время, которое игрок должен подождать между сменами классов (в секундах).";
lang["#SprintingLowersWeaponDesc"] = "Опускается ли оружие при беге.";
lang["#WeaponRaisingSystemDesc"] = "Включить систему опускания оружия.";
lang["#PropKillProtectionDesc"] = "Включить защиту от убийства объектами";
lang["#GeneratorIntervalDesc"] = "Сколько времени требуется генератору, чтобы произвести деньги (в секундах).";
lang["#GravityGunPuntDesc"] = "Включить возможность гравипушки толкать предметы.";
lang["#DefaultInventoryWeightDesc"] = "Вес, который игрок может переносить в инвентаре (килограммы).";
lang["#DefaultInventorySpaceDesc"] = "Объем, который игрок может переносить в инвентаре (литры).";
lang["#DataSaveIntervalDesc"] = "Интервал сохранения данных сервером в секундах.";
lang["#ViewPunchOnDamageDesc"] = "Whether or not a player's view gets punched when they take damage.";
lang["#UnrecognisedNameDesc"] = "The name that is given to unrecognised players.";
lang["#LimbDamageSystemDesc"] = "Limb Damage System Enabled";
lang["#FallDamageScaleDesc"] = "The amount to scale fall damage by.";
lang["#StartingCurrencyDesc"] = "The default amount of cash that each player starts with.";
lang["#ArmorAffectsChestDesc"] = "Whether or not armor only affects the chest.";
lang["#MinimumPhysicalDescriptionDesc"] = "The minimum amount of characters a player must have in their physical description.";
lang["#WoodBreaksFallDesc"] = "Whether or not wooden physics entities break a player's fall.";
lang["#VignetteEnabledDesc"] = "Whether or not the vignette is enabled.";
lang["#HeartbeatSoundsDesc"] = "Whether or not the heartbeat is enabled.";
lang["#CrosshairEnabledDesc"] = "Whether or not the crosshair is enabled.";
lang["#FreeAimingDesc"] = "Whether or not free aiming is enabled.";
lang["#RecogniseSystemDesc"] = "Whether or not the recognise system is enabled.";
lang["#CurrencyEnabledDesc"] = "Whether or not cash is enabled.";
lang["#DefaultPhysicalDescriptionDesc"] = "The physical description that each player begins with.";
lang["#ChestDamageScaleDesc"] = "The amount to scale chest damage by.";
lang["#CorpseDecayTimeDesc"] = "The time that it takes for a player's ragdoll to decay (seconds).";
lang["#BannedDisconnectMessageDesc"] = "The message that a player receives when trying to join while banned.\n!t for the time left, !f for the time format.";
lang["#WagesIntervalDesc"] = "The time that it takes for wages cash to be distrubuted (seconds).";
lang["#PropCostScaleDesc"] = "How to much to scale prop cost by.\nSet to 0 to to make props free.";
lang["#FadeNPCCorpsesDesc"] = "Whether or not to fade dead NPCs.";
lang["#CashWeightDesc"] = "The weight of cash (kilograms).";
lang["#CashSpaceDesc"] = "The amount of space cash takes (litres).";
lang["#HeadDamageScaleDesc"] = "The amount to scale head damage by.";
lang["#BlockInventoryBindsDesc"] = "Whether or not inventory binds should be blocked for players.";
lang["#LimbDamageScaleDesc"] = "The amount to scale limb damage by.";
lang["#TargetIDDelayDesc"] = "The delay before the Target ID is displayed when looking at an entity.";
lang["#HeadbobEnabledDesc"] = "Whether or not to enable headbob.";
lang["#ChatCommandPrefixDesc"] = "The prefix that is used for chat commands.";
lang["#CrouchWalkSpeedDesc"] = "The speed that characters walk at when crouched.";
lang["#MaximumChatLengthDesc"] = "The maximum amount of characters that can be typed in chat.";
lang["#StartingFlagsDesc"] = "The flags that each player begins with.";
lang["#PlayerSprayDesc"] = "Whether players can spray their tags.";
lang["#HintIntervalDesc"] = "The time that a hint is displayed to each player (seconds).";
lang["#OOCChatIntervalDesc"] = "The time that a player has to wait to speak out-of-character again (seconds).\nSet to 0 for never.";
lang["#MinuteTimeDesc"] = "The time that it takes for a minute to pass (seconds).";
lang["#DoorUnlockIntervalDesc"] = "The time that a player has to wait to unlock a door (seconds).";
lang["#VoiceChatEnabledDesc"] = "Whether or not voice chat is enabled.";
lang["#LocalVoiceChatDesc"] = "Whether or not to enable local voice.";
lang["#TalkRadiusDesc"] = "The radius of each player that other characters have to be in to hear them talk (units).";
lang["#GiveHandsDesc"] = "Whether or not to give hands to each player.";
lang["#CustomWeaponColorDesc"] = "Whether or not to enable custom weapon colors.";
lang["#GiveKeysDesc"] = "Whether or not to give keys to each player.";
lang["#WagesNameDesc"] = "The name that is given to wages.";
lang["#JumpPowerDesc"] = "The power that characters jump at.";
lang["#RespawnDelayDesc"] = "The time that a player has to wait before they can spawn again (seconds).";
lang["#MaximumWalkSpeedDesc"] = "The speed that characters walk at.";
lang["#MaximumRunSpeedDesc"] = "The speed that characters run at.";
lang["#DoorPriceDesc"] = "The amount of cash that each door costs.";
lang["#DoorLockIntervalDesc"] = "The time that a player has to wait to lock a door (seconds).";
lang["#MaximumOwnableDoorsDesc"] = "The maximum amount of doors a player can own.";
lang["#EnableSpaceSystemDesc"] = "Whether or not to use the space system that affects inventories.";
lang["#DrawIntroBarsDesc"] = "Whether or not to draw cinematic intro black bars on top and bottom of the screen.";
lang["#EnableJoggingDesc"] = "Whether or not to enable jogging.";
lang["#EnableLOOCIconsDesc"] = "Whether or not to enable LOOC chat icons.";
lang["#ShowBusinessMenuDesc"] = "Whether or not to show the business menu.";
lang["#EnableChatMultiplierDesc"] = "Whether or not to change text size based on types of chat.";
lang["#SteamAPIKeyDesc"] = "Some non-essential features may require the usage of the Steam API.\nhttp://steamcommunity.com/dev/apikey";
lang["#MapPropsPhysgrabDesc"] = "Whether or not players will be able to grab map props and doors with physguns.";
lang["#EntityUseCooldownDesc"] = "The amount of time between entity uses a player has to wait.";
lang["#EnableSmoothSprintDesc"] = "Whether or not smooth sprinting will be used.";
lang["#EnableQuickRaiseDesc"] = "Whether or not players can use quick raising to raise their weapons.";
lang["#PlayersChangeThemesDesc"] = "Whether or not players can switch between available themes.";
lang["#DefaultThemeDesc"] = "The default theme that players will start with.";
lang["#EnableIronsightsDesc"] = "Whether or not players can use ironsights on their weapons when available.";
lang["#IronsightsSpreadReductionDesc"] = "The amount that ironsights will reduce bullet spread by.";
lang["#IronsightsSlowAmountDesc"] = "The amount that using ironsights will decrease a player's movement speed by.";

-- Config Names
lang["#AttributeProgressionScale"] = "Attribute Progression Scale";
lang["#MessagesMustSeePlayer"] = "Messages Must See Player";
lang["#StartingAttributePoints"] = "Starting Attribute Points";
lang["#ClockworkIntroEnabled"] = "Clockwork Introduction Enabled";
lang["#HealthRegenerationEnabled"] = "Health Regeneration Enabled";
lang["#PropProtectionEnabled"] = "Prop Protection Enabled";
lang["#UseLocalMachineDate"] = "Use Local Machine Date";
lang["#UseLocalMachineTime"] = "Use Local Machine Time";
lang["#UseKeyOpensEntityMenus"] = "Use Key Opens Entity Menus";
lang["#ShootAfterRaiseDelay"] = "Shoot After Raise Delay";
lang["#UseClockworkAdminSystem"] = "Use Clockwork's Admin System";
lang["#SavedRecognisedNames"] = "Saved Recognised Names";
lang["#SaveAttributeBoosts"] = "Save Attribute Boosts";
lang["#RagdollDamageImmunityTime"] = "Ragdoll Damage Immunity Time";
lang["#AdditionalCharacterCount"] = "Additional Character Count";
lang["#ClassChangingInterval"] = "Class Changing Interval";
lang["#SprintingLowersWeapon"] = "Sprinting Lowers Weapon";
lang["#WeaponRaisingSystem"] = "Weapon Raising System Enabled";
lang["#PropKillProtection"] = "Prop Kill Protection Enabled";
lang["#SmoothServerRates"] = "Use Smooth Server Rates";
lang["#MediumServerRates"] = "Use Medium Performance Server Rates";
lang["#LagFreeServerRates"] = "Use Lag Free Server Rates";
lang["#GeneratorInterval"] = "Generator Interval";
lang["#GravityGunPunt"] = "Gravity Gun Punt Enabled";
lang["#DefaultInventoryWeight"] = "Default Inventory Weight";
lang["#DefaultInventorySpace"] = "Default Inventory Space";
lang["#DataSaveInterval"] = "Data Save Interval";
lang["#ViewPunchOnDamage"] = "View Punch On Damage";
lang["#UnrecognisedName"] = "Unrecognised Name";
lang["#LimbDamageSystem"] = "Limb Damage System Enabled";
lang["#FallDamageScale"] = "Fall Damage Scale";
lang["#StartingCurrency"] = "Starting Currency";
lang["#ArmorAffectsChest"] = "Armor Affects Chest Only";
lang["#MinimumPhysicalDescription"] = "Minimum Physical Description Length";
lang["#WoodBreaksFall"] = "Wood Breaks Fall";
lang["#VignetteEnabled"] = "Vignette Enabled";
lang["#HeartbeatSounds"] = "Heartbeat Sounds Enabled"; //Day 132. Still converting strings..
lang["#CrosshairEnabled"] = "Crosshair Enabled";
lang["#FreeAiming"] = "Free Aiming Enabled";
lang["#RecogniseSystem"] = "Recognise System Enabled";
lang["#CurrencyEnabled"] = "Currency Enabled";
lang["#DefaultPhysicalDescription"] = "Default Physical Description";
lang["#ChestDamageScale"] = "Chest Damage Scale";
lang["#CorpseDecayTime"] = "Corpse Decay Time";
lang["#BannedDisconnectMessage"] = "Banned Disconnect Message";
lang["#WagesInterval"] = "Wages Interval";
lang["#PropCostScale"] = "Prop Cost Scale";
lang["#FadeNPCCorpses"] = "Fade NPC Corpses";
lang["#CashWeight"] = "Cash Weight";
lang["#CashSpace"] = "Cash Space";
lang["#HeadDamageScale"] = "Head Damage Scale";
lang["#BlockInventoryBinds"] = "Block Inventory Binds";
lang["#LimbDamageScale"] = "Limb Damage Scale";
lang["#TargetIDDelay"] = "Target ID Delay";
lang["#HeadbobEnabled"] = "Headbob Enabled";
lang["#ChatCommandPrefix"] = "Chat Command Prefix";
lang["#CrouchWalkSpeed"] = "Crouch Walk Speed";
lang["#MaximumChatLength"] = "Maximum Chat Length";
lang["#StartingFlags"] = "Starting Flags";
lang["#PlayerSpray"] = "Player Spray Enabled";
lang["#HintInterval"] = "Hint Interval";
lang["#OOCChatInterval"] = "Out-Of-Character Chat Interval";
lang["#MinuteTime"] = "Minute Time";
lang["#DoorUnlockInterval"] = "Door Unlock Interval";
lang["#VoiceChatEnabled"] = "Voice Chat Enabled";
lang["#LocalVoiceChat"] = "Local Voice Chat";
lang["#TalkRadius"] = "Talk Radius";
lang["#GiveHands"] = "Give Hands";
lang["#CustomWeaponColor"] = "Custom Weapon Color";
lang["#GiveKeys"] = "Give Keys";
lang["#WagesName"] = "Wages Name";
lang["#JumpPower"] = "Jump Power";
lang["#RespawnDelay"] = "Respawn Delay"; // Send help...
lang["#MaximumWalkSpeed"] = "Maximum Walk Speed";
lang["#MaximumRunSpeed"] = "Maximum Run Speed";
lang["#DoorPrice"] = "Door Price";
lang["#DoorLockInterval"] = "Door Lock Interval";
lang["#MaximumOwnableDoors"] = "Maximum Ownable Doors";
lang["#EnableSpaceSystem"] = "Enable Space System";
lang["#DrawIntroBars"] = "Draw Intro Bars";
lang["#EnableJogging"] = "Enable Jogging";
lang["#EnableLOOCIcons"] = "Enable LOOC Icons";
lang["#ShowBusinessMenu"] = "Show Business Menu";
lang["#EnableChatMultiplier"] = "Enable Chat Multiplier";
lang["#SteamAPIKey"] = "Steam API Key";
lang["#MapPropsPhysgrab"] = "Enable Map Props Physgrab";
lang["#EntityUseCooldown"] = "Entity Use Cooldown";
lang["#EnableSmoothSprint"] = "Enable Smooth Sprint";
lang["#EnableQuickRaise"] = "Enable Quick Raise";
lang["#PlayersChangeThemes"] = "Players Change Themes";
lang["#DefaultTheme"] = "Default Theme";
lang["#EnableIronsights"] = "Enable Ironsights";
lang["#IronsightsSpreadReduction"] = "Ironsights Spread Reduction";
lang["#IronsightsSlowAmount"] = "Ironsights Slow Amount"; // omg finally i can sleep now

-- Days
lang["#Monday"] = "Поденельник";
lang["#Tuesday"] = "Вторник";
lang["#Wednesday"] = "Среда";
lang["#Thursday"] = "Четверг";
lang["#Friday"] = "Пятница";
lang["#Saturday"] = "Суббота";
lang["#Sunday"] = "Воскресенье";

-- Tab Menu Descriptions
lang["#BusinessDesc"] = "Покупайте предметы для вашего бизнеса.";
lang["#InventoryDesc"] = "Управление предметами в вашем инвентаре.";
lang["#DirectoryDesc"] = "Документация команд, а также различная информация.";
lang["#SystemDesc"] = "Доступ к различным настройкам сервера.";
lang["#ScoreboardDesc"] = "Список игроков на сервере.";
lang["#AttributesDesc"] = "Статус ваших аттрибутов.";
lang["#SettingsDesc"] = "Настройте то, как Clockwork работает у вас.";
lang["#ClassesDesc"] = "Выбор класса вашего персонажа.";
lang["#CharactersDesc"] = "Нажмите эту кнопку, чтобы перейти в меню выбора персонажей.";
lang["#CloseMenuDesc"] = "Нажмите эту кнопку, чтобы закрыть это меню.";

-- Tab Menu Names
lang["#Attributes"] = "Аттрибуты";
lang["#Attribute"] = "Аттрибут";
lang["#System"] = "Админка";
lang["#Settings"] = "Настройки";
lang["#Classes"] = "Классы";
lang["#Scoreboard"] = "Игроки";
lang["#Directory"] = "Помощь";
lang["#Inventory"] = "Инвентарь";
lang["#Business"] = "Бизнес";
lang["#Characters"] = "ПЕРСОНАЖИ";
lang["#CloseMenu"] = "ЗАКРЫТЬ";

-- Misc Terms
lang["#Destroy"] = "Уничтожить";
lang["#Cash"] = "Деньги";
lang["#Drop"] = "Выбросить";
lang["#Use"] = "Использовать";