--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("Give"..string.gsub(NAME_CASH, "%s", ""));
COMMAND.tip = "Give "..string.lower(NAME_CASH).." to the target character.";
COMMAND.text = "<number "..string.gsub(NAME_CASH, "%s", "")..">";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.alias = {"GiveCash"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	local cash = math.floor(tonumber((arguments[1] or 0)));
	
	if (target and target:IsPlayer()) then
		if (target:GetShootPos():Distance(player:GetShootPos()) <= 192) then			
			if (cash and cash >= 1) then
				if (CW.player:CanAfford(player, cash)) then
					local playerName = player:Name();
					local targetName = target:Name();
					
					if (!CW.player:DoesRecognise(player, target)) then
						targetName = CW.player:GetUnrecognisedName(target, true);
					end;
					
					if (!CW.player:DoesRecognise(target, player)) then
						playerName = CW.player:GetUnrecognisedName(player, true);
					end;
					
					CW.player:GiveCash(player, -cash);
					CW.player:GiveCash(target, cash);
					
					CW.player:Notify(player, "You have given "..CW.kernel:FormatCash(cash, nil, true).." to "..targetName..".");
					CW.player:Notify(target, "You were given "..CW.kernel:FormatCash(cash, nil, true).." by "..playerName..".");
				else
					local amount = cash - player:GetCash();
					CW.player:Notify(player, "You need another "..CW.kernel:FormatCash(amount, nil, true).."!");
				end;
			else
				CW.player:Notify(player, "This is not a valid amount!");
			end;
		else
			CW.player:Notify(player, "This character is too far away!");
		end;
	else
		CW.player:Notify(player, "You must look at a valid character!");
	end;
end;

COMMAND:Register();