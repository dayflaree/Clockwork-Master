--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/CW.html
--]]

local COMMAND = CW.command:New("SetClass");
COMMAND.tip = "Set the class of your character.";
COMMAND.text = "<string Class>";
COMMAND.flags = CMD_HEAVY;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local class = CW.class:FindByID(arguments[1]);
	
	if (player:InVehicle()) then
		CW.player:Notify(player, L("CannotActionRightNow"));
		return;
	end;
	
	if (class) then
		local limit = CW.class:GetLimit(class.name);
		
		if (plugin.Call("PlayerCanBypassClassLimit", player, class.index)) then
			limit = game.MaxPlayers();
		end;
		
		if (cwTeam.NumPlayers(class.index) < limit) then
			local previousTeam = player:Team();
			
			if (player:Team() != class.index
			and CW.kernel:HasObjectAccess(player, class)) then
				if (plugin.Call("PlayerCanChangeClass", player, class)) then
					local bSuccess, fault = CW.class:Set(player, class.index, nil, true);
					
					if (!bSuccess) then
						CW.player:Notify(player, fault);
					end;
				end;
			else
				CW.player:Notify(player, L("ClassNoAccess"));
			end;
		else
			CW.player:Notify(player, L("ClassTooMany"));
		end;
	else
		CW.player:Notify(player, L("ClassNotValid"));
	end;
end;

COMMAND:Register();