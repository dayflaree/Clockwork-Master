--[[
	� 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

CW.config:AddToSystem("Hunger Tick", "hunger_tick", "How quickly does hunger bar drain (higher = slower)", 0, 7200);
CW.config:AddToSystem("Hunger Default Refill", "hunger_default_refill", "Default amount of hunger to be restored when player eats food", 0, 100);