--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = CW.class:New("Rebel");
	CLASS.color = Color(230, 100, 100, 255);
	CLASS.factions = {FACTION_REBEL};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "A member of rebelious gang.";
	CLASS.defaultPhysDesc = "Wearing clothes.";
CLASS_REBEL = CLASS:Register();