--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.bans = CW.kernel:NewLibrary("Bans");
CW.bans.stored = CW.bans.stored or {};

--[[
	A local function to handle ban deletion.
	INTERNAL USE ONLY. DO NOT USE.
--]]
local function DELETE_BAN(identifier)
	CW.bans.stored[identifier] = nil;
	
	local queryObj = CW.database:Delete(bansTable);
		queryObj:AddWhere("_Schema = ?", schemaFolder);
		queryObj:AddWhere("_Identifier = ?", identifier);
	queryObj:Push();
end;

--[[
	A local function to handle the loading of bans.
	INTERNAL USE ONLY. DO NOT USE.
--]]
local function BANS_LOAD_CALLBACK(result)
	if (CW.database:IsResult(result)) then
		CW.bans.stored = CW.bans.stored or {};
		
		for k, v in pairs(result)do
			CW.bans.stored[v._Identifier] = {
				unbanTime = tonumber(v._UnbanTime),
				steamName = v._SteamName,
				duration = tonumber(v._Duration),
				reason = v._Reason
			};
		end;
	end;
end

-- A function to load the bans.
function CW.bans:Load()
	local bansTable = CW.config:Get("mysql_bans_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local queryObj = CW.database:Select(bansTable);
		queryObj:SetCallback(BANS_LOAD_CALLBACK);
		queryObj:AddWhere("_Schema = ?", schemaFolder);
	queryObj:Pull();
	
	local unixTime = os.time();
		
	for k, v in pairs(self.stored) do
		if (type(v) == "table") then
			if (v.unbanTime > 0 and unixTime >= v.unbanTime) then
				self:Remove(k, true);
			end;
		else
			DELETE_BAN(k);
		end;
	end;
end;

-- A function to add a ban.
function CW.bans:Add(identifier, duration, reason, Callback, bSaveless)
	local steamName = nil;
	local playerGet = CW.player:FindByID(identifier);
	local bansTable = CW.config:Get("mysql_bans_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();
		
	if (identifier) then
		identifier = string.upper(identifier);
	end;
		
	for k, v in pairs(_player.GetAll()) do
		local playerIP = v:IPAddress();
		local playerSteam = v:SteamID();
			
		if (playerSteam == identifier or playerIP == identifier or playerGet == v) then
			plugin.Call("PlayerBanned", v, duration, reason);
			
			if (playerIP == identifier) then
				identifier = playerIP;
			else
				identifier = playerSteam;
			end;
				
			steamName = v:SteamName();
			v:Kick(reason);
		end;
	end;
		
	if (!reason) then
		reason = "Banned for an unspecified reason.";
	end;
		
	if (steamName) then
		if (duration == 0) then
			self.stored[identifier] = {
				unbanTime = 0,
				steamName = steamName,
				duration = duration,
				reason = reason
			};
		else
			self.stored[identifier] = {
				unbanTime = os.time() + duration,
				steamName = steamName,
				duration = duration,
				reason = reason
			};
		end;
		
		if (!bSaveless) then
			local queryObj = CW.database:Insert(bansTable);
				queryObj:SetValue("_Identifier", identifier);
				queryObj:SetValue("_UnbanTime", self.stored[identifier].unbanTime);
				queryObj:SetValue("_SteamName", self.stored[identifier].steamName);
				queryObj:SetValue("_Duration", self.stored[identifier].duration);
				queryObj:SetValue("_Reason", self.stored[identifier].reason);
				queryObj:SetValue("_Schema", schemaFolder);
			queryObj:Push();
		end;
		
		if (Callback) then
			Callback(steamName, duration, reason);
		end;
		
		return;
	end;
	
	local playersTable = CW.config:Get("mysql_players_table"):Get();
	
	if (string.find(identifier, "STEAM_(%d+):(%d+):(%d+)")) then
		local queryObj = CW.database:Select(playersTable);
			queryObj:AddWhere("_SteamID = ?", identifier);
			queryObj:SetCallback(function(result)
				local steamName = identifier;
				
				if (CW.database:IsResult(result)) then
					steamName = result[1]._SteamName;
				end;
					
				if (duration == 0) then
					self.stored[identifier] = {
						unbanTime = 0,
						steamName = steamName,
						duration = duration,
						reason = reason
					};
				else
					self.stored[identifier] = {
						unbanTime = os.time() + duration,
						steamName = steamName,
						duration = duration,
						reason = reason
					};
				end;
				
				if (!bSaveless) then
					local insertObj = CW.database:Insert(bansTable);
						insertObj:SetValue("_Identifier", identifier);
						insertObj:SetValue("_UnbanTime", self.stored[identifier].unbanTime);
						insertObj:SetValue("_SteamName", self.stored[identifier].steamName);
						insertObj:SetValue("_Duration", self.stored[identifier].duration);
						insertObj:SetValue("_Reason", self.stored[identifier].reason);
						insertObj:SetValue("_Schema", schemaFolder);
					insertObj:Push();
				end;
				
				if (Callback) then
					Callback(steamName, duration, reason);
				end;
			end);
		queryObj:Pull();
		
		return;
	end;
	
	--[[ In this case we're banning them by their IP address. --]]
	if (string.find(identifier, "%d+%.%d+%.%d+%.%d+")) then
		local queryObj = CW.database:Select(playersTable);	
			queryObj:SetCallback(function(result)
				local steamName = identifier;
				
				if (CW.database:IsResult(result)) then
					steamName = result[1]._SteamName;
				end;
				
				if (duration == 0) then
					self.stored[identifier] = {
						unbanTime = 0,
						steamName = steamName,
						duration = duration,
						reason = reason
					};
				else
					self.stored[identifier] = {
						unbanTime = os.time() + duration,
						steamName = steamName,
						duration = duration,
						reason = reason
					};
				end;
				
				if (!bSaveless) then
					local insertObj = CW.database:Insert(bansTable);
						insertObj:SetValue("_Identifier", identifier);
						insertObj:SetValue("_UnbanTime", self.stored[identifier].unbanTime);
						insertObj:SetValue("_SteamName", self.stored[identifier].steamName);
						insertObj:SetValue("_Duration", self.stored[identifier].duration);
						insertObj:SetValue("_Reason", self.stored[identifier].reason);
						insertObj:SetValue("_Schema", schemaFolder);
					insertObj:Push();
				end;
				
				if (Callback) then
					Callback(steamName, duration, reason);
				end;
			end);
			queryObj:AddWhere("_IPAddress = ?", identifier);
		queryObj:Pull();
		
		return;
	end;
	
	if (duration == 0) then
		self.stored[identifier] = {
			unbanTime = 0,
			steamName = steamName,
			duration = duration,
			reason = reason
		};
	else
		self.stored[identifier] = {
			unbanTime = os.time() + duration,
			steamName = steamName,
			duration = duration,
			reason = reason
		};
	end;
	
	if (!bSaveless) then
		local queryObj = CW.database:Insert(bansTable);
			queryObj:SetValue("_Identifier", identifier);
			queryObj:SetValue("_UnbanTime", self.stored[identifier].unbanTime);
			queryObj:SetValue("_SteamName", self.stored[identifier].steamName);
			queryObj:SetValue("_Duration", self.stored[identifier].duration);
			queryObj:SetValue("_Reason", self.stored[identifier].reason);
			queryObj:SetValue("_Schema", schemaFolder);
		queryObj:Push();
	end;
	
	if (Callback) then
		Callback(steamName, duration, reason);
	end;
end;

-- A function to remove a ban.
function CW.bans:Remove(identifier, bSaveless)
	local bansTable = CW.config:Get("mysql_bans_table"):Get();
	local schemaFolder = CW.kernel:GetSchemaFolder();

	if (self.stored[identifier]) then
		self.stored[identifier] = nil;
		
		if (!bSaveless) then
			local queryObj = CW.database:Delete(bansTable);
				queryObj:AddWhere("_Schema = ?", schemaFolder);
				queryObj:AddWhere("_Identifier = ?", identifier);
			queryObj:Push();
		end;
	end;
end;