--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.bars = CW.kernel:NewLibrary("Bars");
CW.bars.x = 0; 
CW.bars.y = 0;
CW.bars.width = 0;
CW.bars.height = 12;
CW.bars.padding = 14;
CW.bars.stored = CW.bars.stored or {};

-- A function to get a top bar.
function CW.bars:FindByID(uniqueID)
	for k, v in pairs(self.stored) do
		if (v.uniqueID == uniqueID) then return v; end;
	end;
end;
	
-- A function to add a top bar.
function CW.bars:Add(uniqueID, color, text, value, maximum, flash, priority)
	self.stored[#self.stored + 1] = {
		uniqueID = uniqueID,
		priority = priority or 0,
		maximum = maximum,
		color = color,
		class = class,
		value = value,
		flash = flash,
		text = text,
	};
end;

-- A function to destroy a top bar.
function CW.bars:Destroy(uniqueID)
	for k, v in pairs(self.stored) do
		if (v.uniqueID == uniqueID) then
			table.remove(self.stored, k);
		end;
	end;
end;