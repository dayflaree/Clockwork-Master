--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyBan");
COMMAND.tip = "Ban a player from the server.";
COMMAND.text = "<string Name|SteamID|IPAddress> <number Minutes> [string Reason]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Ban"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local duration = tonumber(arguments[2]);
	local reason = table.concat(arguments, " ", 3);
	
	if (!reason or reason == "") then
		reason = nil;
	end;
	
	if (!CW.player:IsProtected(arguments[1])) then
		if (duration) then
			CW.bans:Add(arguments[1], duration * 60, reason, function(steamName, duration, reason)
				if (IsValid(player)) then
					if (steamName) then
						if (duration > 0) then
							local hours = math.Round(duration / 3600);
							
							if (hours >= 1) then
								CW.player:NotifyAll(player:Name().." has banned '"..steamName.."' for "..hours.." hour(s) ("..reason..").");
							else
								CW.player:NotifyAll(player:Name().." has banned '"..steamName.."' for "..math.Round(duration / 60).." minute(s) ("..reason..").");
							end;
						else
							CW.player:NotifyAll(player:Name().." has banned '"..steamName.."' permanently ("..reason..").");
						end;
					else
						CW.player:Notify(player, "This is not a valid identifier!");
					end;
				end;
			end);
		else
			CW.player:Notify(player, "This is not a valid duration!");
		end;
	else
		local target = CW.player:FindByID(arguments[1]);
		
		if (target) then
			CW.player:Notify(player, target:Name().." is protected!");
		else
			CW.player:Notify(player, "This player is protected!");
		end;
	end;
end;

COMMAND:Register();