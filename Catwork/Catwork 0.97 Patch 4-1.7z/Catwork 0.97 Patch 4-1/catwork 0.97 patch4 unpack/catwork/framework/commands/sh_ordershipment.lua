--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("OrderShipment");
COMMAND.tip = "Order an item shipment at your target position.";
COMMAND.text = "<string UniqueID>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local itemTable = CW.item:FindByID(arguments[1]);
	
	if (!itemTable or !itemTable:CanBeOrdered()) then
		return false;
	end;
	
	itemTable = CW.item:CreateInstance(itemTable("uniqueID"));
	plugin.Call("PlayerAdjustOrderItemTable", player, itemTable);
	
	if (!CW.kernel:HasObjectAccess(player, itemTable)) then
		CW.player:Notify(player, "You not have access to order this item!");
		return false;
	end;
	
	if (!plugin.Call("PlayerCanOrderShipment", player, itemTable)) then
		return false;
	end;
	
	if (player.cwNextOrderTime and CurTime() < player.cwNextOrderTime) then
		return false;
	end;
	
	if (itemTable:CanPlayerAfford(player)) then
		local trace = player:GetEyeTraceNoCursor();
		local entity = nil;

		if (player:GetShootPos():Distance(trace.HitPos) <= 192) then
			if (itemTable.CanOrder and itemTable:CanOrder(player, v) == false) then
				return false;
			end;
			
			if (itemTable.OnCreateShipmentEntity) then
				entity = itemTable:OnCreateShipmentEntity(player, itemTable("batch"), trace.HitPos);
			end;
			
			if (!IsValid(entity)) then
				if (itemTable("batch") > 1) then
					entity = CW.entity:CreateShipment(player, itemTable("uniqueID"), itemTable("batch"), trace.HitPos);
				else
					entity = CW.entity:CreateItem(player, itemTable, trace.HitPos);
				end;
			end;
			
			if (IsValid(entity)) then
				CW.entity:MakeFlushToGround(entity, trace.HitPos, trace.HitNormal);
			end;
			
			itemTable:DeductFunds(player);
			
			if (itemTable("batch") > 1 and entity.cwInventory) then
				local itemTables = CW.inventory:GetItemsByID(
					entity.cwInventory, itemTable("uniqueID")
				);
				
				for k, v in pairs(itemTables) do
					if (v.OnOrder) then
						v:OnOrder(player, entity);
					end;
				end;
				
				plugin.Call("PlayerOrderShipment", player, itemTable, entity, itemTables);
			else
				if (entity.GetItemTable) then
					itemTable = entity:GetItemTable();
				end;
				
				plugin.Call("PlayerOrderShipment", player, itemTable, entity);
				
				if (itemTable.OnOrder) then
					itemTable:OnOrder(player, entity);
				end;
			end;
			
			player.cwNextOrderTime = CurTime() + (2 * itemTable("batch"));
			netstream.Start(player, "OrderTime", player.cwNextOrderTime);
		else
			CW.player:Notify(player, "You cannot order this item that far away!");
		end;
	else
		local amount = (itemTable("cost") * itemTable("batch")) - player:GetCash();
		CW.player:Notify(player, "You need another "..CW.kernel:FormatCash(amount, nil, true).."!");
	end;
end;

COMMAND:Register();