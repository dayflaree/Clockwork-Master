local ITEM = CW.item:New("cpoutfit_base")
ITEM.uniqueID = "cp_standard_medic"
ITEM.name = "Set of Civil Protection outfit: Standard 'Medic'"
ITEM.PrintName = "Комплект экипировки ГО: Стандартный медицинский"
ITEM.model = "models/props_c17/SuitCase001a.mdl"
ITEM.weight = 5
ITEM.category = "Гражданская Оборона - Комплекты"
ITEM.description = "Стандартная экипировка медика Гражданской Обороны."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = {
	uniform = "1",
	bodygroups = "0000000000",
	gasmask = "0",
	gasmaskshock = "0",
	glow = "1"
}
ITEM.cparmband = nil
ITEM.cppvisor = "-1_-1_-1"
ITEM.cpsvisor = "5_3_1"
ITEM.rank = nil

ITEM:Register()