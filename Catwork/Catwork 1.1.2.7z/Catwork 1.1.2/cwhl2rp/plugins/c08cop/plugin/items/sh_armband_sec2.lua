local ITEM = CW.item:New("cpoutfit_base")
ITEM.uniqueID = "armband_sec2"
ITEM.name = "Armband: 'SeC sign'"
ITEM.PrintName = "Повязка: 'SeC sign'"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.1
ITEM.category = "Гражданская Оборона - Повязки"
ITEM.description = "Серая повязка, на которой написано 'c14:SeC sign'. На ней также изображен зеленый символ City-14."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = nil
ITEM.cparmband = "(255,255,255)_10_(0,0,0,0)_0_(0,0,0,0)_0"
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = "SeC"

ITEM:Register()