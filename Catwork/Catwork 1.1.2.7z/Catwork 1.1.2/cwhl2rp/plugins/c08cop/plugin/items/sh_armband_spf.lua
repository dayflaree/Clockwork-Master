local ITEM = CW.item:New("cpoutfit_base")
ITEM.uniqueID = "armband_spf"
ITEM.name = "Armband: 'SpF'"
ITEM.PrintName = "Повязка: 'SpF'"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.1
ITEM.category = "Гражданская Оборона - Повязки"
ITEM.description = "Серая повязка, на которой написано 'c14:SpF'. На ней также изображен красный символ City-14."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = nil
ITEM.cparmband = "(255,255,255)_2_(183,48,41,250)_1_(160,188,176,200)_8"
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = "SpF"

ITEM:Register()