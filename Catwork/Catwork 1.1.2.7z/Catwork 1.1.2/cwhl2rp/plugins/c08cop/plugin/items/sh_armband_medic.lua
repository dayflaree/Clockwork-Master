local ITEM = CW.item:New("cpoutfit_base")
ITEM.uniqueID = "armband_medic"
ITEM.name = "Armband: 'Medic'"
ITEM.PrintName = "Повязка: 'Медик'"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.1
ITEM.category = "Гражданская Оборона - Повязки"
ITEM.description = "Белая повязка с красным крестом."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = nil
ITEM.cparmband = "(255,255,255)_7_(0,0,0,0)_0_(0,0,0,0)_0"
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = nil

ITEM:Register()