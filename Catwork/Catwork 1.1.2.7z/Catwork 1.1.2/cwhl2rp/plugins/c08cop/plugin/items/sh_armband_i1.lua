local ITEM = CW.item:New("cpoutfit_base")
ITEM.uniqueID = "armband_i1"
ITEM.name = "Armband: 'i1'"
ITEM.PrintName = "Повязка: 'i1'"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.1
ITEM.category = "Гражданская Оборона - Повязки"
ITEM.description = "Серая повязка, на которой написано 'c14:i1'. На ней также изображен зеленый символ City-14."
ITEM.access = "1cp"
ITEM.business = true

ITEM.cpoutfit = nil
ITEM.cparmband = "(255,255,255)_2_(183,48,41,250)_1_(160,188,176,200)_16"
ITEM.cppvisor = nil
ITEM.cpsvisor = nil
ITEM.rank = "i1"

ITEM:Register()