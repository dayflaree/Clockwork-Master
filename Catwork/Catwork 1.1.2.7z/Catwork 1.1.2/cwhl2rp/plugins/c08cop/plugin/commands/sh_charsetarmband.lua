--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = CW.command:New("CharSetArmband")
COMMAND.tip = "Set a Civil Protection armband"
COMMAND.text = "<string Name> <string Armband Code>"
COMMAND.flags = bit.bor(CMD_DEFAULT)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if target then
		if player:IsAdmin() or Schema:IsPlayerCombineRank(player, {"SeC", "CmD", "MaJ", "CpT"}) then
			local text = table.concat(arguments, " ", 2)

			if text == "" then
				return
			end

			if string.find(text, "%(%d+,%d+,%d+%)_(%d+)_%((%d+),(%d+),(%d+),(%d+)%)_(%d+)_%((%d+),(%d+),(%d+),(%d+)%)_(%d+)") then
				target:SetCharacterData("CP08_Armband", text)
				ReadCPArmband(target, text)
				CW.player:Notify(player, "You have changed character's Civil Protection armband successfull.")
			else
				CW.player:Notify(player, "Not valid armband code.")
			end
		else
			CW.player:Notify(player, "У вас нет прав.")
		end
	else
		CW.player:Notify(player, L(player, "NotValidCharacter", arguments[1]))
	end
end

COMMAND:Register();