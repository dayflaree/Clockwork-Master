local PLUGIN = PLUGIN
local Clockwork = Clockwork

CreateConVar("cl_qcop_radio", "say", { FCVAR_ARCHIVE, FCVAR_USERINFO, FCVAR_DONTRECORD }, "")

local surface = surface
local IsValid = IsValid
local mathmax = math.max
local CurTime = CurTime
local pairs = pairs
local tonumber = tonumber

local weapons = {"sxbase_", "weapon_"}
local function checkWeapon(weapon)
	for k, v in pairs(weapons) do
		if string.find(weapon,v) then
			return true
		end
	end
end

concommand.Add("cp_spotting", function()
	if Schema:PlayerIsCombine(LocalPlayer()) then
		local ent = LocalPlayer():GetEyeTrace().Entity
		if ent:IsPlayer() or ent:IsNPC() then
			net.Start("CP_Spotted")
				net.WriteString(ent:EntIndex())
			net.SendToServer()
		end
	end
end)

local spotted = {}
local function isAlreadySpotted(ent)
	for k, v in pairs(spotted) do
		if v.ent == ent then
			return spotted[k]
		end
	end
end

hook.Add("HUDPaint", "CP_SPOT", function()
	for k, v in pairs(spotted) do
		if !IsValid(v.ent) then spotted[k] = nil continue end
		if CurTime() >= v.dur then spotted[k] = nil continue end

		local size = ScreenScaleZ(3)

		local pos = v.ent:GetPos():ToScreen()
		local head = v.ent:LookupBone("ValveBiped.Bip01_Head1")
		if head then
			headpos, headang = v.ent:GetBonePosition(head)
			pos = headpos
			pos.z = pos.z + (11 * mathmax(v.ent:GetPos():Distance(LocalPlayer():GetPos()) / 1500,1))
			pos = pos:ToScreen()
		else
			pos = v.ent:GetPos()
			pos.z = pos.z + (11 * mathmax(v.ent:GetPos():Distance(LocalPlayer():GetPos()) / 1500,1)) + v.ent:OBBMaxs().z/2
			pos = pos:ToScreen()
		end

		local tri = {
			{ x = pos.x - size - 1, y = pos.y + 1},
			{ x = pos.x - 1, y = pos.y - (size * 2.5) + 1},
			{ x = pos.x + size - 1, y = pos.y + 1}
		}
		surface.SetDrawColor(0, 0, 0, 200)
		draw.NoTexture()
		surface.DrawPoly(tri)

		local tri = {
			{ x = pos.x - size, y = pos.y },
			{ x = pos.x, y = pos.y - (size * 2.5) },
			{ x = pos.x + size, y = pos.y }
		}
		local color = Color(255, 200, 50, 255)
		if IsValid(v.ent:GetActiveWeapon()) and v.ent:IsNPC() then
			if checkWeapon(v.ent:GetActiveWeapon():GetClass()) then
				color = Color(255, 50, 50, 255)
			end
		end

		if v.ent:IsPlayer() then
			if Schema:PlayerIsCombine(LocalPlayer()) and Schema:PlayerIsCombine(v.ent) then
				color = Color(50, 255, 50, 255)
			end
		end

		surface.SetDrawColor(color)
		draw.NoTexture()
		surface.DrawPoly(tri)
	end
end)

net.Receive("CP_SpottedSend",function()
	local entid = net.ReadString()
	local duration = net.ReadString()

	local ent = Entity(entid)
	if IsValid(ent) then
		if ent == LocalPlayer() then return end

		local spot = isAlreadySpotted(ent)
		if !spot then
			local spotdata = {
				dur = CurTime() + tonumber(duration),
				ent = ent
			}
			table.insert(spotted, spotdata)
		else
			spot.dur = CurTime() + tonumber(duration)
		end
	end
end)

local CUSTOM_KEYS = {}
CUSTOM_KEYS[KEY_Z] = { command = "radio1" }
CUSTOM_KEYS[KEY_X] = { command = "radio2" }
CUSTOM_KEYS[KEY_C] = { command = "radio3" }
CUSTOM_KEYS[KEY_T] = { command = "cp_spotting" }

local last = {}
local chatboxOpened = false

function PLUGIN:Think()
	for k,v in pairs(CUSTOM_KEYS ) do
		if !last[k] and input.IsKeyDown(k) and !chatbox.IsOpen() and !gui.IsGameUIVisible() then
			RunConsoleCommand(v.command)
			last[k] = true
		end
		if !input.IsKeyDown(k) and last[k] then
			last[k] = false
		end
	end
end
function PLUGIN:ChatBoxOpened()
	chatboxOpened = true
end
function PLUGIN:ChatBoxClosed()
	chatboxOpened = false
end

function ScreenScaleZ(num)
	return (ScrH() / 480) * num
end
surface.CreateFont("RadioFont", {
	font = "Consolas",
	size = 19,
	weight = 1000,
	blursize = 0,
	scanlines = 0,
	antialias = true,
})
local rendertarget_radiomenu = GetRenderTargetEx("RadioMenu", ScreenScaleZ(256), ScreenScaleZ(256), RT_SIZE_DEFAULT, MATERIAL_RT_DEPTH_SHARED, 0, CREATERENDERTARGETFLAGS_AUTOMIPMAP, IMAGE_FORMAT_DEFAULT)
local radiomenu_mat = CreateMaterial("_RadioMenuMat", "UnlitGeneric", {
	["$vertexcolor"] = 1,
	["$vertexalpha"] = 1,
	["$additive"] = 1,
})

local PANEL = {}
function PANEL:Init()
	cpgui_radiomenu = self
	self:SetPos(20, 0)
	self:SetSize(ScreenScaleZ(512), ScreenScaleZ(256))

	self.Height = 0
	self.Buttons = {}
end
function PANEL:AddButton(text, bind, onclick, color)
	local tbl = {
		text = text,
		onclick = onclick,
		color = color,
		bind = bind,
	}
	table.insert(self.Buttons, tbl)
end
function PANEL:Paint(w, h)
	render.PushRenderTarget(rendertarget_radiomenu)
		render.Clear(0, 0, 0, 255)
		render.PushFilterMin(TEXFILTER.POINT)
		cam.Start2D()
			surface.SetFont("RadioFont")
			local w_text, h_text = surface.GetTextSize("B")
			self.Height = 0
			for k, v in pairs(self.Buttons) do
				if v.color then
					surface.SetTextColor(v.color)
					self.Height = 5
				else
					surface.SetTextColor(Color(255, 255, 255))
				end
				surface.SetTextPos(h_text, h_text / 2 + self.Height)
				surface.DrawText(v.text)
				self.Height = self.Height + h_text + 5
			end
		cam.End2D()
		render.PopFilterMin()
	render.PopRenderTarget()

	radiomenu_mat:SetTexture("$basetexture", rendertarget_radiomenu)
	surface.SetMaterial(Material("gui/gradient"))
	surface.SetDrawColor(Color(0, 0, 0, 200))
	surface.DrawTexturedRect(20, 0, ScreenScaleZ(160), self.Height  + 10)

	surface.SetMaterial(radiomenu_mat)
	surface.SetDrawColor(Color(255, 255, 255))
	surface.DrawTexturedRect(20, 0, ScreenScaleZ(256), ScreenScaleZ(256))
end
function PANEL:PerformLayout()
	surface.SetFont("RadioFont")
	local w_text, h_text = surface.GetTextSize("B")
	self:SetPos(0, ScrH() / 2 - ((h_text + 5) * #self.Buttons) / 2)
end
function PANEL:CallMenu(slot)
	if slot then
		for k, v in pairs(self.Buttons) do
			if v.bind and v.bind == slot then
				if v.onclick then
					v.onclick()
					return
				end
			end
		end

		self:Close()
		return
	end
end
function PANEL:Close()
	self:Remove()
	cpgui_radiomenu = nil
end
vgui.Register("CP_Radiomenu", PANEL, "EditablePanel")


local function GetFuncGP(command, typ)
	if !cpgui_radiomenu then return end

	local sector = "_"..typ
	RunConsoleCommand(command .. sector)
	cpgui_radiomenu:Close()
end
local function GetFuncCode(command, typ)
	if !cpgui_radiomenu then return end

	if command == "r_doc_backup" then
		local sector = "_"..typ
		OpenRadiomenu1_Code(typ, command .. sector)
	else
		local sector = "_"..typ
		RunConsoleCommand(command .. sector)
		cpgui_radiomenu:Close()
	end
end

function OpenRadiomenu1_Block(typ, command)
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end

	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton("Жилой Блок", nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. 'A'", 1, function()
		GetFuncCode(command, "block_a")
	end)
	cpgui_radiomenu:AddButton("2. 'B'", 2, function()
		GetFuncCode(command, "block_b")
	end)
	cpgui_radiomenu:AddButton("3. 'C'", 3, function()
		GetFuncCode(command, "block_c")
	end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end

function OpenRadiomenu1_Code(typ, command)
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end

	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton("Выберите код", nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. КОД 1", 1, function()
		GetFuncGP(command, "1")
	end)
	cpgui_radiomenu:AddButton("2. КОД 2", 2, function()
		GetFuncGP(command, "2")
	end)
	cpgui_radiomenu:AddButton("3. КОД 3", 3, function()
		GetFuncGP(command, "3")
	end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end

function OpenRadiomenu1_Sector(typ)
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end
	local title = ""
	local command = ""
	if typ == "my1020" then
		title = "Доложить своё 10-20"
		command = "r_doc_my1020"
	elseif typ == "404" then
		title = "Возможно замечен 404"
		command = "r_doc_404"
	elseif typ == "biotics" then
		title = "Возможны биотики/нежить"
		command = "r_doc_biotics"
	elseif typ == "backup" then
		title = "Запрос поддержки"
		command = "r_doc_backup"
	elseif typ == "leave" then
		title = "Покидаю пост/район"
		command = "r_doc_leave"
	end

	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton(title, nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. Главная Площадь", 1, function()
		GetFuncCode(command, "gp")
	end)
	cpgui_radiomenu:AddButton("2. Офис ГСР", 2, function()
		GetFuncCode(command, "cwu")
	end)
	cpgui_radiomenu:AddButton("3. Жилой Блок...", 3, function()
		OpenRadiomenu1_Block(typ,command)
	end)
	cpgui_radiomenu:AddButton("4. D-1", 4, function()
		GetFuncCode(command, "d1")
	end)
	cpgui_radiomenu:AddButton("5. D-2", 5, function()
		GetFuncCode(command, "d2")
	end)
	cpgui_radiomenu:AddButton("6. D-3", 6, function()
		GetFuncCode(command, "d3")
	end)
	cpgui_radiomenu:AddButton("7. D-4", 7, function()
		GetFuncCode(command, "d4")
	end)
	cpgui_radiomenu:AddButton("8. D-5", 8, function()
		GetFuncCode(command, "d5")
	end)
	cpgui_radiomenu:AddButton("9. D-6", 9, function()
		GetFuncCode(command, "d6")
	end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end

function OpenRadiomenu1()
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end
	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton("Быстрые радиокоманды", nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. Доклад о своем 10-20", 1, function() OpenRadiomenu1_Sector("my1020") end)
	cpgui_radiomenu:AddButton("2. Возможно замечен 404", 2, function() OpenRadiomenu1_Sector("404") end)
	cpgui_radiomenu:AddButton("3. Доклад о состоянии местности вокруг", 3, function() RunConsoleCommand("r_doc_status") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("4. Доклад о своём здоровье/броне", 4, function() RunConsoleCommand("r_doc_health") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("5. Возможны биотики/нежить", 5, function() OpenRadiomenu1_Sector("biotics") end)
	cpgui_radiomenu:AddButton("6. Запрос поддержки", 6, function() OpenRadiomenu1_Sector("backup") end)
	cpgui_radiomenu:AddButton("7. Покидаю пост/район", 7, function() OpenRadiomenu1_Sector("leave") end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end
function OpenRadiomenu2()
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end
	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton("Локальные команды", nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. Гражданин", 1, function() RunConsoleCommand("r_citizen") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("2. Стоять на месте", 2, function() RunConsoleCommand("r_dontmove") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("3. Побег, приоритет два", 3, function() RunConsoleCommand("r_escape") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("4. Нарушитель", 4, function() RunConsoleCommand("r_anticitizen") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("5. Свершение приговора", 5, function() RunConsoleCommand("r_judge") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("6. Готов к отсечению!", 6, function() RunConsoleCommand("r_amputateready") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("7. Отсечь", 7, function() RunConsoleCommand("r_amputate") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("8. Двигаюсь на точку", 8, function() RunConsoleCommand("r_hardpoint") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("9. Проходи!", 9, function() RunConsoleCommand("r_movealong") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end
function OpenRadiomenu3()
	if !Schema:PlayerIsCombine(LocalPlayer()) then return end
	if !LocalPlayer():Alive() then return end
	if cpgui_radiomenu then
		cpgui_radiomenu:Remove()
		cpgui_radiomenu = nil
	end
	vgui.Create("CP_Radiomenu")
	cpgui_radiomenu:AddButton("Локальные команды #2", nil, function() end, Color(125, 250, 255))
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("1. Вижу цель! Вижу цель!", 1, function() RunConsoleCommand("r_gosharp") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("2. Тяжелое сопротивление", 2, function() RunConsoleCommand("r_heavyresist") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("3. Малые ранения", 3, function() RunConsoleCommand("r_minorhits") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("4. Некротики", 4, function() RunConsoleCommand("r_necrotics") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("5. Нарушитель вооружен", 5, function() RunConsoleCommand("r_505") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("6. Приготовиться к штурму", 6, function() RunConsoleCommand("r_inject") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("7. Чисто", 7, function() RunConsoleCommand("r_cleaned") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("8. Отступаем", 8, function() RunConsoleCommand("r_backup") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("9. Двигайся внутрь!", 9, function() RunConsoleCommand("r_movein") cpgui_radiomenu:Close() end)
	cpgui_radiomenu:AddButton("")
	cpgui_radiomenu:AddButton("0. Выход", 0, function() cpgui_radiomenu:Remove() end)
end

concommand.Add("radio1", function() OpenRadiomenu1() end)
concommand.Add("radio2", function() OpenRadiomenu2() end)
concommand.Add("radio3", function() OpenRadiomenu3() end)