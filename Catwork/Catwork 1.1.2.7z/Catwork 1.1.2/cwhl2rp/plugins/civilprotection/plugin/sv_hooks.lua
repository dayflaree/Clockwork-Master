local PLUGIN = PLUGIN

CW.player:AddCharacterData("cp_traitpoints", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_lid", NWTYPE_STRING, "#NONE", true)
CW.player:AddCharacterData("civ_reputation", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_blackmarks", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_status", NWTYPE_STRING, "NON-CITIZEN", true)
CW.player:AddCharacterData("civ_jail_type", NWTYPE_STRING, "#N", true)
CW.player:AddCharacterData("civ_jail_time", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_city", NWTYPE_STRING, "#NONE", true)
CW.player:AddCharacterData("civ_wp", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_loyalboost", NWTYPE_NUMBER, 0, true)
CW.player:AddCharacterData("civ_faction", NWTYPE_STRING, "#NONE", true)

function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (data["civ_jail_type"] == "None") then
		data["civ_jail_type"] = "#N"
	end

	if (!data["cp_traitpoints"]) then
		data["cp_traitpoints"] = 0
	end
	if (!data["civ_reputation"]) then
		data["civ_reputation"] = 0
	end
	if (!data["civ_blackmarks"]) then
		data["civ_blackmarks"] = 0
	end
	if (!data["civ_lid"]) then
		data["civ_lid"] = "#NONE"
	end
	if (!data["civ_status"]) then
		data["civ_status"] = "NON-CITIZEN"
	end
	if (!data["civ_jail_type"]) then
		data["civ_jail_type"] = "#N"
	end
	if (!data["civ_jail_time"]) then
		data["civ_jail_time"] = 0
	end
	if (!data["civ_city"]) then
		data["civ_city"] = "#NONE"
	end
	if (!data["civ_wp"]) then
		data["civ_wp"] = 0
	end
	if (!data["civ_loyalboost"]) then
		data["civ_loyalboost"] = 0
	end
	if (!data["civ_faction"]) then
		data["civ_faction"] = "#NONE"
	end
end

function PLUGIN:PlayerThink(player, curTime, infoTable)
	local faction = player:GetFaction()
	local location = Schema:PlayerGetLocation(player)

	if !player.nextAssign or CurTime() >= player.nextAssign then
		if player:Alive() and !player:IsRagdolled() then
			if player:GetCharacterData("civ_lid") == "#NONE" or player:GetCharacterData("civ_city") != "#N" then	
				local appID = table.Random({"C101", "C102", "C103", "C201", "C202", "C203"})

				player:SetCharacterData("civ_lid", appID)
				player:SetCharacterData("civ_wp", 0)
				player:SetCharacterData("civ_loyalboost", 0)
				--player:SetCharacterData("civ_reputation", 0)
				--player:SetCharacterData("civ_blackmarks", 0)
				--player:SetCharacterData("civ_status", "CITIZEN")
				player:SetCharacterData("civ_jail_type", "#N")
				player:SetCharacterData("civ_jail_time", 0)
				player:SetCharacterData("civ_city", "#N")

				if faction == FACTION_CITIZEN then
					player:SendLua("LocalPlayer():EmitSound('ambient/alarms/train_horn2.wav', 100, 100)")

					--CW.chatBox:SendColored(player, Color(50, 100, 150), "Информационная система "..Schema.City..": ''<:: Гражданин ", Color(255, 255, 255), ""..string.upper(player:Name()).." #"..player:GetCharacterData("citizenid").."", Color(50, 100, 150), ", Альянс приветствует вас в Сити 17/47.''")
					--CW.chatBox:SendColored(player, Color(50, 100, 150), "Информационная система "..Schema.City..": ''<:: Вы были заселены в апартаменты ", Color(255, 255, 255), ""..appID.."", Color(50, 100, 150), ".''")
					chatbox.AddText(player, "\"".."Гражданин "..string.upper(player:Name()).." #"..player:GetCharacterData("citizenid")..", Альянс приветствует Вас в "..Schema.City..".\"", {sender = player, suffix = ": ", playerName = "Информационная система "..Schema.City, forceName = true, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(50, 100, 150, 255), data = {dispatch = true}})
					chatbox.AddText(player, "\"".."Вы были заселены в апартаменты "..appID..".\"", {sender = player, suffix = ": ", playerName = "Информационная система "..Schema.City, forceName = true, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(50, 100, 150, 255), data = {dispatch = true}})
				end
			end
		end
		player.nextAssign = CurTime() + 1
	end

	local jailtime = player:GetCharacterData("civ_jail_time")
	local jailtype = player:GetCharacterData("civ_jail_type")

	if !player.isolationTimer or CurTime() >= player.isolationTimer then
		if faction != FACTION_MPF and faction != FACTION_OTA then
			if player:GetCharacterData("civ_jail_type") != "#N" and player:GetCharacterData("civ_jail_time") > 0 then	
				player:SetCharacterData("civ_jail_time", player:GetCharacterData("civ_jail_time") - 1)
			end
		end
		player.isolationTimer = CurTime() + 1
	end
	if !player.isolationRemind or CurTime() >= player.isolationRemind then
		if faction != FACTION_MPF and faction != FACTION_OTA then
			if player:GetCharacterData("civ_jail_type") != "#N" and player:GetCharacterData("civ_jail_time") == 0 then	
				for k, v in pairs(_player.GetAll()) do
					if v:Alive() then
						if v:GetFaction() == FACTION_MPF then
							chatbox.AddText(v, "Изоляция "..player:GetName().." #"..player:GetCharacterData("citizenid").." завершена, освободить гражданина.", {suffix = ": ", sender = combine, playerName = "Центр", forceName = true, isPlayerMessage = true, filter = "ic", radius = 0, textColor = Color(75, 150, 50, 255), data = {radio = true}})
						end
					end
				end
			end
		end
		player.isolationRemind = CurTime() + 40
	end	
end