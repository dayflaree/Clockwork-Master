local ITEM = CW.item:New()
ITEM.name = "Красная карта"
ITEM.uniqueID = "card_red"
ITEM.model = "models/cwu_card3.mdl"
ITEM.weight = 0.1
ITEM.description = "Пластиковая карточка красного цвета с символикой Альянса на ней."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();