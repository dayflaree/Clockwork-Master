local ITEM = CW.item:New()
ITEM.name = "Зелёная карта"
ITEM.uniqueID = "card_green"
ITEM.model = "models/cwu_card4.mdl"
ITEM.weight = 0.1
ITEM.description = "Пластиковая карточка зелёного цвета с символикой Альянса на ней."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();