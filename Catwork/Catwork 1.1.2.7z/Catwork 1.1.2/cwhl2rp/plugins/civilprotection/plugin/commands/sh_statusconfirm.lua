local COMMAND = CW.command:New("StatusConfirm")
COMMAND.tip = "Запрос подтверждения статуса гражданина."
COMMAND.text = "<string CID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine) or combine:GetFaction() == FACTION_CWU) then
		local stringCID = arguments[1]

		for k, citizen in pairs(player.GetAll()) do
			if (citizen:GetCharacterData("citizenid") == stringCID) then
				if (citizen:IsCitizen()) then				
					combine:CombineRequestSay("Запрашиваю подтверждения статуса гражданина #"..stringCID..".")
					citizen:SetCharacterData("civ_status", "CITIZEN")

					timer.Simple(1, function()
						combine:CombineRequestAnswer("Статус гражданина #"..stringCID.." изменён на: CITIZEN.")
					end)

					break
				end
			end
		end
	else
		CW.player:Notify(combine, "You are not a CWU!")
	end
end

COMMAND:Register();