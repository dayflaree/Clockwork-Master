local COMMAND = CW.command:New("CPInfoRequest")
COMMAND.tip = "Запрос информации о юните Гражданской Обороны."
COMMAND.text = "<string UID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if Schema:PlayerIsCombine(combine) then
		local UID = arguments[1]
		for k,v in pairs(player.GetAll()) do
			if Schema:PlayerIsCombine(v) then
				local digits = string.Right(v:GetName(), 3)
				if digits == UID then
					--if Schema:GetPlayerCombineRank(combine) > Schema:GetPlayerCombineRank(v) then
						local civ_citizenid = v:GetCharacterData("citizenid")
						local civ_lid = v:GetCharacterData("civ_lid")
						local cp_traitpoints = v:GetCharacterData("cp_traitpoints")

						combine:CombineRequestSay("Запрашиваю информацию о юните #"..digits..".")					
						timer.Simple(2, function()					
							combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
							combine:CombineRequestAnswer("Запрос информации о юните #"..digits.." был подтвержден.")
							combine:CombineRequestAnswer("ID: "..v:GetName()..".")
							combine:CombineRequestAnswer("Номер: "..digits..".")
							combine:CombineRequestAnswer("CID: "..(citizenid and citizenid or "#ERROR")..".")
							combine:CombineRequestAnswer("Апартаменты: "..(civ_lid and civ_lid or "#ERROR")..".")
							combine:CombineRequestAnswer("Очки выговора: "..cp_traitpoints..".")
						end)

						break
					--end
				end
			end
		end
	else
		CW.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();