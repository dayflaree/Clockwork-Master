local COMMAND = CW.command:New("OTAStasisState")
COMMAND.tip = "Включает/Выключает стазисное поле для OTA."
COMMAND.text = "<(0/1) disable/enable>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (combine:GetFaction() == FACTION_MPF) then
		if (Schema:IsPlayerCombineRank(combine, {"SeC","CmD"})) then
			local tr = (arguments[1] == "1") and true or false

			combine:EmitSound("npc/combine_soldier/vo/on2.wav")

			if (tr) then
				combine:CombineRequestSay("Центр, запрашиваю вывод сил OTA из стазиса.")
			else
				combine:CombineRequestSay("Центр, запрашиваю ввод сил OTA в стазис.")
			end

			timer.Simple(math.random(1,3), function()
				Schema.OTACanUse = tr

				combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
				if (tr) then
					combine:CombineRequestAnswer("Силы OTA были выведены из стазиса.")
				else
					combine:CombineRequestAnswer("Силы OTA были введены в стазис.")
				end
			end)
		end
	end
end

COMMAND:Register();