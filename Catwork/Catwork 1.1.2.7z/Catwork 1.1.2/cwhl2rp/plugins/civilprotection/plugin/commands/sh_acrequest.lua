--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]
local PLUGIN = PLUGIN

local COMMAND = CW.command:New("acrequest")
COMMAND.tip = "Запрос на изменение статуса гражданина."
COMMAND.text = "<string CID> <string status: CITIZEN/NON-CITIZEN/ANTI-CITIZEN>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) then
		if (Schema:IsPlayerCombineRank(combine, {"SeC","MaJ","CpT","OfC"})) then
			local target

			if (Schema:PlayerIsCombine(combine) and arguments[1]) then
				local CID = arguments[1]
				
				for k, v in pairs(player.GetAll()) do
					if (v:GetCharacterData("citizenid") == CID) then
						local verdict = arguments[2]

						combine:CombineRequestSay("Запрашиваю утверждение статуса "..verdict.." по гражданину #"..CID)

						if (verdict == "ANTI-CITIZEN" or verdict == "CITIZEN" or verdict == "NON-CITIZEN") then
							v:SetCharacterData("civ_status", verdict);	

							if (verdict == "ANTI-CITIZEN") then
								PLUGIN:CombineBroadcast("Гражданин #"..CID.." - "..v:GetName()..", Вы обвиняетесь в тяжком несоответствии. Асоциальный статус подтвержден.")
								BroadcastLua("LocalPlayer():EmitSound('npc/overwatch/cityvoice/f_capitalmalcompliance_spkr.wav')");	
							end									

							timer.Simple(2, function()
								if (combine:Alive()) then							
									combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
									combine:CombineRequestAnswer("Статус #"..CID.." изменён на: "..verdict)
								end
							end)

							break
						end
					end
				end
			end
		end
	else
		CW.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();