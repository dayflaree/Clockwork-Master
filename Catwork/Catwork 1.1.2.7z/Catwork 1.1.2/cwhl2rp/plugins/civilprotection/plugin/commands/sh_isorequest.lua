--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = CW.command:New("isorequest")
COMMAND.tip = "Запрос изоляции гражданина."
COMMAND.text = "<string CID> <string REASON> <number TIME(min)>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 3

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) then
		local stringCID = arguments[1]
		local stringREASON = arguments[2]
		local numberTIME = tonumber(arguments[3])

		for k, v in pairs(player.GetAll()) do
			if (v:IsPlayer() and v:Alive()) then
				if ((v:GetCharacterData("citizenid") == arguments[1]) and v:IsCitizen()) then

					combine:CombineRequestSay("Запрос изоляции гражданина #"..stringCID..", причина: "..stringREASON..", время изоляции: "..numberTIME.." минут.")

					if (v:GetCharacterData("civ_jail_type") == "#N") then
						v:SetCharacterData("civ_jail_type", stringREASON)									
						v:SetCharacterData("civ_jail_time", numberTIME*60)	
					end						

					timer.Simple(2, function()
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Запрос изоляции гражданина #"..stringCID.." был подтвержден.")
					end)

					break
				end
			end
		end
	else
		CW.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();