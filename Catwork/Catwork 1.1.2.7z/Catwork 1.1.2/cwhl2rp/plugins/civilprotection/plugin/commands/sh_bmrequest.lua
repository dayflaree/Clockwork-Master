--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]
local PLUGIN = PLUGIN

local COMMAND = CW.command:New("bmrequest")
COMMAND.tip = "Запрос на начисление Очков Нарушения гражданину."
COMMAND.text = "<string CID> <string REASON> <number AMOUNT>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 3

function COMMAND:OnRun(combine, arguments)
	if (Schema:PlayerIsCombine(combine)) then
		local stringCID = arguments[1]
		local stringREASON = arguments[2]
		local numberAMOUNT = tonumber(arguments[3])

		for k, citizen in pairs(player.GetAll()) do
			if (citizen:IsPlayer() and citizen:Alive()) then
				if (citizen:GetCharacterData("citizenid") == arguments[1] and citizen:IsCitizen()) then
					combine:CombineRequestSay("Центр, зачислите очки нарушения гражданину #"..stringCID..", причина: "..stringREASON..", количество очков: "..numberAMOUNT..".")
					citizen:SetCharacterData("civ_blackmarks", math.Clamp(citizen:GetCharacterData("civ_blackmarks") + numberAMOUNT, 0, 30))		

					timer.Simple(2, function()
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Очки нарушения гражданину #"..stringCID.." были начислены. Гражданин получил "..numberAMOUNT.." очков нарушения, общее количество: "..tostring(citizen:GetCharacterData("civ_blackmarks", 0)).."/30")
					end)

					break
				end
			end
		end
	else
		CW.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();