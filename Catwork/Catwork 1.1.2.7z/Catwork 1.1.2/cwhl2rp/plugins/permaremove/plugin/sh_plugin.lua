local PLUGIN = PLUGIN

CW.kernel:IncludePrefixed("sv_plugin.lua")
CW.kernel:IncludePrefixed("sv_hooks.lua");