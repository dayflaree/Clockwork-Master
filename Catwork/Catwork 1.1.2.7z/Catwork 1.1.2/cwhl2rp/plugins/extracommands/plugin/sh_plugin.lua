--[[
	© 2016 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

if (SERVER) then
	function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
		local bodyGroup = player:GetCharacterData("CustomBodyGroups")
		local skin = player:GetCharacterData("CustomSkin")

		if (istable(bgs)) then
			for k, v in pairs(bgs) do
				player:SetBodyGroup(k, v)
			end
		end

		if (skin) then
			player:SetSkin(skin)
		end
	end
end