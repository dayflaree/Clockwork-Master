--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local PLUGIN = PLUGIN

CW.hint:Add("Books", "Invest in a book, give your character some knowledge.")

netstream.Hook("TakeBook", function(player, data)
	if (IsValid(data)) then
		if (data:GetClass() == "cw_book") then
			if (player:GetPos():Distance(data:GetPos()) <= 192 and player:GetEyeTraceNoCursor().Entity == data) then
				local success, fault = player:GiveItem(CW.item:CreateInstance(data.book.uniqueID))

				if (!success) then
					CW.player:Notify(player, fault)
				else
					data:Remove()
				end
			end
		end
	end
end)

-- A function to load the books.
function PLUGIN:LoadBooks()
	local books = CW.kernel:RestoreSchemaData("plugins/books/"..game.GetMap())

	for k, v in pairs(books) do
		if (CW.item:GetAll()[v.book]) then
			local entity = ents.Create("cw_book")

			CW.player:GivePropertyOffline(v.key, v.uniqueID, entity)

			entity:SetAngles(v.angles)
			entity:SetBook(v.book)
			entity:SetPos(v.position)
			entity:Spawn()

			if (!v.moveable) then
				local physicsObject = entity:GetPhysicsObject()

				if (IsValid(physicsObject)) then
					physicsObject:EnableMotion(false)
				end
			end
		end
	end
end

-- A function to save the books.
function PLUGIN:SaveBooks()
	local books = {}

	for k, v in pairs(ents.FindByClass("cw_book")) do
		local physicsObject = v:GetPhysicsObject()
		local moveable

		if (IsValid(physicsObject)) then
			moveable = physicsObject:IsMoveable()
		end

		books[#books + 1] = {
			key = CW.entity:QueryProperty(v, "key"),
			book = v.book.uniqueID,
			angles = v:GetAngles(),
			moveable = moveable,
			uniqueID = CW.entity:QueryProperty(v, "uniqueID"),
			position = v:GetPos()
		}
	end

	CW.kernel:SaveSchemaData("plugins/books/"..game.GetMap(), books)
end