--[[
	© 2016 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

local PLUGIN = PLUGIN

CW.kernel:IncludePrefixed("sv_plugin.lua")
CW.kernel:IncludePrefixed("cl_plugin.lua")

-- A function to draw the background blurs.
function CW.kernel:DrawBackgroundBlurs()
	local scrH, scrW = ScrH(), ScrW()
	local sysTime = SysTime()

	if (!CW.ScreenBlur) then
		CW.ScreenBlur = Material("pp/blurscreen")
	end

	for k, v in pairs(CW.BackgroundBlurs) do
		if (type(k) == "string" or (IsValid(k) and k:IsVisible())) then
			local fraction = math.Clamp((sysTime - v) / 1, 0, 1)
			local x, y = 0, 0

			surface.SetMaterial(CW.ScreenBlur)
			surface.SetDrawColor(255, 255, 255, 255)

			for i = 0.33, 1, 0.33 do
				CW.ScreenBlur:SetFloat("$blur", fraction * 5 * i)
				CW.ScreenBlur:Recompute()
				if (render) then render.UpdateScreenEffectTexture();end
				surface.DrawTexturedRect(x, y, scrW, scrH)
			end

			surface.SetDrawColor(10, 10, 30, 120 * fraction)
			surface.DrawRect(x, y, scrW, scrH)
		end
	end
end