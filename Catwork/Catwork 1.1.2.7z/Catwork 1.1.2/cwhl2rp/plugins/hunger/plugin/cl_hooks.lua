--[[
	© 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

local PLUGIN = PLUGIN

function PLUGIN:GetBars(bars)
	local hunger = CW.Client:GetNetVar("Hunger") or 100
	local thirst = CW.Client:GetNetVar("Thirst") or 100

	if (hunger < 90 and CW.Client:Alive() and self:PlayerHasNeeds(CW.Client)) then
		bars:Add("#Bars_Hunger", Color(100, 175, 175, 255), "", hunger, 100, hunger < 10, nil, thirst, "#Bars_Thirst")
	end
end
