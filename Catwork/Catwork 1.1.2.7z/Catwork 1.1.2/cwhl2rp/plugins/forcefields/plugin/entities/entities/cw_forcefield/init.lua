include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

function ENT:Initialize()
	self:SetModel("models/hunter/plates/plate2x4.mdl");
	self:SetMaterial("effects/com_shield003a");

	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetUseType(SIMPLE_USE);
	self:SetSolid(SOLID_VPHYSICS);

	self.dissolver = ents.Create("env_entity_dissolver");
		self.dissolver:SetKeyValue("dissolvetype", 1);
		self.dissolver:SetKeyValue("magnitude", 5);
	self.dissolver:Spawn();

	self.leftFence = ents.Create("prop_dynamic");
		self.leftFence:SetPos(self:GetPos()+Vector(-50,-57,-1));
		self.leftFence:SetAngles(self:GetAngles()+Angle(90,90,0));
		self.leftFence:SetModel("models/props_combine/combine_fence01a.mdl")
		self.leftFence:Activate();
		self.leftFence:SetParent(self);
		self.leftFence:DeleteOnRemove(self);
	self.leftFence:Spawn();

	self.rightFence = ents.Create("prop_dynamic");
		self.rightFence:SetPos(self:GetPos()+Vector(50,-57,-1));
		self.rightFence:SetAngles(self:GetAngles()+Angle(90,90,0));
		self.rightFence:SetModel("models/props_combine/combine_fence01b.mdl")
		self.rightFence:Activate();
		self.rightFence:SetParent(self);
		self.rightFence:DeleteOnRemove(self);
	self.rightFence:Spawn();

	self.ambientLoop = ents.Create("ambient_generic");
		self.ambientLoop:SetKeyValue("message", "combine.sheild_loop");
		self.ambientLoop:SetKeyValue("targetname", "sss");
		self.ambientLoop:SetKeyValue("radius", 100);
		self.ambientLoop:SetKeyValue("spawnflags", 0);
		self.ambientLoop:SetPos(self:GetPos())
	self.ambientLoop:Spawn()
end;

function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS;
end;

function ENT:PhysicsUpdate(physicsObject)
	if (!self:IsPlayerHolding() and !self:IsConstrained()) then
		physicsObject:SetVelocity(Vector(0, 0, 0));
		physicsObject:Sleep();
	end;
end;

local blacklist = {
	"info_player_start",
	"physgun_beam",
	"player",
	"npc_cscanner",
	"prop_ragdoll",
	"predicted_viewmodel"
};

function ENT:DissolveEntity(entity)
	if (!table.HasValue(blacklist, entity:GetClass())) then
		local target = "targeted_"..entity:EntIndex();

		entity:SetKeyValue("targetname", target);

		self.dissolver:SetPos(entity:GetPos());
		self.dissolver:Fire("Dissolve", target, 0);
	end;
end;

function ENT:Use(activator, caller)
end;

function ENT:StartTouch(entity)
	if ((entity.nextFieldTouch or 0) < CurTime()) then
		if (entity:IsPlayer() or entity:IsNPC()) then
			if (entity:IsPlayer()) then
				if (!hook.Run("PlayerCanGoThrough", entity)) then
					entity.nextFieldTouch = CurTime() + 1;

					return
				end;
			end;

			self:EmitSound("buttons/button9.wav");
			self:SetCollisionGroup(COLLISION_GROUP_DEBRIS);
		else
			self:EmitSound("buttons/button8.wav");

			self:DissolveEntity(entity);
		end;

		entity.nextFieldTouch = CurTime() + 1;
	end;
end;

function ENT:EndTouch(entity)
	if (entity and entity:IsPlayer()) then
		self:CollisionReturn(entity);
	end;
end;

function ENT:CollisionReturn(entity)
	timer.Simple(0.3, function()
		if(!IsValid(entity) or self:GetPos():Distance(entity:GetPos()) > 111) then
		   self:SetCollisionGroup(COLLISION_GROUP_NONE);
		else
			self:CollisionReturn(entity);
		end;
	end);
end;

function ENT:CanTool(player, trace, tool)
	return false
end;