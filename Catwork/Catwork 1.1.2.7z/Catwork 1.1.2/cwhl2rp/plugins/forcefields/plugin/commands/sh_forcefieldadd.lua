local PLUGIN = PLUGIN;

local COMMAND = CW.command:New("ForceFieldAdd");
COMMAND.tip = "Spawn force field at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.alias = {"addforcefield", "spawnforcefield", "forcefield"};


-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local entity = ents.Create("cw_forcefield");

	entity:SetPos(trace.HitPos + Vector(0,0,5));
	entity:Spawn();

	if (IsValid(entity)) then
		entity:SetAngles(Angle(0, player:EyeAngles().yaw + 180,0));

		CW.player:Notify(player, "You have spawned a force field.");
	end;
end;

COMMAND:Register();