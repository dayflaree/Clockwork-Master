local PLUGIN = PLUGIN

CW.kernel:IncludePrefixed("cl_plugin.lua")
CW.kernel:IncludePrefixed("cl_hooks.lua");