local PLUGIN = PLUGIN

CW.setting:AddCheckBox("#Framework", "Включить вид от 3-его лица.", "cwThirdPerson", "Использовать ли вид от третьего лица.");