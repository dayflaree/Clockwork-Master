--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PKModeOn")
COMMAND.tip = "Turn PK mode on for the given amount of minutes."
COMMAND.text = "<number Minutes>"
COMMAND.access = "o"
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local minutes = tonumber(arguments[1])

	if (minutes and minutes > 0) then
		netvars.SetNetVar("PKMode", 1)
		CW.kernel:CreateTimer("pk_mode", minutes * 60, 1, function()
			netvars.SetNetVar("PKMode", 0)

			CW.player:NotifyAll("Perma-kill mode has been turned off, you are safe now.")
		end)

		CW.player:NotifyAll(player:Name().." has turned on perma-kill mode for "..minutes.." minute(s), try not to be killed.")
	else
		CW.player:Notify(player, "This is not a valid amount of minutes!")
	end
end

COMMAND:Register();