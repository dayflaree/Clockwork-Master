local ITEM = CW.item:New("ammo_base")
	ITEM.name = "Ammo 545x39"
	ITEM.PrintName = "Коробка патронов: 5.45х39мм"
	ITEM.cost = 0
	ITEM.classes = {CLASS_EMP, CLASS_EOW}
	ITEM.model = "models/items/boxmrounds.mdl"
	ITEM.weight = 3
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_545x39"
	ITEM.business = true
	ITEM.ammoClass = "5.45x39mm"
	ITEM.ammoAmount = 30
	ITEM.description = "Тяжелый контейнер, наполненный патронами калибра 5.45х39мм."
ITEM:Register();