--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New("ammo_base")
	ITEM.name = "Shotgun Shells"
	ITEM.PrintName = "Коробка патронов: Дробь 12 калибра"
	ITEM.cost = 30
	ITEM.classes = {CLASS_EOW}
	ITEM.model = "models/items/boxbuckshot.mdl"
	ITEM.weight = 1
	ITEM.uniqueID = "ammo_buckshot"
	ITEM.business = true
	ITEM.ammoClass = "12 gauge"
	ITEM.ammoAmount = 16
	ITEM.description = "Коробка, наполненная патронами с дробью 12 калибра."
ITEM:Register()