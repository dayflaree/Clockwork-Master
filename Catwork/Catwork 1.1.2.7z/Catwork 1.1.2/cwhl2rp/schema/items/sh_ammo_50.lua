--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New("ammo_base")
	ITEM.name = ".50 BMG Bullets"
	ITEM.PrintName = "Коробка патронов: .50 BMG"
	ITEM.cost = 40
	ITEM.classes = {CLASS_EOW}
	ITEM.model = "models/items/357ammo.mdl"
	ITEM.weight = 1
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_50"
	ITEM.business = true
	ITEM.ammoClass = ".50 bmg"
	ITEM.ammoAmount = 10
	ITEM.description = "Коробка, наполненная огромными патронами калибра .50 BMG."
ITEM:Register();