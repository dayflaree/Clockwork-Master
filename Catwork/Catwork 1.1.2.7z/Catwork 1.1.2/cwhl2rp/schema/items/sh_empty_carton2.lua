local ITEM = CW.item:New()
ITEM.name = "Empty Takeout Carton"
ITEM.PrintName = "Пустая коробка"
ITEM.uniqueID = "empty_takeout_carton"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"
ITEM.weight = 0.1
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая коробка из под лапши."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();