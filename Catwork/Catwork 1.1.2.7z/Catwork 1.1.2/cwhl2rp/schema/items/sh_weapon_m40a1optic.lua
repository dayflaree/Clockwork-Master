local ITEM = CW.item:New("weapon_base")
	ITEM.name = "M40A1 Optic"
	ITEM.PrintName = "M40A1 с оптическим прицелом"
	ITEM.cost = 0
	ITEM.model = "models/items/m40a1_scope.mdl"
	ITEM.weight = 4.8
	ITEM.access = "V"
	ITEM.classes = {CLASS_EOW}
	ITEM.uniqueID = "sxbase_m40a1optic"
	ITEM.business = true
	ITEM.description = "Американская снайперская винтовка калибра 7.62х51мм."
	ITEM.isAttachment = true
	ITEM.loweredOrigin = Vector(3, 0, -4)
	ITEM.loweredAngles = Angle(0, 45, 0)
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine2"
	ITEM.attachmentOffsetAngles = Angle(110, 0, 95)
	ITEM.attachmentOffsetVector = Vector(-1.5, 4, 1)
ITEM:Register();