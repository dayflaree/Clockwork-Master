--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New()
ITEM.name = "High Tier Ration Packet"
ITEM.PrintName = "#ITEM_High_Tier_Ration_Packet"
ITEM.uniqueID = "ration_high"
ITEM.model = "models/weapons/w_packatp.mdl"
ITEM.weight = 1.75
ITEM.useText = "Open"
ITEM.description = "#ITEM_High_Tier_Ration_Packet_Desc"

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
	if (quickUse) then
		if (!player:CanHoldWeight(self.weight)) then
			CW.player:Notify(player, "You do not have enough inventory space!")

			return false
		end
	end
end

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	CW.player:GiveCash(player, 100, "рацион")

	player:GiveItem(CW.item:CreateInstance("citizen_supplements"), true)
	player:GiveItem(CW.item:CreateInstance("special_breens_water"), true)
	player:GiveItem(CW.item:CreateInstance("special_breens_water"), true)

	hook.Run("PlayerUseRation", player)
end

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();