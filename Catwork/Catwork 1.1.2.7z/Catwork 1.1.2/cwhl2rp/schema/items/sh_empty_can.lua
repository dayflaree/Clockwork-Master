local ITEM = CW.item:New()
ITEM.name = "Empty Can"
ITEM.PrintName = "Пустая банка"
ITEM.uniqueID = "empty_can"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.weight = 0.35
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Старая ржавая банка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();