--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New()
ITEM.name = "Minimal Tier Ration Packet"
ITEM.PrintName = "#ITEM_Minimal_Tier_Ration_Packet"
ITEM.uniqueID = "ration_normal"
ITEM.model = "models/weapons/w_packati.mdl"
ITEM.weight = 1.25
ITEM.useText = "Open"
ITEM.description = "#ITEM_Minimal_Tier_Ration_Packet_Desc"

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
	if (quickUse) then
		if (!player:CanHoldWeight(self.weight)) then
			CW.player:Notify(player, "You do not have enough inventory space!")

			return false
		end
	end
end

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	CW.player:GiveCash(player, 25, "рацион")

	player:GiveItem(CW.item:CreateInstance("citizen_supplements"), true)

	hook.Run("PlayerUseRation", player)
end

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();