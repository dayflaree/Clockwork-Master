﻿--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = CW.item:New()
ITEM.name = "Хлеб"
ITEM.cost = 25
ITEM.model = "models/bioshockinfinite/dread_loaf.mdl"
ITEM.weight = 0.4
ITEM.access = "v"
ITEM.useText = "Съесть"
ITEM.business = false
ITEM.category = "Consumables"
ITEM.description = "Сделанный из низкосортного зерна хлеб. Жестковат."
ITEM.hunger = 35

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:BoostAttribute(self.name, ATB_STRENGHT, 2, 120)
	player:BoostAttribute(self.name, ATB_ENDURANCE, 2, 120)
end

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();