local ITEM = CW.item:New("ammo_base")
	ITEM.name = "7.62x51mm Bullets"
	ITEM.PrintName = "Коробка патронов: 7.62х51мм"
	ITEM.cost = 0
	ITEM.classes = {CLASS_EMP, CLASS_EOW}
	ITEM.model = "models/items/boxmrounds.mdl"
	ITEM.weight = 3.5
	ITEM.access = "V"
	ITEM.uniqueID = "ammo_762x51"
	ITEM.business = true
	ITEM.ammoClass = "7.62x51mm"
	ITEM.ammoAmount = 30
	ITEM.description = "Тяжелый контейнер, наполненный патронами калибра 7.62х51мм."
ITEM:Register();