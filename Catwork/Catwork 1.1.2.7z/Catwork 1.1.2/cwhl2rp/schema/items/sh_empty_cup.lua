local ITEM = CW.item:New()
ITEM.name = "Empty Cup"
ITEM.PrintName = "Пустая чашка"
ITEM.uniqueID = "empty_cup"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_coffeemug001a.mdl"
ITEM.weight = 0.3
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая чашка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();