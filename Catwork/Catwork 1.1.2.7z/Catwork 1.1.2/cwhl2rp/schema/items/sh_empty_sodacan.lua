local ITEM = CW.item:New()
ITEM.name = "Empty Soda Can"
ITEM.PrintName = "Пустая алюминиевая банка"
ITEM.uniqueID = "empty_soda_can"
ITEM.cost = 0
ITEM.model = "models/props_junk/popcan01a.mdl"
ITEM.weight = 0.16
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая алюминиевая банка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();