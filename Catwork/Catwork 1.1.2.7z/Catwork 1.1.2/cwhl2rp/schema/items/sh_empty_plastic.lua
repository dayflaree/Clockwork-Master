local ITEM = CW.item:New()
ITEM.name = "Empty Plastic Bottle"
ITEM.PrintName = "Пустая бутылка"
ITEM.uniqueID = "empty_plastic_bottle"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl"
ITEM.weight = 0.5
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Большая пластиковая бутылка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();