--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New()
	ATTRIBUTE.name = "#Attribute_Strength"
	ATTRIBUTE.maximum = 75
	ATTRIBUTE.uniqueID = "str"
	ATTRIBUTE.description = "#Attribute_Strength_Desc"
	ATTRIBUTE.isOnCharScreen = true
	ATTRIBUTE.category = "Характеристики"
ATB_STRENGTH = CW.attribute:Register(ATTRIBUTE);