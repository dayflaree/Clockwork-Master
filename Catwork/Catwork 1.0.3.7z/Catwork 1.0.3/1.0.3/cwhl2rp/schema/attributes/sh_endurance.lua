--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New()
	ATTRIBUTE.name = "#Attribute_Endurance"
	ATTRIBUTE.maximum = 75
	ATTRIBUTE.uniqueID = "end"
	ATTRIBUTE.description = "#Attribute_Endurance_Desc"
	ATTRIBUTE.isOnCharScreen = true
	ATTRIBUTE.category = "Характеристики"
ATB_ENDURANCE = CW.attribute:Register(ATTRIBUTE);