local ITEM = Clockwork.item:New()
ITEM.name = "Empty Tin Can"
ITEM.PrintName = "Пустая банка"
ITEM.uniqueID = "empty_tin_can"
ITEM.cost = 0
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.weight = 0.2
ITEM.business = false
ITEM.category = "Мусор"
ITEM.description = "Пустая пластиковая банка."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();