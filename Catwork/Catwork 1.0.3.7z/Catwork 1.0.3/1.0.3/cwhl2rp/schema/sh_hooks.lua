--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when the Clockwork shared variables are added.
function Schema:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("antidepressants", true)
	playerVars:Bool("permaKilled", false)
	playerVars:String("customClass")
	playerVars:String("citizenID", true)
	playerVars:Number("scanner", true)
	playerVars:Number("clothes", true)
	playerVars:Number("tied")
	globalVars:Number("PKMode")
end

