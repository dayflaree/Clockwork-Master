--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("ViewObjectives")
COMMAND.tip = "View the Civil Protection objectives."
COMMAND.flags = CMD_DEFAULT

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		netstream.Start(player, "EditObjectives", Schema.combineObjectives)

		player.editObjectivesAuthorised = true
	else
		CW.player:Notify(player, "You are not the Combine!")
	end
end

COMMAND:Register();