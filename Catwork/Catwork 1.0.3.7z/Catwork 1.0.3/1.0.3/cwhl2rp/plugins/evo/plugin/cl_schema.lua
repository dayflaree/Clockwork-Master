--[[
		Created by Polis, July 2014.
		Do not re-distribute as your own.


	 	Sort of messy, but /much/ better than it was before.  Believe me, god damn.
]]


CreateClientConVar("evo_names", 1, true, false)
CreateClientConVar("evo_hud", 1, true, false)
CreateClientConVar("evo_outlines", 1, true, false)
CreateClientConVar("evo_crosshair", 1, true, false)
CreateClientConVar("evo_outline_distance", 300, true, false)
CreateClientConVar("evo_hud_distance", 300, true, false)

evo = {}

-- Get rid of them nasty display lines.
Schema.randomDisplayLines = {
	"Инициализация визора..."
}

--[[
-- White Outlines Fixed
hook.Add("PreDrawHalos", "Outlines", function()
	if (Schema:PlayerIsCombine(LocalPlayer())) then
		local kek = table.Copy(player.GetAll())
		for k,v in pairs(kek) do
			if v:GetMoveType() == MOVETYPE_NOCLIP then
				kek[k] = nil
			end
		end
		halo.Add(kek, Color(248,248,255,255), 0, 0, 1, true, false)
	end
end)
]]

-- Colours
evo.colormal = Color(255, 10, 0, 255)
evo.coloryel = Color(255, 215, 0, 255)
evo.colorgre = Color(50, 205, 50, 255)
evo.color = Color(0, 128, 255, 255)
evo.colorcitizen = Color(255, 250, 250, 255)

-- Fonts
surface.CreateFont("HUDFont", {
	font = "BudgetLabel",
	size = 16,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

surface.CreateFont("NameFont", {
	font = "BudgetLabel",
	size = 18,
	weight = 600,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = true,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})



-- Crosshair
hook.Add("HUDPaint", "Crosshair", function()
	if (ConVarExists("evo_crosshair") and GetConVar("evo_crosshair"):GetInt() == 1) then
		if (Schema:PlayerIsCombine(LocalPlayer())) then
			local x = ScrW() / 2
			local y = ScrH() / 2
			surface.SetDrawColor(0, 128, 255, 255)
			local gap = 5
			local length = gap + 15
			surface.DrawLine(x - length, y, x - gap, y)
			surface.DrawLine(x + length, y, x + gap, y)
			surface.DrawLine(x, y - length, x, y - gap)
			surface.DrawLine(x, y + length, x, y + gap)
		end
	end
end)



-- Settings Derma
concommand.Add("evo_settings", function()
		local frame = vgui.Create("DFrame")
		local PropertySheet = vgui.Create("DPropertySheet")
		PropertySheet:SetParent(frame)
		PropertySheet:SetPos(0, 25)
		PropertySheet:SetSize(600, 215)
		frame:SetPos((surface.ScreenWidth()/2) - 350,(surface.ScreenHeight()/2) - 350)
		frame:SetSize(600, 245)
		frame:SetTitle("Enhanced Visual Overlay - Menu")
		frame:SetBackgroundBlur(true)
		frame:SetDraggable(true)
		frame:MakePopup()

		local SheetItemOne = vgui.Create("DPanel")
		SheetItemOne:SetPos(25, 50)
		SheetItemOne:SetSize(350, 230)
		SheetItemOne.Paint = function() --
		surface.SetDrawColor(50, 50, 50, 255) --
		surface.DrawRect(0, 0, SheetItemOne:GetWide(), SheetItemOne:GetTall())
		end

		local NamesBox = vgui.Create("DCheckBoxLabel", SheetItemOne)
		NamesBox:SetPos(15, 15)
		NamesBox:SetText("Enable Friendly Names")
		NamesBox:SetConVar("evo_names")
		NamesBox:SizeToContents()

		local HudBox = vgui.Create("DCheckBoxLabel", SheetItemOne)
		HudBox:SetPos(15, 30)
		HudBox:SetText("Enable Primary Detection")
		HudBox:SetConVar("evo_hud")
		HudBox:SizeToContents()	

		local OutBox = vgui.Create("DCheckBoxLabel", SheetItemOne)
		OutBox:SetPos(15,45)
		OutBox:SetText("Enable Secondary Detection")
		OutBox:SetConVar("evo_outlines")
		OutBox:SizeToContents()

		local CrossBox = vgui.Create("DCheckBoxLabel", SheetItemOne)
		CrossBox:SetPos(15,60)
		CrossBox:SetText("Enable the Crosshair")
		CrossBox:SetConVar("evo_crosshair")
		CrossBox:SizeToContents()

		local HUDDistanceMod = vgui.Create("DNumSlider", SheetItemOne)
		HUDDistanceMod:SetPos(15,90)
		HUDDistanceMod:SetSize(450, 50)
		HUDDistanceMod:SetText("HUD Distance Modifier")
		HUDDistanceMod:SetMin(260)
		HUDDistanceMod:SetMax(4096)
		HUDDistanceMod:SetDecimals(0)
		HUDDistanceMod:SetConVar("evo_hud_distance")													

		PropertySheet:AddSheet("Settings", SheetItemOne, "icon16/wrench.png", false, false, "Configure the settings for your visual overlay.")				
end)



hook.Add("HUDPaint", "General Interface", function()
	local LP = LocalPlayer()
	local maxdist = GetConVarNumber("evo_hud_distance")
	local max = 600
	maxdist = math.Clamp(maxdist, 0, max)

	if Schema:PlayerIsCombine(LP) then
		for k,e in pairs (player.GetAll()) do
			if e:IsNoClipping() then continue end
			if e == LP then continue end
			if e:GetPos():Distance(LP:GetPos()) > maxdist then continue end

			local Position = (e:GetPos() + Vector(0,0,80)):ToScreen()
			if ConVarExists("evo_names") and GetConVar("evo_names"):GetInt() == 1 and Schema:PlayerIsCombine(e) then
				Position.y = Position.y + 15
				draw.DrawText(e:Name(), "NameFont", Position.x, Position.y, Color(0, 128, 255, 255), 1)
			end

			if LP:IsLineOfSightClear(e:GetPos()) then
				local font = "HUDFont"
				if ConVarExists("evo_hud") and GetConVar("evo_hud"):GetInt() == 1 then	
					if e:Health() <= 0 then
						Position.y = Position.y + 20
						draw.DrawText("<:: !ВНИМ: БЕЗ ПРИЗНАКОВ ЖИЗНИ!", font, Position.x, Position.y, evo.colormal, 1)
					elseif e:Health() <= 10 then
						Position.y = Position.y + 20
						draw.DrawText("<:: !УВДМЛ: ПРИ СМЕРТИ.", font, Position.x, Position.y, evo.colormal, 1)
					elseif e:Health() <= 96 then
						Position.y = Position.y + 20
						draw.DrawText("<:: !УВДМЛ: РАНЕН.", font, Position.x, Position.y, evo.coloryel, 1)
					end


					if e:IsRagdolled() and e:Alive() then
						Position.y = Position.y + 15
						draw.DrawText("<:: !УВДМЛ: БЕЗ СОЗНАНИЯ.", font, Position.x, Position.y, evo.coloryel, 1)
					elseif e:GetSharedVar("tied") != 0 and !Schema:PlayerIsCombine(e) then
						Position.y = Position.y + 15
						draw.DrawText("<:: !УВДМЛ: СВЯЗАН.", font, Position.x, Position.y, evo.colorgre, 1)
					elseif e:GetSharedVar("tied") != 0 and Schema:PlayerIsCombine(e) then
						Position.y = Position.y + 15
						draw.DrawText("<:: !ВНИМ: СВЯЗАННЫЙ ЮНИТ!", font, Position.x, Position.y, evo.coloryel, 1)
					end


					if e:FlashlightIsOn() then
						Position.y = Position.y + 15
						draw.DrawText("<:: !УВДМЛ: ИСПОЛЬЗУЕТ ФОНАРЬ.", font, Position.x, Position.y, evo.colorgre, 1)
					end

					if !Schema:PlayerIsCombine(e) then
						for k, v in pairs(e:GetWeapons()) do
							local weaponItem = Clockwork.item:GetByWeapon(v)
							if weaponItem then
								Position.y = Position.y + 15
								draw.DrawText("<:: !ВНИМ: "..weaponItem("name"), font, Position.x, Position.y, evo.colormal, 1)
							end
						end
					end


					if e:IsOnFire() then
						Position.y = Position.y + 20
						draw.DrawText("<:: !ВНИМ: ПОД ОГНЕМ.", font, Position.x, Position.y, evo.colormal, 1)
					elseif e:InVehicle() and !Schema:PlayerIsCombine(e) then
						Position.y = Position.y + 20
						draw.DrawText("<:: !ВНИМ: НЕАВТОРИЗИРОВАННОЕ УПРАВЛЕНИЕ ТС.", font, Position.x, Position.y, evo.colormal, 1)
					elseif e:IsRunning() then
						if !Schema:PlayerIsCombine(e) then
							Position.y = Position.y + 20
							draw.DrawText("<:: !ВНИМ: НАРУШЕНИЕ ДИРЕКТИВ ПОВЕДЕНИЯ.", font, Position.x, Position.y, evo.coloryel, 1)
						end
					elseif e:Crouching() and !Schema:PlayerIsCombine(e) then
						Position.y = Position.y + 20
						draw.DrawText("<:: !ВНИМ: ПОПЫТКА СКРЫТЬСЯ.", font, Position.x, Position.y, evo.coloryel, 1)
					elseif e:Crouching() and Schema:PlayerIsCombine(e) then
						Position.y = Position.y + 20
						draw.DrawText("<:: !УВДМЛ: СКРЫТ.", font, Position.x, Position.y, evo.colorgre, 1)
					end
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "Flying Words", function()
	local LP = LocalPlayer()
	local maxdist = GetConVarNumber("evo_hud_distance")
	local max = 600

	maxdist = math.Clamp(maxdist, 0, max)

	if ConVarExists("evo_outlines") and GetConVar("evo_outlines"):GetInt() == 1 and Schema:PlayerIsCombine(LocalPlayer()) then
		for k, ent in pairs(ents.FindByClass("cw_item")) do
			if LP:Alive() and Clockwork.entity:HasFetchedItemData(ent) then
				if !LP:IsLineOfSightClear(ent:GetPos()) then continue end
				if ent:GetPos():Distance(LP:GetPos()) > maxdist then continue end

				local Table = ent:GetItemTable()
				local ita =  Table("category")	
				local Position = ent:GetPos():ToScreen()
				local distance = ent:GetPos():Distance(LP:GetPos())
				if ita == "Weapons" then
					draw.DrawText("<:: !ВНИМ: "..Table("name"), "HUDFont", Position.x, Position.y, Color(255, 0, 10, 255), 1)
					draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, Color(255, 0, 10, 255), 1)
				elseif ita == "Ammunition" then
					draw.DrawText("<:: !ВНИМ: "..Table("name"), "HUDFont", Position.x, Position.y, Color(10, 80, 255, 255), 1)
					draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, Color(10, 80, 255, 255), 1)
				elseif ita == "Medical" and ita != "Weapons" and ita != "Ammunition" then
					draw.DrawText("<:: "..Table("name"), "HUDFont", Position.x, Position.y, Color(0, 255, 10, 255), 1)
					draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, Color(0, 255, 10, 255), 1)
				end
			end
		end
		for k,ent in pairs(ents.FindByClass("npc_grenade_frag")) do
			if LP:Alive() then
				if !LP:IsLineOfSightClear(ent:GetPos()) then continue end
				if ent:GetPos():Distance(LP:GetPos()) > maxdist then continue end

				local Position = ent:GetPos():ToScreen()
				local distance = ent:GetPos():Distance(LP:GetPos())
				draw.DrawText("<:: !ГРАНАТА", "HUDFont", Position.x, Position.y, evo.colormal, 1)
				draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, evo.colormal, 1)
			end
		end
		for k,ent in pairs(ents.FindByClass("ent_flashbang")) do
			if LP:Alive() then
				if !LP:IsLineOfSightClear(ent:GetPos()) then continue end
				if ent:GetPos():Distance(LP:GetPos()) > maxdist then continue end

				local Position = ent:GetPos():ToScreen()
				local distance = ent:GetPos():Distance(LP:GetPos());
				draw.DrawText("<:: !СВЕТОШУМОВАЯ", "HUDFont", Position.x, Position.y, evo.colormal, 1)
				draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, evo.colormal, 1)
			end
		end
		for k,ent in pairs(ents.FindByClass("ent_smokegrenade")) do
			if LP:Alive() then
				if !LP:IsLineOfSightClear(ent:GetPos()) then continue end
				if ent:GetPos():Distance(LP:GetPos()) > maxdist then continue end

				local Position = ent:GetPos():ToScreen()
				local distance = ent:GetPos():Distance(LP:GetPos());
				draw.DrawText("<:: !ДЫМЧАТКА", "HUDFont", Position.x, Position.y, evo.colormal, 1)
				draw.DrawText("<:: ДИСТ: " .. math.floor(distance), "HUDFont", Position.x, Position.y + 10, evo.colormal, 1)
			end
		end
	end
end)

-- A function that modifies the Combine Display lines.
function Schema:AddCombineDisplayLine(text, color)
	if (self:PlayerIsCombine(Clockwork.Client)) then
		if (!self.combineDisplayLines) then
			self.combineDisplayLines = {}
		end

		table.insert(self.combineDisplayLines, {"!<:: "..text, CurTime() + 8, 5, color})
	end
end