--[[
		Created by Polis, July 2014.
		Do not re-distribute as your own.
]]

local PLUGIN = PLUGIN

Clockwork.kernel:IncludePrefixed("sv_plugin.lua")
Clockwork.kernel:IncludePrefixed("cl_schema.lua")
Clockwork.kernel:IncludePrefixed("sv_hooks.lua")
