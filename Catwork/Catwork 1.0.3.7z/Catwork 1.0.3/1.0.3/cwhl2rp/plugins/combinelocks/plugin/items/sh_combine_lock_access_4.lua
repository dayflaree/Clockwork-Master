local ITEM = Clockwork.item:New()
ITEM.name = "Combine Lock Access Card"
ITEM.PrintName = "Карта доступа 4 ур."
ITEM.uniqueID = "combine_lock_access_4"
ITEM.model = "models/gibs/metal_gib4.mdl"
ITEM.weight = 0.1
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.business = true
ITEM.description = "УРОВЕНЬ ДОСТУПА: 4\nКарта доступа, с помощью которой можно взаимодействовать с замками Альянса."
ITEM.category = "Карты и замки"

function ITEM:OnDrop(player, position) end

ITEM:Register()