local PLUGIN = PLUGIN
local CW = CW

CW.kernel:IncludePrefixed("sv_plugin.lua");