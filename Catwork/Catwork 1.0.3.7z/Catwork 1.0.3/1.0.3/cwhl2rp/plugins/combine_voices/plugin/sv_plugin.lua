local PLUGIN = PLUGIN
local CW = CW

-- Adds the "HL2 Beta SNPCs" workshop file to the server's FastDL.
resource.AddWorkshop("175272156")
resource.AddWorkshop("604823499");