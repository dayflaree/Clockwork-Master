--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

function ENT:HUDPaintTargetID(x, y, alpha)
	local colorTargetID = Clockwork.option:GetColor("target_id")
	local colorWhite = Clockwork.option:GetColor("white")
	local itemTable = CW.item:FindByID(self:GetItem())

	y = Clockwork.kernel:DrawInfo(itemTable("PlantName"), x, y, colorTargetID, alpha)

	if (CW.attributes:Fraction(ATB_FARM, 100) > 25) then
		local GrowthPercent = math.Clamp(math.Round((CurTime() - self:GetSpawnTime()) / (self:GetGrowTime() - self:GetSpawnTime()) * 100), 0, 100)
		y = Clockwork.kernel:DrawInfo("Зрелость: "..GrowthPercent.."%", x, y, Color(255, 255, 255), alpha)
	end
end

include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:Initialize()

end

function ENT:Think()

end