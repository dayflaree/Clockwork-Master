DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "One Very Good Person";
ENT.PrintName = "Force Fields";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.UsableInVehicle = false;
ENT.PhysgunDisabled = true;