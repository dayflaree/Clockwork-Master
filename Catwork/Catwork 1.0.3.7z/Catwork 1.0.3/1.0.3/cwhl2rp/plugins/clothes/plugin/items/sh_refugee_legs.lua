--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Grey Jeans"
	ITEM.PrintName = "#ITEM_Ref_Legs_Name"
	ITEM.cost = 65
	ITEM.model = "models/tnb/items/pants_citizen.mdl"
	ITEM.skin = 2
	ITEM.plural = "#ITEM_Ref_Legs_Plural"
	ITEM.weight = 0.5
	ITEM.uniqueID = "refugee_legs"
	ITEM.business = false
	ITEM.bodyGroup = 2
	ITEM.bodyGroupVal = 2
	ITEM.description = "#ITEM_Ref_Legs_Desc"
ITEM:Register();