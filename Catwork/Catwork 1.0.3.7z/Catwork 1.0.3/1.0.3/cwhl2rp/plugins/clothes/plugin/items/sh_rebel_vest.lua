--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Rebel Vest"
	ITEM.PrintName = "Униформа Сопротивления"
	ITEM.model = "models/tnb/items/shirt_rebel_molle.mdl"
	ITEM.plural = "Униформы Сопротивления"
	ITEM.weight = 2
	ITEM.uniqueID = "rebel_vest"
	ITEM.business = false
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 8
	ITEM.description = "Униформа сопротивления, немного потрёпанная."
	ITEM.protection = 10
ITEM:Register();