--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "CWU Uniform"
	ITEM.PrintName = "Рубашка ГСР"
	ITEM.skin = 2
	ITEM.cost = 80
	ITEM.model = "models/tnb/items/shirt_citizen1.mdl"
	ITEM.plural = "Рубашки ГСР"
	ITEM.weight = 0.4
	ITEM.uniqueID = "cit_uniform_cwu"
	ITEM.business = false
	ITEM.bodyGroup = 1
	ITEM.bodyGroupVal = 2
	ITEM.description = "Белая рубашка для работников ГСР."
ITEM:Register();