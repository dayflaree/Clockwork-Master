--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Blue Beanie"
	ITEM.PrintName = "#ITEM_Blue_Beanie_Name"
	ITEM.cost = 40
	ITEM.model = "models/tnb/items/beanie.mdl"
	ITEM.plural = "#ITEM_Blue_Beanie_Name_Plural"
	ITEM.weight = 0.4
	ITEM.uniqueID = "blue_beanie"
	ITEM.business = false
	ITEM.bodyGroup = 4
	ITEM.bodyGroupVal = 3
	ITEM.description = "#ITEM_Blue_Beanie_Desc"
ITEM:Register();