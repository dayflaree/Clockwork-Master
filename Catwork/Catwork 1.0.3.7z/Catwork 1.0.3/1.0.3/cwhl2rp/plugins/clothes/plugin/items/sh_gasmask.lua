--[[
	© 2016 TeslaCloud Studios.
	Private code for Global Cooldown community.
	Stealing Lua cache is not nice lol.
	get a life kiddos.
--]]

local ITEM = CW.item:New("bodygroup_base")
	ITEM.name = "Gas Mask"
	ITEM.PrintName = "#ITEM_Gasmask_Name"
	ITEM.cost = 90
	ITEM.model = "models/tnb/items/gasmask.mdl"
	ITEM.plural = "#ITEM_Gasmask_Name_Plural"
	ITEM.weight = 0.6
	ITEM.uniqueID = "gas_mask"
	ITEM.business = false
	ITEM.bodyGroup = 4
	ITEM.bodyGroupVal = 2
	ITEM.description = "#ITEM_Gasmask_Desc"
	ITEM.protection = 5
ITEM:Register();