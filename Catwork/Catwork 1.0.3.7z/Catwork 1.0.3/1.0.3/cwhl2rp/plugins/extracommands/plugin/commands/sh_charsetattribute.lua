--[[
	© 2016 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

local COMMAND = CW.command:New("CharSetAttribute")
COMMAND.tip = "Sets attribute's value for a character."
COMMAND.text = "<string Player> <string Attribute> <number Amount>"
COMMAND.access = "s"
COMMAND.arguments = 3
COMMAND.alias = {"SetAttribute"}

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])
	local rawAttribute = string.utf8lower(arguments[2])
	local attribute = CW.attribute:FindByID(rawAttribute)
	local amt = tonumber(arguments[3]) or 0

	if (IsValid(target)) then
		if (attribute) then
			CW.attributes:Update(target, attribute.uniqueID, amt)

			CW.player:Notify(player, "You have set "..target:Name().."'s "..(attribute.name or "Unknown").." ["..attribute.uniqueID.."] attribute to "..tostring(amt)..".")
		else
			CW.player:Notify(player, arguments[2].." is not a valid attribute!")
		end
	else
		CW.player:Notify(player, arguments[1].." is not a valid target!")
	end
end

COMMAND:Register();