--[[
	© 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

config.Add("hunger_tick", 15000, true)
config.Add("thirst_tick", 10000, true)
config.Add("hunger_default_refill", 25, true)
config.Add("thirst_drain_scale", 4, true);