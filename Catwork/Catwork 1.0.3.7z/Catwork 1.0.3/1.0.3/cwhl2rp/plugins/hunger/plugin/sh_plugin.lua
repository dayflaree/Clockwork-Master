--[[
	© 2016 TeslaCloud Studios.
	Please do not use anywhere else.
--]]

CW.kernel:IncludePrefixed("sv_plugin.lua")
CW.kernel:IncludePrefixed("sv_hooks.lua")
CW.kernel:IncludePrefixed("cl_plugin.lua")
CW.kernel:IncludePrefixed("cl_hooks.lua");