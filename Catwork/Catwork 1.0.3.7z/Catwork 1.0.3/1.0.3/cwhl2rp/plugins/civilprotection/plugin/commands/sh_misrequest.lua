--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("misrequest")
COMMAND.tip = "Запрос проверки отклонения численности."
COMMAND.text = ""
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if Schema:PlayerIsCombine(combine) then
		local airwatch_civCount = 0

		combine:CombineRequestSay("Возможное отклонение численности, запрашиваю подтверждение.")

		for k, v in pairs(player.GetAll()) do
			if v:IsPlayer() and v:Alive() then
				if ((v:GetFaction() == FACTION_CITIZEN) or (v:GetFaction() == FACTION_CWU)) and (v:GetMoveType() != MOVETYPE_NOCLIP) then
					local traceCIV = {}
					traceCIV.start = v:GetPos()
					traceCIV.endpos = v:GetPos()+(v:GetUp()*4096)
					traceCIV.filter = v

					local traceCIV_U = util.TraceLine(traceCIV)
					if traceCIV_U.HitSky then
						airwatch_civCount = airwatch_civCount + 1
					end
				end
			end
		end

		timer.Simple(2.4, function()
			for k, v in pairs(player.GetAll()) do
				if v:IsPlayer() and v:Alive() then
					if ((v:GetFaction() == FACTION_CITIZEN) or (v:GetFaction() == FACTION_CWU)) and (v:GetMoveType() != MOVETYPE_NOCLIP) then
						local traceCIV = {}	
						traceCIV.start = v:GetPos()
						traceCIV.endpos = v:GetPos()+(v:GetUp()*4096)
						traceCIV.filter = v

						local traceCIV_U = util.TraceLine(traceCIV)
						if traceCIV_U.HitSky then
							v:SendLua("LocalPlayer():EmitSound('music/stingers/hl1_stinger_song16.mp3')")
						end
					end
				end
			end

			if (airwatch_civCount > 1) then
				combine:CombineRequestAnswer("Возможное отклонение от численности в количестве "..airwatch_civCount.." граждан. Действовать согласно протоколу.")
			elseif (airwatch_civCount == 1) then
				combine:CombineRequestAnswer("Возможное отклонение от численности в количестве "..airwatch_civCount.." гражданина. Действовать согласно протоколу.")
			elseif (airwatch_civCount == 0) then
				combine:CombineRequestAnswer("Возможное отклонение от числ	нности не зафиксировано.")
			end
		end)	
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register()