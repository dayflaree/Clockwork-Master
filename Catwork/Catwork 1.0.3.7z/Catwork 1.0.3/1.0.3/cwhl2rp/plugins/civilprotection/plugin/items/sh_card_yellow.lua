local ITEM = Clockwork.item:New()
ITEM.name = "Жёлтая карта"
ITEM.uniqueID = "card_yellow"
ITEM.model = "models/cwu_card1.mdl"
ITEM.weight = 0.1
ITEM.description = "Пластиковая карточка жёлтого цвета с символикой Альянса на ней."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

ITEM:Register();