local vec1 = Vector(0, 0, 0)
local vec2 = Vector(0, 0, 0)

if SERVER then
	COMBINE_MORTAR_ISFIRING = false
	COMBINE_MORTAR_COUNT = 1
	COMBINE_MORTAR_CURRENT = 1
	COMBINE_MORTAR_BOMBS = {}

	hook.Add("Think","BOMB_REQUEST",function()
		for k, v in pairs(COMBINE_MORTAR_BOMBS) do
			ShootBomb(v.pos)

			COMBINE_MORTAR_BOMBS[k] = nil
		end
	end)

	function ShootBomb(pos)
		local bomb = ents.Create("combine_mortar_shell")

		if (bomb) then
			local tr = util.TraceLine({
				start = pos,
				endpos = pos + Vector(0,0,1) * (10^14),
				mask = MASK_PLAYERSOLID,
				filter = bomb
			})

			bomb:SetPos(tr.HitPos - bomb:OBBMaxs() - Vector(0,0,1))
			bomb:Spawn()
		end
	end
end

local COMMAND = Clockwork.command:New("BombRequest")
COMMAND.tip = "Запрос на артобстрел D-5."
COMMAND.text = "<number Count> <number Repeats>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if (combine:GetFaction() == FACTION_MPF) then
		if Schema:IsPlayerCombineRank(combine, {"CmD","SeC", "MaJ"}) and !COMBINE_MORTAR_ISFIRING then
			local count = math.Clamp(tonumber(arguments[1]),1,30) or 1
			local rep = math.Clamp(tonumber(arguments[2]),1,4) or 1

			combine:CombineRequestSay("Центр, запрашиваю огневую задачу по 10-20: D-5.")

			timer.Simple(math.random(1,3), function()
				COMBINE_MORTAR_ISFIRING = true
				COMBINE_MORTAR_COUNT = count
				COMBINE_MORTAR_CURRENT = 1

				for i = 1, COMBINE_MORTAR_COUNT do
					local rand_x = math.Rand(vec1.x,vec2.x)
					local rand_y = math.Rand(vec1.y,vec2.y)
					local rand_z = math.Rand(vec1.z,vec2.z)
					local vec3 = Vector(rand_x,rand_y,rand_z)
						
					COMBINE_MORTAR_BOMBS[#COMBINE_MORTAR_BOMBS + 1] = {
						pos = vec3
					}
				end

				combine:CombineRequestAnswer("Артбатарея на связи. Принято, огневая задача на 10-20: D-5! Количество артбатарей: "..count..".")

				if (rep - 1) != 0 then
					local reloadtime = 0.5 * COMBINE_MORTAR_COUNT
					timer.Create("combine_mortar", reloadtime, rep - 1, function()
						COMBINE_MORTAR_CURRENT = COMBINE_MORTAR_CURRENT + 1

						for i = 1, COMBINE_MORTAR_COUNT do
							local rand_x = math.Rand(vec1.x,vec2.x)
							local rand_y = math.Rand(vec1.y,vec2.y)
							local rand_z = math.Rand(vec1.z,vec2.z)
							local vec3 = Vector(rand_x,rand_y,rand_z)
								
							COMBINE_MORTAR_BOMBS[#COMBINE_MORTAR_BOMBS + 1] = {
								pos = vec3
							}
						end

						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Артбатарея: Залп #"..COMBINE_MORTAR_CURRENT.."!")

						if COMBINE_MORTAR_CURRENT == rep then
							timer.Simple(30, function()
								combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
								combine:CombineRequestAnswer("Артбатарея заряжена и готова выполнить приказ!!")

								COMBINE_MORTAR_ISFIRING = false
							end)
						end
					end)
				else
					local reloadtime = 0.5 * COMBINE_MORTAR_COUNT
					timer.Simple(reloadtime, function()						
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Артбатарея заряжена и готова выполнить приказ!")

						COMBINE_MORTAR_ISFIRING = false
					end)
				end
			end)
		end
	end
end

COMMAND:Register();