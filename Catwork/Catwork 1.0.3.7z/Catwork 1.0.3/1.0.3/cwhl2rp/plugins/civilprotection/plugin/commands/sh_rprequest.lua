--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("rprequest")
COMMAND.tip = "Запрос начисления очков репутации гражданину."
COMMAND.text = "<string CID> <string REASON> <number AMOUNT>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 3

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if combine:GetFaction() == FACTION_MPF then
		local stringCID = arguments[1]
		local stringREASON = arguments[2]
		local numberAMOUNT = tonumber(arguments[3])

		for k, citizen in pairs(player.GetAll()) do
			if citizen:GetCharacterData("citizenid") == arguments[1] then
				if citizen:GetFaction() == FACTION_CITIZEN or citizen:GetFaction() == FACTION_CWU or citizen:GetFaction() == FACTION_REBEL or citizen:GetFaction() == FACTION_REFUGE or citizen:GetFaction() == FACTION_RENEG  then				
					combine:EmitSound("npc/combine_soldier/vo/on2.wav")
					combine:CombineRequestSay("Центр, зачислите очки репутации гражданину #"..stringCID..", причина: "..stringREASON..", количество очков: "..numberAMOUNT..".")

					citizen:SetCharacterData("civ_reputation", math.Clamp(citizen:GetCharacterData("civ_reputation") + numberAMOUNT, 0, 150))					

					local newBMD = citizen:GetCharacterData("civ_reputation")
					timer.Simple(2, function()
						combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
						combine:CombineRequestAnswer("Очки репутации гражданину #"..stringCID.." были начислены. Гражданин получил "..numberAMOUNT.." очков репутации, общее количество: "..newBMD.."/150.")
					end)

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не юнит ГО!")
	end
end

COMMAND:Register();