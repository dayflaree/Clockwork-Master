local COMMAND = Clockwork.command:New("CPTpRequest")
COMMAND.tip = "Запрос на начисление Очков Выговора выбранному юниту."
COMMAND.text = "<string CID> <string REASON> <number AMOUNT>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 3

function COMMAND:OnRun(combine, arguments)
	if combine:GetFaction() == FACTION_MPF then
		if Schema:IsPlayerCombineRank(combine, {"CmD","SeC", "MaJ", "CpT", "OfC"}) then
			local UID = arguments[1]
			local stringREASON = arguments[2]
			local numberAMOUNT = arguments[3]

			for k, v in pairs(player.GetAll()) do
				if Schema:PlayerIsCombine(v) then
					local digits = string.match(v:GetName(),"CP%:.*%..*%.(%d+)")
					if digits == UID then
						combine:CombineRequestSay("Центр, зачислите очки выговора юниту #"..UID..", причина: "..stringREASON..", количество очков: "..numberAMOUNT..".")

						v:SetCharacterData("cp_traitpoints", math.Clamp(v:GetCharacterData("cp_traitpoints") + numberAMOUNT, 0, 50))			

						local newBMD = v:GetCharacterData("cp_traitpoints")
						timer.Simple(2, function()
							combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
							combine:CombineRequestAnswer("Очки выговора юниту #"..UID.." были начислены. Юнит получил "..numberAMOUNT.." очков выговора, общее количество: "..newBMD.."/50.")
						end)
					end
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();