--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("relrequest")
COMMAND.tip = "Запрос освобождения гражданина."
COMMAND.text = "<string CID>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if Schema:PlayerIsCombine(combine) then
		local stringCID = arguments[1]
		for k, citizen in pairs(player.GetAll()) do
			if citizen:GetCharacterData("citizenid") == stringCID then
				if citizen:GetFaction() == FACTION_CITIZEN or citizen:GetFaction() == FACTION_CWU or citizen:GetFaction() == FACTION_REBEL or citizen:GetFaction() == FACTION_REFUGE or citizen:GetFaction() == FACTION_RENEG then
					combine:CombineRequestSay("Подаю рапорт об освобождении гражданина #"..stringCID..".''")

					if citizen:GetCharacterData("civ_jail_type") != "#N" then								
						citizen:SetCharacterData("civ_jail_type", "#N")
						timer.Simple(2, function()
							if combine:Alive() then							
								combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
								combine:CombineRequestAnswer("Рапорт об освобождении гражданина #"..stringCID.." был подтвержден.''")
							end
						end)
					elseif citizen:GetCharacterData("civ_jail_type") == "#N" then
						timer.Simple(2, function()
							if combine:Alive() then							
								combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
								combine:CombineRequestAnswer("Отказано. Гражданин #"..stringCID.." не в изоляции.''")
							end
						end)							
					end

					break
				end
			end
		end
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();