--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("IsoInfoRequest")
COMMAND.tip = "Запрос информации о заключенных."
COMMAND.text = ""
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(combine, arguments)
	if Schema:PlayerIsCombine(combine) then
			combine:EmitSound("npc/combine_soldier/vo/on2.wav")
			combine:CombineRequestSay("Запрашиваю информацию о заключённых.")

		timer.Simple(2, function()					
			combine:EmitSound("npc/combine_soldier/vo/off"..math.random(1, 2)..".wav")
			combine:CombineRequestAnswer("Запрос информации о заключённых был подтвержден.")

			local i = 0

			for k,v in pairs(player.GetAll()) do
				if v:GetFaction() == FACTION_CITIZEN or v:GetFaction() == FACTION_CWU then
					if v:GetCharacterData("civ_jail_type") != "#N" then
						local civ_citizenid = v:GetCharacterData("citizenid")

						i = i + 1
						combine:CombineRequestAnswer(tostring(i)..". "..v:GetName().." #"..civ_citizenid..".")
						combine:CombineRequestAnswer("Причина задержания: "..v:GetCharacterData("civ_jail_type")..".")
						combine:CombineRequestAnswer("Срок (осталось): "..math.Round((tonumber(v:GetCharacterData("civ_jail_time"))/60)).." минут(ы/а).")
					end
				end
			end
		end)
	else
		Clockwork.player:Notify(combine, "Вы не сотрудник ГО!")
	end
end

COMMAND:Register();