local ITEM = Clockwork.item:New()
ITEM.name = "Дозиметр"
ITEM.uniqueID = "geiger_counter"
ITEM.cost = 0
ITEM.model = "models/kali/miscstuff/stalker/sensor_a.mdl"
ITEM.weight = 0.1
ITEM.business = true
ITEM.description = "Старый на вид прибор для измерения радиационного фона."

function ITEM:OnDrop(player, position) end

ITEM:Register()