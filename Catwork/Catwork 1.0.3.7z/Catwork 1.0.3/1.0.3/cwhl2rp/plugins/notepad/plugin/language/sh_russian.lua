--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("ru");

lang["#Notepad_Title"] = "Блокнот";
lang["#Notepad_Written"] = "На нём что-то написано.";
lang["#Notepad_Blank"] = "На нём ничего не написано.";
lang["#Notepad_Read"] = "Читать";
lang["#Notepad_Write"] = "Написать";
lang["#Notepad_Edit"] = "Редактировать";
lang["#Notepad_CannotEdit"] = "Данный блокнот не принадлежит вам!";