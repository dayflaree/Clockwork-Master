--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

PLUGIN:SetGlobalAlias("cwNotepad");

cwNotepad.notepadIDs = cwNotepad.notepadIDs or {};

CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");
CW.kernel:IncludePrefixed("sv_hooks.lua");