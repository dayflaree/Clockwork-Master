--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.kernel:IncludePrefixed("cl_schema.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");
CW.kernel:IncludePrefixed("cl_theme.lua");
CW.kernel:IncludePrefixed("sh_hooks.lua");
CW.kernel:IncludePrefixed("sv_schema.lua");
CW.kernel:IncludePrefixed("sv_hooks.lua");

Schema.customPermits = Schema.customPermits or {};

for k, v in pairs(_file.Find("models/humans/group17/*.mdl", "GAME")) do
	CW.animation:AddMaleHumanModel("models/humans/group17/"..v);
end;

CW.animation:AddCivilProtectionModel("models/eliteghostcp.mdl");
CW.animation:AddCivilProtectionModel("models/eliteshockcp.mdl");
CW.animation:AddCivilProtectionModel("models/leet_police2.mdl");
CW.animation:AddCivilProtectionModel("models/sect_police2.mdl");
CW.animation:AddCivilProtectionModel("models/policetrench.mdl");

CW.option:SetKey("default_date", {month = 1, year = 2016, day = 1});
CW.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});
CW.option:SetKey("format_singular_cash", "%a");
CW.option:SetKey("model_shipment", "models/items/item_item_crate.mdl");
CW.option:SetKey("intro_image", "halfliferp/hl2rp_logo");
CW.option:SetKey("schema_logo", "halfliferp/hl2rp_logo");
CW.option:SetKey("format_cash", "%a %n");
CW.option:SetKey("menu_music", "music/hl2_song19.mp3");
CW.option:SetKey("name_cash", "#HL2RP_CashName");
CW.option:SetKey("model_cash", "models/props_lab/box01a.mdl");
CW.option:SetKey("gradient", "halfliferp/bg_gradient");

CW.config:ShareKey("intro_text_small");
CW.config:ShareKey("intro_text_big");
CW.config:ShareKey("business_cost");
CW.config:ShareKey("permits");

CW.quiz:SetEnabled(true);
CW.quiz:AddQuestion("#Quiz_Question1", 1, "#Quiz_Yes", "#Quiz_No");
CW.quiz:AddQuestion("#Quiz_Question2", 2, "#Quiz_Question2_BrainDead", "#Quiz_Question2_Correct");
CW.quiz:AddQuestion("#Quiz_Question3", 1, "#Quiz_Yes", "#Quiz_No");
CW.quiz:AddQuestion("#Quiz_Question4", 1, "#Quiz_Yes", "#Quiz_No");
CW.quiz:AddQuestion("#Quiz_Question5", 2, "#Quiz_Question5_Wrong", "#Quiz_Question5_Correct");
CW.quiz:AddQuestion("#Quiz_Question6", 2, "#Quiz_Question6_Wrong", "#Quiz_Question6_Correct");

CW.flag:Add("v", "Light Blackmarket", "Access to light blackmarket goods.");
CW.flag:Add("V", "Heavy Blackmarket", "Access to heavy blackmarket goods.");
CW.flag:Add("m", "Resistance Manager", "Access to the resistance manager's goods.");

-- A function to add a custom permit.
function Schema:AddCustomPermit(name, flag, model)
	local formattedName = string.gsub(name, "[%s%p]", "");
	local lowerName = string.lower(name);
	
	self.customPermits[ string.lower(formattedName) ] = {
		model = model,
		name = name,
		flag = flag,
		key = CW.kernel:SetCamelCase(formattedName, true)
	};
end;

-- A function to check if a string is a Combine rank.
function Schema:IsStringCombineRank(text, rank)
	if (type(rank) == "table") then
		for k, v in ipairs(rank) do
			if (self:IsStringCombineRank(text, v)) then
				return true;
			end;
		end;
	elseif (rank == "EpU") then
		if (string.find(text, "%pSeC%p") or string.find(text, "%pDvL%p")
		or string.find(text, "%pEpU%p")) then
			return true;
		end;
	else
		return string.find(text, "%p"..rank.."%p");
	end;
end;

-- A function to check if a player is a Combine rank.
function Schema:IsPlayerCombineRank(player, rank, realRank)
	local name = player:Name();
	local faction = player:GetFaction();
	
	if (self:IsCombineFaction(faction)) then
		if (type(rank) == "table") then
			for k, v in ipairs(rank) do
				if (self:IsPlayerCombineRank(player, v, realRank)) then
					return true;
				end;
			end;
		elseif (rank == "EpU" and !realRank) then
			if (string.find(name, "%pSeC%p") or string.find(name, "%pDvL%p")
			or string.find(name, "%pEpU%p")) then
				return true;
			end;
		else
			return string.find(name, "%p"..rank.."%p");
		end;
	end;
end;

-- A function to get a player's Combine rank.
function Schema:GetPlayerCombineRank(player)
	local faction = player:GetFaction();
	
	if (faction == FACTION_OTA) then
		if (self:IsPlayerCombineRank(player, "OWS")) then
			return 0;
		elseif (self:IsPlayerCombineRank(player, "EOW")) then
			return 1;
		else
			return 2;
		end;
	elseif (self:IsPlayerCombineRank(player, "RCT")) then
		return 0;
	elseif (self:IsPlayerCombineRank(player, "04")) then
		return 1;
	elseif (self:IsPlayerCombineRank(player, "03")) then
		return 2;
	elseif (self:IsPlayerCombineRank(player, "02")) then
		return 3;
	elseif (self:IsPlayerCombineRank(player, "01")) then
		return 4;
	elseif (self:IsPlayerCombineRank(player, "OfC")) then
		return 6;
	elseif (self:IsPlayerCombineRank(player, "EpU", true)) then
		return 7;
	elseif (self:IsPlayerCombineRank(player, "DvL")) then
		return 8;
	elseif (self:IsPlayerCombineRank(player, "SeC")) then
		return 9;
	elseif (self:IsPlayerCombineRank(player, "SCN")) then
		if (!self:IsPlayerCombineRank(player, "SYNTH")) then
			return 10;
		else
			return 11;
		end;
	else
		return 5;
	end;
end;

-- A function to get if a faction is Combine.
function Schema:IsCombineFaction(faction)
	return (faction == FACTION_MPF or faction == FACTION_OTA);
end;