--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New("ammo_base");
	ITEM.name = "Pulse-Rifle Orb";
	ITEM.cost = 80;
	ITEM.classes = {CLASS_EOW};
	ITEM.model = "models/items/combine_rifle_ammo01.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_ar2altfire";
	ITEM.business = true;
	ITEM.ammoClass = "ar2altfire";
	ITEM.ammoAmount = 1;
	ITEM.description = "A strange item which an orange glow emitting from it.";
ITEM:Register();