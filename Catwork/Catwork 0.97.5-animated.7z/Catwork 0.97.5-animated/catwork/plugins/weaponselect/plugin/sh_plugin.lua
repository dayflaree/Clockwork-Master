--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	You don't have to do this, but I think it's nicer.
	Alternatively, you can simply use the PLUGIN variable.
--]]
PLUGIN:SetGlobalAlias("cwWeaponSelect");

--[[ You don't have to do this either, but I prefer to seperate the functions. --]]
CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");

CW.config:ShareKey("weapon_selection_multi");

if (CLIENT) then
	cwWeaponSelect.displaySlot = 0;
	cwWeaponSelect.displayFade = 0;
	cwWeaponSelect.displayAlpha = 0;
	cwWeaponSelect.displayDelay = 0;
	cwWeaponSelect.weaponPrintNames = cwWeaponSelect.weaponPrintNames or {};
end;