--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Roll");
COMMAND.tip = "#Commands_RollDesc";
COMMAND.text = "[number Range]";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local number = math.Clamp(math.floor(tonumber(arguments[1]) or 100), 0, 1000000000);
	local roll = math.random(0, number)
	local target = player:GetEyeTraceNoCursor().Entity;
	local PVPMode = false;
	
	if (IsValid(target) and typeof(target) == "player") then
		PVPMode = true;
	end;
	
	local adjust, adjust2 = plugin.Call("AdjustRollNumber", player, roll, number, (PVPMode and target) or nil);
	adjust = adjust or 0;
	adjust2 = adjust2 or 0;
	
	roll = roll + adjust;
	
	if (PVPMode) then
		chatbox.AddText(nil, "* PVP:", {filter = "player_events", textColor = Color("#EE7542"), icon = false, position = player:GetPos()});
		
		chatbox.AddText(nil, L(player, "HasRolled", player:Name(), roll, number), {textColor = Color("#EE7542"), filter = "player_events", icon = "icon16/lightning.png", position = player:GetPos()});
		CW.kernel:PrintLog(LOGTYPE_GENERIC, L("LogHasRolled", player:Name(), roll, number));
		
		local roll2 = math.random(0, number);
		roll2 = roll2 + adjust2;
		
		chatbox.AddText(nil, L(target, "HasRolled", target:Name(), roll2, number), {textColor = Color("#EE7542"), filter = "player_events", icon = "icon16/lightning.png", position = player:GetPos()});
		CW.kernel:PrintLog(LOGTYPE_GENERIC, L("LogHasRolled", player:Name(), roll2, number));
	else
		chatbox.AddText(nil, L(player, "HasRolled", player:Name(), roll, number), {textColor = Color("#EE4343"), filter = "player_events", icon = "icon16/lightning.png", position = player:GetPos()});
		CW.kernel:PrintLog(LOGTYPE_GENERIC, L("LogHasRolled", player:Name(), roll, number));
	end;
end;

COMMAND:Register();