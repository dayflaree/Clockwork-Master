--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Announce");

COMMAND.tip = "Announce something to all players.";
COMMAND.text = "<string Text>";
COMMAND.arguments = 1;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");

 	CW.player:NotifyAll(text);
end;

COMMAND:Register();