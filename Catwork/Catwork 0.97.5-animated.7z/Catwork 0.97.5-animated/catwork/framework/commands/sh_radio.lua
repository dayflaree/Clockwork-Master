--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Radio");
COMMAND.tip = "#Commands_RDesc";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 1;
COMMAND.alias = {"R"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	CW.player:SayRadio(player, table.concat(arguments, " "), true);
end;

COMMAND:Register();