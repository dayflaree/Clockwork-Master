--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local lang = CW.lang:GetTable("en");

lang.name = "English";

-- Config Print
lang["#ConfigVariablesPrinted"] = "The config variables have been printed to the console.";

-- Various Error Messages
lang["#CannotPurchaseAnotherDoor"] = "You cannot purchase another door!";
lang["#EntityOptionWaitTime"] = "You cannot use another entity that fast!";
lang["#YouNeedAnother"] = "You need another #1!";
lang["#NotEnoughText"] = "You did not specify enough text!";
lang["#NotValidMap"] = "#1 is not a valid map!"
lang["#CannotChangeClassFor"] = "You cannot change class for another #1 second(s)!";
lang["#CannotActionRightNow"] = "You cannot do this action at the moment!";
lang["#DroppedItemsOtherChar"] = "You cannot pick up items you dropped on another character!";
lang["#DroppedCashOtherChar"] = "You cannot pick up #1 you dropped on another character!";
lang["#NotValidCharacter"] = "#1 is not a valid character!";
lang["#NotValidPlayer"] = "#1 is not a valid player!";
lang["#NotValidAmount"] = "This is not a valid amount!";

-- Roll Message
lang["#HasRolled"] = "#1 has rolled #2 out of #3.";
lang["#LogHasRolled"] = "#1 has rolled #2 out of #3!";

-- Cash Set Messages
lang ["CashSetTarget"] = "Your #1 was set to #2 by #3."
lang ["CashSetPlayer"] = "You have set #1's #2 to #3."

-- Storage Error Messages
lang["#StorageNoInstance"] = "The storage does not contain an instance of this item!";
lang["#StorageNotOpen"] = "You do not have storage open!";
lang["#StorageCannotGive"] = "You cannot give items to this container!";
lang["#StoragePlayerNoInstance"] = "You do not have an instance of this item!";

-- Class Error Messages
lang["#ClassNoAccess"] = "You do not have access to this class!";
lang["#ClassTooMany"] = "There are too many characters with this class!";
lang["#ClassNotValid"] = "This is not a valid class!";

-- Voicemail Notifies
lang["#VoicemailRemoved"] = "You have removed your voicemail.";
lang["#VoicemailSet"] = "You have set your voicemail to '#1'.";

-- Weapon Error Messages
lang["#CannotHolsterWeapon"] = "You cannot holster this weapon!";
lang["#CannotDropWeapon"] = "You cannot drop this weapon!";
lang["#CannotUseWeapon"] = "You cannot use this weapon!";

-- Config Error Messages
lang["#ConfigUnableToSet"] = "#1 was unable to be set!";
lang["#ConfigIsStaticKey"] = "#1 is a static config key!";
lang["#ConfigKeyNotValid"] = "#1 is not a valid config key!";

-- Settings Categories
lang["#Framework"] = "Framework";
lang["#ChatBox"] = "Chat Box";
lang["#Theme"] = "Theme";
lang["#AdminESP"] = "Admin ESP";
	
-- Settings Info Text
lang["#SettingsInfoText"] = "These settings are client-side to help you personalise Clockwork.";
lang["#NoSettingsInfoText"] = "You do not have access to any settings!";

-- Settings Descriptions
lang["#ThemeDesc"] = "The current active GUI theme to display.";
lang["#EnableAdminESPDesc"] = "Whether or not to show the admin ESP.";
lang["#DrawESPBarsDesc"] = "Whether or not to draw progress bars for certain values.";
lang["#ShowItemEntitiesDesc"] = "Whether or not to view items in the admin ESP.";
lang["#ShowSalesmenEntitiesDesc"] = "Whether or not to view salesmen in the admin ESP.";
lang["#ESPIntervalDesc"] = "The amount of time between ESP checks.";
lang["#TwelveHourClockDesc"] = "Whether or not to show a twelve hour clock.";
lang["#ShowBarsDesc"] = "Whether or not to show bars at the top of the screen.";
lang["#EnableHintsDesc"] = "Whether or not to show you any hints.";
lang["#LangDesc"] = "The currently selected language.";
lang["#EnableVignetteDesc"] = "Whether or not to draw the vignette.";
lang["#ShowTimestampsDesc"] = "Whether or not to show you timestamps on messages.";
lang["#ShowCWMessagesDesc"] = "Whether or not to show you any Clockwork messages.";
lang["#ShowServerMessagesDesc"] = "Whether or not to show you any server messages.";
lang["#ShowOOCMessagesDesc"] = "Whether or not to show you any out-of-character messages.";
lang["#ShowICMessagesDesc"] = "Whether or not to show you any in-character messages.";
lang["#HeadbobAmountDesc"] = "The amount to scale the headbob by.";
lang["#ChatLinesDesc"] = "The amount of chat lines shown at once.";
lang["#EnableConsoleLogDesc"] = "Whether or not to show the admin console log.";
lang["#TextColorDesc"] = "The information color used mostly in the text of the theme.";
lang["#BGColorDesc"] = "The Background Color.";
lang["#TabMenuXDesc"] = "The position of the tab menu on the X axis.";
lang["#TabMenuYDesc"] = "The position of the tab menu on the Y axis.";
lang["#BackMenuXDesc"] = "The position of the background on the X axis.";
lang["#BackMenuYDesc"] = "The position of the background on the Y axis.";
lang["#BackMenuWDesc"] = "The width of the background.";
lang["#BackMenuHDesc"] = "The height of the background.";
lang["#FadePanelsDesc"] = "Whether or not to fade in and out menu panels.";
lang["#ShowMaterialDesc"] = "Whether or not to show a material background.";
lang["#ShowGradientDesc"] = "Whether or not to show a gradient background.";
lang["#MenuMaterialDesc"] = "The material to be used for the tab menu.";

-- Settings Names
lang["#EnableAdminESP"] = "Enable the Admin ESP.";
lang["#DrawESPBars"] = "Draw ESP Bars.";
lang["#ShowSpawnPoints"] = "Show Spawn Points.";
lang["#ShowStaticEnts"] = "Show Static Entities.";
lang["#ShowItemEntities"] = "Show Item Entities.";
lang["#ShowSalesmenEntities"] = "Show Salesmen Entities.";
lang["#ESPInterval"] = "ESP Interval:";
lang["#TwelveHourClock"] = "Enable the twelve hour clock.";
lang["#ShowBars"] = "Show bars at the top of the screen.";
lang["#EnableHints"] = "Enable the hints system.";
lang["#Language"] = "Language";
lang["#EnableVignette"] = "Enable Vignette";
lang["#ShowTimestamps"] = "Show timestamps on messages.";
lang["#ShowCWMessages"] = "Show messages related to Clockwork.";
lang["#ShowServerMessages"] = "Show messages from the server.";
lang["#ShowOOCMessages"] = "Show out-of-character messages.";
lang["#ShowICMessages"] = "Show in-character messages.";
lang["#HeadbobAmount"] = "Headbob Amount:";
lang["#ChatLines"] = "Chat Lines:";
lang["#EnableConsoleLog"] = "Enable the admin console log.";
lang["#TextColor"] = "Text Color:";
lang["#BGColor"] = "Background Color:";
lang["#TabMenuX"] = "TabMenu X-Axis:";
lang["#TabMenuY"] = "TabMenu Y-Axis:";
lang["#BackMenuX"] = "BackMenu X-Axis:";
lang["#BackMenuY"] = "BackMenu Y-Axis:";
lang["#BackMenuW"] = "BackMenu Width:";
lang["#BackMenuH"] = "BackMenu Height:";
lang["#FadePanels"] = "Fade Panels:";
lang["#ShowMaterial"] = "Show Material:";
lang["#ShowGradient"] = "Show Gradient:";
lang["#MenuMaterial"] = "Material:";

--[[
	You don't HAVE to translate the config, but I feel like it'd be 
	easier for server owners / SAs who have trouble with English.
--]]

-- Config Descriptions
lang["#AttributeProgressionScaleDesc"] = "The amount to scale attribute progress by.";
lang["#MessagesMustSeePlayerDesc"] = "Whether or not you must see a player to hear some in-character messages.";
lang["#StartingAttributePointsDesc"] = "The default amount of attribute points that a player has.";
lang["#ClockworkIntroEnabledDesc"] = "Enable the Clockwork introduction for new players.";
lang["#HealthRegenerationEnabledDesc"] = "Whether or not health regeneration is enabled.";
lang["#PropProtectionEnabledDesc"] = "Whether or not to enable prop protection.";
lang["#UseLocalMachineDateDesc"] = "Whether or not to use the local machine's date when the map is loaded.";
lang["#UseLocalMachineTimeDesc"] = "Whether or not to use the local machine's time when the map is loaded.";
lang["#UseKeyOpensEntityMenusDesc"] = "Whether or not 'use' opens the context menus.";
lang["#ShootAfterRaiseDelayDesc"] = "The time that it takes for players to be able to shoot after raising their weapon (seconds).\nSet to 0 for no time.";
lang["#UseClockworkAdminSystemDesc"] = "Whether or not you use a different group or admin system to CW.";
lang["#SavedRecognisedNamesDesc"] = "Whether or not recognised names should be saved.";
lang["#SaveAttributeBoostsDesc"] = "Whether or not attribute boosts are saved.";
lang["#RagdollDamageImmunityTimeDesc"] = "The time that a player's ragdoll is immune from damage (seconds).";
lang["#AdditionalCharacterCountDesc"] = "The additional amount of characters that each player can have.";
lang["#ClassChangingIntervalDesc"] = "The time that a player has to wait to change class again (seconds).";
lang["#SprintingLowersWeaponDesc"] = "Whether or not sprinting lowers a player's weapon.";
lang["#WeaponRaisingSystemDesc"] = "Whether or not the raised weapon system is enabled.";
lang["#PropKillProtectionDesc"] = "Whether or not prop kill protection is enabled.";
lang["#SmoothServerRatesDesc"] = "Whether or not to use Clockwork smooth rates.";
lang["#MediumServerRatesDesc"] = "Whether or not to use Clockwork mid performance rates (bars will be less smooth).";
lang["#LagFreeServerRatesDesc"] = "Whether or not to use Clockwork max performance rates (kills all lags, screws up bars).";
lang["#GeneratorIntervalDesc"] = "The time that it takes for generator cash to be distrubuted (seconds).";
lang["#GravityGunPuntDesc"] = "Whether or not to enable entities to be punted with the gravity gun.";
lang["#DefaultInventoryWeightDesc"] = "The default inventory weight (kilograms).";
lang["#DefaultInventorySpaceDesc"] = "The default inventory space (litres).";
lang["#DataSaveIntervalDesc"] = "The time that it takes for data to be saved (seconds).";
lang["#ViewPunchOnDamageDesc"] = "Whether or not a player's view gets punched when they take damage.";
lang["#UnrecognisedNameDesc"] = "The name that is given to unrecognised players.";
lang["#LimbDamageSystemDesc"] = "Limb Damage System Enabled";
lang["#FallDamageScaleDesc"] = "The amount to scale fall damage by.";
lang["#StartingCurrencyDesc"] = "The default amount of cash that each player starts with.";
lang["#ArmorAffectsChestDesc"] = "Whether or not armor only affects the chest.";
lang["#MinimumPhysicalDescriptionDesc"] = "The minimum amount of characters a player must have in their physical description.";
lang["#WoodBreaksFallDesc"] = "Whether or not wooden physics entities break a player's fall.";
lang["#VignetteEnabledDesc"] = "Whether or not the vignette is enabled.";
lang["#HeartbeatSoundsDesc"] = "Whether or not the heartbeat is enabled.";
lang["#CrosshairEnabledDesc"] = "Whether or not the crosshair is enabled.";
lang["#FreeAimingDesc"] = "Whether or not free aiming is enabled.";
lang["#RecogniseSystemDesc"] = "Whether or not the recognise system is enabled.";
lang["#CurrencyEnabledDesc"] = "Whether or not cash is enabled.";
lang["#DefaultPhysicalDescriptionDesc"] = "The physical description that each player begins with.";
lang["#ChestDamageScaleDesc"] = "The amount to scale chest damage by.";
lang["#CorpseDecayTimeDesc"] = "The time that it takes for a player's ragdoll to decay (seconds).";
lang["#BannedDisconnectMessageDesc"] = "The message that a player receives when trying to join while banned.\n!t for the time left, !f for the time format.";
lang["#WagesIntervalDesc"] = "The time that it takes for wages cash to be distrubuted (seconds).";
lang["#PropCostScaleDesc"] = "How to much to scale prop cost by.\nSet to 0 to to make props free.";
lang["#FadeNPCCorpsesDesc"] = "Whether or not to fade dead NPCs.";
lang["#CashWeightDesc"] = "The weight of cash (kilograms).";
lang["#CashSpaceDesc"] = "The amount of space cash takes (litres).";
lang["#HeadDamageScaleDesc"] = "The amount to scale head damage by.";
lang["#BlockInventoryBindsDesc"] = "Whether or not inventory binds should be blocked for players.";
lang["#LimbDamageScaleDesc"] = "The amount to scale limb damage by.";
lang["#TargetIDDelayDesc"] = "The delay before the Target ID is displayed when looking at an entity.";
lang["#HeadbobEnabledDesc"] = "Whether or not to enable headbob.";
lang["#ChatCommandPrefixDesc"] = "The prefix that is used for chat commands.";
lang["#CrouchWalkSpeedDesc"] = "The speed that characters walk at when crouched.";
lang["#MaximumChatLengthDesc"] = "The maximum amount of characters that can be typed in chat.";
lang["#StartingFlagsDesc"] = "The flags that each player begins with.";
lang["#PlayerSprayDesc"] = "Whether players can spray their tags.";
lang["#HintIntervalDesc"] = "The time that a hint is displayed to each player (seconds).";
lang["#OOCChatIntervalDesc"] = "The time that a player has to wait to speak out-of-character again (seconds).\nSet to 0 for never.";
lang["#MinuteTimeDesc"] = "The time that it takes for a minute to pass (seconds).";
lang["#DoorUnlockIntervalDesc"] = "The time that a player has to wait to unlock a door (seconds).";
lang["#VoiceChatEnabledDesc"] = "Whether or not voice chat is enabled.";
lang["#LocalVoiceChatDesc"] = "Whether or not to enable local voice.";
lang["#TalkRadiusDesc"] = "The radius of each player that other characters have to be in to hear them talk (units).";
lang["#GiveHandsDesc"] = "Whether or not to give hands to each player.";
lang["#CustomWeaponColorDesc"] = "Whether or not to enable custom weapon colors.";
lang["#GiveKeysDesc"] = "Whether or not to give keys to each player.";
lang["#WagesNameDesc"] = "The name that is given to wages.";
lang["#JumpPowerDesc"] = "The power that characters jump at.";
lang["#RespawnDelayDesc"] = "The time that a player has to wait before they can spawn again (seconds).";
lang["#MaximumWalkSpeedDesc"] = "The speed that characters walk at.";
lang["#MaximumRunSpeedDesc"] = "The speed that characters run at.";
lang["#DoorPriceDesc"] = "The amount of cash that each door costs.";
lang["#DoorLockIntervalDesc"] = "The time that a player has to wait to lock a door (seconds).";
lang["#MaximumOwnableDoorsDesc"] = "The maximum amount of doors a player can own.";
lang["#EnableSpaceSystemDesc"] = "Whether or not to use the space system that affects inventories.";
lang["#DrawIntroBarsDesc"] = "Whether or not to draw cinematic intro black bars on top and bottom of the screen.";
lang["#EnableJoggingDesc"] = "Whether or not to enable jogging.";
lang["#EnableLOOCIconsDesc"] = "Whether or not to enable LOOC chat icons.";
lang["#ShowBusinessMenuDesc"] = "Whether or not to show the business menu.";
lang["#EnableChatMultiplierDesc"] = "Whether or not to change text size based on types of chat.";
lang["#SteamAPIKeyDesc"] = "Some non-essential features may require the usage of the Steam API.\nhttp://steamcommunity.com/dev/apikey";
lang["#MapPropsPhysgrabDesc"] = "Whether or not players will be able to grab map props and doors with physguns.";
lang["#EntityUseCooldownDesc"] = "The amount of time between entity uses a player has to wait.";
lang["#EnableSmoothSprintDesc"] = "Whether or not smooth sprinting will be used.";
lang["#EnableQuickRaiseDesc"] = "Whether or not players can use quick raising to raise their weapons.";
lang["#PlayersChangeThemesDesc"] = "Whether or not players can switch between available themes.";
lang["#DefaultThemeDesc"] = "The default theme that players will start with.";
lang["#EnableIronsightsDesc"] = "Whether or not players can use ironsights on their weapons when available.";
lang["#IronsightsSpreadReductionDesc"] = "The amount that ironsights will reduce bullet spread by.";
lang["#IronsightsSlowAmountDesc"] = "The amount that using ironsights will decrease a player's movement speed by.";

-- Config Names
lang["#AttributeProgressionScale"] = "Attribute Progression Scale";
lang["#MessagesMustSeePlayer"] = "Messages Must See Player";
lang["#StartingAttributePoints"] = "Starting Attribute Points";
lang["#ClockworkIntroEnabled"] = "Clockwork Introduction Enabled";
lang["#HealthRegenerationEnabled"] = "Health Regeneration Enabled";
lang["#PropProtectionEnabled"] = "Prop Protection Enabled";
lang["#UseLocalMachineDate"] = "Use Local Machine Date";
lang["#UseLocalMachineTime"] = "Use Local Machine Time";
lang["#UseKeyOpensEntityMenus"] = "Use Key Opens Entity Menus";
lang["#ShootAfterRaiseDelay"] = "Shoot After Raise Delay";
lang["#UseClockworkAdminSystem"] = "Use Clockwork's Admin System";
lang["#SavedRecognisedNames"] = "Saved Recognised Names";
lang["#SaveAttributeBoosts"] = "Save Attribute Boosts";
lang["#RagdollDamageImmunityTime"] = "Ragdoll Damage Immunity Time";
lang["#AdditionalCharacterCount"] = "Additional Character Count";
lang["#ClassChangingInterval"] = "Class Changing Interval";
lang["#SprintingLowersWeapon"] = "Sprinting Lowers Weapon";
lang["#WeaponRaisingSystem"] = "Weapon Raising System Enabled";
lang["#PropKillProtection"] = "Prop Kill Protection Enabled";
lang["#SmoothServerRates"] = "Use Smooth Server Rates";
lang["#MediumServerRates"] = "Use Medium Performance Server Rates";
lang["#LagFreeServerRates"] = "Use Lag Free Server Rates";
lang["#GeneratorInterval"] = "Generator Interval";
lang["#GravityGunPunt"] = "Gravity Gun Punt Enabled";
lang["#DefaultInventoryWeight"] = "Default Inventory Weight";
lang["#DefaultInventorySpace"] = "Default Inventory Space";
lang["#DataSaveInterval"] = "Data Save Interval";
lang["#ViewPunchOnDamage"] = "View Punch On Damage";
lang["#UnrecognisedName"] = "Unrecognised Name";
lang["#LimbDamageSystem"] = "Limb Damage System Enabled";
lang["#FallDamageScale"] = "Fall Damage Scale";
lang["#StartingCurrency"] = "Starting Currency";
lang["#ArmorAffectsChest"] = "Armor Affects Chest Only";
lang["#MinimumPhysicalDescription"] = "Minimum Physical Description Length";
lang["#WoodBreaksFall"] = "Wood Breaks Fall";
lang["#VignetteEnabled"] = "Vignette Enabled";
lang["#HeartbeatSounds"] = "Heartbeat Sounds Enabled"; //Day 132. Still converting strings..
lang["#CrosshairEnabled"] = "Crosshair Enabled";
lang["#FreeAiming"] = "Free Aiming Enabled";
lang["#RecogniseSystem"] = "Recognise System Enabled";
lang["#CurrencyEnabled"] = "Currency Enabled";
lang["#DefaultPhysicalDescription"] = "Default Physical Description";
lang["#ChestDamageScale"] = "Chest Damage Scale";
lang["#CorpseDecayTime"] = "Corpse Decay Time";
lang["#BannedDisconnectMessage"] = "Banned Disconnect Message";
lang["#WagesInterval"] = "Wages Interval";
lang["#PropCostScale"] = "Prop Cost Scale";
lang["#FadeNPCCorpses"] = "Fade NPC Corpses";
lang["#CashWeight"] = "Cash Weight";
lang["#CashSpace"] = "Cash Space";
lang["#HeadDamageScale"] = "Head Damage Scale";
lang["#BlockInventoryBinds"] = "Block Inventory Binds";
lang["#LimbDamageScale"] = "Limb Damage Scale";
lang["#TargetIDDelay"] = "Target ID Delay";
lang["#HeadbobEnabled"] = "Headbob Enabled";
lang["#ChatCommandPrefix"] = "Chat Command Prefix";
lang["#CrouchWalkSpeed"] = "Crouch Walk Speed";
lang["#MaximumChatLength"] = "Maximum Chat Length";
lang["#StartingFlags"] = "Starting Flags";
lang["#PlayerSpray"] = "Player Spray Enabled";
lang["#HintInterval"] = "Hint Interval";
lang["#OOCChatInterval"] = "Out-Of-Character Chat Interval";
lang["#MinuteTime"] = "Minute Time";
lang["#DoorUnlockInterval"] = "Door Unlock Interval";
lang["#VoiceChatEnabled"] = "Voice Chat Enabled";
lang["#LocalVoiceChat"] = "Local Voice Chat";
lang["#TalkRadius"] = "Talk Radius";
lang["#GiveHands"] = "Give Hands";
lang["#CustomWeaponColor"] = "Custom Weapon Color";
lang["#GiveKeys"] = "Give Keys";
lang["#WagesName"] = "Wages Name";
lang["#JumpPower"] = "Jump Power";
lang["#RespawnDelay"] = "Respawn Delay"; // Send help...
lang["#MaximumWalkSpeed"] = "Maximum Walk Speed";
lang["#MaximumRunSpeed"] = "Maximum Run Speed";
lang["#DoorPrice"] = "Door Price";
lang["#DoorLockInterval"] = "Door Lock Interval";
lang["#MaximumOwnableDoors"] = "Maximum Ownable Doors";
lang["#EnableSpaceSystem"] = "Enable Space System";
lang["#DrawIntroBars"] = "Draw Intro Bars";
lang["#EnableJogging"] = "Enable Jogging";
lang["#EnableLOOCIcons"] = "Enable LOOC Icons";
lang["#ShowBusinessMenu"] = "Show Business Menu";
lang["#EnableChatMultiplier"] = "Enable Chat Multiplier";
lang["#SteamAPIKey"] = "Steam API Key";
lang["#MapPropsPhysgrab"] = "Enable Map Props Physgrab";
lang["#EntityUseCooldown"] = "Entity Use Cooldown";
lang["#EnableSmoothSprint"] = "Enable Smooth Sprint";
lang["#EnableQuickRaise"] = "Enable Quick Raise";
lang["#PlayersChangeThemes"] = "Players Change Themes";
lang["#DefaultTheme"] = "Default Theme";
lang["#EnableIronsights"] = "Enable Ironsights";
lang["#IronsightsSpreadReduction"] = "Ironsights Spread Reduction";
lang["#IronsightsSlowAmount"] = "Ironsights Slow Amount"; // omg finally i can sleep now

-- Days
lang["#Monday"] = "Monday";
lang["#Tuesday"] = "Tuesday";
lang["#Wednesday"] = "Wednesday";
lang["#Thursday"] = "Thursday";
lang["#Friday"] = "Friday";
lang["#Saturday"] = "Saturday";

-- Tab Menu Descriptions
lang["#BusinessDesc"] = "Order items for your business.";
lang["#InventoryDesc"] = "Manage the items in your inventory.";
lang["#DirectoryDesc"] = "A directory of various topics and information.";
lang["#SystemDesc"] = "Access a variety of server-side options.";
lang["#ScoreboardDesc"] = "See which players are on the server.";
lang["#AttributesDesc"] = "Check the status of your attributes.";
lang["#SettingsDesc"] = "Configure the way Clockwork works for you.";
lang["#ClassesDesc"] = "Choose from a list of available classes.";
lang["#CharactersDesc"] = "Click here to view the character menu.";
lang["#CloseMenuDesc"] = "Click here to close the menu.";

-- Tab Menu Names
lang["#Attributes"] = "Attributes";
lang["#Attribute"] = "Attribute";
lang["#System"] = "System";
lang["#Settings"] = "Settings";
lang["#Classes"] = "Classes";
lang["#Scoreboard"] = "Scoreboard";
lang["#Directory"] = "Directory";
lang["#Inventory"] = "Inventory";
lang["#Business"] = "Business";
lang["#Characters"] = "CHARACTERS";
lang["#CloseMenu"] = "CLOSE MENU";

-- MainMenu
lang["#MainMenu_New"] = "NEW";
lang["#MainMenu_Load"] = "LOAD";
lang["#MainMenu_Leave"] = "LEAVE";
lang["#MainMenu_DevelopedBy"] = "DEVELOPED BY #1";

-- Quiz panel
lang["#QuizPanel_Continue"] = "CONTINUE";
lang["#QuizPanel_Disconnect"] = "DISCONNECT";
lang["#QuizPanel_Language"] = "Language";
lang["#QuizPanel_Questions"] = "Questions";
lang["#QuizPanel_KickReason"] = "You got too many questions wrong!";
lang["#QuizPanel_Warning"] = "If any answers are incorrect, you may be kicked from the server.";

-- Character Creation
lang["#CharCreation_Previous"] = "PREVIOUS";
lang["#CharCreation_Next"] = "NEXT";
lang["#CharCreation_Cancel"] = "CANCEL";
lang["#CharCreation_CannotCreateMoreChars"] = "You cannot create any more characters!";

-- Business Menu
lang["#BusinessMenu_NoAccess"] = "You do not have access to the #1 menu!";
lang["#BusinessMenu_Free"] = "Free";

-- Attributes Menu
lang["#AttributesMenu_NoAccess"] = "You do not have access to any #1!";

-- Classes Menu
lang["#ClassesMenu_NoStay"] = "Classes you choose do not stay with your character.";
lang["#ClassesMenu_NoAccess"] = "You do not have access to any classes!";
lang["#ClassesMenu_CurrentPlayers"] = "There are #1/#2 characters with this class.";

-- Donations Menu
lang["#DonationsMenu_Title"] = "Donations";
lang["#DonationsMenu_SomeSubsExpire"] = "Some subscriptions can expire and will have to be donated for again.";
lang["#DonationsMenu_NoActiveSubs"] = "You do not have any active donations!";
lang["#DonationsMenu_NoExpire"] = "This subscription will never expire.";
lang["#DonationsMenu_Expired"] = "This subscription has expired!";
lang["#DonationsMenu_ExpiresIn"] = "This donation will expire in #1 second(s).";

-- F1 Menu
lang["#InfoMenu_Title"] = "CHARACTER AND ROLEPLAY INFO";
lang["#InfoMenu_SelectOption"] = "SELECT A QUICK MENU OPTION";

-- Misc Terms
lang["#Destroy"] = "Destroy";
lang["#Cash"] = "Cash";
lang["#Drop"] = "Drop";
lang["#Use"] = "Use";

-- Command Descriptions,
lang["#Commands_RollDesc"] = "Roll a number between 0 and the specified number.";
lang["#Commands_MeDesc"] = "Speak in third person to others around you.";
lang["#Commands_YDesc"] = "Yell to characters near you.";
lang["#Commands_WDesc"] = "Whisper to characters near you.";
lang["#Commands_PMDesc"] = "Send a private message to a player.";
lang["#Commands_RDesc"] = "Send a radio message out to other characters.";
lang["#Commands_FDesc"] = "Make your character fall to the floor.";

-- Chat suffixes and prefixes.
lang["#Suffix_Whisper"] = "whispers:";
lang["#Suffix_Yell"] = "yells:";

-- Scoreboard
lang["#Scoreboard_Tip"] = "Click on a player's model icon to bring up available commands.";

lang["#CMDDesc_Aliases"] = "Aliases:";
lang["#CMDDesc_Usage"] = "Usage:";