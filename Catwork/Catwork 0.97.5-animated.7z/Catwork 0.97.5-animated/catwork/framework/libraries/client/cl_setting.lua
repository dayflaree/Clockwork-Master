--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.setting = CW.kernel:NewLibrary("Setting");
CW.setting.stored = CW.setting.stored or {};

-- A function to add a number slider setting.
function CW.setting:AddNumberSlider(category, text, conVar, minimum, maximum, decimals, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		decimals = decimals,
		toolTip = toolTip,
		maximum = maximum,
		minimum = minimum,
		conVar = conVar,
		class = "numberSlider",
		text = text
	};

	return index;
end;

-- A function to add a multi-choice setting.
function CW.setting:AddMultiChoice(category, text, conVar, options, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	if (options) then
		table.sort(options, function(a, b) return a < b; end);
	else
		options = {};
	end;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		toolTip = toolTip,
		options = options,
		conVar = conVar,
		class = "multiChoice",
		text = text
	};

	return index;
end;

-- A function to add a number wang setting.
function CW.setting:AddNumberWang(category, text, conVar, minimum, maximum, decimals, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		decimals = decimals,
		toolTip = toolTip,
		maximum = maximum,
		minimum = minimum,
		conVar = conVar,
		class = "numberWang",
		text = text
	};

	return index;
end;

-- A function to add a text entry setting.
function CW.setting:AddTextEntry(category, text, conVar, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		toolTip = toolTip,
		conVar = conVar,
		class = "textEntry",
		text = text
	};

	return index;
end;

-- A function to add a check box setting.
function CW.setting:AddCheckBox(category, text, conVar, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		toolTip = toolTip,
		conVar = conVar,
		class = "checkBox",
		text = text
	};

	return index;
end;

-- A function to add a color mixer setting.
function CW.setting:AddColorMixer(category, text, conVar, toolTip, Condition)
//	local index = string.lower(string.gsub(category.."|"..text, " ", "_"));
	local index = conVar;

	self.stored[index] = {
		Condition = Condition,
		category = category,
		toolTip = toolTip,
		conVar = conVar,
		class = "colorMixer",
		text = text
	};

	return index;
end;

-- A function to remove a setting by its index.
function CW.setting:RemoveByIndex(index)
	self.stored[index] = nil;
end;

-- A function to remove a setting by its convar.
function CW.setting:RemoveByConVar(conVar)
	for k, v in pairs(self.stored) do
		if (v.conVar == conVar) then
			self.stored[k] = nil;
		end;
	end;
end;

-- A function to remove a setting.
function CW.setting:Remove(category, text, class, conVar)
	for k, v in pairs(self.stored) do
		if ((!category or v.category == category)
		and (!conVar or v.conVar == conVar)
		and (!class or v.class == class)
		and (!text or v.text == text)) then
			self.stored[k] = nil;
		end;
	end;
end;

function CW.setting:AddSettings()
	local langTable = {};

	for k, v in pairs(CW.lang:GetAll()) do
		langTable[v.name] = k;
	end;

	local themeTable = {};

	for k, v in pairs(CW.theme:GetAll()) do
		themeTable[k] = k;
	end;

	local frameworkStr = "#Framework";
	local chatBoxStr = "#ChatBox";
	local themeStr = "#Theme";
	local adminESP = "#AdminESP";

	CW.setting:AddNumberSlider(frameworkStr, "#HeadbobAmount", "cwHeadbobScale", 0, 1, 1, "#HeadbobAmountDesc");
	CW.setting:AddNumberSlider(chatBoxStr, "#ChatLines", "cwMaxChatLines", 1, 10, 0, "#ChatLinesDesc");

	CW.setting:AddCheckBox(frameworkStr, "#EnableConsoleLog", "cwShowLog", "#EnableConsoleLogDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);

	CW.setting:AddCheckBox(frameworkStr, "#TwelveHourClock", "cwTwelveHourClock", "#TwelveHourClockDesc");
	CW.setting:AddCheckBox(frameworkStr, "#ShowBars", "cwTopBars", "#ShowBarsDesc");
	CW.setting:AddCheckBox(frameworkStr, "#EnableHints", "cwShowHints", "#EnableHintsDesc");
	CW.setting:AddMultiChoice(frameworkStr, "#Language", "gmod_language", langTable, "#LangDesc");
	CW.setting:AddCheckBox(frameworkStr, "#EnableVignette", "cwShowVignette", "#EnableVignetteDesc");

	CW.setting:AddCheckBox(chatBoxStr, "#ShowTimestamps", "cwShowTimeStamps", "#ShowTimestampsDesc");
	CW.setting:AddCheckBox(chatBoxStr, "#ShowCWMessages", "cwShowCW", "#ShowCWMessagesDesc");
	CW.setting:AddCheckBox(chatBoxStr, "#ShowServerMessages", "cwShowServer", "#ShowServerMessagesDesc");
	CW.setting:AddCheckBox(chatBoxStr, "#ShowOOCMessages", "cwShowOOC", "#ShowOOCMessagesDesc");
	CW.setting:AddCheckBox(chatBoxStr, "#ShowICMessages", "cwShowIC", "#ShowICMessagesDesc");

	CW.setting:AddMultiChoice(themeStr, themeStr, "cwActiveTheme", themeTable, "#ThemeDesc", function ()
		return (CW.config:Get("modify_themes"):GetBoolean());
	end);
	CW.setting:AddColorMixer(themeStr, "#TextColor", "cwTextColor", "#TextColorDesc", function()
		return (!CW.theme:IsFixed());
	end);
	CW.setting:AddColorMixer(themeStr, "#BGColor", "cwBackColor", "#BGColorDesc");
	CW.setting:AddNumberSlider(themeStr, "#TabMenuX", "cwTabPosX", 0, ScrW(), 0, "#TabMenuXDesc");
	CW.setting:AddNumberSlider(themeStr, "#TabMenuY", "cwTabPosY", 0, ScrH(), 0, "#TabMenuYDesc");
	CW.setting:AddNumberSlider(themeStr, "#BackMenuX", "cwBackX", 0, ScrW(), 0, "#BackMenuXDesc");
	CW.setting:AddNumberSlider(themeStr, "#BackMenuY", "cwBackY", 0, ScrH(), 0, "#BackMenuYDesc");
	CW.setting:AddNumberSlider(themeStr, "#BackMenuW", "cwBackW", 0, ScrW(), 0, "#BackMenuWDesc");
	CW.setting:AddNumberSlider(themeStr, "#BackMenuH", "cwBackH", 0, ScrH(), 0, "#BackMenuHDesc");
	CW.setting:AddCheckBox(themeStr, "#FadePanels", "cwFadePanels", "#FadePanelsDesc");
	CW.setting:AddCheckBox(themeStr, "#ShowMaterial", "cwShowMaterial", "#ShowMaterialDesc");
	CW.setting:AddCheckBox(themeStr, "#ShowGradient", "cwShowGradient", "#ShowGradientDesc");
//	CW.setting:AddTextEntry(themeStr, "#CharacterText", "cwCharString", "#CharacterTextDesc");
//	CW.setting:AddTextEntry(themeStr, "#CloseMenuText", "cwCloseString", "#CloseMenuTextDesc");
	CW.setting:AddTextEntry(themeStr, "#MenuMaterial", "cwMaterial", "#MenuMaterialDesc");

	CW.setting:AddCheckBox(adminESP, "#EnableAdminESP", "cwAdminESP", "#EnableAdminESPDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);

	CW.setting:AddCheckBox(adminESP, "#DrawESPBars", "cwESPBars", "#DrawESPBarsDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);

	CW.setting:AddCheckBox(adminESP, "#ShowItemEntities", "cwItemESP", "#ShowItemEntitiesDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);

	CW.setting:AddCheckBox(adminESP, "#ShowSalesmenEntities", "cwSaleESP", "#ShowSalesmenEntitiesDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);

	CW.setting:AddNumberSlider(adminESP, "#ESPInterval", "cwESPTime", 0, 2, 0, "#ESPIntervalDesc", function()
		return CW.player:IsAdmin(CW.Client);
	end);
end;
