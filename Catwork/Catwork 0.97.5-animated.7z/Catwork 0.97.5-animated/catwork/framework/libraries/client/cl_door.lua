--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.door = CW.kernel:NewLibrary("Door");

-- A function to get whether the door panel is open.
function CW.door:IsDoorPanelOpen()
	local panel = self:GetPanel();
	
	if (IsValid(panel)) then
		return true;
	end;
end;

-- A function to get whether the door has shared text.
function CW.door:HasSharedText()
	return self.cwDoorSharedTxt;
end;

-- A function to get whether the door has shared access.
function CW.door:HasSharedAccess()
	return self.cwDoorSharedAxs;
end;

-- A function to get whether the door is a parent.
function CW.door:IsParent()
	return self.isParent;
end;

-- A function to get whether the door is unsellable.
function CW.door:IsUnsellable()
	return self.unsellable;
end;

-- A function to get the door's access list.
function CW.door:GetAccessList()
	return self.accessList;
end;

-- A function to get the door's name.
function CW.door:GetName()
	return self.name;
end;

-- A function to get the door panel.
function CW.door:GetPanel()
	if (IsValid(self.panel)) then
		return self.panel;
	end;
end;

-- A function to get the door owner.
function CW.door:GetOwner()
	if (IsValid(self.owner)) then
		return self.owner;
	end;
end;

-- A function to get the door entity.
function CW.door:GetEntity()
	return self.entity;
end;