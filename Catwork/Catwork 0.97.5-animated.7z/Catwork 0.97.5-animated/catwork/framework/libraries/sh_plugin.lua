--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[ The plugin library is already defined! --]]
if (plugin) then return; end;

library.New("plugin", _G);

--[[
	We do local variables instead of global ones for performance increase.
	Most CW libraries use functions to return their tables anyways.
--]]
local stored = {};
local modules = {};
local unloaded = {};
local extras = {};
local hookCache = {};

--[[
	@codebase Shared
	@details A function to get the local stored table that contains all registered plugins.
	@returns Table The local stored plugin table.
--]]
function plugin.GetStored()
	return stored;
end;

--[[
	@codebase Shared
	@details A function to get the local plugin module table that contains all registered plugin modules.
	@returns Table The local plugin module table.
--]]
function plugin.GetModules()
	return modules;
end;

--[[
	@codebase Shared
	@details A function to get the local unloaded table that contains all unloaded plugins.
	@returns Table The local stored unloaded plugin table.
--]]
function plugin.GetUnloaded()
	return unloaded;
end;

--[[
	@codebase Shared
	@details A function to get the extras that will be included in each plugin.
	@returns Table The local table of extras to be searched for in plugins.
--]]
function plugin.GetExtras()
	return extras;
end;

--[[
	@codebase Shared
	@details A function to get the local plugin hook cache.
	@returns Table The local plugin hook cache table.
--]]
function plugin.GetCache()
	return hookCache;
end;

function plugin.DebugPrintCache()
	PrintTable(hookCache);
end;

PLUGIN_META = {__index = PLUGIN_META};
PLUGIN_META.description = "An undescribed plugin or schema.";
PLUGIN_META.hookOrder = 0;
PLUGIN_META.version = 1.0;
PLUGIN_META.author = "Unknown";
PLUGIN_META.name = "Unknown";

PLUGIN_META.SetGlobalAlias = function(PLUGIN_META, aliasName)
	_G[aliasName] = PLUGIN_META;
	PLUGIN_META.alias = aliasName;
end;	
	
PLUGIN_META.GetDescription = function(PLUGIN_META)
	return PLUGIN_META.description;
end;
	
PLUGIN_META.GetBaseDir = function(PLUGIN_META)
	return PLUGIN_META.baseDir;
end;

PLUGIN_META.GetHookOrder = function(PLUGIN_META)
	return PLUGIN_META.hookOrder;
end;
	
PLUGIN_META.GetVersion = function(PLUGIN_META)
	return PLUGIN_META.version;
end;
	
PLUGIN_META.GetAuthor = function(PLUGIN_META)
	return PLUGIN_META.author;
end;
	
PLUGIN_META.GetName = function(PLUGIN_META)
	return PLUGIN_META.name;
end;
	
PLUGIN_META.Register = function(PLUGIN_META)
	plugin.Register(PLUGIN_META);
end;

if (SERVER) then
	function plugin.SetUnloaded(name, isUnloaded)
		local pluginTable = plugin.FindByID(name);
		
		if (pluginTable and pluginTable != Schema) then
			if (isUnloaded) then
				unloaded[pluginTable.folderName] = true;
			else
				unloaded[pluginTable.folderName] = nil;
			end;
			
			CW.kernel:SaveSchemaData("plugins", unloaded);
			return true;
		end;
		
		return false;
	end;
	
	-- A function to get whether a plugin is disabled.
	function plugin.IsDisabled(name, bFolder)
		if (!bFolder) then
			local pluginTable = plugin.FindByID(name);
			
			if (pluginTable and pluginTable != Schema) then
				for k, v in pairs(unloaded) do
					local unloaded = plugin.FindByID(k);
					
					if (unloaded and unloaded != Schema
					and pluginTable.folderName != unloaded.folderName) then
						if (table.HasValue(unloaded.plugins, pluginTable.folderName)) then
							return true;
						end;
					end;
				end;
			end;
		else
			for k, v in pairs(unloaded) do
				local unloaded = plugin.FindByID(k);
				
				if (unloaded and unloaded != Schema and name != unloaded.folderName) then
					if (table.HasValue(unloaded.plugins, name)) then
						return true;
					end;
				end;
			end;
		end;
		
		return false;
	end;
	
	-- A function to get whether a plugin is unloaded.
	function plugin.IsUnloaded(name, bFolder)
		if (!bFolder) then
			local pluginTable = plugin.FindByID(name);
			
			if (pluginTable and pluginTable != Schema) then
				return (unloaded[pluginTable.folderName] == true);
			end;
		else
			return (unloaded[name] == true);
		end;
		
		return false;
	end;
else
	plugin.override = plugin.override or {};
	
	-- A function to set whether a plugin is unloaded.
	function plugin.SetUnloaded(name, isUnloaded)
		local pluginTable = plugin.FindByID(name);
		
		if (pluginTable) then
			plugin.override[pluginTable.folderName] = isUnloaded;
		end;
	end;
	
	-- A function to get whether a plugin is disabled.
	function plugin.IsDisabled(name, bFolder)
		if (!bFolder) then
			local pluginTable = plugin.FindByID(name);
			
			if (pluginTable and pluginTable != Schema) then
				for k, v in pairs(unloaded) do
					local unloaded = plugin.FindByID(k);
					
					if (unloaded and unloaded != Schema
					and pluginTable.folderName != unloaded.folderName) then
						if (table.HasValue(unloaded.plugins, pluginTable.folderName)) then
							return true;
						end;
					end;
				end;
			end;
		else
			for k, v in pairs(unloaded) do
				local unloaded = plugin.FindByID(k);
				
				if (unloaded and unloaded != Schema
				and name != unloaded.folderName) then
					if (table.HasValue(unloaded.plugins, name)) then
						return true;
					end;
				end;
			end;
		end;
		
		return false;
	end;
	
	-- A function to get whether a plugin is unloaded.
	function plugin.IsUnloaded(name, bFolder)
		if (!bFolder) then
			local pluginTable = plugin.FindByID(name);
			
			if (pluginTable and pluginTable != Schema) then
				if (plugin.override[pluginTable.folderName] != nil) then
					return plugin.override[pluginTable.folderName];
				end;
				
				return (unloaded[pluginTable.folderName] == true);
			end;
		else
			if (plugin.override[name] != nil) then
				return plugin.override[name];
			end;
			
			return (unloaded[name] == true);
		end;
		
		return false;
	end;
end;

-- A function to set if the plugin system is initialized.
function plugin.SetInitialized(bInitialized)
	plugin.cwInitialized = bInitialized;
end;

-- A function to get whether the config has initialized.
function plugin.HasInitialized()
	return plugin.cwInitialized;
end;

-- A function to initialize the plugin system.
function plugin.Initialize()
	if (plugin.HasInitialized()) then
		return;
	end;

	if (SERVER) then
		unloaded = CW.kernel:RestoreSchemaData("plugins");
	end;
	
	plugin.SetInitialized(true);
end;

-- A function to register a new plugin.
function plugin.Register(pluginTable)
	local newBaseDir = CW.kernel:RemoveTextFromEnd(pluginTable.baseDir, "/schema");
	local files, pluginFolders = _file.Find(newBaseDir.."/plugins/*", "LUA", "namedesc");

	stored[pluginTable.name] = pluginTable;
	stored[pluginTable.name].plugins = {};
	
	for k, v in pairs(pluginFolders) do
		if (v != ".." and v != ".") then
			table.insert(stored[pluginTable.name].plugins, v);
		end;
	end;
	
	if (!plugin.IsUnloaded(pluginTable.folderName)) then
		plugin.IncludeExtras(pluginTable:GetBaseDir());
	
		if (CLIENT and Schema != pluginTable) then
			pluginTable.helpID = CW.directory:AddCode("Plugins", [[
				<div class="cwTitleSeperator">
					]]..string.upper(pluginTable:GetName())..[[
				</div>
				<div class="cwContentText">
					<div class="cwCodeText">
						developed by ]]..pluginTable:GetAuthor()..[[
					</div>
					]]..pluginTable:GetDescription()..[[
				</div>
			]], true, pluginTable:GetAuthor());
		end;
	end;
	
	--[[
		Schema functions shouldn't be overriden. There's always a way to do it
		with plugins, so this will be warned against!
	--]]
	--[[if (Schema == pluginTable) then
		Schema.__funcIdx = {};
		
		for k, v in pairs(Schema) do
			if (type(v) == "function") then
				Schema.__funcIdx[k] = tostring(v);
			end;
		end;
	end;--]]

	plugin.IncludePlugins(newBaseDir);
end;

-- A function to find a plugin by an ID.
function plugin.FindByID(identifier)
	return stored[identifier];
end;

-- A function to determine whether a plugin's version is higher than the framework's.
function plugin.CompareVersion(version, name, cwVersion, cwBuild)
	if (tostring(version) == CW.kernel:GetVersionBuild()) then return false; end;

	local pluginVersion = string.Explode("-", version)[1] or {version};
	local pluginBuild = string.Explode("-", version)[2];

	if (pluginVersion > cwVersion) then
		return true;
	elseif (pluginVersion == cwVersion) then
		if (pluginBuild and cwBuild) then
			if (pluginBuild > cwBuild) then
				return true;
			end;
		elseif (!pluginBuild) then
			return true;
		end;
	end;

	return false;
end;

-- A function to include a plugin.
function plugin.Include(directory)
	local schemaFolder = CW.kernel:GetSchemaFolder();
	local explodeDir = string.Explode("/", directory);
	local folderName = explodeDir[#explodeDir - 1];
	local pathCRC = util.CRC(directory);
	
	PLUGIN_BASE_DIR = directory;
	PLUGIN_FOLDERNAME = folderName;

	PLUGIN = plugin.New();

	if (SERVER) then
		local iniDir = "gamemodes/"..CW.kernel:RemoveTextFromEnd(directory, "/plugin"); 
		local iniTable = CW.config:LoadINI(iniDir.."/plugin.ini", true, true);
		
		if (iniTable) then
			if (iniTable["Plugin"]) then
				iniTable = iniTable["Plugin"];
				iniTable.isUnloaded = plugin.IsUnloaded(PLUGIN_FOLDERNAME, true);
					table.Merge(PLUGIN, iniTable);
				CW_SCRIPT_SHARED.plugins[pathCRC] = iniTable;
			else
				MsgC(Color(255, 100, 0, 255), "\n[CW:Plugin] The "..PLUGIN_FOLDERNAME.." plugin has no plugin.ini!\n");
			end;
		end;
	else
		local iniTable = CW_SCRIPT_SHARED.plugins[pathCRC];

		if (iniTable) then
			table.Merge(PLUGIN, iniTable);

			if (iniTable.isUnloaded) then
				unloaded[PLUGIN_FOLDERNAME] = true;
			end;
		else
			MsgC(Color(255, 100, 0, 255), "\n[CW:Plugin] The "..PLUGIN_FOLDERNAME.." plugin has no plugin.ini!\n");
		end;
	end;

	if (stored[PLUGIN.name]) then
		PLUGIN = stored[PLUGIN.name]; -- Restore plugin's data on refresh.
	end;

	local isUnloaded = plugin.IsUnloaded(PLUGIN_FOLDERNAME, true);
	local isDisabled = plugin.IsDisabled(PLUGIN_FOLDERNAME, true);
	local shPluginDir = directory.."/sh_plugin.lua";
	local addCSLua = true;
		
	if (!isUnloaded and !isDisabled) then
		if (_file.Exists(shPluginDir, "LUA")) then
			CW.kernel:IncludePrefixed(shPluginDir);
		end;

		addCSLua = false;
	end;

	if (SERVER and addCSLua) then
		AddCSLuaFile(shPluginDir);
	end;

	PLUGIN:Register();

	for k, v in pairs(PLUGIN) do
		if (isfunction(v)) then
			hookCache[k] = hookCache[k] or {};
			hookCache[k][PLUGIN.name] = {v, PLUGIN};
		end;
	end;
	
	PLUGIN = nil;
end;

function plugin.CacheSchemaHooks()
	for k, v in pairs(Schema) do
		if (isfunction(v)) then
			hookCache[k] = hookCache[k] or {};
			hookCache[k][Schema:GetName()] = {v, Schema};
		end;
	end;
end;

-- A function to create a new plugin.
function plugin.New()
	local pluginTable = CW.kernel:NewMetaTable(PLUGIN_META);
	pluginTable.baseDir = PLUGIN_BASE_DIR;
	pluginTable.folderName = PLUGIN_FOLDERNAME;
	
	return pluginTable;
end;

-- A function to sort a list of plugins storted by k, v.
function plugin.SortList(pluginList)
	local sortedTable = {};
	
	for k, v in pairs(pluginList) do
		sortedTable[#sortedTable + 1] = v;
	end;
	
	--[[table.sort(sortedTable, function(a, b)
		return a:GetHookOrder() > b:GetHookOrder();
	end);]]
	
	return sortedTable;
end;

local function ArgsToError(...)
	local args = {...};
	
	for k, v in pairs(args) do
		if (v != nil) then
			MsgC(Color(255, 100, 0), v);
		end;
	end;
	
	MsgC(Color(255, 255, 255), "\n");
end;

-- A function to run the plugin hooks.
function plugin.RunHooks(name, bGamemode, ...)
	if (name != "HookCall") then
		local succ, val, a, b, c = pcall(plugin.Call, "HookCall", name, ...);
		
		if (!succ) then
			MsgC(Color(255, 100, 0, 255), "\n[CW]\nThe '"..name.."' expansion hook has failed to run.\n");
			ArgsToError(val, a, b, c)
		elseif (val != nil) then
			return val, a, b, c;
		end;
	end;

	if (hookCache[name]) then
		for k, v in pairs(hookCache[name]) do
			if (v != nil) then
				local bSuccess, value, a, b, c = pcall(v[1], v[2], ...);
					
				if (!bSuccess) then
					MsgC(Color(255, 100, 0, 255), "\n[CW:"..k.."]\nThe '"..name.."' hook has failed to run.\n");
					ArgsToError(value, a, b, c)
				elseif (value != nil) then
					return value, a, b, c;
				end;
			end;
		end;
	end;

	if (bGamemode and CW[name]) then
		local bSuccess, value, a, b, c = pcall(CW[name], CW, ...);
		
		if (!bSuccess) then
			MsgC(Color(255, 100, 0, 255), "\n[CW:Kernel]\nThe '"..name.."' clockwork hook has failed to run.\n");
			ArgsToError(value, a, b, c);
		elseif (value != nil) then
			return value, a, b, c;
		end;
	end;
end;

-- A function to call a function for all plugins.
function plugin.Call(name, ...)
	return plugin.RunHooks(name, true, ...);
end;

-- A function to remove a module by name.
function plugin.Remove(name)
	for k, v in pairs(modules[name]) do
		if (isfunction(v)) then
			hookCache[k] = hookCache[k] or {};
			hookCache[k][name] = nil;
		end;
	end;
	
	modules[name] = nil;
end;

-- A function to add a table as a module.
function plugin.Add(name, moduleTable, hookOrder)
	if (!moduleTable.name) then
		moduleTable.name = name;
	end;
	
	moduleTable.hookOrder = hookOrder or 0;
	
	modules[name] = moduleTable;
	
	for k, v in pairs(moduleTable) do
		if (isfunction(v)) then
			hookCache[k] = hookCache[k] or {};
			hookCache[k][name] = {v, moduleTable};
		end;
	end;
end;

-- A function to include a plugin's entities.
function plugin.IncludeEntities(directory)
	local files, entityFolders = _file.Find(directory.."/entities/entities/*", "LUA", "namedesc");

	for k, v in pairs(entityFolders) do
		if (v != ".." and v != ".") then
			ENT = {Type = "anim", Folder = directory.."/entities/entities/"..v};
			
			if (SERVER) then
				if (file.Exists("gamemodes/"..directory.."/entities/entities/"..v.."/init.lua", "GAME")) then
					include(directory.."/entities/entities/"..v.."/init.lua");
				elseif (file.Exists("gamemodes/"..directory.."/entities/entities/"..v.."/shared.lua", "GAME")) then
					include(directory.."/entities/entities/"..v.."/shared.lua");
				end;
				
				if (file.Exists("gamemodes/"..directory.."/entities/entities/"..v.."/cl_init.lua", "GAME")) then
					AddCSLuaFile(directory.."/entities/entities/"..v.."/cl_init.lua");
				end;
			elseif (_file.Exists(directory.."/entities/entities/"..v.."/cl_init.lua", "LUA")) then
				include(directory.."/entities/entities/"..v.."/cl_init.lua");
			elseif (_file.Exists(directory.."/entities/entities/"..v.."/shared.lua", "LUA")) then
				include(directory.."/entities/entities/"..v.."/shared.lua");
			end;
			
			scripted_ents.Register(ENT, v); ENT = nil;
		end;
	end;
end;

-- A function to include a plugin's effects.
function plugin.IncludeEffects(directory)
	local files, effectFolders = _file.Find(directory.."/entities/effects/*", "LUA", "namedesc");
	
	for k, v in pairs(effectFolders) do
		if (v != ".." and v != ".") then
			if (SERVER) then
				if (_file.Exists("gamemodes/"..directory.."/entities/effects/"..v.."/cl_init.lua", "GAME")) then
					AddCSLuaFile(directory.."/entities/effects/"..v.."/cl_init.lua");
				elseif (_file.Exists("gamemodes/"..directory.."/entities/effects/"..v.."/init.lua", "GAME")) then
					AddCSLuaFile(directory.."/entities/effects/"..v.."/init.lua");
				end;
			elseif (_file.Exists(directory.."/entities/effects/"..v.."/cl_init.lua", "LUA")) then
				EFFECT = {Folder = directory.."/entities/effects/"..v};
					include(directory.."/entities/effects/"..v.."/cl_init.lua");
				effects.Register(EFFECT, v); EFFECT = nil;
			elseif (_file.Exists(directory.."/entities/effects/"..v.."/init.lua", "LUA")) then
				EFFECT = {Folder = directory.."/entities/effects/"..v};
					include(directory.."/entities/effects/"..v.."/init.lua");
				effects.Register(EFFECT, v); EFFECT = nil;
			end;
		end;
	end;
end;

-- A function to include a plugin's weapons.
function plugin.IncludeWeapons(directory)
	local files, weaponFolders = _file.Find(directory.."/entities/weapons/*", "LUA");

	for k, v in pairs(weaponFolders) do
		if (v != ".." and v != ".") then
			SWEP = { Folder = directory.."/entities/weapons/"..v, Base = "weapon_base", Primary = {}, Secondary = {} };
			
			if (SERVER) then
				if (_file.Exists("gamemodes/"..directory.."/entities/weapons/"..v.."/init.lua", "GAME")) then
					include(directory.."/entities/weapons/"..v.."/init.lua");
				elseif (_file.Exists("gamemodes/"..directory.."/entities/weapons/"..v.."/shared.lua", "GAME")) then
					include(directory.."/entities/weapons/"..v.."/shared.lua");
				end;
				
				if (_file.Exists("gamemodes/"..directory.."/entities/weapons/"..v.."/cl_init.lua", "GAME")) then
					AddCSLuaFile(directory.."/entities/weapons/"..v.."/cl_init.lua");
				end;
			elseif (_file.Exists(directory.."/entities/weapons/"..v.."/cl_init.lua", "LUA")) then
				include(directory.."/entities/weapons/"..v.."/cl_init.lua");
			elseif (_file.Exists(directory.."/entities/weapons/"..v.."/shared.lua", "LUA")) then
				include(directory.."/entities/weapons/"..v.."/shared.lua");
			end;
			
			weapons.Register(SWEP, v); SWEP = nil;
		end;
	end;
end;

-- A function to include a plugin's plugins.
function plugin.IncludePlugins(directory)
	local files, pluginFolders = _file.Find(directory.."/plugins/*", "LUA", "namedesc");
	
	if (!plugin.HasInitialized()) then
		plugin.Initialize();
	end;
	
	for k, v in pairs(pluginFolders) do
		plugin.Include(directory.."/plugins/"..v.."/plugin");
	end;
end;

-- A function to add an extra folder to include for plugins.
function plugin.AddExtra(folderName)
	if (!table.HasValue(extras, folderName)) then
		extras[#extras + 1] = folderName;
	end;
end;

-- A function to include a plugin's extras.
function plugin.IncludeExtras(directory)
	local files, folders = _file.Find(directory.."/*", "LUA", "namedesc");
	
	if (table.HasValue(folders, "entities")) then
		plugin.IncludeEffects(directory);
		plugin.IncludeWeapons(directory);
		plugin.IncludeEntities(directory);
	end;

	for k, v in ipairs(extras) do
		if (table.HasValue(folders, v:gsub("/", ""))) then
			CW.kernel:IncludeDirectory(directory..v);
		end;
	end;
end;

plugin.AddExtra("/libraries/");
plugin.AddExtra("/directory/");
plugin.AddExtra("/system/");
plugin.AddExtra("/factions/");
plugin.AddExtra("/classes/");
plugin.AddExtra("/attributes/");
plugin.AddExtra("/items/");
plugin.AddExtra("/derma/");
plugin.AddExtra("/commands/");
plugin.AddExtra("/language/");
plugin.AddExtra("/config/");
plugin.AddExtra("/tools/");
plugin.AddExtra("/themes/");

--[[ This table will hold the plugin info, if it doesn't already exist. --]]
CW_SCRIPT_SHARED.plugins = CW_SCRIPT_SHARED.plugins or {};

--[[
	This is a hack to allow us to call plugin hooks based
	on default GMod hooks that are called.

	It modifies the hook.Call funtion to call hooks inside Clockwork plugins
	as well as hooks that are added normally with hook.Add.
--]]
hook.ClockworkCall = hook.ClockworkCall or hook.Call;

local function ArgsToError(...)
	local args = {...};
	
	for k, v in pairs(args) do
		if (v != nil) then
			MsgC(Color(255, 100, 0), v);
		end;
	end;
	
	MsgC(Color(255, 255, 255), "\n");
end;

function hook.Call(name, gamemode, ...)
	local arguments = {...};
	
	if (CLIENT) then
		if (!IsValid(CW.Client)) then
			CW.Client = LocalPlayer();
			cwClient = CW.Client;
		end;
	else
		if (name == "EntityTakeDamage") then
			if (CW.kernel:DoEntityTakeDamageHook(arguments)) then
				return;
			end;
		elseif (name == "PlayerDisconnected") then
			if (!IsValid(arguments[1])) then
				return;
			end;
		end;
	end;
	
	local result = {pcall(plugin.RunHooks, name, nil, unpack(arguments))};
	local status = result[1];
	table.remove(result, 1);

	if (!status) then
		MsgC(Color(255, 100, 0, 255), "\n[CW:Kernel]\nThe '"..name.."' hook has failed to run.\n");
		ArgsToError(unpack(result));
	end;
	
	if (#result == 0 or name == THINK_NAME) then
		local result = {pcall(hook.ClockworkCall, name, gamemode or Clockwork, unpack(arguments))};
		local status = result[1];
		table.remove(result, 1);
		
		if (!status) then
			MsgC(Color(255, 100, 0, 255), "\n[CW:Kernel]\nThe '"..name.."' gamemode hook failed to run.\n");
			ArgsToError(unpack(result));
		else
			return unpack(result);
		end;
	else
		return unpack(result);
	end;
end;