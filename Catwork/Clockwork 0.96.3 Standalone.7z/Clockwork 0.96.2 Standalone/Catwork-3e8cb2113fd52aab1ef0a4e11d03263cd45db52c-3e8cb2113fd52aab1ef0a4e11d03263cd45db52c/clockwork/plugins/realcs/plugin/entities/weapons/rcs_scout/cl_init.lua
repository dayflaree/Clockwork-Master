include('shared.lua')

-- I put this in here because of the fact that there is a whole cl_init in the old rcs_Scout, so this would overwrite it, you can delete it if you want