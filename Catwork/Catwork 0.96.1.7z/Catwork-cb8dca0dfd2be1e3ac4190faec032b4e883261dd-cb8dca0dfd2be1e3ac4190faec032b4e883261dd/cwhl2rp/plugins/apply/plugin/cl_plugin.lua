--[[
	© 2014 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

PLUGIN = PLUGIN;

Clockwork.config:AddToSystem("Enable Apply Recognise", "apply_recognise_enable", "Whether or not should players recognise other characters if they use /Apply?");