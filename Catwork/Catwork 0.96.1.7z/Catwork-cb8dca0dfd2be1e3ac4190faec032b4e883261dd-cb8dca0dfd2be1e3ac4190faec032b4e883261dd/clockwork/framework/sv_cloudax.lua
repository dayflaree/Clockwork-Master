--[[ 
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local phrases = {
	"Sending your private info to kurozael",
	"Hacking your bank accounts",
	"Stealing your cat",
	"Installing Windows 10 spyware",
	"Sending your private info to Microsoft",
	"Do not wait",
	"Using your server to DDoS LemonPunch",
	"Using your server to mine bitcoins",
	"Crashing your server",
	"Adding extra 7 seconds to boot times",
	"Sending a DMCA notice to Alex Grist",
	"Starting a lawsuit against you for using Standalone",
	"Installing backdoors",
	"Giving kurozael owner",
	"Banning your whole playerbase",
	"You are not authorized by CloudAuthX to use Standalone",
	"Making kittens cry",
	"Installing an update that breaks everything",
	"Loading your CPU core to 100%",
	"Crying about that extra space in the serial file",
	"Attempting to explode your server for using Standalone",
	"CloudAuthX is not installed",
	"Downloading porn",
	"Opening kuro's favorite PH category (gay porn)",
	"Reporting you to NSA",
	"Banning random people",
	"Attempting to install legit Clockwork... ERROR",
	"Transferring all your money to kurozael",
	"Transferring $30 to kurozael",
	"#kurobucks, #kurobank",
	"Throwing all the errors at you",
	"Downloading internet",
	"Sending your server IP to Anonymous",
	"Taking over your community",
	"Turning your cat into a dog",
	"Turning your dog into a cat",
	"Suing you for using Standalone",
	"Generating shit ton of Alex Grist drama",
	"Burning your CPU",
	"Stealing your CS:GO items",
	"Stealing your TF2 hats",
	"Downloading ponies",
	"Generating Lua Errors",
	"Something is creating script errors",
	"Banning people for thinking about NutScript",
	"Installing NutScript",
	"Ripping off NutScript",
	"Stealing TARDIS",
	"Installing winlocker",
	"Hacking your Apple ID"
}

MsgC(Color(0, 255, 255, 255), "[CloudAuthX] "..table.Random(phrases)..", please wait...\n");