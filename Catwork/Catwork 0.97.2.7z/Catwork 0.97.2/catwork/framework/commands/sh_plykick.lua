--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyKick");
COMMAND.tip = "Kick a player from the server.";
COMMAND.text = "<string Name> <string Reason>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.alias = {"Kick"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local reason = table.concat(arguments, " ", 2);
	
	if (!reason or reason == "") then
		reason = "N/A";
	end;
	
	if (target) then
		if (!CW.player:IsProtected(arguments[1])) then
			CW.player:NotifyAll(player:Name().." has kicked '"..target:Name().."' ("..reason..").");
				target:Kick(reason);
			target.kicked = true;
		else
			CW.player:Notify(player, target:Name().." is protected!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();