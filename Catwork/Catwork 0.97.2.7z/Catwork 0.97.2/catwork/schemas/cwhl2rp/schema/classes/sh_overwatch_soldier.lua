--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local CLASS = CW.class:New("Overwatch Soldier");
	CLASS.color = Color(150, 50, 50, 255);
	CLASS.wages = 40;
	CLASS.factions = {FACTION_OTA};
	CLASS.wagesName = "Supplies";
	CLASS.description = "A transhuman Overwatch soldier produced by the Combine.";
	CLASS.defaultPhysDesc = "Wearing dirty Overwatch gear";
CLASS_OWS = CLASS:Register();