--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local PLUGIN = PLUGIN;

Schema:AddCustomPermit("Literature", "3", "models/props_lab/bindergreenlabel.mdl");

CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");
CW.kernel:IncludePrefixed("sv_hooks.lua");