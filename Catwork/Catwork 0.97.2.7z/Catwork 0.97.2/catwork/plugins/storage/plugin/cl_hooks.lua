--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when an entity's target ID HUD should be painted.
function cwStorage:HUDPaintEntityTargetID(entity, info)
	local colorTargetID = CW.option:GetColor("target_id");
	local colorWhite = CW.option:GetColor("white");
	
	if (CW.entity:IsPhysicsEntity(entity)) then
		local model = string.lower(entity:GetModel());
		
		if (self.containerList[model]) then
			if (entity:GetNetworkedString("Name") != "") then
				info.y = CW.kernel:DrawInfo(entity:GetNetworkedString("Name"), info.x, info.y, colorTargetID, info.alpha);
			else
				info.y = CW.kernel:DrawInfo(self.containerList[model][2], info.x, info.y, colorTargetID, info.alpha);
			end;
			
			info.y = CW.kernel:DrawInfo("You can put stuff inside it.", info.x, info.y, colorWhite, info.alpha);
		end;
	end;
end;

-- Called when an entity's menu options are needed.
function cwStorage:GetEntityMenuOptions(entity, options)
	if (CW.entity:IsPhysicsEntity(entity)) then
		local model = string.lower(entity:GetModel());
		
		if (self.containerList[model]) then
			options["Open"] = "cwContainerOpen";
		end;
	end;
end;

-- Called when the local player's storage is rebuilt.
function cwStorage:PlayerStorageRebuilt(panel, categories)
	if (panel.storageType == "Container") then
		local entity = CW.storage:GetEntity();
		
		if (IsValid(entity) and entity.cwMessage) then
			local messageForm = vgui.Create("DForm", panel);
			local helpText = messageForm:Help(entity.cwMessage);
				messageForm:SetPadding(5);
				messageForm:SetName("Message");
				helpText:SetFont("Default");
			panel:AddItem(messageForm);
		end;
	end;
end;