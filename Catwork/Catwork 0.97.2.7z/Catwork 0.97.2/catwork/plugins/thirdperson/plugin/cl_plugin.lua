local cwThirdPerson = cwThirdPerson;

CW.config:AddToSystem("Enable Third Person", "enable_third_person", "Whether or not players will be able to toggle third person.");

//if (!cwThirdPerson.addedSettings) then
	CW.setting:AddCheckBox("Third Person", "Enable Third Person View.", "cwThirdPerson", "Whether or not to enable third person view.");
	CW.setting:AddNumberSlider("Third Person", "Back Position:", "cwChaseCamBack", -75, 75, 1, "How far back the third person camera is.");
	CW.setting:AddNumberSlider("Third Person", "Right Position:", "cwChaseCamRight", -55, 55, 1, "How far to the right (or left) the third person camera is.");
	CW.setting:AddNumberSlider("Third Person", "Up Position:", "cwChaseCamUp", -50, 50, 1, "How far up (or down) the third person camera is.");

//	cwThirdPerson.addedSettings = true;
//end;