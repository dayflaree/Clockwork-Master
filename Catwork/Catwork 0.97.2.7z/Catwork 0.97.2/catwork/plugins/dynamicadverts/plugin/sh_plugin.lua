--[[ 
	Catwork © 2016 Some good coders
	Do not share.
	
	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	You don't have to do this, but I think it's nicer.
	Alternatively, you can simply use the PLUGIN variable.
--]]
PLUGIN:SetGlobalAlias("cwDynamicAdverts");

--[[ You don't have to do this either, but I prefer to seperate the functions. --]]
CW.kernel:IncludePrefixed("cl_plugin.lua");
CW.kernel:IncludePrefixed("sv_plugin.lua");
CW.kernel:IncludePrefixed("sv_hooks.lua");
CW.kernel:IncludePrefixed("cl_hooks.lua");

cwDynamicAdverts.storedList = cwDynamicAdverts.storedList or {};