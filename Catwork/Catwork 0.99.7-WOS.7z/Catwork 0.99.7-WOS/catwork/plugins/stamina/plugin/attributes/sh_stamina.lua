--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "#Attribute_Stamina";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "stam";
	ATTRIBUTE.description = "#Attribute_Stamina_Desc";
	ATTRIBUTE.isOnCharScreen = true;
ATB_STAMINA = CW.attribute:Register(ATTRIBUTE);