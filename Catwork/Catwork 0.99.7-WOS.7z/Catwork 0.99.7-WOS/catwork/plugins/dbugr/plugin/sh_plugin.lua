--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

if (DBugR) then
	function PLUGIN:Initialize()
		timer.Simple(5, function()
			DBugR.Print("Catwork plugin hooks detoured! Detoured total of "..plugin.nDets.." hooks!");
		end);
	end;
end;