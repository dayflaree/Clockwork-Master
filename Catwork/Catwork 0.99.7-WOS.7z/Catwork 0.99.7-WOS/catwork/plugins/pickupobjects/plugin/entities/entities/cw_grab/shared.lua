--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

ENT.Type = "anim";
ENT.Base = "base_anim"
ENT.Author = "kurozael";
ENT.PrintName = "Grab";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;