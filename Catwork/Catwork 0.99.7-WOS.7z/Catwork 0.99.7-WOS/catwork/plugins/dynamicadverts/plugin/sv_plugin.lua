--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- A function to load the dynamic adverts.
function cwDynamicAdverts:LoadDynamicAdverts()
	self.storedList = CW.kernel:RestoreSchemaData("plugins/adverts/"..game.GetMap());
end;

-- A function to save the dynamic adverts.
function cwDynamicAdverts:SaveDynamicAdverts()
	CW.kernel:SaveSchemaData("plugins/adverts/"..game.GetMap(), self.storedList);
end;