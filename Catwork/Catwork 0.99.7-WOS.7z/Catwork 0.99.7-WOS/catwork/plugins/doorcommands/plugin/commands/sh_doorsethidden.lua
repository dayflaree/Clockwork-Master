--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("DoorSetHidden");
COMMAND.tip = "Set whether a door is hidden.";
COMMAND.text = "<bool IsHidden>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local door = player:GetEyeTraceNoCursor().Entity;

	if (IsValid(door) and CW.entity:IsDoor(door)) then
		if (CW.kernel:ToBool(arguments[1])) then
			local data = {
				position = door:GetPos(),
				entity = door
			};				

			CW.entity:SetDoorHidden(door, true);

			cwDoorCmds.doorData[data.entity] = {
				position = door:GetPos(),
				entity = door,
				text = "hidden",
				name = "hidden"
			};

			cwDoorCmds:SaveDoorData();

			CW.player:Notify(player, "You have hidden this door.");
		else
			CW.entity:SetDoorHidden(door, false);

			cwDoorCmds.doorData[door] = nil;
			cwDoorCmds:SaveDoorData();

			CW.player:Notify(player, "You have unhidden this door.");
		end;
	else
		CW.player:Notify(player, "This is not a valid door!");
	end;
end;

COMMAND:Register();