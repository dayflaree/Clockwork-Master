--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called just after the translucent renderables have been drawn.
function cwSurfaceTexts:PostDrawTranslucentRenderables(bDrawingDepth, bDrawingSkybox)
	if (bDrawingSkybox or bDrawingDepth) then return; end;

	local large3D2DFont = CW.option:GetFont("surface_text_font");
	local eyeAngles = EyeAngles();
	local eyePos = EyePos();
	local curTime = CurTime();

	cam.Start3D(eyePos, eyeAngles);
		for k, v in pairs(self.storedList) do
			local text = v.text;
			local position = v.position;
			local normal = v.normal;
			local angles = v.angles;
			local scale = v.scale;
			local alpha = math.Clamp(
				CW.kernel:CalculateAlphaFromDistance(512, eyePos, position) * 1.5, 0, 255
			);

			if (alpha > 0) then
				if (!v.width or !v.height or !v.x or !v.y) then
					surface.SetFont(large3D2DFont)
					v.width, v.height = surface.GetTextSize(text);
					v.x = -v.width * 0.5;
					v.y = -v.height * 0.5;
				end;

				local width, height, x, y = v.width, v.height, v.x, v.y;
				local style = v.style;

				if (style and style > 1) then
					cam.Start3D2D(position - normal * 0.8, angles, (scale or 0.25) * 0.2);
						render.PushFilterMin(TEXFILTER.ANISOTROPIC);
						render.PushFilterMag(TEXFILTER.ANISOTROPIC);
							if (style and style > 2) then
								local col = Color((v.styleData or "#FF0000"));
								col.a = math.Clamp(alpha - 75, 0, 255);

								if (style > 3) then
									col.a = col.a * (1 - math.Clamp(math.sin(curTime * 4), 0, 1));
								end;

								surface.SetDrawColor(col);
								surface.DrawRect(x - 8, y - 8, width + 16, height + 16);
							end;

							draw.SimpleText(text, large3D2DFont, x, y, Color(255, 255, 255, alpha - 230));
						render.PopFilterMag();
						render.PopFilterMin();
					cam.End3D2D();
				end;

				if (normal) then
					cam.Start3D2D(position - normal * 0.3, angles, (scale or 0.25) * 0.2);
						render.PushFilterMin(TEXFILTER.ANISOTROPIC);
						render.PushFilterMag(TEXFILTER.ANISOTROPIC);
							draw.SimpleText(text, large3D2DFont, x, y, Color(30, 30, 30, alpha));
						render.PopFilterMag();
						render.PopFilterMin();
					cam.End3D2D();
				end;

				cam.Start3D2D(position, angles, (scale or 0.25) * 0.2);
					render.PushFilterMin(TEXFILTER.ANISOTROPIC);
					render.PushFilterMag(TEXFILTER.ANISOTROPIC);
						draw.SimpleText(text, large3D2DFont, x, y, Color(255, 255, 255, alpha));
					render.PopFilterMag();
					render.PopFilterMin();
				cam.End3D2D();
			end;
		end;
	cam.End3D();
end;