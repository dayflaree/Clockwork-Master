--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("AnimATW");
COMMAND.tip = "Make your character put their hands up against the wall.";
COMMAND.text = "[bool HandsUp]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local curTime = CurTime();

	if (!player.cwNextStance or curTime >= player.cwNextStance) then
		player.cwNextStance = curTime + 2;

		local modelClass = CW.animation:GetModelClass(player:GetModel());
		local eyePos = player:EyePos();

		if (modelClass == "maleHuman") then
			local forcedAnimation = player:GetForcedAnimation();
			local angles = player:GetAngles():Forward();

			if (forcedAnimation and (forcedAnimation.animation == "spreadwallidle" or forcedAnimation.animation == "apcarrestidle")) then
				cwEmoteAnims:MakePlayerExitStance(player);
			elseif (!forcedAnimation or !cwEmoteAnimscwEmoteAnims[forcedAnimation]) then
				if (player:Crouching()) then
					CW.player:Notify(player, "You cannot do this while you are crouching!");
				else
					local traceLine = util.TraceLine({
						start = eyePos,
						endpos = eyePos + (angles * 18),
						filter = player
					});

					if (traceLine.Hit) then
						player.cwPreviousPos = player:GetPos();

						if (!CW.kernel:ToBool(arguments[1])) then
							player:SetPos(player:GetPos() + (angles * -24));
							player:SetForcedAnimation("apcarrestidle", 0, nil, function()
								cwEmoteAnims:MakePlayerExitStance(player);
							end);
						else
							player:SetPos(player:GetPos() + (angles * 14));
							player:SetForcedAnimation("spreadwallidle", 0, nil, function()
								cwEmoteAnims:MakePlayerExitStance(player);
							end);
						end;

						player:SetEyeAngles(traceLine.HitNormal:Angle() + Angle(0, 180, 0));
						player:SetNetVar("StancePos", player:GetPos());
						player:SetNetVar("StanceAng", player:GetAngles());
						player:SetNetVar("StanceIdle", false);
					else
						CW.player:Notify(player, "You must be facing, and near a wall!");
					end;
				end;
			end;
		else
			CW.player:Notify(player, "The model that you are using cannot perform this action!");
		end;
	else
		CW.player:Notify(player, "You cannot do another stance or gesture yet!");
	end;
end;

COMMAND:Register();

if (CLIENT) then
	CW.quickmenu:AddCommand("#Emotes_animATW", "#Emotes", COMMAND.name);
end;