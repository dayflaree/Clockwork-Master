--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("StaticModeToggle");
COMMAND.tip = "Toggle static mode, where ALL player spawned entities will be checked through the whitelist and staticed on spawn.";
COMMAND.access = "a";
COMMAND.alias = {"SMToggle"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)	
	cwStaticEnts.staticMode[1] = !cwStaticEnts.staticMode[1];

	CW.kernel:SaveSchemaData("maps/"..game.GetMap().."/static_entities/static_mode", cwStaticEnts.staticMode);

	CW.player:Notify(player, "You have toggled the static mode to "..tostring(cwStaticEnts.staticMode[1])..".");
end;

COMMAND:Register();