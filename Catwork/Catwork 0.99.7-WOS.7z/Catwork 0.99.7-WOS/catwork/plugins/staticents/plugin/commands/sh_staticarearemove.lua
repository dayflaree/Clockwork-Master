--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("StaticAreaRemove");
COMMAND.tip = "Remove static ents in a certain radius around yourself.";
COMMAND.text = "<number Radius> [bool PropsOnly]";
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local radius = tonumber(arguments[1]);

	if (radius) then
		local radiusEnts = ents.FindInSphere(player:GetPos(), radius);
		local staticCount = 0;
		local propsOnly = CW.kernel:ToBool(arguments[2]) or false;

		for k, entity in pairs(radiusEnts) do
			if (!propsOnly or propsOnly and entity.class == "prop_physics") then
				for k2, v2 in pairs(cwStaticEnts.staticEnts) do
					if (entity == v2) then
						table.remove(cwStaticEnts.staticEnts, k2);
						staticCount = staticCount + 1;
					end;
				end;
			end;
		end;

		if (staticCount > 0) then
			cwStaticEnts:SaveStaticEnts();
		end;

		CW.player:Notify(player, "You have removed "..staticCount.." static entities within "..radius.." units around you.");
	else
		CW.player:Notify(player, "You must enter a number for the radius!");
	end;
end;

COMMAND:Register();