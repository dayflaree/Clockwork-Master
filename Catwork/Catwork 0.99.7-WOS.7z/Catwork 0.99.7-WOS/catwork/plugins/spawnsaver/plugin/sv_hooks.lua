--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when a player's character has unloaded.
function cwSpawnSaver:PlayerCharacterUnloaded(player)
	if (config.Get("spawn_where_left"):Get() and player:Alive() and plugin.Call("ShouldSavePlayerSpawn", player) != false) then
		local position = player:GetPos();
		local posTable = {
			map = game.GetMap(),
			x = position.x,
			y = position.y,
			z = position.z
		};

		player:SetCharacterData("SpawnPoint", posTable);
	end;
end;

-- Called just after a player spawns.
function cwSpawnSaver:PostPlayerSpawn(player, bLightSpawn, bChangeClass, bFirstSpawn)
	if (!bLightSpawn) then
		local spawnPos = player:GetCharacterData("SpawnPoint");

		if (spawnPos and config.GetVal("spawn_where_left") and plugin.Call("ShouldSavePlayerSpawn", player) != false) then
			if (spawnPos.map == game.GetMap()) then
				player:SetPos(Vector(spawnPos.x, spawnPos.y, spawnPos.z));
				player:SetCharacterData("SpawnPoint", nil);
			end;
		end;
	end;
end;