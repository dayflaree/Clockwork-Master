--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	@codebase Server
	@details Provides an interface to the server-side voice channels.
	@field stored A table containing a list of voice channels.
--]]
CW.voice = CW.kernel:NewLibrary("Voice");
local stored = CW.voice.stored or {};
CW.voice.stored = stored;

--[[
	@codebase Server
	@details A function to get all of the voice channels.
	@returns Table A table containing a list of channels.
--]]
function CW.voice:GetChannels()
	return stored;
end;

--[[
	@codebase Server
	@details A function to get a voice channel.
	@param String A unique identifier.
	@returns String The flag for the channel.
--]]
function CW.voice:Get(name)
	return stored[name];
end;

--[[
	@codebase Server
	@details A function to get a voice channel.
	@param String A unique identifier.
	@param String The flag to use the channel.
--]]
function CW.voice:AddChannel(name, flag)
	stored[name] = flag;
end;

--[[
	@codebase Server
	@details A function to add a player to a voice channel.
	@param Player The player to add to the channel.
	@param String A unique identifier.
--]]
function CW.voice:AddToChannel(player, name)
	if (self:Get(name)) then
		player.cwVoiceChannel = self:Get(name);
	end;
end;

--[[
	@codebase Server
	@details A function if a player is in the channel.
	@param Player The player to check if in a channel.
	@param String A unique identifier.
	@returns Bool Whether or not the player is in the channel.
--]]
function CW.voice:IsInChannel(player, name)
	if (player.cwVoiceChannel and player.cwVoiceChannel != "") then	
		if (player.cwVoiceChannel == self:Get(name)) then
			return true;
		end;
	end;
end;

--[[
	@codebase Server
	@details A function to get the players active channel.
	@param Player The player to check if in a channel.
	@param String A unique identifier.
	@returns Bool Whether or not the player is in the channel.
--]]
function CW.voice:GetActiveChannel(player)
	return player.cwVoiceChannel;
end;