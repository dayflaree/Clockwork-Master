--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.system = CW.kernel:NewLibrary("System");
CW.system.stored = CW.system.stored or {};

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE};

-- A function to register a new system.
function CLASS_TABLE:Register()
	return CW.system:Register(self);
end;

-- A function to get all systems.
function CW.system:GetAll()
	return self.stored;
end;

-- A function to get a new system.
function CW.system:New(name)
	local object = CW.kernel:NewMetaTable(CLASS_TABLE);
		object.name = name or "Unknown";
	return object;
end;

-- A function to get a system by an identifier.
function CW.system:FindByID(identifier)
	return self.stored[identifier];
end;

-- A function to get the system panel.
function CW.system:GetPanel()
	if (IsValid(self.panel)) then
		return self.panel;
	end;
end;

-- A function to rebuild an system.
function CW.system:Rebuild(name)
	local panel = self:GetPanel();

	if (panel and self:GetActive() == name) then
		panel:Rebuild();
	end;
end;

-- A function to get the active system.
function CW.system:GetActive()
	local panel = self:GetPanel();

	if (panel) then
		return panel.system;
	end;
end;

-- A function to set the active system.
function CW.system:SetActive(name)
	local panel = self:GetPanel();

	if (panel) then
		panel.system = name;
		panel:Rebuild();
	end;
end;

-- A function to register a new system.
function CW.system:Register(system)
	self.stored[system.name] = system;

	if (!system.HasAccess) then
		system.HasAccess = function(systemTable)
			return CW.player:HasFlags(CW.Client, systemTable.access);
		end;
	end;

	-- A function to get whether the system is active.
	system.IsActive = function(systemTable)
		local activeAdmin = self:GetActive();

		if (activeAdmin == systemTable.name) then
			return true;
		else
			return false;
		end;
	end;

	-- A function to rebuild the system.
	system.Rebuild = function(systemTable)
		self:Rebuild(systemTable.name);
	end;
end;