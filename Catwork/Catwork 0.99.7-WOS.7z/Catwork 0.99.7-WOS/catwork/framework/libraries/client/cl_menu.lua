--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

CW.menu = CW.kernel:NewLibrary("Menu");
CW.menu.width = math.min(ScrW() * 0.7, 768);
CW.menu.height = ScrH() * 0.75;
CW.menu.stored = CW.menu.stored or {};

-- A function to get the menu's active panel.
function CW.menu:GetActivePanel()
	local panel = self:GetPanel();

	if (panel) then
		return panel.activePanel;
	end;
end;

-- A function to get whether a panel is active.
function CW.menu:IsPanelActive(panel)
	return (CW.menu:GetOpen() and self:GetActivePanel() == panel);
end;

-- A function to get the menu hold time.
function CW.menu:GetHoldTime()
	return self.holdTime;
end;

-- A function to get the menu's items.
function CW.menu:GetItems()
	return self.stored;
end;

-- A function to get the menu's width.
function CW.menu:GetWidth()
	return self.width;
end;

-- A function to get the menu's height.
function CW.menu:GetHeight()
	return self.height;
end;

-- A function to toggle whether the menu is open.
function CW.menu:ToggleOpen()
	local panel = self:GetPanel();

	if (panel) then
		if (self:GetOpen()) then
			panel:SetOpen(false);
		else
			panel:SetOpen(true);
		end;
	end;
end;

-- A function to set whether the menu is open.
function CW.menu:SetOpen(bIsOpen)
	local panel = self:GetPanel();

	if (panel) then
		panel:SetOpen(bIsOpen);
	end;
end;

-- A function to get whether the menu is open.
function CW.menu:GetOpen()
	return self.bIsOpen;
end;

-- A function to get the menu panel.
function CW.menu:GetPanel()
	if (IsValid(self.panel)) then
		return self.panel;
	end;
end;

-- A function to create the menu.
function CW.menu:Create(setOpen)
	local panel = self:GetPanel();

	if (!panel) then
		self.panel = vgui.Create("CW.menu");

		if (IsValid(self.panel)) then
			self.panel:SetOpen(setOpen);
			self.panel:MakePopup();
		end;
	end;
end;