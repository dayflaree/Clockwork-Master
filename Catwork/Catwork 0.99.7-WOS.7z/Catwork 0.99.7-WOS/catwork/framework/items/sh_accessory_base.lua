--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New(nil, true);
ITEM.name = "Аксессуары";
ITEM.model = "models/gibs/hgibs.mdl";
ITEM.weight = 1;
ITEM.useText = "Одеть";
ITEM.category = "Аксессуары";
ITEM.description = "Акксесуар, который вы можете одеть на себя.";
ITEM.isAttachment = true;
ITEM.attachmentBone = "ValveBiped.Bip01_Head1";
ITEM.attachmentOffsetAngles = Angle(270, 270, 0);
ITEM.attachmentOffsetVector = Vector(0, 3, 3);

-- Called when a player wears the accessory.
function ITEM:OnWearAccessory(player, bIsWearing)
	if (bIsWearing) then
	else
	end;
end;

-- Called to get whether a player has the item equipped.
function ITEM:HasPlayerEquipped(player, bIsValidWeapon)
	if (CLIENT) then
		return CW.player:IsWearingAccessory(self);
	else
		return player:IsWearingAccessory(self);
	end;
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, extraData)
	player:RemoveAccessory(self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player:IsWearingAccessory(self)) then
		CW.player:Notify(player, "Вы не можете выбросить их, пока они у вас одеты!");
		return false;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (player:Alive() and !player:IsRagdolled()) then
		if (!self.CanPlayerWear or self:CanPlayerWear(player, itemEntity) != false) then
			player:WearAccessory(self);
			return true;
		end;
	else
		CW.player:Notify(player, "Вы не можете сделать это прямо сейчас!");
	end;

	return false;
end;

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		if (!self:IsInstance()) then return; end;

		if (CW.player:IsWearingAccessory(self)) then
			return "Is Wearing: Yes";
		else
			return "Is Wearing: No";
		end;
	end;
end;

CW.item:Register(ITEM);