--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Y");
COMMAND.tip = "Крик вашего персонажа";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ");

	if (text == "") then
		CW.player:Notify(player, L(player, "NotEnoughText"));

		return;
	end;

	chatbox.AddText(nil, "\""..text.."\"", {suffix = " #Suffix_Yell ", sender = player, isPlayerMessage = true, filter = "ic", radius = talkRadius, textColor = Color(255, 255, 180, 255)});
end;

COMMAND:Register();