--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local amountTable = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"};

local COMMAND = CW.command:New("CharGiveItem");
COMMAND.tip = "Выдает определенную вещь персонажу.";
COMMAND.text = "<string Name> <string Item> [number Amount]";
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"PlyGiveItem", "GiveItem"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (CW.player:HasFlags(player, "G")) then
		local target = CW.player:FindByID(arguments[1]);
		local amount = tonumber(arguments[3]) or 1;

		if (target) then
			if (amount > 0 and amount <= 10) then
				local itemTable = CW.item:FindByID(arguments[2]);

				if (itemTable and !itemTable.isBaseItem) then
					for i = 1, amount do
						local itemTable = CW.item:CreateInstance(itemTable("uniqueID"));
						local bSuccess, fault = target:GiveItem(itemTable, true);

						if (!bSuccess) then
							CW.player:Notify(player, fault);

							break;
						end;
					end;

					if (string.utf8sub(itemTable("name"), -1) == "s" and amount == 1) then
						CW.player:Notify(player, "Вы выдали игроку "..target:Name().." "..itemTable("name")..".");
					elseif (amount > 1) then
						CW.player:Notify(player, "Вы выдали игроку "..target:Name().." "..amountTable[amount].." "..CW.kernel:Pluralize(itemTable("name"))..".");
					else
						CW.player:Notify(player, "Вы выдали игроку "..target:Name().." "..itemTable("name")..".");
					end;

					if (player != target) then
						if (string.utf8sub(itemTable("name"), -1) == "s" and amount == 1) then
							CW.player:Notify(target, player:Name().." выдал вам "..itemTable("PrintName")..".");
						elseif (amount > 1) then
							CW.player:Notify(target, player:Name().." выдал вам "..amountTable[amount].." "..CW.kernel:Pluralize(itemTable("PrintName"))..".");
						else
							CW.player:Notify(target, player:Name().." выдал вам "..itemTable("PrintName")..".");
						end;
					end;
				else
					CW.player:Notify(player, "Такой вещи не существует!");
				end;
			else
				CW.player:Notify(player, "Вы можете выдать от 1 до 10 количества!");
			end;
		else
			CW.player:Notify(player, L(player, "NotValidCharacter", arguments[1]));
		end;
	else
		CW.player:Notify(player, "У Вас нет доступа к данной команде!");
	end;
end;

COMMAND:Register();