--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyRespawnStay");
COMMAND.tip = "Появление игрока заново на своей позиции смерти.";
COMMAND.text = "<string Target>";
COMMAND.arguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"PlyRStay", "RespawnStay"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (target) then
		CW.player:LightSpawn(target, true, true, false);
		CW.player:Notify(player, target:GetName().." был заспавнен на своей позиции смерти.");
	else
		CW.player:Notify(player, arguments[1].." это не существующий игрок!");
	end;
end;

COMMAND:Register();