--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharTransfer");
COMMAND.tip = "Переводит персонажа в другую фракцию.";
COMMAND.text = "<string Name> <string Faction> [string Data]";
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Transfer"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if (target) then
		local faction = arguments[2];
		local name = target:Name();

		if (!CW.faction:GetStored()[faction]) then
			CW.player:Notify(player, faction.." это не существующая фракция!");
			return;
		end;

		if (!CW.faction:GetStored()[faction].whitelist or CW.player:IsWhitelisted(target, faction)) then
			local targetFaction = target:GetFaction();

			if (targetFaction == faction) then
				CW.player:Notify(player, target:Name().." уже в "..faction.." фракции!");
				return;
			end;

			if (!CW.faction:IsGenderValid(faction, target:GetGender())) then
				CW.player:Notify(player, target:Name().." некорекктный пол персонажа для "..faction.." фракции!");
				return;
			end;

			if (!CW.faction:GetStored()[faction].OnTransferred) then
				CW.player:Notify(player, target:Name().." не может быть переведен в "..faction.." фракцию!");
				return;
			end;

			local bSuccess, fault = CW.faction:GetStored()[faction]:OnTransferred(target, CW.faction:GetStored()[targetFaction], arguments[3]);

			if (bSuccess != false) then
				target:SetCharacterData("Faction", faction, true);

				CW.player:LoadCharacter(target, CW.player:GetCharacterID(target));
				CW.player:NotifyAll(player:Name().." перевел "..name.." в "..faction.." фракцию.");
			else
				CW.player:Notify(player, fault or target:Name().." не может быть перемещен в "..faction.." фракцию!");
			end;
		else
			CW.player:Notify(player, target:Name().." не в "..faction.." вайтлисте!");
		end;
	else
		CW.player:Notify(player, arguments[1].." это не существующий игрок!");
	end;
end;

COMMAND:Register();