--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyUnwhitelist");
COMMAND.tip = "Забирает вайтлист у игрока.";
COMMAND.text = "<string Name> <string Faction>";
COMMAND.access = "W";
COMMAND.arguments = 2;
COMMAND.alias = {"UnWhitelist", "DeWhitelist"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if (target) then
		local factionTable = CW.faction:FindByID(table.concat(arguments, " ", 2));

		if (factionTable) then
			if (factionTable.whitelist) then
				if (CW.player:IsWhitelisted(target, factionTable.name)) then
					CW.player:SetWhitelisted(target, factionTable.name, false);
					CW.player:SaveCharacter(target);

					CW.player:NotifyAll(player:Name().." забрал у "..target:Name().." "..factionTable.name.." вайтлист.");
				else
					CW.player:Notify(player, target:Name().." не в "..factionTable.name.." вайтлисте!");
				end;
			else
				CW.player:Notify(player, factionTable.name.." не имеет вайтлиста!");
			end;
		else
			CW.player:Notify(player, factionTable.name.." это не сущеуствующая фракция!");
		end;
	else
		CW.player:Notify(player, arguments[1].." это не существующий игрок!");
	end;
end;

COMMAND:Register();