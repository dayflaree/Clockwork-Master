--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharSetDesc");
COMMAND.tip = "Выдает пермаментное описание персонажу.";
COMMAND.text = "<string Name> <string Description>";
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"SetDescription", "SetDesc"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local minimumPhysDesc = config.Get("minimum_physdesc"):Get();
	local text = arguments[2];

	if (target) then
		if (text and text != "") then
			if (string.utf8len(text) < minimumPhysDesc) then
				CW.player:Notify(player, "Физическое описание должно быть не менее "..minimumPhysDesc.." букв!");
				return;
			end;

			local physDesc = CW.kernel:ModifyPhysDesc(text);

			target:SetCharacterData("PhysDesc", physDesc);

			CW.player:Notify(player, target:Name().." изменено описание на \'"..physDesc.."\'");
		else
			CW.dermaRequest:RequestString(player, "Physical Description Change", "На какое описание, Вы хотите изменить Ваше старое описание?", target:GetDTString(STRING_PHYSDESC), function(result)
				player:RunClockworkCmd(self.name, target:Name(), result);
			end)
		end;
	else
		CW.player:Notify(player, L(player, "NotValidCharacter", arguments[1]));
	end;
end;

COMMAND:Register();
