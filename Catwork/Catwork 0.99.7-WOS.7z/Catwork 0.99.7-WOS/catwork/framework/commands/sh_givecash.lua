--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("GiveCash", "");
COMMAND.tip = "Передает деньги игроку напротив вас.";
COMMAND.text = "<number cash>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.alias = {"GiveCash", "GiveTokens", "ДатьТокены", "Заплатить"};
COMMAND.cooldown = 5;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	local cash = math.floor(tonumber((arguments[1] or 0)));

	if (target and target:IsPlayer()) then
		if (target:GetShootPos():Distance(player:GetShootPos()) <= 192) then			
			if (cash and cash >= 1) then
				if (CW.player:CanAfford(player, cash)) then
					local playerName = player:Name();
					local targetName = target:Name();

					if (!CW.player:DoesRecognise(player, target)) then
						targetName = CW.player:GetUnrecognisedName(target, true);
					end;

					if (!CW.player:DoesRecognise(target, player)) then
						playerName = CW.player:GetUnrecognisedName(player, true);
					end;

					CW.player:GiveCash(player, -cash);
					CW.player:GiveCash(target, cash);

					CW.player:Notify(player, "Вы передали "..CW.kernel:FormatCash(cash, nil, true).." игроку "..targetName..".");
					CW.player:Notify(target, "Вам передал "..CW.kernel:FormatCash(cash, nil, true).." игрок "..playerName..".");
				else
					local amount = cash - player:GetCash();
					CW.player:Notify(player, "Вам нужно другой "..CW.kernel:FormatCash(amount, nil, true).."!");
				end;
			else
				CW.player:Notify(player, "Это не существующее количество!");
			end;
		else
			CW.player:Notify(player, "Этот персонаж слишком далеко от вас!");
		end;
	else
		CW.player:Notify(player, "Вы должны смотреть на персонажа!");
	end;
end;

COMMAND:Register();