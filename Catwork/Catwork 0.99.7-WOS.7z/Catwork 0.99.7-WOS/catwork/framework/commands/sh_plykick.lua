--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyKick");
COMMAND.tip = "Кикает игрока с сервера.";
COMMAND.text = "<string Name> <string Reason>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 2;
COMMAND.alias = {"Kick"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local reason = table.concat(arguments, " ", 2);

	if (!reason or reason == "") then
		reason = "Вы являетесь противной персоной.";
	end;

	if (target) then
		if (!CW.player:IsProtected(arguments[1])) then
			CW.player:NotifyAll(player:Name().." кикнул '"..target:Name().."' ("..reason..").");
				target:Kick(reason);
			target.kicked = true;
		else
			CW.player:Notify(player, target:Name().." защищен!");
		end;
	else
		CW.player:Notify(player, arguments[1].." это не сущеуствующий игрок!");
	end;
end;

COMMAND:Register();