--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("EventLocal");
COMMAND.tip = "Посылает определенное событие, игрокам в вашей местности.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"LocalEvent", "EL"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	chatbox.AddText(nil, "* "..table.concat(arguments, " "), {filter = "player_events", textColor = Color("#FFAB00"), icon = false, position = player:GetPos()});
end;

COMMAND:Register();