--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PluginLoad");
COMMAND.tip = "Загружает плагины.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local pluginTable = plugin.FindByID(arguments[1]);

	if (!plugin) then
		CW.player:Notify(player, "Этот плагин не существует!");
		return;
	end;

	local loadTable = CW.command:FindByID("PluginLoad");

	if (!plugin.IsDisabled(pluginTable.name)) then
		local bSuccess = plugin.SetUnloaded(pluginTable.name, false);
		local recipients = {};

		if (bSuccess) then
			CW.player:NotifyAll(player:Name().." загрузил "..pluginTable.name.." плагин до следующего рестарта.");

			for k, v in ipairs(_player.GetAll()) do
				if (v:HasInitialized()) then
					if (CW.player:HasFlags(v, loadTable.access)) then
						recipients[#recipients + 1] = v;
					end;
				end;
			end;

			if (#recipients > 0) then
				netstream.Start(recipients, "SystemPluginSet", {pluginTable.name, false});
			end;
		else
			CW.player:Notify(player, "Этот плагин не может быть загружен!");
		end;
	else
		CW.player:Notify(player, "Этот плагин зависит от другого плагина!");
	end;
end;

COMMAND:Register();