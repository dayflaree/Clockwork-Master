--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyWhitelist");
COMMAND.tip = "Добавляет игрока в вайтлист фракции.";
COMMAND.text = "<string Name> <string Faction>";
COMMAND.access = "a";
COMMAND.arguments = 2;
COMMAND.alias = {"Whitelist", "CharWhitelist", "GiveWhitelist"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if (target) then
		local factionTable = CW.faction:FindByID(table.concat(arguments, " ", 2));

		if (factionTable) then
			if (factionTable.whitelist) then
				if (!CW.player:IsWhitelisted(target, factionTable.name)) then
					CW.player:SetWhitelisted(target, factionTable.name, true);
					CW.player:SaveCharacter(target);

					CW.player:NotifyAll(player:Name().." добавил "..target:Name().." в "..factionTable.name.." вайтлист.");
				else
					CW.player:Notify(player, target:Name().." уже в "..factionTable.name.." вайтлисте!");
				end;
			else
				CW.player:Notify(player, factionTable.name.." не имеет вайтлиста!");
			end;
		else
			CW.player:Notify(player, table.concat(arguments, " ", 2).." это не существующая фракция!");
		end;
	else
		CW.player:Notify(player, arguments[1].." это не сущестующий игрок!");
	end;
end;

COMMAND:Register();