--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlySetHealth");
COMMAND.tip = "Устанавливает количество здоровья персонажу.";
COMMAND.text = "<string Target> <number HP>";
COMMAND.arguments = 2;
COMMAND.access = "o";
COMMAND.alias = {"PlyHealth", "Health", "SetHealth"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local health = tonumber(arguments[2]);

	if (isnumber(health)) then
		target:SetHealth(health);
		CW.player:Notify(player, target:GetName().." установлено здоровье на "..health..".");
		CW.player:Notify(target, "Ваше здоровье было установлено на "..health.." администратором "..player:GetName()..".");
	end;
end;

COMMAND:Register();