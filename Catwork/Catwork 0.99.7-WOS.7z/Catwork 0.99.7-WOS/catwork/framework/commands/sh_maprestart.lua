--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("MapRestart");
COMMAND.tip = "Перезагружает текущую карту.";
COMMAND.text = "[number Delay]";
COMMAND.access = "a";
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Restart"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local delay = tonumber(arguments[1]) or 10;

	if (type(arguments[1]) == "number") then
		delay = arguments[1];
	end;

	CW.player:NotifyAll(player:Name().." перезагружает карту через "..delay.." секунд!");

	timer.Simple(delay, function()
		RunConsoleCommand("changelevel", game.GetMap());
	end);
end;

COMMAND:Register();