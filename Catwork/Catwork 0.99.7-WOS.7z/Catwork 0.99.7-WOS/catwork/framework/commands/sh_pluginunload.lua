--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PluginUnload");
COMMAND.tip = "Разгружает плагины.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local plugin = plugin.FindByID(arguments[1]);

	if (!plugin) then
		CW.player:Notify(player, "Этого плагина не существует!");
		return;
	end;

	local unloadTable = CW.command:FindByID("PluginLoad");
	local loadTable = CW.command:FindByID("PluginLoad");

	if (!plugin.IsDisabled(plugin.name)) then
		local bSuccess = plugin.SetUnloaded(plugin.name, true);
		local recipients = {};

		if (bSuccess) then
			CW.player:NotifyAll(player:Name().." разгрузил "..plugin.name.." плагин до следующего рестарта.");

			for k, v in ipairs(_player.GetAll()) do
				if (v:HasInitialized()) then
					if (CW.player:HasFlags(v, loadTable.access)
					or CW.player:HasFlags(v, unloadTable.access)) then
						recipients[#recipients + 1] = v;
					end;
				end;
			end;

			if (#recipients > 0) then
				netstream.Start(recipients, "SystemPluginSet", {plugin.name, true});
			end;
		else
			CW.player:Notify(player, "Этот плагин не может быть разгружен!");
		end;
	else
		CW.player:Notify(player, "Этот плагин зависит от другуго плагина!");
	end;
end;

COMMAND:Register();