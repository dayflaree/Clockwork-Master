--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Event");
COMMAND.tip = "Посылает определенное событие всем игрокам.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"E"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	chatbox.AddText(nil, "** "..table.concat(arguments, " "), {filter = "events", textColor = Color("#FFAB00"), icon = false});
end;

COMMAND:Register();