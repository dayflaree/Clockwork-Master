--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyRespawnTP");
COMMAND.tip = "Появление игрока заново, при этом телепортируя его на вашу позицию.";
COMMAND.text = "<string Target> <bool isSilent>";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.access = "o";
COMMAND.alias = {"PlyRTP", "RespawnTP"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local isSilent = CW.kernel:ToBool(arguments[2]);
	local trace = player:GetEyeTraceNoCursor();

	if (target) then
		CW.player:LightSpawn(target, true, true, true);
		CW.player:SetSafePosition(target, trace);
		CW.player:Notify(player, target:GetName().." был зареспавнен и телепортирован на вашу позицию.");
	else
		CW.player:Notify(player, arguments[2].." это не существующий игрок!");
	end;
end;

COMMAND:Register();