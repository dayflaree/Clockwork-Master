--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharTie");
COMMAND.tip = "Связать/Развязать персонажа.";
COMMAND.text = "<string Name>";
COMMAND.access = "a";
COMMAND.arguments = 1;
COMMAND.optionalArguments = 1;
COMMAND.alias = {"Tie"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (!CW.command:FindByID("InvZipTie")) then
		player:Notify("Эта схема не поддерживает команды, используйте клавишу F3.");
		return;
	end;

	if (target) then
		if (target:GetNetVar("tied") != 0) then
			Schema:TiePlayer(target, false);
			player:Notify("Вы развязали "..target:GetName()..".");
			target:Notify("Вы были развязаны "..player:GetName()..".");
		else
			Schema:TiePlayer(target, true);
			player:Notify("Вы связали "..target:GetName()..".");
			target:Notify("Вы были связаны "..player:GetName()..".");
		end
	else
		player:Notify(arguments[2].." это не существующий игрок!");
	end
end;

COMMAND:Register();