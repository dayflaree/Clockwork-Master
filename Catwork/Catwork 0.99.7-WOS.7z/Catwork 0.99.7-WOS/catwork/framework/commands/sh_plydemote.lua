--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyDemote");
COMMAND.tip = "Увольняет игрока из группы.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;
COMMAND.alias = {"Demote"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (target) then
		if (!CW.player:IsProtected(target)) then
			local userGroup = target:GetClockworkUserGroup();

			if (userGroup != "user") then
				CW.player:NotifyAll(player:Name().." уволил "..target:Name().." из "..userGroup.." на user.");
					target:SetClockworkUserGroup("user");
				CW.player:LightSpawn(target, true, true);
			else
				CW.player:Notify(player, "Этот игрок уже находится в данной группе!");
			end;
		else
			CW.player:Notify(player, target:Name().." защищен!");
		end;
	else
		CW.player:Notify(player, arguments[1].." это не сущеуствующий игрок!");
	end;
end;

COMMAND:Register();