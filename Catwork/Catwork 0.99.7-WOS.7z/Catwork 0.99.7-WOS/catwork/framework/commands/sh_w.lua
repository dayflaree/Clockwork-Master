--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("W");
COMMAND.tip = "Шепот вашего персонажа";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local talkRadius = math.min(config.Get("talk_radius"):Get() / 3, 80);
	local text = table.concat(arguments, " ");

	if (text == "") then
		CW.player:Notify(player, L(player, "NotEnoughText"));

		return;
	end;

	chatbox.AddText(nil, "\""..text.."\"", {suffix = " #Suffix_Whisper ", sender = player, isPlayerMessage = true, filter = "ic", radius = talkRadius, textColor = Color(255, 255, 230, 200)});
end;

COMMAND:Register();