--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("ARequest");
COMMAND.tip = "Послыает запрос всем администраторам.";
COMMAND.text = "<string Text>";
COMMAND.access = "o";
COMMAND.arguments = 1;
COMMAND.alias = {"AR"};
COMMAND.cooldown = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
   if (!CW.player:IsAdmin(player)) then
      CW.player:NotifyAdmins("o", "REQUEST from "..player:Name()..": "..table.concat(arguments, " "), nil);
   else
      CW.player:Notify(player, "Вы администратор. Используйте команду /a.");
   end;
end;

COMMAND:Register();
