--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("StorageGive"..string.gsub(NAME_CASH, "%s", ""));
COMMAND.tip = "Give some "..string.lower(NAME_CASH).." to storage.";
COMMAND.text = "<number "..string.gsub(NAME_CASH, "%s", "")..">";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.cooldown = 5;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local storageTable = player:GetStorageTable();

	if (storageTable) then
		local target = storageTable.entity;
		local cash = math.floor(tonumber(arguments[1]));

		if ((target and !IsValid(target)) or !config.Get("cash_enabled"):Get()) then
			return;
		end;

		if (cash and cash > 1 and CW.player:CanAfford(player, cash)) then
			if (!storageTable.CanGiveCash
			or (storageTable.CanGiveCash(player, storageTable, cash) != false)) then
				if (!target or !target:IsPlayer()) then
					local cashWeight = config.Get("cash_weight"):Get();
					local myWeight = CW.storage:GetWeight(player);

					local cashSpace = config.Get("cash_space"):Get();
					local mySpace = CW.storage:GetSpace(player);

					if (CW.storage:GetWeight(player) + (config.Get("cash_weight"):Get() * cash) <= storageTable.weight and mySpace + (cashSpace * cash) <= storageTable.space) then
						CW.player:GiveCash(player, -cash, nil, true);
						CW.storage:UpdateCash(player, storageTable.cash + cash);
					end;
				else
					CW.player:GiveCash(player, -cash, nil, true);
					CW.player:GiveCash(target, cash, nil, true);
					CW.storage:UpdateCash(player, target:GetCash());
				end;

				if (storageTable.OnGiveCash
				and storageTable.OnGiveCash(player, storageTable, cash)) then
					CW.storage:Close(player);
				end;
			end;
		end;
	else
		CW.player:Notify(player, L("StorageNotOpen"));
	end;
end;

COMMAND:Register();