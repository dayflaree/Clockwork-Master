--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharPhysDesc");
COMMAND.tip = "Меняет физическое описание вашего персонажа.";
COMMAND.text = "[string Text]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;
COMMAND.alias = {"PhysDesc", "ChangeDesc", "ChangeDescription"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local minimumPhysDesc = config.Get("minimum_physdesc"):Get();

	if (arguments[1]) then
		local text = table.concat(arguments, " ");

		if (string.utf8len(text) < minimumPhysDesc) then
			CW.player:Notify(player, "Физическое описание должно быть не менее "..minimumPhysDesc.." букв длинной!");
			return;
		end;

		player:SetCharacterData("PhysDesc", CW.kernel:ModifyPhysDesc(text));
	else
		CW.dermaRequest:RequestString(player, "Physical Description Change", "На какое описание вы хотите изменить ваше старое описание?", player:GetDTString(STRING_PHYSDESC), function(result)
			player:RunClockworkCmd(self.name, result);
		end)
	end;
end;

COMMAND:Register();