--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("DropWeapon");
COMMAND.tip = "Выбрасывает ваше оружие на определенную позицию.";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.alias = {"Drop"};
COMMAND.cooldown = 5;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local weapon = player:GetActiveWeapon();

	if (IsValid(weapon)) then
		local class = weapon:GetClass();
		local itemTable = CW.item:GetByWeapon(weapon);

		if (!itemTable) then
			CW.player:Notify(player, "Это не существующее оружие!");
			return;
		end;

		if (plugin.Call("PlayerCanDropWeapon", player, itemTable, weapon)) then
			local trace = player:GetEyeTraceNoCursor();

			if (player:GetShootPos():Distance(trace.HitPos) <= 192) then
				local entity = CW.entity:CreateItem(player, itemTable, trace.HitPos);

				if (IsValid(entity)) then
					CW.entity:MakeFlushToGround(entity, trace.HitPos, trace.HitNormal);
						player:TakeItem(itemTable, true);
						player:StripWeapon(class);
						player:SelectWeapon("cw_hands");
					plugin.Call("PlayerDropWeapon", player, itemTable, entity, weapon);
				end;
			else
				CW.player:Notify(player, "Вы не можете выбрасывать оружие так далеко!");
			end;
		end;
	else
		CW.player:Notify(player, "Это не существующее оружие!");
	end;
end;

COMMAND:Register();