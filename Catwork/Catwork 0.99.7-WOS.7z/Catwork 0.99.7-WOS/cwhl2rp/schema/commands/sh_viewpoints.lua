--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("ViewPoints");
COMMAND.tip = "Displays Criminal and Loyalty points of the player.";
COMMAND.text = "<string Player>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;
COMMAND.alias = {"CheckPoints", "CheckLP", "CheckCP", "ViewLP", "ViewCP"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local isAdmin = (player:GetUserGroup() == "superadmin");

	if ((Schema:PlayerIsCombine(player)) or isAdmin) then
		local target = CW.player:FindByID(arguments[1]);

		if (IsValid(target)) then
			CW.player:Notify(
				player,
				target:Name()..": LP - "..(target:GetCharacterData("LoyaltyPoints") or 0)..", CP - "..(target:GetCharacterData("CriminalPoints") or 0).."."
			);
		else
			CW.player:Notify(player, arguments[1].." is not a valid player!");
		end;
	else
		CW.player:Notify(player, "You are not the Combine!");
	end;
end;

COMMAND:Register();