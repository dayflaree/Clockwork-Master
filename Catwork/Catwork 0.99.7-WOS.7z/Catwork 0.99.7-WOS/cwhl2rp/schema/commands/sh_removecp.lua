--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("RemoveCP");
COMMAND.tip = "Remove Criminal Points from character's data.";
COMMAND.text = "<string Player> <number Amount>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 2;
COMMAND.alias = {"RemoveCriminalPoints", "RemoveCrimePoints"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local isAdmin = (player:GetUserGroup() == "superadmin");

	if ((Schema:PlayerIsCombine(player) and !player:Name():find("RCT")) or isAdmin) then
		local target = CW.player:FindByID(arguments[1]);
		local amount = tonumber(arguments[2]);

		if (IsValid(target)) then
			if (!(target.nextCPSet and target.nextCPSet > os.time() or isAdmin)) then
				if (amount) then
					if (!isAdmin) then
						amount = math.Clamp(amount, 0, 20);
					end;

					local curCP = target:GetCharacterData("CriminalPoints") or 0;
					Schema:SetCP(target, curCP - amount);

					target.nextCPSet = os.time() + 120;

					CW.player:Notify(player, target:Name().."'s Criminal Points were set to "..target:GetCharacterData("CriminalPoints").." ("..curCP.." - "..amount..").");
				else
					CW.player:Notify(player, tostring(arguments[2]).." is not a valid amount!");
				end;
			else
				CW.player:Notify(player, "Please wait before setting "..target:Name().."'s Criminal Points again!");
			end;
		else
			CW.player:Notify(player, arguments[1].." is not a valid player!");
		end;
	else
		CW.player:Notify(player, "You are not the Combine or not ranked high enough to use this command!");
	end;
end;

COMMAND:Register();