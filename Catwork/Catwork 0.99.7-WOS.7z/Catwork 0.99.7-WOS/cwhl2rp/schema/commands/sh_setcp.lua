--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("SetCP");
COMMAND.tip = "Sets Criminal Points for character.";
COMMAND.text = "<string Player> <number Amount>";
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);
	local amount = tonumber(arguments[2]);

	if (IsValid(target)) then
		if (amount) then
			Schema:SetCP(target, amount);

			CW.player:Notify(player, target:Name().."'s Criminal Points were set to "..target:GetCharacterData("CriminalPoints")..".");
		else
			CW.player:Notify(player, tostring(arguments[2]).." is not a valid amount!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();