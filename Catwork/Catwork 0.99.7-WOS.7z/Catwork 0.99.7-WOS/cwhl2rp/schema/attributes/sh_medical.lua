--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = CW.attribute:New();
	ATTRIBUTE.name = "#Attribute_Medical";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "med";
	ATTRIBUTE.description = "#Attribute_Medical_Desc";
	ATTRIBUTE.isOnCharScreen = true;
ATB_MEDICAL = CW.attribute:Register(ATTRIBUTE);