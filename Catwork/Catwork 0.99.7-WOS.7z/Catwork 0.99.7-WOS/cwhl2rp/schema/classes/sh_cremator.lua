--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Крематор");
	CLASS.color = Color(255, 165, 0, 255);
	CLASS.wages = 0;
	CLASS.factions = {FACTION_CREMATOR};
	CLASS.isDefault = true;
	CLASS.wagesName = "Денежное довольствие";
	CLASS.description = "Уничтожает биомусор, а также обычный мусор в городе.";
	CLASS.defaultPhysDesc = "Зеленый плащ из шерстяной ткани, скорее всего он сшит с телом, имеется неизвестный вырез на животе. Черные сапоги. Странная голова, со светящимся оранжевым глазами и небольшим респиратором ниже.";
CLASS_CREMATOR = CLASS:Register();