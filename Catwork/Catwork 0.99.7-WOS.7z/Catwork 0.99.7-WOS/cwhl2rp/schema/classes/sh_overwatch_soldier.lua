--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local CLASS = CW.class:New("#Class_OverwatchSoldier");
	CLASS.color = Color(150, 50, 50, 255);
	CLASS.wages = 40;
	CLASS.factions = {FACTION_OTA};
	CLASS.wagesName = "#Class_OverwatchSoldier_Wages";
	CLASS.description = "#Class_OverwatchSoldier_Desc";
	CLASS.defaultPhysDesc = "Wearing dirty Overwatch gear";
CLASS_OWS = CLASS:Register();