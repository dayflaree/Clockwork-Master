--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ITEM = CW.item:New();
ITEM.name = "Стандартный рацион";
ITEM.uniqueID = "ration_standard";
ITEM.model = "models/weapons/w_packatc.mdl";
ITEM.weight = 1.35;
ITEM.useText = "Распаковать";
ITEM.description = "Фиолетовый пакет, на лицевой стороне маркировка /CITIZEN/?";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
	if (quickUse) then
		if (!player:CanHoldWeight(self.weight)) then
			CW.player:Notify(player, "У Вас недостаточно места в инвентаре!");

			return false;
		end;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (Schema:PlayerIsCombine(player)) then
		CW.player:Notify(player, "Вы не имеете права открывать данный рацион!");

		return false;
	elseif (player:GetFaction() == FACTION_ADMIN) then
		CW.player:Notify(player, "Вы не имеете права открывать данный рацион!");

		return false;
	else
		CW.player:GiveCash(player, 35, "ration packet");

		player:GiveItem(CW.item:CreateInstance("citizen_supplements"), true);
		player:GiveItem(CW.item:CreateInstance("breens_water"), true);

		plugin.Call("PlayerUseRation", player);
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();