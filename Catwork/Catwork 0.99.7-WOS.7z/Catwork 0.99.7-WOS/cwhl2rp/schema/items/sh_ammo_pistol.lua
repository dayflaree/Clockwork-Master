--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Пистолетные патроны 9мм";
	ITEM.cost = 20;
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.model = "models/items/boxsrounds.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_pistol";
	ITEM.business = true;
	ITEM.ammoClass = "pistol";
	ITEM.ammoAmount = 20;
	ITEM.description = "Зеленый контейнер наполненный патронами, на лицевой стороне белой краской написанно /9мм/.";
ITEM:Register();