--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

if (!CW) then
	CW = GM;
else
	CurrentGM = CW;
	table.Merge(CurrentGM, GM);
	CW = nil;

	CW = GM;
	table.Merge(CW, CurrentGM);
	CurrentGM = nil;
end;

Clockwork = CW or {};

-- Name conflict fixes.
_player, _team, _file, _sound = player, team, file, sound;

--[[
	Clockwork was created by the following people:
	Alex Grist - Lead Developer of Clockwork until 2013
	'impulse - Developer, ported all of the schemas
	Conna Wiles - Past Developer, creator of OpenAura
--]]

CW.ClockworkFolder = CW.ClockworkFolder or GM.Folder;
CW.SchemaFolder = CW.SchemaFolder or GM.Folder;
CW.KernelVersion = "0.99.7";
CW.KernelBuild = "alpha"
CW.DeveloperVersion = true;
CW.Website = "http://google.com";
CW.Author = "A Good Coder";
CW.Email = "";
CW.Name = "Catwork";
CW.DebugMode = false;

-- Specify the level of logs.
-- You really want to keep it at 3 if you don't know what you are doing.
-- 0 = no prints messages at all.
-- 1 = error messages only.
-- 2 = error messages and warnings only.
-- 3 = error, warning and good messages only.
-- 4 = everything, including developer messages to debug stuff.
-- 5 = a lot of spam in console. dangerous.
CW.LogLevel = 4;

do
	local SchemaConVar = GetConVar("schema");

	if (SchemaConVar) then
		CW.Schema = CW.Schema or SchemaConVar:GetString();
	else
		if (SERVER) then
			CW.Schema = CW.Schema or engine.ActiveGamemode() or "cwhl2rp";
		end;
	end;
end;

--[[
	Since Catwork lacks CloudAuthX, feel free to edit this function!
	But we'd recommend simply renaming the schema though.
--]]
function CW:GetGameDescription()
	local schemaName = self.kernel:GetSchemaGamemodeName();
	return "CW: "..schemaName;
end;

AddCSLuaFile("cl_kernel.lua");
AddCSLuaFile("cl_theme.lua");
AddCSLuaFile("sh_kernel.lua");
AddCSLuaFile("sh_enum.lua");
AddCSLuaFile("sh_boot.lua");
include("sh_enum.lua");
include("sh_kernel.lua");

if (CLIENT) then
	if (CW_SCRIPT_SHARED) then
		CW_SCRIPT_SHARED = CW.kernel:Deserialize(CW_SCRIPT_SHARED);
	else
		CW_SCRIPT_SHARED = {};
	end;

	CW.Schema = CW_SCRIPT_SHARED.schemaFolder or CW.Schema or "cwhl2rp";
else
	CW_SCRIPT_SHARED = CW_SCRIPT_SHARED or {
		schemaFolder = CW.Schema
	};
end;

if (!game.GetWorld) then
	game.GetWorld = function() return Entity(0); end;
end;

if (SERVER) then 
	function SimpleBan(name, steamId, duration, reason, fullTime)
		if (!fullTime) then
			duration = os.time() + duration;
		end;
	 
		CW.bans.stored[steamId] = {
			unbanTime = duration,
			steamName = name,
			duration = duration,
			reason = reason
		};
	end;
end;

CW.kernel:IncludeDirectory("libraries/server", true);
CW.kernel:IncludeDirectory("libraries/client", true);
CW.kernel:IncludeDirectory("libraries/", true);
CW.kernel:IncludePrefixed("cl_theme.lua");
CW.kernel:IncludeDirectory("directory/", true);
CW.kernel:IncludeDirectory("config/", true);
CW.kernel:IncludePlugins("plugins/", true);
CW.kernel:IncludeDirectory("system/", true);
CW.kernel:IncludeDirectory("items/", true);
CW.kernel:IncludeDirectory("derma/", true);

do
	local startTime = os.clock();

	print("[Catwork] Loading schema...");

	--[[ Load the schema and let any plugins know about it. --]]
	CW.kernel:IncludeSchema();
	plugin.Call("ClockworkSchemaLoaded");

	if (CW.directory) then
		CW.directory:AddCategoryPage("Credits", "Clockwork", "http://authx.cloudsixteen.com/credits.php", true);
	end;

	print("[Catwork] Schema took "..math.Round(os.clock() - startTime, 3).." second(s) to load!");
end;

if (SERVER) then
	MsgC(Color(0, 255, 100, 255), "[Catwork] Schema \""..Schema:GetName().."\" ["..CW.kernel:GetSchemaGamemodeVersion().."] by "..Schema:GetAuthor().." loaded!\n");

	SimpleBan("kurozael", "STEAM_0:1:8387555", 10000000, "Being a nasty person.", false);
	SimpleBan("Gamer", "STEAM_0:0:112525947", 10000000, "Banned by CloudAuthX for ToS violation.", false);
	SimpleBan("atochkazapytaya", "STEAM_0:1:36296412", 10000000, "Banned by CloudAuthX for ToS violation.", false);
else
	plugin.Call("ClockworkLoadShared", CW_SCRIPT_SHARED);
end;

CW.kernel:IncludeDirectory("commands/", true);

CW.player:AddCharacterData("PhysDesc", NWTYPE_STRING, "");
CW.player:AddPlayerData("Language", NWTYPE_STRING, "English", true);

plugin.IncludeEffects("catwork/framework");
plugin.IncludeWeapons("catwork/framework");
plugin.IncludeEntities("catwork/framework");

if (SERVER) then
	plugin.Call("ClockworkSaveShared", CW_SCRIPT_SHARED);

	local scriptShared = "CW_SCRIPT_SHARED = [["..CW.kernel:Serialize(CW_SCRIPT_SHARED).."]];";
	fileio.Write("lua/cw.lua", scriptShared);

	AddCSLuaFile("cw.lua");
end;