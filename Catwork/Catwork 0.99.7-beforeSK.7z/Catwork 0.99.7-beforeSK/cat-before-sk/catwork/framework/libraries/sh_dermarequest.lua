--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

--[[
	@codebase Shared
	@details A library to send Derma String Requests to clients through the server. It can also send simple Derma messages.
--]]
CW.dermaRequest = CW.kernel:NewLibrary("DermaRequest");

local REQUEST_INDEX = 0;
function CW.dermaRequest:GenerateID()
	REQUEST_INDEX = REQUEST_INDEX + 1;
	return os.time() + REQUEST_INDEX;
end;

if (SERVER) then
	local hooks = CW.dermaRequest.hooks or {};
	CW.dermaRequest.hooks = hooks;

	--[[
		@codebase Server
		@details Requests a string in the form of a derma popup on the specified client.
		@param Player The player to send the request to.
		@param String A title string to apply to the derma popup.
		@param String The question to ask in the derma popup.
		@param String An optional default string for the answer.
		@param Function A callback function. It passes the answer as an argument.
	--]]
	function CW.dermaRequest:RequestString(player, title, question, default, Callback)
		local rID = self:GenerateID();
		netstream.Start(player, "dermaRequest_stringQuery", {id = rID, title = title, question = question, default = default});
		hooks[rID] = {Callback = Callback, player = player};
	end;

	--[[
		@codebase Server
		@details Requests a confirmation from a player. When called, it displays a question box with a Confirm and Cancel button.
		@param Player The player to send the request to.
		@param String A title string to apply to the derma popup.
		@param String The question to ask in the derma popup.
		@param Function A callback function. It passes the answer as an argument.
	--]]
	function CW.dermaRequest:RequestConfirmation(player, title, question, Callback)
		local rID = self:GenerateID();
		netstream.Start(player, "dermaRequest_confirmQuery", {id = rID, title = title, question = question});
		hooks[rID] = {Callback = Callback, player = player};
	end;

	--[[
		@codebase Server
		@details Sends a derma popup message to a specific player.
		@param Player The player to send the request to.
		@param String The message to send to the player.
		@param String A title string to apply to the derma popup (Optional).
		@param String An optional button text override (Optional).
	--]]
	function CW.dermaRequest:Message(player, message, title, button)
		netstream.Start(player, "dermaRequest_message", {message = message, title = title or nil, button = button or nil});
	end;

	-- An internal function to validate a return
	function CW.dermaRequest:Validate(player, data)
		if (data.id and data.recv and hooks[data.id] and hooks[data.id].player == player) then
			return true;
		end;
		return false;
	end;

	netstream.Hook("dermaRequestCallback", function(player, data)
		if (!CW.dermaRequest:Validate(player, data)) then return; end;
		hooks[data.id].Callback(data.recv);
		hooks[data.id] = nil;
	end);

else

	function CW.dermaRequest:Send(id, recv)
		netstream.Start("dermaRequestCallback", {id = id, recv = recv});
	end;

	netstream.Hook("dermaRequest_stringQuery", function(data)
		Derma_StringRequest(data.title, data.question, data.default, function(recv)
			CW.dermaRequest:Send(data.id, recv);
		end);
	end);

	netstream.Hook("dermaRequest_confirmQuery", function(data)
		Derma_Query(data.question, data.title, 
			"#DermaRequest_confirmQuery_Confirm", function() CW.dermaRequest:Send(data.id, true) end,
			"#DermaRequest_confirmQuery_Cancel", function() CW.dermaRequest:Send(data.id, false); end);
	end);

	netstream.Hook("dermaRequest_message", function(data)
		local title = data.title or nil;
		local button = data.button or nil;
		Derma_Message(data.message, data.title, data.button);
	end);

end