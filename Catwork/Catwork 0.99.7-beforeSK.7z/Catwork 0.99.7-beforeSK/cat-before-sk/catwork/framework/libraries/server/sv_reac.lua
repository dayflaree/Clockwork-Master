--[[
	� 2016 TeslaCloud Studios.
	Do not use, edit, distribute or sell this
	code outside of RePlayGame Community or
	TeslaCloud Studios LLC.
--]]

library.New("catAC", _G);

local reason = "Banned by anti-cheat from secure server!";

netstream.Hook("catAC.BadConvar", function(player, name, cvarlist)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has attempted to create a bad console variable! ("..name.." - "..cvarlist..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.BadKeyword", function(player, name, keyword)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has attempted to create a console variable with a bad keyword in it! ("..name.." - "..keyword..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.BadG", function(player, name)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has a bad variable in _G table! ("..name..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.BadR", function(player, name)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has a bad variable in _R table! ("..name..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.BadHook", function(player, name, keyword)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has attempted to create a console variable with a bad keyword in it! ("..name.." - "..keyword..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.CvarMismatch", function(player, name, cvarVal)
	if (cvars.Number(name) == cvarVal) then
		return;
	end;

	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has a console variable mismatch! ("..name..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

netstream.Hook("catAC.BadPrefix", function(player, name, prefix)
	MsgC(Color(255, 255, 0), player:Name().." ("..player:SteamID()..") has attempted to create a console variable with a bad prefix! ("..name.." - "..prefix..")\n");
	//player:Kick(reason);
	CW.player:NotifyAll(player:Name().." ("..player:SteamID()..") is a cheater!");
end);

catAC.AcCode = [[
local vars = {
	{"sv_cheats", 0},
	{"sv_allowcslua", 0},
	{"mat_fullbright", 0}
};

local BadCvars = {
	"snixzz", "razor_aim", "bonus_sv_cheats", "bonus_sv_allowcslua", "sp00f_sv_cheats", "bs_sv_cheats", "sp00f_sv_allowcslua", "ah_sv_cheats", 
	"ah_sv_allowcslua", "ah_cheats", "ah_timescale", "dead_chams", "dead_xray", "mh_rearview", "zedhack", "boxbot", "damnbot_", "ahack_active", 
	"ahack_aimbot_active", "mapex_showadmins", "mapex_speedhack_speed", "mapex_dancin", "mapex_xray", "damnbot_esp_info", "damnbot_esp_box", 
	"damnbot_misc_bunnyhop", "damnbot_aim_aimspot", "fap_esp_radar", "fap_bunnyhopspeed", "fap_checkforupdates", "fap_aim_autoreload", "fap_aim_enabled", 
	"fap_aim_bonemode", "b-hacks_misc_bhop", "hera_esp_chams", "traffichack_aimbot_active", "traffichack_aimbot_randombones", "lenny_triggerbot", "lenny_aimsnap", 
	"lenny_wh", "dead_esp", "ok_aimbot", "ok_visuals_esp", "ok_misc_autohop", "ok_hvh_antiaim", "ok_hvh_aa_edge", "hz_crosshair"
};

local BadKeywords = {
	"hack", "cheat", "showadmins", "aimbot", "wallhack", "chams", "x_ray", "xray", "mapex", "lenny", "spiritwalk", "bypass", "decode",
	"triggerbot", "hax", "h4x", "h4cks", "hacks", "cheats", "ch34t", "ch3at", "che4t", "4it", "xak", "speedhack", "sanic", "walls", "aimassist",
	"xhair", "fap", "damnbot", "ahack", "bhack", "norecoil", "noreload", "nospread", "antiafk", "afkscript", "destroyer", "ok_visuals", "ok_aimbot",
	"ok_misc", "ok_hvh", "skidscorcher", "espbox", "ignorez", "gdaap"
};

local BadPrefixes = {
	"hz_", "ok_", "esp_", "wallhack", "mapex_", "fap_", "sp00f_", "ahack_", "ah_", "lenny_", "damnbot_", "hack_", "cheat_", "aimbot_",
	"xray_", "hera_", "razor_", "mh_", "gdaap", "gdaap_"
};

local BadG = {
	"ok", "skidscorcher"
};

local BadR = {
	"__rbackup"
}

function catAC.CheckMismatches()
	for k, v in pairs(vars) do
		if (cvars.Number(v[1]) != v[2]) then
			netstream.Start("catAC.CvarMismatch", v[1], cvars.Number(v[1]));
		end;
	end;
end;

function catAC.CheckG()
	for k, v in pairs(BadG) do
		if (_G[v]) then
			netstream.Start("catAC.BadG", v);
		end;
	end;
end;

function catAC.CheckR()
	local reg = debug.getregistry();

	for k, v in pairs(BadR) do
		if (reg[v]) then
			netstream.Start("catAC.BadR", v);
		end;
	end;
end;

function catAC.CheckHooks()
	for k, v in pairs(hook.GetTable()) do
		for k2, v2 in pairs(v) do
			for _, keyword in pairs(BadKeywords) do
				if (typeof(k2) == "string") then
					if (k2:lower():find(keyword)) then
						netstream.Start("catAC.BadHook", k2, keyword);
					end;
				end;
			end;
		end;
	end;
end;

function CW:OnConVarCreate(name, value, flags, help)
	for k, v in pairs(BadCvars) do
		if (name:lower() == v:lower()) then
			netstream.Start("catAC.BadConvar", name, v);
			return true;
		end;
	end;

	for k, v in pairs(BadKeywords) do
		if (name:lower():find(v)) then
			netstream.Start("catAC.BadKeyword", name, v);
			return true;
		end;
	end;

	for k, v in pairs(BadPrefixes) do
		if (name:lower():StartWith(v)) then
			netstream.Start("catAC.BadPrefix", name, v);
			return true;
		end;
	end;
end;

function CW:OnClientConVarCreate(name, default, shouldsave, userdata, helptext)
	for k, v in pairs(BadCvars) do
		if (name:lower() == v:lower()) then
			netstream.Start("catAC.BadConvar", name, v);
			return true;
		end;
	end;

	for k, v in pairs(BadKeywords) do
		if (name:lower():find(v)) then
			netstream.Start("catAC.BadKeyword", name, v);
			return true;
		end;
	end;

	for k, v in pairs(BadPrefixes) do
		if (name:lower():StartWith(v)) then
			netstream.Start("catAC.BadPrefix", name, v);
			return true;
		end;
	end;
end;


do
	MsgC(Color(255, 255, 100), "[catAC] ");
	MsgC(Color(255, 255, 255), "Initializing...\n");

	timer.Create("catAC.MismatchChecker", 1, 0, function()
		catAC.CheckMismatches();
		catAC.CheckG();
		catAC.CheckR();
	end);

	timer.Create("catAC.HookChecker", 5, 0, function()
		catAC.CheckHooks();
	end);

	netstream.Start("CatACInitialized", "maowlikespotatoes");
end;
]]
