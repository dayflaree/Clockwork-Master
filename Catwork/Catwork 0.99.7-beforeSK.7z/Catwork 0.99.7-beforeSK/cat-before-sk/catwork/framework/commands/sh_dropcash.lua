--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local NAME_CASH = CW.option:GetKey("name_cash");

local COMMAND = CW.command:New("DropCash");
COMMAND.tip = "Drop "..string.lower(NAME_CASH).." at your target position.";
COMMAND.text = "<number "..string.gsub(NAME_CASH, "%s", "")..">";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.alias = {"DropCash", "DropTokens"};
COMMAND.cooldown = 8;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local cash = tonumber(arguments[1]);

	if (cash and cash > 1) then
		cash = math.floor(cash);

		if (player:GetShootPos():Distance(trace.HitPos) <= 192) then
			if (CW.player:CanAfford(player, cash)) then
				CW.player:GiveCash(player, -cash, "Dropping "..CW.option:GetKey("name_cash"));

				local entity = CW.entity:CreateCash(player, cash, trace.HitPos);

				if (IsValid(entity)) then
					CW.entity:MakeFlushToGround(entity, trace.HitPos, trace.HitNormal);
				end;
			else
				local amount = cash - player:GetCash();
				CW.player:Notify(player, "You need another "..CW.kernel:FormatCash(amount, nil, true).."!");
			end;
		else
			CW.player:Notify(player, "You cannot drop "..string.lower(NAME_CASH).." that far away!");
		end;
	else
		CW.player:Notify(player, "This is not a valid amount!");
	end;
end;

COMMAND:Register();