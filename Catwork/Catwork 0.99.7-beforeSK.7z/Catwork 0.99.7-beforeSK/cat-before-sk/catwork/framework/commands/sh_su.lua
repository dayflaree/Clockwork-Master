--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("Su");
COMMAND.tip = "Send a private message to all superadmins.";
COMMAND.text = "<string Msg>";
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local listeners = {};

	for k, v in ipairs(_player.GetAll()) do
		if (v:IsSuperAdmin()) then
			listeners[#listeners + 1] = v;
		end;
	end;

	chatbox.AddText(listeners, table.concat(arguments, " "), {filter = "admin", sender = player, prefix = "* [Super Admins] "})
end;

COMMAND:Register();
