--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("CharSetModel");
COMMAND.tip = "Set a character's model permanently.";
COMMAND.text = "<string Name> <string Model>";
COMMAND.access = "M";
COMMAND.arguments = 2;
COMMAND.alias = {"SetModel"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1])

	if (target) then
		local model = table.concat(arguments, " ", 2);

		target:SetCharacterData("Model", model, true);
		target:SetModel(model);

		CW.player:NotifyAll(player:Name().." set "..target:Name().."'s model to "..model..".");
	else
		CW.player:Notify(player, L(player, "NotValidCharacter", arguments[1]));
	end;
end;

COMMAND:Register();