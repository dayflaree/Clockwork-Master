--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("PlyDemote");
COMMAND.tip = "Demote a player from their user group.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;
COMMAND.alias = {"Demote"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = CW.player:FindByID(arguments[1]);

	if (target) then
		if (!CW.player:IsProtected(target)) then
			local userGroup = target:GetClockworkUserGroup();

			if (userGroup != "user") then
				CW.player:NotifyAll(player:Name().." has demoted "..target:Name().." from "..userGroup.." to user.");
					target:SetClockworkUserGroup("user");
				CW.player:LightSpawn(target, true, true);
			else
				CW.player:Notify(player, "This player is only a user and cannot be demoted!");
			end;
		else
			CW.player:Notify(player, target:Name().." is protected!");
		end;
	else
		CW.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();