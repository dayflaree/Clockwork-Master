--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

config.Add("stam_regen_scale", 0.1, true);
config.Add("stam_drain_scale", 0.2, true);
config.Add("breathing_volume", 1, true);
