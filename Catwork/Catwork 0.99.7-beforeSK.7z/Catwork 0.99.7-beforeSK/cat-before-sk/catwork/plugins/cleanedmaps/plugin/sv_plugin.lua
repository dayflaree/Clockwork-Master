--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

config.Add("remove_map_physics", false, nil, nil, nil, nil, true);

cwCleanedMaps.entityList = {
	"item_healthcharger",
	"item_suitcharger",
	"weapon_*"
};