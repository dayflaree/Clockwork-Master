--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

-- Called when Clockwork has loaded all of the entities.
function cwSurfaceTexts:ClockworkInitPostEntity() self:LoadSurfaceTexts(); end;

-- Called when a player's data stream info should be sent.
function cwSurfaceTexts:PlayerSendDataStreamInfo(player)
	netstream.Start(player, "SurfaceTexts", self.storedList);
end;