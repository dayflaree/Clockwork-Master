--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

Schema.voices = CW.kernel:NewLibrary("Voices");
local stored = Schema.voices.stored or {
	normalVoices = {},
	dispatchVoices = {},
	humanVoices = {}
};
Schema.voices.stored = stored;

-- A function to add a voice.
function Schema.voices:Add(faction, command, phrase, sound, female, menu)
	if (_G["cwSharedBooted"]) then return; end;

	stored.normalVoices[#stored.normalVoices + 1] = {
		command = command,
		faction = faction,
		phrase = phrase,
		female = female,
		sound = sound,
		menu = menu
	};
end;

-- A function to add a dispatch voice.
function Schema.voices:AddDispatch(command, phrase, sound)
	if (_G["cwSharedBooted"]) then return; end;

	stored.dispatchVoices[#stored.dispatchVoices + 1] = {
		command = command,
		phrase = phrase,
		sound = sound
	};
end;

-- A function to add a citizen voice.
function Schema.voices:AddCitizen(faction, command, phrase, sound, female, menu)
	if (_G["cwSharedBooted"]) then return; end;

	stored.humanVoices[#stored.humanVoices + 1] = {
		command = command,
		faction = faction,
		phrase = phrase,
		female = female,
		sound = sound,
		menu = menu
	};
end;

if (!_G["ClockworkClientsideBooted"]) then
	Schema.voices:AddDispatch("anticitizen1", "Внимание. Неопознанное лицо. Немедленно подтвердить статус в отделе Гражданской Обороны.", "npc/overwatch/cityvoice/f_confirmcivilstatus_1_spkr.wav");
	Schema.voices:AddDispatch("anticitizen2", "Вниманию наземных сил. В сообществе найден нарушитель. Код: ОКРУЖИТЬ, КЛЕЙМИТЬ, УСМИРИТЬ.", "npc/overwatch/cityvoice/f_anticitizenreport_spkr.wav");
	Schema.voices:AddDispatch("anticitizen3", "Внимание. Уклонистское поведение. Неподчинение обвиняемого. Наземным силам ГО, тревога. Код: ИЗОЛИРОВАТЬ, ОГЛАСИТЬ, ИСПОЛНИТЬ.", "npc/overwatch/cityvoice/f_evasionbehavior_2_spkr.wav");

	Schema.voices:AddDispatch("level5", "Гражданин, теперь вы угроза обществу пятого уровня. Немедленно прекратить уклонение и выслушать приговор.", "npc/overwatch/cityvoice/f_ceaseevasionlevelfive_spkr.wav");
	Schema.voices:AddDispatch("level4", "Гражданин, вы обвиняетесь во множественных нарушениях. Гражданство отозвано. Статус: ЗЛОСТНЫЙ НАРУШИТЕЛЬ.", "npc/overwatch/cityvoice/f_citizenshiprevoked_6_spkr.wav");
	Schema.voices:AddDispatch("level3", "Гражданин, вы обвиняетесь в тяжком несоответствии. Асоциальный статус подтвержден.", "npc/overwatch/cityvoice/f_capitalmalcompliance_spkr.wav");
	Schema.voices:AddDispatch("level2", "Гражданин, вы обвиняетесь в несоответствии второго уровня и антиобщественной деятельности первого уровня. Силам ГО, обвинительный код: ДОЛГ, МЕЧ. Выполнять.", "npc/overwatch/cityvoice/f_anticivil1_5_spkr.wav");
	Schema.voices:AddDispatch("level1", "Гражданин, вы угроза обществу первого уровня. Подразделениям ГО, код пресечения: ДОЛГ, МЕЧ, ПОЛНОЧЬ.", "npc/overwatch/cityvoice/f_sociolevel1_4_spkr.wav");

	Schema.voices:AddDispatch("area1", "Вниманию гражданам. Производится проверка идентификации. Занять назначенные для инспекции места.", "npc/overwatch/cityvoice/f_trainstation_assemble_spkr.wav");
	Schema.voices:AddDispatch("area2", "Внимание. Всем гражданам жилого квартала. Занять места для инспекции.", "npc/overwatch/cityvoice/f_trainstation_assumepositions_spkr.wav");
	Schema.voices:AddDispatch("area3", "Вниманию отрядам Гражданской Обороны. Обнаружено уклонение от надзора. ОТРЕАГИРОВАТЬ, ИЗОЛИРОВАТЬ, ДОПРОСИТЬ.", "npc/overwatch/cityvoice/f_protectionresponse_1_spkr.wav");
	Schema.voices:AddDispatch("area4", "Вниманию жителей. Ваш квартал обвиняется в недоносительстве. Штраф пять пищевых единиц.", "npc/overwatch/cityvoice/f_rationunitsdeduct_3_spkr.wav");

	Schema.voices:AddDispatch("coop1", "Граждане, бездействие преступно. О противоправном поведении немедленно доложить силам ГО.", "npc/overwatch/cityvoice/f_innactionisconspiracy_spkr.wav");
	Schema.voices:AddDispatch("coop2", "Вниманию жителей. Замечено отклонение численности. Сотрудничество с отрядом ГО награждается полным пищевым рационом.", "npc/overwatch/cityvoice/f_trainstation_cooperation_spkr.wav");
	Schema.voices:AddDispatch("coop3", "Граждане, отказ в сотрудничестве будет наказан выселением в нежилое пространство.", "npc/overwatch/cityvoice/f_trainstation_offworldrelocation_spkr.wav");
	Schema.voices:AddDispatch("coop4", "Внимание. В квартале потенциальный источник вреда обществу. ДОНЕСТИ, СОДЕЙСТВОВАТЬ, СОБРАТЬ.", "npc/overwatch/cityvoice/f_trainstation_inform_spkr.wav");

	Schema.voices:AddDispatch("unrest1", "Отрядам Гражданкой Обороны. Признаки антиобщественной деятельности. Код: СОБРАТЬ, ОКРУЖИТЬ, ЗАДЕРЖАТЬ.", "npc/overwatch/cityvoice/f_anticivilevidence_3_spkr.wav");
	Schema.voices:AddDispatch("unrest2", "Тревога. Подразделениям Гражданской Обороны. Обнаружены локальные беспорядки. СОБРАТЬ, ИСПОЛНИТЬ, УСМИРИТЬ.", "npc/overwatch/cityvoice/f_localunrest_spkr.wav");
	Schema.voices:AddDispatch("unrest3", "Граждане, введен код действия при беспорядках. Код: ОБЕЗВРЕДИТЬ, ЗАЩИТИТЬ, УСМИРИТЬ. Код: ПОДАВИТЬ, МЕЧ, СТЕРИЛИЗОВАТЬ.", "npc/overwatch/cityvoice/f_unrestprocedure1_spkr.wav");
	Schema.voices:AddDispatch("unrest4", "Вниманию наземного отряда ГО. Задействовано осуждение на месте. Приговор выносить по усмотрению. Код: ОТСЕЧЬ, ОБНУЛИТЬ, ПОДТВЕРДИТЬ.", "npc/overwatch/cityvoice/f_protectionresponse_4_spkr.wav");
	Schema.voices:AddDispatch("unrest5", "Вниманию всех наземных сил. Судебное разбирательство отменено. Смертная казнь по усмотрению.", "npc/overwatch/cityvoice/f_protectionresponse_5_spkr.wav");

	Schema.voices:AddDispatch("out1", "Тревога. Обнаружена аномальная внешняя активность. Следовать процедуре сдерживания и докладывать.", "npc/overwatch/cityvoice/fprison_nonstandardexogen.wav");
	Schema.voices:AddDispatch("out2", "Внимание. Отключены системы наблюдения и обнаружения. Оставшимся сотрудникам охраны доложить о вторжении.", "npc/overwatch/cityvoice/fprison_detectionsystemsout.wav");
	Schema.voices:AddDispatch("out3", "Патруль подтверждает вторжение из вне. Вызваны вспомогательные воздушные силы. Ожидать поддержки.", "npc/overwatch/cityvoice/fprison_airwatchdispatched.wav");
	Schema.voices:AddDispatch("out4", "Особое внимание. Отключены ограничители периметра. Всем сотрудникам охраны немедленно принять участие в сдерживании.", "npc/overwatch/cityvoice/fprison_restrictorsdisengaged.wav");
	Schema.voices:AddDispatch("out5", "Директива номер два. Задействовать резерв. Сдерживать вторжение из вне.", "npc/overwatch/cityvoice/fprison_containexogens.wav");
	Schema.voices:AddDispatch("out6", "Внимание наземным силам. Провал миссии влечет выселение в нежилое пространство. Напоминаю код: ПОЖЕРТВОВАТЬ, ОСТАНОВИТЬ, УСТРАНИТЬ.", "npc/overwatch/cityvoice/fprison_missionfailurereminder.wav");


	Schema.voices:Add("Combine", "Sweeping", "Sweeping for suspect.", "npc/metropolice/hiding02.wav");
	Schema.voices:Add("Combine", "Isolate", "Isolate!", "npc/metropolice/hiding05.wav");
	Schema.voices:Add("Combine", "You Can Go", "Alright, you can go.", "npc/metropolice/vo/allrightyoucango.wav");
	Schema.voices:Add("Combine", "Need Assistance", "Eleven-ninety-nine, officer needs assistance!", "npc/metropolice/vo/11-99officerneedsassistance.wav");
	Schema.voices:Add("Combine", "Administer", "Administer.", "npc/metropolice/vo/administer.wav");
	Schema.voices:Add("Combine", "Affirmative", "Affirmative.", "npc/metropolice/vo/affirmative.wav");
	Schema.voices:Add("Combine", "All Units Move In", "All units move in!", "npc/metropolice/vo/allunitsmovein.wav");
	Schema.voices:Add("Combine", "Amputate", "Amputate.", "npc/metropolice/vo/amputate.wav");
	Schema.voices:Add("Combine", "Anti-Citizen", "Anti-citizen.", "npc/metropolice/vo/anticitizen.wav");
	Schema.voices:Add("Combine", "Citizen", "Citizen.", "npc/metropolice/vo/citizen.wav");
	Schema.voices:Add("Combine", "Copy", "Copy.", "npc/metropolice/vo/copy.wav");
	Schema.voices:Add("Combine", "Cover Me", "Cover me, I'm going in!", "npc/metropolice/vo/covermegoingin.wav");
	Schema.voices:Add("Combine", "Assist Trespass", "Assist for a criminal trespass!", "npc/metropolice/vo/criminaltrespass63.wav");
	Schema.voices:Add("Combine", "Destroy Cover", "Destroy that cover!", "npc/metropolice/vo/destroythatcover.wav");
	Schema.voices:Add("Combine", "Don't Move", "Don't move!", "npc/metropolice/vo/dontmove.wav");
	Schema.voices:Add("Combine", "Final Verdict", "Final verdict administered.", "npc/metropolice/vo/finalverdictadministered.wav");
	Schema.voices:Add("Combine", "Final Warning", "Final warning!", "npc/metropolice/vo/finalwarning.wav");
	Schema.voices:Add("Combine", "First Warning", "First warning, move away!", "npc/metropolice/vo/firstwarningmove.wav");
	Schema.voices:Add("Combine", "Get Down", "Get down!", "npc/metropolice/vo/getdown.wav");
	Schema.voices:Add("Combine", "Get Out", "Get out of here!", "npc/metropolice/vo/getoutofhere.wav");
	Schema.voices:Add("Combine", "Suspect One", "I got suspect one here.", "npc/metropolice/vo/gotsuspect1here.wav");
	Schema.voices:Add("Combine", "Help", "Help!", "npc/metropolice/vo/help.wav");
	Schema.voices:Add("Combine", "Running", "He's running!", "npc/metropolice/vo/hesrunning.wav");
	Schema.voices:Add("Combine", "Hold It", "Hold it right there!", "npc/metropolice/vo/holditrightthere.wav");
	Schema.voices:Add("Combine", "Move Along Repeat", "I said move along.", "npc/metropolice/vo/isaidmovealong.wav");
	Schema.voices:Add("Combine", "Malcompliance", "Issuing malcompliance citation.", "npc/metropolice/vo/issuingmalcompliantcitation.wav");
	Schema.voices:Add("Combine", "Keep Moving", "Keep moving!", "npc/metropolice/vo/keepmoving.wav");
	Schema.voices:Add("Combine", "Lock Position", "All units, lock your position!", "npc/metropolice/vo/lockyourposition.wav");
	Schema.voices:Add("Combine", "Trouble", "Lookin' for trouble?", "npc/metropolice/vo/lookingfortrouble.wav");
	Schema.voices:Add("Combine", "Look Out", "Look out!", "npc/metropolice/vo/lookout.wav");
	Schema.voices:Add("Combine", "Minor Hits", "Minor hits, continuing prosecution.", "npc/metropolice/vo/minorhitscontinuing.wav");
	Schema.voices:Add("Combine", "Move", "Move!", "npc/metropolice/vo/move.wav");
	Schema.voices:Add("Combine", "Move Along", "Move along!", "npc/metropolice/vo/movealong3.wav");
	Schema.voices:Add("Combine", "Move Back", "Move back, right now!", "npc/metropolice/vo/movebackrightnow.wav");
	Schema.voices:Add("Combine", "Move It", "Move it!", "npc/metropolice/vo/moveit2.wav");
	Schema.voices:Add("Combine", "Hardpoint", "Moving to hardpoint.", "npc/metropolice/vo/movingtohardpoint.wav");
	Schema.voices:Add("Combine", "Officer Help", "Officer needs help!", "npc/metropolice/vo/officerneedshelp.wav");
	Schema.voices:Add("Combine", "Privacy", "Possible level three civil privacy violator here!", "npc/metropolice/vo/possiblelevel3civilprivacyviolator.wav");
	Schema.voices:Add("Combine", "Judgement", "Suspect prepare to receive civil judgement!", "npc/metropolice/vo/prepareforjudgement.wav");
	Schema.voices:Add("Combine", "Priority Two", "I have a priority two anti-citizen here!", "npc/metropolice/vo/priority2anticitizenhere.wav");
	Schema.voices:Add("Combine", "Prosecute", "Prosecute!", "npc/metropolice/vo/prosecute.wav");
	Schema.voices:Add("Combine", "Amputate Ready", "Ready to amputate!", "npc/metropolice/vo/readytoamputate.wav");
	Schema.voices:Add("Combine", "Rodger That", "Rodger that!", "npc/metropolice/vo/rodgerthat.wav");
	Schema.voices:Add("Combine", "Search", "Search!", "npc/metropolice/vo/search.wav");
	Schema.voices:Add("Combine", "Shit", "Shit!", "npc/metropolice/vo/shit.wav");
	Schema.voices:Add("Combine", "Sentence Delivered", "Sentence delivered.", "npc/metropolice/vo/sentencedelivered.wav");
	Schema.voices:Add("Combine", "Sterilize", "Sterilize!", "npc/metropolice/vo/sterilize.wav");
	Schema.voices:Add("Combine", "Take Cover", "Take cover!", "npc/metropolice/vo/takecover.wav");
	Schema.voices:Add("Combine", "Restrict", "Restrict!", "npc/metropolice/vo/restrict.wav");
	Schema.voices:Add("Combine", "Restricted", "Restricted block.", "npc/metropolice/vo/restrictedblock.wav");
	Schema.voices:Add("Combine", "Second Warning", "This is your second warning!", "npc/metropolice/vo/thisisyoursecondwarning.wav");
	Schema.voices:Add("Combine", "Verdict", "You want a non-compliance verdict?", "npc/metropolice/vo/youwantamalcomplianceverdict.wav");
	Schema.voices:Add("Combine", "Backup", "Backup!", "npc/metropolice/vo/backup.wav");
	Schema.voices:Add("Combine", "Apply", "Apply.", "npc/metropolice/vo/apply.wav");
	Schema.voices:Add("Combine", "Restriction", "Terminal restriction zone.", "npc/metropolice/vo/terminalrestrictionzone.wav");
	Schema.voices:Add("Combine", "Complete", "Protection complete.", "npc/metropolice/vo/protectioncomplete.wav");
	Schema.voices:Add("Combine", "Location Unknown", "Suspect location unknown.", "npc/metropolice/vo/suspectlocationunknown.wav");
	Schema.voices:Add("Combine", "Can 1", "Pick up that can.", "npc/metropolice/vo/pickupthecan1.wav");
	Schema.voices:Add("Combine", "Can 2", "Pick... up... the can.", "npc/metropolice/vo/pickupthecan2.wav");
	Schema.voices:Add("Combine", "Wrap It", "That's it, wrap it up.", "npc/combine_soldier/vo/thatsitwrapitup.wav");
	Schema.voices:Add("Combine", "Can 3", "I said pickup the can!", "npc/metropolice/vo/pickupthecan3.wav");
	Schema.voices:Add("Combine", "Can 4", "Now, put it in the trash can.", "npc/metropolice/vo/putitinthetrash1.wav");
	Schema.voices:Add("Combine", "Can 5", "I said put it in the trash can!", "npc/metropolice/vo/putitinthetrash2.wav");
	Schema.voices:Add("Combine", "Now Get Out", "Now get out of here!", "npc/metropolice/vo/nowgetoutofhere.wav");
	Schema.voices:Add("Combine", "Haha", "Haha.", "npc/metropolice/vo/chuckle.wav");
	Schema.voices:Add("Combine", "X-Ray", "X-Ray!", "npc/metropolice/vo/xray.wav");
	Schema.voices:Add("Combine", "Patrol", "Patrol!", "npc/metropolice/vo/patrol.wav");
	Schema.voices:Add("Combine", "Serve", "Serve.", "npc/metropolice/vo/serve.wav");
	Schema.voices:Add("Combine", "Knocked Over", "You knocked it over, pick it up!", "npc/metropolice/vo/youknockeditover.wav");
	Schema.voices:Add("Combine", "Watch It", "Watch it!", "npc/metropolice/vo/watchit.wav");
	Schema.voices:Add("Combine", "Restricted Canals", "Suspect is using restricted canals at...", "npc/metropolice/vo/suspectusingrestrictedcanals.wav");
	Schema.voices:Add("Combine", "505", "Subject is five-oh-five!", "npc/metropolice/vo/subjectis505.wav");
	Schema.voices:Add("Combine", "404", "Possible four-zero-oh here!", "npc/metropolice/vo/possible404here.wav");
	Schema.voices:Add("Combine", "Vacate", "Vacate citizen!", "npc/metropolice/vo/vacatecitizen.wav");
	Schema.voices:Add("Combine", "Escapee", "Priority two escapee.", "npc/combine_soldier/vo/prioritytwoescapee.wav");
	Schema.voices:Add("Combine", "Objective", "Priority one objective.", "npc/combine_soldier/vo/priority1objective.wav");
	Schema.voices:Add("Combine", "Payback", "Payback.", "npc/combine_soldier/vo/payback.wav");
	Schema.voices:Add("Combine", "Got Him Now", "Affirmative, we got him now.", "npc/combine_soldier/vo/affirmativewegothimnow.wav");
	Schema.voices:Add("Combine", "Antiseptic", "Antiseptic.", "npc/combine_soldier/vo/antiseptic.wav");
	Schema.voices:Add("Combine", "Cleaned", "Cleaned.", "npc/combine_soldier/vo/cleaned.wav");
	Schema.voices:Add("Combine", "Engaged Cleanup", "Engaged in cleanup.", "npc/combine_soldier/vo/engagedincleanup.wav");
	Schema.voices:Add("Combine", "Engaging", "Engaging.", "npc/combine_soldier/vo/engaging.wav");
	Schema.voices:Add("Combine", "Full Response", "Executing full response.", "npc/combine_soldier/vo/executingfullresponse.wav");
	Schema.voices:Add("Combine", "Heavy Resistance", "Overwatch advise, we have heavy resistance.", "npc/combine_soldier/vo/heavyresistance.wav");
	Schema.voices:Add("Combine", "Inbound", "Inbound.", "npc/combine_soldier/vo/inbound.wav");
	Schema.voices:Add("Combine", "Lost Contact", "Lost contact!", "npc/combine_soldier/vo/lostcontact.wav");
	Schema.voices:Add("Combine", "Move In", "Move in!", "npc/combine_soldier/vo/movein.wav");
	Schema.voices:Add("Combine", "Harden Position", "Harden that position!", "npc/combine_soldier/vo/hardenthatposition.wav");
	Schema.voices:Add("Combine", "Go Sharp", "Go sharp, go sharp!", "npc/combine_soldier/vo/gosharpgosharp.wav");
	Schema.voices:Add("Combine", "Delivered", "Delivered.", "npc/combine_soldier/vo/delivered.wav");
	Schema.voices:Add("Combine", "Necrotics Inbound", "Necrotics, inbound!", "npc/combine_soldier/vo/necroticsinbound.wav");
	Schema.voices:Add("Combine", "Necrotics", "Necrotics.", "npc/combine_soldier/vo/necrotics.wav");
	Schema.voices:Add("Combine", "Outbreak", "Outbreak!", "npc/combine_soldier/vo/outbreak.wav");
	Schema.voices:Add("Combine", "Copy That", "Copy that.", "npc/combine_soldier/vo/copythat.wav");
	Schema.voices:Add("Combine", "Outbreak Status", "Outbreak status is code.", "npc/combine_soldier/vo/outbreakstatusiscode.wav");
	Schema.voices:Add("Combine", "Overwatch", "Overwatch!", "npc/combine_soldier/vo/overwatch.wav");
	Schema.voices:Add("Combine", "Preserve", "Preserve!", "npc/metropolice/vo/preserve.wav");
	Schema.voices:Add("Combine", "Pressure", "Pressure!", "npc/metropolice/vo/pressure.wav");
	Schema.voices:Add("Combine", "Phantom", "Phantom!", "npc/combine_soldier/vo/phantom.wav");
	Schema.voices:Add("Combine", "Stinger", "Stinger!", "npc/combine_soldier/vo/stinger.wav");
	Schema.voices:Add("Combine", "Shadow", "Shadow!", "npc/combine_soldier/vo/shadow.wav");
	Schema.voices:Add("Combine", "Savage", "Savage!", "npc/combine_soldier/vo/savage.wav");
	Schema.voices:Add("Combine", "Reaper", "Reaper!", "npc/combine_soldier/vo/reaper.wav");
	Schema.voices:Add("Combine", "Victor", "Victor!", "npc/metropolice/vo/victor.wav");
	Schema.voices:Add("Combine", "Sector", "Sector!", "npc/metropolice/vo/sector.wav");
	Schema.voices:Add("Combine", "Inject", "Inject!", "npc/metropolice/vo/inject.wav");
	Schema.voices:Add("Combine", "Dagger", "Dagger!", "npc/combine_soldier/vo/dagger.wav");
	Schema.voices:Add("Combine", "Blade", "Blade!", "npc/combine_soldier/vo/blade.wav");
	Schema.voices:Add("Combine", "Razor", "Razor!", "npc/combine_soldier/vo/razor.wav");
	Schema.voices:Add("Combine", "Nomad", "Nomad!", "npc/combine_soldier/vo/nomad.wav");
	Schema.voices:Add("Combine", "Judge", "Judge!", "npc/combine_soldier/vo/judge.wav");
	Schema.voices:Add("Combine", "Ghost", "Ghost!", "npc/combine_soldier/vo/ghost.wav");
	Schema.voices:Add("Combine", "Sword", "Sword!", "npc/combine_soldier/vo/sword.wav");
	Schema.voices:Add("Combine", "Union", "Union!", "npc/metropolice/vo/union.wav");
	Schema.voices:Add("Combine", "Helix", "Helix!", "npc/combine_soldier/vo/helix.wav");
	Schema.voices:Add("Combine", "Storm", "Storm!", "npc/combine_soldier/vo/storm.wav");
	Schema.voices:Add("Combine", "Spear", "Spear!", "npc/combine_soldier/vo/spear.wav");
	Schema.voices:Add("Combine", "Vamp", "Vamp!", "npc/combine_soldier/vo/vamp.wav");
	Schema.voices:Add("Combine", "Nova", "Nova!", "npc/combine_soldier/vo/nova.wav");
	Schema.voices:Add("Combine", "Mace", "Mace!", "npc/combine_soldier/vo/mace.wav");
	Schema.voices:Add("Combine", "Grid", "Grid!", "npc/combine_soldier/vo/grid.wav");
	Schema.voices:Add("Combine", "Kilo", "Kilo!", "npc/combine_soldier/vo/kilo.wav");
	Schema.voices:Add("Combine", "Echo", "Echo!", "npc/combine_soldier/vo/echo.wav");
	Schema.voices:Add("Combine", "Dash", "Dash!", "npc/combine_soldier/vo/dash.wav");
	Schema.voices:Add("Combine", "Apex", "Apex!", "npc/combine_soldier/vo/apex.wav");
	Schema.voices:Add("Combine", "Jury", "Jury!", "npc/metropolice/vo/jury.wav");
	Schema.voices:Add("Combine", "King", "King!", "npc/metropolice/vo/king.wav");
	Schema.voices:Add("Combine", "Lock", "Lock!", "npc/metropolice/vo/lock.wav");
	Schema.voices:Add("Combine", "Vice", "Vice!", "npc/metropolice/vo/vice.wav");
	Schema.voices:Add("Combine", "Zero", "Zero!", "npc/metropolice/vo/zero.wav");
	Schema.voices:Add("Combine", "Zone", "Zone!", "npc/metropolice/vo/zone.wav");

	-- Human = working voices
	Schema.voices:AddCitizen("Human", "You all over", "That's you all over.", "vo/npc/male01/answer01.wav", "vo/npc/female01/answer01.wav");
	Schema.voices:AddCitizen("Human", "Hold it against you", "I won't hold it against you.", "vo/npc/male01/answer02.wav", "vo/npc/female01/answer02.wav");
	Schema.voices:AddCitizen("Human", "Figures", "Figures.", "vo/npc/male01/answer03.wav", "vo/npc/female01/answer03.wav");
	Schema.voices:AddCitizen("Human", "Dwell on it", "Try not to dwell on it.", "vo/npc/male01/answer04.wav", "vo/npc/female01/answer04.wav");
	Schema.voices:AddCitizen("Human", "Talk later", "Can we talk about this later?", "vo/npc/male01/answer05.wav", "vo/npc/female01/answer05.wav");
	Schema.voices:AddCitizen("Human", "Same here", "Same here.", "vo/npc/male01/answer07.wav", "vo/npc/female01/answer07.wav");
	Schema.voices:AddCitizen("Human", "Know what you mean", "Know what you mean.", "vo/npc/male01/answer08.wav", "vo/npc/female01/answer08.wav");
	Schema.voices:AddCitizen("Human", "Talking to yourself", "Talking to yourself again.", "vo/npc/male01/answer09.wav", "vo/npc/female01/answer09.wav");
	Schema.voices:AddCitizen("Human", "Say that too loud", "I wouldn't say that too loud.", "vo/npc/male01/answer10.wav", "vo/npc/female01/answer10.wav");
	Schema.voices:AddCitizen("Human", "Tomb stone", "I'll put it on your tomb stone.", "vo/npc/male01/answer11.wav", "vo/npc/female01/answer11.wav");
	Schema.voices:AddCitizen("Human", "Thinking about", "Doesn't bare thinking about.", "vo/npc/male01/answer12.wav", "vo/npc/female01/answer12.wav");
	Schema.voices:AddCitizen("Human", "With you", "I'm with you.", "vo/npc/male01/answer13.wav", "vo/npc/female01/answer13.wav");
	Schema.voices:AddCitizen("Human", "You and me both", "You and me both.", "vo/npc/male01/answer14.wav", "vo/npc/female01/answer14.wav");
	Schema.voices:AddCitizen("Human", "looking at it", "That's one way of looking at it.", "vo/npc/male01/answer15.wav", "vo/npc/female01/answer15.wav");
	Schema.voices:AddCitizen("Human", "Original Thought", "Have you ever had an original thought?", "vo/npc/male01/answer16.wav", "vo/npc/female01/answer16.wav");
	Schema.voices:AddCitizen("Human", "Shut up", "I'm not even going to tell you to shut up.", "vo/npc/male01/answer17.wav", "vo/npc/female01/answer17.wav");
	Schema.voices:AddCitizen("Human", "Task at hand", "Let's concentrate on the task at hand.", "vo/npc/male01/answer18.wav", "vo/npc/female01/answer18.wav");
	Schema.voices:AddCitizen("Human", "Mind on work", "Keep your mind on your work.", "vo/npc/male01/answer19.wav", "vo/npc/female01/answer19.wav");
	Schema.voices:AddCitizen("Human", "Mind in gutter", "Your mind is in the gutter.", "vo/npc/male01/answer20.wav", "vo/npc/female01/answer20.wav");
	Schema.voices:AddCitizen("Human", "Sure of that", "Don't be so sure of that.", "vo/npc/male01/answer21.wav", "vo/npc/female01/answer21.wav");
	Schema.voices:AddCitizen("Human", "Never know", "You never know.", "vo/npc/male01/answer22.wav", "vo/npc/female01/answer22.wav");
	Schema.voices:AddCitizen("Human", "Never can tell", "Never can tell.", "vo/npc/male01/answer23.wav", "vo/npc/female01/answer23.wav");
	Schema.voices:AddCitizen("Human", "Why telling me", "Why are you telling me?", "vo/npc/male01/answer24.wav", "vo/npc/female01/answer24.wav");
	Schema.voices:AddCitizen("Human", "How about that", "How about that.", "vo/npc/male01/answer25.wav", "vo/npc/female01/answer25.wav");
	Schema.voices:AddCitizen("Human", "More information", "That's more information than I require.", "vo/npc/male01/answer26.wav", "vo/npc/female01/answer26.wav");
	Schema.voices:AddCitizen("Human", "Wannna bet", "Wanna bet?", "vo/npc/male01/answer27.wav", "vo/npc/female01/answer27.wav");
	Schema.voices:AddCitizen("Human", "A dime", "I wish I had a dime for everytime somebody said that.", "vo/npc/male01/answer28.wav", "vo/npc/female01/answer28.wav");
	Schema.voices:AddCitizen("Human", "Do about it", "What am I supposed to do about it?", "vo/npc/male01/answer29.wav", "vo/npc/female01/answer29.wav");
	Schema.voices:AddCitizen("Human", "Talking to me", "You talking to me?", "vo/npc/male01/answer30.wav", "vo/npc/female01/answer30.wav");
	Schema.voices:AddCitizen("Human", "Nip that talk", "You should nip that kind of talk in the bud.", "vo/npc/male01/answer31.wav", "vo/npc/female01/answer31.wav");
	Schema.voices:AddCitizen("Human", "Right on", "Right on.", "vo/npc/male01/answer32.wav", "vo/npc/female01/answer32.wav");
	Schema.voices:AddCitizen("Human", "No argument", "No argument there.", "vo/npc/male01/answer33.wav", "vo/npc/female01/answer33.wav");
	Schema.voices:AddCitizen("Human", "Hawaii", "Don't forget hawaii.", "vo/npc/male01/answer34.wav", "vo/npc/female01/answer34.wav");
	Schema.voices:AddCitizen("Human", "Let it get to you", "Try not to let it get to you.", "vo/npc/male01/answer35.wav", "vo/npc/female01/answer36.wav");
	Schema.voices:AddCitizen("Human", "First time", "Wouldn't be the first time.", "vo/npc/male01/answer36.wav", "vo/npc/female01/answer37.wav");
	Schema.voices:AddCitizen("Human", "Sure about that", "You sure about that?", "vo/npc/male01/answer37.wav", "vo/npc/female01/answer38.wav");
	Schema.voices:AddCitizen("Human", "Leave it alone", "Leave it alone.", "vo/npc/male01/answer38.wav", "vo/npc/female01/answer39.wav");
	Schema.voices:AddCitizen("Human", "Enough out of you", "That's enough out of you.", "vo/npc/male01/answer39.wav", "vo/npc/female01/answer40.wav");
	Schema.voices:AddCitizen("Human", "Talking to me", "You talking to me?", "vo/npc/male01/answer30.wav", "vo/npc/female01/answer30.wav");
	Schema.voices:AddCitizen("Human", "Remember anything", "I can't remember the last time I had, well... Anything.", "vo/npc/male01/question31.wav", "vo/npc/female01/answer35.wav");
	Schema.voices:AddCitizen("Human", "Wars gonna end", "I don't think this wars ever gonna end.", "vo/npc/male01/question01.wav", "vo/npc/female01/question01.wav");
	Schema.voices:AddCitizen("Human", "Sell insurance", "To think, all I used to wanna do is sell insurance.", "vo/npc/male01/question02.wav", "vo/npc/female01/question02.wav");
	Schema.voices:AddCitizen("Human", "Dream anymore", "I don't dream anymore.", "vo/npc/male01/question03.wav", "vo/npc/female01/question03.wav");
	Schema.voices:AddCitizen("Human", "All over kidding", "When this is all over I'm... Ah who am I kidding.", "vo/npc/male01/question04.wav", "vo/npc/female01/question04.wav");
	Schema.voices:AddCitizen("Human", "Deja vu", "Woah, Deja vu.", "vo/npc/male01/question05.wav", "vo/npc/female01/question05.wav");
	Schema.voices:AddCitizen("Human", "Dream about cheese", "Sometimes, I dream about cheese.", "vo/npc/male01/question06.wav", "vo/npc/female01/question06.wav");
	Schema.voices:AddCitizen("Human", "Smell freedom", "You smell that? It's freedom.", "vo/npc/male01/question07.wav", "vo/npc/female01/question07.wav");
	Schema.voices:AddCitizen("Human", "Hands on doctor breen", "If I ever get my hands on Doctor Breen.", "vo/npc/male01/question08.wav", "vo/npc/female01/question08.wav");
	Schema.voices:AddCitizen("Human", "Eat a horse", "I could eat a horse, hooves and all.", "vo/npc/male01/question09.wav", "vo/npc/female01/question09.wav");
	Schema.voices:AddCitizen("Human", "Day finally come", "I can't believe this day has finally come.", "vo/npc/male01/question10.wav", "vo/npc/female01/question10.wav");
	Schema.voices:AddCitizen("Human", "Not part of plan", "I'm pretty sure this isn't part of the plan.", "vo/npc/male01/question11.wav", "vo/npc/female01/question11.wav");
	Schema.voices:AddCitizen("Human", "Getting worse", "Looks to me things are getting worse, not better.", "vo/npc/male01/question12.wav", "vo/npc/female01/question12.wav");
	Schema.voices:AddCitizen("Human", "Live my life over", "If I could live my life over again.", "vo/npc/male01/question13.wav", "vo/npc/female01/question13.wav");
	Schema.voices:AddCitizen("Human", "Reminds me of", "I'm not even going to tell you what that reminds me of.", "vo/npc/male01/question14.wav", "vo/npc/female01/question14.wav");
	Schema.voices:AddCitizen("Human", "Stalker out of me", "They're never going to make a stalker out of me.", "vo/npc/male01/question15.wav", "vo/npc/female01/question15.wav");
	Schema.voices:AddCitizen("Human", "Change in air", "Finally, change is in the air.", "vo/npc/male01/question16.wav", "vo/npc/female01/question16.wav");
	Schema.voices:AddCitizen("Human", "You feel it", "You feel it? I feel it.", "vo/npc/male01/question17.wav", "vo/npc/female01/question17.wav");
	Schema.voices:AddCitizen("Human", "Dont feel anything", "I don't feel anything anymore.", "vo/npc/male01/question18.wav", "vo/npc/female01/question18.wav");
	Schema.voices:AddCitizen("Human", "Last shower", "I can't remember the last time I had a shower.", "vo/npc/male01/question19.wav", "vo/npc/female01/question19.wav");
	Schema.voices:AddCitizen("Human", "Bad memory", "Someday, this will all be a bad memory.", "vo/npc/male01/question20.wav", "vo/npc/female01/question20.wav");
	Schema.voices:AddCitizen("Human", "Betting man", "I'm not a betting man, but the odds are not good.", "vo/npc/male01/question21.wav", "vo/npc/female01/question21.wav");
	Schema.voices:AddCitizen("Human", "Care what i think", "Doesn't anyone care what I think?", "vo/npc/male01/question22.wav", "vo/npc/female01/question22.wav");
	Schema.voices:AddCitizen("Human", "Whistle tune", "I can't get this tune out of my head. *Whistling*", "vo/npc/male01/question23.wav", "vo/npc/female01/question23.wav");
	Schema.voices:AddCitizen("Human", "One of those days", "I just knew it was going to be one of those days.", "vo/npc/male01/question25.wav", "vo/npc/female01/question25.wav");
	Schema.voices:AddCitizen("Human", "Bullshit", "This is bullshit!", "vo/npc/male01/question26.wav", "vo/npc/female01/question26.wav");
	Schema.voices:AddCitizen("Human", "Ate something bad", "I think I ate something bad.", "vo/npc/male01/question27.wav", "vo/npc/female01/question27.wav");
	Schema.voices:AddCitizen("Human", "Im hungry", "God I'm hungry.", "vo/npc/male01/question28.wav", "vo/npc/female01/question28.wav");
	Schema.voices:AddCitizen("Human", "Gonna mate", "When this is all over, I'm gonna mate.", "vo/npc/male01/question29.wav", "vo/npc/female01/question29.wav");
	Schema.voices:AddCitizen("Human", "No kids", "I'm glad there's no kids around to see this.", "vo/npc/male01/question30.wav", "vo/npc/female01/question30.wav");
	Schema.voices:AddCitizen("Human", "Behind you", "Behind you!", "vo/npc/male01/behindyou01.wav", "vo/npc/female01/behindyou01.wav");
	Schema.voices:AddCitizen("Human", "Im busy", "Can't you see I'm busy?", "vo/npc/male01/busy02.wav", "vo/npc/female01/busy02.wav");
	Schema.voices:AddCitizen("Human", "Look out below", "Look out below!", "vo/npc/male01/cit_dropper04.wav", "vo/npc/female01/cit_dropper04.wav");
	Schema.voices:AddCitizen("Human", "Civil protection", "Civil protection!", "vo/npc/male01/civilprotection01.wav", "vo/npc/female01/civilprotection01.wav");
	Schema.voices:AddCitizen("Human", "Combine", "Combine!", "vo/npc/male01/combine01.wav", "vo/npc/female01/combine01.wav");
	Schema.voices:AddCitizen("Human", "Cps", "Cps!", "vo/npc/male01/cps01.wav", "vo/npc/female01/cps01.wav");
	Schema.voices:AddCitizen("Human", "Cover reload", "Cover me while I reload.", "vo/npc/male01/coverwhilereload01.wav", "vo/npc/female01/coverwhilereload01.wav");
	Schema.voices:AddCitizen("Human", "Doing something", "Shouldn't we be doing something?", "vo/npc/male01/doingsomething.wav", "vo/npc/female01/doingsomething.wav");
	Schema.voices:AddCitizen("Human", "Excuse me", "Excuse me.", "vo/npc/male01/excuseme01.wav", "vo/npc/female01/excuseme01.wav");
	Schema.voices:AddCitizen("Human", "Fantastic", "Fantastic!", "vo/npc/male01/fantastic01.wav", "vo/npc/female01/fantastic01.wav");
	Schema.voices:AddCitizen("Human", "Finally", "Finally.", "vo/npc/male01/finally.wav", "vo/npc/female01/finally.wav");
	Schema.voices:AddCitizen("Human", "Get down", "Get down!", "vo/npc/male01/getdown02.wav", "vo/npc/female01/getdown02.wav");
	Schema.voices:AddCitizen("Human", "Get going soon", "Are we gonna get going soon?", "vo/npc/male01/getgoingsoon.wav", "vo/npc/female01/getgoingsoon.wav");
	Schema.voices:AddCitizen("Human", "Get the hell out", "Get the hell out of here!", "vo/npc/male01/gethellout.wav", "vo/npc/female01/gethellout.wav");
	Schema.voices:AddCitizen("Human", "Good god", "Good god.", "vo/npc/male01/goodgod.wav", "vo/npc/female01/goodgod.wav");
	Schema.voices:AddCitizen("Human", "Now what", "Now what.", "vo/npc/male01/gordead_ans01.wav", "vo/npc/female01/gordead_ans01.wav");
	Schema.voices:AddCitizen("Human", "Going so well", "And things were going so well.", "vo/npc/male01/gordead_ans02.wav", "vo/npc/female01/gordead_ans02.wav");
	Schema.voices:AddCitizen("Human", "Dont tell me", "Don't tell me.", "vo/npc/male01/gordead_ans03.wav", "vo/npc/female01/gordead_ans03.wav");
	Schema.voices:AddCitizen("Human", "Oh god", "Oh god.", "vo/npc/male01/gordead_ans04.wav", "vo/npc/female01/gordead_ans04.wav");
	Schema.voices:AddCitizen("Human", "Oh no", "Oh no.", "vo/npc/male01/gordead_ans05.wav", "vo/npc/female01/gordead_ans05.wav");
	Schema.voices:AddCitizen("Human", "Please no", "Please no!", "vo/npc/male01/gordead_ans06.wav", "vo/npc/female01/gordead_ans06.wav");
	Schema.voices:AddCitizen("Human", "Thats gotta hurt", "If you dare say... that's gotta hurt, I'll kill you.", "vo/npc/male01/gordead_ans07.wav", "vo/npc/female01/gordead_ans07.wav");
	Schema.voices:AddCitizen("Human", "Bury him here", "Should we bury him here?", "vo/npc/male01/gordead_ans08.wav", "vo/npc/female01/gordead_ans08.wav");
	Schema.voices:AddCitizen("Human", "Even he could not help", "I had a feeling even he couldn't help us.", "vo/npc/male01/gordead_ans09.wav", "vo/npc/female01/gordead_ans09.wav");
	Schema.voices:AddCitizen("Human", "Spread the word", "Spread the word.", "vo/npc/male01/gordead_ans10.wav", "vo/npc/female01/gordead_ans10.wav");
	Schema.voices:AddCitizen("Human", "What is the use", "What's the use?", "vo/npc/male01/gordead_ans11.wav", "vo/npc/female01/gordead_ans11.wav");
	Schema.voices:AddCitizen("Human", "What is the point", "What's the point?", "vo/npc/male01/gordead_ans12.wav", "vo/npc/female01/gordead_ans12.wav");
	Schema.voices:AddCitizen("Human", "Why go on", "Why go on?", "vo/npc/male01/gordead_ans13.wav", "vo/npc/female01/gordead_ans13.wav");
	Schema.voices:AddCitizen("Human", "Were done for", "We're done for.", "vo/npc/male01/gordead_ans14.wav", "vo/npc/female01/gordead_ans14.wav");
	Schema.voices:AddCitizen("Human", "Well now what", "Well, now what?", "vo/npc/male01/gordead_ans15.wav", "vo/npc/female01/gordead_ans15.wav");
	Schema.voices:AddCitizen("Human", "Dibs on the suit", "Dibs on the suit!", "vo/npc/male01/gordead_ans16.wav", "vo/npc/female01/gordead_ans16.wav");
	Schema.voices:AddCitizen("Human", "Done this before", "He's done this before, he'll be okay.", "vo/npc/male01/gordead_ans18.wav", "vo/npc/female01/gordead_ans18.wav");
	Schema.voices:AddCitizen("Human", "Gonna be sick", "I'm gonna be sick.", "vo/npc/male01/gordead_ans19.wav", "vo/npc/female01/gordead_ans19.wav");
	Schema.voices:AddCitizen("Human", "Take his crowbar", "Somebody, take his crowbar.", "vo/npc/male01/gordead_ans20.wav", "vo/npc/female01/gordead_ans20.wav");
	Schema.voices:AddCitizen("Human", "Hes dead", "He's dead.", "vo/npc/male01/gordead_ques01.wav", "vo/npc/female01/gordead_ques01.wav");
	Schema.voices:AddCitizen("Human", "Way to go", "What a way to go.", "vo/npc/male01/gordead_ques02.wav", "vo/npc/female01/gordead_ques02.wav");
	Schema.voices:AddCitizen("Human", "Cant be", "This can't be.", "vo/npc/male01/gordead_ques06.wav", "vo/npc/female01/gordead_ques06.wav");
	Schema.voices:AddCitizen("Human", "Look hes dead", "Look he's dead.", "vo/npc/male01/gordead_ques07.wav", "vo/npc/female01/gordead_ques07.wav");
	Schema.voices:AddCitizen("Human", "This is bad", "This, is bad.", "vo/npc/male01/gordead_ques10.wav", "vo/npc/female01/gordead_ques10.wav");
	Schema.voices:AddCitizen("Human", "End like this", "It's not supposed to end like this.", "vo/npc/male01/gordead_ques14.wav", "vo/npc/female01/gordead_ques14.wav");
	Schema.voices:AddCitizen("Human", "What now", "What now?", "vo/npc/male01/gordead_ques16.wav", "vo/npc/female01/gordead_ques16.wav");
	Schema.voices:AddCitizen("Human", "Got one", "Got one!", "vo/npc/male01/gotone01.wav", "vo/npc/female01/gotone01.wav");
	Schema.voices:AddCitizen("Human", "Gotta reload", "Gotta reload.", "vo/npc/male01/gottareload01.wav", "vo/npc/female01/gottareload01.wav");
	Schema.voices:AddCitizen("Human", "Hacks", "Hacks!", "vo/npc/male01/hacks01.wav", "vo/npc/female01/hacks01.wav");
	Schema.voices:AddCitizen("Human", "Headcrabs", "Headcrabs!", "vo/npc/male01/headcrabs01.wav", "vo/npc/female01/headcrabs01.wav");
	Schema.voices:AddCitizen("Human", "Heads up", "Heads up!", "vo/npc/male01/headsup01.wav", "vo/npc/female01/headsup01.wav");
	Schema.voices:AddCitizen("Human", "Help", "Help!", "vo/npc/male01/help01.wav", "vo/npc/female01/help01.wav");
	Schema.voices:AddCitizen("Human", "Here come hacks", "Here come the hacks!", "vo/npc/male01/herecomehacks01.wav", "vo/npc/female01/herecomehacks01.wav");
	Schema.voices:AddCitizen("Human", "Here they come", "Here they come!", "vo/npc/male01/heretheycome01.wav", "vo/npc/female01/heretheycome01.wav");
	Schema.voices:AddCitizen("Human", "Here to help", "We thought you were here to help.", "vo/npc/male01/heretohelp01.wav", "vo/npc/female01/heretohelp01.wav");
	Schema.voices:AddCitizen("Human", "Hi", "Hi.", "vo/npc/male01/hi01.wav", "vo/npc/female01/hi01.wav");
	Schema.voices:AddCitizen("Human", "Hit in gut", "Aargh, hit in the gut.", "vo/npc/male01/hitingut01.wav", "vo/npc/female01/hitingut01.wav");
	Schema.voices:AddCitizen("Human", "Hold this spot", "I'm gonna stay here and hold down this spot.", "vo/npc/male01/holddownspot01.wav", "vo/npc/female01/holddownspot01.wav");
	Schema.voices:AddCitizen("Human", "Ill stay here", "I'll stay here", "vo/npc/male01/illstayhere01.wav", "vo/npc/female01/illstayhere01.wav");
	Schema.voices:AddCitizen("Human", "Im hurt", "Aargh, I'm hurt.", "vo/npc/male01/imhurt01.wav", "vo/npc/female01/imhurt01.wav");
	Schema.voices:AddCitizen("Human", "Sticking here", "I'm sticking here.", "vo/npc/male01/imstickinghere01.wav", "vo/npc/female01/imstickinghere01.wav");
	Schema.voices:AddCitizen("Human", "Incoming", "Incoming!", "vo/npc/male01/incoming02.wav", "vo/npc/female01/incoming02.wav");
	Schema.voices:AddCitizen("Human", "Lead the way", "You lead the way!", "vo/npc/male01/leadtheway01.wav", "vo/npc/female01/leadtheway01.wav");
	Schema.voices:AddCitizen("Human", "Lets go", "Lets go.", "vo/npc/male01/letsgo02.wav", "vo/npc/female01/letsgo02.wav");
	Schema.voices:AddCitizen("Human", "My arm", "Aargh, my arm.", "vo/npc/male01/myarm01.wav", "vo/npc/female01/myarm01.wav");
	Schema.voices:AddCitizen("Human", "My leg", "Aargh, my leg.", "vo/npc/male01/myleg01.wav", "vo/npc/female01/myleg01.wav");
	Schema.voices:AddCitizen("Human", "Nice", "Nice!", "vo/npc/male01/nice.wav", "vo/npc/female01/nice02.wav");
	Schema.voices:AddCitizen("Human", "Noooo", "Nooooo!", "vo/npc/male01/no02.wav", "vo/npc/female01/no02.wav");
	Schema.voices:AddCitizen("Human", "Man I thought", "You're not the man I thought you were.", "vo/npc/male01/notthemanithought02.wav", "vo/npc/female01/notthemanithought02.wav");
	Schema.voices:AddCitizen("Human", "Oh no", "Oh no.", "vo/npc/male01/ohno.wav", "vo/npc/female01/ohno.wav");
	Schema.voices:AddCitizen("Human", "Okay", "Okay!", "vo/npc/male01/ok01.wav", "vo/npc/female01/ok01.wav");
	Schema.voices:AddCitizen("Human", "Im ready", "Okay, I'm ready.", "vo/npc/male01/okimready01.wav", "vo/npc/female01/okimready01.wav");
	Schema.voices:AddCitizen("Human", "Get out of way", "Let me get out of your way.", "vo/npc/male01/outofyourway02.wav", "vo/npc/female01/outofyourway02.wav");
	Schema.voices:AddCitizen("Human", "Over here", "Over here!", "vo/npc/male01/overhere01.wav", "vo/npc/female01/overhere01.wav");
	Schema.voices:AddCitizen("Human", "Over there", "Over there!", "vo/npc/male01/overthere01.wav", "vo/npc/female01/overthere01.wav");
	Schema.voices:AddCitizen("Human", "Pardon me", "Pardon me.", "vo/npc/male01/pardonme02.wav", "vo/npc/female01/pardonme02.wav");
	Schema.voices:AddCitizen("Human", "Ready when you are", "Ready when you are!", "vo/npc/male01/readywhenyouare01.wav", "vo/npc/female01/readywhenyouare01.wav");
	Schema.voices:AddCitizen("Human", "Run for your life", "Run for your life!", "vo/npc/male01/runforyourlife02.wav", "vo/npc/female01/runforyourlife02.wav");
	Schema.voices:AddCitizen("Human", "Sorry", "Sorry.", "vo/npc/male01/sorry03.wav", "vo/npc/female01/sorry03.wav");
	Schema.voices:AddCitizen("Human", "Follow me", "Follow me!", "vo/npc/male01/squad_away03.wav", "vo/npc/female01/squad_away03.wav");
	Schema.voices:AddCitizen("Human", "Tale cover", "Take cover.", "vo/npc/male01/takecover02.wav", "vo/npc/female01/takecover02.wav");
	Schema.voices:AddCitizen("Human", "Do nicely", "This will do nicely.", "vo/npc/male01/thislldonicely01.wav", "vo/npc/female01/thislldonicely01.wav");
	Schema.voices:AddCitizen("Human", "Uh oh", "Uh oh!", "vo/npc/male01/uhoh.wav", "vo/npc/female01/uhoh.wav");
	Schema.voices:AddCitizen("Human", "Up there", "Up there!", "vo/npc/male01/upthere01.wav", "vo/npc/female01/upthere01.wav");
	Schema.voices:AddCitizen("Human", "Waiting for somebody", "You waiting for somebody?", "vo/npc/male01/waitingsomebody.wav", "vo/npc/female01/waitingsomebody.wav");
	Schema.voices:AddCitizen("Human", "Watch out", "Watch out!", "vo/npc/male01/watchout.wav", "vo/npc/female01/watchout.wav");
	Schema.voices:AddCitizen("Human", "Watch what doing", "Watch what you're doing!", "vo/npc/male01/watchwhat.wav", "vo/npc/female01/watchwhat.wav");
	Schema.voices:AddCitizen("Human", "We trusted you", "We trusted you!", "vo/npc/male01/wetrustedyou01.wav", "vo/npc/female01/wetrustedyou01.wav");
	Schema.voices:AddCitizen("Human", "Woops", "Woops.", "vo/npc/male01/whoops01.wav", "vo/npc/female01/whoops01.wav");
	Schema.voices:AddCitizen("Human", "Yeah", "Yeah.", "vo/npc/male01/yeah02.wav", "vo/npc/female01/yeah02.wav");
	Schema.voices:AddCitizen("Human", "You reload", "You'd better reload.", "vo/npc/male01/youdbetterreload01.wav", "vo/npc/female01/youdbetterreload01.wav");
	Schema.voices:AddCitizen("Human", "You got it", "You got it.", "vo/npc/male01/yougotit02.wav", "vo/npc/female01/yougotit02.wav");
	Schema.voices:AddCitizen("Human", "Zombies", "Zombies!", "vo/npc/male01/zombies01.wav", "vo/npc/female01/zombies01.wav");
	Schema.voices:AddCitizen("Human", "Woops", "Woops.", "vo/npc/male01/whoops01.wav", "vo/npc/female01/whoops01.wav");
	Schema.voices:AddCitizen("Human", "Mumbo jumbo", "Enough of your mumbo jumbo.", "vo/npc/male01/vanswer01.wav", "vo/npc/female01/vanswer01.wav");
	Schema.voices:AddCitizen("Human", "Damn vorts", "Damn vorts.", "vo/npc/male01/vanswer02.wav", "vo/npc/female01/vanswer02.wav");
	Schema.voices:AddCitizen("Human", "How to take that", "I'm not sure how to take that.", "vo/npc/male01/vanswer03.wav", "vo/npc/female01/vanswer03.wav");
	Schema.voices:AddCitizen("Human", "Take that personally", "Should I take that personally?", "vo/npc/male01/vanswer04.wav", "vo/npc/female01/vanswer04.wav");
	Schema.voices:AddCitizen("Human", "Speak english", "Speak english.", "vo/npc/male01/vanswer05.wav", "vo/npc/female01/vanswer05.wav");
	Schema.voices:AddCitizen("Human", "Got that from me", "You got that from me!", "vo/npc/male01/vanswer06.wav", "vo/npc/female01/vanswer06.wav");
	Schema.voices:AddCitizen("Human", "Put up with you", "That's why we put up with you.", "vo/npc/male01/vanswer07.wav", "vo/npc/female01/vanswer07.wav");
	Schema.voices:AddCitizen("Human", "Put it better myself", "Couldn't have put it better myself.", "vo/npc/male01/vanswer08.wav", "vo/npc/female01/vanswer08.wav");
	Schema.voices:AddCitizen("Human", "Almost made sense", "That, almost made sense.", "vo/npc/male01/vanswer09.wav", "vo/npc/female01/vanswer09.wav");
	Schema.voices:AddCitizen("Human", "Something wrong with me", "Something must be wrong with me, I almost understood that.", "vo/npc/male01/vanswer10.wav", "vo/npc/female01/vanswer10.wav");
	Schema.voices:AddCitizen("Human", "Getting used to vorts", "I guess I'm getting used to you vorts.", "vo/npc/male01/vanswer11.wav", "vo/npc/female01/vanswer11.wav");
	Schema.voices:AddCitizen("Human", "Vort philosophy", "None of your vort philosophy.", "vo/npc/male01/vanswer12.wav", "vo/npc/female01/vanswer12.wav");
	Schema.voices:AddCitizen("Human", "Stop killing me", "Stop you're killing me.", "vo/npc/male01/vanswer13.wav", "vo/npc/female01/vanswer13.wav");
	Schema.voices:AddCitizen("Human", "Do to deserve this", "What did I do to deserve this.", "vo/npc/male01/vanswer14.wav", "vo/npc/female01/vanswer14.wav");
	Schema.voices:AddCitizen("Human", "Stop looking at me", "Stop looking at me like that.", "vo/npc/male01/vquestion01.wav", "vo/npc/female01/vquestion01.wav");
	Schema.voices:AddCitizen("Human", "Never get used to", "Some things I just never get used to.", "vo/npc/male01/vquestion02.wav", "vo/npc/female01/vquestion02.wav");
	Schema.voices:AddCitizen("Human", "Survived this long", "I don't know how you things have survived as long as you have.", "vo/npc/male01/vquestion03.wav", "vo/npc/female01/vquestion03.wav");
	Schema.voices:AddCitizen("Human", "Ended up with you", "Sometimes I wonder how I ended up with you.", "vo/npc/male01/vquestion04.wav", "vo/npc/female01/vquestion04.wav");
	Schema.voices:AddCitizen("Human", "Alright vorty", "You're alright vorty.", "vo/npc/male01/vquestion05.wav", "vo/npc/female01/vquestion05.wav");
	Schema.voices:AddCitizen("Human", "Vorts half bad", "You vorts aren't half bad.", "vo/npc/male01/vquestion06.wav", "vo/npc/female01/vquestion06.wav");
	Schema.voices:AddCitizen("Human", "Pals with vort", "If anyone ever told me I'd be pals with a vortigaunt.", "vo/npc/male01/vquestion07.wav", "vo/npc/female01/vquestion07.wav");

	if (CLIENT) then
		table.sort(Schema.voices.stored.normalVoices, function(a, b) return a.command < b.command; end);
		table.sort(Schema.voices.stored.dispatchVoices, function(a, b) return a.command < b.command; end);

		for k, v in pairs(Schema.voices.stored.dispatchVoices) do
			CW.directory:AddCode("#Directory_CombineDispatch", [[
				<div class="auraInfoTitle">]]..string.upper(v.command)..[[</div>
				<div class="auraInfoText">]]..v.phrase..[[</div>
			]], true);
		end;

		for k, v in pairs(Schema.voices.stored.normalVoices) do
			CW.directory:AddCode("#Directory_CP", [[
				<div class="auraInfoTitle">]]..string.upper(v.command)..[[</div>
				<div class="auraInfoText">]]..v.phrase..[[</div>
			]], true);
		end;

		for k, v in pairs(Schema.voices.stored.humanVoices) do
			CW.directory:AddCode("#Directory_Human", [[
				<div class="auraInfoTitle">]]..string.upper(v.command)..[[</div>
				<div class="auraInfoText">]]..v.phrase..[[</div>
			]], true);
		end;
	end;
end;