--[[ 
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = CW.command:New("AddLP");
COMMAND.tip = "Add Loyalty Points to character's data.";
COMMAND.text = "<string Player> <number Amount>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 2;
COMMAND.alias = {"AddLoyaltyPoints"};

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local isAdmin = (player:GetUserGroup() == "superadmin");

	if ((Schema:PlayerIsCombine(player) and !player:Name():find("RCT")) or isAdmin) then
		local target = CW.player:FindByID(arguments[1]);
		local amount = tonumber(arguments[2]);

		if (IsValid(target)) then
			if (!(target.nextLPSet and target.nextLPSet > os.time() or isAdmin)) then
				if (amount) then
					if (!isAdmin) then
						amount = math.Clamp(amount, 0, 8);
					end;

					local curLP = target:GetCharacterData("LoyaltyPoints") or 0;
					Schema:SetLP(target, curLP + amount);

					target.nextLPSet = os.time() + 120;

					CW.player:Notify(player, target:Name().."'s Loyalty Points were set to "..target:GetCharacterData("LoyaltyPoints").." ("..curLP.." + "..amount..").");
				else
					CW.player:Notify(player, tostring(arguments[2]).." is not a valid amount!");
				end;
			else
				CW.player:Notify(player, "Please wait before setting "..target:Name().."'s Loyalty Points again!");
			end;
		else
			CW.player:Notify(player, arguments[1].." is not a valid player!");
		end;
	else
		CW.player:Notify(player, "You are not the Combine or not ranked high enough to use this command!");
	end;
end;

COMMAND:Register();