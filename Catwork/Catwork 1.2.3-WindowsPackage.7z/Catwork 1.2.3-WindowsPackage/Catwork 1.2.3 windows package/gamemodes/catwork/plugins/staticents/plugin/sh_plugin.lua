--[[
	Flux © 2016-2017 TeslaCloud Studios
	Do not share or re-distribute before
	the framework is publicly released.
--]]

PLUGIN:SetGlobalAlias("cwStaticEnts")

util.Include("sv_hooks.lua")