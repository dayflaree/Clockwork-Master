

ITEM.name = "Broken M4A1"
ITEM.PrintName = "Поломанная М4А1"
ITEM.model = "models/weapons/w_m4_1.mdl"
ITEM.weight = 2
ITEM.category = "Materials"
ITEM.description = "Автомат без приклада, прицельной планки и затвора."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

