

ITEM.name = "Broken Shotgun"
ITEM.PrintName = "Поломанный дробовик"
ITEM.model = "models/weapons/w_shotgun.mdl"
ITEM.weight = 4
ITEM.category = "Materials"
ITEM.description = "Дробовик 'SPAS-12' без цевья, затвора и приклада."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

