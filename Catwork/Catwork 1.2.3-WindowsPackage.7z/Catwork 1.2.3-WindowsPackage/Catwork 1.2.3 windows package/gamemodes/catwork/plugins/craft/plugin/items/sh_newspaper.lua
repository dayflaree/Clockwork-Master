

ITEM.name = "Newspaper"
ITEM.PrintName = "Газета"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl"
ITEM.weight = 0.4
ITEM.category = "Materials"
ITEM.description = "Очень старая газета. Она рвется от малейших прикосновений."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

