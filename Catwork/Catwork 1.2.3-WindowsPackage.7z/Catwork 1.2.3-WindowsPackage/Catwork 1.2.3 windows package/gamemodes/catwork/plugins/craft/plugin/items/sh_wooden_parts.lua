
ITEM.name = "Wooden Parts"
ITEM.PrintName = "Деревянные части"
ITEM.model = "models/gibs/furniture_gibs/furnituredrawer002a_gib03.mdl"
ITEM.weight = 0.25
ITEM.uniqueID = "wooden_parts"
ITEM.category = "Materials"
ITEM.business = false
ITEM.description = "Маленькие обломки старой мебели."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

