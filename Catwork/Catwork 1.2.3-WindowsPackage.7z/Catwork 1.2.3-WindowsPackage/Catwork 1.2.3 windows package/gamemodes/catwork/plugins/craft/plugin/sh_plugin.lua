local PLUGIN = PLUGIN

function PLUGIN:PlayerCanCraft(player, bpTable) return true end

function PLUGIN:PlayerHasCraftAttributes(player, bpTable)
	local atts = bpTable("reqatt")

	if (table.Count(atts) > 0) then
		for k, v in pairs(atts) do
			if (cw.attributes:Get(player, v[1], nil, true) < v[2]) then
				return false
			end
		end
	end

	return true
end

function PLUGIN:PlayerHasCraftMaterials(player, bpTable)
	local inventory = nil
	if CLIENT then
		inventory = cw.inventory:GetClient()
	else
		inventory = player:GetInventory()
	end

	if !bpTable then return false end

	local required = bpTable("required")
	local recipe = bpTable("recipe")
	local stored_recipe = {}

	if table.Count(recipe) > 0 then
		for k, v in pairs(recipe) do
			stored_recipe[#stored_recipe + 1] = { v[1], v[2] }
		end
	end
	if table.Count(required) > 0 then
		for k, v in pairs(required) do
			stored_recipe[#stored_recipe + 1] = { v[1], v[2] }
		end
	end

	local stored = {}
	for k, v in pairs(stored_recipe) do
		for z, x in pairs(inventory) do
			if z == v[1] then
				for z2, x2 in pairs(x) do
					if !stored[z] then
						stored[z] = 1
					else
						stored[z] = stored[z] + 1
					end
				end
			end
		end
	end

	if table.Count(stored) == 0 then return false end

	local err = false
	local check = true
	while !err and check do
		for k, v in pairs(stored_recipe) do
			for z, x in pairs(stored) do
				if !stored[v[1]] then
					err = true
				else
					if stored[v[1]] < v[2] then
						err = true
					end
				end
			end
			if k == #stored_recipe then
				check = false
			end
		end
	end

	return !err
end

netstream.Hook("CraftItem", function(player, uniqueID)
	local bpTable = cw.blueprints:FindByID(uniqueID)

	if !bpTable then
		return false
	end

	if !player.activeCraftTable then
		cw.player:Notify(player, "Вы не используете верстак!")
		return false
	elseif IsValid(player.activeCraftTable) then
		if player:GetPos():Distance(player.activeCraftTable:GetPos()) > 70 then
			cw.player:Notify(player, "Вы не используете верстак!")
			return false
		end
	end

	bpTable = table.Copy(cw.blueprints:FindByID(uniqueID))

	if player.cwNextCraftTime and CurTime() < player.cwNextCraftTime then
		return false
	end
	if !PLUGIN:PlayerCanCraft(player, bpTable) then
		return false
	end

	if player:CanSeeCraft(bpTable) then
		if PLUGIN:PlayerHasCraftAttributes(player, bpTable) then
			if PLUGIN:PlayerHasCraftMaterials(player, bpTable) then
				cw.core:PrintLog(LOGTYPE_MINOR, player:Name().." has crafted a "..bpTable("name")..".")

				if bpTable.OnCraft then
					bpTable:OnCraft(player, bpTable)
				end

				PLUGIN:PlayerCraftItem(player, bpTable, player.activeCraftTable)
				player.activeCraftTable:EmitSound("plats/elevator_stop.wav")
				player.cwNextCraftTime = CurTime() + 2

				netstream.Start(player, "CraftTime", player.cwNextCraftTime)
			else
				cw.player:Notify(player, "У вас нет необходимых вещей!")
			end
		else
			cw.player:Notify(player, "У вас нет необходимых навыков!")
		end
	else
		cw.player:Notify(player, "Этот крафт недоступен Вам!")
	end
end)

if SERVER then	
	function PLUGIN:PlayerCraftItem(player, bpTable, entity)
		local inventory = player:GetInventory()
		if !bpTable then return false end

		local recipe = bpTable("recipe")
		local result = bpTable("finish")
		local updatt = bpTable("updatt")

		if table.Count(recipe) > 0 then
			for k, v in pairs(recipe) do
				for i = 1, v[2] do
					if !player:TakeItemByID(v[1]) then
						return
					end
				end
			end
		end

		if table.Count(result) > 0 then
			for k, v in pairs(result) do
				for i = 1, v[2] do
					if !player:GiveItem(v[1]) then
						if IsValid(entity) then
							if entity.GetCraftPos then
								cw.entity:CreateItem(nil, v[1], entity:GetCraftPos(), Angle(0, 0, 0))
							end
						end
					end
				end
			end
		end

		if table.Count(updatt) > 0 then
			for k, v in pairs(updatt) do
				player:ProgressAttribute(v[1], v[2], true)
			end
		end

		cw.player:Notify(player, "Вы создали: " .. bpTable("name"))
	end

	function PLUGIN:SaveCraftTables()
		local craftT = {}
		for k, v in ipairs(ents.GetAll()) do
			if (v.IsCraft) then
				craftT[#craftT + 1] = {
					class = v:GetClass(),
					angles = v:GetAngles(),
					position = v:GetPos()
				}
			end
		end
		cw.core:SaveSchemaData("plugins/craft/"..game.GetMap(), craftT)
	end

	function PLUGIN:LoadCraftTables()
		local craftT = cw.core:RestoreSchemaData("plugins/craft/"..game.GetMap())
		
		for k, v in pairs(craftT) do
			local device = ents.Create(v.class)

			if device then
				device:SetPos(v.position)
				device:SetAngles(v.angles)
				device:Spawn()
				device:GetPhysicsObject():EnableMotion(false)
			end
		end
	end

	function PLUGIN:ClockworkInitPostEntity()
		self:LoadCraftTables()
	end

	function PLUGIN:PostSaveData()
		self:SaveCraftTables()
	end
end

local playerMeta = FindMetaTable("Player")

do
	function playerMeta:CanSeeCraft(bpTable)
		local flags = bpTable("flag")
		local atts = bpTable("reqatt")

		if (table.Count(atts) > 0) then
			for k, v in pairs(atts) do

				if (SERVER) then
					local att = cw.attributes:Fraction(self, v[1], 100)

					if ((v[2] >= 25 and att < 25) or
					(v[2] >= 50 and att < 50) or
					(v[2] >= 75 and att < 75)) then
						return false
					end
				else
					local att = cw.attributes:Fraction(v[1], 100)

					if (v[2] and att) then
						if ((v[2] >= 25 and att < 25) or
						(v[2] >= 50 and att < 50) or
						(v[2] >= 75 and att < 75)) then
							return false
						end
					end
				end
			end
		end

		return true
	end
end