

ITEM.name = "Broken M9"
ITEM.PrintName = "Поломанный M9 Beretta"
ITEM.model = "models/weapons/w_m9beretta.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Пистолет М9, покрытый ржавчиной."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

