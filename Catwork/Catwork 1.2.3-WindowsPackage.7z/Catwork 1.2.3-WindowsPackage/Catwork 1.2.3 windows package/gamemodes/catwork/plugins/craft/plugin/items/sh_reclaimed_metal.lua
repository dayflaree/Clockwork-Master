

ITEM.name = "Reclaimed Metal"
ITEM.PrintName = "Восстановленный металл"
ITEM.model = "models/props_lab/pipesystem03a.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.description = "Добротный кусок металла."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

