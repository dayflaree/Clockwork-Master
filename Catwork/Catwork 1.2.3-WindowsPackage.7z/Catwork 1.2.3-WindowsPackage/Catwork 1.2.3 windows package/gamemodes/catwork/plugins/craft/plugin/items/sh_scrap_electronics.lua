

ITEM.name = "Scrap Electronics"
ITEM.PrintName = "Поврежденная электроника"
ITEM.model = "models/props_lab/reciever01d.mdl"
ITEM.weight = 0.4
ITEM.category = "Materials"
ITEM.description = "Поломанные платы, перегоревшие транзисторы и вздувшиеся конденсаторы."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

