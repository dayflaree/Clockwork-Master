

ITEM.name = "Sulphur"
ITEM.PrintName = "Сера"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Маленький пакетик с желтым порошком внутри."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

