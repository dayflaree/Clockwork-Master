local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Рюкзак"
BLUEPRINT.uniqueID = "blueprint_backpack"
BLUEPRINT.model = "models/props_junk/cardboard_box004a.mdl"
BLUEPRINT.category = "Хранилища"
BLUEPRINT.description = "Из обрывков ткани можно сшить рюкзак."
BLUEPRINT.reqatt = {
	{"cloth", 30}
}
BLUEPRINT.updatt = {
	{"cloth", 20}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"cloth", 2},
	{"cables", 2}
}
BLUEPRINT.finish = {
	{"boxed_backpack", 1}
}
BLUEPRINT:Register();