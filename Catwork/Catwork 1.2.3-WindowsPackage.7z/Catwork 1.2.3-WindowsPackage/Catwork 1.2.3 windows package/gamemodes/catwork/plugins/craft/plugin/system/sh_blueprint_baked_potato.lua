local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Печеная картошка"
BLUEPRINT.uniqueID = "blueprint_baked_potato"
BLUEPRINT.model = "models/bioshockinfinite/hext_potato.mdl"
BLUEPRINT.category = "Еда"
BLUEPRINT.description = "Картофель можно бросить в печь и запечь."
BLUEPRINT.craftplace = "cw_craft_cook"
BLUEPRINT.reqatt = {}
BLUEPRINT.updatt = {
	{"cook", 10}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"potato", 1},
}
BLUEPRINT.finish = {
	{"baked_potato", 1}
}
BLUEPRINT:Register();