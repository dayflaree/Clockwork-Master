DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "AleXXX_007"
ENT.PrintName = "Печка"

ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false
ENT.IsCraft = true

ENT.Model = "models/props_c17/furniturefireplace001a.mdl"
ENT.Category = "HL2RP: Мастерские"

function ENT:SetupDataTables()

end