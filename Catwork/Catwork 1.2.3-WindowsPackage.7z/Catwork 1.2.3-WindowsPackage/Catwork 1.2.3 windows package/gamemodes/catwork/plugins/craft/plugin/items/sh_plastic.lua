

ITEM.name = "Plastic"
ITEM.PrintName = "Пластик"
ITEM.model = "models/props_debris/metal_panelshard01b.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Лист пластика."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

