

ITEM.name = "Car Battery"
ITEM.PrintName = "Автомобильный аккумулятор"
ITEM.model = "models/items/car_battery01.mdl"
ITEM.weight = 1
ITEM.category = "Materials"
ITEM.description = "На удвиление, он заряжен."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

