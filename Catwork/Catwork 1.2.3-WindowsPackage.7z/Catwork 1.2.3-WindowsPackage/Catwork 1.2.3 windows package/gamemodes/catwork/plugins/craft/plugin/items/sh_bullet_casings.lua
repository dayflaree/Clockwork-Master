

ITEM.name = "Bullet Casings"
ITEM.PrintName = "Гильзы"
ITEM.model = "models/items/ammobox.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Коробка с различными гильзами."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

