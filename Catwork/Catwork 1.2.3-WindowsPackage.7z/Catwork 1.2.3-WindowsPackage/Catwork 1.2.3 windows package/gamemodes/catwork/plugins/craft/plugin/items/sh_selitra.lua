

ITEM.name = "Selitra"
ITEM.PrintName = "Селитра"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.weight = 0.5
ITEM.category = "Materials"
ITEM.description = "Маленький пакетик с белыми катышками внутри."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

