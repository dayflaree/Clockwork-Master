

ITEM.name = "Cables"
ITEM.PrintName = "Кабель"
ITEM.model = "models/Items/CrossbowRounds.mdl"
ITEM.weight = 0.2
ITEM.category = "Materials"
ITEM.description = "Сверток различных кабелей"

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

