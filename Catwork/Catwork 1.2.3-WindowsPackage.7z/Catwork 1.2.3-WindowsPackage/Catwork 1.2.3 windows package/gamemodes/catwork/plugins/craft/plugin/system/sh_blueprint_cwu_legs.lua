local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Светлые джинсы"
BLUEPRINT.uniqueID = "blueprint_cwu_legs"
BLUEPRINT.model = "models/tnb/items/pants_citizen.mdl"
BLUEPRINT.category = "Одежда"
BLUEPRINT.description = "Сшить из ткани светлые джинсы."
BLUEPRINT.required = {}
BLUEPRINT.updatt = {
	{"cloth", 45}
}
BLUEPRINT.reqatt = {
	{"cloth", 15}
}
BLUEPRINT.recipe = {
	{"cloth", 3},
}
BLUEPRINT.finish = {
	{"cwu_legs", 1}
}
BLUEPRINT:Register();