local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Гаечный ключ"
BLUEPRINT.uniqueID = "blueprint_wrench"
BLUEPRINT.model = "models/props_c17/TrapPropeller_Lever.mdl"
BLUEPRINT.category = "Инструменты"
BLUEPRINT.description = "Погнутый гаечный ключ."
BLUEPRINT.reqatt = {
	{"rem", 10}
}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"refined_metal", 1}
}
BLUEPRINT.finish = {
	{"wrench", 1}
}
BLUEPRINT:Register();