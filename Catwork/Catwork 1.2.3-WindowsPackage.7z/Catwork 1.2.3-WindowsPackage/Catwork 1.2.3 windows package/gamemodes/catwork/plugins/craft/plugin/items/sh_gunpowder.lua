

ITEM.name = "Gunpowder"
ITEM.PrintName = "Порох"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.weight = 0.2
ITEM.category = "Materials"
ITEM.description = "Маленькая коробка, наполненная порохом."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

