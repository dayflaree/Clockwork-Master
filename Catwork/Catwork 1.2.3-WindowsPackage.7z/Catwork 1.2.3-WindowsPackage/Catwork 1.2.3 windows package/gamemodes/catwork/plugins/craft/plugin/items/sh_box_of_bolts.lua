

ITEM.name = "Box of Bolts"
ITEM.PrintName = "Коробка болтов"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.weight = 0.6
ITEM.category = "Materials"
ITEM.description = "Маленькая коробка, наполненная болтами."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

