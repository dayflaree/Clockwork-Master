--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local ATTRIBUTE = cw.attribute:New()
	ATTRIBUTE.name = "Кулинария"
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "cook"
	ATTRIBUTE.description = "Определяет, как хорошо Вы готовите различную пищу."
	ATTRIBUTE.isOnCharScreen = false
	ATTRIBUTE.category = "Навыки"
ATB_COOK = cw.attribute:Register(ATTRIBUTE);