--[[
	Catwork © 2016 Some good coders
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.

local ATTRIBUTE = cw.attribute:New()
	ATTRIBUTE.name = "Столярство"
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "carp"
	ATTRIBUTE.description = "Определяет, как хорошо Вы создаете изделия из дерева."
	ATTRIBUTE.isOnCharScreen = false
	ATTRIBUTE.category = "Навыки"
ATB_CARP = cw.attribute:Register(ATTRIBUTE)

--]]