

ITEM.name = "Rock"
ITEM.PrintName = "Камень"
ITEM.model = "models/props_junk/rock001a.mdl"
ITEM.weight = 4
ITEM.category = "Materials"
ITEM.description = "Тяжелый булыжник."

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end

