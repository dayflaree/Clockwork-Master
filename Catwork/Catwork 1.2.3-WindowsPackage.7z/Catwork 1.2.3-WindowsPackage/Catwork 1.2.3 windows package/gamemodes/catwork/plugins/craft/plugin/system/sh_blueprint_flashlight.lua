local BLUEPRINT = cw.blueprints:New()

BLUEPRINT.name = "Самодельный фонарик"
BLUEPRINT.uniqueID = "blueprint_flashlight"
BLUEPRINT.model = "models/lagmite/lagmite.mdl"
BLUEPRINT.category = "Разное"
BLUEPRINT.description = "Смастерить простейшую электронную схему из фонарика, выключателя и батарейки, затем поместить все это в корпус из банки."
BLUEPRINT.reqatt = {
	{"rem", 15}
}
BLUEPRINT.updatt = {
	{"rem", 15}
}
BLUEPRINT.required = {}
BLUEPRINT.recipe = {
	{"empty_soda_can", 2},
	{"energy_cell", 1},
	{"scrap_electronics", 1},
}
BLUEPRINT.finish = {
	{"flashlight", 1}
}
BLUEPRINT:Register();