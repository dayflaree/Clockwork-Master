--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("Announce")

COMMAND.tip = "Announce something to all players."
COMMAND.text = "<string Text>"
COMMAND.arguments = 1
COMMAND.access = "o"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ")

 	cw.player:NotifyAll(text)
end

COMMAND:Register();