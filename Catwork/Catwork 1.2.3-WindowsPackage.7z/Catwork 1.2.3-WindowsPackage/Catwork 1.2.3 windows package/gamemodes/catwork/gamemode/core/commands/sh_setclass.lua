--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("SetClass")
COMMAND.tip = "Set the class of your character."
COMMAND.text = "<string Class>"
COMMAND.flags = CMD_HEAVY
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local class = cw.class:FindByID(arguments[1])

	if (player:InVehicle()) then
		cw.player:Notify(player, L("CannotActionRightNow"))
		return
	end

	if (class) then
		local limit = cw.class:GetLimit(class.name)

		if (hook.Run("PlayerCanBypassClassLimit", player, class.index)) then
			limit = game.MaxPlayers()
		end

		if (_team.NumPlayers(class.index) < limit) then
			local previousTeam = player:Team()

			if (player:Team() != class.index
			and cw.core:HasObjectAccess(player, class)) then
				if (hook.Run("PlayerCanChangeClass", player, class)) then
					local bSuccess, fault = cw.class:Set(player, class.index, nil, true)

					if (!bSuccess) then
						cw.player:Notify(player, fault)
					end
				end
			else
				cw.player:Notify(player, L("ClassNoAccess"))
			end
		else
			cw.player:Notify(player, L("ClassTooMany"))
		end
	else
		cw.player:Notify(player, L("ClassNotValid"))
	end
end

COMMAND:Register();