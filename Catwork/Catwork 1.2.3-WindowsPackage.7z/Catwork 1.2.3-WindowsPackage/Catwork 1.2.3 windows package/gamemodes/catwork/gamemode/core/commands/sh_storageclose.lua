--[[
	Catwork © 2016-2017 TeslaCloud Studios
	Do not share.

	Original code by Alex Grist, 'impulse and Conna Wiles
	with contributions from Cloud Sixteen community.
--]]

local COMMAND = cw.command:New("StorageClose")
COMMAND.tip = "Close the active storage."
COMMAND.flags = CMD_DEFAULT

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local storageTable = player:GetStorageTable()

	if (storageTable) then
		cw.storage:Close(player, true)
	else
		cw.player:Notify(player, L("StorageNotOpen"))
	end
end

COMMAND:Register();