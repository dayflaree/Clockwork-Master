--[[
Name: "init.lua".
Product: "Day One".
--]]

require("blueprint_core");