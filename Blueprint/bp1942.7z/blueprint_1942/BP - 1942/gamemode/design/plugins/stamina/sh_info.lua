--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Stamina";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds stamina to limit player movement.";