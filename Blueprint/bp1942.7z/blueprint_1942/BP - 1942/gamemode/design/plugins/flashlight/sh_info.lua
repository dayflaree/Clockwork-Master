--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Flashlight";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds flashlights to allow players to see in the dark.";