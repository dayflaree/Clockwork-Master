--[[
Name: "sh_auto.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.paperIDs = {};
BLUEPRINT:IncludePrefixed("cl_hooks.lua");
BLUEPRINT:IncludePrefixed("sv_hooks.lua");