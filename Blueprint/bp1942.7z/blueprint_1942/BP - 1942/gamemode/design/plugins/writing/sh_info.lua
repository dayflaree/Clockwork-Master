--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Writing";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds paper to the design which players can write on.";