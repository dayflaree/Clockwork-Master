--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Storage";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds containers where players can store items.";