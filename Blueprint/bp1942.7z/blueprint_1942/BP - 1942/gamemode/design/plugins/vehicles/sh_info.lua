--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

local PLUGIN = PLUGIN;

PLUGIN.name = "Vehicles";
PLUGIN.author = "kurozael";
PLUGIN.description = "Adds faction vehicles to the design.";