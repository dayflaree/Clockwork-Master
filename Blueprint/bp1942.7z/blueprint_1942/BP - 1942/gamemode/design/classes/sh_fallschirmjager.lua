local CLASS = {};

CLASS.color = Color(165, 155, 95, 255);
CLASS.factions = {FACTION_FALL};
CLASS.isDefault = true;
CLASS.description = "A Fallschirmjager Soldier.";
CLASS.defaultPhysDesc = "A Fallschirmjager Soldier.";

CLASS_FALL = blueprint.class.Register(CLASS, "Fallschirmjager");