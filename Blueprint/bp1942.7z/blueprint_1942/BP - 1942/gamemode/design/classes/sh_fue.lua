local CLASS = {};

CLASS.color = Color(165, 155, 95, 255);
CLASS.factions = {FACTION_FUE};
CLASS.isDefault = true;
CLASS.description = "A Fuehrer Soldier.";
CLASS.defaultPhysDesc = "A Fuehrer Soldier.";

CLASS_FUE = blueprint.class.Register(CLASS, "Fuehrer");