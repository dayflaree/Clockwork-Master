local CLASS = {};

CLASS.color = Color(165, 155, 95, 255);
CLASS.factions = {FACTION_RA};
CLASS.isDefault = true;
CLASS.description = "A Red Army Soldier.";
CLASS.defaultPhysDesc = "A Red Army Soldier.";

CLASS_RA = blueprint.class.Register(CLASS, "Red Army");