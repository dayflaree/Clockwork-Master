local CLASS = {};

CLASS.color = Color(165, 155, 95, 255);
CLASS.factions = {FACTION_CRIMEAN};
CLASS.isDefault = true;
CLASS.description = "A crimean citizen.";
CLASS.defaultPhysDesc = "A crimean citizen.";

CLASS_CRIMEAN = blueprint.class.Register(CLASS, "Crimean Citizen");