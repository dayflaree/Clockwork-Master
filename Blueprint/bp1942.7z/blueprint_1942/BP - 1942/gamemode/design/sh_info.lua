--[[
Name: "sh_info.lua".
Product: "Day One".
--]]

DESIGN.name = "1942RP";
DESIGN.author = "Mistress May";
DESIGN.description = "A roleplaying game based on the catastrophic events of WWII.";