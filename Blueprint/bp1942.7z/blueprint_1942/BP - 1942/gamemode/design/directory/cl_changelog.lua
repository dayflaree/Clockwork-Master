--[[
Name: "cl_changelog.lua".
Product: "Day One".
--]]
	
blueprint.directory.AddCategoryPage( "Changelog", nil, [[
	<p>
		<font size="4">
			<b><i>Changes made on the 15th April 2012.</i></b><br>
		</font>
		<b>+</b> Nuke Script goes into Alpha.
	</p>
	<p>
		<font size="4">
			<b><i>Changes made on the 14th April 2012.</i></b><br>
		</font>
		<b>+</b> Work on Nuke Script began.
	</p>
]] );