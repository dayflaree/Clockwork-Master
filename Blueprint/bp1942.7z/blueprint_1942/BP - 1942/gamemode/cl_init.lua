--[[
Name: "cl_init.lua".
Product: "Day One".
--]]

BLUEPRINT = GM;
DeriveGamemode("blueprint");