local Clockwork = Clockwork;

Atomic.special = Clockwork.kernel:NewLibrary("Special");

if (SERVER) then
	Atomic.special.module = Clockwork.kernel:NewLibrary("SpecialModule");

	function Atomic.special.module:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
		if (!lightSpawn) then
			for k, v in pairs(Atomic.special:GetNameTable()) do
				local value = Atomic.special:LoadSpecial(player, v);

				player:SetSpecial(k, value);
			end;
		end;
	end;

	function Atomic.special.module:PlayerCharacterUnloaded(player)
		for k, v in pairs(Atomic.special:GetNameTable()) do
			Atomic.special:SetBoost(player, k, 0);
		end;
	end;

	function Atomic.special.module:OnPlayerSpecialChanged(player, statName, oldValue, newValue)
		if (statName == "Endurance") then
			local percent = player:Health() / player:GetMaxHealth();
			local newMaxHealth = Clockwork.plugin:Call("AdjustMaxHealth", player, 100);

			player:SetMaxHealth(newMaxHealth);
			player:SetHealth(newMaxHealth * percent);
		end;
	end;

	Clockwork.plugin:Add("ATOMIC_SPECIAL", Atomic.special.module);
end;

function Atomic.special:GetNameTable()
	return {
		S = "Strength",
		P = "Perception",
		E = "Endurance",
		C = "Charisma",
		I = "Intelligence",
		A = "Agility",
		L = "Luck"
	};
end;

function Atomic.special:SaveSpecial(player, stat, value)
	if (Clockwork.config:Get("enable_special"):Get()) then
		local newStat = self:GetNameTable()[stat] or stat;

		player:SetCharacterData("s_"..newStat, value);
	end;
end;

function Atomic.special:LoadSpecial(player, stat)
	if (Clockwork.config:Get("enable_special"):Get()) then
		local newStat = self:GetNameTable()[stat] or stat;

		return player:GetCharacterData("s_"..newStat) or 1;
	else
		return 0;
	end;
end;

function Atomic.special:SetSpecial(player, stat, value, bSave)
	local statName = self:GetNameTable()[stat] or stat;
	local oldValue = player:GetSpecial(statName);

	player:SetNWInt("s_"..statName, value);

	local newValue = player:GetSpecial(statName);

	if (bSave) then
		self:SaveSpecial(player, statName, value);
	end;

	Clockwork.plugin:Call("OnPlayerSpecialChanged", player, statName, oldValue, newValue);
end;

function Atomic.special:GetSpecial(player, stat, boostless)
	if (Clockwork.config:Get("enable_special"):Get()) then
		local statName = self:GetNameTable()[stat] or stat;

		local origStat = player:GetNWInt("s_"..statName);
		local boost = nil;

		if (!boostless) then
			boost = player:GetBoost(statName);
		end;

		if (origStat) then
			if (boost) then
				origStat = origStat + boost;
			end;

			return origStat;
		else
			return 1;
		end;
	else
		return 0;
	end;
end;

function Atomic.special:GetBoost(player, stat)
	local statName = self:GetNameTable()[stat] or stat;

	return player:GetNWInt(statName.."_boost") or 0;
end;

function Atomic.special:SetBoost(player, stat, value)
	local statName = self:GetNameTable()[stat] or stat;
	local newValue = player:GetSpecial(statName, true) + value;
	local oldValue = player:GetSpecial(statName);

	player:SetNWInt(statName.."_boost", value);

	Clockwork.plugin:Call("OnPlayerSpecialChanged", player, statName, oldValue, newValue);
end;

function Atomic.special:AddBoost(player, stat, value)
	local statName = self:GetNameTable()[stat] or stat;
	local oldBoost = player:GetBoost(statName);

	return self:SetBoost(player, statName, oldBoost + value);
end;

local PLAYER_META = FindMetaTable("Player");

function PLAYER_META:GetSpecial(stat, boostless)
	return Atomic.special:GetSpecial(self, stat, boostless);
end;

function PLAYER_META:SetSpecial(stat, value)
	return Atomic.special:SetSpecial(self, stat, value);
end;

function PLAYER_META:GetBoost(stat)
	return Atomic.special:GetBoost(self, stat);
end;

function PLAYER_META:AddBoost(stat, value)
	return Atomic.special:AddBoost(self, stat, value);
end;