local Clockwork = Clockwork;

Atomic.perks = Clockwork.kernel:NewLibrary("Perks");

local stored = {};

KARMA_NEUTRAL = 0;
KARMA_GOOD = 1;
KARMA_EVIL = 2;

Clockwork.plugin:AddExtra("/perks/");
Clockwork.plugin:AddExtra("/traits/");

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE};

CLASS_TABLE.name = "Unknown";
CLASS_TABLE.karma = KARMA_NEUTRAL;
CLASS_TABLE.icon = "icon16/error.png";
CLASS_TABLE.description = "An unknown perk.";
CLASS_TABLE.isTrait = false;
CLASS_TABLE.special = {};
CLASS_TABLE.skill = {};
CLASS_TABLE.Module = {}


-- A function to register a new attribute.
function CLASS_TABLE:Register()
	return Atomic.perks:Register(self);
end;

-- A function to get a player's perks as a table.
function Atomic.perks:GetPlayerPerks(player)
	local perkTable = string.Explode(",", player:GetNWString("Perks"));

	for k, v in pairs(perkTable) do
		if (v == "") then
			table.remove(perkTable, k);
		end;
	end;

	return perkTable;
end;

-- A function to set a player's perks from a table.
function Atomic.perks:SetPlayerPerks(player, perkTable)
	return player:SetNWString("Perks", table.concat(perkTable, ","));
end;

-- A function to remove a perk from a player's table.
function Atomic.perks:RemovePerk(player, perkName)
	local perkTable = player:GetPerks();
	local bHas, key = player:HasPerk(perkName);
		
	if (bHas) then
		table.remove(perkTable, key);
	end;

	player:SetPerks(perkTable);
end;

-- A function to add a perk to a player's table.
function Atomic.perks:AddPerk(player, perkName)
	if (!player:HasPerk(perkName)) then
		local perkTable = player:GetPerks();

		table.insert(perkTable, perkName);

		player:SetPerks(perkTable);
	end;
end;

-- A function to check if a player has a certain perk or not.
function Atomic.perks:HasPerk(player, perkName)
	local perkTable = player:GetPerks();

	for k, v in pairs(perkTable) do
		if (v == perkName) then
			return true, k;
		end;
	end;

	return false;
end;

-- A function to return the stored table.
function Atomic.perks:GetStored()
	return stored;
end;

-- A function to find a perk by its id.
function Atomic.perks:FindByID(id)
	return stored[id];
end;

-- A less precise way to find a perk.
function Atomic.perks:FindPerk(perkName)
	for k, v in pairs(stored) do
		if (string.find(v.name, perkName)) then
			return v;
		end;
	end;
end;

-- A function to get a new attribute.
function Atomic.perks:New(name)
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE);

	return object;
end;

-- A function to register a new perk and any of its hooks.
function Atomic.perks:Register(perk)	
	Clockwork.plugin:Call("OnPerkRegistered", perk);
	stored[perk.name] = perk;
end;

local PLAYER_META = FindMetaTable("Player");

function PLAYER_META:HasPerk(perkName)
	return Atomic.perks:HasPerk(self, perkName);
end;

function PLAYER_META:AddPerk(perkName)
	return Atomic.perks:AddPerk(self, perkName);
end;

function PLAYER_META:RemovePerk(perkName)
	return Atomic.perks:RemovePerk(self, perkName);
end;

function PLAYER_META:GetPerks()
	return Atomic.perks:GetPlayerPerks(self);
end;

function PLAYER_META:SetPerks(perkTable)
	return Atomic.perks:SetPlayerPerks(self, perkTable);
end;