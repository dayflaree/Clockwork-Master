local PERK = Atomic.perks:New();

PERK.name = "Swift Learner";
PERK.icon = "atomic/hud/perks/swift_learner.png";
PERK.description = "You learn quick on your feet, progressing skills twice as fast as normal.";

if (SERVER) then
	local perkModule = Clockwork.kernel:NewLibrary("SwiftLearner_Module");

	-- Called when an attribute gains progress to adjust how much is progressed.
	function perkModule:OnAttributeProgress(player, attribute, amount)
		print("test");
		if (player:HasPerk(PERK.name)) then
			print(amount);
			amount = amount * 2;
			print(amount);
		end;
	end;

	Clockwork.plugin:Add("SwiftLearner_Module", perkModule);
end;

PERK:Register();