--[[ 
    � 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 70;
	ITEM.name = "5.7x28mm Rounds";
	ITEM.batch = 1;
	ITEM.model = "models/items/boxzrounds.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "T";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_xbowbolt";
	ITEM.ammoClass = "xbowbolt";
	ITEM.ammoAmount = 24;
	ITEM.description = "An average sized blue container with 5.7x28mm on the side.";
ITEM:Register();