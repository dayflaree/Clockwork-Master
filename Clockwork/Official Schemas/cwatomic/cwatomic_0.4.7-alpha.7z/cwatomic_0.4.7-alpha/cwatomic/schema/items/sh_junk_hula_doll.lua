--[[ 
    � 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local ITEM = Clockwork.item:New("base_junk");
	ITEM.name = "Hula Doll";
	ITEM.worth = 1;
	ITEM.model = "models/props_lab/huladoll.mdl";
	ITEM.weight = 0.1
	ITEM.description = "A Hula Doll, it sways from side to side.";
ITEM:Register();