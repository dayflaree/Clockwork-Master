local gripMat = Material("atomic/hud/vert_scrollbar.png");
local upMat = Material("atomic/hud/scroll_up.png");
local downMat = Material("atomic/hud/scroll_down.png");

local PANEL = {};

function PANEL:Init()
	local color = Clockwork.option:GetColor("information");
	local perks = {};

	for k, v in pairs(Clockwork.Client:GetPerks()) do
		table.insert(perks, v);
	end;
	
	table.sort(perks, function(a, b)
		return a < b;
	end);
	
	self.drawBlur = true;
	self:SetSize(700, 512);
	self:SetTitle("ABILITY REVIEW");

	self.LeftHalf = vgui.Create("DScrollPanel", self);
	self.LeftHalf:SetPos(0, 50);
	self.LeftHalf:SetSize(self:GetWide() * 0.4, self:GetTall() - 70);
	
	function self.LeftHalf:Paint(w, h)
		return false;
	end;

	local sBar = self.LeftHalf:GetVBar();

	function sBar:Paint(w, h)
		return false;
	end;

	function sBar.btnGrip:Paint(w, h)
		surface.SetDrawColor(color);
		surface.SetMaterial(gripMat);
		surface.DrawTexturedRect(0, 0, w, h);
	end;

	function sBar.btnDown:Paint(w, h)
		surface.SetDrawColor(color);
		surface.SetMaterial(downMat);
		surface.DrawTexturedRect(0, 0, w, h);
	end;

	function sBar.btnUp:Paint(w, h)
		surface.SetDrawColor(color);
		surface.SetMaterial(upMat);
		surface.DrawTexturedRect(0, 0, w, h);
	end;

	local btnY = 0;

	local perkImage = vgui.Create("DImageButton", self);

	perkImage:SetPos(350, 95);
	perkImage:SetSize(256, 256);
	perkImage:SetImage("atomic/hud/perks/strongback.png");
	perkImage:SetColor(color);

	local perkDesc = vgui.Create("DLabel", self);

	perkDesc:SetPos(300, 280);
	perkDesc:SetSize(400, 200);
	perkDesc:SetFont(Clockwork.option:GetFont("atomic_menu_text_20"));
	perkDesc:SetText("Your friends shape who you are, and Vault-Tec wants to know just who those friends are!");
	perkDesc:SetColor(color);
	perkDesc:SetWrap(true);

	local buttons = {};

	for k, v in pairs(perks) do
		local button = vgui.Create("DImageButton", self.LeftHalf);
		local perk = Atomic.perks:FindByID(v);

		button:SetFont(Clockwork.option:GetFont("hud_text"));
		button:SetText(perk.name)
		button:SetTextColor(color);
		button:SetPos(15, btnY);
		button:SetSize(250, 50);
		button:SetColor(color);

		function button:Paint(w, h)
			if (self:IsHovered()) then
				surface.SetDrawColor(color);

				for i=0, 3 do
					surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
				end;

				if (perk.icon) then
					perkImage:SetImage(perk.icon);
				end;

				if (perk.description) then
					perkDesc:SetText(perk.description);
				else
					perkDesc:SetText("");
				end;

				if (!self.played) then
					Clockwork.option:PlaySound("rollover");

					self.played = true;
				end;
			else
				if (self.played) then
					self.played = nil;
				end;
			end;
		end;

		table.insert(buttons, button);

		btnY = btnY + 50;
	end;

	function perkImage:Think()
		local isHovering = false;

		if (buttons) then
			for k, v in pairs(buttons) do
				if (self.IsHovered()) then
					isHovering = true;
				end;
			end;
		end;

		if (isHovering == false) then
			self:SetImage("atomic/hud/perks/strongback.png");
			perkDesc:SetText("Your friends shape who you are, and Vault-Tec wants to know just who those friends are!");
		end;
	end;
end;

-- Called every frame and every tick.
function PANEL:Think()
	self.lblTitle:SetVisible(false);
	self.btnMaxim:SetVisible(false);
	self.btnMinim:SetVisible(false);
	self.btnClose:SetVisible(false);
	
	if (self.animation) then
		self.animation:Run();
	end;
end;

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and CW_CONVAR_FADEPANEL:GetInt() == 1 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255));
			
			if (animation.Finished) then
				panel:SetVisible(false);
			end;
			
			if (animation.Finished and Callback) then
				Callback();
			end;
		end);
		
		if (self.animation) then
			self.animation:Start(speed);
		end;
		
		Clockwork.option:PlaySound("rollover");
	else
		self:SetVisible(false);
		self:SetAlpha(0);
		
		if (Callback) then
			Callback();
		end;
	end;
end;

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and CW_CONVAR_FADEPANEL:GetInt() == 1 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetVisible(true);
			panel:SetAlpha(delta * 255);
			
			if (animation.Finished) then
				self.animation = nil;
			end;
			
			if (animation.Finished and Callback) then
				Callback();
			end;
		end);
		
		if (self.animation) then
		end;
			self.animation:Start(speed);
	else
		self:SetVisible(true);
		self:SetAlpha(255);
		
		if (Callback) then
			Callback();
		end;
	end;
	
	Clockwork.option:PlaySound("click_release");
end;

vgui.Register("cwPerks", PANEL, "FO4Frame");