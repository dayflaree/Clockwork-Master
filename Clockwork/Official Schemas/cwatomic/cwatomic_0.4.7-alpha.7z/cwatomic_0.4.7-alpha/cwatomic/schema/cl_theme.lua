--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local THEME = Clockwork.theme:Begin();

-- Called when fonts should be created.
function THEME:CreateFonts()
	surface.CreateFont("ato_Large3D2D", {
		size = Clockwork.kernel:FontScreenScale(2048),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextSmall", {
		size = Clockwork.kernel:FontScreenScale(16),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextTiny", {
		size = Clockwork.kernel:FontScreenScale(12),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_CinematicText", {
		size = Clockwork.kernel:FontScreenScale(18),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_IntroTextBig", {
		size = Clockwork.kernel:FontScreenScale(18),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_TargetIDText", {
		size = Clockwork.kernel:FontScreenScale(8),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextHuge", {
		size = Clockwork.kernel:FontScreenScale(22),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextBig", {
		size = Clockwork.kernel:FontScreenScale(20),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});


	surface.CreateFont("ato_MainText", {
		size = Clockwork.kernel:FontScreenScale(8),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_MenuTextSmall", {
		size = Clockwork.kernel:FontScreenScale(10),
		weight = 100,
		antialias = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText", {
		size = Clockwork.kernel:FontScreenScale(12),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_small", {
		size = Clockwork.kernel:FontScreenScale(5),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText2", {
		size = Clockwork.kernel:FontScreenScale(20),
		weight = 100,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_blur", {
		size = Clockwork.kernel:FontScreenScale(12),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText_small_blur", {
		size = Clockwork.kernel:FontScreenScale(5),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	surface.CreateFont("ato_HUDText2_blur", {
		size = Clockwork.kernel:FontScreenScale(20),
		weight = 100,
		blursize = 4,
		antialias = true,
		shadow = true,
		font = "Monofonto"
	});

	for k, i in pairs({28, 25, 16, 19, 70, 20}) do
		surface.CreateFont("ato_menu"..i, {
			font = "Tahoma",
			size = i,
			antialias = true,
			weight = 900,
			shadow = true
		})
		
		surface.CreateFont("ato_menu_glow"..i, {
			font = "Tahoma",
			size = i,
			blursize = 4,
			scanlines = 2,
			antialias = true,
			weight = 900
		})
	end;
end;

-- Called when to initialize the theme.
function THEME:Initialize()
	Clockwork.option:SetColor("target_id", Color(165, 155, 95, 255));
	Clockwork.option:SetColor("background", Color(0, 0, 0, 255));

	Clockwork.option:SetFont("bar_text", "ato_IntroTextTiny");
	Clockwork.option:SetFont("main_text", "ato_MainText");
	Clockwork.option:SetFont("hints_text", "ato_IntroTextTiny");
	Clockwork.option:SetFont("large_3d_2d", "ato_Large3D2D");
	Clockwork.option:SetFont("target_id_text", "ato_TargetIDText");
	Clockwork.option:SetFont("cinematic_text", "ato_CinematicText");
	Clockwork.option:SetFont("date_time_text", "ato_IntroTextSmall");
	Clockwork.option:SetFont("menu_text_big", "ato_MenuTextBig");
	Clockwork.option:SetFont("menu_text_huge", "ato_MenuTextHuge");
	Clockwork.option:SetFont("menu_text_tiny", "ato_MainText");
	Clockwork.option:SetFont("intro_text_big", "ato_IntroTextBig");
	Clockwork.option:SetFont("menu_text_small", "ato_MenuTextSmall");
	Clockwork.option:SetFont("intro_text_tiny", "ato_IntroTextTiny");
	Clockwork.option:SetFont("intro_text_small", "ato_IntroTextSmall");
	Clockwork.option:SetFont("player_info_text", "ato_MainText");
	Clockwork.option:SetFont("hud_text", "ato_HUDText");
	Clockwork.option:SetFont("hud_text_small", "ato_HUDText_small");
	Clockwork.option:SetFont("hud_text_big", "ato_HUDText2");
	Clockwork.option:SetFont("hud_text_blur", "ato_HUDText_blur");
	Clockwork.option:SetFont("hud_text_small_blur", "ato_HUDText_small_blur");
	Clockwork.option:SetFont("hud_text_big_blur", "ato_HUDText2_blur");
	Clockwork.option:SetFont("chat_box_text", "ato_MainText");
	Clockwork.option:SetFont("chat_box_syntax", "ato_MainText");

	for k, i in pairs({28, 25, 16, 19, 70, 20}) do
		Clockwork.option:SetFont("atomic_menu_text_"..i, "ato_menu"..i);
		Clockwork.option:SetFont("atomic_menu_text_glow_"..i, "ato_menu_glow"..i);
	end;

	Clockwork.option:SetKey("icon_data_classes", {path = "", size = 32});
	Clockwork.option:SetKey("icon_data_settings", {path = "atomic/hud/menuitems/settings.png", size = 32});
	Clockwork.option:SetKey("icon_data_perks", {path = "atomic/hud/menuitems/perks.png", size = 32});
	Clockwork.option:SetKey("icon_data_donations", {path = "", size = 32});
	Clockwork.option:SetKey("icon_data_system", {path = "atomic/hud/menuitems/system.png", size = 32});
	Clockwork.option:SetKey("icon_data_scoreboard", {path = "atomic/hud/menuitems/scoreboard.png", size = 32});
	Clockwork.option:SetKey("icon_data_inventory", {path = "atomic/hud/menuitems/inventory.png", size = 32});
	Clockwork.option:SetKey("icon_data_directory", {path = "atomic/hud/menuitems/directory.png", size = 32});
	Clockwork.option:SetKey("icon_data_attributes", {path = "atomic/hud/menuitems/skills.png", size = 32});
	Clockwork.option:SetKey("icon_data_special", {path = "atomic/hud/menuitems/special.png", size = 32});
	Clockwork.option:SetKey("icon_data_business", {path = "", size = 32});
end;

-- Called just before a bar is drawn.
function THEME.module:PreDrawBar(barInfo)
	if (barInfo.text) then
		barInfo.text = string.upper(barInfo.text);
	end;
end;

-- Called just after a bar is drawn.
function THEME.module:PostDrawBar(barInfo)
end;

-- Called when the menu is opened.
function THEME.module:MenuOpened()
	if (Clockwork.Client:HasInitialized()) then
		Clockwork.kernel:RegisterBackgroundBlur("MainMenu", SysTime());
	end;
end;

-- Called when the menu is closed.
function THEME.module:MenuClosed()
	if (Clockwork.Client:HasInitialized()) then
		Clockwork.kernel:RemoveBackgroundBlur("MainMenu");
	end;
end;

-- Called just before the weapon selection info is drawn.
function THEME.module:PreDrawWeaponSelectionInfo(info)
	THEME:DrawAtomicBorder(info)
	info.drawBackground = false;
end;

-- Called when the weapon list is drawn.
function THEME.module:DrawWeaponList(x, y, w, h, alpha, wepType)
	if (wepType == "current" and alpha) then
		local color = Clockwork.option:GetColor("information");
		
		Atomic.Draw:WeaponSelect(x, y, w, h, color);
	end;
end;

-- A function to draw a border.
function THEME:DrawAtomicBorder(info)
	local color = Clockwork.option:GetColor("information");
	local colorBlack = Color(10, 10, 10, 255);
	local colorDarker = Color(
		math.max(color.r - 130, 0),
		math.max(color.g - 130, 0),
		math.max(color.b - 130, 0),
		150
	);

	draw.RoundedBox(0, info.x, info.y, info.width, info.height, colorDarker); --BACKGROUND--

	if (info.lines) then
		local colorDarkest = Color(
			math.max(color.r - 150, 0),
			math.max(color.g - 150, 0),
			math.max(color.b - 150, 0),
			180
		);

		for i = 1, (info.height / 4) - 2 do
			draw.RoundedBox(0, info.x, i * 4 + 5, info.width, 1, colorDarkest);
		end;
	end;
	
	DisableClipping(true);
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + 1, info.width + 6, 2, color, "down");
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + info.height - 3, info.width + 6, 2, color, "up");

		Atomic.Draw:ShadowedLine(info.x - 3, info.y + 3, 2, 12, color, "rightdown");
		Atomic.Draw:ShadowedLine(info.x + info.width + 1, info.y + 3, 2, 12, color, "leftdown");
		
		Atomic.Draw:ShadowedLine(info.x - 3, info.y + info.height - 15, 2, 12, color, "rightup");
		Atomic.Draw:ShadowedLine(info.x + info.width + 1, info.y + info.height - 15, 2, 12, color, "leftup");
	DisableClipping(false);
end;

-- Called just before the local player's information is drawn.
function THEME.module:PreDrawPlayerInfo(boxInfo, information, subInformation)
	THEME:DrawAtomicBorder(boxInfo);
	
	boxInfo.drawBackground = false;
end;

-- Called after the character menu has initialized.
function THEME.hooks:PostCharacterMenuInit(panel) end;

-- Called every frame that the character menu is open.
function THEME.hooks:PostCharacterMenuThink(panel) end;

-- Called after the character menu is painted.
function THEME.hooks:PostCharacterMenuPaint(panel) end;

-- Called after a character menu panel is opened.
function THEME.hooks:PostCharacterMenuOpenPanel(panel) end;

-- Called after the main menu has initialized.
function THEME.hooks:PostMainMenuInit(panel) end;

-- Called after the main menu is rebuilt.
function THEME.hooks:PostMainMenuRebuild(panel)
	for k, v in pairs(Clockwork.menu:GetItems()) do
		if (IsValid(v.button)) then
			v.button.canOutline 	= true;
			v.button.isMenu 		= true;
		end;
	end;

	panel.closeMenu.canOutline 		= true;
	panel.closeMenu.isMenu 			= true;

	panel.characterMenu.canOutline 	= true;
	panel.characterMenu.isMenu 		= true;
end;

-- Called after a main menu panel is opened.
function THEME.hooks:PostMainMenuOpenPanel(panel, panelToOpen) end;

-- Called after the main menu is painted.
function THEME.hooks:PostMainMenuPaint(panel) end;

-- Called every frame that the main menu is open.
function THEME.hooks:PostMainMenuThink(panel) end;

Clockwork.theme:HookReplace("cwScoreboard", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

Clockwork.theme:HookReplace("cwAttributes", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

Clockwork.theme:HookReplace("cwSettings", "Paint", function(PANEL, w, h)
	THEME:DrawAtomicBorder({
		x = 0,
		y = 0,
		width = w,
		height = h
	});

	return true;
end);

Clockwork.theme:HookAfter("cwInventory", "Init", function(PANEL)
	PANEL.inventoryList:SetPadding(10);
 	PANEL.inventoryList:SetSpacing(8);
 	PANEL.equipmentList:SetPadding(10);
 	PANEL.equipmentList:SetSpacing(8);

	function PANEL.inventoryList.Paint(invList, w, h)
		THEME:DrawAtomicBorder({
			x = 0,
			y = 0,
			width = w,
			height = h
		});

		return true;
	end;

	function PANEL.equipmentList.Paint(invList, w, h)
		THEME:DrawAtomicBorder({
			x = 0,
			y = 0,
			width = w,
			height = h
		});

		return true;
	end;
end);

--[[
Clockwork.theme:HookReplace("cwLabelButton", "Think", function(PANEL)
	if (PANEL.animation) then
		PANEL.animation:Run();
	end;
	
	if (PANEL.canOutline and !PANEL.isMenu) then
		local color = Clockwork.option:GetColor("information");
		local colorDisabled = Color(
			math.max(color.r - 170, 0),
			math.max(color.g - 170, 0),
			math.max(color.b - 170, 0),
			255
		);
		
		if (PANEL:GetDisabled()) then
			PANEL:SetTextColor(PANEL.OverrideColorHover or colorDisabled);
		else
			PANEL:SetTextColor(PANEL.OverrideColorNormal or color);
		end;
		
		PANEL:SetExpensiveShadow(1, Color(0, 0, 0, 150));
	end;
end);

Clockwork.theme:HookReplace("cwLabelButton", "SetCallback", function(PANEL, Callback)
	PANEL.DoClick = function(button)
		if (button.canOutline and !button.isMenu) then
			surface.PlaySound("atomic/pipboy_t3_press.wav");
		end;

		Callback(button);
	end;
end);

Clockwork.theme:HookReplace("cwLabelButton", "Paint", function(PANEL, w, h)
	if (PANEL.canOutline and PANEL:IsHovered()) then
		local color = Clockwork.option:GetColor("information");

		surface.SetDrawColor(color.r, color.g, color.b, 25);
		surface.DrawRect(0, 0, w, h);

		surface.SetDrawColor(color.r, color.g, color.b, 255);

		for i=0, 3 do
			surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
		end;

		if (!PANEL.played) then
			surface.PlaySound("atomic/pipboy_rollover.wav");

			PANEL.played = true
		end;
	else
		if (PANEL.played) then
			PANEL.played = nil;
		end;
	end;
end);

--]]

local PANEL = {};

-- A function to add a new sheet.
function PANEL:AddSheet(label, panel, material)
	if (!IsValid(panel)) then
		return;
	end;
	
	local newSheet = {};
	
	if (self.ButtonOnly) then
		newSheet.Button = vgui.Create("DImageButton", self.Navigation);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 1, 0, 0);
	else
		newSheet.Button = vgui.Create("cwIconButton", self.Navigation);
		
		local size = Clockwork.fonts:GetSize(Clockwork.option:GetFont("menu_text_tiny"), 20);
	
		newSheet.Button:SetTall(32);
		newSheet.Button:Dock(TOP);
		newSheet.Button:DockMargin(0, 0, 0, 8);
		newSheet.Button:SetFont(size);
		
		newSheet.Button.Paint = function(sheet, w, h)
			local color = Clockwork.option:GetColor("information");

			sheet:SetColor(color);
			sheet:SetExpensiveShadow(1, color);
		end;
	end;
	
	newSheet.Button:SetImage(material);
	newSheet.Button.Target = panel;
	newSheet.Button:SetText(label);
	newSheet.Button.DoClick = function()
		self:SetActiveButton(newSheet.Button)
	end;
	
	newSheet.Panel = panel;
	newSheet.Panel:SetParent(self.Content);
	newSheet.Panel:SetVisible(false);
	
	if (self.ButtonOnly) then
		newSheet.Button:SizeToContents();
	end;
	
	table.insert(self.Items, newSheet)
	
	if (!IsValid(self.ActiveButton)) then
		self:SetActiveButton(newSheet.Button);
	end;
end;

-- A function to set the active button.
function PANEL:SetActiveButton(active)
	if (self.ActiveButton == active) then
		return;
	end;
	
	if (self.ActiveButton && self.ActiveButton.Target) then	
		self.ActiveButton.Target:SetVisible(false)
		self.ActiveButton:SetSelected(false)

		self.ActiveButton.Paint = function(sheet, w, h)
			local color = Clockwork.option:GetColor("information");

			sheet:SetColor(color);
			sheet:SetExpensiveShadow(1, color);
		end;
	end;

	self.ActiveButton = active;
	
	active.Target:SetVisible(true);
	active:SetSelected(true);

	active.Paint = function(sheet, w, h)
		local color = Clockwork.option:GetColor("information");

		surface.SetDrawColor(color.r, color.g, color.b, 50);
		surface.DrawRect(0, 0, w, h);

		surface.SetDrawColor(color.r, color.g, color.b, alpha);

		for i= 0, 2 do
			surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2);
		end;

		sheet:SetColor(color);
		sheet:SetExpensiveShadow(1, color);
	end;
	
	self.Content:InvalidateLayout();
end
	
vgui.Register("cwColumnSheet", PANEL, "DColumnSheet");

THEME.skin.frameBorder = Color(255, 255, 255, 255);
THEME.skin.frameTitle = Color(255, 255, 255, 255);

THEME.skin.bgColorBright = Color(255, 255, 255, 255);
THEME.skin.bgColorSleep = Color(70, 70, 70, 255);
THEME.skin.bgColorDark = Color(50, 50, 50, 255);
THEME.skin.bgColor = Color(40, 40, 40, 225);

THEME.skin.controlColorHighlight = Color(70, 70, 70, 255);
THEME.skin.controlColorActive = Color(175, 175, 175, 255);
THEME.skin.controlColorBright = Color(100, 100, 100, 255);
THEME.skin.controlColorDark = Color(30, 30, 30, 255);
THEME.skin.controlColor = Color(60, 60, 60, 255);

THEME.skin.colPropertySheet = Color(255, 255, 255, 255);
THEME.skin.colTabTextInactive = Color(0, 0, 0, 255);
THEME.skin.colTabInactive = Color(255, 255, 255, 255);
THEME.skin.colTabShadow = Color(0, 0, 0, 170);
THEME.skin.colTabText = Color(255, 255, 255, 255);
THEME.skin.colTab = Color(0, 0, 0, 255);

THEME.skin.fontCategoryHeader = "ato_MainText";
THEME.skin.fontMenuOption = "ato_MainText";
THEME.skin.fontFormLabel = "ato_MainText";
THEME.skin.fontButton = "ato_MainText";
THEME.skin.fontFrame = "ato_MainText";
THEME.skin.fontTab = "ato_MainText";

-- A function to draw a generic background.
function THEME.skin:DrawGenericBackground(x, y, w, h, color)
	surface.SetDrawColor(color);
	surface.DrawRect(x, y, w, h);
end;

-- Called when a frame is layed out.
function THEME.skin:LayoutFrame(panel)
	panel.lblTitle:SetFont(self.fontFrame);
	panel.lblTitle:SetText(panel.lblTitle:GetText():upper());
	panel.lblTitle:SetTextColor(Color(0, 0, 0, 255));
	panel.lblTitle:SizeToContents();
	panel.lblTitle:SetExpensiveShadow(nil);
	
	panel.btnClose:SetDrawBackground(true);
	panel.btnClose:SetPos(panel:GetWide() - 22, 2);
	panel.btnClose:SetSize(18, 18);
	panel.lblTitle:SetPos(8, 2);
	panel.lblTitle:SetSize(panel:GetWide() - 25, 20);
end;

-- Called when a form is schemed.
function THEME.skin:SchemeForm(panel)
	panel.Label:SetFont(self.fontFormLabel);
	panel.Label:SetText(panel.Label:GetText():upper());
	panel.Label:SetTextColor(Color(255, 255, 255, 255));
	panel.Label:SetExpensiveShadow(1, Color(0, 0, 0, 200));
end;

-- Called when a tab is painted.
function THEME.skin:PaintTab(panel)
	if (panel:GetPropertySheet():GetActiveTab() == panel) then
		self:DrawGenericBackground(1, 1, panel:GetWide() - 2, panel:GetTall() + 8, self.colTab);
	else
		self:DrawGenericBackground(1, 2, panel:GetWide() - 2, panel:GetTall() + 8, self.colTabInactive);
	end;
end;

-- Called when a list view is painted.
function THEME.skin:PaintListView(panel)
	if (panel.m_bBackground) then
		surface.SetDrawColor(255, 255, 255, 255);
		panel:DrawFilledRect();
	end;
end;
	
-- Called when a list view line is painted.
function THEME.skin:PaintListViewLine(panel)
	local color = Color(50, 50, 50, 255);
	local textColor = Color(255, 255, 255, 255);
	
	if (panel:IsSelected()) then
		color = Color(255, 255, 255, 255);
		textColor = Color(0, 0, 0, 255);
	elseif (panel.Hovered) then
		color = Color(100, 100, 100, 255);
	elseif (panel.m_bAlt) then
		color = Color(75, 75, 75, 255);
	end;
	
	for k, v in pairs(panel.Columns) do
		v:SetTextColor(textColor);
	end;
 
	surface.SetDrawColor(color.r, color.g, color.b, color.a);
	surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall());
end;

-- Called when a list view label is schemed.
function THEME.skin:SchemeListViewLabel(panel)
	panel:SetTextInset(3);
	panel:SetTextColor(Color(255, 255, 255, 255));
end;

-- Called when a menu is painted.
function THEME.skin:PaintMenu(panel)
	surface.SetDrawColor(Color(0, 0, 0, 255));
	panel:DrawFilledRect(0, 0, w, h);
end;

-- Called when a menu is painted over.
function THEME.skin:PaintOverMenu(panel) end;

-- Called when a menu option is schemed.
function THEME.skin:SchemeMenuOption(panel)
	panel:SetFGColor(255, 255, 255, 255);
end;

-- Called when a menu option is painted.
function THEME.skin:PaintMenuOption(panel)
	local textColor = Color(255, 255, 255, 255);
	
	if (panel.m_bBackground and panel.Hovered) then
		local color = nil;

		if (panel.Depressed) then
			color = Color(225, 225, 225, 255);
		else
			color = Color(255, 255, 255, 255);
		end;

		surface.SetDrawColor(color.r, color.g, color.b, color.a);
		surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall());
		
		textColor = Color(0, 0, 0, 255);
	end;
	
	panel:SetFGColor(textColor);
end;

-- Called when a menu option is layed out.
function THEME.skin:LayoutMenuOption(panel)
	panel:SetFont(self.fontMenuOption);
	panel:SizeToContents();
	panel:SetWide(panel:GetWide() + 30);
	panel:SetSize(math.max(panel:GetParent():GetWide(), panel:GetWide()), 18);
	
	if (panel.SubMenuArrow) then
		panel.SubMenuArrow:SetSize(panel:GetTall(), panel:GetTall());
		panel.SubMenuArrow:CenterVertical();
		panel.SubMenuArrow:AlignRight();
	end;
end;

-- Called when a button is painted.
function THEME.skin:PaintButton(panel)
	local w, h = panel:GetSize();
	local textColor = Color(255, 255, 255, 255);
	
	if (panel.m_bBackground) then
		local color = Color(0, 0, 0, 255);
		local borderColor = Color(255, 255, 255, 255);
		
		if (panel:GetDisabled()) then
			color = self.controlColorDark;
		elseif (panel.Depressed or panel:GetSelected()) then
			color = Color(255, 255, 255, 255);
			textColor = Color(0, 0, 0, 255);
		elseif (panel.Hovered) then
			color = self.controlColorHighlight;
		end;

		self:DrawGenericBackground(0, 0, w, h, borderColor);
		self:DrawGenericBackground(1, 1, w - 2, h - 2, color);
	end;
	
	panel:SetFGColor(textColor);
end;

-- Called when a scroll bar grip is painted.
function THEME.skin:PaintScrollBarGrip(panel)
	local w, h = panel:GetSize();
	local color = Color(255, 255, 255, 255);

	self:DrawGenericBackground(0, 0, w, h, color);
	self:DrawGenericBackground(2, 2, w - 4, h - 4, Color(0, 0, 0, 255));
end;

Clockwork.theme:Finish(THEME);