--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local surface = surface;
local LEFT_SEPERATOR = Material("atomic/hud/hud_left.png");
local RIGHT_SEPERATOR = Material("atomic/hud/hud_right.png");
local MENU_TICK = Material("atomic/hud/hud_tick_mark.png");
local COMP_STRIP = Material("atomic/hud/hud_comp.png");
local ARMOR_EMPTY = Material("atomic/hud/armor_empty.png");
local ARMOR_FILL = Material("atomic/hud/armor_fill.png");
local ARMOR_BROKEN = Material("atomic/hud/armor_broken.png");
local CROSSHAIR = Material("atomic/hud/crosshair.png");
local CROSSHAIR_FILL = Material("atomic/hud/crosshair_filled.png");
local XP_BAR = Material("atomic/hud/xp_bar.png");
local XP_POINTER = Material("atomic/hud/xp_pointer.png");
local gradMat = Material("atomic/hud/line/fade_to_top.png");
local MAT_UP = Material("atomic/hud/arrow_up.png");
local MAT_DOWN = Material("atomic/hud/arrow_down.png");
local RADAR_TICK = Material("atomic/hud/vert_scrollbar.png");

-- Called when the menu's items should be destroyed.
function Atomic:MenuItemsDestroy(menuItems)
--	if (!Clockwork.player:HasFlags(Clockwork.Client, "T")) then
		menuItems:Destroy(Clockwork.option:GetKey("name_business"));
--	end;
end;

-- Called when the menu's items should be destroyed.
function Atomic:MenuItemsAdd(menuItems)
	if (Clockwork.config:Get("enable_special"):Get()) then
		menuItems:Add("SPECIAL", "cwSpecial", "View your current SPECIAL stats.", Clockwork.option:GetKey("icon_data_special"));
	end;

	if (#Clockwork.Client:GetPerks() > 0) then
		menuItems:Add("PERKS", "cwPerks", "View your current perks.", Clockwork.option:GetKey("icon_data_perks"));
	end;
end;

-- Called when a player's scoreboard options are needed.
function Atomic:GetPlayerScoreboardOptions(player, options, menu)
	if (Clockwork.command:FindByID("CharSetCustomClass") != nil) then
		if ( Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharSetCustomClass").access) ) then
			options["Custom Class"] = {};
			options["Custom Class"]["Set"] = function()
				Derma_StringRequest(player:Name(), "What would you like to set their custom class to?", player:GetSharedVar("customClass"), function(text)
					Clockwork.kernel:RunCommand("CharSetCustomClass", player:Name(), text);
				end);
			end;
			
			if (player:GetSharedVar("customClass") != "") then
				options["Custom Class"]["Take"] = function()
					Clockwork.kernel:RunCommand( "CharTakeCustomClass", player:Name() );
				end;
			end;
		end;
	end;
end;

-- Called when a player's scoreboard class is needed.
function Atomic:GetPlayerScoreboardClass(player)
	local customClass = player:GetSharedVar("customClass");
	
	if (customClass != "") then
		return customClass;
	end;
end;

-- Called when the local player's item functions should be adjusted.
function Atomic:PlayerAdjustItemFunctions(itemTable, itemFunctions)
	--[[
	MAKE THIS A PERK
	if (Clockwork.player:HasFlags(Clockwork.Client, "T") and itemTable.cost) then
		itemFunctions[#itemFunctions + 1] = "Caps";
	end;
	]]--
end;

-- Called when the local player's character screen faction is needed.
function Atomic:GetPlayerCharacterScreenFaction(character)
	if (character.customClass and character.customClass != "") then
		return character.customClass;
	end;
end;

-- Called when the local player's default color modify should be set.
function Atomic:PlayerSetDefaultColorModify(colorModify)
	colorModify["$pp_colour_brightness"] = -0.02;
	colorModify["$pp_colour_contrast"] = 1.1;
	colorModify["$pp_colour_colour"] = 0.6;
end;

-- Called when the schema initializes.
function Atomic:Initialize()
	CW_CONVAR_FOHUD = Clockwork.kernel:CreateClientConVar("cwFallout3HUD", 1, true, true);
	CW_CONVAR_FO4HUD = Clockwork.kernel:CreateClientConVar("cwFallout4HUD", 1, true, true);

	if (CW_CONVAR_FOHUD:GetInt() == 1) then
		Clockwork.chatBox:SetCustomPosition(50, ScrH() - 200);
	end;
end;

-- Called when a ConVar has changed.
function Atomic:ClockworkConVarChanged()
	if (CW_CONVAR_FOHUD:GetInt() == 1 or CW_CONVAR_FO4HUD:GetInt() == 1) then
		Clockwork.chatBox:SetCustomPosition(50, ScrH() - 200);
	else
		Clockwork.chatBox:ResetCustomPosition();
	end;

	local color = Color(
		GetConVarNumber("cwTextColorR"), 
		GetConVarNumber("cwTextColorG"), 
		GetConVarNumber("cwTextColorB"), 
		GetConVarNumber("cwTextColorA")
	);

	Clockwork.option:SetColor("basic_form_highlight", color);
	Clockwork.option:SetColor("basic_form_color", color);
	Clockwork.option:SetColor("scoreboard_name", color);
	Clockwork.option:SetColor("scoreboard_desc", color);
	Clockwork.option:SetColor("target_id", color);
end;

-- Called when an entity's target ID HUD should be painted.
function Atomic:HUDPaintEntityTargetID(entity, info)
	local infoColor = Clockwork.option:GetColor("information");
	local color = Color(infoColor.r, infoColor.g, infoColor.b, info.alpha);
	
	if (entity:GetClass() == "prop_physics") then
		local physDesc = entity:GetNetworkedString("physDesc");
		
		if (physDesc != "") then
			info.y = Clockwork.kernel:DrawInfo(physDesc, info.x, info.y, color, info.alpha);
		end;
	end;
end;

-- Called before the item entity's target ID is drawn. Return false to stop default draw.
function Atomic:PaintItemTargetID(x, y, alpha, itemTable)
	local trace = Clockwork.Client:GetEyeTraceNoCursor();
	local entity = trace.Entity;

	if (entity and entity:NearestPoint(trace.StartPos):Distance(trace.StartPos) <= 80) then
		Atomic:DrawInfoUI(itemTable("name"), "WG", itemTable("weight"), "VAL", itemTable("cost"), alpha);
	end;

	return false;
end;

-- Called to draw the player's crosshair.
function Atomic:DrawPlayerCrosshair(x, y, color)
	return false;
end;

local factions = {
	["Brotherhood of Steel"] = {
		"Crimson Caravan",
		"Wastelander"
	},
	["Crimson Caravan"] = {
		"Crimson Caravan",
		"Wastelander",
		"Enclave",
		"New California Republic",
		"Brotherhood of Steel",
		"Caesar's Legion"
	},
	["Enclave"] = {
		"Crimson Caravan"
	},
	["Caesar's Legion"] = {
		"Crimson Caravan"
	},
	["New California Republic"] = {
		"Crimson Caravan",
		"Wastelander"
	},
	["Raider"] = {
		"nope"
	},
	["Wastelander"] = {
		"Crimson Caravan",
		"New California Republic",
		"Brotherhood of Steel"
	}
};

function Atomic:IsFactionFriendly(fac1, fac2)
	if (fac1 == fac2) then return true; end;
	if (!fac1 or !fac2) then return false; end;
	if (fac1 == "Raider" or fac2 == "Raider") then return false; end;
		
	local one, two = false, false;
		
	for k, v in pairs(factions[fac1]) do
		if (v == fac2) then
			one = true;
		end;
	end;
		
	for k, v in pairs(factions[fac2]) do
		if (v == fac1) then
			two = true;
		end;
	end;
		
	if (one or two) then
		return true;
	end;
		
	return false;
end;

function Atomic:GetRadarTable()
	local trace = LocalPlayer():GetEyeTraceNoCursor();
	local entTable = ents.FindInCone(trace.StartPos, trace.Normal, 1024, 0);
	local radarTable = {};

	for k, v in pairs(entTable) do
		if (v:IsValid() and v != Clockwork.Client) then
			if (Atomic:CanSeeBlip(v)) then
				local entry = {ent = v, color = Clockwork.option:GetColor("information")};

				if (v:IsPlayer()) then				
					local bIsFriendly = self:IsFactionFriendly(v:GetFaction(), LocalPlayer():GetFaction());
									
					if (!bIsFriendly) then entry.color = Color(240, 70, 20, 255); end;
				else
					if (!v.radarColor) then
						Clockwork.datastream:Request("GetEntityRelationship", {v:GetClass(), Clockwork.Client:Name()}, function(data)
							if (data == 1) then entry.color = Color(240, 70, 20, 255); v.radarColor = entry.color; end;
						end);
					else
						entry.color = v.radarColor;
					end;
				end;

				table.insert(radarTable, entry);
			end;
		end;
	end;

	return radarTable;
end;

-- A function to draw the F03/NV styled HUD.
function Atomic:DrawFO3HUD(color, found, nextFind)
	local width = 385
	local height = 140;
	local x = ScrW() - width - 40;
	local y = ScrH() - height - 20;
	local tickWidth = 8;
	local tickHeight = 25;
	local tickX = x + 363;
	local tickY = y + 47;
	local tickColor = Color(color.r, color.g, color.b, 200);
	local skillDisplay = self.skillDisplay;
	local curTime = CurTime();
	local entity = Clockwork.Client:GetEyeTraceNoCursor().Entity;

	if (Clockwork.plugin:Call("CanDrawHUD", "XPBar")) then
		if (skillDisplay) then
			self:DrawXPBar(skillDisplay.name, Clockwork.attributes:Get(skillDisplay.name) or 1);
		end;
	end;

	if (Clockwork.plugin:Call("CanDrawHUD", "Sneak")) then
		if (Clockwork.Client:Crouching()) then
			draw.SimpleText("[SNEAK]", Clockwork.option:GetFont("hud_text_blur"), ScrW() / 2, 20, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER);
			draw.SimpleText("[SNEAK]", Clockwork.option:GetFont("hud_text"), ScrW() / 2, 20, color, TEXT_ALIGN_CENTER);
		end;
	end;

	if (Clockwork.plugin:Call("CanDrawHUD", "Crosshair")) then
		local info = {
			x = ScrW() / 2,
			y = ScrH() / 2
		};

		local crosshairMat = CROSSHAIR;

		if (self.crosshairFill) then
			crosshairMat = CROSSHAIR_FILL;
		end;

		Clockwork.plugin:Call("GetPlayerCrosshairInfo", info);

		surface.SetDrawColor(color);
		surface.SetMaterial(crosshairMat);
		surface.DrawTexturedRect(info.x - 32, info.y - 32, 64, 64);

		self.crosshairFill = false;
	end;

	if (Clockwork.plugin:Call("CanDrawHUD", "UseUI")) then
		local eyePos = Clockwork.Client:EyePos();

		if (entity and entity:IsValid() and entity:NearestPoint(eyePos):Distance(eyePos) <= 80) then
			local entityOptions = {};
			local canDraw = false;
			local useText = "Use";
			local useTable = {};
	
			Clockwork.plugin:Call("GetEntityMenuOptions", entity, entityOptions);

			--[[
				I don't know why checking the number of entries in the table doesn't work, but this dumb way works.
			--]]
			for k, v in pairs(entityOptions) do
				if (k or v) then
					canDraw = true;

					table.insert(useTable, k);
				end;
			end;

			local useNum = #useTable;

			if (useNum == 1) then
				useText = useTable[1];
			elseif (useNum > 1) then
				useText = "Use ["..tostring(useNum).."]";
			end;

			if (canDraw or entity:GetClass() == "cw_item") then
				local alpha = Clockwork.kernel:CalculateAlphaFromDistance(255, Clockwork.Client, entity);
				local y = ScrH() - 160;

				self.crosshairFill = true;

				draw.SimpleText("E) "..useText, Clockwork.option:GetFont("hud_text_blur"), ScrW() / 2, y - 35, Color(0, 0, 0, alpha), TEXT_ALIGN_CENTER);
				draw.SimpleText("E) "..useText, Clockwork.option:GetFont("hud_text"), ScrW() / 2, y - 35, Color(color.r, color.g, color.b, alpha), TEXT_ALIGN_CENTER);
			end;
		end;
	end;

	local compX = 50;
	local compW = 312;
	local h = ScrH() - 50;

	if (Clockwork.plugin:Call("CanDrawHUD", "Compass")) then
		local compPart = -Clockwork.Client:GetAngles().y;

		if (compPart < 0) then
			compPart = (180 + compPart) + 180;
		end;				

		if (!nextFind or nextFind <= CurTime()) then
			found = self:GetRadarTable()

			nextFind = CurTime() + 1;
		end;

		-- Radar (EVS)
		render.SetScissorRect(compX + 7, h, compX + compW, h - 72, true);
			if (#found > 0) then
				for k, v in pairs(found) do
					if (v.ent:IsValid()) then
						local pos = v.ent:GetPos();
						local plyPos = LocalPlayer():GetPos();						
						local mark = (pos + Vector(0, 0, 16)):ToScreen();

						surface.SetDrawColor(0, 0, 0, 255);
						surface.SetMaterial(RADAR_TICK);
						surface.DrawTexturedRect(compX + mark.x * (compW / ScrW()) - 13, h - 34, 36, 22);

						surface.SetDrawColor(v.color);
						surface.SetMaterial(RADAR_TICK);
						surface.DrawTexturedRect(compX + mark.x * (compW / ScrW()) - 11, h - 32, 32, 18);

						if ((pos.z - plyPos.z) >= 60) then
							surface.SetMaterial(MAT_UP);
							surface.DrawTexturedRect(compX + mark.x * (compW / ScrW()) - 4, h - 32, 19, 17);
						elseif ((plyPos.z - pos.z) >= 60) then
							surface.SetMaterial(MAT_DOWN);
							surface.DrawTexturedRect(compX + mark.x * (compW / ScrW()) - 4, h - 32, 19, 17);
						end;
					end;
				end;
			end;
		render.SetScissorRect(0, 0, 0, 0, false);

		surface.SetDrawColor(color);
		surface.SetMaterial(COMP_STRIP);
		surface.DrawPartialTexturedRect(compX, ScrH() - 90, compW, 64, (1024 / 360) * compPart, 0, compW, 64, 1336, 64);
	end;

	if (Clockwork.plugin:Call("CanDrawHUD", "RightFrame")) then
		local stamina = Clockwork.Client:GetSharedVar("Stamina");
		local progress = math.ceil((38 * 0.01) * stamina);
		local weapon = Clockwork.Client:GetActiveWeapon();
				
		if (weapon and IsValid(weapon)) then
			local itemTable = Clockwork.item:GetByWeapon(weapon);

			if (weapon.Clip1) then
				local clipOne = weapon:Clip1();

				if (clipOne >= 0) then
					local ammoString = (clipOne.."/"..Clockwork.Client:GetAmmoCount(weapon:GetPrimaryAmmoType()))

					draw.SimpleText(ammoString, Clockwork.option:GetFont("hud_text_blur"), x + width - 30, tickY + 25, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
					draw.SimpleText(ammoString, Clockwork.option:GetFont("hud_text"), x + width - 30, tickY + 25, color, TEXT_ALIGN_RIGHT);
				end;
			end;

			if (itemTable) then
				local health = itemTable.health or 200
				local dura = (itemTable:GetData("Condition") / health) * 100;

				if (dura) then
					local barColor = Color(math.max(color.r - 70, 0), math.max(color.g - 70, 0), math.max(color.b - 70, 0), color.a);

					draw.SimpleText("CND", Clockwork.option:GetFont("hud_text_blur"), x + 120, tickY + 25, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
					draw.SimpleText("CND", Clockwork.option:GetFont("hud_text"), x + 120, tickY + 25, color, TEXT_ALIGN_RIGHT);
							
					surface.SetDrawColor(barColor);
					surface.DrawRect(x + 125, tickY + 34, 58, 19);

					local duraProg = math.ceil((58 * 0.01) * dura);
							
					surface.SetDrawColor(color);
					surface.DrawRect(x + 125, tickY + 34, duraProg, 19);						
				end;
			end;
		end;

		draw.SimpleText("STAM", Clockwork.option:GetFont("hud_text_blur"), x + width - 30, tickY - 40, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
		draw.SimpleText("STAM", Clockwork.option:GetFont("hud_text"), x + width - 30, tickY - 40, color, TEXT_ALIGN_RIGHT);
				
		for i = 1, 38 do
			if (progress != 0 and progress >= i) then
				local newTickX = tickX - ((i - 1) * tickWidth);

				if (i == 1) then
					newTickX = tickX;
				end;

				surface.SetDrawColor(tickColor);
				surface.SetMaterial(MENU_TICK);
				surface.DrawTexturedRect(newTickX, tickY, tickWidth, tickHeight);
			end;
		end;
	
		surface.SetDrawColor(color);
		surface.SetMaterial(RIGHT_SEPERATOR);
		surface.DrawTexturedRect(x, y, width, height);
	end;

	if (Clockwork.plugin:Call("CanDrawHUD", "LeftFrame")) then
		local healProgress = math.ceil((38 / Clockwork.Client:GetMaxHealth()) * Clockwork.Client:Health());

		draw.SimpleText("HP", Clockwork.option:GetFont("hud_text_blur"), 65, tickY - 40, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT);
		draw.SimpleText("HP", Clockwork.option:GetFont("hud_text"), 65, tickY - 40, color, TEXT_ALIGN_LEFT);
				
		for i = 1, 38 do
			if (healProgress != 0 and healProgress >= i) then
				local newTickX = 57 + ((i - 1) * tickWidth);

				if (i == 1) then
					newTickX = 57;
				end;

				surface.SetDrawColor(tickColor);
				surface.SetMaterial(MENU_TICK);
				surface.DrawTexturedRect(newTickX, tickY, tickWidth, tickHeight);
			end;
		end;

		surface.SetDrawColor(color);
		surface.SetMaterial(LEFT_SEPERATOR);
		surface.DrawTexturedRect(38, y, width + 2, height);

		local armor = Clockwork.Client:Armor();
		local itemTable = Clockwork.player:GetClothesItem();

		if (armor > 0) then
			local armorPercent = armor / Clockwork.Client:GetMaxArmor();

			surface.SetMaterial(ARMOR_FILL);
			surface.DrawPartialTexturedRect(30 + width, (tickY - 32) + (32 - (32 * armorPercent)), 32, 32, 0, 32 - (32 * armorPercent), 32, 32, 32, 32);

			surface.SetMaterial(ARMOR_EMPTY);
			surface.DrawTexturedRect(30 + width, tickY - 32, 32, 32);
		elseif (itemTable) then
			local itemArmor = itemTable:GetData("Armor");

			if (armor == itemArmor) then
				surface.SetDrawColor(Color(255, 0, 0, 255));
				surface.SetMaterial(ARMOR_BROKEN);
				surface.DrawTexturedRect(30 + width, tickY - 32, 32, 32);
			end;
		end;
	end;
end;

-- A function to draw the FO4-styled HUD.
function Atomic:DrawFO4HUD(color, found, nextFind)
	local w, h = ScrW(), ScrH();
	local colorDark = Color(
		math.max(color.r - 30, 0),
		math.max(color.g - 30, 0),
		math.max(color.b - 30, 0),
		255
	);
	local colorDarker = Color(
		math.max(color.r - 130, 0),
		math.max(color.g - 130, 0),
		math.max(color.b - 130, 0),
		150
	);
	local colorBlack = Color(0, 0, 0, 255);

	-- Health
	if (Clockwork.Client:Health() < Clockwork.Client:GetMaxHealth()) then
		Atomic.Draw:Bar(65, h - 91, Clockwork.Client:Health(), Clockwork.Client:GetMaxHealth(), colorBlack, {width = w / 6, height = 11});
		Atomic.Draw:Bar(64, h - 90, Clockwork.Client:Health(), Clockwork.Client:GetMaxHealth(), color, {width = w / 6, height = 11});
		surface.SetFont(Clockwork.option:GetFont("hud_text"));

		surface.SetTextColor(colorBlack);
		surface.SetTextPos(26, h - 101);
		surface.DrawText("HP");
		surface.SetTextColor(color);
		surface.SetTextPos(25, h - 100);
		surface.DrawText("HP");
	end;
				
	if (Clockwork.Client:GetSharedVar("Stamina") < 100) then
		-- Stamina
		local stamHeight = h - 90;

		if (Clockwork.Client:Health() < Clockwork.Client:GetMaxHealth()) then
			stamHeight = h - 140;
		end;

		Atomic.Draw:Bar(65, stamHeight + 1, Clockwork.Client:GetSharedVar("Stamina"), 100, colorBlack, {width = w / 6, height = 11});
		Atomic.Draw:Bar(64, stamHeight, Clockwork.Client:GetSharedVar("Stamina"), 100, color, {width = w / 6, height = 11});
		surface.SetFont(Clockwork.option:GetFont("hud_text"));

		surface.SetTextColor(colorBlack);
		surface.SetTextPos(26, stamHeight - 11);
		surface.DrawText("ST");
		surface.SetTextColor(color);
		surface.SetTextPos(25, stamHeight - 10);
		surface.DrawText("ST");
	end;

	if (Clockwork.Client:Crouching()) then
		Atomic.Draw:WeaponSelect(ScrW()/2 - 50, 26, 100, 25, color)

		draw.SimpleText("SNEAK", Clockwork.option:GetFont("hud_text_blur"), ScrW() / 2, 20, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER);
		draw.SimpleText("SNEAK", Clockwork.option:GetFont("hud_text"), ScrW() / 2, 20, color, TEXT_ALIGN_CENTER);
	end;
			
	if (Clockwork.plugin:Call("CanDrawHUD", "Crosshair")) then
		local info = {
			x = w / 2, 
			y = h / 2
		};

		Clockwork.plugin:Call("GetPlayerCrosshairInfo", info);

		if (self.crosshairFill) then
			-- left horizontal
			Atomic.Draw:ShadowedLine(info.x - 15, info.y - 27, 12, 2, color, "down");
			-- right horizontal
			Atomic.Draw:ShadowedLine(info.x - 15, info.y + 17, 12, 2, color, "down");
			-- upper
			Atomic.Draw:ShadowedLine(info.x - 15 , info.y - 25, 2, 12, color, "rightup");
			-- down
			Atomic.Draw:ShadowedLine(info.x - 15 , info.y + 5, 2, 12, color, "right");

			-- left horizontal
			Atomic.Draw:ShadowedLine(info.x + 15, info.y - 27, 12, 2, color, "down");
			-- right horizontal
			Atomic.Draw:ShadowedLine(info.x + 15, info.y + 17, 12, 2, color, "down");
			-- upper
			Atomic.Draw:ShadowedLine(info.x + 26 , info.y - 25, 2, 12, color, "rightup");
			-- down
			Atomic.Draw:ShadowedLine(info.x + 26 , info.y + 5, 2, 12, color, "right");
		elseif (Clockwork.player:GetWeaponRaised(Clockwork.Client)) then
			-- left horizontal
			Atomic.Draw:ShadowedLine(info.x - 12, info.y - 2, 8, 2, color, "down");
			-- right horizontal
			Atomic.Draw:ShadowedLine(info.x + 4, info.y - 2, 8, 2, color, "down");
			-- upper
			Atomic.Draw:ShadowedLine(info.x - 1 , info.y - 12, 2, 8, color, "rightup");
			-- down
			Atomic.Draw:ShadowedLine(info.x - 1 , info.y + 2, 2, 8, color, "right");
		else
			Atomic.Draw:ShadowedLine(info.x, info.y, 2, 2, color, "down");
		end;

		self.crosshairFill = false;
	end;
				
	-- Compass
	local compPart = Clockwork.Client:GetAngles().y;

	if (compPart < 0) then
		compPart = (180 + compPart) + 180;
	end;
					
	local compX = w / 2 - (w / 5) / 2;

	surface.SetDrawColor(colorDarker);
	surface.SetMaterial(gradMat);
	surface.DrawTexturedRect(compX, h - 105, w / 5 + 2, 30);

	Atomic.Draw:Box(compX + 2, h - 78, w / 5, 3, colorBlack);
	Atomic.Draw:Box(compX, h - 88, 3, 12, colorBlack);
	Atomic.Draw:Box(compX + (w / 5), h - 88, 3, 12, colorBlack);
			
	-- , 180, 90, 270
	local south = Atomic.Draw:AngleToRelative2D(compPart, w / 5, 1);
	local west = Atomic.Draw:AngleToRelative2D(compPart, w / 5, 2);
	local north = Atomic.Draw:AngleToRelative2D(compPart, w / 5, 3);
	local east = Atomic.Draw:AngleToRelative2D(compPart, w / 5, 4);

	render.SetScissorRect(compX, h - 78, compX + w / 5, h - 38, true);
	surface.SetFont(Clockwork.option:GetFont("hud_text"));
			
	Atomic.Draw:Box(compX + south, h - 78, 3, 11, colorBlack)
	Atomic.Draw:Box(compX + south, h - 78, 2, 10, colorDark)
	surface.SetTextPos(compX + south - 5, h - 69)
	surface.SetTextColor(colorBlack);
	surface.DrawText("N");
	surface.SetTextPos(compX + south - 6, h - 70)
	surface.SetTextColor(colorDark);
	surface.DrawText("N");

	Atomic.Draw:Box(compX + west, h - 78, 3, 11, colorBlack)
	Atomic.Draw:Box(compX + west, h - 78, 2, 10, colorDark)
	surface.SetTextPos(compX + west - 5, h - 69)
	surface.SetTextColor(colorBlack);
	surface.DrawText("W");
	surface.SetTextPos(compX + west - 6, h - 70)
	surface.SetTextColor(colorDark);
	surface.DrawText("W");

	Atomic.Draw:Box(compX + north, h - 78, 3, 11, colorBlack)
	Atomic.Draw:Box(compX + north, h - 78, 2, 10, colorDark)
	surface.SetTextPos(compX + north - 5, h - 69)
	surface.SetTextColor(colorBlack);
	surface.DrawText("S");
	surface.SetTextPos(compX + north - 6, h - 70)
	surface.SetTextColor(colorDark);
	surface.DrawText("S");

	Atomic.Draw:Box(compX + east, h - 78, 3, 11, colorBlack)
	Atomic.Draw:Box(compX + east, h - 78, 2, 10, colorDark)
	surface.SetTextPos(compX + east - 5, h - 69)
	surface.SetTextColor(colorBlack);
	surface.DrawText("E");
	surface.SetTextPos(compX + east - 6, h - 70)
	surface.SetTextColor(colorDark);
	surface.DrawText("E");

	render.SetScissorRect(0, 0, 0, 0, false);

	Atomic.Draw:Box(compX, h - 78, w / 5, 2, colorDark);
	Atomic.Draw:Box(compX, h - 88, 2, 12, colorDark);
	Atomic.Draw:Box(compX + (w / 5), h - 88, 2, 12, colorDark);

	if (!nextFind or nextFind <= CurTime()) then
		found = self:GetRadarTable()

		nextFind = CurTime() + 1;
	end;

	-- Radar (EVS)
	render.SetScissorRect(compX, h - 130, compX + w / 5, h - 72, true);
		if (#found > 0) then
			for k, v in pairs(found) do
				local pos = v.ent:GetPos();
				local plyPos = LocalPlayer():GetPos();			
				local mark = (pos + Vector(0, 0, 16)):ToScreen();

				draw.RoundedBox(0, compX + mark.x / 5, h - 104, 10, 10, Color(20, 20, 20, 255));
				draw.RoundedBox(0, compX + mark.x / 5, h - 104, 9, 9, v.color);
							
				if ((pos.z - plyPos.z) >= 60) then
					surface.SetDrawColor(v.color)
					surface.SetMaterial(MAT_UP)
					surface.DrawTexturedRect(compX + mark.x / 5 - 4, h - 120, 19, 17)
					surface.SetTextPos(compX + mark.x / 5 - 3, h - 122)
				elseif ((plyPos.z - pos.z) >= 60) then
					surface.SetDrawColor(v.color)
					surface.SetMaterial(MAT_DOWN)
					surface.DrawTexturedRect(compX + mark.x / 5 - 4, h - 96, 19, 17)
					surface.SetTextPos(compX + mark.x / 5 - 3, h - 122)
				end;
			end;
		end;
	render.SetScissorRect(0, 0, 0, 0, false);

	-- Ammo
	local weapon = Clockwork.Client:GetActiveWeapon();
				
	if (weapon) then
		if (weapon.Clip1) then
			local clipOne = weapon:Clip1();
						
			if (clipOne >= 0) then
				local Ammo = Clockwork.Client:GetAmmoCount(weapon:GetPrimaryAmmoType())
				
				surface.SetFont(Clockwork.option:GetFont("hud_text_big"))

				surface.SetTextColor(colorBlack);
				surface.SetTextPos(w - 89, h - 251)
				surface.DrawText(Atomic.Draw:StyleNumber(clipOne));
				surface.SetTextColor(color);
				surface.SetTextPos(w - 90, h - 252)
				surface.DrawText(Atomic.Draw:StyleNumber(clipOne));
						
				surface.SetTextColor(colorBlack);	
				surface.SetTextPos(w - 89, h - 194)
				surface.DrawText(Atomic.Draw:StyleNumber(Ammo));
				surface.SetTextColor(color);	
				surface.SetTextPos(w - 90, h - 195)
				surface.DrawText(Atomic.Draw:StyleNumber(Ammo));
						
				Atomic.Draw:Box(w - 87, h - 195, 69, 4, colorBlack);
				Atomic.Draw:Box(w - 87, h - 195, 68, 3, color);
			end;
		end;
	end;
					
	-- Armor
	if (Clockwork.Client:Armor() > 0) then
		Atomic.Draw:ReversedBar(w - (w / 6 + 63), h - 89, Clockwork.Client:Armor(), 100, colorBlack, {width = w / 6, height = 11});
		Atomic.Draw:ReversedBar(w - (w / 6 + 64), h - 90, Clockwork.Client:Armor(), 100, color, {width = w / 6, height = 11});

		surface.SetFont(Clockwork.option:GetFont("hud_text"));

		surface.SetTextColor(colorBlack);
		surface.SetTextPos(w - 49, h - 99)
		surface.DrawText("AP");
		surface.SetTextColor(color);
		surface.SetTextPos(w - 50, h - 100)
		surface.DrawText("AP");
	end;

	local entity = Clockwork.Client:GetEyeTraceNoCursor().Entity;
	local eyePos = Clockwork.Client:EyePos();

	if (entity and entity:NearestPoint(eyePos):Distance(eyePos) <= 80) then
		local entityOptions = {};
		local canDraw = false;
		local useText = "Use";
		local useTable = {};
		Clockwork.plugin:Call("GetEntityMenuOptions", entity, entityOptions);

		--[[
			I don't know why checking the number of entries in the table doesn't work, but this dumb way works.
		--]]
		for k, v in pairs(entityOptions) do
			if (k or v) then
				canDraw = true;

				table.insert(useTable, k);
			end;
		end;

		local useNum = #useTable;

		if (useNum == 1) then
			useText = useTable[1];
		elseif (useNum > 1) then
			useText = "Use ["..tostring(useNum).."]";
		end;

		if (canDraw or entity:GetClass() == "cw_item") then
			local y = ScrH() * 0.55;

			Atomic.crosshairFill = true;

			surface.SetFont(Clockwork.option:GetFont("hud_text"));
			local textX, textY = surface.GetTextSize(useText);
			local eX = ScrW() * 0.665 - (textX /2);

			draw.SimpleText("Ⓔ", Clockwork.option:GetFont("hud_text_big"), eX + 1, y - 49, colorBlack, TEXT_ALIGN_RIGHT);
			draw.SimpleText("Ⓔ", Clockwork.option:GetFont("hud_text_big"), eX, y - 50, Color(color.r, color.g, color.b, 255), TEXT_ALIGN_RIGHT);
					
			draw.SimpleText(useText, Clockwork.option:GetFont("hud_text"), ScrW() * 0.67 + 1, y - 34, colorBlack, TEXT_ALIGN_CENTER);
			draw.SimpleText(useText, Clockwork.option:GetFont("hud_text"), ScrW() * 0.67, y - 35, Color(color.r, color.g, color.b, 255), TEXT_ALIGN_CENTER);
		end;
	end;
end;

-- Called when the HUD is painted.
function Atomic:HUDPaint()
	if (!Clockwork.kernel:IsChoosingCharacter() and Clockwork.Client:Health() > 0 and !Clockwork.Client:IsRagdolled()) then
		local color = Clockwork.option:GetColor("information");
		local found = {};
		local nextFind = nil;

		if (CW_CONVAR_FO4HUD:GetInt() == 0 and CW_CONVAR_FO3HUD:GetInt() == 1) then
			Atomic:DrawFO3HUD(color, found, nextFind);
		else
			Atomic:DrawFO4HUD(color, found, nextFind);
		end;
	end;
end;

local positions = {
	25,
	51,
	76,
	101,
	126,
	152,
	176,
	203,
	228
};

function Atomic:DrawXPBar(name, newValue)
	local oldValue = newValue - 1;
	local infoColor = Clockwork.option:GetColor("information");
	local color = Color(infoColor.r, infoColor.g, infoColor.b, self.skillAlpha);
	local colorBlack = Color(0, 0, 0, self.skillAlpha);
	local frameTime = FrameTime();
	local nextTen = math.ceil(newValue / 10) * 10;
	local lastTen = math.floor(newValue / 10) * 10;
	local w = 385;
	local h = 140;
	
	if (oldValue - lastTen <= 0) then
		if (lastTen / 10 >= 1 and newValue - lastTen != 1) then
			self.tick = self.tick or 228;
		else
			self.tick = self.tick or 0;
		end;
	else
		self.tick = self.tick or (positions[oldValue - lastTen] or 0);
	end;

	if (lastTen == nextTen) then
		nextTen = lastTen + 10;
	end;

	if (!self.SkillFadeIn) then
		surface.PlaySound("atomic/skill_up.wav");

		self.SkillFadeIn = CurTime() + 7;

		if (!self.skillAlpha) then
			self.skillAlpha = 0;
		end;
	end;

	if (self.fadeOut == true) then
		self.skillAlpha = math.Clamp(self.skillAlpha - (100 * FrameTime()), 0, 255);
	end;

	if (self.skillAlpha < 255) then
		if (!self.fadeOut) then
			self.skillAlpha = math.Clamp(self.skillAlpha + (100 * FrameTime()), 0, 255);
		end;
	elseif (self.skillAlpha == 255) then
		if (!self.SkillFadeOut) then
			self.SkillFadeOut = CurTime() + 1;
		end;

		if (CurTime() >= self.SkillFadeOut) then
			self.fadeOut = true;	
		end;
	end;

	if (self.SkillFadeOut) then
		if (newValue - lastTen <= 0) then
			self.tick = math.Clamp(self.tick - (150 * FrameTime()), 0, self.tick);
		else
			self.tick = math.Clamp(self.tick + (15 * FrameTime()), self.tick, positions[newValue - lastTen]);
		end;
	end;

	local pointerAlpha = self.skillAlpha;
	local tickPosition = ScrW() - w + 58 + self.tick;

	if (newValue - lastTen <= 0 and !self.SkillFadeOut) then
		nextTen = nextTen - 10;
		lastTen = lastTen - 10;
	end;

	surface.SetDrawColor(color.r, color.g, color.b, self.skillAlpha);
	surface.SetMaterial(XP_BAR);
	surface.DrawTexturedRect(ScrW() - w, ScrH() * 0.65, w, h);

	surface.SetDrawColor(color.r, color.g, color.b, pointerAlpha);
	surface.SetMaterial(XP_POINTER);
	surface.DrawTexturedRect(tickPosition, ScrH() * 0.65 + 10, 42, 42)

	surface.SetFont(Clockwork.option:GetFont("hud_text"));
	local nX, nY = surface.GetTextSize(name);

	surface.SetFont(Clockwork.option:GetFont("hud_text_big"));
	local n2X, n2Y = surface.GetTextSize("+"..newValue);

	local valuePos = ScrW() - nX - (n2X / 2) - 15;

	if (newValue >= 10) then
		valuePos = valuePos + 15;
	end;

	draw.DrawText("+"..newValue, Clockwork.option:GetFont("hud_text_big_blur"), valuePos, ScrH() * 0.65 + 70, colorBlack, TEXT_ALIGN_RIGHT);
	draw.DrawText("+"..newValue, Clockwork.option:GetFont("hud_text_big"), valuePos, ScrH() * 0.65 + 70, color, TEXT_ALIGN_RIGHT);
	draw.DrawText(name, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 30, ScrH() * 0.65 + 75, colorBlack, TEXT_ALIGN_RIGHT);
	draw.DrawText(name, Clockwork.option:GetFont("hud_text"), ScrW() - 30, ScrH() * 0.65 + 75, color, TEXT_ALIGN_RIGHT);
	draw.DrawText(nextTen - 1, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 55, ScrH() * 0.65 + 25, colorBlack, TEXT_ALIGN_CENTER);
	draw.DrawText(nextTen - 1, Clockwork.option:GetFont("hud_text"), ScrW() - 55, ScrH() * 0.65 + 25, color, TEXT_ALIGN_CENTER);
	draw.DrawText(lastTen, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 325, ScrH() * 0.65 + 25, colorBlack, TEXT_ALIGN_CENTER);
	draw.DrawText(lastTen, Clockwork.option:GetFont("hud_text"), ScrW() - 325, ScrH() * 0.65 + 25, color, TEXT_ALIGN_CENTER);
	
	if (self.SkillFadeIn <= CurTime()) then
		self.skillDisplay = nil;
		self.SkillFadeIn = nil;
		self.skillAlpha = nil;
		self.fadeOut = nil;
		self.tick = nil;
		self.SkillFadeOut = nil;
	end;
end;

-- Called when a HUD element wants to be drawn.
function Atomic:CanDrawHUD(name)
	--[[
	if (CW_CONVAR_FOHUD:GetInt() == 0) then 
		return false;
	end;
	--]]

	if (name == "Crosshair") then
		return Clockwork.config:Get("enable_crosshair"):Get();
	end;

	return true;
end;

-- Called to determine if the entity will show up on the player's compass.
function Atomic:CanSeeBlip(entity)
	if (entity:IsPlayer() and entity:GetMoveType() == MOVETYPE_WALK) then
		local p = Clockwork.Client:GetSpecial("P");
		local s = entity:GetNWInt("Sneak");

		if (p and s) then
			if (entity:Crouching()) then
				if ((p * 10) > s) then
					return true;
				end;
			else
				return true;
			end;
		else
			return true;
		end;
	elseif (entity:IsNPC() or string.find(entity:GetClass(), "npc")) then
		return true;
	end;

	return false;
end;

-- Called when a text entry has gotten focus.
function Atomic:OnTextEntryGetFocus(panel)
	self.textEntryFocused = panel;
end;

-- Called when a text entry has lost focus.
function Atomic:OnTextEntryLoseFocus(panel)
	self.textEntryFocused = nil;
end;

-- Called when the cinematic intro info is needed.
function Atomic:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = Clockwork.config:Get("intro_text_big"):Get(),
		text = Clockwork.config:Get("intro_text_small"):Get()
	};
end;

-- Called when an entity's menu options are needed.
function Atomic:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "cw_radio") then
		if ( !entity:GetOff() ) then
			options["Turn Off"] = "cw_radioToggle";
		else
			options["Turn On"] = "cw_radioToggle";
		end;
		
		options["Set Frequency"] = function()
			Derma_StringRequest("Frequency", "What would you like to set the frequency to?", frequency, function(text)
				if ( IsValid(entity) ) then
					Clockwork.entity:ForceMenuOption(entity, "Set Frequency", text);
				end;
			end);
		end;
		
		options["Take"] = "cw_radioTake";
	elseif (entity:GetClass() == "cw_music_radio") then
		if (!entity:GetNWBool("Off")) then
			options["Turn Off"] = "cw_musicToggle";
		else
			options["Turn On"] = "cw_musicToggle";
		end;
		
		options["Take"] = "cw_musicTake";
	end;
end;

-- Called when the target's status should be drawn.
function Atomic:DrawTargetPlayerStatus(target, alpha, x, y)
	local colorInformation = Clockwork.option:GetColor("information");
	local thirdPerson = "him";
	local mainStatus = nil;
	local gender = "He";
	local action = Clockwork.player:GetAction(target);
	
	if (target:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if ( target:Alive() ) then
		if (action == "die") then
			mainStatus = gender.." is in critical condition.";
		end;
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." is clearly unconscious.";
		end;
		
		if (mainStatus) then
			y = Clockwork.kernel:DrawInfo(mainStatus, x, y, colorInformation, alpha);
		end;
		
		return y;
	end;
end;

-- Called when the chat box info should be adjusted.
function Atomic:ChatBoxAdjustInfo(info)
	if (Clockwork.config:Get("can_anon"):GetBoolean()) then
		if (IsValid(info.speaker)) then
			if (info.data.anon) then
				info.name = "Somebody";
			end;
		end;
	end;
end;

-- Called when the post progress bar info is needed.
function Atomic:GetPostProgressBarInfo()
	if ( Clockwork.Client:Alive() ) then
		local action, percentage = Clockwork.player:GetAction(Clockwork.Client, true);
		
		if (action == "die") then
			return {text = "You are slowly dying.", percentage = percentage, flash = percentage > 75};
		end;
	end;
end;