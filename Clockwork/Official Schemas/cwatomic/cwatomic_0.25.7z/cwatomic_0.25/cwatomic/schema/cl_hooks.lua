--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local surface = surface;
local LEFT_SEPERATOR = Material("atomic/hud/hud_left.png");
local RIGHT_SEPERATOR = Material("atomic/hud/hud_right.png");
local MENU_TICK = Material("atomic/hud/hud_tick_mark.png");
local COMP_STRIP = Material("atomic/hud/hud_comp.png");
local ARMOR_EMPTY = Material("atomic/hud/armor_empty.png");
local ARMOR_FILL = Material("atomic/hud/armor_fill.png");
local ARMOR_BROKEN = Material("atomic/hud/armor_broken.png");
local CROSSHAIR = Material("atomic/hud/crosshair.png");
local CROSSHAIR_FILL = Material("atomic/hud/crosshair_filled.png");
local XP_BAR = Material("atomic/hud/xp_bar.png");
local XP_POINTER = Material("atomic/hud/xp_pointer.png");

-- Called when the menu's items should be destroyed.
function Atomic:MenuItemsDestroy(menuItems)
--	if (!Clockwork.player:HasFlags(Clockwork.Client, "T")) then
		menuItems:Destroy(Clockwork.option:GetKey("name_business"));
--	end;
end;

-- Called when the menu's items should be destroyed.
function Atomic:MenuItemsAdd(menuItems)
	if (Clockwork.config:Get("enable_special"):Get()) then
		menuItems:Add("SPECIAL", "cwSpecial", "View your current SPECIAL stats.", Clockwork.option:GetKey("icon_data_special"));
	end;
end;

-- Called when a player's scoreboard options are needed.
function Atomic:GetPlayerScoreboardOptions(player, options, menu)
	if (Clockwork.command:FindByID("CharSetCustomClass") != nil) then
		if ( Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharSetCustomClass").access) ) then
			options["Custom Class"] = {};
			options["Custom Class"]["Set"] = function()
				Derma_StringRequest(player:Name(), "What would you like to set their custom class to?", player:GetSharedVar("customClass"), function(text)
					Clockwork.kernel:RunCommand("CharSetCustomClass", player:Name(), text);
				end);
			end;
			
			if (player:GetSharedVar("customClass") != "") then
				options["Custom Class"]["Take"] = function()
					Clockwork.kernel:RunCommand( "CharTakeCustomClass", player:Name() );
				end;
			end;
		end;
	end;
end;

-- Called when a player's scoreboard class is needed.
function Atomic:GetPlayerScoreboardClass(player)
	local customClass = player:GetSharedVar("customClass");
	
	if (customClass != "") then
		return customClass;
	end;
end;

-- Called when the local player's item functions should be adjusted.
function Atomic:PlayerAdjustItemFunctions(itemTable, itemFunctions)
	--[[
	MAKE THIS A PERK
	if (Clockwork.player:HasFlags(Clockwork.Client, "T") and itemTable.cost) then
		itemFunctions[#itemFunctions + 1] = "Caps";
	end;
	]]--
end;

-- Called when the local player's character screen faction is needed.
function Atomic:GetPlayerCharacterScreenFaction(character)
	if (character.customClass and character.customClass != "") then
		return character.customClass;
	end;
end;

-- Called when the local player's default color modify should be set.
function Atomic:PlayerSetDefaultColorModify(colorModify)
	colorModify["$pp_colour_brightness"] = -0.02;
	colorModify["$pp_colour_contrast"] = 1.1;
	colorModify["$pp_colour_colour"] = 0.6;
end;

-- Called when the schema initializes.
function Atomic:Initialize()
	CW_CONVAR_FOHUD = Clockwork.kernel:CreateClientConVar("cwFalloutHUD", 1, true, true);

	if (CW_CONVAR_FOHUD:GetInt() == 1) then
		Clockwork.chatBox:SetCustomPosition(50, ScrH() - 200);
	end;
end;

-- Called when a ConVar has changed.
function Atomic:ClockworkConVarChanged()
	if (CW_CONVAR_FOHUD:GetInt() == 1) then
		Clockwork.chatBox:SetCustomPosition(50, ScrH() - 200);
	else
		Clockwork.chatBox:ResetCustomPosition();
	end;
end;

-- Called when an entity's target ID HUD should be painted.
function Atomic:HUDPaintEntityTargetID(entity, info)
	local infoColor = Clockwork.option:GetColor("information");
	local color = Color(infoColor.r, infoColor.g, infoColor.b, info.alpha);
	
	if (entity:GetClass() == "prop_physics") then
		local physDesc = entity:GetNetworkedString("physDesc");
		
		if (physDesc != "") then
			info.y = Clockwork.kernel:DrawInfo(physDesc, info.x, info.y, color, info.alpha);
		end;
	end;
end;

-- Called before the item entity's target ID is drawn. Return false to stop default draw.
function Atomic:PaintItemTargetID(x, y, alpha, itemTable)
	local trace = Clockwork.Client:GetEyeTraceNoCursor();
	local entity = trace.Entity;

	if (entity and entity:NearestPoint(trace.StartPos):Distance(trace.StartPos) <= 80) then
		Atomic:DrawInfoUI(itemTable("name"), "WG", itemTable("weight"), "VAL", itemTable("cost"), alpha);
	end;

	return false;
end;

-- Called to draw the player's crosshair.
function Atomic:DrawPlayerCrosshair(x, y, color)
	return false;
end;

-- Called when the HUD is painted.
function Atomic:HUDPaint()
	if (!Clockwork.kernel:IsChoosingCharacter()) then	
		local width = 385
		local height = 140;
		local x = ScrW() - width - 40;
		local y = ScrH() - height - 20;
		local color = Clockwork.option:GetColor("information");
		local tickWidth = 8;
		local tickHeight = 25;
		local tickX = x + 363;
		local tickY = y + 47;
		local tickColor = Color(color.r, color.g, color.b, 200);
		local skillDisplay = self.skillDisplay;
		local curTime = CurTime();
		local entity = Clockwork.Client:GetEyeTraceNoCursor().Entity;

		if (Clockwork.plugin:Call("CanDrawHUD", "XPBar")) then
			if (skillDisplay) then
				self:DrawXPBar(skillDisplay.name, Clockwork.attributes:Get(skillDisplay.name) or 1);
			end;
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "Sneak")) then
			if (Clockwork.Client:Crouching()) then
				draw.SimpleText("[SNEAK]", Clockwork.option:GetFont("hud_text_blur"), ScrW() / 2, 20, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER);
				draw.SimpleText("[SNEAK]", Clockwork.option:GetFont("hud_text"), ScrW() / 2, 20, color, TEXT_ALIGN_CENTER);
			end;
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "Crosshair")) then
			local info = {
				x = ScrW() / 2,
				y = ScrH() / 2
			};

			local crosshairMat = CROSSHAIR;

			if (self.crosshairFill) then
				crosshairMat = CROSSHAIR_FILL;
			end;

			Clockwork.plugin:Call("GetPlayerCrosshairInfo", info);

			surface.SetDrawColor(color);
			surface.SetMaterial(crosshairMat);
			surface.DrawTexturedRect(info.x - 32, info.y - 32, 64, 64);

			self.crosshairFill = false;
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "UseUI")) then
			local eyePos = Clockwork.Client:EyePos();

			if (entity and entity:NearestPoint(eyePos):Distance(eyePos) <= 80) then
				local entityOptions = {};
				local canDraw = false;
				local useText = "Use";
				local useTable = {};

				Clockwork.plugin:Call("GetEntityMenuOptions", entity, entityOptions);

				--[[
					I don't know why checking the number of entries in the table doesn't work, but this dumb way works.
				--]]
				for k, v in pairs(entityOptions) do
					if (k or v) then
						canDraw = true;

						table.insert(useTable, k);
					end;
				end;

				local useNum = #useTable;

				if (useNum == 1) then
					useText = useTable[1];
				elseif (useNum > 1) then
					useText = "Use ["..tostring(useNum).."]";
				end;

				if (canDraw or entity:GetClass() == "cw_item") then
					local alpha = Clockwork.kernel:CalculateAlphaFromDistance(255, Clockwork.Client, entity);
					local y = ScrH() - 160;

					self.crosshairFill = true;

					draw.SimpleText("E) "..useText, Clockwork.option:GetFont("hud_text_blur"), ScrW() / 2, y - 35, Color(0, 0, 0, alpha), TEXT_ALIGN_CENTER);
					draw.SimpleText("E) "..useText, Clockwork.option:GetFont("hud_text"), ScrW() / 2, y - 35, Color(color.r, color.g, color.b, alpha), TEXT_ALIGN_CENTER);
				end;
			end;
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "Compass")) then
			local compPart = -LocalPlayer():GetAngles().y;

			if (compPart < 0) then
				compPart = (180 + compPart) + 180;
			end;

			surface.SetDrawColor(color);
			surface.SetMaterial(COMP_STRIP);
			surface.DrawPartialTexturedRect( 50, ScrH() - 90, 312, 64, (1024 / 360) * compPart, 0, 312, 64, 1336, 64);
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "RightFrame")) then
			local stamina = Clockwork.Client:GetSharedVar("Stamina");
			local progress = math.ceil((38 * 0.01) * stamina);
			local weapon = Clockwork.Client:GetActiveWeapon();
			local clipOne = weapon:Clip1();

			if (weapon and IsValid(weapon)) then
				local itemTable = Clockwork.item:GetByWeapon(weapon);

				if (weapon.Clip1) then
					local clipOne = weapon:Clip1();

					if (clipOne >= 0) then
						local ammoString = (clipOne.."/"..Clockwork.Client:GetAmmoCount(weapon:GetPrimaryAmmoType()))

						draw.SimpleText(ammoString, Clockwork.option:GetFont("hud_text_blur"), x + width - 30, tickY + 25, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
						draw.SimpleText(ammoString, Clockwork.option:GetFont("hud_text"), x + width - 30, tickY + 25, color, TEXT_ALIGN_RIGHT);
					end;
				end;

				if (itemTable) then
					local health = itemTable.health or 200
					local dura = (itemTable:GetData("Condition") / health) * 100;

					if (dura) then
						local barColor = Color(math.max(color.r - 70, 0), math.max(color.g - 70, 0), math.max(color.b - 70, 0), color.a);

						draw.SimpleText("CND", Clockwork.option:GetFont("hud_text_blur"), x + 120, tickY + 25, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
						draw.SimpleText("CND", Clockwork.option:GetFont("hud_text"), x + 120, tickY + 25, color, TEXT_ALIGN_RIGHT);
						
						surface.SetDrawColor(barColor);
						surface.DrawRect(x + 125, tickY + 34, 58, 19);

						local duraProg = math.ceil((58 * 0.01) * dura);
						
						surface.SetDrawColor(color);
						surface.DrawRect(x + 125, tickY + 34, duraProg, 19);						
					end;
				end;
			end;

			draw.SimpleText("STAM", Clockwork.option:GetFont("hud_text_blur"), x + width - 30, tickY - 40, Color(0, 0, 0, 255), TEXT_ALIGN_RIGHT);
			draw.SimpleText("STAM", Clockwork.option:GetFont("hud_text"), x + width - 30, tickY - 40, color, TEXT_ALIGN_RIGHT);
			
			for i = 1, 38 do
				if (progress != 0 and progress >= i) then
					local newTickX = tickX - ((i - 1) * tickWidth);

					if (i == 1) then
						newTickX = tickX;
					end;

					surface.SetDrawColor(tickColor);
					surface.SetMaterial(MENU_TICK);
					surface.DrawTexturedRect(newTickX, tickY, tickWidth, tickHeight);
				end;
			end;

			surface.SetDrawColor(color);
			surface.SetMaterial(RIGHT_SEPERATOR);
			surface.DrawTexturedRect(x, y, width, height);
		end;

		if (Clockwork.plugin:Call("CanDrawHUD", "LeftFrame")) then
			local healProgress = math.ceil((38 / Clockwork.Client:GetMaxHealth()) * Clockwork.Client:Health());

			draw.SimpleText("HP", Clockwork.option:GetFont("hud_text_blur"), 65, tickY - 40, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT);
			draw.SimpleText("HP", Clockwork.option:GetFont("hud_text"), 65, tickY - 40, color, TEXT_ALIGN_LEFT);
			
			for i = 1, 38 do
				if (healProgress != 0 and healProgress >= i) then
					local newTickX = 57 + ((i - 1) * tickWidth);

					if (i == 1) then
						newTickX = 57;
					end;

					surface.SetDrawColor(tickColor);
					surface.SetMaterial(MENU_TICK);
					surface.DrawTexturedRect(newTickX, tickY, tickWidth, tickHeight);
				end;
			end

			surface.SetDrawColor(color);
			surface.SetMaterial(LEFT_SEPERATOR);
			surface.DrawTexturedRect(38, y, width + 2, height);

			local armor = Clockwork.Client:Armor();
			local itemTable = Clockwork.player:GetClothesItem();

			if (armor > 0) then
				local armorPercent = armor / Clockwork.Client:GetMaxArmor();

				surface.SetMaterial(ARMOR_FILL);
				surface.DrawPartialTexturedRect(30 + width, (tickY - 32) + (32 - (32 * armorPercent)), 32, 32, 0, 32 - (32 * armorPercent), 32, 32, 32, 32);

				surface.SetMaterial(ARMOR_EMPTY);
				surface.DrawTexturedRect(30 + width, tickY - 32, 32, 32);
			elseif (itemTable) then
				local itemArmor = itemTable:GetData("Armor");

				if (armor == itemArmor) then
					surface.SetDrawColor(Color(255, 0, 0, 255));
					surface.SetMaterial(ARMOR_BROKEN);
					surface.DrawTexturedRect(30 + width, tickY - 32, 32, 32);
				end;
			end;
		end;
	end;
end;

local positions = {
	25,
	51,
	76,
	101,
	126,
	152,
	176,
	203,
	228
};

function Atomic:DrawXPBar(name, newValue)
	local oldValue = newValue - 1;
	local infoColor = Clockwork.option:GetColor("information");
	local color = Color(infoColor.r, infoColor.g, infoColor.b, self.skillAlpha);
	local colorBlack = Color(0, 0, 0, self.skillAlpha);
	local frameTime = FrameTime();
	local nextTen = math.ceil(newValue / 10) * 10;
	local lastTen = math.floor(newValue / 10) * 10;
	local w = 385;
	local h = 140;
	
	if (oldValue - lastTen <= 0) then
		if (lastTen / 10 >= 1 and newValue - lastTen != 1) then
			self.tick = self.tick or 228;
		else
			self.tick = self.tick or 0;
		end;
	else
		self.tick = self.tick or (positions[oldValue - lastTen] or 0);
	end;

	if (lastTen == nextTen) then
		nextTen = lastTen + 10;
	end;

	if (!self.SkillFadeIn) then
		surface.PlaySound("atomic/skill_up.wav");

		self.SkillFadeIn = CurTime() + 7;

		if (!self.skillAlpha) then
			self.skillAlpha = 0;
		end;
	end;

	if (self.fadeOut == true) then
		self.skillAlpha = math.Clamp(self.skillAlpha - (100 * FrameTime()), 0, 255);
	end;

	if (self.skillAlpha < 255) then
		if (!self.fadeOut) then
			self.skillAlpha = math.Clamp(self.skillAlpha + (100 * FrameTime()), 0, 255);
		end;
	elseif (self.skillAlpha == 255) then
		if (!self.SkillFadeOut) then
			self.SkillFadeOut = CurTime() + 1;
		end;

		if (CurTime() >= self.SkillFadeOut) then
			self.fadeOut = true;	
		end;
	end;

	if (self.SkillFadeOut) then
		if (newValue - lastTen <= 0) then
			self.tick = math.Clamp(self.tick - (150 * FrameTime()), 0, self.tick);
		else
			self.tick = math.Clamp(self.tick + (15 * FrameTime()), self.tick, positions[newValue - lastTen]);
		end;
	end;

	local pointerAlpha = self.skillAlpha;
	local tickPosition = ScrW() - w + 58 + self.tick;

	if (newValue - lastTen <= 0 and !self.SkillFadeOut) then
		nextTen = nextTen - 10;
		lastTen = lastTen - 10;
	end;

	surface.SetDrawColor(color.r, color.g, color.b, self.skillAlpha);
	surface.SetMaterial(XP_BAR);
	surface.DrawTexturedRect(ScrW() - w, ScrH() * 0.65, w, h);

	surface.SetDrawColor(color.r, color.g, color.b, pointerAlpha);
	surface.SetMaterial(XP_POINTER);
	surface.DrawTexturedRect(tickPosition, ScrH() * 0.65 + 10, 42, 42)

	surface.SetFont(Clockwork.option:GetFont("hud_text"));
	local nX, nY = surface.GetTextSize(name);

	surface.SetFont(Clockwork.option:GetFont("hud_text_big"));
	local n2X, n2Y = surface.GetTextSize("+"..newValue);

	local valuePos = ScrW() - nX - (n2X / 2) - 15;

	if (newValue >= 10) then
		valuePos = valuePos + 15;
	end;

	draw.DrawText("+"..newValue, Clockwork.option:GetFont("hud_text_big_blur"), valuePos, ScrH() * 0.65 + 70, colorBlack, TEXT_ALIGN_RIGHT);
	draw.DrawText("+"..newValue, Clockwork.option:GetFont("hud_text_big"), valuePos, ScrH() * 0.65 + 70, color, TEXT_ALIGN_RIGHT);
	draw.DrawText(name, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 30, ScrH() * 0.65 + 75, colorBlack, TEXT_ALIGN_RIGHT);
	draw.DrawText(name, Clockwork.option:GetFont("hud_text"), ScrW() - 30, ScrH() * 0.65 + 75, color, TEXT_ALIGN_RIGHT);
	draw.DrawText(nextTen - 1, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 55, ScrH() * 0.65 + 25, colorBlack, TEXT_ALIGN_CENTER);
	draw.DrawText(nextTen - 1, Clockwork.option:GetFont("hud_text"), ScrW() - 55, ScrH() * 0.65 + 25, color, TEXT_ALIGN_CENTER);
	draw.DrawText(lastTen, Clockwork.option:GetFont("hud_text_blur"), ScrW() - 325, ScrH() * 0.65 + 25, colorBlack, TEXT_ALIGN_CENTER);
	draw.DrawText(lastTen, Clockwork.option:GetFont("hud_text"), ScrW() - 325, ScrH() * 0.65 + 25, color, TEXT_ALIGN_CENTER);
	
	if (self.SkillFadeIn <= CurTime()) then
		self.skillDisplay = nil;
		self.SkillFadeIn = nil;
		self.skillAlpha = nil;
		self.fadeOut = nil;
		self.tick = nil;
		self.SkillFadeOut = nil;
	end;
end;

-- Called when a HUD element wants to be drawn.
function Atomic:CanDrawHUD(name)
	if (CW_CONVAR_FOHUD:GetInt() == 0) then 
		return false;
	end;

	if (name == "Crosshair") then
		return Clockwork.config:Get("enable_crosshair"):Get();
	end;

	return true;
end;

-- Called to determine if the entity will show up on the player's compass.
function Atomic:CanSeeBlip(entity)
	if (entity:IsPlayer()) then
		local p = Clockwork.Client:GetSpecial("P");
		local s = entity:GetNWInt("Sneak");

		if (p and s) then
			if ((p * 10) > s) then
				return true;
			end;
		else
			return true;
		end;
	elseif (entity:IsNPC() or string.find(entity:GetClass(), "npc")) then
		return true;
	end;

	return false;
end;

-- Called when a text entry has gotten focus.
function Atomic:OnTextEntryGetFocus(panel)
	self.textEntryFocused = panel;
end;

-- Called when a text entry has lost focus.
function Atomic:OnTextEntryLoseFocus(panel)
	self.textEntryFocused = nil;
end;

-- Called when the cinematic intro info is needed.
function Atomic:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = Clockwork.config:Get("intro_text_big"):Get(),
		text = Clockwork.config:Get("intro_text_small"):Get()
	};
end;

-- Called when an entity's menu options are needed.
function Atomic:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "prop_ragdoll") then
		local player = Clockwork.entity:GetPlayer(entity);
		
		if ( !player or !player:Alive() ) then
			--MAKE THIS A PERK!--
			options["Mutilate"] = "cw_corpseMutilate";
		end;
	elseif (entity:GetClass() == "cw_radio") then
		if ( !entity:GetOff() ) then
			options["Turn Off"] = "cw_radioToggle";
		else
			options["Turn On"] = "cw_radioToggle";
		end;
		
		options["Set Frequency"] = function()
			Derma_StringRequest("Frequency", "What would you like to set the frequency to?", frequency, function(text)
				if ( IsValid(entity) ) then
					Clockwork.entity:ForceMenuOption(entity, "Set Frequency", text);
				end;
			end);
		end;
		
		options["Take"] = "cw_radioTake";
	end;
end;

-- Called when the target's status should be drawn.
function Atomic:DrawTargetPlayerStatus(target, alpha, x, y)
	local colorInformation = Clockwork.option:GetColor("information");
	local thirdPerson = "him";
	local mainStatus = nil;
	local gender = "He";
	local action = Clockwork.player:GetAction(target);
	
	if (target:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if ( target:Alive() ) then
		if (action == "die") then
			mainStatus = gender.." is in critical condition.";
		end;
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." is clearly unconscious.";
		end;
		
		if (mainStatus) then
			y = Clockwork.kernel:DrawInfo(mainStatus, x, y, colorInformation, alpha);
		end;
		
		return y;
	end;
end;

-- Called when the chat box info should be adjusted.
function Atomic:ChatBoxAdjustInfo(info)
	if (Clockwork.config:Get("can_anon"):GetBoolean()) then
		if (IsValid(info.speaker)) then
			if (info.data.anon) then
				info.name = "Somebody";
			end;
		end;
	end;
end;

-- Called when the post progress bar info is needed.
function Atomic:GetPostProgressBarInfo()
	if ( Clockwork.Client:Alive() ) then
		local action, percentage = Clockwork.player:GetAction(Clockwork.Client, true);
		
		if (action == "die") then
			return {text = "You are slowly dying.", percentage = percentage, flash = percentage > 75};
		end;
	end;
end;