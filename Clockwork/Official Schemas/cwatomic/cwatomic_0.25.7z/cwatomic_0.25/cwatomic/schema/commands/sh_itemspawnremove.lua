--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

COMMAND = Clockwork.command:New("ItemSpawnRemove");
COMMAND.tip = "Remove item spawns at your target position.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);
	local trashSpawns = 0;
	
	for k, v in pairs(Atomic.trashSpawns) do
		if (v:Distance(position) <= 256) then
			trashSpawns = trashSpawns + 1;
			
			Atomic.trashSpawns[k] = nil;
		end;
	end
	
	if (trashSpawns > 0) then
		if (trashSpawns == 1) then
			Clockwork.player:Notify(player, "You have removed "..trashSpawns.." item spawn.");
		else
			Clockwork.player:Notify(player, "You have removed "..trashSpawns.." item spawns.");
		end;
	else
		Clockwork.player:Notify(player, "There were no item spawns near this position.");
	end;
	
	Atomic:SaveTrashSpawns();
end;

COMMAND:Register();