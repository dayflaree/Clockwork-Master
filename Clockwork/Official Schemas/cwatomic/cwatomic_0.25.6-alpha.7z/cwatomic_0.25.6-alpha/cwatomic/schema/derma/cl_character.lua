--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local Clockwork = Clockwork;
local pairs = pairs;
local RunConsoleCommand = RunConsoleCommand;
local SysTime = SysTime;
local ScrH = ScrH;
local ScrW = ScrW;
local table = table;
local string = string;
local vgui = vgui;
local math = math;

local PANEL = {};

-- Called every frame.
function PANEL:Think()
	if (self.animation) then
		self.animation:Run();
	end;
	
	local color = Clockwork.option:GetColor("information");
	local colorDisabled = Color(
		math.max(color.r - 170, 0),
		math.max(color.g - 170, 0),
		math.max(color.b - 170, 0),
		255
	);
	
	if (self:GetDisabled()) then
		self:SetTextColor(self.OverrideColorHover or colorDisabled);
	else
		self:SetTextColor(self.OverrideColorNormal or color);
	end;
	
	self:SetExpensiveShadow(1, Color(0, 0, 0, 150));
end;

-- A function to set the panel's Callback.
function PANEL:SetCallback(Callback)
	self.DoClick = function(button)
		surface.PlaySound("atomic/pipboy_t3_press.wav");
		Callback(button);
	end;
end;

vgui.Register("cwMenuLblBtn", PANEL, "cwLabelButton");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	if (!Clockwork.theme:Call("PreCharacterMenuInit", self)) then
		local smallTextFont = Clockwork.option:GetFont("menu_text_big");
		local hugeTextFont = Clockwork.option:GetFont("menu_text_huge");
		local scrH = ScrH();
		local scrW = ScrW();
		
		self:SetPos(0, 0);
		self:SetSize(scrW, scrH);
		self:SetDrawOnTop(false)
		self:SetPaintBackground(false);
		self:SetMouseInputEnabled(true);
		
		self.titleLabel = vgui.Create("cwMenuLblBtn", self);
		self.titleLabel:SetDisabled(true);
		self.titleLabel:SetFont(hugeTextFont);
		self.titleLabel:SetText(string.upper(Schema:GetName()));
		
		local schemaLogo = Clockwork.option:GetKey("schema_logo")
	
		self.createButton = vgui.Create("cwMenuLblBtn", self);
		self.createButton:SetFont(smallTextFont);
		self.createButton:SetText("NEW");
		self.createButton:FadeIn(0.5);
		self.createButton:SetCallback(function(panel)
			if (table.Count(Clockwork.character:GetAll()) >= Clockwork.player:GetMaximumCharacters()) then
				return Clockwork.character:SetFault("You cannot create any more characters!");
			end;
			
			Clockwork.character:ResetCreationInfo();
			Clockwork.character:OpenNextCreationPanel();
		end);
		self.createButton:SizeToContents();
		self.createButton:SetMouseInputEnabled(true);
		self.createButton:SetPos(ScrW() * 0.25, ScrH() * 0.85);
		self.titleLabel:SetPos(0, self.createButton.y - (self.createButton:GetTall()/2) + 4);
		
		self.loadButton = vgui.Create("cwMenuLblBtn", self);
		self.loadButton:SetFont(smallTextFont);
		self.loadButton:SetText("LOAD");
		self.loadButton:FadeIn(0.5);
		self.loadButton:SetCallback(function(panel)
			self:OpenPanel("cwCharacterList", nil, function(panel)
				Clockwork.character:RefreshPanelList();
			end);
		end);
		self.loadButton:SizeToContents();
		self.loadButton:SetMouseInputEnabled(true);
		self.loadButton:SetPos(ScrW() * 0.40, ScrH() * 0.85);

		self.aboutButton = vgui.Create("cwMenuLblBtn", self);
		self.aboutButton:SetFont(smallTextFont);
		self.aboutButton:SetText("FORUMS");
		self.aboutButton:SetAlpha(0);
		self.aboutButton:FadeIn(1);
		self.aboutButton:SetCallback(function(panel)
		 gui.OpenURL(Clockwork.option:GetKey("menu_forum_url"));
		end);
		self.aboutButton:SizeToContents();
		self.aboutButton:SetMouseInputEnabled(true);
		self.aboutButton:SetPos(ScrW() * 0.55, ScrH() * 0.85);

		self.disconnectButton = vgui.Create("cwMenuLblBtn", self);
		self.disconnectButton:SetFont(smallTextFont);
		self.disconnectButton:SetText("DISCONNECT");
		self.disconnectButton:FadeIn(0.5);
		self.disconnectButton:SetCallback(function(panel)
			if (Clockwork.Client:HasInitialized() and !Clockwork.character:IsMenuReset()) then
				Clockwork.character:SetPanelMainMenu();
				Clockwork.character:SetPanelOpen(false);
			else
				RunConsoleCommand("disconnect");
			end;
		end);
		self.disconnectButton:SizeToContents();
		self.disconnectButton:SetPos(ScrW() * 0.70, ScrH() * 0.85);
		self.disconnectButton:SetMouseInputEnabled(true);
		
		self.previousButton = vgui.Create("cwMenuLblBtn", self);
		self.previousButton:SetFont(smallTextFont);
		self.previousButton:SetText("PREVIOUS");
		self.previousButton:SetCallback(function(panel)
			if (!Clockwork.character:IsCreationProcessActive()) then
				local activePanel = Clockwork.character:GetActivePanel();
				
				if (activePanel and activePanel.OnPrevious) then
					activePanel:OnPrevious();
				end;
			else
				Clockwork.character:OpenPreviousCreationPanel()
			end;
		end);
		self.previousButton:SizeToContents();
		self.previousButton:SetMouseInputEnabled(true);
		self.previousButton:SetPos((scrW * 0.2) - (self.previousButton:GetWide() / 2), scrH * 0.9);
		
		self.nextButton = vgui.Create("cwMenuLblBtn", self);
		self.nextButton:SetFont(smallTextFont);
		self.nextButton:SetText("NEXT");
		self.nextButton:SetCallback(function(panel)
			if (!Clockwork.character:IsCreationProcessActive()) then
				local activePanel = Clockwork.character:GetActivePanel();
				
				if (activePanel and activePanel.OnNext) then
					activePanel:OnNext();
				end;
			else
				Clockwork.character:OpenNextCreationPanel()
			end;
		end);
		self.nextButton:SizeToContents();
		self.nextButton:SetMouseInputEnabled(true);
		self.nextButton:SetPos((scrW * 0.8) - (self.nextButton:GetWide() / 2), scrH * 0.9);
		
		self.cancelButton = vgui.Create("cwMenuLblBtn", self);
		self.cancelButton:SetFont(smallTextFont);
		self.cancelButton:SetText("CANCEL");
		self.cancelButton:SetCallback(function(panel)
			self:ReturnToMainMenu();
		end);
		self.cancelButton:SizeToContents();
		self.cancelButton:SetMouseInputEnabled(true);
		self.cancelButton:SetPos((scrW * 0.5) - (self.cancelButton:GetWide() / 2), scrH * 0.9);
		
		self.characterModel = vgui.Create("cwCharacterModel", self);
		self.characterModel:SetSize(512, 512);
		self.characterModel:SetAlpha(0);
		self.characterModel:SetModel("models/error.mdl");
		self.createTime = SysTime();
		
		Clockwork.theme:Call("PostCharacterMenuInit", self)
	end;
end;

-- A function to fade in the model panel.
function PANEL:FadeInModelPanel(model)
	if (ScrH() < 768) then
		return true;
	end;

	local panel = Clockwork.character:GetActivePanel();
	local x, y = ScrW() - self.characterModel:GetWide() - 8, 16;
	
	if (panel) then
		x, y = panel.x + panel:GetWide() - 16, panel.y - 80;
	end;
	
	self.characterModel:SetPos(x, y);
	
	if (self.characterModel:FadeIn(0.5)) then
		self:SetModelPanelModel(model);
		return true;
	else
		return false;
	end;
end;

-- A function to fade out the model panel.
function PANEL:FadeOutModelPanel()
	self.characterModel:FadeOut(0.5);
end;

-- A function to set the model panel's model.
function PANEL:SetModelPanelModel(model)
	if (self.characterModel.currentModel != model) then
		self.characterModel.currentModel = model;
		self.characterModel:SetModel(model);
	end;
	
	local modelPanel = self.characterModel;
	local weaponModel = Clockwork.plugin:Call(
		"GetModelSelectWeaponModel", model
	);
	local sequence = Clockwork.plugin:Call(
		"GetModelSelectSequence", modelPanel.Entity, model
	);
	
	if (weaponModel) then
		self.characterModel:SetWeaponModel(weaponModel);
	else
		self.characterModel:SetWeaponModel(false);
	end;
	
	if (sequence) then
		modelPanel.Entity:ResetSequence(sequence);
	end;
end;

-- A function to return to the main menu.
function PANEL:ReturnToMainMenu()
	local panel = Clockwork.character:GetActivePanel();
	
	if (panel) then
		if (panel.FadeOut) then
			panel:FadeOut(0.5, function()
				Clockwork.character.activePanel = nil;
					panel:Remove();
				self:FadeInTitle();
			end);
		else
			Clockwork.character.activePanel = nil;
				panel:Remove();
			self:FadeInTitle();
		end;
	else
		self:FadeInTitle();
	end;
	
	self:FadeOutModelPanel();
	self:FadeOutNavigation();
end;

-- A function to fade out the navigation.
function PANEL:FadeOutNavigation()
	self.previousButton:FadeOut(0.5);
	self.cancelButton:FadeOut(0.5);
	self.nextButton:FadeOut(0.5);
end;

-- A function to fade in the navigation.
function PANEL:FadeInNavigation()
	self.previousButton:FadeIn(0.5);
	self.cancelButton:FadeIn(0.5);
	self.nextButton:FadeIn(0.5);
end;

-- A function to fade out the title.
function PANEL:FadeOutTitle()
--	self.subLabel:FadeOut(0.5);
	self.titleLabel:FadeOut(0.5);
	self.createButton:FadeOut(0.5)
	self.loadButton:FadeOut(0.5)
	self.aboutButton:FadeOut(0.5)
	self.disconnectButton:FadeOut(0.5)
--	self.authorLabel:FadeOut(0.5);
end;

-- A function to fade in the title.
function PANEL:FadeInTitle()
--	self.subLabel:FadeIn(0.5);
	self.createButton:FadeIn(0.5)
	self.loadButton:FadeIn(0.5)
	self.aboutButton:FadeIn(0.5)
	self.disconnectButton:FadeIn(0.5)
	self.titleLabel:FadeIn(0.5);
--	self.authorLabel:FadeIn(0.5);
end;

-- A function to open a panel.
function PANEL:OpenPanel(vguiName, childData, Callback)
	if (!Clockwork.theme:Call("PreCharacterMenuOpenPanel", self, vguiName, childData, Callback)) then
		local panel = Clockwork.character:GetActivePanel();
		
		if (panel) then
			if (panel.FadeOut) then
				panel:FadeOut(0.5, function()
					panel:Remove(); self.childData = childData;
					
					Clockwork.character.activePanel = vgui.Create(vguiName, self);

					if (Clockwork.character.activePanel.FadeIn) then
						Clockwork.character.activePanel:SetAlpha(0);
						Clockwork.character.activePanel:FadeIn(0.5);
					else
						Clockwork.character.activePanel:SetAlpha(255);
					end;

					Clockwork.character.activePanel:MakePopup();

					if (ScrH() <= 768) then
						Clockwork.character.activePanel:SetPos(ScrW() * 0.2, 50);
					else
						Clockwork.character.activePanel:SetPos(ScrW() * 0.2, ScrH() * 0.275);
					end;

					if (Callback) then
						Callback(Clockwork.character.activePanel);
					end;
					
					if (childData) then
						Clockwork.character.activePanel.bIsCreationProcess = true;
						Clockwork.character:FadeInNavigation();
					end;
				end);
			else
				panel:Remove(); self.childData = childData;
					
				Clockwork.character.activePanel = vgui.Create(vguiName, self);

				if (Clockwork.character.activePanel.FadeIn) then
					Clockwork.character.activePanel:SetAlpha(0);
					Clockwork.character.activePanel:FadeIn(0.5);
				else
					Clockwork.character.activePanel:SetAlpha(255);
				end;

				Clockwork.character.activePanel:MakePopup();
				
				if (ScrH() <= 768) then
					Clockwork.character.activePanel:SetPos(ScrW() * 0.2, 50);
				else
					Clockwork.character.activePanel:SetPos(ScrW() * 0.2, ScrH() * 0.275);
				end;

				if (Callback) then
					Callback(Clockwork.character.activePanel);
				end;
					
				if (childData) then
					Clockwork.character.activePanel.bIsCreationProcess = true;
					Clockwork.character:FadeInNavigation();
				end;
			end;
		else
			self.childData = childData;
			self:FadeOutTitle();
			
			Clockwork.character.activePanel = vgui.Create(vguiName, self);

			if (Clockwork.character.activePanel.FadeIn) then
				Clockwork.character.activePanel:SetAlpha(0);
				Clockwork.character.activePanel:FadeIn(0.5);
			else
				Clockwork.character.activePanel:SetAlpha(255);
			end;

			Clockwork.character.activePanel:MakePopup();
			
			if (ScrH() <= 768) then
				Clockwork.character.activePanel:SetPos(ScrW() * 0.2, 50);
			else
				Clockwork.character.activePanel:SetPos(ScrW() * 0.2, ScrH() * 0.275);
			end;
			
			if (Callback) then
				Callback(Clockwork.character.activePanel);
			end;
			
			if (childData) then
				Clockwork.character.activePanel.bIsCreationProcess = true;
				Clockwork.character:FadeInNavigation();
			end;
		end;
		
		--[[ Fade out the model panel, we probably don't need it now! --]]
		self:FadeOutModelPanel();
		
		Clockwork.theme:Call("PostCharacterMenuOpenPanel", self);
	end;
end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	if (!Clockwork.theme:Call("PreCharacterMenuPaint", self)) then
		local scrW = ScrW();
		local schemaLogo = Clockwork.option:GetKey("schema_logo");
		local subLabelAlpha = self.createButton:GetAlpha();
		local color = Clockwork.option:GetColor("information");
		local curTime = CurTime();
		
		if (schemaLogo != "" and subLabelAlpha > 0) then
			if (!self.logoTextureID) then
				self.logoTextureID = Material(schemaLogo..".png");
			end;

			if (!self.pipBoy) then
				self.pipBoy = Material("atomic/hud/pipboy_main.png");
			end;

			if (!self.neon) then
				self.neon = Material("atomic/atomic_logo_neon.png");
			end;
			
			self.logoTextureID:SetFloat("$alpha", subLabelAlpha);
			self.pipBoy:SetFloat("$alpha", subLabelAlpha);

			surface.SetDrawColor(color.r, color.g, color.b, subLabelAlpha - 70);
			surface.SetMaterial(self.logoTextureID);
			surface.DrawTexturedRect((scrW * 0.50 - 256), ScrH() * 0.35, 512, 256);

			local neonAlpha = math.abs(math.sin(curTime) * 255);

			if (!self.nextFlicker or self.nextFlicker <= curTime) then
				self.canFlicker = curTime + math.random();
			end;

			if (self.nextFlicker and self.nextFlicker >= curTime) then
				if (self.canFlicker and self.canFlicker <= curTime) then
					neonAlpha = 0;

					if (!self.sparkPlayed) then
						surface.PlaySound("ambient/energy/spark"..math.random(1, 4)..".wav");

						self.sparkPlayed = true;
					end;
				else
					self.nextFlicker = curTime + math.random(0.1, 3);

					self.sparkPlayed = nil;
				end;
			else
				self.nextFlicker = curTime + math.random(0.1, 3);
			end;

			surface.SetDrawColor(255, 255, 255, math.min(subLabelAlpha, 255 - neonAlpha));
			surface.SetMaterial(self.neon);
			surface.DrawTexturedRect((scrW * 0.50 - 256), ScrH() * 0.35, 512, 256);
		end;
		
		local x, y = self:CursorPos();
		local canPlay = self.canPlay;
		local boxX, boxY, boxW, boxH;

		if (subLabelAlpha == 255) then
			if (x >= self.createButton.x and x <= self.createButton.x + self.createButton:GetWide()
			and y >= self.createButton.y and y <= self.createButton.y + self.createButton:GetTall()) then
				boxX = self.createButton.x;
				boxY = self.createButton.y;
				boxW = self.createButton:GetWide();
				boxH = self.createButton:GetTall();

				self.canPlay = 1;
			elseif (x >= self.loadButton.x and x <= self.loadButton.x + self.loadButton:GetWide()
			and y >= self.loadButton.y and y <= self.loadButton.y + self.loadButton:GetTall()) then
				boxX = self.loadButton.x;
				boxY = self.loadButton.y;
				boxW = self.loadButton:GetWide();
				boxH = self.loadButton:GetTall();

				self.canPlay = 2;
			elseif (x >= self.aboutButton.x and x <= self.aboutButton.x + self.aboutButton:GetWide()
			and y >= self.aboutButton.y and y <= self.aboutButton.y + self.aboutButton:GetTall()) then
				boxX = self.aboutButton.x;
				boxY = self.aboutButton.y;
				boxW = self.aboutButton:GetWide();
				boxH = self.aboutButton:GetTall();

				self.canPlay = 3;
			elseif (x >= self.disconnectButton.x and x <= self.disconnectButton.x + self.disconnectButton:GetWide()
			and y >= self.disconnectButton.y and y <= self.disconnectButton.y + self.disconnectButton:GetTall()) then
				boxX = self.disconnectButton.x;
				boxY = self.disconnectButton.y;
				boxW = self.disconnectButton:GetWide();
				boxH = self.disconnectButton:GetTall();	

				self.canPlay = 4;
			else
				self.canPlay = nil
			end;
		elseif (self.previousButton:GetAlpha() == 255) then
			if (x >= self.previousButton.x and x <= self.previousButton.x + self.previousButton:GetWide()
			and y >= self.previousButton.y and y <= self.previousButton.y + self.previousButton:GetTall()) then
				boxX = self.previousButton.x;
				boxY = self.previousButton.y;
				boxW = self.previousButton:GetWide();
				boxH = self.previousButton:GetTall();	

				self.canPlay = 5;
			elseif (x >= self.cancelButton.x and x <= self.cancelButton.x + self.cancelButton:GetWide()
			and y >= self.cancelButton.y and y <= self.cancelButton.y + self.cancelButton:GetTall()) then
				boxX = self.cancelButton.x;
				boxY = self.cancelButton.y;
				boxW = self.cancelButton:GetWide();
				boxH = self.cancelButton:GetTall();	

				self.canPlay = 6;
			elseif (x >= self.nextButton.x and x <= self.nextButton.x + self.nextButton:GetWide()
			and y >= self.nextButton.y and y <= self.nextButton.y + self.nextButton:GetTall()) then
				boxX = self.nextButton.x;
				boxY = self.nextButton.y;
				boxW = self.nextButton:GetWide();
				boxH = self.nextButton:GetTall();	

				self.canPlay = 7;
			else
				self.canPlay = nil
			end;
		end;

		if (boxX and boxX != nil) then
			boxX = boxX - 10;
			boxW = boxW + 20;

			surface.SetDrawColor(color.r, color.g, color.b, 255);

			for i=0, 3 do
				surface.DrawOutlinedRect(boxX - i, boxY - i, boxW + i * 2, boxH + i * 2);
			end;

			surface.SetDrawColor(color.r, color.g, color.b, 25);
			surface.DrawRect(boxX, boxY, boxW, boxH);
		end;
		
		if (self.canPlay and canPlay != self.canPlay) then
			surface.PlaySound("atomic/pipboy_rollover.wav");
		end;

		Clockwork.theme:Call("PostCharacterMenuPaint", self)
	end;
end;


-- Called each frame.
function PANEL:Think()
	if (!Clockwork.theme:Call("PreCharacterMenuThink", self)) then
		local characters = table.Count(Clockwork.character:GetAll());
		local bIsLoading = Clockwork.character:IsPanelLoading();
		local schemaLogo = Clockwork.option:GetKey("schema_logo");
		local activePanel = Clockwork.character:GetActivePanel();
		local fault = Clockwork.character:GetFault();
		
		if (Clockwork.plugin:Call("ShouldDrawCharacterBackgroundBlur")) then
			Clockwork.kernel:RegisterBackgroundBlur(self, self.createTime);
		else
			Clockwork.kernel:RemoveBackgroundBlur(self);
		end;
		
		if (self.characterModel) then
			if (!self.characterModel.currentModel
			or self.characterModel.currentModel == "models/error.mdl") then
				self.characterModel:SetAlpha(0);
			end;
		end;
		
		if (!Clockwork.character:IsCreationProcessActive()) then
			if (activePanel) then
				if (activePanel.GetNextDisabled
				and activePanel:GetNextDisabled()) then
					self.nextButton:SetDisabled(true);
				else
					self.nextButton:SetDisabled(false);
				end;
				
				if (activePanel.GetPreviousDisabled
				and activePanel:GetPreviousDisabled()) then
					self.previousButton:SetDisabled(true);
				else
					self.previousButton:SetDisabled(false);
				end;
			end;
		else
			local previousPanelInfo = Clockwork.character:GetPreviousCreationPanel();
			
			if (previousPanelInfo) then
				self.previousButton:SetDisabled(false);
			else
				self.previousButton:SetDisabled(true);
			end;
			
			self.nextButton:SetDisabled(false);
		end;
		
		if (schemaLogo == "") then
			self.titleLabel:SetVisible(true);
		else
			self.titleLabel:SetVisible(false);
		end;
		
		if (characters == 0 or bIsLoading) then
			self.loadButton:SetDisabled(true);
		else
			self.loadButton:SetDisabled(false);
		end;
		
		if (characters >= Clockwork.player:GetMaximumCharacters()
		or Clockwork.character:IsPanelLoading()) then
			self.createButton:SetDisabled(true);
		else
			self.createButton:SetDisabled(false);
		end;

		if (LocalPlayer():HasInitialized() and !Clockwork.character:IsMenuReset()) then
			self.disconnectButton:SetText("CANCEL");
			self.disconnectButton:SizeToContents();
		else
			self.disconnectButton:SetText("DISCONNECT");
			self.disconnectButton:SizeToContents();
		--	self.disconnectButton:SetPos(ScrW() * 0.70, ScrH() * 0.85);
		end;

		if (self.animation) then
			self.animation:Run();
		end;
		
		self:SetSize(ScrW(), ScrH());
		
		Clockwork.theme:Call("PostCharacterMenuThink", self)
	end;
end;

vgui.Register("cwCharacterMenu", PANEL, "DPanel");

Clockwork.character:RemoveCreationPanel("Persuasion");
Clockwork.character:RegisterCreationPanel("Faction", "cwCharacterFaction", 1, 
	function(info)
		local factions = {};
		
		for k, v in pairs(Clockwork.faction.stored) do
			if (!v.whitelist or Clockwork.character:IsWhitelisted(v.name)) then
				if (!Clockwork.faction:HasReachedMaximum(k)) then
					factions[#factions + 1] = v.name;
				end;
			end;
		end;

		if (#factions > 1) then
			return true;
		end;
		
		info.faction = factions[1];
		return false;
	end
);
Clockwork.character:RegisterCreationPanel("Gender", "cwCharacterGender", 2);
Clockwork.character:RegisterCreationPanel("S.P.E.C.I.A.L.", "cwCharacterSpecial", 4);