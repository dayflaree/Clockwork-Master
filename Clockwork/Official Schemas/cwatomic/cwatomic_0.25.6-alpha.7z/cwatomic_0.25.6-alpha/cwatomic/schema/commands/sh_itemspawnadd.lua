--[[ 
    © 2015 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).

    Clockwork was created by Conna Wiles (also known as kurozael.)
    http://cloudsixteen.com/license/clockwork.html

    Atomic was developed by NightAngel, if you have any questions or
    wish to give any feedback whatsoever, please send a message to
    http://steamcommunity.com/id/NA1455.
--]]

local COMMAND = Clockwork.command:New("ItemSpawnAdd");
COMMAND.tip = "Add an item spawn at your target position.";
COMMAND.access = "a";
COMMAND.text = "[string Categories]"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);

	Atomic.trashSpawns[#Atomic.trashSpawns + 1] = {arguments, position};
	Atomic:SaveTrashSpawns();
	
	Clockwork.player:Notify(player, "You have added an item spawn.");
end;

COMMAND:Register();