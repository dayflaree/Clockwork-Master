--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("custom_storage");
	ITEM.name = "Jacket";
	ITEM.cost = 150;
	ITEM.description = "A small and tattered storage jacket.";
	ITEM.extraWeight = 4;
Clockwork.item:Register(ITEM);