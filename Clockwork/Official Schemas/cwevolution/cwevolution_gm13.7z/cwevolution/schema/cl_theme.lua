--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local THEME = Clockwork.theme:Begin();

function ScaleToWideScreen(size)
	return math.min(math.max( ScreenScale(size / 2.62467192), math.min(size, 14) ), size);
end;

-- A function to create a font with legacy arguments.
function THEME:LegacyFont(font, scale, weight, antialias, shadow, name)
	surface.CreateFont(name, {
		font = font,
		scale = scale,
		weight = weight,
		antialias = antialias,
		shadow = shadow,
	})
end;

-- Called when fonts should be created.
function THEME:CreateFonts()
	self:LegacyFont("Anklada�", Clockwork.kernel:GetFontSize3D(), 600, true, false, "test_Large3D2D");
	self:LegacyFont("Anklada�", ScaleToWideScreen(24), 600, true, false, "test_IntroTextSmall");
	self:LegacyFont("Anklada�", ScaleToWideScreen(17), 600, true, false, "test_IntroTextTiny");
	self:LegacyFont("Anklada�", ScaleToWideScreen(22), 600, true, false, "test_CinematicText");
	self:LegacyFont("Anklada�", ScaleToWideScreen(45), 600, true, false, "test_IntroTextBig");
	self:LegacyFont("Anklada�", ScaleToWideScreen(17), 600, true, false, "test_TargetIDText");
	self:LegacyFont("Anklada�", ScaleToWideScreen(11), 600, true, false, "test_SmallBarText");
	self:LegacyFont("Anklada�", ScaleToWideScreen(70), 600, true, false, "test_MenuTextHuge");
	self:LegacyFont("Anklada�", ScaleToWideScreen(45), 600, true, false, "test_MenuTextBig");
	self:LegacyFont("Anklada�", ScaleToWideScreen(14), 600, true, false, "test_PlayerInfoText");
	self:LegacyFont("Anklada�", ScaleToWideScreen(14), 600, true, false, "test_MainText");
end;

-- Called when to initialize theme.
function THEME:Initialize()
	Clockwork.option:SetColor("information", Schema.MAIN_COLOR);
	Clockwork.option:SetColor("background", Schema.BACKGROUND_COLOR);
	Clockwork.option:SetColor("foreground", Schema.FOREGROUND_COLOR);
	Clockwork.option:SetColor("target_id", Color(114, 203, 213, 255));
	Clockwork.option:SetFont("bar_text", "test_TargetIDText");
	Clockwork.option:SetFont("main_text", "test_MainText");
	Clockwork.option:SetFont("hints_text", "test_IntroTextTiny");
	Clockwork.option:SetFont("large_3d_2d", "test_Large3D2D");
	Clockwork.option:SetFont("target_id_text", "test_TargetIDText");
	Clockwork.option:SetFont("cinematic_text", "test_CinematicText");
	Clockwork.option:SetFont("date_time_text", "test_IntroTextSmall");
	Clockwork.option:SetFont("menu_text_big", "test_MenuTextBig");
	Clockwork.option:SetFont("menu_text_huge", "test_MenuTextHuge");
	Clockwork.option:SetFont("menu_text_tiny", "test_IntroTextTiny");
	Clockwork.option:SetFont("intro_text_big", "test_IntroTextBig");
	Clockwork.option:SetFont("menu_text_small", "test_IntroTextSmall");
	Clockwork.option:SetFont("intro_text_tiny", "test_IntroTextTiny");
	Clockwork.option:SetFont("intro_text_small", "test_IntroTextSmall");
	Clockwork.option:SetFont("player_info_text", "test_PlayerInfoText");
end;

-- Called after the character menu has initialized.
function THEME.hooks:PostCharacterMenuInit(panel) end;

-- Called every frame that the character menu is open.
function THEME.hooks:PostCharacterMenuThink(panel) end;

-- Called after the character menu is painted.
function THEME.hooks:PostCharacterMenuPaint(panel) end;

-- Called after a character menu panel is opened.
function THEME.hooks:PostCharacterMenuOpenPanel(panel) end;

-- Called after the main menu has initialized.
function THEME.hooks:PostMainMenuInit(panel) end;

-- Called after the main menu is rebuilt.
function THEME.hooks:PostMainMenuRebuild(panel) end;

-- Called after a main menu panel is opened.
function THEME.hooks:PostMainMenuOpenPanel(panel, panelToOpen) end;

-- Called after the main menu is painted.
function THEME.hooks:PostMainMenuPaint(panel) end;

-- Called every frame that the main menu is open.
function THEME.hooks:PostMainMenuThink(panel) end;

Clockwork.theme:Finish(THEME);