
Clockwork.config:Add("database_logging_enabled", true, nil, nil, true, true, true);
Clockwork.config:Add("mysql_logs_table", "logs", nil, nil, true, true, true);
