--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:AddToSystem("Spawn where left", "spawn_where_left", "Whether or not players spawn where they disconnected.");