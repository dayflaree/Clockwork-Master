--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:Add("remove_map_physics", false, nil, nil, nil, nil, true);

cwCleanedMaps.entityList = {
	"item_healthcharger",
	"item_suitcharger",
	"weapon_*"
};