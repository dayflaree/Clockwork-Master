--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:AddToSystem("Remove map physics", "remove_map_physics", "Whether or not physics entities should be removed when the map is loaded.");