--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

TYPING_WHISPER = 6;
TYPING_PERFORM = 5;
TYPING_NORMAL = 4;
TYPING_RADIO = 3;
TYPING_YELL = 2;
TYPING_OOC = 1;