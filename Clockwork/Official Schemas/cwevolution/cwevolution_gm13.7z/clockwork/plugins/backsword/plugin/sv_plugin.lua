--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:AddFile("materials/gmod/scope-refract.vtf");
Clockwork.kernel:AddFile("materials/gmod/scope-refract.vmt");
Clockwork.kernel:AddFile("materials/gmod/scope.vtf");
Clockwork.kernel:AddFile("materials/gmod/scope.vmt");