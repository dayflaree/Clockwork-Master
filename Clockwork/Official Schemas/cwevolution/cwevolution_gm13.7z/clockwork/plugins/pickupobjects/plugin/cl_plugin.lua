--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:AddToSystem("Take physcannon", "take_physcannon", "Whether or not the player is stripped of the physics cannon.");