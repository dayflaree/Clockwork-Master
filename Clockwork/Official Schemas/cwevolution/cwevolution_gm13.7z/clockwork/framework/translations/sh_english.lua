
local LANGUAGE = {};
	LANGUAGE['developed_by'] = "Developed by %s";
	LANGUAGE['new'] = "New";
	LANGUAGE['load'] = "Load";
	LANGUAGE['leave'] = "Leave";
	LANGUAGE['previous'] = "Previous";
	LANGUAGE['next'] = "Next";
	LANGUAGE['cancel'] = "Cancel";
Clockwork.language:Add("en", LANGUAGE);
