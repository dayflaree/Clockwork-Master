--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[ Include Vercas's and Penguin's serialization library. --]]
include("external/von.lua");
include("external/pon.lua");

--[[
	Include the shared Lua table and
	the Clockwork kernel.
--]]
include("clockwork.lua");
include("clockwork/framework/cl_kernel.lua");