local PLUGIN = PLUGIN;

Clockwork.directory:AddCategory("General", "Voices");