local PLUGIN = PLUGIN;

Clockwork.kernel:AddDirectory("materials/models/spraycan3.*");

Clockwork.config:Get("disable_sprays"):Set(false);