Skeleton
========

A skeleton schema for the Clockwork roleplaying framework with more fundementals.

Credits:
Alex Grist
kurozael
RJ