--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.config:AddToSystem("Big intro text", "intro_text_big", "The big text displayed for the introduction.");
Clockwork.config:AddToSystem("Small intro text", "intro_text_small", "The small text displayed for the introduction.");