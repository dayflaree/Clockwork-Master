--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:AddDirectory("materials/skeleton/");

Clockwork.config:Add("intro_text_big", "Example Big Text.", true);
Clockwork.config:Add("intro_text_small", "Example Little Text.", true);