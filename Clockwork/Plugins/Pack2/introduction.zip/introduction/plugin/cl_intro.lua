local PLUGIN = PLUGIN;
PLUGIN.text = [[Point Insertion

Once Gordon disembarks the train, he eventually meets up with his old friend and co-worker from Black Mesa, Barney Calhoun, who has infiltrated the Civil Protection in support of the fledging resistance movement. Barney instructs Gordon to make his way to Doctor Isaac Kleiner's lab, but along the way, Civil Protection detects Gordon and he is put to flight. Surrounded and eventually stunned by the Civil Protection, Gordon is rescued by Alyx Vance, the daughter of Doctor Eli Vance.

"A Red Letter Day"

After rescuing Gordon from the Civil Protection, Alyx Vance brings Gordon to Doctor Kleiner's lab. After Gordon is outfitted with his upgraded H.E.V. suit, Doctor Kleiner attempts to teleport Alyx and Gordon to Black Mesa East, where Alyx's father is waiting. Although Alyx makes it to Black Mesa East, Doctor Kleiner's pet headcrab Lamarr pulls off a crucial wiring as she falls from a ventilation shaft, when Gordon is in the process of being teleported. The interruption leads to a chaotic sequence in which Gordon is briefly transported to, in addition to other locations, the office of Doctor Breen at the Combine Citadel. He eventually ends up outside Kleiner's lab, where Barney gives Gordon his old crowbar. The Citadel is on high alert for Gordon, and Barney tells him to take the canals to get to Eli's lab.

Route Kanal

While navigating the city's canals, Gordon is chased by Civil Protection and scanners. He finds small resistance bases populated by both humans and Vortigaunts, one of the several species of invading aliens of the original Half-Life turned allies. After being helped through an underground railroad system, Gordon is provided an air boat, allowing him greater expediency.

Water Hazard

Gordon's air boat is soon spotted by the Combine and relentlessly pursued by a hunter-chopper assault helicopter. At another resistance base, a Vortigaunt affixes a salvaged Overwatch hunter-chopper turret to the craft, which allows Gordon to eventually down the pursuing helicopter.]];