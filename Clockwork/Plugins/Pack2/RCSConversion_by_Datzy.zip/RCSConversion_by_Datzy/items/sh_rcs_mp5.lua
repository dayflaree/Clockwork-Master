--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "H&K MP5";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_smg_mp5.mdl";
	ITEM.weight = 3.5;
	ITEM.access = "V";
	ITEM.classes = {CLASS_EMP, CLASS_EOW};
	ITEM.uniqueID = "rcs_mp5";
	ITEM.business = true;
	ITEM.description = "A compact submachine gun with 'H&K' printed on the side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();