--[[
	First line, title of the config setting.
	Second line, the config code.
    Third line, description what it does.
--]]

local PLUGIN = PLUGIN

Clockwork.config:AddToSystem("Enable/Disable Quick Raise", "quick_raise_enable", "Enables or Disables Quick Raise.");