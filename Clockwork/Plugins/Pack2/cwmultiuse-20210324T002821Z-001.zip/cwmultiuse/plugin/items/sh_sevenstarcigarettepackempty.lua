--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Seven Star Cigarette Pack";
ITEM.cost = 1;
ITEM.model = "models/closedboxshin.mdl";
ITEM.weight = 0.1;
ITEM.access = "V";
ITEM.category = "Drugs";
ITEM.business = false;
ITEM.batch = 1;
ITEM.description = "An Empty filtered Cigarette Pack Containing Zero.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;


ITEM:Register();