--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Seven Star Cigarettes 2 Left";
ITEM.cost = 1;
ITEM.model = "models/closedboxshin.mdl";
ITEM.weight = 0.1;
ITEM.access = "V";
ITEM.useText = "Take One Out.";
ITEM.category = "Drugs";
ITEM.useSound = "npc/barnacle/neck_snap2.wav";
ITEM.business = false;
ITEM.batch = 1;
ITEM.sleep = 10;
ITEM.thirst = -10;
ITEM.hunger = 10;
ITEM.description = "A filtered Cigarette Pack Visibly Containing Two.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
        player:GiveItem(Clockwork.item:CreateInstance("Seven Star Cigarette"), true);
        player:GiveItem(Clockwork.item:CreateInstance("Seven Star Cigarettes 1 Left"), true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;


ITEM:Register();