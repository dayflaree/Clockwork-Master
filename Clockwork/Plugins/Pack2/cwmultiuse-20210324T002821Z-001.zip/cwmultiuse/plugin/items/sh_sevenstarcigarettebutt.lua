--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Seven Star Cigarette Butt";
ITEM.cost = 1;
ITEM.model = "models/nt/props_debris/cigarette_butt01.mdl";
ITEM.weight = 0.1;
ITEM.access = "V";
ITEM.category = "Drugs";
ITEM.business = false;
ITEM.batch = 1;
ITEM.description = "A Seven Star filtered Cigarette Butt.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;


ITEM:Register();