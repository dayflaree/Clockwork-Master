--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Seven Star Cigarette";
ITEM.cost = 1;
ITEM.model = "models/phycinnew.mdl";
ITEM.weight = 0.1;
ITEM.access = "V";
ITEM.useText = "Smoke";
ITEM.category = "Drugs";
ITEM.useSound = "ambient/voices/cough4.wav";
ITEM.business = false;
ITEM.batch = 1;
ITEM.sleep = 10;
ITEM.thirst = -10;
ITEM.hunger = 10;
ITEM.description = "A filtered Cigarette.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
        player:TakeDamage(1, player, player);
        player:GiveItem(Clockwork.item:CreateInstance("Seven Star Cigarette Butt"), true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;


ITEM:Register();