DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.PrintName = "Air Compressor";
ENT.Author = "Crazy Catiwis";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.PhysgunDisabled = false;