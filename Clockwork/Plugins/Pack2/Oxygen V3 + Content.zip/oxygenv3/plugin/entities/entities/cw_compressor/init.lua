AddCSLuaFile("shared.lua");
AddCSLuaFile("cl_init.lua");

include("shared.lua");

function ENT:Initialize()
	self:SetModel("models/props_wasteland/laundry_washer003.mdl");
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);
	self:SetUseType(SIMPLE_USE);
	self:DrawShadow(false);
end;

function ENT:Use(activator, caller)
	if( !self.NextCheck or self.NextCheck < CurTime() )then
		self.NextCheck = CurTime() + 10;
		if (activator:HasItemByID("oxygen_tank")) then
			if (activator:GetCharacterData("tankoxygen") != 100) then
				timer.Simple(2, function()
					self:EmitSound("doors/doormove2.wav")
					Clockwork.player:Notify(activator, "You have recharged your oxygen tank!");
					activator:SetCharacterData("tankoxygen", 100);
				end);
			else
				Clockwork.player:Notify(activator, "Your oxygen tank is full!");
			end;
		else
			Clockwork.player:Notify(activator, "You haven't got any oxygen tank to recharge!");
		end;
	end;
end;