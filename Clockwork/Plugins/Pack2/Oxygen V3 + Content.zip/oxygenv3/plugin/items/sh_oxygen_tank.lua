--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Oxygen Tank";
	ITEM.batch = 1;
	ITEM.useText = "Equip";
	ITEM.cost = 60;
	ITEM.model = "models/dpfilms/metropolice/props/biopolice_oxygen_tank.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.category = "Other";
	ITEM.business = true;
	ITEM.uniqueID = "oxygen_tank";
	ITEM.description = "A black and orange tank filled with pure oxygen.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine2";
	ITEM.attachmentOffsetAngles = Angle(90, -90, 0);
	ITEM.attachmentOffsetVector = Vector(0, -6, -50);

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	Clockwork.player:RemoveGear(player, "OxygenTank", self);
	hasOxygen = 0;
end;

ITEM:Register();