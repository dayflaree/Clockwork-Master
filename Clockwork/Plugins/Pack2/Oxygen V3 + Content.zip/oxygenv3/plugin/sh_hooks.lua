local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("oxygen", true);
	playerVars:Number("tankoxygen", true);
	playerVars:Number("hastank", true);
end;