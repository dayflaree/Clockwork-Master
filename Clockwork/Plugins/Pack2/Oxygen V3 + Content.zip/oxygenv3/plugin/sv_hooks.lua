
local PLUGIN = PLUGIN;

-- Called each tick.
function PLUGIN:Tick()

	if( !self.NextCheck or self.NextCheck < CurTime() )then
		self.NextCheck = CurTime() + 2;
	
		for k,v in pairs(_player.GetAll())do
			if (v:Alive()) then
				local itemTable = Clockwork.item:FindByID("oxygen_tank");
			
				if (v:HasItemByID("oxygen_tank")) then
					if (v:GetCharacterData("hastank") == 0) then
						Clockwork.player:CreateGear(v, "OxygenTank", itemTable);
						v:SetCharacterData("hastank", 1);
					end;
				else
					if (v:GetCharacterData("hastank") == 1) then
						Clockwork.player:RemoveGear(v, "OxygenTank", itemTable);
						v:SetCharacterData("hastank", 0);
					end;
				end;
				
				if (v:WaterLevel() == 3) then
					if (v:GetCharacterData("oxygen") <= 0) then
						v:TakeDamage(25, v, v);
					else
						if (v:HasItemByID("oxygen_tank")) then
							if (v:GetCharacterData("tankoxygen") > 0) then
								v:SetCharacterData("tankoxygen", v:GetCharacterData("tankoxygen") - 1);
							else
								v:TakeDamage(25, v, v);
							end;
						else
							v:SetCharacterData("oxygen", v:GetCharacterData("oxygen") - 25);
						end;
						if (v:GetCharacterData("oxygen") < 0) then
							v:SetCharacterData("oxygen", 0);
						end;
					end;
					v:EmitSound("player/pl_drown"..math.random(1, 3)..".wav");
				else
					if (v:GetCharacterData("oxygen") < 100) then
						v:SetCharacterData("oxygen", v:GetCharacterData("oxygen") + 5);
					end;
					
					if (v:GetCharacterData("oxygen") > 100) then
						v:SetCharacterData("oxygen", 100);
					end;
				end;
			end;
		end;
	end;
end;

-- Called when a player's character data should be saved.
function PLUGIN:PlayerSaveCharacterData(player, data)
	if ( data["oxygen"] ) then
		data["oxygen"] = math.Round( data["oxygen"] );
	end;
	if ( data["tankoxygen"] ) then
		data["tankoxygen"] = math.Round( data["tankoxygen"] );
	end;
	if ( data["hastank"] ) then
		data["hastank"] = math.Round( data["hastank"] );
	end;
end;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	data["oxygen"] = data["oxygen"] or 100;
	data["tankoxygen"] = data["tankoxygen"] or 0;
	data["hastank"] = data["hastank"] or 0;
end;

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("oxygen", 100);
		player:SetCharacterData("tankoxygen", 0);
		player:SetCharacterData("hastank", 0);
	end;
end;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "oxygen", math.Round( player:GetCharacterData("oxygen") ) );
	player:SetSharedVar( "tankoxygen", math.Round( player:GetCharacterData("tankoxygen") ) );
	player:SetSharedVar( "hastank", math.Round( player:GetCharacterData("hastank") ) );
end;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
    self:LoadCompressors();
end;

-- Called when data should be saved.
function PLUGIN:PostSaveData()
	self:SaveCompressors();
end;