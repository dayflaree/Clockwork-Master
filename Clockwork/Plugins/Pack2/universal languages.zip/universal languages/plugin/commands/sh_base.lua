
-----------------------------------------------------
--[[
	Made by Freelok. January 2018.
	Do not re-distribute as your own or modify without the permission of the creator.
]]

local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("First Three Letters of Language");                                     -- Use whatever you want, but it's easier to use the first three letters of the langauge.
COMMAND.tip = "Speak in [Insert Langauge Here].";
COMMAND.text = "<string speech>";
COMMAND.flags = bit.bor(CMD_DEFAULT);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Clockwork.player:HasFlags(player, "Your flag here"")) then    -- Be careful to not use already existing flags, like p or v.
		local speech = arguments[1]

		for k,v in pairs(_player.GetAll()) do
			local distance = v:GetPos():Distance(player:GetPos());
			if (math.floor(distance) <= Clockwork.config:Get("talk_radius"):Get()) then
				if (Clockwork.player:HasFlags(v, "--Your flag here"")) then			                -- Be careful to not use already existing flags, like p or v.
				Clockwork.chatBox:SendColored(v, Color(102, 205, 170, 255), "[Insert Language] "..player:Name()..": "..speech)
			else
				Clockwork.chatBox:SendColored(v, Color(102, 205, 170, 255), player:Name().." -- Whatever you want to follow in chat after a character uses the command. For example, '( so and so) speaks in (insert langauge here). Check the other langauge files for further understanding.")                                                                                             --You have the freedom to type whatever you want here. 
				end;
			end;
		end;
	else
		Clockwork.player:Notify(player, "You do not speak [Insert Langauge Here]!")                                        -- Again, you have the freedom to write whatever you want here.
	end;
end;

COMMAND:Register();