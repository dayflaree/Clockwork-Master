
-----------------------------------------------------
--[[
	Made by Freelok. January 2018.
	Do not re-distribute as your own or modify without the permission of the creator.
]]

local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Pla");
COMMAND.tip = "Speak in Plasmatic.";
COMMAND.text = "<string speech>";
COMMAND.flags = bit.bor(CMD_DEFAULT);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Clockwork.player:HasFlags(player, "--Your flag here"")) then
		local speech = arguments[1]

		for k,v in pairs(_player.GetAll()) do
			local distance = v:GetPos():Distance(player:GetPos());
			if (math.floor(distance) <= Clockwork.config:Get("talk_radius"):Get()) then
				if (Clockwork.player:HasFlags(v, "--Your flag here"")) then			
				Clockwork.chatBox:SendColored(v, Color(102, 205, 170, 255), "[Plasmatic] "..player:Name()..": "..speech)
			else
				Clockwork.chatBox:SendColored(v, Color(102, 205, 170, 255), player:Name().." speaks in an Alien langauge, which sounds strangely liquidy. You cannot understand it.")
				end;
			end;
		end;
	else
		Clockwork.player:Notify(player, "You do not speak Plasmatic!")
	end;
end;

COMMAND:Register();