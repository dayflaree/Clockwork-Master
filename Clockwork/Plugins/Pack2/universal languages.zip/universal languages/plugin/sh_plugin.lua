-----------------------------------------------------------------------------------------------------------------------------------
local PLUGIN = PLUGIN;
--Replace "flag" with whatever your flag is for that langauge. Say for Arabic, you'd replace "flag" with "z" or something like that.
--REMOVE THE -- SYMBOL FOR THE LANGAUGES YOU WANT!
-----------------------------------------------------------------------------------------------------------------------------------
--Clockwork.flag:Add("flag", "Arabic", "Allows a character to speak Arabic with /ara.");
--Clockwork.flag:Add("flag", "Chinese", "Allows a character to speak Chinese with /chi.");
--Clockwork.flag:Add("flag", "French", "Allows a character to speak French with /fre.");
--Clockwork.flag:Add("flag", "German", "Allows a character to speak German with /ger.");
--Clockwork.flag:Add("flag", "Italian", "Allows a character to speak Italian with /ita.");
--Clockwork.flag:Add("flag", "Japanese", "Allows a character to speak Japanese with /jap.");
--Clockwork.flag:Add("flag", "Russian", "Allows a character to speak Russian with /rus.");
--Clockwork.flag:Add("flag", "Spanish", "Allows a character to speak Spanish with /spa.");
--Clockwork.flag:Add("flag", "Finnish", "Allows a character to speak Finnish with /fin.");

--Clockwork.flag:Add("flag", "Korean", "Allows a character to speak Finnish with /kor.");

--Clockwork.flag:Add("flag", "Swedish", "Allows a character to speak Finnish with /swe.");

--Clockwork.flag:Add("flag", "Hebrew", "Allows a character to speak Hebrew with /hen.");

--Clockwork.flag:Add("flag", "Polish", "Allows a character to speak Polish with /pol.");

--Clockwork.flag:Add("flag", "Hmong", "Allows a character to speak Hmong with /hmo.");

--Clockwork.flag:Add("flag", "Hindi", "Allows a character to speak Hindi with /hin.");

--Clockwork.flag:Add("flag", "Portugese", "Allows a character to speak Portugese with /por.");

--Clockwork.flag:Add("flag", "Bengali", "Allows a character to speak Bengali with /ben.");

--Clockwork.flag:Add("flag", "Mandarin", "Allows a character to speak Mandarin with /man.");

--Clockwork.flag:Add("flag", "Swahili", "Allows a character to speak Swahili with /swa.");

--Clockwork.flag:Add("flag", "Hausa", "Allows a character to speak Hausa with /hau.");

--Clockwork.flag:Add("flag", "Freelokian", "Allows a character to comprehend and speak Freelokian with /lok.");

--Clockwork.flag:Add("flag", "American Sign Langauge", "Allows a character to convey American Sign Langauge with /asl.");

--Clockwork.flag:Add("flag", "Czech", "Allows a character to speak Czech with /cze.");

--Clockwork.flag:Add("flag", "Vortigese", "Allows a character to speak Vortigese with /vor.");

--Clockwork.flag:Add("flag", "Wastelander", "Allows a character to speak Wastelander with /was.");

--Clockwork.flag:Add("flag", "Dutch", "Allows a character to speak Dutch with /dut.");

--Clockwork.flag:Add("flag", "Greek", "Allows a character to speak Greek with /gre.");

--Clockwork.flag:Add("flag", "Javanese", "Allows a character to speak Javanese with /jav.");

--Clockwork.flag:Add("flag", "Xhosa", "Allows a character to speak Xhosa with /xho.");

--Clockwork.flag:Add("flag", "Zulu", "Allows a character to speak Zulu with /zul.");

--Clockwork.flag:Add("flag", "Demonese", "Allows a character to speak Demonese with /dem.");

--Clockwork.flag:Add("flag", "Plasmatic", "Allows a character to speak Plasmatic with /pla.");

--Clockwork.flag:Add("flag", "Sylhetti", "Allows a character to speak Gaelic with /syl.");

--Clockwork.flag:Add("flag", "Gaelic", "Allows a character to speak Gaelic with /gae.");

--Clockwork.flag:Add("flag", "Tsmishan", "Allows a character to speak Tsmishan with /tsi.");

--Clockwork.flag:Add("flag", "Dog", "Allows a characters I.Q. to expand enough to comprehend Dog, using /dog.");