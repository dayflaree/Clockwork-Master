Edited from Cinder & Polis' langauge plugin.
Newer langauges created by Freelok.
1/4/18