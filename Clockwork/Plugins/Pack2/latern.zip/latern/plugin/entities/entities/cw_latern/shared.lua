DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "karl-police";
ENT.PrintName = "Latern";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;