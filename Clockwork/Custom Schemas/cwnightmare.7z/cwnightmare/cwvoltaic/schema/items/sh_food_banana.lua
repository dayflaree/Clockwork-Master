--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Banana";
ITEM.cost = 5;
ITEM.model = "models/props/cs_italy/bananna.mdl";
ITEM.weight = .2;
ITEM.access = "v";
ITEM.uniqueID = "cw_banana";
ITEM.useText = "Peel";
ITEM.useSound = "npc/barnacle/neck_snap2.wav";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.description = "A curved yellow fruit.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("cw_banana_peeled");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("cw_banana_skin");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();