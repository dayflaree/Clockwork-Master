local ITEM = Clockwork.item:New();
	ITEM.name = "How To: Campfire";
	ITEM.cost = 40;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bfire";
	ITEM.weight = 0.1;
	ITEM.access = "v";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains how to start a campfire a piece of wood. \n1x Wood Scrap";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getWood = player:FindItemByID("cw_wood");
local giveFire = Clockwork.item:CreateInstance("cw_tinderbox");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bfire");

if (getWood) then
player:TakeItem(getWood, true);
player:GiveItem(giveFire, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required crafting materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);