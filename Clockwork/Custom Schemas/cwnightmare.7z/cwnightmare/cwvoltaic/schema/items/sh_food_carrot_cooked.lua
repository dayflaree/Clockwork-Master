--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Boiled Carrot";
ITEM.cost = 2;
ITEM.model = "models/props/cs_office/Snowman_nose.mdl";
ITEM.weight = .1;
ITEM.access = "v";
ITEM.uniqueID = "cw_carrot_cooked";
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.useSound = "npc/barnacle/barnacle_crunch2.wav";
ITEM.business = true;
ITEM.description = "An orange carrot, it looks pretty tasty.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 20, 0, 100));
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 15, 0, 100) );
	player:BoostAttribute(self.name, ATB_STAMINA, 5, 600);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();