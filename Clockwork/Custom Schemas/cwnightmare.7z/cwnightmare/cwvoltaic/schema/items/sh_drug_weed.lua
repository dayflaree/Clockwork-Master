local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Ounce Bag of Marijuana";
ITEM.cost = 100;
ITEM.model = "models/props_junk/garbage_bag001a.mdl";
ITEM.weight = 0.02;
ITEM.access = "V";
ITEM.useText = "Smoke";
ITEM.category = "Drugs";
ITEM.business = true;
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "An ounce bag of marijuana, a popular recreational drug";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetSharedVar("antidepressants", CurTime() + 600);
	
	player:BoostAttribute(self.name, ATB_ENDURANCE, 2, 120);
	player:BoostAttribute(self.name, ATB_STRENGTH, -2, 120);

end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();