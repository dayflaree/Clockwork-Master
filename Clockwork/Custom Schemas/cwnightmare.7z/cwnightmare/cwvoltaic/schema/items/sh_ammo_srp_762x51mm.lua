--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 200;
	ITEM.name = "Box of 7.62x51mm (x50)";
	ITEM.model = "models/items/ammorounds.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_helicoptergun";
	ITEM.ammoClass = "HelicopterGun";
	ITEM.ammoAmount = 50;
	ITEM.description = "A box containing 7.62x51mm rounds.";
Clockwork.item:Register(ITEM);