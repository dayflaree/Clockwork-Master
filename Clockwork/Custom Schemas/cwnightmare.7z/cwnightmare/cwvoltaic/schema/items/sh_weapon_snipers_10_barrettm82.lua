--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Barret M82";
	ITEM.cost = 60000;
	ITEM.model = "models/weapons/w_barret_m82.mdl";
	ITEM.weight = 5;
	ITEM.access = "V";
	ITEM.batch = 1;
	ITEM.category = "Snipers";
	ITEM.weaponClass = "m9k_barret_m82";
	ITEM.uniqueID = "m9k_barret_m82";
	ITEM.business = true;
	ITEM.description = "A recoil-operated, semi-automatic anti-materiel rifle.\nUtilizes .50 BMG rounds.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	--ITEM.loweredOrigin = Vector(3, 0, -4);
	--ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 5, 35);
ITEM:Register();