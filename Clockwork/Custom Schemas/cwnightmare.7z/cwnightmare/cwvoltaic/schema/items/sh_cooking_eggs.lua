--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Recipe: Eggs";
	ITEM.cost = 20;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_egg_r";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Recipes";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that simply explains how to cook an egg \n1x Egg \nFrying Pan.";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getEgg= player:FindItemByID("cw_egg");
local getPan= player:FindItemByID("cw_pan");
local giveCegg = Clockwork.item:CreateInstance("cw_egg_c");
local giveBlueprint = Clockwork.item:CreateInstance("cw_egg_r");

if (getEgg and getPan) then
player:TakeItem(getEgg, true);
player:GiveItem(giveCegg, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required eggs or pan!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);