--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 80;
	ITEM.name = "Box of .308 Winchester Rounds(x30)";
	ITEM.model = "models/items/redammo.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_308winchester";
	ITEM.ammoClass = "ar2altfire";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box containing .308 Winchester rounds.";
Clockwork.item:Register(ITEM);