--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Tea Pot";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.uniqueID = "cw_tea_pot";
	ITEM.model = "models/props_interiors/pot01a.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An empty tea pot.";
Clockwork.item:Register(ITEM);