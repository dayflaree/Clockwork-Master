--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Melon Chunk";
ITEM.cost = 5;
ITEM.model = "models/props_junk/watermelon01_chunk01b.mdl";
ITEM.weight = .25;
ITEM.access = "v";
ITEM.uniqueID = "cw_melon_chunk";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.business = true;
ITEM.description = "A slice of watermelon, it looks delicious.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, 100));
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 20, 0, 100) );
	player:SetCharacterData( "thirst", math.Clamp(player:GetCharacterData("thirst") - 15, 0, 100) );
	player:BoostAttribute(self.name, ATB_ACROBATICS, 3, 600);
	player:BoostAttribute(self.name, ATB_AGILITY, 3, 600);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();