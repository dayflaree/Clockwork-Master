--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Mannequin";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/nh2_gmn/dave_the_dummy_on_stand_phys.mdl";
	ITEM.weight = 1;
	ITEM.description = "";
Clockwork.item:Register(ITEM);