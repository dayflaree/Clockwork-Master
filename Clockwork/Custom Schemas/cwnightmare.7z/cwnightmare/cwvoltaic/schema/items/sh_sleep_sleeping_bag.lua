--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Sleeping Bag";
	ITEM.batch = 1;
	ITEM.cost = 10;
	ITEM.model = "models/props_junk/garbage_carboard001a.mdl";
	ITEM.weight = 0.1;
	ITEM.category = "Useful";
	ITEM.business = true;
	ITEM.access = "v";
	ITEM.useText = "Sleep In";
	ITEM.useSound = "physics/metal/metal_box_footstep1.wav";
	ITEM.uniqueID = "cw_sleeping_bag";
	ITEM.useSound = "player/footsteps/sand4.wav";
	ITEM.description = "A comfortable looking sleeping bag.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local instance = Clockwork.item:CreateInstance("cw_sleeping_bag");
		
	player:GiveItem(instance, true);
	
	player:SetCharacterData( "sleep", math.Clamp(player:GetCharacterData("sleep") - 75, 0, 100) );
	
end;

	-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_c17/furnituremetal001a");
end;

	-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);