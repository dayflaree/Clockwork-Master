--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Moonshine Bucket";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_junk/plasticbucket001a.mdl";
	ITEM.weight = 0.2;
	ITEM.description = "An empty plastic bucket that smells horrible.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;

Clockwork.item:Register(ITEM);