--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Salvager Kit";
	ITEM.batch = 1;
	ITEM.model = "models/props_c17/suitcase_passenger_physics.mdl";
	ITEM.weight = 2;
	ITEM.uniqueID = "cw_salvager";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A box filled with tools used to salvage materials from certain objects.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("phoenix_storms/metalset_1-2");
	end;
	
Clockwork.item:Register(ITEM);