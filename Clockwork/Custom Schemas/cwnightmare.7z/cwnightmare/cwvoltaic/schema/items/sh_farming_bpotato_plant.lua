--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "How To: Potato Farming";
	ITEM.cost = 1000;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bpotato_plant";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Farming";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper with some detailed drawings on it.";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getTubers = player:FindItemByID("cw_tubers");
local getWater = player:FindItemByID("cw_water");
local givePlant = Clockwork.item:CreateInstance("cw_potato_plant");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bpotato_plant");

if (getTubers and getWater) then
player:TakeItem(getTubers, true);
player:TakeItem(getWater, true);
player:GiveItem(givePlant, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required Farming materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);