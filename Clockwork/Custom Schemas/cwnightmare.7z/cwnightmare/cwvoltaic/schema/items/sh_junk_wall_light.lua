--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Wall Light";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_silo/wall_light_off.mdl";
	ITEM.weight = 2;
	ITEM.description = "A long cylinder that can illuminate an area if powered.";
Clockwork.item:Register(ITEM);