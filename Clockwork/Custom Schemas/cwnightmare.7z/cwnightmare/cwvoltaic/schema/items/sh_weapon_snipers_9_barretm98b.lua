--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Barret M98B";
	ITEM.cost = 50000;
	ITEM.model = "models/weapons/w_barrett_m98b.mdl";
	ITEM.weight = 4;
	ITEM.access = "V";
	ITEM.batch = 1;
	ITEM.category = "Snipers";
	ITEM.weaponClass = "m9k_m98b";
	ITEM.uniqueID = "m9k_m98b";
	ITEM.business = true;
	ITEM.description = "A bolt-action sniper rifle.\nUtilizes .50 BMG rounds.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	--ITEM.loweredOrigin = Vector(3, 0, -4);
	--ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();