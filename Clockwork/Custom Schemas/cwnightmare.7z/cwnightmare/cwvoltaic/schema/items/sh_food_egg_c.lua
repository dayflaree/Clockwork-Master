--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Cooked Egg";
ITEM.cost = 3;
ITEM.model = "models/props_c17/streetsign004e.mdl";
ITEM.weight = .3;
ITEM.uniqueID = "cw_egg_c";
ITEM.useText = "Eat";
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.category = "Consumables";
ITEM.description = "An egg on a plate, it looks delicious.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 20, 0, 100));
		player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 10, 0, 100) );
	player:BoostAttribute(self.name, ATB_ACROBATICS, 4, 600);
end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_c17/furnituremetal001a");
	end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();