ITEM = Clockwork.item:New("weapon_base", true);
ITEM.name = "Custom Weapon";
ITEM.damageScale = 100;

ITEM:AddData("Name", "", true);
ITEM:AddData("Desc", "", true);
ITEM:AddData("Found", false);
ITEM:AddData("Rarity", 0, true);
ITEM:AddData("Damage", -1, true);
ITEM:AddData("IDLocked", false);

ITEM:AddQueryProxy("damageScale", "Damage", true);
ITEM:AddQueryProxy("description", "Desc", true);
ITEM:AddQueryProxy("name", "Name", true);
--ITEM.customFunctions = {"Personalize"};


-- A function to get the item's rarity color.
function ITEM:GetRarityColor()
	if (self:GetData("Rarity") == 1) then
		return Color(73, 184, 255, 255);
	elseif (self:GetData("Rarity") == 2) then
		return Color(255, 85, 85, 255);
	elseif (self:GetData("Rarity") == 3) then
		return Color(119, 198, 89, 255);
	elseif (self:GetData("Rarity") == 4) then
		return Color(247, 46, 245, 255);
	elseif (self:GetData("Rarity") == 5) then
		return Color(247, 192, 46, 255);
	end;
end;

--[[
function ITEM:CanEdit()
if player:HasItemByID("handheld_radio") then

	return true

	else

	return false

	end
end
--]]


ITEM:AddQueryProxy("color", ITEM.GetRarityColor);

if (CLIENT) then
	function ITEM:GetClientSideInfo()
		local weaponBaseClass = self:GetBaseClass("weapon_base");
		local clientSideInfo = weaponBaseClass.GetClientSideInfo(self);
		local damageScale = self("damageScale");
		local itemRarity = self:GetData("Rarity");
		
		if (!clientSideInfo) then
			clientSideInfo = "";
		end;
		
		clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Damage Scale: "..math.floor(damageScale).."%");
		
		if (itemRarity == 1) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Generic", Color(73, 184, 255, 255));
		elseif (itemRarity == 2) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Generic", Color(255, 85, 85, 255));
		elseif (itemRarity == 3) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Unique", Color(119, 198, 89, 255));
		elseif (itemRarity == 4) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Rare", Color(247, 46, 245, 255));
		elseif (itemRarity == 5) then
			clientSideInfo = Clockwork.kernel:AddMarkupLine(clientSideInfo, "Legendary", Color(247, 192, 46, 255));
		end;
		
		return (clientSideInfo != "" and clientSideInfo);
	end;
	
	-- Called when the item entity's menu options are needed.
	function ITEM:GetEntityMenuOptions(entity, options)
		if (Clockwork.player:HasFlags(Clockwork.Client, "h")) then
			options["Customize"] = function()
				local customData = {};
				
				Derma_StringRequest("Name", "What would you like to set the name to?", "", function(text)
					customData.name = text;
					
				Derma_StringRequest("Rarity", "Color of the weapon text. 1 is Blue, 2 is Red 3 is Green. 4 is Purple, 5 is Gold", "", function(text)
					customData.rarity = math.Clamp(tonumber(text), 0, 5);
					
				Derma_StringRequest("Damage", "How much should we scale weapon damage by (the default is 100%)?", "", function(text)
					customData.damage = math.Clamp(tonumber(text), 0, 500);
					
				Derma_StringRequest("Description", "What would you like to set the description to?", "", function(text)
					customData.desc = text;
					
					if (IsValid(entity)) then
						Clockwork.entity:ForceMenuOption(
							entity, "Customize", customData
						);
					end;
				end); end); end); end);
			end;
		end;
	end
end;

--[[
if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (name == "Personalize") then
		if player:HasItemByID("handheld_radio") then
				local customData = {};
				
				Derma_StringRequest("Name", "What would you like to set the name to?", "", function(text)
					customData.name = text;
					
				Derma_StringRequest("Rarity", "Color of the weapon text. 1 is Blue, 2 is Red 3 is Green.", "", function(text)
					customData.rarity = math.Clamp(tonumber(text), 0, 3);
					
				Derma_StringRequest("Description", "What would you like to set the description to?", "", function(text)
					customData.desc = text;
					
					if (IsValid(entity)) then
						Clockwork.entity:ForceMenuOption(
							entity, "Customize", customData
						);
					end;
				end); end); end);
			end;
		else
		
		return false
		
		end;
		local weaponBaseClass = self:GetBaseClass("weapon_base");
		
		if (weaponBaseClass) then
			weaponBaseClass.GetEntityMenuOptions(self, entity, options);
		end;
	end;
	end
--]]

Clockwork.item:Register(ITEM);