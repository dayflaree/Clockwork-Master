local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Novice Book";
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.weight = .1;
ITEM.business = false;
ITEM.uniqueID = "cw_starting_book";
ITEM.category = "Storage";
ITEM.description = "This is a serious roleplay server, please go onto the forums and get the content, if you are new to roleplay you will also be able to find guides there\nDrop this item to receive starting items.";


-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("cw_novice_pack_" .. math.random(1,8) .. "");
		
	player:GiveItem(instance, true);
end;
ITEM:Register();
