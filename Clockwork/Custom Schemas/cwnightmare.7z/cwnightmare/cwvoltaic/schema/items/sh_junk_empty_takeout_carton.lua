--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Takeout Carton";
	ITEM.batch = 1;
	ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl";
	ITEM.weight = 0.1
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.description = "An old and empty takeout carton.";

Clockwork.item:Register(ITEM);