--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Guitar";
	ITEM.batch = 1;
	ITEM.model = "models/props_phx/misc/fender.mdl";
	ITEM.weight = 0.75;
	ITEM.category = "Scavenging";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.useText = "Play";
	ITEM.uniqueID = "cw_guitar";
	ITEM.useSound = "physics/metal/metal_box_strain2.wav";
	ITEM.description = "A popular musical instrument that makes sound by the playing of its (typically) six strings with the sound being projected either acoustically or through electrical amplification (for an acoustic guitar or an electric guitar, respectively). It is typically played by strumming or plucking the strings with the right hand while fretting the strings with the left hand.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local instance = Clockwork.item:CreateInstance("cw_guitar");
		
	player:GiveItem(instance, true);
end;

	-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);