local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Meal Ready to Eat";
ITEM.cost = 40;
ITEM.model = "models/weapons/w_package.mdl";
ITEM.weight = 1;
ITEM.access = "v";
ITEM.useText = "Eat";
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.description = "A small box, it has 'M.R.E.' writen on it. \n It contains a freeze dried meal.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 3, 0, 100));
	player:BoostAttribute(self.name, ATB_AGILITY, 4, 600);
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 30, 0, 100) );
	player:BoostAttribute(self.name, ATB_ENDURANCE, 4, 600);
	player:BoostAttribute(self.name, ATB_STRENGTH, 4, 600);
	
	local instance = Clockwork.item:CreateInstance("mre_packaging");
	
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);