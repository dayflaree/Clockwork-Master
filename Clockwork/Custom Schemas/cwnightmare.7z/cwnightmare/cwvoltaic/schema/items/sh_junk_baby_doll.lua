--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Baby Doll";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_c17/doll01.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An old baby doll, it's missing an eye.";
Clockwork.item:Register(ITEM);