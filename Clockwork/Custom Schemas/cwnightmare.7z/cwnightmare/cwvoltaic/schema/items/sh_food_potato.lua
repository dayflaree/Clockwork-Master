--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Potato";
ITEM.cost = 3;
ITEM.model = "models/props_phx/misc/potato.mdl";
ITEM.weight = .2;
ITEM.access = "v";
ITEM.uniqueID = "cw_potato";
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.business = true;
ITEM.description = "A brown vegetable, it seems rough.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 3, 0, 100));
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 40, 0, 100) );
	player:BoostAttribute(self.name, ATB_ENDURANCE, 4, 600);
end;
	

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();