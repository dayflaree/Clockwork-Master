--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Battery";
	ITEM.batch = 1;
	ITEM.model = "models/Items/car_battery01.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "cw_battery";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "An energy storing battery, useful for electronics.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);