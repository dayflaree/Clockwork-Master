--[[
        © 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New();
ITEM.name = "Scrap Package";
ITEM.model = "models/props_junk/cardboard_box003a.mdl";
ITEM.weight = 4;
ITEM.uniqueID = "cw_scrap_pack";
ITEM.useText = "Open";
ITEM.description = "A medium sized box containing useful crafting materials.";
 
-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
        if (quickUse) then
                if (!player:CanHoldWeight(self.weight)) then
                        Clockwork.player:Notify(player, "You do not have enough inventory space!");
                       
                        return false;
                end;
        end;
end;
 
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)

                player:GiveItem(Clockwork.item:CreateInstance("cw_scrapc"), true);
                player:GiveItem(Clockwork.item:CreateInstance("cw_metal"), true);
                player:GiveItem(Clockwork.item:CreateInstance("cw_wood"), true);
                player:GiveItem(Clockwork.item:CreateInstance("cw_cardboard"), true);
                player:GiveItem(Clockwork.item:CreateInstance("cw_plastic"), true);

end;
 
-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
 
ITEM:Register();