--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Cinder Block";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.model = "models/props_junk/cinderblock01a.mdl";
	ITEM.weight = 1.25;
	ITEM.description = "A heavy block of concrete.";
Clockwork.item:Register(ITEM);