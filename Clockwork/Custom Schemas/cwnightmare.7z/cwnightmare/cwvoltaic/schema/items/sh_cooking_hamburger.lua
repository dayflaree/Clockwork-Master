--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Recipe: Hamburger";
	ITEM.cost = 20;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_hamburger_r";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Create";
	ITEM.business = true;
	ITEM.category = "Recipes";
	ITEM.useSound = "items/ammocrate_open.wav";
	ITEM.description = "A recipe that explains how to make a tasty meal out of some delicious materials. \n1x Cooked Hamburger Meat";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred= player:FindItemByID("cw_hamburger_cooked");
local giveCooked = Clockwork.item:CreateInstance("cw_hamburger");
local giveBlueprint = Clockwork.item:CreateInstance("cw_hamburger_r");

if (getIngred) then
player:TakeItem(getIngred, true);
player:GiveItem(giveCooked, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required ingredients or tools!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);