--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "M24";
	ITEM.cost = 3000;
	ITEM.model = "models/weapons/w_snip_m24_6.mdl";
	ITEM.weight = 5.4;
	ITEM.batch = 1;
	ITEM.category = "Snipers";
	ITEM.weaponClass = "m9k_m24";
	ITEM.access = "V";
	ITEM.uniqueID = "m9k_m24";
	ITEM.business = true;
	ITEM.description = "The military and police version of the Remington 700 rifle.\nUtilizes 7.62x51mm rounds.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	--ITEM.loweredOrigin = Vector(3, 0, -4);
	--ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();