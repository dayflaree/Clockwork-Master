--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
	ITEM.name = "Bottled Water";
	ITEM.cost = 4;
	ITEM.model = "models/props_junk/glassbottle01a.mdl";
	ITEM.weight = 0.2;
	ITEM.access = "v";
	ITEM.uniqueID = "cw_water";
	ITEM.business = true;
	ITEM.useText = "Drink";
	ITEM.useSound = "npc/barnacle/barnacle_gulp1.wav";
	ITEM.category = "Consumables";
	ITEM.description = "A bottle of clear water, it restores Stamina.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData("stamina", 100);
	player:SetHealth( math.Clamp(player:Health() + 10, 0, 100) );
	player:SetCharacterData( "thirst", math.Clamp(player:GetCharacterData("thirst") - 25, 0, 100) );
	player:BoostAttribute(self.name, ATB_AGILITY, 4, 600);
	player:BoostAttribute(self.name, ATB_STAMINA, 4, 600);
	
	local instance = Clockwork.item:CreateInstance("cw_eb_water");
		
	player:GiveItem(instance, true);
end;

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);