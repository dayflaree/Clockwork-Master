--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_weapon");
ITEM.name = "Sledgehammer";
ITEM.model = "models/weapons/w_sledgehammer.mdl";
ITEM.weight = 6;
ITEM.batch = 1;
ITEM.cost = 120;
ITEM.uniqueID = "cw_sledgehammer";
ITEM.category = "Melee";
ITEM.description = "A tool with a large, flat head attached to a hand. The head is made of metal.";
ITEM.meleeWeapon = true;
ITEM.isAttachment = true;
ITEM.business = true;
ITEM.access = "v";
ITEM.loweredOrigin = Vector(-12, 2, 0);
ITEM.loweredAngles = Angle(-25, 15, -80);
ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 255, 0);
ITEM.attachmentOffsetVector = Vector(5, 5, -8);

ITEM:Register();