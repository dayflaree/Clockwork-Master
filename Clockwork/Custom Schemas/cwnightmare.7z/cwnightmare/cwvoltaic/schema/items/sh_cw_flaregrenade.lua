local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Flare Grenade";
	ITEM.cost = 25;
	ITEM.model = "models/items/grenadeammo.mdl";
	ITEM.weight = 0.8;
	ITEM.uniqueID = "cw_flaregrenade";
	ITEM.description = "A makeshift flare grenade, used to light up a dark area.";
	ITEM.isAttachment = true;
	ITEM.access = "V1";
	ITEM.business = true;	
	ITEM.category = "Grenades"
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();