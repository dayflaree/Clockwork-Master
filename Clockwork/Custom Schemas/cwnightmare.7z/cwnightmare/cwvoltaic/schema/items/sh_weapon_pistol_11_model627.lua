local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "S&W Model 627";
	ITEM.cost = 575;
	ITEM.model = "models/Weapons/W_357.mdl";
	ITEM.weight = 1;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Pistols";
	ITEM.weaponClass = "m9k_model627";
	ITEM.uniqueID = "m9k_model627";
	ITEM.business = true;
	ITEM.description = "A double action revolver.\nUtilizes .357 rounds.";
	
	ITEM.hasFlashlight = false;
    ITEM.loweredOrigin = Vector(0.67, 0.865, -0.866)
    ITEM.loweredAngles = Angle(-14.461, 34.729, -7.441)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(-180, 180, 90);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();