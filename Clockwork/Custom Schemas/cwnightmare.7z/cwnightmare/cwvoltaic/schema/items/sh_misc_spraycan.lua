local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Spray Can";
ITEM.cost = 15;
ITEM.model = "models/sprayca2.mdl";
ITEM.weight = 1;
ITEM.access = "v";
ITEM.category = "Reusables";
ITEM.business = true;
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "A standard sized spray can filled with paint.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();