--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Beer Bottle";
	ITEM.batch = 1;
	ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl";
	ITEM.weight = 0.1;
	ITEM.uniqueID = "cw_beer_empty";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "An empty glass bottle that smells of alcohol.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);