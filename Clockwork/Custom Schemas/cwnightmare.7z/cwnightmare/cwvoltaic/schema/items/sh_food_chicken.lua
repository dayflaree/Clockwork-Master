--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Fried Chicken";
ITEM.cost = 14;
ITEM.model = "models/Gibs/HGIBS_scapula.mdl";
ITEM.weight = .25;
ITEM.access = "v";
ITEM.uniqueID = "cw_chicken";
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.description = "It tastes just like- fuck you for thinking of that, eat a dick.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, 100));
	player:BoostAttribute(self.name, ATB_STAMINA, 1, 600);
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 10, 0, 100) );
end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk");
	end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();