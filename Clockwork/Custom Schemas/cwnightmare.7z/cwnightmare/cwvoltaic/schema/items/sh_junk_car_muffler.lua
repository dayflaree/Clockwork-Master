--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Car Muffler";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.uniqueID = "cw_muffler";
	ITEM.model = "models/props_vehicles/carparts_muffler01a.mdl";
	ITEM.weight = 4;
	ITEM.description = "A metal muffler that was once attached to a car.";
Clockwork.item:Register(ITEM);