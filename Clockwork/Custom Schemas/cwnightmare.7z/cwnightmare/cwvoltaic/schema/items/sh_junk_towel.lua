--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Towel";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.model = "models/props_junk/garbage_carboard002a.mdl";
	ITEM.weight = 0.2;
	ITEM.description = "A piece of absorbent fabric used for drying.";
	
	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_c17/FurnitureFabric003a");
	end;
	
Clockwork.item:Register(ITEM);