--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Blueprint: Skull Mask";
	ITEM.cost = 1000;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bskull_mask";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains how to create a makeshift mask with a skull and a knife. \n1x Human Skull";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred = player:FindItemByID("cw_metal");
local getTool = player:FindItemByID("cw_knife");
local giveCrafted = Clockwork.item:CreateInstance("skullMask");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bskull_mask");

if (getIngred and getTool) then
player:TakeItem(getIngred, true);
player:GiveItem(giveCrafted, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have all the materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);