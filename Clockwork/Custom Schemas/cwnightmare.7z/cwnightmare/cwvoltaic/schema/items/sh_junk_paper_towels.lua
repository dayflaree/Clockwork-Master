--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Paper Towels";
	ITEM.batch = 1;
	ITEM.plural = "Paper Towels";
	ITEM.access = "j";
	ITEM.useText = "Salvage";
	ITEM.business = true;
	ITEM.model = "models/props/cs_office/Paper_towels.mdl";
	ITEM.weight = 0.2;
	ITEM.description = "A large roll of convenient paper towels.";
	
		-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("paper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
	
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
	
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
	
	player:GiveItem(instance, true);
end;
Clockwork.item:Register(ITEM);