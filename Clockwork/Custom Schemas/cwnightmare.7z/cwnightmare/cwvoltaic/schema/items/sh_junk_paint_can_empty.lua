--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Paint Can";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.uniqueID = "cw_paint_can_empty";
	ITEM.model = "models/props_junk/metal_paintcan001a.mdl";
	ITEM.weight = .2;
	ITEM.description = "An empty can that once contained paint.";
	
Clockwork.item:Register(ITEM);