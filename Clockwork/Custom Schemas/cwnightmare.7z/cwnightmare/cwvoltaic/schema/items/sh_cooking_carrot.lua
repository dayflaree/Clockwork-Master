--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Recipe: Boiled Carrots";
	ITEM.cost = 20;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_carrot_r";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Cook";
	ITEM.business = true;
	ITEM.category = "Recipes";
	ITEM.useSound = "ambient/fire/mtov_flame2.wav";
	ITEM.description = "A recipe that explains how to boil carrots with a large pot. \n1x Deep Pot \n1x Carrot";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred= player:FindItemByID("cw_carrot");
local getPan= player:FindItemByID("cw_pan");
local giveCooked = Clockwork.item:CreateInstance("cw_carrot_cooked");
local giveBlueprint = Clockwork.item:CreateInstance("cw_carrot_r");

if (getIngred and getPan) then
player:TakeItem(getIngred, true);
player:GiveItem(giveCooked, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required ingredients or tools!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);