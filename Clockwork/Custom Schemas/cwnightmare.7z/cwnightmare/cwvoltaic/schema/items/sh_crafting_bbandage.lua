--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Blueprint: Bandages";
	ITEM.cost = 500;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bbandage";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains how to use clothing scraps as bandages. \n1x Scrap Clothing";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getScrapc= player:FindItemByID("cw_scrapc");
local giveBandage = Clockwork.item:CreateInstance("cw_bandage");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bbandage");

if (getScrapc) then
player:TakeItem(getScrapc, true);
player:GiveItem(giveBandage, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required crafting materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);