local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Breach";
ITEM.cost = 50;
ITEM.model = "models/props_wasteland/prison_padlock001a.mdl";
ITEM.plural = "Breaches";
ITEM.weight = 0.5;
ITEM.access = "V";
ITEM.useText = "Place";
ITEM.category = "Useful";
ITEM.business = true;
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "A small device capable of blowing a door off of its hinges.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local trace = player:GetEyeTraceNoCursor();
	local entity = trace.Entity;
	
	if (IsValid(entity)) then
		if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
			if (!IsValid(entity.breach)) then
				if (Clockwork.plugin:Call("PlayerCanBreachEntity", player, entity)) then
					local breach = ents.Create("cw_breach"); breach:Spawn();
					
					breach:SetBreachEntity(entity, trace);
				else
					Clockwork.player:Notify(player, "This entity cannot be breached!");
					
					return false;
				end;
			else
				Clockwork.player:Notify(player, "This entity already has a breach!");
				
				return false;
			end;
		else
			Clockwork.player:Notify(player, "You are not close enough to the entity!");
			
			return false;
		end;
	else
		Clockwork.player:Notify(player, "That is not a valid entity!");
		
		return false;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();