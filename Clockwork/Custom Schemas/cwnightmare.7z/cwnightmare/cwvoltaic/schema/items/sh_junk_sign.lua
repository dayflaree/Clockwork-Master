--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Road Sign";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.useText = "Salvage";
	ITEM.model = "models/props_c17/streetsign004f.mdl";
	ITEM.weight = 1;
	ITEM.description = "A road sign that seems to have been misplaced.";
	
		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getSalvager = player:FindItemByID("cw_salvager");
local giveScraps = Clockwork.item:CreateInstance("cw_metal");
local giveSalvager = Clockwork.item:CreateInstance("cw_salvager");

if (getSalvager) then
player:GiveItem(giveScraps, true);
else
Clockwork.player:Notify(player, "You do not have the required equipment!");
return false;
end;
end;
Clockwork.item:Register(ITEM);