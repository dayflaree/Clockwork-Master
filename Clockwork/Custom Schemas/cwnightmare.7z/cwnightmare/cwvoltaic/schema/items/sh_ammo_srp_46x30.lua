--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 110;
	ITEM.name = "Box of 4.6x30mm(x30)";
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_battery";
	ITEM.ammoClass = "Battery";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box containing 4.6x30mm rounds.";
Clockwork.item:Register(ITEM);