--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Pick Axe Head";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_mining/pickaxe01_head.mdl";
	ITEM.weight = .75;
	ITEM.description = "The head of a pick axe.";
Clockwork.item:Register(ITEM);