--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Stuffed Turtle";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.model = "models/props/de_tides/vending_turtle.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An old childrens' toy.";
Clockwork.item:Register(ITEM);