--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "73 Winchester Carbine";
	ITEM.cost = 800;
	ITEM.batch = 1;
	ITEM.model = "models/weapons/w_winchester_1873.mdl";
	ITEM.weight = 3;
	ITEM.access = "V";
	ITEM.category = "Assault Rifles";
	ITEM.business = true;
	ITEM.weaponClass = "m9k_winchester73";
	ITEM.uniqueID = "m9k_winchester73";
	ITEM.description = "A powerful lever action rifle./nUtilizes .40 Winchester rounds";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();