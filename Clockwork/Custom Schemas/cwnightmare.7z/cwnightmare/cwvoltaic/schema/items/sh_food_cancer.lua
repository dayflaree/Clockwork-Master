--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Cancer";
ITEM.cost = 4;
ITEM.model = "models/Gibs/HGIBS.mdl";
ITEM.weight = 0.6;
ITEM.useSound = "npc/barnacle/barnacle_gulp1.wav";
ITEM.access = "v";
ITEM.business = false;
ITEM.attributes = {Strength = 10};
ITEM.description = "You have literally found cancer.";

-- Called when a player drinks the item.
function ITEM:OnDrink(player)
	player:SetCharacterData( "thirst", math.Clamp(player:GetCharacterData("thirst") - 5, 0, 100) );
	player:TakeDamage(75, player, player);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();