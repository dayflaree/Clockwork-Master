--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Chocolate Box";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_lab/box01b.mdl";
	ITEM.weight = .1;
	ITEM.description = "An empty box that smells like chocolate.";
Clockwork.item:Register(ITEM);