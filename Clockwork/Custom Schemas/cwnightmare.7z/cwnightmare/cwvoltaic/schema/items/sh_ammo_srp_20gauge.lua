--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 120;
	ITEM.name = "Box of 20 Gauge Shells(x20)";
	ITEM.model = "models/Items/BoxBuckshot.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_20gauge";
	ITEM.ammoClass = "buckshot";
	ITEM.ammoAmount = 20;
	ITEM.description = "A box containing 20-gauge shells.";
Clockwork.item:Register(ITEM);