--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Gear";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_mining/elevator_winch_cog.mdl";
	ITEM.weight = 2.5;
	ITEM.description = "An old metal gear from some type of machine.";
Clockwork.item:Register(ITEM);