--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Scrap Metal";
	ITEM.batch = 1;
	ITEM.model = "models/props_c17/oildrumchunk01e.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "cw_metal";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A sheet of old metal.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);