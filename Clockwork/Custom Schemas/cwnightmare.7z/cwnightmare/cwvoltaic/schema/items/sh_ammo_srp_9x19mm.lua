--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 90;
	ITEM.name = "Box of 9x19mm(x25)";
	ITEM.model = "models/Items/BoxSRounds.mdl";
	ITEM.weight = .75;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_pistol";
	ITEM.ammoClass = "pistol";
	ITEM.ammoAmount = 25;
	ITEM.description = "A box containing 9x19mm rounds.";
Clockwork.item:Register(ITEM);