--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Moonshine";
ITEM.cost = 5;
ITEM.model = "models/props_junk/plasticbucket001a.mdl";
ITEM.weight = 1;
ITEM.access = "v";
ITEM.uniqueID = "cw_moonshine";
ITEM.business = true;
ITEM.attributes = {Strength = 20};
ITEM.description = "A glass bottle filled with liquid, it has a funny smell.";

-- Called when a player drinks the item.
function ITEM:OnDrink(player)
	
	local instance = Clockwork.item:CreateInstance("moonshine_bucket");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();