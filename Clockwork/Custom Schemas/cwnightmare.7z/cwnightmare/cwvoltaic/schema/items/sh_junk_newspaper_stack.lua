--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Stack of Newspapers";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.useText = "Salvage";
	ITEM.model = "models/props/cs_militia/newspaperstack01.mdl";
	ITEM.weight = 4;
	ITEM.description = "A large stack of old newspapers.";
	
	-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("newspaper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("newspaper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("newspaper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("newspaper");
		
	player:GiveItem(instance, true);
end;
Clockwork.item:Register(ITEM);