--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Chocolate";
ITEM.cost = 7;
ITEM.plural = "Boxes of Chocolate";
ITEM.model = "models/props_lab/box01a.mdl";
ITEM.weight = 0.3;
ITEM.access = "v";
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.description = "A box of delicious chocolates.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 2, 0, player:GetMaxHealth()));
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 10, 0, 100) );
	
	local instance = Clockwork.item:CreateInstance("empty_chocolate_box");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();