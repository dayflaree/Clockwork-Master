--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 100;
	ITEM.name = "Box of .45 ACP (x30)";
	ITEM.model = "models/Items/BoxSRounds.mdl";
	ITEM.weight = .75;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_thumper";
	ITEM.ammoClass = "Thumper";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box containing .45 ACP rounds.";
Clockwork.item:Register(ITEM);