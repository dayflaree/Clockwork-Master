--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Cooking Pot";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.uniqueID = "cw_pot";
	ITEM.useText = "Salvage";
	ITEM.model = "models/props_interiors/pot02a.mdl";
	ITEM.weight = 0.2;
	ITEM.description = "A dirty pot used for cooking.";
	
		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getSalvager = player:FindItemByID("cw_salvager");
local giveScraps = Clockwork.item:CreateInstance("cw_metal");

if (getSalvager) then
player:GiveItem(giveScraps, true);
else
Clockwork.player:Notify(player, "You do not have the required equipment!");
return false;
end;
end;
Clockwork.item:Register(ITEM);