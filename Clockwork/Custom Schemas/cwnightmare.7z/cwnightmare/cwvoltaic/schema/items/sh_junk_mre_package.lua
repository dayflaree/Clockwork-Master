--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "MRE Packaging";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.uniqueID = "cw_mre_p";
	ITEM.model = "models/weapons/w_package.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "The plastic packaging of an MRE.";
Clockwork.item:Register(ITEM);