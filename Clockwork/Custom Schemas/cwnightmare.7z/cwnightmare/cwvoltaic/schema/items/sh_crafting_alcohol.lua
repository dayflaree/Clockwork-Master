--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Distilled Alcohol";
	ITEM.batch = 1;
	ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl";
	ITEM.weight = .1;
	ITEM.uniqueID = "cw_alcohol";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A small bottled containing distilled alcohol.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);