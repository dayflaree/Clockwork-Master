--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Ares Shrike";
	ITEM.cost = 10000;
	ITEM.model = "models/weapons/w_ares_shrike.mdl";
	ITEM.weight = 3.4;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Machine Guns";
	ITEM.weaponClass = "m9k_ares_shrike";
	ITEM.uniqueID = "m9k_ares_shrike";
	ITEM.business = true;
	ITEM.description = "A massive weapon that is air-cooled, and dual-feed.\nUtilizes 5.56x45mm rounds.";
	ITEM.isAttachment = true;	
	ITEM.hasFlashlight = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();