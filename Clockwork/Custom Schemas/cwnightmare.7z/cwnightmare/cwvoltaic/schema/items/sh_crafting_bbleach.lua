--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Blueprint: Bleach";
	ITEM.cost = 1000;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bbleach";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains a good way to put bleach into another container. \n1x Bleach \n1x Scrap Platic";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred = player:FindItemByID("cw_plastic");
local getIngred2 = player:FindItemByID("cw_chemical");
local giveCrafted = Clockwork.item:CreateInstance("cw_bleach");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bbleach");

if (getIngred and getIngred2) then
player:TakeItem(getIngred, true);
player:TakeItem(getIngred2, true);
player:GiveItem(giveCrafted, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);