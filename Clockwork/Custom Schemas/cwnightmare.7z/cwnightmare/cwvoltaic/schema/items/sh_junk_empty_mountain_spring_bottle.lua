--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Mountain Spring Bottle";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.uniqueID = "cw_eb_mountain";
	ITEM.model = "models/props/cs_office/water_bottle.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An empty bottle made of plastic, it has no scent.";
Clockwork.item:Register(ITEM);