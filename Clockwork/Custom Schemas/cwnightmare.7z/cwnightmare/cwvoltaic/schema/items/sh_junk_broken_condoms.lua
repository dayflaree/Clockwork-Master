--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Broken Condoms";
	ITEM.cost = 30;
	ITEM.model = "models/props_lab/box01a.mdl";
	ITEM.weight = 0.1;
	ITEM.access = "v";
	ITEM.uniqueID = "cw_broken_condoms";
	ITEM.business = true;
	ITEM.useText = "Wrap it";
	ITEM.useSound = "npc/barnacle/barnacle_tongue_pull3.wav";
	ITEM.category = "Sexual";
	ITEM.description = "Even if you wrap it, you might still pap it.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp(player:Health() + 10, 0, 100) );
	player:BoostAttribute(self.name, ATB_AGILITY, 4, 600);
	player:BoostAttribute(self.name, ATB_STAMINA, 4, 600);
	
end;

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);