--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Horse Sized Dildo";
	ITEM.batch = 1;
	ITEM.model = "models/gibs/hgibs_spine.mdl";
	ITEM.weight = .5;
	ITEM.category = "Sexual";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.useText = "Insert";
	ITEM.uniqueID = "cw_dildo_h";
	ITEM.useSound = "vo/npc/female01/pain06.wav";
	ITEM.description = "Swiggity Swooty, I'm comin- Oh Jesus Christ that's horrifying.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local instance = Clockwork.item:CreateInstance("cw_dildo_h");
		
	player:GiveItem(instance, true);
end;

	-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_c17/furnituremetal001a");
end;

	-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);