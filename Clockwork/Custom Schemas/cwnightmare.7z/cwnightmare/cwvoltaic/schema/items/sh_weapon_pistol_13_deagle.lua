local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "Deagle";
	ITEM.cost = 1050;
	ITEM.model = "models/weapons/w_tcom_deagle.mdl";
	ITEM.weight = 1;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Pistols";
	ITEM.weaponClass = "m9k_deagle";
	ITEM.uniqueID = "m9k_deagle";
	ITEM.business = true;
	ITEM.description = "A large-framed, gas-operated, semi-automatic pistol.\nUtilizes .357 rounds.";
	
	ITEM.hasFlashlight = false;
    ITEM.loweredOrigin = Vector(0.67, 0.865, -0.866)
    ITEM.loweredAngles = Angle(-14.461, 34.729, -7.441)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 180);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();