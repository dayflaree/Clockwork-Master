--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Briefcase";
	ITEM.model = "models/props_c17/BriefCase001a.mdl";
	ITEM.weight = 0.2;
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.description = "An old brown briefcase.";
Clockwork.item:Register(ITEM);