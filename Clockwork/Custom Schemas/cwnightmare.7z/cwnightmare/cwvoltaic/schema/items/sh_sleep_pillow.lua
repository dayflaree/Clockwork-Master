--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Pillow";
	ITEM.batch = 1;
	ITEM.cost = 5;
	ITEM.category = "Useful";
	ITEM.access = "v";
	ITEM.uniqueID = "cw_pillow";
	ITEM.useText = "Sleep On";
	ITEM.business = true;
	ITEM.model = "models/hunter/blocks/cube025x05x025.mdl";
	ITEM.useSound = "physics/metal/metal_box_footstep1.wav";
	ITEM.weight = 0.1;
	ITEM.description = "A soft pillow, it seems to be in fairly good condition.";
	
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local instance = Clockwork.item:CreateInstance("cw_pillow");
		
	player:GiveItem(instance, true);
	
	player:SetCharacterData( "sleep", math.Clamp(player:GetCharacterData("sleep") - 50, 0, 100) );
	
end;
	
	-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_c17/furnituremetal001a");
end;
	

Clockwork.item:Register(ITEM);