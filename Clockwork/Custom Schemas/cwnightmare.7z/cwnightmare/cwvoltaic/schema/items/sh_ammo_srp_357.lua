--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 120;
	ITEM.name = "Box of .357 (x12)";
	ITEM.model = "models/Items/357ammo.mdl";
	ITEM.weight = .75;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_357";
	ITEM.ammoClass = "357";
	ITEM.ammoAmount = 12;
	ITEM.description = "A box containing .357 rounds.";
Clockwork.item:Register(ITEM);