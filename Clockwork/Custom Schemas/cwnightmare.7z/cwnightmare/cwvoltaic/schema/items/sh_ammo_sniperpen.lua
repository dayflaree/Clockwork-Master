--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New();
ITEM.base = "ammo_base";
ITEM.name = "Multipurpose Sniper Ammunition";
ITEM.model = "models/items/boxmrounds.mdl";
ITEM.weight = 1;
ITEM.uniqueID = "ammo_sniperpen";
ITEM.ammoClass = "SniperPenetratedRound";
ITEM.ammoAmount = 40;
ITEM.description = "A large green container filled with various large caliber rounds used for snipers.";

Clockwork.item:Register(ITEM);