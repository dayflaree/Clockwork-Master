--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Milk Carton";
	ITEM.model = "models/props_junk/garbage_milkcarton002a.mdl";
	ITEM.weight = 0.1;
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.description = "An empty milk carton, it smells like rotten milk.";
Clockwork.item:Register(ITEM);