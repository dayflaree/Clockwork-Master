--[[
	� 2011 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_clothes");
ITEM.cost = 1250;
ITEM.name = "Arctic Military Outfit";
ITEM.weight = 2.5;
ITEM.batch = 1;
ITEM.access = "M";
ITEM.uniqueID = "cw_a_military2"
ITEM.business = true;
ITEM.category = "Clothing";
ITEM.armorScale = 0.08;
ITEM.replacement = "models/mw2/skin_05/mw2_soldier_03.mdl";
ITEM.description = "A camouflaged suit with protective qualities.";

function ITEM:OnChangedClothes(player, boolean)
	if (boolean) then
		player:BoostAttribute(self.name, ATB_ACROBATICS, 5, nil, true);
		player:BoostAttribute(self.name, ATB_ENDURANCE, 10, nil, true)
	else
		player:BoostAttribute(self.name, ATB_ACROBATICS, false);
		player:BoostAttribute(self.name, ATB_ENDURANCE, false);
	end;
end;


ITEM:Register();