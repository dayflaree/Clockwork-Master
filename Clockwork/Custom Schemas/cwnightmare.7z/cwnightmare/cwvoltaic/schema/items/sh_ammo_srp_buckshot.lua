--[[
Name: "sh_ammo_buckshot.lua".
Product: "Novus Two".
--]]

local ITEM = Clockwork.item:New("ammo_base");

ITEM.cost = 80;
ITEM.name = "Box of Buckshot (x12)";
ITEM.batch = 1;
ITEM.model = "models/Items/BoxBuckshot.mdl";
ITEM.weight = 0.5;
ITEM.access = "V";
ITEM.business = true;
ITEM.uniqueID = "ammo_buckshot";
ITEM.ammoClass = "Buckshot";
ITEM.ammoAmount = 12;
ITEM.description = "A small brown box filled with 'Buckshot' worded on the side.";

ITEM:Register();