--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
	ITEM.name = "Cooked Human Meat";
	ITEM.model = "models/Gibs/Antlion_gib_small_2.mdl";
	ITEM.weight = 0.35;
	ITEM.plural = "Cooked Human Meat";
	ITEM.useText = "Eat";
	ITEM.uniqueID = "cw_human_meat_cooked";
	ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
	ITEM.category = "Consumables";
	ITEM.isRareItem = true;
	ITEM.description = "Meat ripped from the body of a human, it smells horrid.";

	-- Called when a player uses the item.
	function ITEM:OnUse(player, itemEntity)
		player:SetHealth( math.Clamp(player:Health() + 20, 0, 100) );
		player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 50, 0, 100) );
	end;

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk");
	end;
Clockwork.item:Register(ITEM);