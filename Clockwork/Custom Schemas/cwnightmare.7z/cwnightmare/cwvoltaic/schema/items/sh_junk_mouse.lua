--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Computer Mouse";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.usetext = "Salvage";
	ITEM.access = "j";
	ITEM.model = "models/props/cs_office/computer_mouse.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An old computer mouse.";
	
		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getSalvager = player:FindItemByID("cw_salvager");
local giveScraps = Clockwork.item:CreateInstance("cw_electronic");
local giveSalvager = Clockwork.item:CreateInstance("cw_salvager");

if (getSalvager) then
player:GiveItem(giveScraps, true);
local instance = Clockwork.item:CreateInstance("metal_scrap");
	
player:GiveItem(instance, true);
else
Clockwork.player:Notify(player, "You do not have the required equipment!");
return false;
end;
end;
Clockwork.item:Register(ITEM);