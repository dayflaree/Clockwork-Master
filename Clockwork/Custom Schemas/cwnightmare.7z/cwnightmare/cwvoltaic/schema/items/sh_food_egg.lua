--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Raw Egg";
ITEM.cost = 3;
ITEM.model = "models/props_phx/misc/egg.mdl";
ITEM.weight = .1;
ITEM.access = "v";
ITEM.uniqueID = "cw_egg";
ITEM.useText = "Cook";
ITEM.useSound = "ambient/fire/mtov_flame2.wav";
ITEM.category = "Ingredients";
ITEM.business = true;
ITEM.description = "A white egg, you should cook it first.";

		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getPan = player:FindItemByID("cw_pan");
local giveCooked = Clockwork.item:CreateInstance("cw_egg_c");

if (getPan) then
player:GiveItem(giveCooked, true);
else
Clockwork.player:Notify(player, "You do not have a frying pan!");
return false;
end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();