--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Fire Extinguisher";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.usetext = "Salvage";
	ITEM.business = true;
	ITEM.model = "models/props/cs_office/Fire_Extinguisher.mdl";
	ITEM.weight = 1;
	ITEM.description = "A red fire extinguisher.";
	
		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getSalvager = player:FindItemByID("cw_salvager");
local giveScraps = Clockwork.item:CreateInstance("cw_chemical");
local giveSalvager = Clockwork.item:CreateInstance("cw_salvager");

if (getSalvager) then
player:GiveItem(giveScraps, true);
else
Clockwork.player:Notify(player, "You do not have the required equipment!");
return false;
end;
end;
Clockwork.item:Register(ITEM);