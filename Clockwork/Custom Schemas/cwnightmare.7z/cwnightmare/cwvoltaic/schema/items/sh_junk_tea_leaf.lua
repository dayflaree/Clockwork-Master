--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Tea Leaf";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.uniqueID = "cw_tea_leaf";
	ITEM.model = "models/props/cs_office/plant01_gib2.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "A tea leaf.";
	
		-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("pheonix_storms/wire/pcb_green");
	end;
Clockwork.item:Register(ITEM);