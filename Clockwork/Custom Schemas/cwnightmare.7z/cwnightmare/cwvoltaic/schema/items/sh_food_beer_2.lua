--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Absinthe";
ITEM.cost = 12;
ITEM.model = "models/props_junk/GlassBottle01a.mdl";
ITEM.weight = 0.6;
ITEM.skin = 1;
ITEM.useSound = "npc/barnacle/barnacle_gulp1.wav";
ITEM.access = "v";
ITEM.business = true;
ITEM.attributes = {Strength = 30};
ITEM.description = "A glass bottle filled with liquid, it smells alcoholic.";

-- Called when a player drinks the item.
function ITEM:OnDrink(player)
	player:SetCharacterData( "thirst", math.Clamp(player:GetCharacterData("thirst") - 5, 0, 100) );
	local instance = Clockwork.item:CreateInstance("cw_beer_empty_2");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();