local ITEM = Clockwork.item:New("ammo_base");

ITEM.name = "5.45x39mm Box (x30)"; -- The name of the item, obviously.
ITEM.cost = 250; -- How much does this item cost for people with business access to it?
ITEM.model = "models/Items/BoxMRounds.mdl"; -- What model does the item use.
ITEM.weight = 0.5; -- How much does it weigh in kg?
ITEM.access = "A"; -- What flags do you need to have access to this item in your business menu (you only need one of them)?
ITEM.useText = "Equip"; -- What does the text say instead of Use, remove this line to keep it as Use.
ITEM.category = "Ammunition"; -- What category does the item belong in?
ITEM.uniqueID = "ammo_545x39mm";  -- Optionally, you can manually set a unique ID for an item, but usually you don't need to.
ITEM.business = true;  -- Is this item available on the business menu (if the player has access to it)?
ITEM.description = "A box containing 5.45x39mm, hopefully there is something you can use.";
  -- Give a small description of the item.
function ITEM:OnDrop(player, position)
	-- If the item doesn't have this function, it cannot be dropped.
end;


function ITEM:OnUse(player, itemEntity)
player:GiveAmmo( 30, "smg1") -- honestly fuck kuro's system of doing ammo this is a bitch
end;

function ITEM:OnDestroy(player)
	-- If the item doesn't have this function, it cannot be destroyed.
end;

-- Register the item to the nexus framework.
ITEM:Register();