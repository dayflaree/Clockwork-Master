local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Hot Dog";
ITEM.cost = 15;
ITEM.model = "models/food/hotdog.mdl";
ITEM.weight = 0.1;
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "A delicious hot dog.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 5, 0, player:GetMaxHealth() ) );
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 40, 0, 100) );
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);