local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "Rocket Launcher";
	ITEM.cost = 100000;
	ITEM.model = "models/weapons/w_rocket_launcher.mdl";
	ITEM.weight = 10;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Misc Weapons";
	ITEM.weaponClass = "weapon_mad_rpg";
	ITEM.uniqueID = "weapon_mad_rpg";
	ITEM.business = true;
	ITEM.description = "A large rocket launcher.\nUtilizes rockets.";
	
	ITEM.hasFlashlight = false;
    ITEM.loweredOrigin = Vector(0.67, 0.865, -0.866)
    ITEM.loweredAngles = Angle(-14.461, 34.729, -7.441)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();