--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Blueprint: Flashlight";
	ITEM.cost = 1000;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bflashlight";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains how to create a makeshift flashlight with metal, plastic, and a battery. \n1x Scrap Metal \n1x Scrap Plastic \n1x Battery";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred = player:FindItemByID("cw_metal");
local getIngred2 = player:FindItemByID("cw_plastic");
local getIngred3 = player:FindItemByID("cw_battery");
local giveCrafted = Clockwork.item:CreateInstance("cw_flashlight");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bflashlight");

if (getIngred and getIngred2 and getIngred3) then
player:TakeItem(getIngred, true);
player:TakeItem(getIngred2, true);
player:TakeItem(getIngred3, true);
player:GiveItem(giveCrafted, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have all the materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);