--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Blueprint: Makeshift Crossbow";
	ITEM.cost = 2000;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_bcrossbow";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Craft";
	ITEM.business = true;
	ITEM.category = "Crafting";
	ITEM.useSound = {"items/ammocrate_open.wav"};
	ITEM.description = "A piece of paper that explains how to create a makeshift crossbow capable of dealing quite a lot of damage. \n1x Scrap Metal \n1x Scrap Wood \n1x Battery \n1x Scope \n1x Trigger Mechanism";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred = player:FindItemByID("cw_metal");
local getIngred2 = player:FindItemByID("cw_wood");
local getIngred3 = player:FindItemByID("cw_scope");
local getIngred4 = player:FindItemByID("cw_trigger");
local getIngred5 = player:FindItemByID("cw_battery");
local giveCrafted = Clockwork.item:CreateInstance("weapon_mad_crossbow");
local giveBlueprint = Clockwork.item:CreateInstance("cw_bcrossbow");

if (getIngred and getIngred2 and getIngred3 and getIngred4 and getIngred5) then
player:TakeItem(getIngred, true);
player:TakeItem(getIngred2, true);
player:TakeItem(getIngred3, true);
player:TakeItem(getIngred4, true);
player:TakeItem(getIngred5, true);
player:GiveItem(giveCrafted, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have all the materials!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);