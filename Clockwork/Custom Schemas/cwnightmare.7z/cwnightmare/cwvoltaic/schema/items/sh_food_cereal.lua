--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
	ITEM.name = "Cereal";
	ITEM.cost = 8;
	ITEM.model = "models/props_lab/harddrive02.mdl";
	ITEM.weight = 0.25;
	ITEM.access = "v";
	ITEM.uniqueID = "cw_cereal";
	ITEM.useText = "Eat";
	ITEM.business = true;
	ITEM.useSound = "npc/barnacle/barnacle_crunch2.wav";
	ITEM.category = "Consumables";
	ITEM.description = "Dried breakfast cereal in a convenient box.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 5, 0, player:GetMaxHealth()));
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 15, 0, 100) );
	player:BoostAttribute(self.name, ATB_STAMINA, 8, 600);
	
	local instance = Clockwork.item:CreateInstance("cereal_box");
		
	player:GiveItem(instance, true);
end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_c17/furnituremetal001a");
	end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();