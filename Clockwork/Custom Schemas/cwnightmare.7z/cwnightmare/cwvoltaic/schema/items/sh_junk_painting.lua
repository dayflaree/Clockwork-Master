--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Painting";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.usetext = "Salvage";
	ITEM.model = "models/props/de_inferno/picture3.mdl";
	ITEM.weight = .5;
	ITEM.description = "A painting from before the end.";
	
	-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("cw_wood");
		
	player:GiveItem(instance, true);

end;
Clockwork.item:Register(ITEM);