local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Chinese Food";
ITEM.cost = 20;
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl";
ITEM.weight = 0.6;
ITEM.access = "v";
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
ITEM.uniqueID = "cw_chinese"
ITEM.description = "Chinese food contained in a small takeout box.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 10, 0, player:GetMaxHealth() ) );
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 25, 0, 100) );
	player:BoostAttribute(self.name, ATB_ENDURANCE, 2, 120);
	player:BoostAttribute(self.name, ATB_ACCURACY, 1, 120);
	
	local instance = Clockwork.item:CreateInstance("empty_takeout_carton");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);