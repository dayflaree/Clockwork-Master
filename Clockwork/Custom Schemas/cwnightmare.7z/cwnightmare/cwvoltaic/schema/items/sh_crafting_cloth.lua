--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Scrap Clothing";
	ITEM.batch = 1;
	ITEM.model = "models/Gibs/wood_gib01e.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "cw_scrapc";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A torn piece of clothing.";
	
		-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_c17/furnituremetal001a");
	end;
	
Clockwork.item:Register(ITEM);