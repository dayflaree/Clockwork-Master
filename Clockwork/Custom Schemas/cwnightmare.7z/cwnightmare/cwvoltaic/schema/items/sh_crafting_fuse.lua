--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Fuse";
	ITEM.batch = 1;
	ITEM.model = "models/gibs/metal_gib5.mdl";
	ITEM.weight = .1;
	ITEM.uniqueID = "cw_fuse";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A simple pyrotechnic initiating device.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);