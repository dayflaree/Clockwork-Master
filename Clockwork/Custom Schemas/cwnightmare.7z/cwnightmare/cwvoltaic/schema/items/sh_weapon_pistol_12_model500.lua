local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "S&W Model 500";
	ITEM.cost = 550;
	ITEM.model = "models/Weapons/W_357.mdl";
	ITEM.weight = 1;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Pistols";
	ITEM.weaponClass = "m9k_model500";
	ITEM.uniqueID = "m9k_model500";
	ITEM.business = true;
	ITEM.description = "A single-action, cartridge-firing, top-break revolver.\nUtilizes .357 rounds.";
	
	ITEM.hasFlashlight = false;
    ITEM.loweredOrigin = Vector(0.67, 0.865, -0.866)
    ITEM.loweredAngles = Angle(-14.461, 34.729, -7.441)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(-180, 180, 90);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();