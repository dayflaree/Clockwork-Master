--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Framed Picture";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_picture_5";
	ITEM.skin = 5;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_c17/Frame002a.mdl";
	ITEM.weight = .4;
	ITEM.description = "A wooden picture frame.";
Clockwork.item:Register(ITEM);