--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("generator_base");
	ITEM.name = "Banana Tree";
	ITEM.cost = 600;
	ITEM.model = "models/props_junk/shovel01a.mdl";
	ITEM.business = false;
	ITEM.uniqueID = "cw_banana_plant";
	ITEM.description = "This grows bananas over time provided you keep it watered.";
	ITEM.generatorInfo = {
		powerPlural = "Growing Bananas",
		powerName = "Growing Banana",
		uniqueID = "cw_banana_tree",
		maximum = 5,
		health = 150,
		power = 3,
		cash = 1,
		name = "Banana Tree",
	};
	
-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk");
	end;
	
ITEM:Register();