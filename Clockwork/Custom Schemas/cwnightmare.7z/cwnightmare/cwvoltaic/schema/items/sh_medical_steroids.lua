local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Strongman Igor Steroids";
ITEM.cost = 40;
ITEM.model = "models/props_lab/jar01b.mdl";
ITEM.weight = 0.2;
ITEM.access = "V";
ITEM.useText = "Swallow";
ITEM.category = "Medical";
ITEM.business = true;
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "Low caliber steroids, with a picture of a buff Russian looking man who for some reason resembles Stalin.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData("stamina", 100);
	player:BoostAttribute(self.name, ATB_ACROBATICS, 2, 600);
	player:BoostAttribute(self.name, ATB_ENDURANCE, 4, 600);
	player:BoostAttribute(self.name, ATB_STRENGTH, 4, 120);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();