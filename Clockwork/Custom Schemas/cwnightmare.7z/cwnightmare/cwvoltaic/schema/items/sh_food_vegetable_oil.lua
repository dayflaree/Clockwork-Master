local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Vegetable Oil";
ITEM.cost = 6;
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl";
ITEM.weight = 0.6;
ITEM.access = "v";
ITEM.business = true;
ITEM.useText = "Drink";
ITEM.category = "Consumables";
ITEM.description = "A bottle of vegetable oil, it isn't very tasty.";



-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:TakeDamage(5, player, player);
	
	local instance = Clockwork.item:CreateInstance("cw_vege_empty");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();