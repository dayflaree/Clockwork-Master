--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("generator_base");
	ITEM.name = "Carrot Plant";
	ITEM.cost = 500;
	ITEM.model = "models/props_junk/shovel01a.mdl";
	ITEM.business = false;
	ITEM.uniqueID = "cw_carrot_plant";
	ITEM.description = "This grows carrots over time provided you keep it watered.";
	ITEM.generatorInfo = {
		powerPlural = "Growing Carrots",
		powerName = "Growing Carrot",
		uniqueID = "cw_carrot_plant",
		maximum = 5,
		health = 150,
		power = 3,
		cash = 1,
		name = "Carrot Patch",
	};
	
-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/prop_foliage/tree_deciduous_01a_trunk");
	end;
	
ITEM:Register();