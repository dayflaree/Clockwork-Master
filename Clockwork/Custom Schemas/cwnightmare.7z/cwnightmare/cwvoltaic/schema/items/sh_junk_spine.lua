--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Spine";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.model = "models/gibs/hgibs_spine.mdl";
	ITEM.weight = 0.25;
	ITEM.description = "A humanoid spine.";
Clockwork.item:Register(ITEM);