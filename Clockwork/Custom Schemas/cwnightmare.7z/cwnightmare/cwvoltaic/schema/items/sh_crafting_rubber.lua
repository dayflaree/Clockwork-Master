--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Scrap Rubber";
	ITEM.batch = 1;
	ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
	ITEM.weight = .2;
	ITEM.uniqueID = "cw_rubber";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A piece of old rubber.";
	
	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk");
	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);