local ITEM = Clockwork.item:New("ammo_base");

ITEM.name = "7.62x54mm Ammo Belt (x200)"; -- The name of the item, obviously.
ITEM.cost = 650; -- How much does this item cost for people with business access to it?
ITEM.model = "models/Items/BoxMRounds.mdl"; -- What model does the item use.
ITEM.weight = 0.5; -- How much does it weigh in kg?
ITEM.access = "M"; -- What flags do you need to have access to this item in your business menu (you only need one of them)?
ITEM.useText = "Load"; -- What does the text say instead of Use, remove this line to keep it as Use.
ITEM.category = "Ammunition"; -- What category does the item belong in?
ITEM.uniqueID = "ammo_mg";  -- Optionally, you can manually set a unique ID for an item, but usually you don't need to.
ITEM.business = true;  -- Is this item available on the business menu (if the player has access to it)?
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "A box containing 7.62x54mm, hopefully there is something you can use.";
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
  -- Give a small description of the item.
function ITEM:OnDrop(player, position)
	-- If the item doesn't have this function, it cannot be dropped.
end;


function ITEM:OnUse(player, itemEntity)
player:GiveAmmo( 200, "Gravity") -- honestly fuck kuro's system of doing ammo this is a bitch
end;

function ITEM:OnDestroy(player)
	-- If the item doesn't have this function, it cannot be destroyed.
end;

-- Register the item to the nexus framework.
ITEM:Register();