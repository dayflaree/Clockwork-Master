--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Wine Bottle";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props/cs_militia/bottle01.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An empty bottle made of glass, it smells like wine.";
Clockwork.item:Register(ITEM);