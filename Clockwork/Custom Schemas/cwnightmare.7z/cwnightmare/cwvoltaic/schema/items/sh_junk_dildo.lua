--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Dildo";
	ITEM.batch = 1;
	ITEM.model = "models/props_c17/trappropeller_lever.mdl";
	ITEM.weight = 0.1;
	ITEM.category = "Sexual";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.useText = "Insert";
	ITEM.uniqueID = "cw_dildo";
	ITEM.useSound = "vo/npc/Alyx/gasp03.wav";
	ITEM.description = "Swiggity Swooty, I'm comin' for that booty.";
	
-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local instance = Clockwork.item:CreateInstance("cw_dildo");
		
	player:GiveItem(instance, true);
end;

	-- Called when the item entity has spawned.
function ITEM:OnEntitySpawned(entity)
	entity:SetMaterial("models/props_c17/furnituremetal001a");
end;

	-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);