local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Weapon Kit";
ITEM.cost = 35000;
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl";
ITEM.weight = 0.5;
ITEM.batch = 1;
ITEM.access = "V3";
ITEM.uniqueID = "weapon_kit";
ITEM.category = "Useful";
ITEM.business = false;
ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
ITEM.description = "An item that allows you to personalize your weapon.";

function ITEM:OnUse(player, itemEntity)

	--Clockwork.player:GiveFlags(player, "h");

end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();