--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Aloe Vera Lotion";
	ITEM.batch = 1;
	ITEM.model = "models/healthvial.mdl";
	ITEM.weight = .1;
	ITEM.uniqueID = "cw_lotion";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A small container with 'Aloe Vera' plastered onto it.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);