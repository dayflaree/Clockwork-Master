--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("generator_base");
	ITEM.name = "Potato Plant";
	ITEM.cost = 500;
	ITEM.model = "models/props_junk/shovel01a.mdl";
	ITEM.business = false;
	ITEM.uniqueID = "cw_potato_plant";
	ITEM.description = "This grows potatoes over time provided you keep them watered.";
	ITEM.generatorInfo = {
		powerPlural = "Growing Tubers",
		powerName = "Growing Tuber",
		uniqueID = "cw_advancedprinter",
		maximum = 5,
		health = 150,
		power = 1,
		cash = 1,
		name = "Potato Plant",
	};
	
-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/prop_foliage/tree_deciduous_01a_trunk");
	end;
	
ITEM:Register();