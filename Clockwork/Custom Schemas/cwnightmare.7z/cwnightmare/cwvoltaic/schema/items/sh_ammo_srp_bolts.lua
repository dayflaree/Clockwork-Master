--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 120;
	ITEM.name = "Makeshift Bolts (x5)";
	ITEM.model = "models/items/crossbowrounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_xbowbolt";
	ITEM.ammoClass = "XBowBolt";
	ITEM.ammoAmount = 5;
	ITEM.description = "A small pack of makeshift crossbow bolts.";
Clockwork.item:Register(ITEM);