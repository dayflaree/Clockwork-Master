--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Recipe: Moonshine";
	ITEM.cost = 20;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_moonshine_r";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Create";
	ITEM.business = true;
	ITEM.category = "Recipes";
	ITEM.useSound = "items/ammocrate_open.wav";
	ITEM.description = "A recipe that explains how to create your own alcohol from a mix of ingredients. \n1x Box of Condoms \n1x Bleach \n1x Distilled Alcohol";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred= player:FindItemByID("cw_bleach");
local getIngred2= player:FindItemByID("cw_condom");
local getIngred3= player:FindItemByID("cw_alcohol");
local giveCooked = Clockwork.item:CreateInstance("cw_moonshine");
local giveBlueprint = Clockwork.item:CreateInstance("cw_moonshine_r");

if (getIngred and getIngred2 and getIngred3) then
player:TakeItem(getIngred, true);
player:TakeItem(getIngred2, true);
player:TakeItem(getIngred3, true);
player:GiveItem(giveCooked, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required ingredients or tools!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);