local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "AK-74";
	ITEM.cost = 2000;
	ITEM.model = "models/weapons/w_rif_ak47.mdl";
	ITEM.access = "V";
	ITEM.weight = 3;
	ITEM.batch = 1;
	ITEM.category = "Assault Rifles";
	ITEM.weaponClass = "m9k_ak74";
	ITEM.uniqueID = "m9k_ak74";
	ITEM.business = true;
	ITEM.description = "An assault rifle developed in the early 1970s in the Soviet Union.\nUtilizes 5.45x39mm rounds";
	
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();