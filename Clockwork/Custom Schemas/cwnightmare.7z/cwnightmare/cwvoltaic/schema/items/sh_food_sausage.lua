local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Sausage";
ITEM.uniqueID = "cw_sausage";
ITEM.cost = 16;
ITEM.model = "models/gibs/hgibs_spine.mdl";
ITEM.weight = 0.3;
ITEM.useText = "Eat";
ITEM.category = "Consumables";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "A thick and delicious looking sausage.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 5, 0, player:GetMaxHealth() ) );
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 45, 0, 100) );
	
end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/flesh");
	end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);