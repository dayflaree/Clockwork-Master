--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "FAMAS";
	ITEM.cost = 22000;
	ITEM.model = "models/weapons/w_tct_famas.mdl";
	ITEM.weight = 3.8;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Assault Rifles";
	ITEM.weaponClass = "m9k_famas";
	ITEM.uniqueID = "m9k_famas";
	ITEM.business = true;
	ITEM.description = "A bullpup-styled assault rifle designed and manufactured in France.\nUtilizes 5.56x45mm rounds.";
	
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();