--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 200;
	ITEM.name = "Box of .50 BMG (x20)";
	ITEM.model = "models/items/boxmrounds.mdl";
	ITEM.weight = 1.2;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "ammo_sniperpenetratedround";
	ITEM.ammoClass = "SniperPenetratedRound";
	ITEM.ammoAmount = 20;
	ITEM.description = "A box containing .50 BMG rounds.";
Clockwork.item:Register(ITEM);