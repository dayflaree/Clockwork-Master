--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Melon";
ITEM.cost = 5;
ITEM.model = "models/props_junk/watermelon01.mdl";
ITEM.weight = 1;
ITEM.access = "v";
ITEM.uniqueID = "cw_melon";
ITEM.useText = "Cut Open";
ITEM.category = "Consumables"
ITEM.useSound = "physics/flesh/flesh_squishy_impact_hard1.wav";
ITEM.business = true;
ITEM.description = "A green fruit, it has a hard outer shell.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("cw_melon_chunk");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("cw_melon_chunk");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("cw_melon_chunk");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("cw_melon_chunk");
		
	player:GiveItem(instance, true);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();