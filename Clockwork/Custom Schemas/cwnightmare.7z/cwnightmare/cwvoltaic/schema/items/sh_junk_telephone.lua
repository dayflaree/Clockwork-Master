--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Telephone";
	ITEM.batch = 1;
	ITEM.model = "models/props_trainstation/payphone_reciever001a.mdl";
	ITEM.weight = 0.3;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.description = "An old telephone.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);