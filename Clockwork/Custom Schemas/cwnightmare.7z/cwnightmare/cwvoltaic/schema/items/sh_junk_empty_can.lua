--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Blue Aluminum Can";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.uniqueID = "cw_can_b";
	ITEM.access = "j";
	ITEM.model = "models/props_junk/popcan01a.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "An empty aluminum can.";
Clockwork.item:Register(ITEM);