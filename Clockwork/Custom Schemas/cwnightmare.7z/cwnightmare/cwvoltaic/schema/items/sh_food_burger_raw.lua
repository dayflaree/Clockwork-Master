local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Raw Hamburger";
ITEM.cost = 15;
ITEM.model = "models/props_lab/box01a.mdl";
ITEM.weight = 0.1;
ITEM.useText = "Cook";
ITEM.category = "Ingredients";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "Some raw hamburger, it would be tasty if you cooked it up.";

		-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getPan = player:FindItemByID("cw_pan");
local giveCooked = Clockwork.item:CreateInstance("cw_hamburger_cooked");

if (getPan) then
player:GiveItem(giveCooked, true);
else
Clockwork.player:Notify(player, "You do not have a frying pan!");
return false;
end;
end;
-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);