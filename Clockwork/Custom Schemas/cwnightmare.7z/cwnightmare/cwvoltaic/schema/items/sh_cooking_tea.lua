--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
	ITEM.name = "Recipe: Tea";
	ITEM.cost = 20;
	ITEM.model = "models/props_c17/paper01.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "cw_tea_r";
	ITEM.weight = 0.1;
	ITEM.access = "V";
	ITEM.useText = "Create";
	ITEM.business = true;
	ITEM.category = "Recipes";
	ITEM.useSound = "items/ammocrate_open.wav";
	ITEM.description = "A recipe that explains how to make a wonderful drink. \n1x Tea Pot \n1x Tea Leaf \n1x Water";
	
	-- Called when a player drinks the item.
	function ITEM:OnUse(player, itemEntity)
local getIngred= player:FindItemByID("cw_tea_pot");
local getIngred2= player:FindItemByID("cw_tea_leaf");
local getIngred3= player:FindItemByID("cw_water");
local giveCooked = Clockwork.item:CreateInstance("cw_tea");
local giveBlueprint = Clockwork.item:CreateInstance("cw_tea_r");

if (getIngred and getIngred2 and getIngred3) then
player:TakeItem(getIngred, true);
player:TakeItem(getIngred2, true);
player:TakeItem(getIngred3, true);
player:GiveItem(giveCooked, true);
player:GiveItem(giveBlueprint, true);
else
Clockwork.player:Notify(player, "You do not have the required ingredients or tools!");
return false;
end;




	end;
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
Clockwork.item:Register(ITEM);