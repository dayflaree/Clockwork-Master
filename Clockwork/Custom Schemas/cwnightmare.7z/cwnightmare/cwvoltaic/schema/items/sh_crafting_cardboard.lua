--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("crafting_base");
	ITEM.name = "Scrap Cardboard";
	ITEM.batch = 1;
	ITEM.model = "models/props_junk/garbage_carboard002a.mdl";
	ITEM.weight = .2;
	ITEM.uniqueID = "cw_cardboard";
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.description = "A piece of old cardboard.";
	
	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;
	
Clockwork.item:Register(ITEM);