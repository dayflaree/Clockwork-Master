--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Power Saw";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props/CS_militia/circularsaw01.mdl";
	ITEM.weight = 1.2;
	ITEM.description = "An electric saw, it doesn't seem to work.";
Clockwork.item:Register(ITEM);