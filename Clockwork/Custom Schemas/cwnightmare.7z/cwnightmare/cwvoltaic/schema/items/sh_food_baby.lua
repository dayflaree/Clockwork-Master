--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("custom_script");
	ITEM.name = "Human Baby";
	ITEM.model = "models/props_c17/doll01.mdl";
	ITEM.weight = 3;
	ITEM.plural = "Babies";
	ITEM.useText = "Eat";
	ITEM.uniqueID = "cw_baby";
	ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
	ITEM.category = "Consumables";
	ITEM.isRareItem = true;
	ITEM.description = "A human infant.";

	-- Called when a player uses the item.
	function ITEM:OnUse(player, itemEntity)
		player:SetHealth( math.Clamp(player:Health() + 30, 0, 100) );
	end;

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;

Clockwork.item:Register(ITEM);