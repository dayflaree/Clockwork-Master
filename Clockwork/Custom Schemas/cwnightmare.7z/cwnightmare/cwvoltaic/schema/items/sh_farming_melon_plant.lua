--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("generator_base");
	ITEM.name = "Melon Vine";
	ITEM.cost = 600;
	ITEM.model = "models/props_junk/shovel01a.mdl";
	ITEM.business = false;
	ITEM.uniqueID = "cw_melon_plant";
	ITEM.description = "This grows melons over time provided you keep them watered.";
	ITEM.generatorInfo = {
		powerPlural = "Planted Melon Seeds",
		powerName = "Planted Melon Seed",
		uniqueID = "cw_melon_plant",
		maximum = 5,
		health = 1000,
		power = 3,
		cash = 1,
		name = "Melon Vine",
	};
	
ITEM:Register();