--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Trigger Mechanism";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.category = "Gun Parts";
	ITEM.access = "j";
	ITEM.uniqueID = "cw_trigger";
	ITEM.model = "models/props_junk/cardboard_box004a.mdl";
	ITEM.weight = 0.3;
	ITEM.description = "A mechanism that actuates the firing sequence of a firearm.";
Clockwork.item:Register(ITEM);