--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Soda Bottle";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl";
	ITEM.weight = 0.1;
	ITEM.description = "A plastic bottle, the inside is sticky.";
	
Clockwork.item:Register(ITEM);