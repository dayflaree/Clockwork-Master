local ITEM = Clockwork.item:New("custom_script");
ITEM.name = "Tuna";
ITEM.uniqueID = "cw_tuna";
ITEM.cost = 14;
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.weight = 0.3;
ITEM.useText = "Open and Eat";
ITEM.category = "Consumables";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "A can of sealed tuna.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 5, 0, player:GetMaxHealth() ) );
	player:SetCharacterData( "hunger", math.Clamp(player:GetCharacterData("hunger") - 45, 0, 100) );
		
	local instance = Clockwork.item:CreateInstance("tin_can");
		
	player:GiveItem(instance, true);
	
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);