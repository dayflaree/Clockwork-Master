--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Industrial Fan";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_silo/fanoff.mdl";
	ITEM.weight = 2.5;
	ITEM.description = "An old industrial fan.";
Clockwork.item:Register(ITEM);