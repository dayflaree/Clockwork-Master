--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Family Picture";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.access = "j";
	ITEM.model = "models/props_lab/frame002a.mdl";
	ITEM.weight = .1;
	ITEM.description = "A picture of a happy looking family.";
	
Clockwork.item:Register(ITEM);