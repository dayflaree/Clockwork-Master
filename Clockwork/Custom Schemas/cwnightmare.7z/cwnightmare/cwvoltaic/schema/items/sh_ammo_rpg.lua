--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 400;
	ITEM.name = "Crate of Rockets (4x)";
	ITEM.batch = 1;
	ITEM.model = "models/Items/item_item_crate.mdl";
	ITEM.weight = 4;
	ITEM.access = "v";
	ITEM.business = false;
	ITEM.uniqueID = "RPG_Round";
	ITEM.ammoClass = "RPG_Round";
	ITEM.ammoAmount = 4;
	ITEM.description = "A large wooden crate filled with rockets.\nThe crate has alot of russian markings on it that seem to say the number 4.";
Clockwork.item:Register(ITEM);