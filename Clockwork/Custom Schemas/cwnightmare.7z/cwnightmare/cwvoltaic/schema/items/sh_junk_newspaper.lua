--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Newspaper";
	ITEM.batch = 1;
	ITEM.access = "j";
	ITEM.business = true;
	ITEM.useText = "Salvage";
	ITEM.model = "models/props_junk/garbage_newspaper001a.mdl";
	ITEM.weight = 0.25;
	ITEM.description = "An old newspaper with a headline that say 'Gun prices skyrocket!'";
	
	-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	local instance = Clockwork.item:CreateInstance("paper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
		
	player:GiveItem(instance, true);
	local instance = Clockwork.item:CreateInstance("paper");
		
	player:GiveItem(instance, true);
end;
Clockwork.item:Register(ITEM);