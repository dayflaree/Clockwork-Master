local ITEM = Clockwork.item:New("custom_weapon");
	ITEM.name = "Colt 1911";
	ITEM.cost = 700;
	ITEM.model = "models/weapons/s_dmgf_co1911.mdl";
	ITEM.weight = 1;
	ITEM.batch = 1;
	ITEM.access = "V";
	ITEM.category = "Pistols";
	ITEM.weaponClass = "m9k_colt1911";
	ITEM.uniqueID = "m9k_colt1911";
	ITEM.business = true;
	ITEM.description = "A single-action, semi-automatic, magazine-fed, recoil-operated handgun.\nUtilizes .45 ACP.";
	
	ITEM.hasFlashlight = false;
    ITEM.loweredOrigin = Vector(0.67, 0.865, -0.866)
    ITEM.loweredAngles = Angle(-14.461, 34.729, -7.441)
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 180);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();