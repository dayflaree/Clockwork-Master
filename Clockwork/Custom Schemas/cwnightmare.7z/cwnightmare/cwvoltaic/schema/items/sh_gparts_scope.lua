--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Scope";
	ITEM.batch = 1;
	ITEM.business = true;
	ITEM.category = "Gun Parts";
	ITEM.access = "j";
	ITEM.uniqueID = "cw_scope";
	ITEM.model = "models/props_junk/cardboard_box004a.mdl";
	ITEM.weight = 0.4;
	ITEM.description = "An optical instrument useful for firearms.";
Clockwork.item:Register(ITEM);