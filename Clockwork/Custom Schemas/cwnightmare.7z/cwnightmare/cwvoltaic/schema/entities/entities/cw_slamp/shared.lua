DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "RJ";
ENT.PrintName = "Small Lamp";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;