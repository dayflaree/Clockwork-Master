--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ENT.Type = "anim";
ENT.Base = "cw_generator";
ENT.Model = "models/props_wasteland/prison_sinkchunk001b.mdl";
ENT.PrintName = "Potato Plant";