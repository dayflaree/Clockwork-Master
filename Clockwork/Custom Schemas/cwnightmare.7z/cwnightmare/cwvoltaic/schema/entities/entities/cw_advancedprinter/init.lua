--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

-- Called when a player earns cash from the generator.
function ENT:OnEarned(player, cash)
	if (cash > 0) then
		local entityPosition = self:GetPos();
		local endPosition = entityPosition + (self:GetUp() * 128);
		local traceLine = util.TraceLine( {
			endpos = endPosition,
			filter = self,
			start = entityPosition,
			mask = MASK_NPCWORLDSTATIC
		} );
		local getPotato = player:FindItemByID("cw_potato");
		local getWater = player:FindItemByID("cw_water");
		
		Clockwork.entity:CreateItem( player, "cw_potato", traceLine.HitPos - (self:GetUp() * 64), self:GetAngles() );

		return true;
	end;
end;

--Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/props_wasteland/prison_sinkchunk001b.mdl");
	self:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk");
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetUseType(SIMPLE_USE);
	self:SetSolid(SOLID_VPHYSICS);

	local physicsObject = self:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		physicsObject:Wake();
		physicsObject:EnableMotion(true);
	end;
	
	local generator = Clockwork.generator:FindByID(
		self:GetClass()
	);
	
	if (generator) then
		self:SetHealth(generator.health);
		self:SetDTInt(0, generator.power)
		
		timer.Simple(1, function()
			if (IsValid(self) and self.OnCreated) then
				self:OnCreated();
			end;
		end);
	else
		timer.Simple(1, function()
			if (IsValid(self)) then
				self:Remove();
			end;
		end);
	end;
end;

--Called each frame.
function ENT:Think()

	local physicsObject = self:GetPhysicsObject();	
	
	self:NextThink(CurTime() + 1);
	
	if (IsValid(physicsObject)) then
		physicsObject:Wake();
		physicsObject:EnableMotion(false);
	end;
	
	if (!self:IsInWorld()) then
		self:Remove();
	end;
end;