--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ENT.Type = "anim";
ENT.Base = "cw_generator";
ENT.Model = "models/props/de_inferno/fountain_bowl_p10.mdl";
ENT.PrintName = "Carrot Plant";