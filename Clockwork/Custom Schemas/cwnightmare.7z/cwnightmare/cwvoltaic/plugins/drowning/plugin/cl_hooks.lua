--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when the bars are needed.
function PLUGIN:GetBars(bars)
	local drowning = Clockwork.Client:GetSharedVar("Drowning") or 100;
	
	if (drowning and drowning < 100) then
		bars:Add("DROWNING", Color(100, 100, 210, 255), "", drowning, 100, drowning < 10);
	end;
end;