--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when a player's character data should be saved.
function PLUGIN:PlayerSaveCharacterData(player, data)
	if (data["drowning"]) then
		data["drowning"] = math.Round(data["drowning"]);
	end;
end;

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreCharacterData(player, data)
	if (!data["Drowning"]) then
		data["Drowning"] = 100;
	end;
end;

-- Called just after a player spawns.
function PLUGIN:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	if (!firstSpawn and !lightSpawn) then
		player:SetCharacterData("Drowning", 100);
	end;
end;

-- Called when a player's shared variables should be set.
function PLUGIN:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar("Drowning", math.Round(player:GetCharacterData("Drowning")));
end;

-- Called at an interval while a player is connected.
function PLUGIN:PlayerThink(player, curTime, infoTable)
	local scale = Clockwork.config:Get("drowning_drain_scale"):Get();
	local drowning = player:GetCharacterData("Drowning");
	
	if (player:Alive() and player:WaterLevel() == 3) then
		if (drowning == 0) then
			if (player.cwNextDrownPain) then
				if (player.cwNextDrownPain < curTime) then
					player:TakeDamageInfo( Clockwork.kernel:FakeDamageInfo(10, game.GetWorld(), game.GetWorld(), player:GetShootPos(), DMG_DROWN, 1) );
					player.cwNextDrownPain = nil;
				end;
			else
				player.cwNextDrownPain = curTime + 2;
			end;
		else
			player:SetCharacterData("Drowning", math.Clamp(((drowning - 1) * scale), 0, 100));
			player.cwNextDrownPain = nil;
		end;
	else
		player:SetCharacterData("Drowning", math.Clamp(drowning + 2.5, 0, 100));
		player.cwNextDrownPain = nil;
	end;
end;