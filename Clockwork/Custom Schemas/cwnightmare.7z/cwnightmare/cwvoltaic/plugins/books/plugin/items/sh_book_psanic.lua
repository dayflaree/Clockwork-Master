--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Child's Drawing";
ITEM.cost = 2;
ITEM.business = true;
ITEM.batch = 1;
ITEM.model = "models/props_c17/paper01.mdl";
ITEM.uniqueID = "printed_sanic";
ITEM.access = "v";
ITEM.description = "An old drawing of some child's favorite super hero.";
ITEM.bookInformation = [[
	<img src = "http://i.imgur.com/FPLrXNz.png" alt = "[An old drawing of some child's favorite super hero]."/>
]];

ITEM:Register();