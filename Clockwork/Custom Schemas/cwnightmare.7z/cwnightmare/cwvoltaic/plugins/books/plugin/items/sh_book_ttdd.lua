--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.cost = 8;
ITEM.name = "The Sacred Sandwich";
ITEM.batch = 1;
ITEM.model = "models/props_lab/binderredlabel.mdl";
ITEM.uniqueID = "book_ttdd";
ITEM.access = "v";
ITEM.business = true;
ITEM.description = "A book about Tim the Death Dealer.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by Chance R. Chancer.</font>

<font size = '+2'>W</font>ithin the Worlds of Nine, in the land of Earth,
 lived a mighty champion named Timothy the Death Dealer.  The champion stood at
 a height of a mighty five feet and seven inches, he had blond hair, and eyes
 of mighty earth.  Legends say that he could eat two hamburgers at the same time,
 with the use of one mighty hand.  Tim had seen a fair share of dramatic dangers
 in his time, and was no stranger to the call of duty.  The mighty man of metal had
 awoken one day, it was a day just like any other day, a day-y day, of daying.

  It was seven-thirty o�clock A.M. and the sun
  had begun to shine through his glorious windows
  smelted from the sands of Egypt, reflecting
  off of the walls of his room, 
  directly into his revered eyes.  Tim took his
  time sitting up from his amazing bed, a bed of heroes some might say, 
  it was organized chaos, chaos only a hero could
  organize.  The champion sat up and felt an enormous 
  tremor throughout the room, as if Atlas had given the 
  world a good shake, as if it were a snow globe.  
  Timothy opened his mighty jaws and bellowed 
  out �I�m kinda hungry, I think I�m going to go
  make myself a bologna sandwich.�

  The champion had spoken, and the champions words
  were not to be taken lightly, Tim had never gone
  back on his word before, and he certainly would not
  do it today.  The honorable hero moved his mighty legs
  slowly and patiently, a wise man does not need to go
  fast.  He traveled through hallways of gray with floors
  alike that of bear hides.  Then he approached it, his
  only true enemy in the world of monsters that he lived,
  the jagged beast of great heights.  Tim was not afraid,
  he was never afraid, the fearless man took him step
  towards the beast, and would not let it intimidate him.
  With a mighty pound of his foot, he began his climb up
  the beast�s spines of anguish.  With valor he
  persevered against the beast, and reached its head. 

 Tim continued completely unphased from his encounter,
 and moved to where the floor is smooth, and where
 the inferno machines of great warmth make their
 dwelling.  Timothy had fought with these beasts
 before, infact he was powerful enough to even tame
 the creatures, they were now simply tools to him.
 This was also where his friend dwelled, the only
 one he deemed honorable enough to look over his
 tamed beasts, the man of pure white, he had powers
 over the elements themselves, and in the past had
 proven to be the most mighty of Tim�s allies.  The
 champion moved towards his friend in camaraderie,
 he spoke to him, �I hope we�re out of bologna, that
 sure would be inconvenient.� A tragic day indeed it
 was, not one on this earth could have prepared for
 this type of tragic tragedy.  The bologna was gone,
 some fiend, some cruel abomination, some ghastly
 aberration, had eaten all of the sacred bologna,
 stolen it right from under the elemental wizard�s nose.

  Tim was enraged, the fierce screams that bellowed
  from his throat were enough to frighten Zues, Odin,
  and Jove altogether, �Well, that sure is inconvenient,
  I suppose I�ll have to go buy some more then.�
  With that honorable oath he vowed to restore what
  was taken from him, repair the injustice that had
  been dealt to the world.  Tim said goodbye to the
  elemental wizard, and gathered his enchanted vestments,
  created specifically for such a quest.  The armored
  champion twisted opened the Gates to Hades, and set
  out on his journey into the blinding white hell that
  stood in front of him.  Tim faced this challenge, he
  would not back down, he muttered under his breath,
  �It sure is chilly today, I hope it warms up soon.�
  With that, he embarked, he began his march down
  the gray path of frosty horror, he would need to
  walk at least five house worths of distance before
  he would reach his final destination.

  The task may have seemed daunting to an ordinary man,
  but Tim was no ordinary man, he was a man,
  a man with shoes.  Not just any shoes, shoes
  fit specifically for Tim, they were almost
  designed for him they were so perfectly matched
  to his feet, he knew he could walk anywhere if he
  was walking there in his shoes.  Not even the icey
  spears of Jack Frost could penetrate through the
  armor of his shoes.  Knowing this, Tim had full 
  confidence in the success of his journey, he showed
  no fear as he marched uphill both ways into the eye
  of the storm.  The storm proved no match for Tim, he
  made it to his respite, a mighty place known as
  �Grocery Store.�  There he would find his chariot
  waiting for him, his chariot was made of only the
  finest metals entwined within themselves,
  sturdy enough to carry without even bending.

  The mighty hero rode his chariot, searching for what was lost,
  and he would not need to search far, for his prize was within
  his grasp.  Even in a haven such as this, danger still
  lurked, such is the world that a hero lives in.  The floor,
  the floor was not the floor, the floor was a danger, it was
  a trap, it ruse, the floor was slick.  Tim was no stranger
  to a danger of this type, he had learned from his
  past, learned from his mistakes, he knew what was
  going to happen.  He performed a maneuver, one none
  had ever performed before him, he turned left, and
  then went forward, and then went right again, and
  then forward.  He had reached his prize, �Only two
  dollars for a pack of bologna? What a deal!� he chanted,
  but he knew there was no time to celebrate, for
  he was not finished, the menacing tremor of Gaia
  shook the very foundation of Tim�s soul, he needed
  to hurry.  It was then that he swiftly grabbed his
  prize, and continued onward to the guardians of the haven.

  They responded to him in kind, he and the guardians
  were always good friends, heroes were no strangers
  to camaraderie, they saw his predicament and helped
  him on his way, sending him forth at the speed of a
  thousand of Zues� mighty snails.  Tim knew that his
  journey was almost at its end, but he would not get
  over-confident now, he could not afford to make a 
  mistake, he marched back the way he came, but there
  was a sense of urgency this time, he needed to get
  back soon.  Tim would not fail, he could not fail,
  for he was Timothy, the Death Dealer, the
  Bologna Bender, the Crayon Colorer, the Hamburger Helper!
  Tim reached his comfortable abode, and entered
  it with the glory of a thousand knights.  He loudly
  proclaimed his victory, �It�s nice to be home, I should
  make that sandwich now.�  And thus, he went to do what
  few men can only dream of accomplishing.  He reached into
  the bread bag, took out two fine pieces from the entire
  godly loaf, and put them gently onto a plate made of only
  the finest of the king�s paper.  Tim opened his prize, he
  opened the mighty chest with prizes invaluable, and
  took out the mighty disc of glorious bologna.

  He skillfully placed his bologna onto the sandwich, but
  he would not settle for one piece, no, no, no, he would
  put not one, but two pieces of bologna onto the godly bread
  .  Tim pondered for a moment, he knew he could make this
  prize of gods even better, he beseeched the elemental wizard
  one more time, and took forth two pieces of square
  gold, glorious and gleaming he stacked them onto
  the bologna, and completed his sandwich.  With that,
  he had done it, Tim had reached the end of his perilous
  quest and created something amazing.  But wait, Tim had
  one more thing he needed to do.  He grasped the sacred
  sandwich in his mighty hands, and as god as his witness
  he raised it to his mouth, and he took a bite, chewed,
  and swallowed it.  �I forgot the mayo.�  That is the tale
  of how the world as we know it was created, that horrifying
  revelation changed everyone and everything, there was nothing
  more than could be done.  The sandwich spoke for the first
  time, and also the last time, �Defeating the sandwich,
  only makes it tastier.�
]];

ITEM:Register();