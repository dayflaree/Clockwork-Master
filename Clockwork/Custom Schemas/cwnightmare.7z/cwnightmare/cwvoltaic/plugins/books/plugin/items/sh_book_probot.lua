--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Robot Portrait";
ITEM.cost = 2;
ITEM.business = true;
ITEM.batch = 1;
ITEM.model = "models/props_lab/frame002a.mdl";
ITEM.uniqueID = "printed_robot";
ITEM.access = "v";
ITEM.description = "A framed picture of an amazing invention.";
ITEM.bookInformation = [[
	<img src = "http://i.imgur.com/MQNKX1D.jpg" alt = "[A framed picture of an amazing invention]."/>
]];

ITEM:Register();