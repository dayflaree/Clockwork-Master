--[[
local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("CharTempFlags");
COMMAND.tip = "Temporarily give flags to a character.";
COMMAND.text = "<string Name> <string Flags> <number Minutes>";
COMMAND.access = "a";
COMMAND.arguments = 3;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	local flags = arguments[2]
	local time = tonumber(arguments[3]) * 60
	flags = target:StringTakeTempFlags(flags);
	
	if(!flags or flags == "") then
		Clockwork.player:Notify(player, "You need to specify what flags to give!")
	end;
	
	if(!time or time == "") then
		Clockwork.player:Notify(player, "You need to specify an amount of time!")
	end;

	if(target) then
		if(Clockwork.player:HasFlags(target, flags)) then
			Clockwork.player:Notify(player, target:Name().. " already has "..flags.."!")
		else
			target:GiveTempFlags(flags)
			for k, v in pairs(_player.GetAll()) do
				if((v:IsAdmin() or v:IsUserGroup("operator")) and (v != target)) then
					Clockwork.player:Notify(v, "[ADMIN] "..player:Name().." has given "..target:Name().." temporary "..flags.." flags for "..(time / 60).." minutes.")
				end;
				Clockwork.player:Notify(target, "[ADMIN] "..player:Name().." has temporarily given you "..flags.." flags ("..(time / 60).." minutes).")
			end;
			timer.Create("temp_"..target:Name().."-"..flags, time, 1, function()
				target:TakeTempFlags(flags)
				Clockwork.player:Notify(target, "Your temporary flags, "..flags..", have worn off.")
				for k, v in pairs(_player.GetAll()) do
					if((v:IsAdmin() or v:IsUserGroup("operator")) and v:SteamID() != target:SteamID()) then
						Clockwork.player:Notify(v, "[ADMIN] "..target:Name().."'s temporary flags, "..flags..", have worn off.")
					end;
				end;
				timer.Destroy("temp_"..target:Name().."-"..flags)
			end);
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!")
	end;
end;

COMMAND:Register();
]]--