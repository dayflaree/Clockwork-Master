local PLUGIN = PLUGIN;

Clockwork.setting:AddCheckBox("Framework", "Enable third person view.", "cwThirdPerson", "Whether or not to enable third person view.");
Clockwork.setting:AddNumberSlider( "Framework", "How far back the camera is.", "chasecam_back", 20, 150, 0, "How far back?" )
Clockwork.setting:AddNumberSlider( "Framework", "How far up the camera is.", "chasecam_up", 40, 150, 0, "How far up?" )
Clockwork.setting:AddNumberSlider( "Framework", "How far right the camera is.", "chasecam_right", 20, 100, 0, "How far right?" )
Clockwork.setting:AddCheckBox( "Framework", "Enable ThirdPerson Headbob.", "chasecam_bob", "Bob bob bob" )
Clockwork.setting:AddNumberSlider( "Framework", "Third Person Headbob Scale.", "chasecam_bobscale", 0, 1, 0, "How far bob?" )
