
local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Flashlight";
	ITEM.cost = 15;
	ITEM.model = "models/lagmite/lagmite.mdl";
	ITEM.weight = 0.6;
	ITEM.access = "v";
	ITEM.category = "Reusables";
	ITEM.uniqueID = "cw_flashlight";
	ITEM.business = true;
	ITEM.batch = 1; -- How many you buy at once when buying it from the business menu
	ITEM.isFakeWeapon = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A large flashlight to light up the dark.";
ITEM:Register();