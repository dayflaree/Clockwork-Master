local PLUGIN = PLUGIN;

function PLUGIN:Initialize()
	Clockwork.datastream:Hook("EditNotes", function(player, data)
		if (player.editNotesAuthorised == data[1] and type( data[2] ) == "string") then
			data[1]:SetCharacterData( "notesdata", string.sub(data[2], 0, 10000) );
			
			player.editNotesAuthorised = nil;
		end;
	end);
end;
