ENT.Base             = "base_nextbot"
ENT.Spawnable        = true

function ENT:Initialize()
    self:SetModel("models/mossman.mdl");
end