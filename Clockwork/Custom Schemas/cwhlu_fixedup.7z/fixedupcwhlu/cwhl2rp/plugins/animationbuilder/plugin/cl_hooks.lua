--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

PLUGIN.cameraOffset = nil
PLUGIN.cameraAngles = nil

PLUGIN.cameraOrbit = nil
PLUGIN.cameraDistance = 125

PLUGIN.selectedBone = 1

-- Called when an entity's menu options are needed.
function PLUGIN:CalcView(player, origin, angles, fov)
	if (self.building) then

		if (!self.cameraFOV) then
			self.cameraFOV = fov
		end

		local view = {}

		local pangles = player:GetAngles()
		pangles.p = 0

		local vangles = player:GetAngles()
		vangles:RotateAroundAxis(Vector(0, 0, 1), 180)
		vangles.p = 0
		vangles.r = 0

		if (!self.cameraOrbit) then
			self.cameraOrbit = pangles:Forward()
		end

		if (!self.cameraOffset) then
			self.cameraOffset = Vector(0, 0, 16)
		end

		local newOrigin = self.cameraOffset + self.cameraOrbit*self.cameraDistance

		if (!self.cameraAngles) then
			self.cameraAngles = vangles
		end

		view.origin = player:GetPos() + newOrigin
		view.angles = self.cameraAngles
		view.fov = self.cameraFOV
		return view
	end
end

local worldPanel = vgui.GetWorldPanel()
function worldPanel:OnMouseWheeled(delta)
	if (PLUGIN.building) then
		local player = LocalPlayer()
		if (!input.IsKeyDown(KEY_LSHIFT)) then
			PLUGIN.cameraDistance = math.Clamp(PLUGIN.cameraDistance + delta*-4, 2, 512)
		else
			PLUGIN.cameraFOV = PLUGIN.cameraFOV + delta*5
		end
	end
end

local sx, sy = 0, 0
local mx, my = gui.MousePos()
function PLUGIN:Think()
	if (self.building) then
		local player = LocalPlayer()
		local ux, uy = gui.MousePos()
		local dx, dy = (ux-mx), (uy-my)
		if (input.IsMouseDown(MOUSE_RIGHT)) then
			self.cameraOffset = self.cameraOffset + self.cameraAngles:Right()*dx*-0.1
			self.cameraOffset = self.cameraOffset + self.cameraAngles:Up()*dy*0.1
		elseif (input.IsMouseDown(MOUSE_MIDDLE)) then
			sx = sx + (dx/ScrW())*math.pi*2
			sy = sy + (dy/ScrH())*math.pi
			self.cameraOrbit = Vector(math.sin(sx), math.cos(sx), 0)
			self.cameraOrbit = self.cameraOrbit + Vector(0, 0, math.sin(sy))
			self.cameraAngles = ((player:GetPos() + self.cameraOffset) - (player:GetPos() + self.cameraOffset + self.cameraOrbit*self.cameraDistance)):Angle()
		end
		
		mx, my = gui.MousePos()
	end
end

function PLUGIN:ShouldDrawLocalPlayer(player)
	if (self.building) then
		return true
	end
end

function PLUGIN:HUDPaint()
	if (self.building) then
		local player = LocalPlayer()
		
		for _, i in pairs(self:GetBones()) do
			local pos = player:GetBonePosition(i)
			local length = player:BoneLength(i)*2
			local bmatrix = player:GetBoneMatrix(i)
			local ang = bmatrix:GetAngles()
			local normal = ang:Forward()

			local bstart = pos:ToScreen()
			local bend = (pos + normal*length):ToScreen()

			surface.SetDrawColor(Color(255, 255, 255))
			surface.DrawLine(bstart.x, bstart.y, bend.x, bend.y)

			surface.SetDrawColor(Color(255, 0, 0))
			surface.DrawRect(bstart.x-2, bstart.y-2, 4, 4)



		end

		if (self.selectedBone) then
			local i = self.selectedBone
			local wpos = player:GetBonePosition(i)
			local pos = wpos:ToScreen()

			local matrix = player:GetBoneMatrix(i)
			local ang = matrix:GetAngles()
			local gizmo_z = (ang:Up()*10+wpos):ToScreen()
			local gizmo_x = (ang:Right()*10+wpos):ToScreen()
			local gizmo_y = (ang:Forward()*10+wpos):ToScreen()

			surface.SetDrawColor(Color(255, 0, 0))
			surface.DrawLine(pos.x, pos.y, gizmo_x.x, gizmo_x.y)

			surface.SetDrawColor(Color(0, 255, 0))
			surface.DrawLine(pos.x, pos.y, gizmo_y.x, gizmo_y.y)

			surface.SetDrawColor(Color(0, 0, 255))
			surface.DrawLine(pos.x, pos.y, gizmo_z.x, gizmo_z.y)

			surface.SetDrawColor(Color(0, 255, 255))
			surface.DrawRect(pos.x - 4, pos.y - 4, 8, 8)

			//draw.SimpleTextOutlined(player:GetBoneName(i), "DebugFixedSmall", pos.x, pos.y, Color(255, 255, 255), 0, 1, 1, Color(0, 0, 0))
		end
	end
end