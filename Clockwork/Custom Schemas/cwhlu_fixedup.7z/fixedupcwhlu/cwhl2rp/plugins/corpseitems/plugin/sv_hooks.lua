local PLUGIN = PLUGIN

function PLUGIN:PlayerDeath(player)
 if Schema:PlayerIsCombine( player ) then
	if player:GetRagdollEntity() then
		local ragdoll = player:GetRagdollEntity()
		local character = player:GetCharacter()
		local inventory = player:GetInventory()
		local copy = Clockwork.inventory:CreateDuplicate(inventory)
			for k,v in pairs( copy ) do
				for k2,v2 in pairs( v ) do
					Clockwork.inventory:RemoveInstance( copy, v2 )
				end
			end
			Clockwork.inventory:AddInstance( copy, Clockwork.item:CreateInstance( "tactical_vest" ) )
			Clockwork.inventory:AddInstance( copy, Clockwork.item:CreateInstance( "handheld_radio" ) )
			Clockwork.inventory:AddInstance( copy, Clockwork.item:CreateInstance( "cw_stunstick" ) )
		ragdoll.cwInventory = copy
	end
 end
end