local PLUGIN = PLUGIN;

Clockwork.config:Add("use_citizen_voice_flag", true);
Clockwork.config:Add("citizen_voice_flag", "H", true, true);