AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

function ENT:SpawnFunction(player, trace)
    if (!trace.Hit) then return; end;

    local entity = ents.Create("3dpanel");
    entity:Spawn();
    entity:Activate();
    entity:SetPos( trace.HitPos + trace.HitNormal * 32 + Vector(0, 0, 53) );
    entity:SetAngles( Angle(180, 0, 90) );
    entity:SpawnProps();

    return entity;
end;

function ENT:Initialize()
	self:SetModel("models/hunter/plates/plate4x8.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()
	if phys:IsValid() then
		phys:Wake()
	end
end