local COMMAND = Clockwork.command:New("3dpaneladd");

COMMAND.tip = "Adds a 3D panel for displaying HTML.";
--COMMAND.text = "<String URL>";
--COMMAND.arguments = 1;
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	if (!trace.Hit) then return end

	local whychessnut = ents.Create("3dpanel");
	local entity = whychessnut:SpawnFunction(player, trace)
	whychessnut:Remove()
	
	if (IsValid(entity)) then
		Clockwork.player:Notify(player, "You have added a 3D panel.");
	end;
end;

COMMAND:Register()