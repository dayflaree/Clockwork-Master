--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Immolator Gas Battery";
	ITEM.cost = 90;
	ITEM.classes = {CLASS_CREMATOR};
	ITEM.model = "models/Items/battery.mdl";
	ITEM.plural = "Immolator Gas Batteries";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_immolator";
	ITEM.business = true;
	ITEM.ammoClass = "immolator";
	ITEM.ammoAmount = 30;
	ITEM.description = "A cartridge filled with compressed gas.";
ITEM:Register();