-- (c) Khub 2012-2013.
-- Shared privileges functions and configuration.

Datafiles.Privileges = {};
Datafiles.Privileges.Config = {
	["Read"] = 1,
	["ReadMedicalRecord"] = 2,
	["AddMedicalRecord"] = 4,
	["AddLoyaltyRecord"] = 8,
	["AddNote"] = 16,
	["RemoveRecords"] = 32,
	["ManipulateCitizenship"] = 64,
	["ManipulateBOL"] = 128,
	["RevokeLoyaltyStatus"] = 256,
	["Full"] = 511
};

local BasicPrivileges = bit.bor(Datafiles.Privileges.Config.Read, Datafiles.Privileges.Config.AddLoyaltyRecord, Datafiles.Privileges.Config.AddNote, Datafiles.Privileges.Config.RevokeLoyaltyStatus);
local MedicalPrivileges = bit.bor(Datafiles.Privileges.Config.ReadMedicalRecord, Datafiles.Privileges.Config.AddMedicalRecord);

Datafiles.Privileges.Ranks = {
	[1] = {
		label = "06",
		check = function(ply) return string.find(ply:Name(), "06"); end,
		flags = bit.bxor(BasicPrivileges, Datafiles.Privileges.Config.RevokeLoyaltyStatus)
	},
	[2] = {
		label = "05",
		check = function(ply) return string.find(ply:Name(), "05"); end,
		flags = BasicPrivileges
	},
	[3] = {
		label = "04",
		check = function(ply) return string.find(ply:Name(), "04"); end,
		flags = bit.bor(BasicPrivileges, Datafiles.Privileges.Config.ManipulateCitizenship)
	},
	[4] = {
		label = "03",
		check = function(ply) return string.find(ply:Name(), "03"); end,
		flags = bit.bor(BasicPrivileges, Datafiles.Privileges.Config.ManipulateCitizenship)
	},
	[5] = {
		label = "02",
		check = function(ply) return string.find(ply:Name(), "02"); end,
		flags = bit.bor(BasicPrivileges, Datafiles.Privileges.Config.ManipulateCitizenship)
	},
	[6] = {
		label = "01",
		check = function(ply) return string.find(ply:Name(), "01"); end,
		flags = bit.bor(BasicPrivileges, Datafiles.Privileges.Config.ManipulateCitizenship)
	},
	[7] = {
		label = "HC",
		abbreviations = {"HC", "i4"},
		check = function(ply) return string.find(ply:Name(), "i4."); end,
		flags = Datafiles.Privileges.Config.Full
	},
	[8] = {
		label = "Civil Admin",
		check = function(ply) return ply:GetFaction() == FACTION_ADMIN; end,
		abbreviations = {"CA"},
		flags = bit.bor(Datafiles.Privileges.Config.Read, Datafiles.Privileges.Config.AddNote, Datafiles.Privileges.Config.RevokeLoyaltyStatus, Datafiles.Privileges.Config.ManipulateCitizenship)
	},
	[9] = {
		label = "Universal Union",
		check = function(ply) return string.find(ply:Name(), "UU"); end,
		flags = Datafiles.Privileges.Config.Full
	},
	[10] = {
		label = "HC",
		abbreviations = {"HC", "i3"},
		check = function(ply) return string.find(ply:Name(), "i3"); end,
		flags = Datafiles.Privileges.Config.Full
	},
	[11] = {
		label = "HC",
		abbreviations = {"HC", "i2"},
		check = function(ply) return string.find(ply:Name(), "i2"); end,
		flags = Datafiles.Privileges.Config.Full
	},
	[12] = {
		label = "HC",
		abbreviations = {"HC", "i1"},
		check = function(ply) return string.find(ply:Name(), "i1"); end,
		flags = Datafiles.Privileges.Config.Full
	},
};

function Datafiles.Privileges:GetPlayerRank(ply)
	for k, v in pairs(self.Ranks) do
		if (v.check(ply)) then
			return k;
		end;
	end;

	return 1;
end;

function Datafiles.Privileges:GetRankFromLabel(label)
	for k, v in pairs(self.Ranks) do
		if (v.label == label) then
			return k;
		elseif (v.abbreviations) then
			for abbrK, abbrV in pairs(v.abbreviations) do
				if (abbrV == label) then
					return k;
				end;
			end;
		end;
	end;

	return 1;
end;

function Datafiles.Privileges:GetPlayerPrivileges(ply)
	if (!IsValid(ply)) then
		return 0;
	end;
	
	local rankNumber = 1;

	for k, v in pairs(self.Ranks) do
		if (v.check(ply)) then
			rankNumber = k;
			break;
		end;
	end;

	local privilegeFlags = self.Ranks[rankNumber].flags;

	if (string.find(ply:Name(), "C17")) then
		privilegeFlags = bit.bor(privilegeFlags, MedicalPrivileges);
	end;

	return privilegeFlags;
end;

function Datafiles.Privileges:Verify(subject, flag)
	if (!IsValid(subject)) then
		return false;
	end;

	return bit.band(self:GetPlayerPrivileges(subject), flag) > 0;
end;