-- (c) Khub 2012-2013.
-- Shared skeleton of the datafiles system.

local PLUGIN = PLUGIN;

Datafiles = {};
Clockwork.kernel:IncludePrefixed("sh_privileges.lua");

function Datafiles:GetDateFromTimestamp(ts)
	local year = tonumber(os.date("%Y", ts)) + 5;
	if (year < 2000) then
		-- If the record is older than ten years then it's timestamp is probably zero, and something went wrong.
		-- We'll display ####-##-## ##:## instead of 1970-01-01 00:00.
		return "####-##-## ##:##";
	end;

	local monthDay = os.date("%m-%d", ts);
	local clock = os.date("%H:%M", ts);

	return year .. "-" .. monthDay .. " " .. clock;
end;

Datafiles.LoyalistTiers = {
	[1] = {
		tierName = "Black",
		tierColor = Color(55, 55, 55),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("03"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("03"),
		pointsRequirement = 5
	},
	[2] = {
		tierName = "Brown",
		tierColor = Color(110, 80, 0),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("03"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("03"),
		pointsRequirement = 15
	},
	[3] = {
		tierName = "Red",
		tierColor = Color(255, 70, 70),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("02"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("OfC"),
		pointsRequirement = 20
	},
	[4] = {
		tierName = "Blue",
		tierColor = Color(70, 70, 255),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("01"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("OfC"),
		pointsRequirement = 35
	},
	[5] = {
		tierName = "Green",
		tierColor = Color(0, 100, 0),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("OfC"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("OfC"),
		pointsRequirement = 50
	},
	[6] = {
		tierName = "White",
		tierColor = Color(255, 255, 255),
		canGivePoints = Datafiles.Privileges:GetRankFromLabel("OfC"),
		canManipulate = Datafiles.Privileges:GetRankFromLabel("OfC"),
		pointsRequirement = 65
	}
};

Clockwork.kernel:IncludePrefixed("client/cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("client/cl_network.lua");

Clockwork.kernel:IncludePrefixed("server/sv_player.lua");
Clockwork.kernel:IncludePrefixed("server/sv_database.lua");
Clockwork.kernel:IncludePrefixed("server/sv_network.lua");
Clockwork.kernel:IncludePrefixed("server/sv_hooks.lua");

if (SERVER) then
	resource.AddFile("materials/cg/datafile.png");
end;
