-- (c) Khub 2012-2013.

local PLUGIN = PLUGIN;

function PLUGIN:PlayerCharacterInitialized(ply)
	Datafiles.Database:LoadPlayerCharacter(ply);
end;