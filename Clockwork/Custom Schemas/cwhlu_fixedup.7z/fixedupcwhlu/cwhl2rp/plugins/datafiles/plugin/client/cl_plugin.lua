-- (c) Khub 2012-2013.
-- Clientside plugin file of datafiles

if (!Datafiles) then
	error("Execution of Datafiles/cl_plugin.lua was interrupted - shared Datafiles table is non-existant!");
	return;
end;