--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

-- Called when an entity's menu options are needed.
function PLUGIN:GetEntityMenuOptions(entity, options)
	local class = entity:GetClass();
	
	if (class == "cw_book") then
		options["View"] = "cw_bookView";
		options["Take"] = "cw_bookTake";
	end;
end;