--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("VisorStatus");
COMMAND.tip = "Notify other units of the current sociostability code.";
COMMAND.text = "<string green/yellow/red>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsCombine(player)) then
		if (Schema:IsPlayerCombineRank( player, {"SCN", "DvL", "SeC"} ) or player:GetFaction() == FACTION_OTA or player:GetFaction() == FACTION_ADMIN or player:IsAdmin()) then
			local text = table.concat(arguments, " ");
			
			if (text == "green") then
				self:AddCombineDisplayLine( "Current district Sociostability level has been modified. CODE: GREEN.", Color(10, 255, 0, 255) );
				BroadcastLua("LocalPlayer():ConCommand('green')")

			elseif (text == "yellow") then
				self:AddCombineDisplayLine( "Current district Sociostability level has been modified. CODE: YELLOW.", Color(255, 255, 10, 255) );
				BroadcastLua("LocalPlayer():ConCommand('yellow')")

			elseif (text == "red") then
				self:AddCombineDisplayLine( "Current district Sociostability level has been modified. CODE: RED.", Color(255, 10, 0, 255) );
				BroadcastLua("LocalPlayer():ConCommand('red')")
				
			else
				Clockwork.player:Notify(player, "You did not specify a valid sociostability code!");
				
			end;
			
		else
			Clockwork.player:Notify(player, "You are not ranked high enough to use this command!");
		end;
	else
		Clockwork.player:Notify(player, "You are not Civil Protection!");
	end;
end;

-- The function to print to a CP's HUD
function COMMAND:AddCombineDisplayLine(text, color, player, exclude)
	if (player) then
		Clockwork.datastream:Start( player, "CombineDisplayLine", {text, color} );
	else
		local players = {};
		
		for k, v in ipairs( _player.GetAll() ) do
			if (self:PlayerIsCombine(v) and v != exclude) then
				players[#players + 1] = v;
			end;
		end;
		
		Clockwork.datastream:Start(players, "CombineDisplayLine", {text, color});
	end;
end;

-- A function to check if a player is Combine.
function COMMAND:PlayerIsCombine(player, bHuman)
	if (IsValid(player) and player:GetCharacter()) then
		local faction = player:GetFaction();
		
		if (self:IsCombineFaction(faction)) then
			if (bHuman) then
				if (faction == FACTION_MPF) then
					return true;
				end;
			elseif (bHuman == false) then
				if (faction == FACTION_MPF) then
					return false;
				else
					return true;
				end;
			else
				return true;
			end;
		end;
	end;
end;

-- A function to get if a faction is Combine.
function COMMAND:IsCombineFaction(faction)
	return (faction == FACTION_MPF or faction == FACTION_OTA);
end;

-- A function to check if a player is a Combine rank.
function COMMAND:IsPlayerCombineRank(player, rank, realRank)
	local name = player:Name();
	local faction = player:GetFaction();
	
	if (self:IsCombineFaction(faction)) then
		if (type(rank) == "table") then
			for k, v in ipairs(rank) do
				if (self:IsPlayerCombineRank(player, v, realRank)) then
					return true;
				end;
			end;
		elseif (rank == "EpU" and !realRank) then
			if (string.find(name, "%pSeC%p") or string.find(name, "%pDvL%p")
			or string.find(name, "%pEpU%p")) then
				return true;
			end;
		else
			return string.find(name, "%p"..rank.."%p");
		end;
	end;
end;

COMMAND:Register();