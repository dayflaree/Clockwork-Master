--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "H&K USP Match";
	ITEM.model = "models/weapons/w_pistol.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "gdcw_hl2_pistol";
	ITEM.description = "A H&K USP Match with the Combine Insignia stamped onto the side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
ITEM:Register();






