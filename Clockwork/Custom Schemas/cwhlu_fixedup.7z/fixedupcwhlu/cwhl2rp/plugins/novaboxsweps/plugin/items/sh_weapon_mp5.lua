--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "MP5";
	ITEM.model = "models/weapons/w_GDC_MP5.mdl";
	ITEM.weight = 3;
	ITEM.uniqueID = "gdcw_mp5";
	ITEM.description = "An H&K MP5 with the Combine Insignia stamped onto the side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
ITEM:Register();








