--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "SPAS-12";
	ITEM.model = "models/weapons/w_shotgun.mdl";
	ITEM.weight = 3;
	ITEM.uniqueID = "gdcw_hl2_shotgun";
	ITEM.description = "A SPAS-12 with the Combine Insignia stamped onto the side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();








