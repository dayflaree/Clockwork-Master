--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "357";
	ITEM.model = "models/weapons/w_357.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "gdcw_hl2_revolver";
	ITEM.description = "A 357 Revolver with the Combine Insignia stamped onto the side.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
ITEM:Register();






