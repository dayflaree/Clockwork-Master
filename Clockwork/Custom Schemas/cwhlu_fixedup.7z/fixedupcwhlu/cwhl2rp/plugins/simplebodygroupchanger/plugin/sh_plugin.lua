--[[
	Plugin by iKosmonaut.com
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");