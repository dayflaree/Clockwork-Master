Birds

This plugin adds a new faction, Birds.
Simply whitelist a player with the faction "Bird", and they then can create a bird Character.
Birds can fly by "Flapping their wings" or Tapping space, The space key is recommended to be held for about a second between flaps for optimal flight.
Birds may also talk to other birds with /Tweet <Text> or /T <Text>
All other birds read the text cleanly, whilst other factions simply see Chirps.