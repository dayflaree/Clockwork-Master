local PLUGIN = PLUGIN;
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua")

allflags = "AbBcCdDeEfFgGhHiIjJlLmMnNOpPqQrRStTuUvVwWxXyYzZ1234567890";