
ENT.Type = "anim"

ENT.PrintName		= ""
ENT.Author		= ""
ENT.Contact		= ""
ENT.Purpose		= ""
ENT.Instructions	= ""
