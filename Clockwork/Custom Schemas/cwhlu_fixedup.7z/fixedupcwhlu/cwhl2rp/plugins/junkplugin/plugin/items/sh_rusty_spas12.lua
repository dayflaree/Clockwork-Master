--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Rusty Shotgun";
ITEM.cost = 8;
ITEM.model = "models/Weapons/w_shotgun.mdl";
ITEM.weight = 0.5;
ITEM.access = "J";
ITEM.category = "Junk";
ITEM.business = true;
ITEM.description = "A rusted 12 Gauge SPAS-12. <color='FF0000'>This item is illegal.</color>";

function ITEM:OnDrop(player, position) end;

ITEM:Register();