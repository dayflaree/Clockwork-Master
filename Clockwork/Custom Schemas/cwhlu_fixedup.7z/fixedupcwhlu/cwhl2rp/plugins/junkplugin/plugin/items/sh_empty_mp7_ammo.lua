--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty MP7 Ammo Box";
ITEM.value = 0.10;
ITEM.cost = 8;
ITEM.model = "models/Items/BoxMRounds.mdl";
ITEM.weight = 0.5;
ITEM.access = "J";
ITEM.category = "Junk";
ITEM.business = true;
ITEM.description = "An empty box of MP7 bullets. <color='FF0000'>This item is illegal.</color>";

function ITEM:OnDrop(player, position) end;

ITEM:Register();