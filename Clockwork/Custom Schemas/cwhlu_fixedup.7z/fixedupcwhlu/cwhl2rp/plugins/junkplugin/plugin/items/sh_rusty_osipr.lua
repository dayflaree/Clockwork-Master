--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Rusty Pulse-Rifle";
ITEM.cost = 8;
ITEM.model = "models/Weapons/w_IRifle.mdl";
ITEM.weight = 0.5;
ITEM.access = "J";
ITEM.category = "Junk";
ITEM.business = true;
ITEM.description = "A rusted Pulse Rifle. <color='FF0000'>This item is illegal.</color>";

function ITEM:OnDrop(player, position) end;

ITEM:Register();