local Clockwork = Clockwork;

local PLUGIN = PLUGIN;

	
local markers = {}

resource.AddFile( "materials/therma/exclamation.png" )

local whitelist = {
	
	"Metropolice Force",
	"Overwatch Transhuman Arm"

}

local function AddMarker( pl )
	
	if table.HasValue( whitelist, pl:GetFaction() ) then
	
		for _, markerData in pairs( markers ) do
			
			if markerData.player == pl then
				
				table.remove( markers, key )
				
			end
			
		end
		
		local data = {
			
			[ "player" ] = pl,
			[ "players" ] = {},
			[ "time" ] = CurTime() + 480,
			[ "pos" ] = pl:GetPos()
			
		}
		
		table.insert( markers, data )
	
	end
	
end
hook.Add( "PlayerDeath", "add_marker", AddMarker )

local nextThink = 0
local function MarkerThink()

	if nextThink < CurTime() then
		
		for _, pl in pairs( player.GetAll() ) do
			
			if table.HasValue( whitelist, pl:GetFaction() ) then
			
				for key, data in pairs( markers ) do
					
					if not table.HasValue( data.players, pl ) then
						
						table.insert( data.players, pl )
						
						umsg.Start( "death_marker", pl )
						umsg.Char( key - 128 )
						umsg.Entity( data.player )
						umsg.Vector( data.pos )
						umsg.End()
						
					end
					
				end
			
			end
			
		end
		
		for key, data in pairs( markers ) do
			
			if data.time < CurTime() then
				
				umsg.Start( "death_marker_remove", data.players )
				umsg.Char( key - 128 )
				umsg.End()
				
				table.remove( markers, key )
				
			end
			
		end
		
		nextThink = CurTime() + 1
		
	end

end
hook.Add( "Think", "marker_think", MarkerThink )