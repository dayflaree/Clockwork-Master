local PLUGIN = PLUGIN;

local markers = {}
local function ReceiveMarker( msg )
			
	local index = msg:ReadChar() + 128
	local pl = msg:ReadEntity()
	local pos = msg:ReadVector()
	
	local data = {
		
		[ "player" ] = pl,
		[ "pos" ] = pos
		
	}
	
	markers[ index ] = data
	
end
usermessage.Hook( "death_marker", ReceiveMarker )

local function RemoveMarker( msg )
	
	local index = msg:ReadChar() + 128
	markers[ index ] = nil
	
end
usermessage.Hook( "death_marker_remove", RemoveMarker ) 

local icon = Material( "icon16/exclamation.png" )
local function DrawMarkers()
	
	surface.SetMaterial( icon )
	
	for _, data in pairs( markers ) do
		
		local pos = data.pos:ToScreen()
		draw.SimpleText( "No Response", "Default", pos.x + 1, pos.y + 19, Color( 0, 0, 0, 196 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "No Response", "Default", pos.x, pos.y + 18, Color( 255, 255, 255, 196 ), TEXT_ALIGN_CENTER )
		
		surface.SetDrawColor( Color( 115, 45, 45, 255 ) )
		surface.DrawTexturedRect( pos.x - 16, pos.y - 16, 32, 32 )
		
		local y = pos.y + math.sin( CurTime() * 2 ) * 28
		render.SetScissorRect( pos.x - 16, y - 8, pos.x + 16, y + 8, true )
		
		surface.SetDrawColor( Color( 255, 255, 255, 128 ) )
		surface.DrawTexturedRect( pos.x - 16, pos.y - 16, 32, 32 )
		
		render.SetScissorRect( 0, 0, 0, 0, false )
		
	end
	
end
hook.Add( "HUDPaint", "death_marker_draw", DrawMarkers )