-- Called when Clockwork has loaded all of the entities.
function cwStaticEnts:ClockworkInitPostEntity()
	self:LoadStaticEnts();
end;

-- Called just after data should be saved.
function cwStaticEnts:PostSaveData()
	self:SaveStaticEnts();
end;