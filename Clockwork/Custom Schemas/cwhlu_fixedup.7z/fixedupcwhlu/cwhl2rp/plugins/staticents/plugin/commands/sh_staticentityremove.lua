local COMMAND = Clockwork.command:New("StaticEntityRemove");
COMMAND.tip = "Mark the entity you're looking at as not-static.";
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = player:GetEyeTraceNoCursor().Entity;
	
	if (IsValid(target)) then
		if (!table.HasValue(cwStaticEnts.blacklistedClasses, target:GetClass())) then
			for k, v in pairs(cwStaticEnts.staticEnts) do
				if (target == v) then
					cwStaticEnts.staticEnts[k] = nil;
					cwStaticEnts:SaveStaticEnts();
					
					Clockwork.player:Notify(player, "You have removed a static entity.");
					
					return;
				end;
			end;
		else
			Clockwork.player:Notify(player, "This entity is not an allowed entity!");
		end;
	else
		Clockwork.player:Notify(player, "You must look at a valid entity!");
	end;
end;

COMMAND:Register();