PLUGIN:SetGlobalAlias("cwStaticEnts");

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

cwStaticEnts.blacklistedClasses = {"player", "cw_item", "cw_rationdispenser", "cw_vendingmachine", "cw_salesman", "cw_radio", "cw_belongings", "cw_shipment", "cw_cash", "cw_book", "cw_paper", "cw_breach", "cw_gear", "cw_combinelock", "cw_forcefield"}