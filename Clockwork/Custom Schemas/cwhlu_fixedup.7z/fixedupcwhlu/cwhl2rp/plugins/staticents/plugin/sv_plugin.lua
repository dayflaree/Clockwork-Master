-- A function to load the static props.
function cwStaticEnts:LoadStaticEnts()
	self.staticEnts = Clockwork.kernel:RestoreSchemaData("plugins/entities/"..game.GetMap());
	
	for k, v in pairs(self.staticEnts) do
		local entity = ents.Create(v.class);
			entity:SetMaterial(v.material);
			entity:SetAngles(v.angles);
			entity:SetColor(v.color);
			entity:SetModel(v.model);
			entity:SetPos(v.position);
			entity:Spawn();
		Clockwork.entity:MakeSafe(entity, true, true, v.frozen);
		
		self.staticEnts[k] = entity;
	end;
end;

-- A function to save the static props.
function cwStaticEnts:SaveStaticEnts()
	local staticEnts = {};
	
	if (type(self.staticEnts) == "table") then
		for k, v in pairs(self.staticEnts) do
			if !table.HasValue(cwStaticEnts.blacklistedClasses, v:GetClass()) then
				if (IsValid(v)) then
					local frozen = false
					if IsValid(v:GetPhysicsObject()) then
						frozen = v:GetPhysicsObject():IsMotionEnabled()
					end
					staticEnts[#staticEnts + 1] = {
						class = v:GetClass(),
						model = v:GetModel(),
						color = v:GetColor(),
						angles = v:GetAngles(),
						position = v:GetPos(),
						material = v:GetMaterial(),
						frozen = frozen
					};
				end;
			else
				self.staticEnts[k] = nil
			end
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/entities/"..game.GetMap(), staticEnts);
end;