
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.config:Add("ration_interval", 720);