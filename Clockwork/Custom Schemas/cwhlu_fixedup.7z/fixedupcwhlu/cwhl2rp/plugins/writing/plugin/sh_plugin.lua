--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

PLUGIN.paperIDs = {};

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");