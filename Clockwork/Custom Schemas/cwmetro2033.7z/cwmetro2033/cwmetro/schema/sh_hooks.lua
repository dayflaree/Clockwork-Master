function Clockwork.kernel:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:String("customClass");
	playerVars:Number("clothes", true);
end;