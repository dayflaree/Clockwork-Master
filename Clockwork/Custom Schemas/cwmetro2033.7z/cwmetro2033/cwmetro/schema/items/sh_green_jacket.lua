--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.cost = 150;
	ITEM.name = "Green Coat";
	ITEM.weight = 1.5;
	ITEM.replacement = "models/green_coat.mdl";
	ITEM.description = "A green coat to keep you warm.";
Clockwork.item:Register(ITEM);