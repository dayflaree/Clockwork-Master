--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
	ITEM.cost = 8;
	ITEM.name = "Clean water";
	ITEM.model = "models/props_junk/glassjug01.mdl";
	ITEM.batch = 1;
	ITEM.weight = 0.30;
	ITEM.access = "T";
	ITEM.business = true;
	ITEM.description = "A glass bottle filled with liquid, is seems pretty clean with the odd bit of crap floating around.";
	
	-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 14, 0, player:GetMaxHealth() ) );
end;

	-- Called when a player drinks the item.
	function ITEM:OnDrink(player)
		local instance = Clockwork.item:CreateInstance("empty_water_bottle");

		player:GiveItem(instance, true);
	end;
Clockwork.item:Register(ITEM);