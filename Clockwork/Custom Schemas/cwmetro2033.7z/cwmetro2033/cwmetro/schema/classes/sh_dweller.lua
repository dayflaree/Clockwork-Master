--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(179, 106, 3, 35);
	CLASS.factions = {FACTION_DWELLER};
	CLASS.isDefault = true;
	CLASS.description = "A survivor of the world's most catastrophic epidemic.";
	CLASS.defaultPhysDesc = "Wearing dirty clothes and a small satchel";
CLASS_DWELLER = Clockwork.class:Register(CLASS, "Metro Dweller");