--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(19, 86, 210, 219);
	CLASS.factions = {FACTION_REDLINE};
	CLASS.isDefault = true;
	CLASS.description = "A member of the Red Line.";
	CLASS.defaultPhysDesc = "Wearing a Red Line uniform.";
CLASS_REDLINE = Clockwork.class:Register(CLASS, "Red Line Comrade");