--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(103, 5, 173, 275);
	CLASS.factions = {FACTION_BANDITS};
	CLASS.isDefault = true;
	CLASS.description = "A Bandit wearing Bandit clothing.";
	CLASS.defaultPhysDesc = "Let of a horrible smell, wearing Bandit clothing.";
CLASS_BANDITS = Clockwork.class:Register(CLASS, "Bandits");