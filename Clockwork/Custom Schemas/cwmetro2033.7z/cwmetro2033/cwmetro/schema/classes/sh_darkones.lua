--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(199, 209, 4, 63);
	CLASS.factions = {FACTION_DARKONES};
	CLASS.isDefault = true;
	CLASS.description = "A disfigured human from the radiation.";
	CLASS.defaultPhysDesc = "Deformed and disfigured human from the radiation.";
CLASS_DARKONES = Clockwork.class:Register(CLASS, "Dark Ones");