--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(26, 134, 5, 110);
	CLASS.factions = {FACTION_STALKERS};
	CLASS.isDefault = true;
	CLASS.description = "A person in a Stalker uniform and smells.";
	CLASS.defaultPhysDesc = "Wearing a Stalker uniform.";
CLASS_STALKERS = Clockwork.class:Register(CLASS, "Stalker");