--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(210, 19, 19, 0);
	CLASS.factions = {FACTION_REICH};
	CLASS.isDefault = true;
	CLASS.description = "A member of the Fourth Reich.";
	CLASS.defaultPhysDesc = "Wearing a Fourth Reich uniform.";
CLASS_REICH = Clockwork.class:Register(CLASS, "Fourth Reich Soldier");