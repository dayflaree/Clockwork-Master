local CLASS = Clockwork.class:New("Bounty Hunter");
	CLASS.color = Color(86, 152, 0);
	CLASS.factions = {FACTION_HUNTERS};
	CLASS.isDefault = true;
	CLASS.hasJetpack = true;
CLASS_HUNTER = CLASS:Register();