local CLASS = Clockwork.class:New("Citizen");
	CLASS.color = Color(223, 187, 5);
	CLASS.factions = {FACTION_CITIZEN};
CLASS_CITIZEN = CLASS:Register();