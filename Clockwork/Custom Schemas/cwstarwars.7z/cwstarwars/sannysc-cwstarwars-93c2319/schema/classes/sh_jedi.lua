local CLASS = Clockwork.class:New("Jedi");
	CLASS.color = Color(88, 50, 0);
	CLASS.factions = {FACTION_JEDI};
	CLASS.isDefault = true;
CLASS_JEDI = CLASS:Register();