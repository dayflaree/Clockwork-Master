local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "SE-14C";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_se14c.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_se14c";
	ITEM.description = "";
ITEM:Register();