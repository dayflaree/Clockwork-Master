local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "I-HR";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_ihr.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_ihr";
	ITEM.description = "";
ITEM:Register();