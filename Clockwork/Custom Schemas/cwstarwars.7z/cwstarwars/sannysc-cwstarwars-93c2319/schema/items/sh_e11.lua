local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "E-11";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_e11.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_e11";
	ITEM.description = "";
ITEM:Register();