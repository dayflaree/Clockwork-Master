local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "E-60R";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_e60r.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_e60r";
	ITEM.description = "";
ITEM:Register();