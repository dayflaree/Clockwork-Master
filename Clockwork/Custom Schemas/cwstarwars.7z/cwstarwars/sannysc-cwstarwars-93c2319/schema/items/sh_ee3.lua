local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "EE-3";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_ee3.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_ee3";
	ITEM.description = "";
ITEM:Register();