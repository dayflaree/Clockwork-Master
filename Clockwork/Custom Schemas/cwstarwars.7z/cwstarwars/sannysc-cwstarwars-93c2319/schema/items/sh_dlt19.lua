local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "DLT-19";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_dlt19.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_dlt19";
	ITEM.description = "";
ITEM:Register();