local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Bowcaster";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_bowcaster.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_bowcaster";
	ITEM.description = "";
ITEM:Register();