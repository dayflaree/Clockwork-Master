local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "DE-10";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_de10.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_de10";
	ITEM.description = "";
ITEM:Register();