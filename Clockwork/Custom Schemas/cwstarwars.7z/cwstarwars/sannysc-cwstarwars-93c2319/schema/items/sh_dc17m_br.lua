local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "DC-17m BR";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_dc17m_br.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_dc17m_br";
	ITEM.description = "";
ITEM:Register();