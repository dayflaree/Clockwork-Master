local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "DC-15S";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_dc15s.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_dc15s";
	ITEM.description = "";
ITEM:Register();