local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "T-21";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_t21.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_t21";
	ITEM.description = "";
ITEM:Register();