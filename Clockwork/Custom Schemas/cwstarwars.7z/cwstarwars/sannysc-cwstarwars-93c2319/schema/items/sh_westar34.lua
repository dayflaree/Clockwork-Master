local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "WESTAR-34";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_westar34.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_westar34";
	ITEM.description = "";
ITEM:Register();