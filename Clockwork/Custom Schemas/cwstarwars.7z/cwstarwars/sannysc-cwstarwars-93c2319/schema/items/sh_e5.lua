local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "E-5";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_e5.mdl";
	ITEM.weight = 2.5;
	ITEM.uniqueID = "weapon_752_e5";
	ITEM.description = "";
ITEM:Register();