function microwavemenu(player, entity)
	local name = player:GetName()
	
	local DermaFrame = vgui.Create("DFrame") 
	DermaFrame:SetSize(465, 343)
	DermaFrame:Center()
	DermaFrame:SetTitle("Microwave Menu") 
	DermaFrame:SetDraggable(true)
	DermaFrame:SetSizable(false)
	DermaFrame:ShowCloseButton(true)
	DermaFrame:MakePopup()

	local FoodNo1 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo1:SetPos(21, 24)
	FoodNo1:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo1:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo1.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo2 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo2:SetPos(123, 24)
	FoodNo2:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo2:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo2.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo3 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo3:SetPos(231, 24)
	FoodNo3:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo3:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo3.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo4 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo4:SetPos(339, 24)
	FoodNo4:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo4:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo4.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo5 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo5:SetPos(21, 118)
	FoodNo5:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo5:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo5.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo6 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo6:SetPos(123, 118)
	FoodNo6:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo6:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo6.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo7 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo7:SetPos(231, 118)
	FoodNo7:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo7:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo7.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo8 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo8:SetPos(339, 118)
	FoodNo8:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo8:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo8.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo9 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo9:SetPos(21, 208)
	FoodNo9:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo9:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo9.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end

	local FoodNo10 = vgui.Create("SpawnIcon" , DermaFrame)
	FoodNo10:SetPos(123, 208)
	FoodNo10:SetModel("models/props_junk/garbage_takeoutcarton001a.mdl")
	FoodNo10:SetToolTip("Name: Example Food, Cost: $10")
	FoodNo10.DoClick = function()
		local amount = 10
		local item = "example_food"
		local data = {entity, item, amount}
		if entity:GetNetworkedBool("InUse") == false then
			GAMEMODE:AddNotify("Your food is being microwaved $"..amount.." has been deducted from your account.", NOTIFY_HINT, 5)
			Clockwork.datastream:Start("MicrowaveSound", data)
		else
			GAMEMODE:AddNotify("The microwave is currently in use!", NOTIFY_ERROR, 5)
		end
	end
end

-- Hook to initialise the microwave menu.
Clockwork.datastream:Hook("MicrowaveMenu", function(data)
	microwavemenu(player, entity)
end)