function menu_website()
	gui.OpenURL("http://www.wiki.orbiter-gaming.com/index.php/How_To_Play_Science_RP")
end

Clockwork.datastream:Hook("Website", function()
	menu_website()
end)

