function menu_sciencetracker(player)

	local DermaFrame = vgui.Create( "DFrame" ) 
	DermaFrame:SetPos( 600, 100 )
	DermaFrame:SetSize( ScrH() / 2, ScrW() / 3 )
	DermaFrame:SetTitle( "Science Tracker" )
	DermaFrame:SetVisible( true )
	DermaFrame:SetDraggable( true )
	DermaFrame:ShowCloseButton( true )
	DermaFrame:MakePopup()

	-- Main Menu
	local DermaPanel = vgui.Create( "DPanel", DermaFrame )
	DermaPanel:SetPos( 10, 30 )
	DermaPanel:SetSize( ScrH() / 3, ScrW() / 4 )
end

Clockwork.datastream:Hook("ScienceTrackerMenu", function()
	menu_sciencetracker(player)
end)