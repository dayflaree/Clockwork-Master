--- The PDA the administrative faction uses.
local lockdowncheck = false

function adminpanel(player)
local name = player:Nick()

-- Datastream to get current lockdown situation from server.
Clockwork.datastream:Start("RequestLockdownCheck", true)

local DermaFrame = vgui.Create( "DFrame" ) 
DermaFrame:SetPos( 600, 100 )
DermaFrame:SetSize( 1000, 900 )
DermaFrame:SetTitle( "Administrator's PDA" )
DermaFrame:SetVisible( true )
DermaFrame:SetDraggable( true )
DermaFrame:ShowCloseButton( true )
DermaFrame:MakePopup()

-- Main Menu
local DermaPanel = vgui.Create( "DPanel", DermaFrame )
DermaPanel:SetPos( 10, 30 )
DermaPanel:SetSize( 980, 860 )

-- Company Controls
local btnAdCheckName = vgui.Create( "DButton" )
btnAdCheckName:SetParent( DermaPanel )
btnAdCheckName:SetText( "Check Company Name" )
btnAdCheckName:SetPos( 25, 50 )
btnAdCheckName:SetSize( 200, 25 )
btnAdCheckName.DoClick = function()
	Clockwork.datastream:Start( "requestcompanyname", player )
	end

local btnAdSetName = vgui.Create( "DButton" )
btnAdSetName:SetParent( DermaPanel )
btnAdSetName:SetText( "Set Company Name" )
btnAdSetName:SetPos( 300, 50 )
btnAdSetName:SetSize( 200, 25 )
btnAdSetName.DoClick = function()
	Derma_StringRequest("Company Name", "What would you like to set the company name to?", name, function(name)
		if name != "" and name != " " then
			MsgN(name) 
			Clockwork.datastream:Start( "setcompanyname", name )
		else
			Derma_Message("You must enter a name!", "Error", "Okay")	
		end
	end)
	end

local btnAdCompanyAnnouncement = vgui.Create("DButton")
btnAdCompanyAnnouncement:SetParent(DermaPanel)
btnAdCompanyAnnouncement:SetText("Broadcast Company Announcement")
btnAdCompanyAnnouncement:SetPos(575, 50)
btnAdCompanyAnnouncement:SetSize(200, 25)
btnAdCompanyAnnouncement.DoClick = function()
	Derma_StringRequest("Company Announcement", "What would you like to announce?", text, function(text)
		Clockwork.datastream:Start( "companyannouncement", text)
	end)
	end		

-- Bank Balance Controls 
local lblBalance = vgui.Create( "DLabel", DermaPanel )
lblBalance:SetPos(50, 150 )
lblBalance:SetColor(Color(36,36,36,255))
lblBalance:SetFont("default")
lblBalance:SetText("Bank Balance Control")
lblBalance:SizeToContents()

local btnAdCheckBalance = vgui.Create("DButton")
btnAdCheckBalance:SetParent(DermaPanel)
btnAdCheckBalance:SetText("Check Balance")
btnAdCheckBalance:SetPos(25, 180)
btnAdCheckBalance:SetSize(200, 25)
btnAdCheckBalance.DoClick = function()
	Clockwork.datastream:Start("RequestBalance", player)
	end

--Facility Systems
local lblFacilitySystems = vgui.Create("DLabel", DermaPanel)
lblFacilitySystems:SetPos(50, 280)
lblFacilitySystems:SetColor(Color(36,36,36,255))
lblFacilitySystems:SetFont("default")
lblFacilitySystems:SetText("Facility Systems")
lblFacilitySystems:SizeToContents()

local btnAdLockdown = vgui.Create("DButton")
btnAdLockdown:SetParent(DermaPanel)
if lockdowncheck == false then
	btnAdLockdown:SetText("Initiate Lockdown")
else
	btnAdLockdown:SetText("Lift Lockdown")	
end	
btnAdLockdown:SetPos(25, 310)
btnAdLockdown:SetSize(200, 25)
btnAdLockdown.DoClick = function()
		if lockdowncheck == false then
			lockdowncheck = true
			Clockwork.datastream:Start("companyannouncement", "ALERT! LOCKDOWN INITIATED! MOVE TO DESIGNATED LOCATIONS!")
			Clockwork.datastream:Start("Lockdown", lockdowncheck)
			btnAdLockdown:SetText("Lift Lockdown")
		elseif lockdowncheck == true then
			lockdowncheck = false
			Clockwork.datastream:Start("companyannouncement", "Lockdown lifted. Authorisation: "..name)
			Clockwork.datastream:Start("Lockdown", lockdowncheck)
			btnAdLockdown:SetText("Initiate Lockdown")
		end
	end

local btnAdCheckBalance = vgui.Create("DButton")
btnAdCheckBalance:SetParent(DermaPanel)
btnAdCheckBalance:SetText("Message Science Team")
btnAdCheckBalance:SetPos(300, 310)
btnAdCheckBalance:SetSize(200, 25)
btnAdCheckBalance.DoClick = function()
	Derma_StringRequest("Message Science Team", "What would you like to say?", text, function(text)
	Clockwork.chatBox:Add(nil, nil, nil, "**"..name.."** Message To Science Team: "..text)	
	Clockwork.datastream:Start("MessageScienceTeam", text)
	end)	
	end

local btnAdCheckBalance = vgui.Create("DButton")
btnAdCheckBalance:SetParent(DermaPanel)
btnAdCheckBalance:SetText("Message Security Team")
btnAdCheckBalance:SetPos(575, 310)
btnAdCheckBalance:SetSize(200, 25)
btnAdCheckBalance.DoClick = function()
	Derma_StringRequest("Message Science Team", "What would you like to say?", text, function(text)
	Clockwork.chatBox:Add(nil, nil, nil, "**"..name.."** Message To Security Team: "..text)	
	Clockwork.datastream:Start("MessageSecurityTeam", text)
	end)	
	end


-- Employee listings.
local DermaPanel_2 = vgui.Create("DPanel", DermaFrame)
DermaPanel_2:SetPos(10, 30)
DermaPanel_2:SetSize(980, 860)

local EmployeeList = vgui.Create("DListView")
EmployeeList:SetParent(DermaPanel_2)
EmployeeList:SetPos(10, 10)
EmployeeList:SetSize(930, 790)
EmployeeList:SetMultiSelect(false)
EmployeeList:AddColumn("Employee Name")
EmployeeList:AddColumn("Job Position")
for k,v in ipairs(_player.GetAll()) do
    EmployeeList:AddLine(v:GetName(), v:GetFaction())
end

local MainMenu = vgui.Create("DPropertySheet", DermaFrame)
MainMenu:SetPos(10, 30)
MainMenu:SetSize(DermaPanel:GetWide() - 4, DermaPanel:GetTall() - 22)

MainMenu:AddSheet( "Main Menu", DermaPanel, "gui/silkicons/application", false, false, "The Main Menu." )
MainMenu:AddSheet("Employee Menu", DermaPanel_2, "gui/silkicons/group", false, false, "The Employee Menu")

end

-- Datastream hook for receiving the Company Name.
Clockwork.datastream:Hook("companyname", function(data)
	Derma_Message("Company Name: "..data.."", "Company Name", "Thanks!")
end)

-- Datastream hook for receiving the Company Balance
Clockwork.datastream:Hook("SendBalance", function(balance)
	Derma_Message("Company's Bank Balance: $"..balance)	
end)

-- Datastream hook for receiving request to open the Admin PDA
Clockwork.datastream:Hook("AdminPDA", function(player)
	adminpanel(player)	
end)

-- Datastream hook for receiving what the server lockdown is set to.
Clockwork.datastream:Hook("ReturnLockdownCheck", function(lockdownreturn)
	lockdowncheck = lockdownreturn
end)