-- Called when a player's default model is needed.
function Schema:GetPlayerDefaultModel(player)
end

function Schema:KeyPress(player, key)
end	

function Schema:SaveDoorClearance()
	local doorLevel = {}

	for k, v in pairs(ents.GetAll()) do
		if (v:GetClass() == "func_door") or (v:GetClass() == "prop_door_rotating") or (v:GetClass() == "func_door_rotating") then
			local data = {
				door = v,
				level = v:GetNetworkedString("Level"),
				position = v.position
			}

			doorLevel[#doorLevel + 1] = data
		end
	end

	Clockwork.kernel:SaveSchemaData("plugins/doorlevel/"..game.GetMap(), doorLevel)
end

function Schema:LoadDoorClearance()
	doorLevel = {};
	
	local positions = {};
	local doorLevel = Clockwork.kernel:RestoreSchemaData("plugins/doorlevel/"..game.GetMap());
	
	for k, v in pairs(ents.GetAll()) do
		if (IsValid(v)) then
			local position = v:GetPos()
			
			if (position) then
				positions[tostring(position)] = v
			end
		end
	end
	
	for k, v in pairs(doorLevel) do
		local entity = positions[tostring(v.position)]
		
		if (IsValid(entity) and !doorLevel[entity]) then
			if (Clockwork.entity:IsDoor(entity)) then
				local data = {
				door = v,
				level = v:SetNetworkedString("Level"),
				position = v.position
			}			
				doorLevel[data.entity] = data
			end;
		end;
	end;
end;


-- Called when a player's default inventory is needed.
function Schema:GetPlayerDefaultInventory(player, character, inventory)
	if (character.faction == FACTION_ADMIN) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		)
	elseif (character.faction == FACTION_SECGUARD) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		)
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("weapon_pistol")
		)
		for i = 1, 2 do
			Clockwork.inventory:AddInstance(
				inventory, Clockwork.item:CreateInstance("ammo_pistol")
			)
		end
	elseif (character.faction == FACTION_SCIENTIST) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		)
	end
end
-- Called to check if a player does recognise another player.
function Schema:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
	if (target:GetFaction() == FACTION_CHIEFSEC or target:GetFaction() == FACTION_ADMIN) then
		return true
	end
end

function Schema:ClockworkInitPostEntity()
	self:LoadCookers()
	self:LoadMicrowaves()
end	

function Schema:PlayerUseDoor(player, door)
	local level_1 = player:FindItemByID("id_card_level1")
	local level_2 = player:FindItemByID("id_card_level2")
	local level_3 = player:FindItemByID("id_card_level3")
	local level_4 = player:FindItemByID("id_card_level4")
	local level_5 = player:FindItemByID("id_card_level5")
	local door_level = door:GetNetworkedString("Level")
	if door_level == "1" then
		if level_1 then
			id_open_door(door)
		else
			Clockwork.player:Notify(player, "You require a Level 1 ID Card access to enter this area.")
		end
	elseif door_level == "2" then
		if level_1 or level_2 then
			id_open_door(door)
		else
			Clockwork.player:Notify(player, "You require a Level 2+ ID Card access to enter this area.")	
		end
	elseif door_level == "3" then
		if level_1 or level_2 or level_3 then
			id_open_door(door)
		else
			Clockwork.player:Notify(player, "You require a Level 3+ ID Card access to enter this area.")	
		end
	elseif door_level == "4" then
		if level_1 or level_2 or level_3 or level_4 then
			id_open_door(door)
		else
			Clockwork.player:Notify(player, "You require a Level 4+ ID Card access to enter this area.")	
		end
	elseif door_level == "5" then
		if level_1 or level_2 or level_3 or level_4 or level_5 then
			id_open_door(door)
		else
			Clockwork.player:Notify(player, "You require a Level 5+ ID Card access to enter this area.")	
		end
	else
		return nil				 
	end	
end

function id_open_door(door)
	door:Fire("unlock")
	door:Fire("open")
	timer.Simple(5, function()
		door:Fire("close")
		door:Fire("lock")	
	end)
end		

--Called what to do after saving.
function Schema:PostSaveData()
	self:SaveCookers()
	self:SaveMicrowaves()
end