-- Called when the cinematic intro info is needed.
function Schema:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = "Science Roleplay",
		text = "Where it's all about the money."
	};
end;

-- Called to check if a player does recognise another player.
function Schema:PlayerDoesRecognisePlayer(player, status, isAccurate, realValue)
	if (player:GetFaction() == FACTION_CHIEFSEC or player:GetFaction() == FACTION_ADMIN) then
		return true
	end
end