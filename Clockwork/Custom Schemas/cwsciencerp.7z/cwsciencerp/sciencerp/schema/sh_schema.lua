
Clockwork.kernel:IncludePrefixed("cl_schema.lua")
Clockwork.kernel:IncludePrefixed("sv_schema.lua")
Clockwork.kernel:IncludePrefixed("sh_hooks.lua")
Clockwork.kernel:IncludePrefixed("sv_hooks.lua")
Clockwork.kernel:IncludePrefixed("cl_hooks.lua")
Clockwork.kernel:IncludePrefixed("cl_theme.lua")

Clockwork.option:SetKey("menu_music", "common/sciencerptheme.mp3")
newspaper_text = "Aperture Science reach a new breakthrough, in trans dimensional travel!"
newspaper = "HEADLINE: "..newspaper_text

function microwave_play_sounds(player, data)
	local entity = data[1]
	entity:SetNetworkedBool("InUse", true)
	Clockwork.microwavebeep = CreateSound(entity, "buttons/button3.wav")
	Clockwork.microwavestart = CreateSound(entity, "buttons/button1.wav")
	Clockwork.microwaveduring = CreateSound(entity, "ambient/machines/combine_shield_loop3.wav")
	Clockwork.microwavedone = CreateSound(entity, "buttons/blip1.wav")
	Clockwork.microwavebeep:PlayEx(0.75, 100)
	timer.Simple(0.75, function()
		Clockwork.microwavestart:PlayEx(0.75, 100)
		Clockwork.microwaveduring:PlayEx(0.75, 100)
		timer.Simple(15, function()
			Clockwork.microwaveduring:Stop()
			Clockwork.microwavedone:PlayEx(0.75, 100)
			player:GiveItem(Clockwork.item:CreateInstance(data[2]), true)
			Clockwork.player:GiveCash(player, -data[3], nil, true)
			entity:SetNetworkedBool("InUse", false)
		end)
	end)
	
end

function Schema:ScientistSystem()
	local tree1_points = 0
	local tree2_points = 0
	local tree3_points = 0
end	

Clockwork.datastream:Hook("MicrowaveSound", function(player, data)
	microwave_play_sounds(player, data)
end)