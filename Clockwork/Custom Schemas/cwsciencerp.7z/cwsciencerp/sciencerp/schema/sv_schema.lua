Clockwork.kernel:AddFile("sound/common/sciencerptheme.mp3");

local CompanyName = "Orbiter Science Facility"
local balance = 100
local lockdown = false

function Schema:MakeAnnouncement(text)
	for k, v in ipairs(player.GetAll()) do
		v:PrintChat(text)
	end
end

-- Function to make a company announcment to players.
function Schema:CompanyAnnouncement(player, text)
	Clockwork.chatBox:Add(nil, nil, "companyannouncement", "COMPANY ANNOUNCEMENT: "..text)
end

function Schema:MessageScienceTeam(player, text)
	local name = player:Nick()
	for k, v in ipairs(_player.GetAll()) do
		local faction = v:GetFaction()
		if faction == FACTION_SCIENTIST then
			Clockwork.datastream:Start(v, "RecieveMsgScience", {name, text})
		end	
	end	
end

function Schema:MessageSecurityTeam(player, text)
	local name = player:Nick()

	for k, v in ipairs(_player.GetAll()) do
		local faction = v:GetFaction()
		if faction == FACTION_SECGUARD or faction == FACTION_CHIEFSEC then
			Clockwork.datastream:Start(v, "RecieveMsgSecurity", {name, text})
		end
	end
end

function Schema:MessageAdministrator(player, text)
	local name = player:Nick()

	for k, v in ipairs(_player.GetAll()) do
		local faction = v:GetFaction()
		if faction == FACTION_ADMIN then
			Clockwork.datastream:Start(v, "RecieveMsgAdmin", {name, text})
		end
	end
end

function Schema:MessageJanitor(player, text)
	local name = player:Nick()

	for k, v in ipairs(_player.GetAll()) do
		local faction = v:GetFaction()
		if faction == FACTION_JANITOR then
			Clockwork.datastream:Start(v, "RecieveMsgJanitor", {name, text})
		end
	end
end


function Schema:MessageCook(player, text)
	local name = player:Nick()

	for k, v in ipairs(_player.GetAll()) do
		local faction = v:GetFaction()
		if faction == FACTION_COOK then
			Clockwork.datastream:Start(v, "RecieveMsgAdmin", {name, text})
		end
	end
end


function Schema:RadioMessage(player, text)
	local name = player:Nick()

	for k, v in ipairs(_player.GetAll()) do
		if v:FindItemByID("radio") then
			if v:Nick() != name then
			Clockwork.chatBox:Add(nil, nil, "radiomessage", name.." radios in "..text)
			end
		end

	end
end	

function Schema:Lockdown(person, check)
	for k, v in ipairs(_player.GetAll()) do	
		if check == true then
			Clockwork.lockdownalarm = CreateSound(v, "ambient/alarms/alarm_citizen_loop1.wav")
			Clockwork.lockdownalarm:PlayEx(0.75, 100)
		else
			Clockwork.lockdownalarm:FadeOut(3)
		end
	end
end

-- A function to save the cookers.
function Schema:SaveCookers()
	local cookers = {}
	
	for k, v in pairs(ents.FindByClass("sr_cookers")) do
		machines[#cookers + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos(),
		}
	end
	
	Clockwork.kernel:SaveSchemaData("plugins/cookers/"..game.GetMap(), cookers)
end

-- A function to load the cookers.
function Schema:LoadCookers()
	local cookers = Clockwork.kernel:RestoreSchemaData("plugins/cookers/"..game.GetMap())
	
	for k, v in pairs(cookers) do
		local entity = ents.Create("sr_cooker")
		
		entity:SetPos(v.position)
		entity:Spawn()
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles)
		end
	end
end

-- A function to save the microwaves.
function Schema:SaveMicrowaves()
	local microwave = {}
	
	for k, v in pairs(ents.FindByClass("sr_microwave")) do
		machines[#microwave + 1] = {
			angles = v:GetAngles(),
			position = v:GetPos(),
		}
	end
	
	Clockwork.kernel:SaveSchemaData("plugins/microwave/"..game.GetMap(), microwave)
end

-- A function to load the cookers.
function Schema:LoadMicrowaves()
	local microwave = Clockwork.kernel:RestoreSchemaData("plugins/microwave/"..game.GetMap())
	
	for k, v in pairs(microwave) do
		local entity = ents.Create("sr_microwave")
		
		entity:SetPos(v.position)
		entity:Spawn()
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles)
		end
	end
end


		
-- Datastream hook for requesting the company name.
Clockwork.datastream:Hook("requestcompanyname", function(player)
	Clockwork.datastream:Start(player, "companyname", CompanyName)
end)

-- Datastream hook for sending a message to the science team.
Clockwork.datastream:Hook("MessageScienceTeam", function(player, text)
	MsgN(text)
	MsgN(player)
	Schema:MessageScienceTeam(player, text)	 
end)

Clockwork.datastream:Hook("MessageSecurityTeam", function(player, text)
	Schema:MessageSecurityTeam(player, text)	
end)

-- Datastream hook for setting the company name.
Clockwork.datastream:Hook("setcompanyname", function(player, text)
	CompanyName = text
	notice = "Company name has been changed to "..text.."."
	Schema:CompanyAnnouncement(player, notice)
end)

-- Datastream hook for a company announcement.
Clockwork.datastream:Hook("companyannouncement", function(player, text)
		Schema:CompanyAnnouncement(player, text)
	end)

-- Datastreah hook for requesting the budget.
Clockwork.datastream:Hook("RequestBalance", function(player)
		Clockwork.datastream:Start(player, "SendBalance", balance)
	end)

-- Datastream hook for starting a lockdown.
Clockwork.datastream:Hook("Lockdown", function(player, check)
		Schema:Lockdown(player, check)
		lockdown = check
	end)

--Datastream for getting lockdown check at start of PDA's
Clockwork.datastream:Hook("RequestLockdownCheck", function()
	Clockwork.datastream:Start(players, "ReturnLockdownCheck", lockdown)
end)