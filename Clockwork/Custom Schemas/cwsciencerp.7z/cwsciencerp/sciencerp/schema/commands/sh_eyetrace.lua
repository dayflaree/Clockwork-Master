local COMMAND = Clockwork.command:New("Eyetrace")
COMMAND.tip = "To get the object the player would look at."
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local eye = player:GetEyeTraceNoCursor()

	MsgN(eye.Entity)
end

COMMAND:Register()