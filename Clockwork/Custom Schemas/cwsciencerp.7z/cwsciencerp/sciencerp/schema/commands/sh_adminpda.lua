local COMMAND = Clockwork.command:New("AdminPDA");
COMMAND.tip = "Open the Admin PDA"
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local faction = player:GetFaction()

	if (faction == FACTION_ADMIN) then
		Clockwork.datastream:Start(player, "AdminPDA", player)
	else
		Clockwork.player:Notify(player, "You need to have the administrator job to use this command.")	
	end
end

COMMAND:Register()