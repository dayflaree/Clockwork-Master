local COMMAND = Clockwork.command:New("RequestForm")
COMMAND.tip = "Sends the target a form to fill out."
COMMAND.text = "<Target>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 2

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = arguments[1]
end
	

COMMAND:Register()