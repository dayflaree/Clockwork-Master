local COMMAND = Clockwork.command:New("SaveDoorData");
COMMAND.tip = "SavesDoorData"
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Schema:SaveDoorClearance()
end

COMMAND:Register()