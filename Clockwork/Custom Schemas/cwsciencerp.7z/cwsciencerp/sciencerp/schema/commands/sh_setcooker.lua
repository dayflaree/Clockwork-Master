local COMMAND = Clockwork.command:New("SetCooker")
COMMAND.tip = "Ability to allow cooks to set a cooker."
COMMAND.text = "<none>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTrace()
	local model = trace.Entity:GetModel()

	MsgN(model)
	MsgN(trace)
	if (trace.Entity:GetModel() == "models/props_wasteland/kitchen_stove001a.mdl" or trace.Entity:GetModel() == "models/props_c17/furniturestove001a.mdl") then
		trace.Entity:SetNetworkedBool("Cooker", true)
		Clockwork.player:Notify(player, "This has been set to a cooker.")
	else
		Clockwork.player:Notify(player, "This is not a valid model.")
	end
end

COMMAND:Register()