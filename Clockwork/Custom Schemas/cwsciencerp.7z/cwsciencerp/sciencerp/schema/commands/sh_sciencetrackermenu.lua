local COMMAND = Clockwork.command:New("ScienceTracker");
COMMAND.tip = "Open the Science Tracker"
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local faction = player:GetFaction()

	if (faction == FACTION_SCIENTIST) then
		Clockwork.datastream:Start(player, "ScienceTrackerMenu", player)
	else
		Clockwork.player:Notify(player, "You need to be a scientist to use this command.")	
	end
end

COMMAND:Register()