local COMMAND = Clockwork.command:New("LoadDoorData");
COMMAND.tip = "LoadDoorData"
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Schema:LoadDoorClearance()
end

COMMAND:Register()