
local COMMAND = Clockwork.command:New("msgsc")
COMMAND.tip = "Send a message to the science team."
COMMAND.text = "<text>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local name = player:Nick()
	local message = arguments[1]
	local faction = player:GetFaction()
	if faction == FACTION_VISITOR or faction == FACTION_MILITARY or faction == FACTION_FBI or faction == FACTION_ALIEN then
		Clockwork.player:Notify(player, "You can not use this command.")
	else
		Clockwork.chatBox:AddInRadius(player, "messagescience", message, player:GetPos(), Clockwork.config:Get("talk_radius"):Get())
		Schema:MessageScienceTeam(player, message)
	end
end

COMMAND:Register()