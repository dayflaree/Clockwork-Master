
local COMMAND = Clockwork.command:New("msgcook")
COMMAND.tip = "Send a message to Cooks."
COMMAND.text = "<text>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local name = player:Nick()
	local message = arguments[1]
	local counter = 0
	for k, v in ipairs(_player.GetAll()) do
		local group = v:GetClockworkUserGroup()
		if group == "superadmin" or group == "admin"
			counter = counter + 1
			Clockwork.datastream:Start(v, "Report", {name, message})
		end
	end

	if counter == 0 then
		Clockwork.player:Notify(player, "Report failed to send. No admins online.")
	else
		Clockwork.player:Notify(player, "Report sent.")
	end
end

COMMAND:Register()