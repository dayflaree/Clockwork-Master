local COMMAND = Clockwork.command:New("SetDoorLevel")
COMMAND.tip = "Set the level of ID needed between 1 & 5."
COMMAND.text = "<ID Level>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 1

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local level = arguments[1]
	local trace = player:GetEyeTraceNoCursor()
	local message = trace.Entity:GetNetworkedString("Level")

	if (trace.Entity:GetClass() == "func_door") or (trace.Entity:GetClass() == "prop_door_rotating") or (trace.Entity:GetClass() == "func_door_rotating") then
		if level == "1" or level == "2" or level == "3" or level == "4" or level == "5" then
			trace.Entity:SetNetworkedString("Level", level)
			Clockwork.player:Notify(player, "Door level ID set to: "..level..". It has now been automatically locked. Only Level "..level.."+ ID cards can access this door.")
			trace.Entity:Fire("lock")
		else
			Clockwork.player:Notify(player, "The level set must be 1, 2, 3, 4 or 5!")
		end
	else
		Clockwork.player:Notify(player, "This is not a proper door!")	
	end	
end

COMMAND:Register()