local COMMAND = Clockwork.command:New("GetDoorLevel")
COMMAND.tip = "Set the level of ID needed between 1 & 5."
COMMAND.text = "<ID Level>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor()
	local message = trace.Entity:GetNetworkedString("Level")

	Clockwork.player:Notify(player, "Door level is: "..message)
end
	

COMMAND:Register()