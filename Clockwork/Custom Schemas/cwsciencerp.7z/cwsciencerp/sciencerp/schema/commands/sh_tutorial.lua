local COMMAND = Clockwork.command:New("Tutorial")
COMMAND.tip = "First time playing? Use this command."
COMMAND.text = "<nothing>"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 0

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local website = "http://www.wiki.orbiter-gaming.com/index.php/How_To_Play_Science_RP"
	Clockwork.player:Notify(player, "Webpage is opening...")
	Clockwork.datastream:Start(player, "Website", website)
end

COMMAND:Register()