local COMMAND = Clockwork.command:New("CheckCompanyName");
COMMAND.tip = "Check what the company name is.";
COMMAND.text = "<nothing>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local check = 1
	local companyname = Schema:GetCompanyName(text, check)

	Clockwork.player:Notify(player, "Company is: "..companyname..".");
end;

COMMAND:Register();