local COMMAND = Clockwork.command:New("SetCompanyName");
COMMAND.tip = "Set what the company name is.";
COMMAND.text = "<string name>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = table.concat(arguments, " ")
	local check = 0

	Schema:GetCompanyName(text, check)
end;

COMMAND:Register();