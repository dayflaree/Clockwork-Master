local ITEM = Clockwork.item:New()
ITEM.name = "Slice Of Bacon"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/bacon.mdl"
ITEM.uniqueID = "slice_bacon"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Bacon"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "A lovely slice of bacon."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() - 10, 0, player:GetMaxHealth()))
	Clockwork.player:Notify(player, "You have just eaten uncooked meat!")
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()