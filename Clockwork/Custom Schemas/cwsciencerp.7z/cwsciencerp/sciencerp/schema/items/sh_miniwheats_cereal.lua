local ITEM = Clockwork.item:New()
ITEM.name = "Mini Wheats Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/miniwheats.mdl"
ITEM.uniqueID = "miniwheats_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cereal"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "They're mini! They're Wheaty! They're Mini Wheats. Cereal.."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()