local ITEM = Clockwork.item:New()
ITEM.name = "Panda Puffs Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/pandapuffs.mdl"
ITEM.uniqueID = "pandapuffs_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cereal"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Some say the cereal is made from real pandas! The feds haven't been able to prove it yet though."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()