local ITEM = Clockwork.item:New()
ITEM.name = "Cok O Pops Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/cokopops.mdl"
ITEM.uniqueID = "cokopops_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.access = "j"
ITEM.category = "Cereal"
ITEM.business = true
ITEM.description = "The best of both worlds! A tasty cereal and a phallic sounding name. Excellent!"


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()