local ITEM = Clockwork.item:New()
ITEM.name = "Cooked Slice Of Bacon"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/baconcooked.mdl"
ITEM.uniqueID = "cooked_bacon"
ITEM.weight = 0.5
ITEM.access = "j"
ITEM.useText = "Eat"
ITEM.category = "Bacon"
ITEM.business = false
ITEM.description = "A lovely slice of cooked bacon."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 30, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()