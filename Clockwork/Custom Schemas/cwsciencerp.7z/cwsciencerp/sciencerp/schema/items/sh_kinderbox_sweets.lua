local ITEM = Clockwork.item:New()
ITEM.name = "Kinder Eggs Box"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/kinderbox.mdl"
ITEM.uniqueID = "sweets_kindereggbox"
ITEM.weight = 1
ITEM.useText = "Use"
ITEM.category = "Sweets"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Kinder Egg box containing 3 kinder eggs."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()