local ITEM = Clockwork.item:New()
ITEM.name = "Sprunk Light"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/sprunk2.mdl"
ITEM.uniqueID = "drink_sprunklight"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Soft drink sprunk. The light version, so it tastes like shit."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()