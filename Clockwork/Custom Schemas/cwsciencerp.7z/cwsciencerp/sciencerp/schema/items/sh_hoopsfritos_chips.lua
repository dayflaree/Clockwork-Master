local ITEM = Clockwork.item:New()
ITEM.name = "Hoops Fritos"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/chipsfritoshoops.mdl"
ITEM.uniqueID = "chips_hoopsfritos"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Chips"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "They're hoops. Frito hoops. What the fuck."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()