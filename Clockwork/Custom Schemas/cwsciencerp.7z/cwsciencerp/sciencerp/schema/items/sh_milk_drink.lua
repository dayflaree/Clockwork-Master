local ITEM = Clockwork.item:New()
ITEM.name = "Milk"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/milk.mdl"
ITEM.uniqueID = "drink_colabottlebig"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Milked from cows. Not much else to say. Use it with cereal or something."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()