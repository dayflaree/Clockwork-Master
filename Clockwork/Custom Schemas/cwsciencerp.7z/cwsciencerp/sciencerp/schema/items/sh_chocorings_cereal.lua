local ITEM = Clockwork.item:New()
ITEM.name = "Choco Rings Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/cheerios.mdl"
ITEM.uniqueID = "chocorings_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cereal"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "The tasty Choco Rings Cereal. Perfect for Breakfast, or that lazy lunch!"


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()