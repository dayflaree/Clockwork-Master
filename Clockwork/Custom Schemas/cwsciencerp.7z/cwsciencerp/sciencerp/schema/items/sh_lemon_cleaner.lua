local ITEM = Clockwork.item:New()
ITEM.name = "Lemon Cleaner"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/lemoncleaner.mdl"
ITEM.uniqueID = "cleaner_lemoncleaner"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cleaner"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Called lemon cleaner but sure doesn't smell like lemon."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()