local ITEM = Clockwork.item:New()
ITEM.name = "BBQ Fritos"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/chipsfritosbbq.mdl"
ITEM.uniqueID = "chips_bbqfritos"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Chips"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Fritos. They look like food... I think. Taste like BBQ. Whatever the hell that tastes like."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()