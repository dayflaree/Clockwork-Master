local ITEM = Clockwork.item:New()
ITEM.name = "Bagette"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/bagette.mdl"
ITEM.uniqueID = "bagette"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Bread"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Fresh, hard, long piece of bread. Don't get too excited."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 5, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()