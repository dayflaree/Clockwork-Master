local ITEM = Clockwork.item:New()
ITEM.name = "Cornflakes Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/kellogscornflakes.mdl"
ITEM.uniqueID = "cornflakes_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cereal"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "A classic cereal, with an amazing taste."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()