--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base")
	ITEM.name = "Level 3 ID Card"
	ITEM.cost = 0
	ITEM.model = "models/props_citizen_tech/firetrap_button01a.mdl"
	ITEM.weight = 1
	ITEM.access = "j"
	ITEM.uniqueID = "id_card_level3"
	ITEM.business = true
	ITEM.description = "A Level 3 ID Card."
ITEM:Register()