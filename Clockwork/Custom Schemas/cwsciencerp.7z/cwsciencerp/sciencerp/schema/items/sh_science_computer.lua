local ITEM = Clockwork.item:New()
ITEM.name = "Boxed Basic Research Terminal"
ITEM.cost = 0
ITEM.model = "models/props_junk/wood_crate001a.mdl"
ITEM.uniqueID = "science_basicresearchterminal"
ITEM.weight = 60
ITEM.useText = "Build"
ITEM.category = "Science"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "A basic scientific terminal for all your scientific needs."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()