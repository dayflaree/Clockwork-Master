local ITEM = Clockwork.item:New()
ITEM.name = "Orange Juice"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/juice.mdl"
ITEM.uniqueID = "drink_orangejuice"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Orange juice. No pulp, you picky fuckers."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()