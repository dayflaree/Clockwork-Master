local ITEM = Clockwork.item:New()
ITEM.name = "BLT Burger"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/burgergtasa.mdl"
ITEM.uniqueID = "burger_burger2"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Burger"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "A tasty meaty burger with lettuce and tomato.."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()