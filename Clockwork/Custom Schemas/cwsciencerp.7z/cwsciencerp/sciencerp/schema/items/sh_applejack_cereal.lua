local ITEM = Clockwork.item:New()
ITEM.name = "Apple Jack Cereal"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/applejacks.mdl"
ITEM.uniqueID = "applejack_cereal"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Cereal"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "The tasty Apple Jack Cereal. Perfect for Breakfast, or that lazy lunch!"


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()