local ITEM = Clockwork.item:New()
ITEM.name = "Blox"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/blox.mdl"
ITEM.uniqueID = "cleaner_blox"
ITEM.weight = 1
ITEM.useText = "Use"
ITEM.category = "Cleaner"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "The great all emcompassing cleaner."


function ITEM:OnUse(player, itemEntity)
	Clockwork.player:Notify(player, "The cleaner is used. It does nothing. As if it hasn't been coded yet. Sorry about that :(")
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()