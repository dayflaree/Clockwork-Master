local ITEM = Clockwork.item:New()
ITEM.name = "Apple Juice"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/juicesmall.mdl"
ITEM.uniqueID = "drink_applejuice"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Apple juice. Not much else to see."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()