local ITEM = Clockwork.item:New()
ITEM.name = "Doritos"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/chipsdoritos.mdl"
ITEM.uniqueID = "chips_doritos"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Chips"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Want some mountain dew with those doritos."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()