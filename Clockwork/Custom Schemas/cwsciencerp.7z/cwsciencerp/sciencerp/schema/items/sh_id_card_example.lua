--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base")
	ITEM.name = "Example ID Card" -- What is the name of this item?
	ITEM.cost = 0; -- How much does this item cost?
	ITEM.model = "models/props_citizen_tech/firetrap_button01a.mdl"; -- What is the model of this item?
	ITEM.weight = 1; -- What is the weight of the item in KG.
	ITEM.access = "A"; -- What flags are required to purchase this item (remove the line to not require flags).
	ITEM.uniqueID = "id_card"; -- This needs to be unique (remove the line to have a unique ID generated).
	ITEM.business = true; -- Is this item available for purchase at all?
	ITEM.description = "An example ID Card."; -- A short description of the item.
ITEM:Register();