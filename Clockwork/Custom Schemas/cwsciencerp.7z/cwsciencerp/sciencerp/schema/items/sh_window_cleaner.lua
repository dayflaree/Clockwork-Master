local ITEM = Clockwork.item:New()
ITEM.name = "Window Cleaner"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/windowcleaner.mdl"
ITEM.uniqueID = "cleaner_window"
ITEM.weight = 1
ITEM.useText = "Use"
ITEM.access = "j"
ITEM.category = "Cleaner"
ITEM.business = true
ITEM.description = "Great Window Cleaner."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()