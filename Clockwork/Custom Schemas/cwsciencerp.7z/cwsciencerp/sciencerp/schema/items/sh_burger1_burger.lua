local ITEM = Clockwork.item:New()
ITEM.name = "Burger"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/burgergtaiv.mdl"
ITEM.uniqueID = "drink_sprunklight"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Burger"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "A tasty meaty burger."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()