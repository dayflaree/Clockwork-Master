local ITEM = Clockwork.item:New()
ITEM.name = "Handheld Radio"
ITEM.cost = 20
ITEM.model = "models/deadbodies/dead_male_civilian_radio.mdl"
ITEM.weight = 1
ITEM.access = "j"
ITEM.category = "Communication"
ITEM.UniqueID = "radio"
ITEM.business = true
ITEM.description = "A shiny handheld radio with a frequency tuner."


ITEM:Register();