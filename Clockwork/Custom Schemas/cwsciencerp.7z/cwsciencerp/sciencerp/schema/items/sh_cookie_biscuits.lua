local ITEM = Clockwork.item:New()
ITEM.name = "Cookies"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/cookies.mdl"
ITEM.uniqueID = "biscuit_cookies"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Biscuit"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "Who doesn't love a plate of cookies."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()