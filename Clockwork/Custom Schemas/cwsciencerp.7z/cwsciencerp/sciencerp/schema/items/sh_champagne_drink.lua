local ITEM = Clockwork.item:New("alcohol_base")
ITEM.name = "Champagne"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/champagne.mdl"
ITEM.uniqueID = "drink_champagne"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.category = "Drinks"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "A high class alchoholic drink. Costs more than most people make in their lifetime."

ITEM:Register()