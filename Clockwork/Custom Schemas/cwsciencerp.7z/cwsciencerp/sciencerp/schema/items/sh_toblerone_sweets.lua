local ITEM = Clockwork.item:New()
ITEM.name = "Toblerone"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/toblerone.mdl"
ITEM.uniqueID = "sweets_toblerone"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Sweets"
ITEM.access = "j"
ITEM.business = true
ITEM.description = "Triange chocolate bar."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()