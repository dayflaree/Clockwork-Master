local ITEM = Clockwork.item:New()
ITEM.name = "Newspaper"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/newspaper1.mdl"
ITEM.uniqueID = "literature_newspaper"
ITEM.weight = 1
ITEM.useText = "Read"
ITEM.category = "Literature"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Catch up on daily events."


function ITEM:OnUse(player, itemEntity)
	Clockwork.player:Notify(player, newspaper)
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()