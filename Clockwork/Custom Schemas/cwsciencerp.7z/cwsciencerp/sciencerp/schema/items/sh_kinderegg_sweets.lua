local ITEM = Clockwork.item:New()
ITEM.name = "Kinder Egg"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/kindersurprise2.mdl"
ITEM.uniqueID = "sweets_kinderegg"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Sweets"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Kinder Egg. Sweet chocolate with a suprise in the middle."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()