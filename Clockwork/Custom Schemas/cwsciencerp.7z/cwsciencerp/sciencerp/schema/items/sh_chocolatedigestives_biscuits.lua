local ITEM = Clockwork.item:New()
ITEM.name = "Chocolate Digestives"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/digestive.mdl"
ITEM.uniqueID = "biscuit_chocolatedigestives"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.access = "j"
ITEM.category = "Biscuit"
ITEM.business = true
ITEM.description = "Nothing is wrong with something smothered in chocolate."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()