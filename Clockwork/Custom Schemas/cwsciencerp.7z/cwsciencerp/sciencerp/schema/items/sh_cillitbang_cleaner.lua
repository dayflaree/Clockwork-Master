local ITEM = Clockwork.item:New()
ITEM.name = "Cillit Bang"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/cillitbang.mdl"
ITEM.uniqueID = "cleaner_cillitbang"
ITEM.weight = 1
ITEM.useText = "Use"
ITEM.category = "Cleaner"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "Bang & the dirt is gone."


function ITEM:OnUse(player, itemEntity)
	Clockwork.player:Notify(player, "The cleaner is used. It does nothing. As if it hasn't been coded yet. Sorry about that :(")
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()