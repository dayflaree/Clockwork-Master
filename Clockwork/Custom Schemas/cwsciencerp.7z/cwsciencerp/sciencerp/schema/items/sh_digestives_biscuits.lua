local ITEM = Clockwork.item:New()
ITEM.name = "Digestives"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/digestive2.mdl"
ITEM.uniqueID = "biscuit_digestives"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Biscuit"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "These always suprised me at how good they tastes.."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()