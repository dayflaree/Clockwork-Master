local ITEM = Clockwork.item:New()
ITEM.name = "Cola Bottle 500ml"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/colabig.mdl"
ITEM.uniqueID = "drink_colabottlebig"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.access = "j"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.description = "A good old fashion cola soft drink. Except bigger."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()