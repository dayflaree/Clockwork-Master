local ITEM = Clockwork.item:New()
ITEM.name = "Example Food"
ITEM.cost = 0
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"
ITEM.uniqueID = "example_food"
ITEM.weight = 0.8
ITEM.useText = "Eat"
ITEM.category = "Consumables"
ITEM.business = true
ITEM.description = "An example food item, used for development purposes."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()