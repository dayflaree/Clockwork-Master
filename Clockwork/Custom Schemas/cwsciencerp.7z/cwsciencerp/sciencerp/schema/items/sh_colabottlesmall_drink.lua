local ITEM = Clockwork.item:New()
ITEM.name = "Cola Bottle 250ml"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/cola.mdl"
ITEM.uniqueID = "drink_colabottle"
ITEM.weight = 1
ITEM.useText = "Drink"
ITEM.access = "j"
ITEM.category = "Drinks"
ITEM.business = true
ITEM.description = "A good old fashion cola soft drink."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()