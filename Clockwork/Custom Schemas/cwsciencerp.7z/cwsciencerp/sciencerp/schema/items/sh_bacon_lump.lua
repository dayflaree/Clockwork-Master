local ITEM = Clockwork.item:New()
ITEM.name = "Lump Of Bacon"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/bacon_2.mdl"
ITEM.uniqueID = "lump_bacon"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.category = "Bacon"
ITEM.business = true
ITEM.access = "j"
ITEM.description = "A lovely lump of bacon."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() - 10, 0, player:GetMaxHealth()))
	Clockwork.player:Notify(player, "You have just eaten uncooked meat!")
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()