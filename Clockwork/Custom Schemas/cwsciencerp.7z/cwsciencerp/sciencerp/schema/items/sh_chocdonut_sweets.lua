local ITEM = Clockwork.item:New()
ITEM.name = "Chocolate Donut"
ITEM.cost = 0
ITEM.model = "models/foodnhouseholditems/donut.mdl"
ITEM.uniqueID = "sweets_chocdonut"
ITEM.weight = 1
ITEM.useText = "Eat"
ITEM.access = "j"
ITEM.category = "Sweets"
ITEM.business = true
ITEM.description = "Circular object with a hole in the middle. Smothered in chocolate. Result."


function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 10, 0, player:GetMaxHealth()))
	
end

function ITEM:OnDrop(player, position) 
end

ITEM:Register()