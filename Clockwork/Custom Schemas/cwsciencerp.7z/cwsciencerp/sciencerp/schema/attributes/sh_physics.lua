local ATTRIBUTE = Clockwork.attribute:New("Physics");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "phys"
	ATTRIBUTE.description = "Experience in the field of Physics"
	ATTRIBUTE.isOnCharScreen = false
ATB_PHYSICS = ATTRIBUTE:Register()