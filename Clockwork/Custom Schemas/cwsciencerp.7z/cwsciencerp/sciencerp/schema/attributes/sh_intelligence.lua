local ATTRIBUTE = Clockwork.attribute:New("Intelligence");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "str"
	ATTRIBUTE.description = "How smart/clever a person is."
	ATTRIBUTE.isOnCharScreen = true
ATB_INTELLIGENCE = ATTRIBUTE:Register()