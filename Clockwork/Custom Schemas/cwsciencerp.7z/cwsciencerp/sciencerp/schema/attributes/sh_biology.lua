local ATTRIBUTE = Clockwork.attribute:New("Biology");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "bio"
	ATTRIBUTE.description = "Experience in the field of Biology"
	ATTRIBUTE.isOnCharScreen = false
ATB_BIOLOGY = ATTRIBUTE:Register()