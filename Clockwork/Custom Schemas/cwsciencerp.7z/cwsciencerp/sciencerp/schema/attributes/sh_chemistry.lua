local ATTRIBUTE = Clockwork.attribute:New("Chemistry");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "chem"
	ATTRIBUTE.description = "Experience in the field of Chemistry"
	ATTRIBUTE.isOnCharScreen = false
ATB_CHEMISTRY = ATTRIBUTE:Register()