local ATTRIBUTE = Clockwork.attribute:New("Ecology");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "eco"
	ATTRIBUTE.description = "Experience in the field of Ecology"
	ATTRIBUTE.isOnCharScreen = false
ATB_ECOLOGY = ATTRIBUTE:Register()