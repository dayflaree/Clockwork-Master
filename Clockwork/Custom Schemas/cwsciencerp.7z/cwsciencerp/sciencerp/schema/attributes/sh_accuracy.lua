local ATTRIBUTE = Clockwork.attribute:New("Accuracy");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "acc"
	ATTRIBUTE.description = "How accurate someone is when shooting."
	ATTRIBUTE.isOnCharScreen = false
ATB_ACCURACY = ATTRIBUTE:Register()