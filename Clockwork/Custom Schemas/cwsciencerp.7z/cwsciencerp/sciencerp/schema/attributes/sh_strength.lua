local ATTRIBUTE = Clockwork.attribute:New("Strength");
	ATTRIBUTE.maximum = 100
	ATTRIBUTE.uniqueID = "str"
	ATTRIBUTE.description = "How strong someone is."
	ATTRIBUTE.isOnCharScreen = true
ATB_STRENGTH = ATTRIBUTE:Register()