DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "Connall Lindsay"
ENT.PrintName = "Microwave"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false