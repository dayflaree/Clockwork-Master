DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Author = "Connall Lindsay"
ENT.PrintName = "Basic Research Terminal"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.UsableInVehicle = false
ENT.PhysgunDisabled = false