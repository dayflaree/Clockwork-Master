
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
 
include('shared.lua')

function ENT:SpawnFunction(player, trace)

	local ent = ents.Create("sr_cooker")
	ent:SetPos(trace.HitPos + Vector(0, 0, 50))
	ent:Spawn()
	entity = ent
	return ent
end
  
function ENT:Initialize()
 
	self:SetModel("models/props_c17/furnitureStove001a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS) 
	self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end
 
function ENT:Use(activator, caller)
	local cookercheck = self:GetNetworkedBool("CookerOn")

	if (self:GetNetworkedBool("CookerOn") == true) then
		self:SetNetworkedBool("CookerOn", false)
	else
		self:SetNetworkedBool("CookerOn", true)
	end
end
 
function ENT:Think()
end

function ENT:Touch(entity)
	local spawnpos = entity:GetPos()
	local model = entity:GetModel()
	local food = IdentifyFood(model)
	local itemTable = Clockwork.item:FindByID(food)
	Clockwork.cooking = CreateSound(entity, "ambient/fire/fire_small_loop2.wav")

	local CookerInUse = 0
	local EmitterInUse = 0
	local sound = 0
	local Burn = 0

	--[[if (sound == 0 && Burn == 1) then
		sound = 1
		timer.Simple(10, function()
			if (entity:IsValid()) then
				entity:Ignite(2)
				timer.Simple(2, function()
					entity:Remove()
					sound = 0
					Burn = 0
				end)
			end
			Clockwork.cooking:Stop()
		end)
	end
	Taken out since an effective way to detect entity is still on cooker has not been found.]]-- 

	if (itemTable != nil && CookerInUse == 0) then
		Clockwork.cooking:PlayEx(0.75, 100)
		CookerInUse = 1
		--Cooker_Em(entity) Defunct for now.
		timer.Simple(5, function()
			CookerInUse = 0
			entity:Remove()
			Clockwork.entity:CreateItem(player, itemTable, spawnpos)
			Clockwork.cooking:Stop()
		end)
	end
end

function IdentifyFood(model)
	foodtable = {}
	foodtable["models/foodnhouseholditems/bacon.mdl"] = "cooked_bacon"

	for k, v in pairs(foodtable) do
		if k == model then
			return v
		end
	end
end

function Cooker_Em(entity)
	local position = entity:GetPos()
	local em = ParticleEmitter(position)
	local smoke = em:Add("particle/smokesprites_0001", position)

	smoke:SetColor(255,255,255,math.random(255))
    smoke:SetVelocity(Vector(math.random(-1,1),math.random(-1,1),math.random(-1,1)):GetNormal() * 20)
    smoke:SetDieTime(0.5)
    smoke:SetLifeTime(0)
    smoke:SetStartSize(10)
    smoke:SetEndSize(0)
    timer.Simple(5, function()
    	em:Finish()
    end)
end

function ENT:PhysicsCollide(colData, collider)
end