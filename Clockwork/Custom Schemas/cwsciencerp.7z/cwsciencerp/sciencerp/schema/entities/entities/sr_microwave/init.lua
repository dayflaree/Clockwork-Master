
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
 
include('shared.lua')
local microwavecounter = 0
local entity = nil

function ENT:SpawnFunction(player, trace)

	local ent = ents.Create("sr_microwave")
	ent:SetPos(trace.HitPos + Vector(0, 0, 50))
	ent:Spawn()
	entity = ent
	return ent
end
  
function ENT:Initialize()
 
	self:SetModel("models/props/cs_office/microwave.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS) 
	self:SetSolid(SOLID_VPHYSICS)
	self:SetNetworkedBool("InUse", false)
 
    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end
 
function ENT:Use(activator, caller)
	player = activator
	if (!activator:IsPlayer()) then 
		return 
	end
	if microwavecounter == 0 then
		data = {activator, entity}
		Clockwork.datastream:Start(activator, "MicrowaveMenu", data)
		microwavecounter = 1
		timer.Simple(0.2, function()
			microwavecounter = 0
		end)
	else
		return
	end
end
 
function ENT:Think()
end