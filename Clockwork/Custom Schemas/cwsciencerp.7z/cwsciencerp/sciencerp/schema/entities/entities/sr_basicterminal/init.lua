
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
 
include('shared.lua')

local basicterminalcounter = 0
local poweron = false
local counter = 0

function ENT:SpawnFunction(player, trace)

	local ent = ents.Create("sr_basicterminal")
	ent:SetPos(trace.HitPos + Vector(0, 0, 50))
	ent:Spawn()
	entity = ent
	return ent
end
  
function ENT:Initialize()

	self:SetModel("models/props_lab/monitor02.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS) 
	self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end
 
function ENT:Use(activator, caller)
	if basicterminalcounter == 0 then
		basicterminalcounter = 1
			if poweron == true then
				poweron = false
			else
				poweron = true
			end
		timer.Simple(1, function()
			basicterminalcounter = 0
		end)
	end
end
 
function ENT:Think()
	MsgN(counter)
end

function ENT:Touch(entity)
end

function ENT:PhysicsCollide(colData, collider)
end