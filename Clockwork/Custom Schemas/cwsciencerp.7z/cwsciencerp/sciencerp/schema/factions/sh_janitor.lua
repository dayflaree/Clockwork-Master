
local FACTION = Clockwork.faction:New("Janitor")
	
FACTION.whitelist = false
FACTION.useFullName = true
FACTION.material = "sciencestationrp/janitor"
FACTION.models = {
	female = {
		"models/Humans/Group01/Female_01.mdl",
		"models/Humans/Group01/Female_02.mdl",
		"models/Humans/Group01/Female_03.mdl",
		"models/Humans/Group01/Female_04.mdl",
		"models/Humans/Group01/Female_06.mdl",
		"models/Humans/Group01/Female_07.mdl",
		"models/Humans/Group02/Female_03.mdl",
		"models/Humans/Group01/Female_01.mdl",
		"models/Humans/Group01/Female_01.mdl"
	},
	male = {
		"models/Humans/Group01/Male_01.mdl",
		"models/Humans/Group01/Male_02.mdl",
		"models/Humans/Group01/Male_03.mdl",
		"models/Humans/Group01/Male_04.mdl",
		"models/Humans/Group01/Male_05.mdl",
		"models/Humans/Group01/Male_06.mdl",
		"models/Humans/Group01/Male_07.mdl",
		"models/Humans/Group01/Male_08.mdl",
		"models/Humans/Group01/Male_09.mdl"	
	}
}

FACTION_JANITOR = FACTION:Register()