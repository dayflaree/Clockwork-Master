
local FACTION = Clockwork.faction:New("FBI")
	
FACTION.whitelist = true
FACTION.useFullName = true
FACTION.material = "sciencestationrp/fbi"
FACTION.models = {
	female = {
		"models/fbifem_01.mdl"
	},
	male = {
		"models/fbi0.mdl",
		"models/fbim_01.mdl",
		"models/fbim_02.mdl",
		"models/fbi_pack/fbi_01.mdl",
		"models/fbi_pack/fbi_02.mdl",
		"models/fbi_pack/fbi_03.mdl",
		"models/fbi_pack/fbi_04.mdl",
		"models/fbi_pack/fbi_05.mdl",
		"models/fbi_pack/fbi_06.mdl",
		"models/fbi_pack/fbi_07.mdl",
		"models/fbi_pack/fbi_08.mdl",
		"models/fbi_pack/fbi_09.mdl"
	}
}

FACTION_FBI = FACTION:Register()