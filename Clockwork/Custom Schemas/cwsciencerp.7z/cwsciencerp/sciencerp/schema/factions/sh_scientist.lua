
local FACTION = Clockwork.faction:New("Scientist")
	
FACTION.whitelist = false
FACTION.useFullName = true
FACTION.material = "sciencestationrp/scientist"
FACTION.models = {
	female = {
		"models/humans/group01/scrubfe1a.mdl",
		"models/humans/group01/scrubfe1b.mdl",
		"models/humans/group01/scrubfe1c.mdl",
		"models/humans/group01/scrubfe1d.mdl",
		"models/humans/group01/scrubfe1e.mdl"
	},
	male = {
		"models/humans/scien01/male_01.mdl",
		"models/humans/scien01/male_02.mdl",
		"models/humans/scien01/male_03.mdl",
		"models/humans/scien01/male_04.mdl",
		"models/humans/scien01/male_05.mdl",
		"models/humans/scien01/male_06.mdl",
		"models/humans/scien01/male_07.mdl",
		"models/humans/scien01/male_08.mdl",
		"models/humans/scien01/male_09.mdl"			
	}
}

FACTION_SCIENTIST = FACTION:Register()