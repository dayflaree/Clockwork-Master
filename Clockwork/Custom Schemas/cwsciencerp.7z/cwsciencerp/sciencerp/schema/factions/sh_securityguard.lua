
local FACTION = Clockwork.faction:New("Security Guard")
	
FACTION.whitelist = false
FACTION.useFullName = true
FACTION.material = "sciencestationrp/securityguard"
FACTION.models = {
	female = {
		"models/pmc/pmc_4/pmc__02.mdl",
		"models/pmc/pmc_4/pmc__03.mdl",
		"models/pmc/pmc_4/pmc__04.mdl",	
		"models/pmc/pmc_4/pmc__05.mdl",	
		"models/pmc/pmc_4/pmc__06.mdl",	
		"models/pmc/pmc_4/pmc__07.mdl",	
		"models/pmc/pmc_4/pmc__08.mdl",	
		"models/pmc/pmc_4/pmc__09.mdl",	
		"models/pmc/pmc_4/pmc__10.mdl",	
		"models/pmc/pmc_4/pmc__11.mdl",	
		"models/pmc/pmc_4/pmc__12.mdl",	
		"models/pmc/pmc_4/pmc__13.mdl",	
		"models/pmc/pmc_4/pmc__14.mdl"
	},
	male = {
		"models/pmc/pmc_4/pmc__02.mdl",
		"models/pmc/pmc_4/pmc__03.mdl",
		"models/pmc/pmc_4/pmc__04.mdl",	
		"models/pmc/pmc_4/pmc__05.mdl",	
		"models/pmc/pmc_4/pmc__06.mdl",	
		"models/pmc/pmc_4/pmc__07.mdl",	
		"models/pmc/pmc_4/pmc__08.mdl",	
		"models/pmc/pmc_4/pmc__09.mdl",	
		"models/pmc/pmc_4/pmc__10.mdl",	
		"models/pmc/pmc_4/pmc__11.mdl",	
		"models/pmc/pmc_4/pmc__12.mdl",	
		"models/pmc/pmc_4/pmc__13.mdl",	
		"models/pmc/pmc_4/pmc__14.mdl"		
	}
}

FACTION_SECGUARD = FACTION:Register()