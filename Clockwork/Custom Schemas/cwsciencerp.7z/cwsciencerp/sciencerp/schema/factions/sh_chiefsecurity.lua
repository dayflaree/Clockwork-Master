
local FACTION = Clockwork.faction:New("Chief Of Security")
	
FACTION.whitelist = true
FACTION.useFullName = true
FACTION.material = "sciencestationrp/chiefsecurity"
FACTION.models = {
	female = {
		"models/pmc/pmc_4/pmc__03.mdl"
	},
	male = {
		"models/pmc/pmc_4/pmc__01.mdl"
	}
}

FACTION_CHIEFSEC = FACTION:Register()