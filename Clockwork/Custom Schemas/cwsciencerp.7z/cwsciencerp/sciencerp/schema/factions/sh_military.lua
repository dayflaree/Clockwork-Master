
local FACTION = Clockwork.faction:New("Military")
	
FACTION.whitelist = true
FACTION.useFullName = true
FACTION.material = "sciencestationrp/military"
FACTION.models = {
	female = {
		"models/pmc/pmc_1/pmc__02.mdl",
		"models/pmc/pmc_1/pmc__03.mdl",
		"models/pmc/pmc_1/pmc__04.mdl",	
		"models/pmc/pmc_1/pmc__05.mdl",	
		"models/pmc/pmc_1/pmc__06.mdl",	
		"models/pmc/pmc_1/pmc__07.mdl",	
		"models/pmc/pmc_1/pmc__08.mdl",	
		"models/pmc/pmc_1/pmc__09.mdl",	
		"models/pmc/pmc_1/pmc__10.mdl",	
		"models/pmc/pmc_1/pmc__11.mdl",	
		"models/pmc/pmc_1/pmc__12.mdl",	
		"models/pmc/pmc_1/pmc__13.mdl",	
		"models/pmc/pmc_1/pmc__14.mdl"
	},
	male = {
		"models/pmc/pmc_1/pmc__02.mdl",
		"models/pmc/pmc_1/pmc__03.mdl",
		"models/pmc/pmc_1/pmc__04.mdl",	
		"models/pmc/pmc_1/pmc__05.mdl",	
		"models/pmc/pmc_1/pmc__06.mdl",	
		"models/pmc/pmc_1/pmc__07.mdl",	
		"models/pmc/pmc_1/pmc__08.mdl",	
		"models/pmc/pmc_1/pmc__09.mdl",	
		"models/pmc/pmc_1/pmc__10.mdl",	
		"models/pmc/pmc_1/pmc__11.mdl",	
		"models/pmc/pmc_1/pmc__12.mdl",	
		"models/pmc/pmc_1/pmc__13.mdl",	
		"models/pmc/pmc_1/pmc__14.mdl"		
	}
}


FACTION_MILITARY = FACTION:Register()