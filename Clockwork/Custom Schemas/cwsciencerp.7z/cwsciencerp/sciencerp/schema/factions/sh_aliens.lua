
local FACTION = Clockwork.faction:New("Alien")
	
FACTION.whitelist = true
FACTION.useFullName = true
FACTION.material = "sciencestationrp/alien"
FACTION.models = {
	female = {
		"models/vortigaunt.mdl",
		"models/AntLion.mdl",
		"models/headcrabclassic.mdl",
		"models/headcrabblack.mdl",
		"models/headcrab.mdl"	
	},
	male = {
		"models/vortigaunt.mdl",
		"models/AntLion.mdl",
		"models/headcrabclassic.mdl",
		"models/headcrabblack.mdl",
		"models/headcrab.mdl"	
	}
}

FACTION_ALIEN = FACTION:Register()