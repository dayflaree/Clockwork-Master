function Schema:PrintConsole(text)
	MsgC(text, Color(255, 0, 0, 255));
end

function Schema:RequestForm()
	
end

function Schema:RecieveMessageScienceTeam(name, text)
	Clockwork.chatBox:Add(nil, nil, Color(24, 88, 227, 255), "**"..name.."** Message To Science Team: "..text)
end

function Schema:RecieveMessageSecurityTeam(name, text)
	Clockwork.chatBox:Add(nil, nil, Color(24, 88, 227, 255), "**"..name.."** Message To Security Team: "..text)
end

function Schema:RecieveMessageAdmin(name, text)
	Clockwork.chatBox:Add(nil, nil, Color(24, 88, 227, 255), "**"..name.."** Message To Administrator: "..text)
end

function Schema:RecieveMessageJanitor(name, text)
	Clockwork.chatBox:Add(nil, nil, Color(24, 88, 227, 255), "**"..name.."** Message To Janitors: "..text)
end

function Schema:RecieveMessageCook(name, text)
	Clockwork.chatBox:Add(nil, nil, Color(24, 88, 227, 255), "**"..name.."** Message To Cooks: "..text)
end

function Schema:PlayerReport(name, text)
	Clockwork.chatbox:Add(nil, nil, Color(31, 38, 108, 255), "**[REPORT]** "..name..": "..text)
end

Clockwork.chatBox:RegisterClass("messagesecurity", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." messages security team \""..info.text.."\"")
end)

Clockwork.chatBox:RegisterClass("messagescience", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." messages science team \""..info.text.."\"")
end)

Clockwork.chatBox:RegisterClass("messageadministrator", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." messages administrator \""..info.text.."\"")
end)

Clockwork.chatBox:RegisterClass("messagejanitor", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." messages janitor team \""..info.text.."\"")
end)

Clockwork.chatBox:RegisterClass("messagecook", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." messages cooks \""..info.text.."\"")
end)

Clockwork.chatBox:RegisterClass("recievemessage", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(24, 88, 227, 255), info.text)
end)

Clockwork.chatBox:RegisterClass("companyannouncement", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(150, 125, 175, 255), info.text)
end)

Clockwork.chatBox:RegisterClass("radiomessage", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.text)
end)

Clockwork.datastream:Hook("RecieveMsgScience", function(data)
	local name = data[1]
	local text = data[2]
	Schema:RecieveMessageScienceTeam(name, text)
end)

Clockwork.datastream:Hook("RecieveMsgSecurity", function(data)
	local name = data[1]
	local text = data[2]
	Schema:RecieveMessageSecurityTeam(name, text)
end)

Clockwork.datastream:Hook("RecieveMsgAdmin", function(data)
	local name = data[1]
	local text = data[2]
	Schema:RecieveMessageAdmin(name, text)
end)

Clockwork.datastream:Hook("RecieveMsgJanitor", function(data)
	local name = data[1]
	local text = data[2]
	Schema:RecieveMessageJanitor(name, text)
end)

Clockwork.datastream:Hook("RecieveMsgCook", function(data)
	local name = data[1]
	local text = data[2]
	Schema:RecieveMessageCook(name, text)
end)

Clockwork.datastream:Hook("Report", function(data)
	local name = data[1]
	local text = data[2]
	Schema:PlayerReport(name, text)
end)