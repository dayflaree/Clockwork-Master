-- Called when the Clockwork shared variables are added.
function Schema:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("ExampleNumber", true) -- The true means client only, not networked to everybody.
	playerVars:String("ExampleString")
end

function Schema:PlayerCharacterLoaded(player)
	local firstConnect = player:GetSharedVar("FirstTimeConnection")

	if firstConnect == nil then
		Clockwork.player:Notify(player, "This your first time playing? Type /tutorial in chat to learn about the gamemode.")
		player:SetSharedVar("FirstTimeConnection", true)
	end
	
end