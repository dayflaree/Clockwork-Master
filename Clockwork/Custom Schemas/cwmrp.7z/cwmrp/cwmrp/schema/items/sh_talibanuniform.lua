--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.cost = 0;
	ITEM.name = "Taliban Uniform";
	ITEM.weight = 1.5;
	ITEM.replacement = "models/pmc/pmc_4/pmc__02.mdl";
	ITEM.description = "Some leather armor.";
Clockwork.item:Register(ITEM);