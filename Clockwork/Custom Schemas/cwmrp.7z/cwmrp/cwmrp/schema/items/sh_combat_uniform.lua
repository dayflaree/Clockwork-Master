--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.cost = 150;
	ITEM.name = "Leather Armor";
	ITEM.group = "group03";
	ITEM.weight = 1;
	ITEM.description = "Some yellow armor manufactured and worn in the wasteland.";
Clockwork.item:Register(ITEM);