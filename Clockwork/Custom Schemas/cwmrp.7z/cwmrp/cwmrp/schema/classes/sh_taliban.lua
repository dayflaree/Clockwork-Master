--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Taliban");
	CLASS.color = Color(255, 97, 0, 255);
	CLASS.factions = {FACTION_TALIBAN};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.description = "A terrorist.";
	CLASS.defaultPhysDesc = "Wearing average clothes.";
CLASS_TALIBAN = CLASS:Register();