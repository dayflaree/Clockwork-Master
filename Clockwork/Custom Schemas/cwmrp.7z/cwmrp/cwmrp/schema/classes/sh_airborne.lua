--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("11th Airborne Division");
	CLASS.color = Color(63, 127, 0, 255);
	CLASS.factions = {FACTION_AIRBORNE};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.wages = 250;
	CLASS.description = "Airborn Company.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_AIRBORNE = CLASS:Register();