--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("21st Reconnaissance Detachment");
	CLASS.color = Color(63, 127, 0, 255);
	CLASS.factions = {FACTION_RECON};
	CLASS.isDefault = true;
	CLASS.wages = 35;
	CLASS.wagesName = "Pay Check";
	CLASS.description = "A soldier of the Sapphire platoon.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_RECON = CLASS:Register();