--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Drill Instructor");
	CLASS.color = Color(131, 0, 255, 255);
	CLASS.factions = {FACTION_DRILLINSTRUCTOR};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.description = "A drill instructor of the military.";
	CLASS.wages = 25;
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_DRILLINSTRUCTOR = CLASS:Register();