--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("309th Medical Detachment");
	CLASS.color = Color(63, 127, 0, 255);
	CLASS.factions = {FACTION_MEDICAL};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.wages = 50;
	CLASS.description = "A soldier in the medical detachment.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_MEDICAL = CLASS:Register();