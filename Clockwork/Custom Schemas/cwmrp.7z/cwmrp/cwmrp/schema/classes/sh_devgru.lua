--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Naval Special Warfare Development Group");
	CLASS.color = Color(127, 0, 255, 255);
	CLASS.factions = {FACTION_DEVGRU};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.wages = 100;
	CLASS.description = "A regular deployed DEVGRU soldier..";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_DEVGRU = CLASS:Register();