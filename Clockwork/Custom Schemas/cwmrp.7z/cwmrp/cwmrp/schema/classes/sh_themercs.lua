--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("The Mercs");
	CLASS.color = Color(150, 125, 100, 255);
	CLASS.factions = {FACTION_THEMERCS};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.description = "A member of the mercs.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_THEMERCS = CLASS:Register();