--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("27th Armored Division");
	CLASS.color = Color(63, 127, 0, 255);
	CLASS.factions = {FACTION_ARMORED};
	CLASS.isDefault = true;
	CLASS.wagesName = "Pay Check";
	CLASS.wages = 100;
	CLASS.description = "A regular deployed server.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_ARMORED = CLASS:Register();