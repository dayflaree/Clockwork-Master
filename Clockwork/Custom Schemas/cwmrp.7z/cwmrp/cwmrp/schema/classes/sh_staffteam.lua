--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Staff Team");
	CLASS.color = Color(255, 0, 0, 255);
	CLASS.factions = {FACTION_STAFF};
	CLASS.isDefault = false;
	CLASS.wagesName = "Staff Check";
	CLASS.wages = 5000;
	CLASS.description = "A regular deployed server.";
	CLASS.defaultPhysDesc = "Wearing an arm band with his or hers rank on it.";
CLASS_STAFF = CLASS:Register();