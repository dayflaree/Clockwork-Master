--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "SAS VAL";
	ITEM.cost = 1600;
	ITEM.model = "models/weapons/w_dmg_vally.mdl";
	ITEM.weight = 2;
	ITEM.business = false;
	ITEM.uniqueID = "m9k_val";
	ITEM.description = "A grey rifle with a silencer on the end.";
	ITEM.isAttachment = false;
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();