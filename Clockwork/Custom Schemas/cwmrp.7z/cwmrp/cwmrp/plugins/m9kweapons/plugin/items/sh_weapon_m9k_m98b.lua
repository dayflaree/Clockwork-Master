--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "M98B Sniper";
	ITEM.cost = 1600;
	ITEM.model = "models/weapons/w_barrett_m98b.mdl";
	ITEM.weight = 2;
	ITEM.business = false;
	ITEM.uniqueID = "m9k_m98b";
	ITEM.description = "A Sniper.";
	ITEM.isAttachment = false;
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();