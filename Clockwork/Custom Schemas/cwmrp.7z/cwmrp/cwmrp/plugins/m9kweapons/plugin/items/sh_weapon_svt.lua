--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("weapon_base");
        ITEM.name = "SVT 40";
        ITEM.cost = 1200;
        ITEM.model = "models/weapons/w_svt_40.mdl";
        ITEM.weight = 2.4;
        ITEM.business = false;
        ITEM.uniqueID = "m9k_svt40";
        ITEM.description = "A battle rifle with a scope on the top, it looks old.";
        ITEM.isAttachment = false;
        ITEM.hasFlashlight = false;
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();