--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("weapon_base");
        ITEM.name = "FG42";
        ITEM.cost = 1400;
        ITEM.model = "models/weapons/w_fg42.mdl";
        ITEM.weight = 2.2;
        ITEM.business = false;
        ITEM.uniqueID = "m9k_fg42";
        ITEM.description = "A machine gun developed in germany for use in world war two, it's wood and metal.";
        ITEM.isAttachment = false;
        ITEM.hasFlashlight = false;
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();