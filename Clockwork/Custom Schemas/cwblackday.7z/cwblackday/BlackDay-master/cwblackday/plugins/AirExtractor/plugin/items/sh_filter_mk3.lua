--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local ITEM = Clockwork.item:New("air_filter_base");
	ITEM.name = "Special Union Air Filter";
	ITEM.weight = 0.1;
	ITEM.access = "G";
	ITEM.charge = 500;
ITEM:Register();