--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.config:AddToSystem("(ExT) Garbage - respawn time", "garbage_respawn_tick", "Garbage respawn time.");
Clockwork.config:AddToSystem("(ExT) Garbage - cleaning up time", "garbage_clean_time", "Garbage cleaning up time.");
Clockwork.config:AddToSystem("(ExT) Garbage - find rate", "garbage_rate", "Garbage find rate.");