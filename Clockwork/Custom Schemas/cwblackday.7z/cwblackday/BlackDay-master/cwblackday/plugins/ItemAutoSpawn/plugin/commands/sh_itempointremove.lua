--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("ItemAutoSpawnPointRemove");
COMMAND.tip = "Remove item spawns at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";


function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);
	local ItemSpawnList = 0;
	
	for k, v in pairs(PLUGIN.ItemSpawnList) do
		if (v.position:Distance(position) <= 256) then
			ItemSpawnList = ItemSpawnList + 1;	
			PLUGIN.ItemSpawnList[k] = nil;
		end;
	end
	
	if (ItemSpawnList > 0) then
		if (ItemSpawnList == 1) then
			Clockwork.player:Notify(player, "You have removed "..ItemSpawnList.." item spawn.");
		else
			Clockwork.player:Notify(player, "You have removed "..ItemSpawnList.." item spawns.");
		end;
	else
		Clockwork.player:Notify(player, "There were no item spawns near this position.");
	end;
	
	PLUGIN:SaveItemAutoSpawnPoints();
end;

COMMAND:Register();