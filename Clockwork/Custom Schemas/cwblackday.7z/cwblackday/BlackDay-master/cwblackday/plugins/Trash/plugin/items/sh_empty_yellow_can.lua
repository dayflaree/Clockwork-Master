--[[
	� 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author - TheGarry =D (cod7777@yandex.ru).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Yellow Can";
ITEM.cost = 0;
ITEM.model = "models/props_junk/popcan01a.mdl";
ITEM.skin = 2;
ITEM.weight = 0.2;
ITEM.access = "1";
ITEM.business = true;
ITEM.category = "Consumables";
ITEM.description = "A Yellow aluminium can, looks like it is empty.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();