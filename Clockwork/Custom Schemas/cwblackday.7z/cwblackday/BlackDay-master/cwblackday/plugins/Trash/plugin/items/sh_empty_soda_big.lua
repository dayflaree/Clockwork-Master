--[[
	� 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author - TheGarry =D (cod7777@yandex.ru).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Plastic Bottle";
ITEM.cost = 0;
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl";
ITEM.skin = 1;
ITEM.weight = 0.4;
ITEM.access = "1";
ITEM.business = true;
ITEM.category = "Consumables";
ITEM.description = "A large empty plastic bottle with few holes in it.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();