--[[
	� 2013 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author - TheGarry =D (cod7777@yandex.ru).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Ration Packet";
ITEM.cost = 0;
ITEM.model = "models/weapons/w_package.mdl";
ITEM.weight = 0.5;
ITEM.access = "1";
ITEM.business = true;
ITEM.category = "Consumables";
ITEM.description = "A Purple container, looks like there is nothing inside it.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();