PLUGIN = PLUGIN

Clockwork.config:AddToSystem("Health Commands", "health_commands", "Adds the awesome health commands of Connall");