--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.config:AddToSystem("(ExT) PermaDeath - Lifes", "permadeath_lifes", "Character amount of lifes.");
Clockwork.config:AddToSystem("(ExT) PermaDeath - Sucide", "permedeath_suicide", "In case of suicide, your character will be banned.");