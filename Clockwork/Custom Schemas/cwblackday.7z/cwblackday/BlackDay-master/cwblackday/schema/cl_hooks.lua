--[[
	© 2013 TeslaCloud Studios ltd. ( http://teslacloud.net )
	If you got this copy of my work, you might be REALLY cool.
	Please, do not edit or share this file. This will really hurt me.
--]]

-- Эпичное интро.
function Schema:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = "Black Day",
		text = "War will never end."
	};
end;

-- Если у игрока особый класс.
function Schema:GetPlayerScoreboardClass(player)
	local customClass = player:GetSharedVar("customClass");
	
	if (customClass != "") then
		return customClass;
	end;
end;

-- Особые классы.
function Schema:GetPlayerCharacterScreenFaction(character)
	if (character.customClass and character.customClass != "") then
		return character.customClass;
	end;
end;

-- Опции через TAB.
function Schema:GetPlayerScoreboardOptions(player, options, menu)
	if (Clockwork.command:FindByID("PlyAddServerWhitelist")
	or Clockwork.command:FindByID("PlyRemoveServerWhitelist")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("PlyAddServerWhitelist").access)) then
			options["Серверный вайтлист"] = {};
			
			if (Clockwork.command:FindByID("PlyAddServerWhitelist")) then
				options["Серверный вайтлист"]["Добавить"] = function()
					Derma_StringRequest(player:Name(), "В какой серверный вайтлист Вы хотите добавить?", "", function(text)
						Clockwork.kernel:RunCommand("PlyAddServerWhitelist", player:Name(), text);
					end);
				end;
			end;
			
			if (Clockwork.command:FindByID("PlyRemoveServerWhitelist")) then
				options["Серверный вайтлист"]["Убрать"] = function()
					Derma_StringRequest(player:Name(), "Из какого серверного вайтлиста убрать?", "", function(text)
						Clockwork.kernel:RunCommand("PlyRemoveServerWhitelist", player:Name(), text);
					end);
				end;
			end;
		end;
	end;
	
	if (Clockwork.command:FindByID("CharSetCustomClass")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharSetCustomClass").access)) then
			options["Свой класс"] = {};
			options["Свой класс"]["Выставить"] = function()
				Derma_StringRequest(player:Name(), "В какой особый класс вы хотите добавить?", player:GetSharedVar("customClass"), function(text)
					Clockwork.kernel:RunCommand("CharSetCustomClass", player:Name(), text);
				end);
			end;
			
			if (player:GetSharedVar("customClass") != "") then
				options["Свой класс"]["Забрать"] = function()
					Clockwork.kernel:RunCommand( "CharTakeCustomClass", player:Name() );
				end;
			end;
		end;
	end;
	
	-- Убить. Убить. Убить.
	if (Clockwork.command:FindByID("CharPermaKill")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharPermaKill").access)) then
			options["Убить"] = function()
				RunConsoleCommand( "aura", "CharPermaKill", player:Name() );
			end;
		end;
	end;
end;

-- Цвета экрана.
function Schema:PlayerSetDefaultColorModify(colorModify)
	colorModify["$pp_colour_contrast"] = 1;
	colorModify["$pp_colour_colour"] = 0.6;
end;

-- Звуки шагов.
function Schema:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	return true;
end;

-- Статус цели.
function Schema:DrawTargetPlayerStatus(target, alpha, x, y)
	local informationColor = Clockwork.option:GetColor("information");
	local thirdPerson = "его";
	local mainStatus;
	local untieText;
	local gender = "Он";
	local action = Clockwork.player:GetAction(target);
	
	if (target:GetGender() == GENDER_FEMALE) then
		thirdPerson = "ее";
		gender = "Она";
	end;
	
	if (target:Alive()) then
		if (action == "die") then
			mainStatus = gender.." присмерти.";
		end;
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." без сознания.";
		end;
		
		if (target:GetSharedVar("tied") != 0) then
			if (Clockwork.player:GetAction(Clockwork.Client) == "untie") then
				mainStatus = gender.. " развязывается.";
			else
				local untieText;
				
				if (target:GetShootPos():Distance( Clockwork.Client:GetShootPos() ) <= 192) then
					if (Clockwork.Client:GetSharedVar("tied") == 0) then
						mainStatus = "Нажмите :+use: чтобы развязать "..thirdPerson..".";
						
						untieText = true;
					end;
				end;
				
				if (!untieText) then
					mainStatus = gender.." связан.";
				end;
			end;
		elseif (Clockwork.player:GetAction(Clockwork.Client) == "tie") then
			mainStatus = gender.." связывается.";
		end;
		
		if (mainStatus) then
			y = Clockwork.kernel:DrawInfo(Clockwork.kernel:ParseData(mainStatus), x, y, informationColor, alpha);
		end;
		
		return y;
	end;
end;

-- Called to get the screen text info.
function Schema:GetScreenTextInfo()
	local blackFadeAlpha = Clockwork.kernel:GetBlackFadeAlpha();
	
	if (Clockwork.Client:GetSharedVar("permaKilled")) then
		return {
			alpha = blackFadeAlpha,
			title = "ЭТОТ ПЕРСОНАЖ УМЕР",
			text = "Вы можете создать нового через меню."
		};
	elseif (Clockwork.Client:GetSharedVar("beingTied")) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "ВАС СВЯЗЫВАЮТ"
		};
	elseif (Clockwork.Client:GetSharedVar("tied") != 0) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "ВЫ СВЯЗАНЫ"
		};
	end;
end;

-- Called when the chat box info should be adjusted.
function Schema:ChatBoxAdjustInfo(info)
	if (IsValid(info.speaker)) then
		if (info.data.anon) then
			info.name = "Кто-то";
		end;
	end;
end;

-- При нажатии на ентити, мы показываем опции.
function Schema:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "prop_ragdoll") then
		local player = Clockwork.entity:GetPlayer(entity);
		
		if (!player or !player:Alive()) then
			options["Обыскать"] = "cw_corpseLoot";
		end;
	elseif (entity:GetClass() == "cw_belongings") then
		options["Открыть"] = "cw_belongingsOpen";
	elseif (entity:GetClass() == "cw_breach") then
		options["Выбить"] = "cw_breachCharge";
	elseif (entity:GetClass() == "cw_radio") then
		if (!entity:IsOff()) then
			options["Выключить"] = "cw_radioToggle";
		else
			options["Включить"] = "cw_radioToggle";
		end;
		
		options["Выставить частоту"] = function()
			Derma_StringRequest("Частота", "Какую частоту радио вы желаете поставить?", frequency, function(text)
				if (IsValid(entity)) then
					Clockwork.entity:ForceMenuOption(entity, "Выставить частоту", text);
				end;
			end);
		end;
		
		options["Забрать"] = "cw_radioTake";
	end;
end;

-- HUD ID цели.
function Schema:HUDPaintEntityTargetID(entity, info)
	local colorTargetID = Clockwork.option:GetColor("target_id");
	local colorWhite = Clockwork.option:GetColor("white");
	
	if (entity:GetClass() == "prop_physics") then
		local physDesc = entity:GetNetworkedString("physDesc");
		
		if (physDesc != "") then
			info.y = Clockwork.kernel:DrawInfo(physDesc, info.x, info.y, colorWhite, info.alpha);
		end;
	elseif (entity:IsNPC()) then
		local name = entity:GetNetworkedString("cw_Name");
		local title = entity:GetNetworkedString("cw_Title");
		
		if (name != "" and title != "") then
			info.y = Clockwork.kernel:DrawInfo(name, info.x, info.y, Color(255, 255, 100, 255), info.alpha);
			info.y = Clockwork.kernel:DrawInfo(title, info.x, info.y, Color(255, 255, 255, 255), info.alpha);
		end;
	end;
end;

-- Когда мы смотрим на что-то.
function Schema:OnTextEntryGetFocus(panel)
	self.textEntryFocused = panel;
end;

-- Когда мы перестаем на это смотреть.
function Schema:OnTextEntryLoseFocus(panel)
	self.textEntryFocused = nil;
end;

-- Рендерим эффекты.
function Schema:RenderScreenspaceEffects()
	if (!Clockwork.kernel:IsScreenFadedBlack()) then
		local curTime = CurTime();
		
		if (self.flashEffect) then
			local timeLeft = math.Clamp( self.flashEffect[1] - curTime, 0, self.flashEffect[2] );
			local incrementer = 1 / self.flashEffect[2];
			
			if (timeLeft > 0) then
				modify = {};
				
				modify["$pp_colour_brightness"] = 0;
				modify["$pp_colour_contrast"] = 1 + (timeLeft * incrementer);
				modify["$pp_colour_colour"] = 1 - (incrementer * timeLeft);
				modify["$pp_colour_addr"] = incrementer * timeLeft;
				modify["$pp_colour_addg"] = 0;
				modify["$pp_colour_addb"] = 0;
				modify["$pp_colour_mulr"] = 1;
				modify["$pp_colour_mulg"] = 0;
				modify["$pp_colour_mulb"] = 0;
				
				DrawColorModify(modify);
				
				if (!self.flashEffect[3]) then
					DrawMotionBlur( 1 - (incrementer * timeLeft), incrementer * timeLeft, self.flashEffect[2] );
				end;
			end;
		end;
	end;
end;

-- Увеличиваем блюр от движения.
function Schema:PlayerAdjustMotionBlurs(motionBlurs)
	if (!Clockwork.kernel:IsScreenFadedBlack()) then
		local curTime = CurTime();
		
		if (self.flashEffect and self.flashEffect[3]) then
			local timeLeft = math.Clamp( self.flashEffect[1] - curTime, 0, self.flashEffect[2] );
			local incrementer = 1 / self.flashEffect[2];
			
			if (timeLeft > 0) then
				motionBlurs.blurTable["flash"] = 1 - (incrementer * timeLeft);
			end;
		end;
	end;
end;