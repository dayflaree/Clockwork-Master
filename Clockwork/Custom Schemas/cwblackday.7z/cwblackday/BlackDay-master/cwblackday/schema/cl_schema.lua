--[[
	© 2013 TeslaCloud Studios ltd. ( http://teslacloud.net )
	If you got this copy of my work, you might be REALLY cool.
	Please, do not edit or share this file. This will really hurt me.
--]]

--[[ This is where you might add any functions for your schema. --]]
function Schema:PrintConsole(text)
	MsgC(text, Color(255, 0, 0, 255));
end;

-- Добавляем базовый конфиг. Really basic configs.
Clockwork.config:AddToSystem("Small intro text", "intro_text_small", "The small text displayed for the introduction.");
Clockwork.config:AddToSystem("Big intro text", "intro_text_big", "The big text displayed for the introduction.");
Clockwork.config:AddToSystem("Knockout time", "knockout_time", "The time that a player gets knocked out for (seconds).", 0, 7200);

-- Делаем описания объектов.
Clockwork.datastream:Hook("ObjectPhysDesc", function(data)
	local entity = data;
	
	if (IsValid(entity)) then
		Derma_StringRequest("Описание", "Какое описание у этого объекта?", nil, function(text)
			Clockwork.datastream:Start( "ObjectPhysDesc", {text, entity} );
		end);
	end;
end);

-- Устанавливаем частоту радио.
Clockwork.datastream:Hook("Frequency", function(data)
	Derma_StringRequest("Частота радио", "Какую частоту радио установить?", data, function(text)
		Clockwork.kernel:RunCommand("SetFreq", text);
		
		if (!Clockwork.menu:GetOpen()) then
			gui.EnableScreenClicker(false);
		end;
	end);
	
	if (!Clockwork.menu:GetOpen()) then
		gui.EnableScreenClicker(true);
	end;
end);

-- Эффект ослепления.
Clockwork.datastream:Hook("Flashed", function(data)
	Schema:AddFlashEffect();
end);

-- Добавляем эффект ослепления.
function Schema:AddFlashEffect()
	local curTime = CurTime();
	
	self.stunEffects[#self.stunEffects + 1] = {curTime + 10, 10};
	self.flashEffect = {curTime + 20, 20};
	
	surface.PlaySound("hl1/fvox/flatline.wav");
end;

-- Очищаем экран от эффектов.
Clockwork.datastream:Hook("ClearEffects", function(data)
	Schema.stunEffects = {};
	Schema.flashEffect = nil;
end);

-- Получаем текст.
function Schema:IsTextEntryBeingUsed()
	if (self.textEntryFocused) then
		if (self.textEntryFocused:IsValid() and self.textEntryFocused:IsVisible()) then
			return true;
		end;
	end;
end;

-- Игрок является солдатом США?
function Schema:PlayerIsUSAF(player, bHuman)
	if (!IsValid(player)) then
		return;
	end;

	local faction = player:GetFaction();
	
	if (self:IsUSAFFaction(faction)) then
		if (faction == FACTION_USAF) then
		    return true;
		end;
		else
			return false;
		end;
	end;
end;

-- Игрок является солдатом РФ?
function Schema:PlayerIsRussian(player, bHuman)
	if (!IsValid(player)) then
		return;
	end;

	local faction = player:GetFaction();
	
	if (self:IsRussianFaction(faction)) then
		if (faction == FACTION_RUSSIAN) then
		    return true;
		end;
		else
			return false;
		end;
	end;
end;