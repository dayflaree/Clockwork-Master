--[[
	© 2013 TeslaCloud Studios ltd. ( http://teslacloud.net )
	If you got this copy of my work, you might be REALLY cool.
	Please, do not edit or share this file. This will really hurt me.
--]]

Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");

Clockwork.config:ShareKey("intro_text_small"); -- Awesome configs
Clockwork.config:ShareKey("intro_text_big"); -- Another awesome config

Clockwork.flag:Add("v", "Trading", "Access to trading."); -- We need traders, aren't we?

Clockwork.option:SetKey("intro_image", "blackday/logo"); -- Awesome logo
Clockwork.option:SetKey("schema_logo", "blackday/logo"); -- Another awesome logo
Clockwork.option:SetKey("menu_music", "blackday/FallenArmy.mp3"); -- Assasin's Creed: Revelations soundtrack :3
Clockwork.option:SetKey("format_cash", "%a %n");
Clockwork.option:SetKey("name_cash", "Dollars"); -- GIMME 20 DOLLAS
Clockwork.option:SetKey("model_cash", "models/props_lab/box01a.mdl"); -- Change this to somehting else
Clockwork.option:SetKey("gradient", "blackday/bg_gradient"); -- Do not change.
Clockwork.option:SetKey("default_date", {month = 6, year = 2014, day = 13});  -- Friday 13-th :D
Clockwork.option:SetKey("default_time", {minute = 43, hour = 14, day = 1}); -- Bo-ring
Clockwork.option:SetKey("format_singular_cash", "%a"); -- Afraid to change.
Clockwork.option:SetKey("model_shipment", "models/items/item_item_crate.mdl"); -- Dat crate is awesome.

Clockwork.quiz:SetEnabled(true);
Clockwork.quiz:AddQuestion("SOME SORT OF QUESTION?", 1, "PRESS ME.", "DON'T PRESS ME."); -- ToDO: Make quiz questions.

-- From this moment - All descriptions are on Russian.
-- Проверяем является ли текст рангом.
function Schema:IsStringArmyRank(text, rank)
	if (type(rank) == "table") then
		for k, v in ipairs(rank) do
			if (self:IsStringArmyRank(text, v)) then
				return true;
			end;
		end;
	elseif (rank == "Lt") then
		if (string.find(text, "%pMayor%p") or string.find(text, "%pCpt%p")
		or string.find(text, "%pLt%p")) then
			return true;
		end;
	else
		return string.find(text, "%p"..rank.."%p");
	end;
end;

-- Получаем ранг игрока.
function Schema:GetPlayerArmyRank(player)
	local faction = player:GetFaction();
	
	if (self:IsPlayerArmyRank(player, "RCT")) then
		return 0;
	elseif (self:IsPlayerArmyRank(player, "Pvt")) then
		return 1;
	elseif (self:IsPlayerArmyRank(player, "Cpl")) then
		return 2;
	elseif (self:IsPlayerArmyRank(player, "Sgt")) then
		return 3;
	elseif (self:IsPlayerArmyRank(player, "St Sgt")) then
		return 4;
	elseif (self:IsPlayerArmyRank(player, "Commander Sgt")) then
		return 5;
	elseif (self:IsPlayerArmyRank(player, "Lt")) then
		return 6;
	elseif (self:IsPlayerArmyRank(player, "Cpt")) then
		return 7;
	elseif (self:IsPlayerArmyRank(player, "Mayor")) then
		return 8;
	else
		return 99;
	end;
end;

-- Фракция - Армия РФ?
function Schema:IsRussianFaction(faction)
	return (faction == FACTION_RUSSIAN);
end;

-- Фракция - Армия США?
function Schema:IsUSAFFaction(faction)
	return (faction == FACTION_USAF);
end;

-- Проверяем есть ли в имени игрока ранг.
function Schema:IsPlayerArmyRank(player, rank, realRank)
	local name = player:Name();
	local faction = player:GetFaction();
	
	if (self:IsUSAFFaction(faction) or self:IsRussianFaction(faction)) then
		if (type(rank) == "table") then
			for k, v in ipairs(rank) do
				if (self:IsPlayerArmyRank(player, v, realRank)) then
					return true;
				end;
			end;
		elseif (rank == "Lt" and !realRank) then
			if (string.find(name, "%pMayor%p") or string.find(name, "%pCpt%p")
			or string.find(name, "%pLt%p")) then
				return true;
			end;
		else
			return string.find(name, "%p"..rank.."%p");
		end;
	end;
end;