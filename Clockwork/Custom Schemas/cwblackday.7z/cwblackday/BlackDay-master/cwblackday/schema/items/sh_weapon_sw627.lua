--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "S&W Model 627";
	ITEM.cost = 500;
	ITEM.model = "models/weapons/w_sw_model_627.mdl";
	ITEM.weight = 2;
	ITEM.access = "f";
	ITEM.classes = {CLASS_EOW};
	ITEM.uniqueID = "m9k_model627";
	ITEM.business = true;
	ITEM.description = "A Smith & Wesson revolver, it has a wooden oak grip, and iron sights.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();