--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Russian Army Cap.");
	CLASS.color = Color(255, 0, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_RUSSIAN}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.wagesName = "Premie"; -- What is the name of the "wages" for this class.
	CLASS.description = "Russian Army unit who want to stop USA from their evil plans."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Strong marine unit holding a big gun."; -- The default physical description for this class.
CLASS_RUSSIAN_CPT = CLASS:Register();