--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Civilian");
	CLASS.color = Color(0, 255, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_CIVILIAN}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.wagesName = "Wages"; -- What is the name of the "wages" for this class.
	CLASS.description = "Just a Russian Guy who works here."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Weak hostage who's just trying to run out of here."; -- The default physical description for this class.
CLASS_CIVILIAN = CLASS:Register();