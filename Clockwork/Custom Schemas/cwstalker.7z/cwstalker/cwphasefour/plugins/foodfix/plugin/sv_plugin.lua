local Clockwork = Clockwork;
local PLUGIN = PLUGIN;
local playerMeta = FindMetaTable("Player");

-- A function to make a player eat.
function playerMeta:Eat(amount)
	if (!IsValid(self) or !self:HasInitialized()) then return end;

	self:SetCharacterData("hunger", math.Clamp(self:GetCharacterData("hunger") - amount, 0, 100));
end;

-- A function to make a player drink.
function playerMeta:Drink(amount)
	if (!IsValid(self) or !self:HasInitialized()) then return end;

	self:SetCharacterData("thirst", math.Clamp(self:GetCharacterData("thirst") - amount, 0, 100));
end;

-- A function to check if an item is food.
function PLUGIN:IsFood(itemTable)
	return itemTable.category == "Consumables" and !string.find(itemTable.name, "Base");
end;