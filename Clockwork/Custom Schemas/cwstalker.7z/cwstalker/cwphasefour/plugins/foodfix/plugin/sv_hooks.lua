local Clockwork = Clockwork;
local PLUGIN = PLUGIN;


function PLUGIN:PlayerUseItem(player, itemTable, itemEntity)
	local name = itemTable.name;

	if (self:IsFood(itemTable)) then 
		if (itemTable.useText == "Drink") then
			if (name == "Beer") then
				player:Drink(-10);
			elseif (name == "Champagne") then
				player:Drink(-14);
			elseif (name == "Cider") then
				player:Drink(-17);
			elseif (name == "Energy Drink") then
				player:Drink(-10);
			elseif (name == "Lager") then
				player:Drink(-15);
			elseif (name == "Milk Carton") then
				player:Drink(-12);
			elseif (name == "Milk Jug") then
				player:Drink(-12);
			elseif (name == "Red Wine") then
				player:Drink(-12);
			elseif (name == "Vodka") then
				player:Drink(-12);
			elseif (name == "Whiskey") then
				player:Drink(-12)
			elseif (name == "White Wine Wine") then
				player:Drink(-12);
			else
				player:Drink(-10);
			end;
		elseif (itemTable.useText == "Eat") then
			if (name == "Apple") then
				player:Eat(-20);
			elseif (name == "Banana") then
				player:Eat(-35);
			elseif (name == "Beans") then
				player:Eat(-20);
			elseif (name == "Beer") then
				player:Eat(-15);
			elseif (name == "Bon Bons") then 
				player:Eat(-10);
			elseif (name == "Bread") then 
				player:Eat(-10);
			elseif (name == "Candy Floss") then 
				player:Eat(-10);
			elseif (name == "Cereal") then 
				player:Eat(-10);
			elseif (name == "Cheese") then 
				player:Eat(-10);
			elseif (name == "Chocolate") then 
				player:Eat(-10);
			elseif (name == "Corn on the Cob") then 
				player:Eat(-10);
			elseif (name == "Crisps") then 
				player:Eat(-10);
			elseif (name == "Doughnuts") then 
				player:Eat(-10)
			elseif (name == "Hotdog") then 
				player:Eat(-10)
			elseif (name == "Jacket Potato") then 
				player:Eat(-10)
			elseif (name == "Lettuce Sandwich") then 
				player:Eat(-10)
			elseif (name == "Orange") then 
				player:Eat(-10)
			elseif (name == "Peanuts") then 
				player:Eat(-10)
			elseif (name == "Pear") then 
				player:Eat(-10)
			elseif (name == "Jar of Pickles") then 
				player:Eat(-10)
			elseif (name == "Pineapple") then 
				player:Eat(-10)
			elseif (name == "Bag of Popcorn") then 
				player:Eat(-10)
			elseif (name == "Sardines") then 
				player:Eat(-10)
			elseif (name == "Soup") then 
				player:Eat(-10)
			elseif (name == "Sardines") then 
				player:Eat(-10)
			else
				player:Eat(10);
			end;
		end;
	end;
end;