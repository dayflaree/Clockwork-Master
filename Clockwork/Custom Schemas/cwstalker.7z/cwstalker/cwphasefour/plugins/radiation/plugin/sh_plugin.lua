--[[
	Name: sh_auto.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;
PLUGIN.radiationZones = {};

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");