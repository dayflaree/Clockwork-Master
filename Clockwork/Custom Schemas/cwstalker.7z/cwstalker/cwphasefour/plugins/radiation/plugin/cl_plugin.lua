--[[
	Name: cl_auto.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;

-- Called when screen space effects should be rendered.
function PLUGIN:RenderScreenspaceEffects()
	local radiation = Clockwork.Client:GetSharedVar("radiation");
	
	if(radiation)then
		if(radiation >= 75 and radiation < 98)then
			DrawMotionBlur(0.1, 0.79, 0.05);
		elseif(radiation > 85)then
			player:Kill();
		end;
	end;
end;