local ITEM = Clockwork.item:New();
ITEM.name = "Anti-Radiation Pills";
ITEM.uniqueID = "radaway";
ITEM.cost = 0;
ITEM.model = "models/stalker/item/medical/antirad.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Swallow";
ITEM.category = "Medical";
ITEM.access = "v";
ITEM.business = true;
ITEM.useSound = "itemz/Pills.wav";
ITEM.description = "Jar with pills in it. This can help you, if you are infected";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData( "radiation", math.Clamp(player:GetCharacterData("radiation") - 65, 0, 100) );
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register(ITEM);