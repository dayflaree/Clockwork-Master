--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 0;
	ITEM.name = "7.62 mm Rounds";
	ITEM.batch = 5;
	ITEM.model = "models/stalker/ammo/762x39.mdl";
	ITEM.weight = 1;
	ITEM.access = "D";
	ITEM.business = false;
	ITEM.uniqueID = "m9k_ammo_ar2";
	ITEM.ammoClass = "ar2";
	ITEM.ammoAmount = 32;
	ITEM.description = "An average sized blue container with 7.62mm on the side.";
Clockwork.item:Register(ITEM);