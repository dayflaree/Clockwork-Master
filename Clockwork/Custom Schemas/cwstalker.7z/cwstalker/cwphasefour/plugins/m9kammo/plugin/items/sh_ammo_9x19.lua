--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "9x19mm Bullets";
	ITEM.cost = 0;
	ITEM.model = "models/stalker/ammo/9x39.mdl";
	ITEM.weight = 1;
	ITEM.batch = 5;
	ITEM.access = "D";
	ITEM.uniqueID = "m9k_ammo_pistol";
	ITEM.business = false;
	ITEM.ammoClass = "pistol";
	ITEM.ammoAmount = 30;
	ITEM.description = "A container filled with bullets and 9x19mm printed on the side.";
ITEM:Register();