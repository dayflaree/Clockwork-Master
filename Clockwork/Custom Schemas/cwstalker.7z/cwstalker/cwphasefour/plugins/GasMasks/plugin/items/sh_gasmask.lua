
local ITEM = Clockwork.item:New();
ITEM.name = "Backpack";
ITEM.model = "models/warz/alicebackpack.mdl";
ITEM.weight = 0.25;
ITEM.batch = 1;
ITEM.business = true;
ITEM.category = "Clothing";
ITEM.description = "";
ITEM.isAttachment = true;
ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 270, 90);
ITEM.attachmentOffsetVector = Vector(0, -3, -56);
ITEM.access = "U";
ITEM.cost = 0;

-- Called when the attachment offset info should be adjusted.
function ITEM:AdjustAttachmentOffsetInfo(player, entity, info)
	if ( string.find(player:GetModel(), "female") ) then
		info.offsetVector = Vector(0, 0, 0);
	end;
end;

-- A function to get whether the attachment is visible.
function ITEM:GetAttachmentVisible(player, entity)
	if ( player:GetSharedVar("backpack") ) then
		return true;
	end;
end;

-- Called when the item's local amount is needed.
function ITEM:GetLocalAmount(amount)
	if ( Clockwork.Client:GetSharedVar("backpack") ) then
		return amount - 1;
	else
		return amount;
	end;
end;

-- Called to get whether a player has the item equipped.
function ITEM:HasPlayerEquipped(player, arguments)
	return player:GetSharedVar("backpack");
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, arguments)
	local skullMaskGear = Clockwork.player:GetGear(player, "backpack");
	
	if ( player:GetSharedVar("backpack") and IsValid(skullMaskGear) ) then
		player:SetCharacterData("backpack", nil);
		player:SetSharedVar("backpack", false);
		
		if ( IsValid(backpackGear) ) then
			backpackGear:Remove();
		end;
	end;
	
	player:RebuildInventory();
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player:GetSharedVar("backpack") and player:HasItem(self.uniqueID) == 1) then
		Clockwork.player:Notify(player, "You cannot drop this while you are wearing it!");
		
		return false;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if ( player:Alive() and !player:IsRagdolled() ) then
		Clockwork.player:CreateGear(player, "backpack", self);
		
		player:SetCharacterData("backpack", true);
		player:SetSharedVar("backpack", true);
		player:RebuildInventory();

		if (itemEntity) then
			return true;
		end;
	else
		Clockwork.player:Notify(player, "You don't have permission to do this right now!");
	end;
	
	return false;
end;

ITEM:Register();