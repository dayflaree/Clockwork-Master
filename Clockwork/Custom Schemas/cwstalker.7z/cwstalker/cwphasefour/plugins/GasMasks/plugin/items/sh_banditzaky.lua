--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.cost = 0;
	ITEM.name = "Novice Armor S1VW2";
	ITEM.weight = 4.5;
	ITEM.business = false;
	ITEM.armorScale = 0.15;
	ITEM.replacement = "models/stalkertnb/bandit_zaku3.mdl";
	ITEM.description = "Characteristics : \n Armor - 0.15 \n Radiation Protection - Included.";
	ITEM.model = "models/stalkertnb/outfits/io7a_merc3.mdl";
ITEM:Register();

--Called when a player uses the item.
function ITEM:OnEquip(player)
	player:EmitSound("xhosters/a_breath.mp3", 500, 200)
	player:SetSharedVar("wearingRespirator", true);
end;

-- A function to get whether the attachment is visible.
function ITEM:GetAttachmentVisible(player, entity)
	if ( player:GetSharedVar("banditlazy") ) then
		return true;
	end;
end;

-- Called when the item's local amount is needed.
function ITEM:GetLocalAmount(amount)
	if ( Clockwork.Client:GetSharedVar("banditlazy") ) then
		return amount - 1;
	else
		return amount;
	end;
end;

-- Called to get whether a player has the item equipped.
function ITEM:HasPlayerEquipped(player, arguments)
	return player:GetSharedVar("banditlazy");
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, arguments)
	local skullMaskGear = Clockwork.player:GetGear(player, "banditlazy");
	
	if ( player:GetSharedVar("banditlazy") and IsValid(skullMaskGear) ) then
		player:SetCharacterData("banditlazy", nil);
		player:SetSharedVar("banditlazy", false);
		player:SetSharedVar("wearingRespirator", false);
		
		if ( IsValid(banditlazyGear) ) then
			banditlazyGear:Remove();
		end;
	end;
	player:RebuildInventory();
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player:GetSharedVar("banditlazy") and player:HasItem(self.uniqueID) == 1) then
		Clockwork.player:Notify(player, "You cannot drop this while you are wearing it!");
		
		return false;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if ( player:Alive() and !player:IsRagdolled() ) then
		Clockwork.player:CreateGear(player, "banditlazy", self);
		
		player:SetCharacterData("banditlazy", true);
		player:SetSharedVar("banditlazy", true);
		player:SetSharedVar("wearingRespirator", true);
		player:RebuildInventory();
		
		if (itemEntity) then
			return true;
		end;
	else
		Clockwork.player:Notify(player, "You don't have permission to do this right now!");
	end;
	
	return false;
end;

ITEM:Register();