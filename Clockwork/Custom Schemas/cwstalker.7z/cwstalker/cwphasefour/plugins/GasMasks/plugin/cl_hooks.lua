--[[
	Name: cl_hooks.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;
