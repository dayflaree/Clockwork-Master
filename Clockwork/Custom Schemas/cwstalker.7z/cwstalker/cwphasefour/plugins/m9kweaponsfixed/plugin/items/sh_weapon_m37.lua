--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("weapon_base");
        ITEM.name = "Ithaca M37";
        ITEM.cost = 0;
        ITEM.model = "models/weapons/w_ithaca_m37.mdl";
        ITEM.weight = 5.15;
		ITEM.access = "d";
        ITEM.business = false;
        ITEM.uniqueID = "m9k_ithacam37";
        ITEM.description = "A metal shotgun with a long barrel, nicknamed 'Light Feather'.";
        ITEM.isAttachment = true;
        ITEM.hasFlashlight = true;
		ITEM.loweredOrigin = Vector(3, 0, -4);
		ITEM.loweredAngles = Angle(0, 45, 0);
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-4, 4, 4);
ITEM:Register();