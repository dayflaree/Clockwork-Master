local PLUGIN = PLUGIN;

function PLUGIN:PostDrawViewModel( vm, ply, weapon )
   if weapon.UseHands or (not weapon:IsScripted()) then
      local hands = LocalPlayer():GetHands()
      if IsValid(hands) then hands:DrawModel() end
   end
end;