--[[
	Observer stay plugin by Silverdisc - 2013
	Original Clockwork by kurozael. About the original Clockwork code:
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

PLUGIN:SetGlobalAlias("cwObserverStay");

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");