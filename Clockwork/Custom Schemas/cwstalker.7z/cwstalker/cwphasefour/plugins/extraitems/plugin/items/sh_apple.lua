--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Apple";
ITEM.cost = 13;
ITEM.model = "models/bioshockinfinite/loot_apple.mdl";
ITEM.weight = 0.4;
ITEM.access = "l";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.useSound = "itemz/FoodFruit.wav"
ITEM.business = false;
ITEM.description = "An Apple. It looks red and juicy.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 9, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 5, 120);
	-- Because apples make you big and strong <3
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();