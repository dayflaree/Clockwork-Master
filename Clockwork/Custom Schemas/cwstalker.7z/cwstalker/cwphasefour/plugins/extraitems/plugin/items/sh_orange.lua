--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Orange";
ITEM.cost = 13;
ITEM.model = "models/bioshockinfinite/loot_orange.mdl";
ITEM.weight = 0.6;
ITEM.access = "l";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.business = false;
ITEM.useSound = "itemz/FoodFruit.wav"
ITEM.description = "A rather pale looking orange.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 7, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 4, 120);
	-- Oranges.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();