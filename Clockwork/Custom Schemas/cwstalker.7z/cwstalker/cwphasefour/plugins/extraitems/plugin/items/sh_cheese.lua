--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Cheese";
ITEM.cost = 17;
ITEM.model = "models/bioshockinfinite/round_cheese.mdl";
ITEM.weight = 0.7;
ITEM.access = "l";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.business = false;
ITEM.useSound = "itemz/FoodFruit.wav"
ITEM.description = "A yellow block of cheese with holes in it.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 7, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 4, 120);
	player:BoostAttribute(self.name, ATB_STAMINA, 2, 120);
	-- Stilton is bad.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();