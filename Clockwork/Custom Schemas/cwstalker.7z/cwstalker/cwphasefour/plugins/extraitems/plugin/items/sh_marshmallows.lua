--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Marshmallows";
ITEM.cost = 24;
ITEM.model = "models/bioshockinfinite/caramel_box_open.mdl";
ITEM.weight = 0.8;
ITEM.access = "L";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.business = false;

ITEM.description = "A box filled with white, fluffy marshmallows.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 3, 0, player:GetMaxHealth() ) );
	
	-- Marshmallows, yum.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();