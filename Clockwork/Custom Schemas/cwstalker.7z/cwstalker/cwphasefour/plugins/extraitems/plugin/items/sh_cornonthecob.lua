--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Corn on the Cob";
ITEM.cost = 17;
ITEM.model = "models/bioshockinfinite/corn_on_cob.mdl";
ITEM.weight = 0.8;
ITEM.access = "L";
ITEM.useText = "Eat";
ITEM.category = "Consumables"
ITEM.business = false;
ITEM.useSound = "itemz/FoodFruit.wav"
ITEM.description = "Some outdated corn on the cob.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 4, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 6, 120);
	-- Corn on le cob
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();