local PLUGIN = PLUGIN;

-- Called when a player types and enters a text message.
function PLUGIN:PlayerSay(player, text, bTeam) 		
	if (string.sub(text, 1, 2) == "//") then	
		for k, v in pairs(Clockwork.censor.stored) do
			local word = string.lower(v.text);
			local replace = v.replace;
			local final = text:match(self:NoCase(word));
			
			if (final) then
				text = string.gsub(text, final, replace);
			end;
		end;
	end;

	return text;
end;