local Clockwork = Clockwork;

Clockwork.censor = Clockwork.kernel:NewLibrary("Censor");
Clockwork.censor.stored = {};
--[[ Change this to true to enable the use of advanced Regular Expressions --]]
Clockwork.censor.regularExpressions = false;
Clockwork.censor.blacklist = {
	".",
	"\\",
	"?",
	"|",
	"$",
	"[",
	"]",
	"^",
	"+",
	"*",
	"(",
	")"
}

function Clockwork.censor:Add(text, replace)
	for k, v in pairs(self.blacklist) do
		if (!self.regularExpressions) then
			if (!v:match(text)) then
				self.stored[#self.stored + 1] = {
					text = text,
					replace = replace
				};
			else
				ErrorNoHalt("Illegal character in censor ("..v..").\n");
			end;
		else
			self.stored[#self.stored + 1] = {
				text = text,
				replace = replace
			};
		end;
	end;
end;

--[[--------------------------------------------------------
	Please note that this plugin uses Regular Expressions
	http://www.regular-expressions.info/reference.html
--------------------------------------------------------]]--

Clockwork.censor:Add("nigger", "raccoon");
Clockwork.censor:Add("faggot", "flamingo");
Clockwork.censor:Add("wetback", "reindeer");
Clockwork.censor:Add("cunt", "cheetah");
Clockwork.censor:Add("niglet", "pelican");
Clockwork.censor:Add("chink", "dolphin");
Clockwork.censor:Add("Сука", "Собака женского рода");
Clockwork.censor:Add("Блядь", "Лицо вульгароного поведения");
Clockwork.censor:Add("Ебал", "Сношивал");
Clockwork.censor:Add("DICKCOCK", "Норман");
Clockwork.censor:Add("Мобиус", "Шлюха");
Clockwork.censor:Add("Тоби", "Охуенный генератор идей"); 
Clockwork.censor:Add("Пиздец", "Плохое состояние");
Clockwork.censor:Add("Блять", "Все очень плохо");
Clockwork.censor:Add("Мудак", "Пахом");
Clockwork.censor:Add("Жопа", "Пятая точка");
Clockwork.censor:Add("Пидор", "Друг");
Clockwork.censor:Add("Пидр", "Друг");
Clockwork.censor:Add("Педик", "Друг");
Clockwork.censor:Add("Пиздюк", "Школьник");
Clockwork.censor:Add("Админка", "Дай я отсосу");
Clockwork.censor:Add("Админку", "Дай я отсосу");
Clockwork.censor:Add("админка", "Дай я отсосу");
Clockwork.censor:Add("админку", "Дай я отсосу");