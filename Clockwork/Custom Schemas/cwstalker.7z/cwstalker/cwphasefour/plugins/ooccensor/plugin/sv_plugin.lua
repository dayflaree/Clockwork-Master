local PLUGIN = PLUGIN;

-- A function to match with case insensitivity.
-- http://www.lua.org/pil/20.4.html
function PLUGIN:NoCase(text)
	text = string.gsub(text, "%a", function (c)
			return string.format("[%s%s]", string.lower(c), string.upper(c)) 
	end);
	return text;
end;