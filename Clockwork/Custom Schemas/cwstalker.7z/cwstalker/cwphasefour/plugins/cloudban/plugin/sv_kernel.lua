local PLUGIN = PLUGIN;

if(!Clockwork.config:Get("cloudban_url"):Get()) then
	Clockwork.config:Get("cloudban_url"):Set("https://dl.dropboxusercontent.com/u/32687773/banned.txt")
end;

-- Called when a player spawns.
function PLUGIN:PlayerSpawn(player)
		http.Fetch(Clockwork.config:Get("cloudban_url"):Get(),
		function(body, len, headers, code)
     	 if(string.find(body, player:SteamID())) then
			Clockwork.player:NotifyAll("[CloudBan] "..player:SteamName().." ("..player:SteamID()..") has been permanently banned.")
			Clockwork.bans:Add(player:SteamID(), 0, "[CloudBan] You are permanently banned from this server")
		end;
		end,
		function(code)
         	ErrorNoHalt("[CloudBan] An error has occurred ("..code.."). Reverting to default ban list.")
         	http.Fetch("https://dl.dropboxusercontent.com/u/32687773/banned.txt",
		function(body, len, headers, code)
     	 if(string.find(body, player:SteamID())) then
			Clockwork.player:NotifyAll("[CloudBan] "..player:SteamName().." ("..player:SteamID()..") has been permanently banned.")
			Clockwork.bans:Add(player:SteamID(), 0, "[CloudBan] You are permanently banned from this server")
		end;
		end,
		function(code)
         	ErrorNoHalt("[CloudBan] An error has occurred ("..code..").")
		end)
		end)
end;