--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

function PLUGIN:SaveItemAutoSpawnPoints()
	Clockwork.kernel:SaveSchemaData("plugins/itemspawn/"..game.GetMap(), self.ItemSpawnList);
end;

function PLUGIN:LoadItemAutoSpawnPoints()
	self.ItemSpawnList = Clockwork.kernel:RestoreSchemaData("plugins/itemspawn/"..game.GetMap());
	
	if (!self.ItemSpawnList) then
		self.ItemSpawnList = {};
	end;
	
	for k,v in pairs(self.ItemSpawnList) do
		v.nextSpawn = 0;
	end;
end;

function PLUGIN:SpawnItem(spawnTable, time)
	local nextSpawn = time + spawnTable.timePeriod;
	local item = Clockwork.item:FindByID(spawnTable.item);
	
	if (item) then
		Clockwork.entity:CreateItem(nil, item.uniqueID, spawnTable.position);
	end
	
	return nextSpawn;
end

function PLUGIN:IsThereAItem(item, position)
	local props = ents.FindInSphere(position,50);
	
	
	if (props) then
		for k2, v2 in pairs(props) do
			if (IsValid(v2) && v2:GetClass() == "cw_item") then
				local index = v2:GetDTInt(0);
				
				if (index != 0) then	
					local findedItem = Clockwork.item:FindByID(index);
					local spawnItem = Clockwork.item:FindByID(item);

					if (findedItem == spawnItem) then
						return false;
					end;
				end;
			end;
		end;
	end

	return true;
end