--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("ItemAutoSpawnPointAdd");
COMMAND.tip = "Add a item spawn at your target position.";
COMMAND.text = "<Item> <Time>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local item = string.Trim(arguments[1]);
	local timePeriod = tonumber(arguments[2]);
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);
	
	table.insert(PLUGIN.ItemSpawnList,{
		item = item,
		position = position,
		timePeriod = timePeriod,
		nextSpawn = 0
	});
	
	PLUGIN:SaveItemAutoSpawnPoints();
	
	Clockwork.player:Notify(player, "You have added a item spawn point: ".. item ..".");
end;

COMMAND:Register();