--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitPostEntity()
	self:LoadItemAutoSpawnPoints();
end;

function PLUGIN:Tick()
	local curTime = CurTime();
	
	for k,v in pairs(self.ItemSpawnList) do
		
		if (curTime > v.nextSpawn) then
			
			if (self:IsThereAItem(v.item,v.position)) then
				v.nextSpawn = self:SpawnItem(v, curTime);
			else
				v.nextSpawn = v.nextSpawn + v.timePeriod;
			end;
		end;
	
	end;
end;
