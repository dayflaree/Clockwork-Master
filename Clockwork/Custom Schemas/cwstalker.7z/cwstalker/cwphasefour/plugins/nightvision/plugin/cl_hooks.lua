
local PLUGIN = PLUGIN;

function PLUGIN:RenderScreenspaceEffects()
	if Clockwork.Client:GetSharedVar("nightvision") then
		local colormod = {}
		colormod[ "$pp_colour_contrast" ] = 1.5
		colormod[ "$pp_colour_addr" ] = 120 / 2550
		colormod[ "$pp_colour_addg" ] = 255 / 2550
		colormod[ "$pp_colour_addb" ] = 120 / 2550
 		DrawColorModify(colormod)
	end
end

function PLUGIN:Think()
	if Clockwork.Client:GetSharedVar("nightvision") then
		local light = DynamicLight(LocalPlayer():EntIndex())
		light.Pos = LocalPlayer():GetPos() + Vector(0,0,30)
		light.r = 120
		light.g = 255
		light.b = 120
		light.Brightness = 1
		light.Size = 7000
		light.Decay = 7000 * 5
		light.DieTime = CurTime() + 1
		light.Style = 0
	end
end