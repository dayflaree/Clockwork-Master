function PLUGIN:GetBars(bars)
 local hunger = Clockwork.Client:GetSharedVar("hunger");
 local thirst = Clockwork.Client:GetSharedVar("thirst");
 local sleep = Clockwork.Client:GetSharedVar("sleep");
 
 if (!self.hunger) then
  self.hunger = hunger;
 else
  self.hunger = math.Approach(self.hunger, hunger, 1);
 end;
 
 if (!self.thirst) then
  self.thirst = thirst;
 else
  self.thirst = math.Approach(self.thirst, thirst, 1);
 end;
 
 if (!self.sleep) then
  self.sleep = sleep;
 else
  self.sleep = math.Approach(self.sleep, sleep, 1);
 end;
 
 local text,color = "Unknown", Color(255,255,255,255);
 
 if ( thirst >= 80 ) then
  text = "Thirst";
  color = Color(88,138,172,255); -- green
 elseif( thirst >= 60 ) then
  text = "Thirst";
  color = Color(88,138,172,255); -- lime green
 elseif( thirst >= 40 ) then
  text = "Thirst";
  color = Color(88,138,172,255); -- yellow
 elseif( thirst >= 20 ) then
  text = "Thirst"; -- orange
  color = Color(88,138,172,255);
 elseif( thirst >= 0 ) then
  text = "Thirst"; -- red
  color = Color(88,138,172,255);
 end;


 if ( hunger >= 80 ) then
  hungerText = "Hunger";
  hungerColor = Color(255,209,98,255); -- green
 elseif( hunger >= 60 ) then
  hungerText = "Hunger";
  color = Color(255,209,98,255); -- lime green
 elseif( hunger >= 40 ) then
  hungerText = "Hunger";
  hungerColor = Color(255,209,98,255); -- yellow
 elseif( hunger >= 20 ) then
  hungerText = "Hunger"; -- orange
  hungerColor = Color(255,209,98,255);
 elseif( hunger >= 0 ) then
  hungerText = "Hunger"; -- red
  hungerColor = Color(255,209,98,255);
 end;
 
 if ( sleep >= 80 ) then
  sleepText = "Sleep";
  sleepColor = Color(199,255,252,255); -- green
 elseif( sleep >= 60 ) then
  sleepText = "Sleep";
  sleepColor = Color(199,255,252,255); -- lime green
 elseif( sleep >= 40 ) then
  sleepText = "Sleep";
  sleepColor = Color(199,255,252,255); -- yellow
 elseif( sleep >= 20 ) then
  sleepText = "Sleep"; -- orange
  sleepColor = Color(199,255,252,255);
 elseif( sleep >= 0 ) then
  sleepText = "Sleep"; -- red
  sleepColor = Color(199,255,252,255);
 end;
 
 Clockwork.bars:Add("HUNGER", hungerColor, hungerText, self.hunger, 100, self.hunger < 90);
 Clockwork.bars:Add("THIRST", color, text, self.thirst, 100, self.thirst < 90);
 Clockwork.bars:Add("SLEEP", sleepColor, sleepText, self.sleep, 100, self.sleep < 90);
end;