--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Map";
ITEM.model = "models/stalker/item/handhelds/files4.mdl";
ITEM.uniqueID = "book_mmp";
ITEM.description = "Metro map.";
ITEM.bookInformation = [[
<img src = "http://savepic.ru/488193.jpg" alt = "[Moscow metro map]."/>

]];

ITEM:Register();