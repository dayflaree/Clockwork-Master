--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Usual suit";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.08;
	ITEM.replacement = "models/devcon/mrp/act/bandit_vest.mdl";
	ITEM.description = "Dirty pants, black boots and an old armor";
	ITEM.model = "models/stalkertnb/outfits/io7a_merc3.mdl";
 -- ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();