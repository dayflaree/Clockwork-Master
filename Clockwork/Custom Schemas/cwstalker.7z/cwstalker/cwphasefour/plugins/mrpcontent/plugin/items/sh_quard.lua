--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Old suit";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.04;
	ITEM.replacement = "models/devcon/mrp/act/guard.mdl";
	ITEM.description = "The old armor and pants, a sweater and a battered rag mask";
 -- ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();