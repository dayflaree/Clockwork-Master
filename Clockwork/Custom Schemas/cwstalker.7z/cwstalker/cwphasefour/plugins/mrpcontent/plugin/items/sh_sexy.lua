--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Costume whores";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.01;
	ITEM.replacement = "models/devcon/mrp/act/longlostblake.mdl";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
	ITEM.description = "The short skirt, stockings, no panties, a small jacket and boots.";
ITEM:Register();