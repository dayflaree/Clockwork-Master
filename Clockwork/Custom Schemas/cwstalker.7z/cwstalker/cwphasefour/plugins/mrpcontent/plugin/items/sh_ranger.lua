--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Ranger Armor";
	ITEM.weight = 5;
	ITEM.business = false;
	ITEM.armorScale = 0.17;
	ITEM.replacement = "models/devcon/mrp/act/ranger_2.mdl";
	ITEM.description = "Strong armor Rangers, reinforced helmet with a gas mask.";
 -- ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();