--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Costume stalker";
	ITEM.weight = 4;
	ITEM.business = false;
	ITEM.armorScale = 0.14;
	ITEM.replacement = "models/devcon/mrp/act/stalker.mdl";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
	ITEM.description = "Reinforced helmet, armor, black boots, badges are missing.";
ITEM:Register();

