--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Uniform of stalker Reich ";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.25;
	ITEM.replacement = "models/devcon/mrp/act/reich_stalker.mdl";
	ITEM.description = "Warmed armored suit with a gas mask and an emblem of the Reich.";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();