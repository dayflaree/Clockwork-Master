--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "light suit 1";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.07;
	ITEM.replacement = "models/devcon/mrp/act/stealth_light.mdl";
	ITEM.description = "Light suit without features.";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();