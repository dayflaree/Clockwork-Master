--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "light suit 2";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.07;
	ITEM.replacement = "models/devcon/mrp/act/stealth_light2.mdl";
	ITEM.description = "Light suit without features.";
ITEM:Register();