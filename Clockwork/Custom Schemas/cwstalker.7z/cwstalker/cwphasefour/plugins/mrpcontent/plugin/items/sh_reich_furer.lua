--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Costume Of. Reich";
	ITEM.weight = 2;
	ITEM.business = false;
	ITEM.armorScale = 0.14;
	ITEM.replacement = "models/devcon/mrp/act/reich_offizier_jake.mdl";
	ITEM.description = "Reich's cap, a long coat, first aid kit, boots.";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();