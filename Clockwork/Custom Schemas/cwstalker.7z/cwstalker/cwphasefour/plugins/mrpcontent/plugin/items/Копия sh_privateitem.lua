--[[
	2013 Metro2033RP team
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Dark Armor";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.8;
	ITEM.replacement = "models/devcon/mrp/act/darkone.mdl";
	ITEM.description = "Dark Armor by Anti-ming";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();