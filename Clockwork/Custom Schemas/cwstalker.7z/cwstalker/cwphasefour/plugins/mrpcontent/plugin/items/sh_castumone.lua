--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Black suit";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.05;
	ITEM.replacement = "models/devcon/mrp/act/bandit_light_2.mdl";
	ITEM.description = "Plain black suit";
	ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
	--ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
	--ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();