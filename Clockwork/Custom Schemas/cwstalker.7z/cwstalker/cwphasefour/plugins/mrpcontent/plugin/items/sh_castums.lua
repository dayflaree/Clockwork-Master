--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 00;
	ITEM.name = "Blue suit";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.06;
	ITEM.replacement = "models/devcon/mrp/act/bandit_vest2.mdl";
	ITEM.description = "Net pants, black boots and a blue vest";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();