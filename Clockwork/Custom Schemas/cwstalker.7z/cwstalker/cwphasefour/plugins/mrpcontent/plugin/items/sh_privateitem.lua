--[[
	2013 Metro2033RP team
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "The prototype armor of d6";
	ITEM.weight = 4;
	ITEM.business = false;
	ITEM.armorScale = 0.7;
	ITEM.replacement = "models/devcon/mrp/act/master_stalker.mdl";
	ITEM.description = "Black combat armor, built-in radio and a gas mask, black boots, reinforced armor.";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();