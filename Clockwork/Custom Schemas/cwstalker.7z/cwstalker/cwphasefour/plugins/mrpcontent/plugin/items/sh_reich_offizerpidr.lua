--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Uniforms stalker Reich";
	ITEM.weight = 3;
	ITEM.business = false;
	ITEM.armorScale = 0.15;
	ITEM.replacement = "models/devcon/mrp/act/herr_offizier_jake.mdl";
	ITEM.description = "Costume veteran officer of the Reich 4, first aid kit, glamorous sunglasses gay";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();