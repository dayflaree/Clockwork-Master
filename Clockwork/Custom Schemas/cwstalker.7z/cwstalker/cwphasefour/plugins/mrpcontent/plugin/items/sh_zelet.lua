--[[
	2013 By Portal Dla pidarasov
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Black coat";
	ITEM.weight = 2;
	ITEM.business = false;
	ITEM.armorScale = 0.08;
	ITEM.replacement = "models/devcon/mrp/act/trenchcoat_black.mdl";
	ITEM.description = "The usual black coat unremarkable.";
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();