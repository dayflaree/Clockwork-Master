--[[
	2013 By Portal
--]]

local ITEM = Clockwork.item:New("custom_clothes");
	ITEM.cost = 0;
	ITEM.name = "Green coat";
	ITEM.weight = 1;
	ITEM.business = false;
	ITEM.armorScale = 0.1;
	ITEM.replacement = "models/devcon/mrp/act/green_coat.mdl";
	ITEM.description = "Black pants, a green coat, a rag mask";
 -- ITEM.model = "models/devcon/mrp/props/clothes_shirt_dark.mdl"; --черный
 --	ITEM.model = "models/devcon/mrp/props/clothes_shirt_brown.mdl"; --коричневый
    ITEM.model = "models/devcon/mrp/props/clothes_shirt_camo.mdl" -- камуфляж
ITEM:Register();