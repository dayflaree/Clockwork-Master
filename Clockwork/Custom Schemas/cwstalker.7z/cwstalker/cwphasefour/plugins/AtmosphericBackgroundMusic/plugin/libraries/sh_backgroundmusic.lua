--[[
	� 2012 Iron-Wall.org do not share, re-distribute or modify
	without permission of its author (ext@iam1337.ru).
--]]

Clockwork.backgroundmusic = Clockwork.kernel:NewLibrary("BackgroundMusic");
Clockwork.backgroundmusic.stored = {};

function Clockwork.backgroundmusic:Add(id, name, music, addFile)
	self.stored[id] = {
		name = name,
		music = music
	};
	
	if (SERVER) then
		if (addFile) then
			Clockwork.kernel:AddFile("sound/bg/"..music);
		end;
	end;
end;

function Clockwork.backgroundmusic:FindByID(id)
	return self.stored[id];
end;

function Clockwork.backgroundmusic:FindByName(name)
	for k,v in pairs(self.stored) do
		if (string.lower(v.name) == string.lower(v.name)) then return v; end;
	end;
end;

if (CLIENT) then
	function Clockwork.backgroundmusic:Play(id)
		if (!self.sound and self:FindByID(tostring(id))) then
			self.sound = CreateSound(Clockwork.Client, self:FindByID(tostring(id)).music);
			self.sound:PlayEx(0.75,100);		
			
			return;
		else
			self:Stop();
			
			timer.Simple(5, function()
			Clockwork.backgroundmusic:Play(id);
		end)
		end;
	end;
	
	function Clockwork.backgroundmusic:Stop()
		if self.sound then -- @FIX by Sanya_Zol
		self.sound:FadeOut(3);
		self.sound = false;
		end
	end;
	
	Clockwork.datastream:Hook("cwMusicList", function(data)
		Clockwork.Client:PrintMessage(2, "######## [Clockwork] Music List ########\n");
		for k,v in pairs(Clockwork.backgroundmusic.stored) do
			Clockwork.Client:PrintMessage(2,k..") Name: "..v.name.." | Music patch: "..v.music.."\n");
		end;
	end);
end;

Clockwork.backgroundmusic:Add("1", "SHIT", "sound/bg/tun1.mp3");
