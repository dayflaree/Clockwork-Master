--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[
	You don't have to do this, but I think it's nicer.
	Alternatively, you can simply use the Schema variable.
--]]
Schema:SetGlobalAlias("PhaseFour");

--[[ You don't have to do this either, but I prefer to seperate the functions. --]]
Clockwork.kernel:IncludePrefixed("sv_schema.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");

Clockwork.attribute:FindByID("Stamina").isOnCharScreen = true;

Clockwork.option:SetKey("description_business", "Craft a variety of equipment with your rations.");
Clockwork.option:SetKey("intro_image", "pics/gutlaga");
Clockwork.option:SetKey("schema_logo", "phasefour/logo1");
Clockwork.option:SetKey("name_business", "Crafting");
Clockwork.option:SetKey("menu_music", "music/hl2_song19.mp3");
Clockwork.option:SetKey("model_shipment", "models/items/item_item_exper.mdl");
Clockwork.option:SetKey("model_cash", "models/stalker/ammo/magnum.mdl");
Clockwork.option:SetKey("name_cash", "Bullets");
Clockwork.option:SetKey("gradient", "phasefour/bg_gradient");

-- Called when the Clockwork shared variables are added.
function PhaseFour:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("beingChloro", true);
	playerVars:Bool("beingTied", true);
	playerVars:Bool("implant", true);
	playerVars:Number("nextDC", true);
	playerVars:Number("fuel", true);
	playerVars:Bool("ghostheart");
	playerVars:Bool("skullMask");
	playerVars:String("alliance");
	playerVars:Entity("disguise");
	playerVars:Entity("jetpack");
	playerVars:Number("bounty");
	playerVars:String("title");
	playerVars:Number("honor");
	playerVars:Number("rank");
	playerVars:Bool("tied");
end;

Clockwork.quiz:SetName("Agreement");
Clockwork.quiz:SetEnabled(true);

Clockwork.quiz:AddQuestion("What universe this roleplay based on? ", 2, "World War II", "Metro 2033.");
Clockwork.quiz:AddQuestion("In what city action go on?", 6, "dickcock", "Saint-Petersbur", "Berlin", "Sochi", "London", "Moscow" );
Clockwork.quiz:AddQuestion("What is NLR?", 1, "New Life Rule.", "National Litva Laboratory.");
Clockwork.quiz:AddQuestion("What is RDM?", 2, "Remote Device Managment.", "Random Death-Match.");
Clockwork.quiz:AddQuestion("You can type properly?", 3, "YES IMMA CAN DO THIS, LET ME DO THIS!", "WUT ARE YOU RETARDED?", "Yes, I can", "SIEG HEIL!", "PROEBAL MID MUDAK", "Yes, I cAn TyEp Pruperli");
Clockwork.quiz:AddQuestion("You should respect other players, isn't it?", 2, "Oy blya ti mudak.", "Of course, I know that i should respect all players.", "5 Carry team ggwp, i leave.", "Idi ti nahui mudak, ves pol zasral.");

RANK_RCT = 0;
RANK_PVT = 1;
RANK_SGT = 2;
RANK_LT = 3;
RANK_CPT = 4;
RANK_MAJ = 5;

-- A function to get a player's honor text.
function PhaseFour:PlayerGetHonorText(player, honor)
	if (honor >= 90) then
		return "This character is worshiped!";
	elseif (honor >= 80) then
		return "This character is divine."
	elseif (honor >= 70) then
		return "This character is blessed."
	elseif (honor >= 60) then
		return "This character is a nice guy.";
	elseif (honor >= 50) then
		return "This character is friendly.";
	elseif (honor >= 40) then
		return "This character is nasty.";
	elseif (honor >= 30) then
		return "This character is a bad guy.";
	elseif (honor >= 20) then
		return "This character is cursed.";
	elseif (honor >= 10) then
		return "This character is evil.";
	else
		return "This character is satanic!";
	end;
end;

local modelGroups = {60, 61, 62};

for _, group in pairs(modelGroups) do
	for k, v in pairs(_file.Find("models/humans/group"..group.."/*.mdl", "GAME")) do
		if (string.find(string.lower(v), "female")) then
			Clockwork.animation:AddFemaleHumanModel("models/humans/group"..group.."/"..v);
		else
			Clockwork.animation:AddMaleHumanModel("models/humans/group"..group.."/"..v);
		end;
	end;
end;

for k, v in pairs(_file.Find("models/napalm_atc/*.mdl", "GAME")) do
	Clockwork.animation:AddMaleHumanModel("models/napalm_atc/"..v);
end;

for k, v in pairs(_file.Find("models/nailgunner/*.mdl", "GAME")) do
	Clockwork.animation:AddMaleHumanModel("models/nailgunner/"..v);
end;

for k, v in pairs(_file.Find("models/salem/*.mdl", "GAME")) do
	Clockwork.animation:AddMaleHumanModel("models/salem/"..v);
end;

for k, v in pairs(_file.Find("models/bio_suit/*.mdl", "GAME")) do
	Clockwork.animation:AddMaleHumanModel("models/bio_suit/"..v);
end;

for k, v in pairs(_file.Find("models/srp/*.mdl", "GAME")) do
	Clockwork.animation:AddMaleHumanModel("models/srp/"..v);
end;

Clockwork.animation:AddMaleHumanModel("models/humans/group03/male_experim.mdl");
Clockwork.animation:AddMaleHumanModel("models/pmc/pmc_4/pmc__07.mdl");
Clockwork.animation:AddMaleHumanModel("models/tactical_rebel.mdl");
Clockwork.animation:AddMaleHumanModel("models/riot_ex2.mdl");

local MODEL_SPX7 = Clockwork.animation:AddMaleHumanModel("models/spx7.mdl");
local MODEL_SPX2 = Clockwork.animation:AddMaleHumanModel("models/spx2.mdl");
local MODEL_SPEX = Clockwork.animation:AddMaleHumanModel("models/spex.mdl");
local SPEX_MODELS = {MODEL_SPEX, MODEL_SPX2, MODEL_SPX7};

for k, v in ipairs(SPEX_MODELS) do
	Clockwork.animation:AddOverride(v, "stand_grenade_idle", "LineIdle03");
	Clockwork.animation:AddOverride(v, "stand_pistol_idle", "LineIdle03");
	Clockwork.animation:AddOverride(v, "stand_blunt_idle", "LineIdle03");
	Clockwork.animation:AddOverride(v, "stand_slam_idle", "LineIdle03");
	Clockwork.animation:AddOverride(v, "stand_fist_idle", "LineIdle03");
end;