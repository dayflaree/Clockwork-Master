--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("Dark");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/WUT";
FACTION.models = {
	male = {
"models/devcon/mrp/act/darkone.mdl"
},
   female = {
"models/devcon/mrp/act/darkone.mdl"
	};
};

FACTION_DARK = FACTION:Register();