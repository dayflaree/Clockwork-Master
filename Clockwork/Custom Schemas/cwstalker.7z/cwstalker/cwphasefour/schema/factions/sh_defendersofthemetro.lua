--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("The Defenders Of the Metro");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/miss";
FACTION.models = {
	male = {
"models/devcon/mrp/act/redline_soldier.mdl"
},
   female = {
"models/devcon/mrp/act/redline_soldier.mdl"
	};
};

FACTION_DEF = FACTION:Register();