--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("Rangers");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/wut";
FACTION.models = {
	male = {
"models/devcon/mrp/act/green_sweater.mdl"
},
   female = {
"models/devcon/mrp/act/green_sweater.mdl"
	};
};

FACTION_RANGERS = FACTION:Register();