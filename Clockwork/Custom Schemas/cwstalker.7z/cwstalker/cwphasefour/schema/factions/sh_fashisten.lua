--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("4th Reich");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/FourthReich";
FACTION.models = {
	male = {
"models/devcon/mrp/act/reich_enlisted.mdl"
},
   female = {
"models/devcon/mrp/act/reich_enlisted.mdl"
	};
};

FACTION_REICH = FACTION:Register();