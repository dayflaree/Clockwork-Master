--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("Mutants");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/WUT";
FACTION.models = {
	male = {
"models/Zombie/Classic.mdl",
"models/Zombie/Fast.mdl",
"models/Zombie/Poison.mdl",
"models/stalkertnb/bandit7.mdl",
"models/stalkertnb/bandit8.mdl",
"models/stalkertnb/bandit9.mdl",
"models/stalkertnb/zombie2.mdl",
"models/stalkertnb/zombie1.mdl"

},
   female = {
"models/Zombie/Classic.mdl",
"models/Zombie/Fast.mdl",
"models/Zombie/Poison.mdl",
"models/stalkertnb/bandit7.mdl",
"models/stalkertnb/bandit8.mdl",
"models/stalkertnb/bandit9.mdl",
"models/stalkertnb/zombie2.mdl",
"models/stalkertnb/zombie1.mdl"
	};
};

FACTION_MUTANTS = FACTION:Register();