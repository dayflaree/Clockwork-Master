--[[
	� 2013 By Portal.
--]]

local FACTION = Clockwork.faction:New("Red line");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "pics/RedLineTexture";
FACTION.models = {
	male = {
"models/devcon/mrp/act/redline_soldier.mdl"
},
   female = {
"models/devcon/mrp/act/redline_soldier.mdl"
	};
};

FACTION_RED = FACTION:Register();