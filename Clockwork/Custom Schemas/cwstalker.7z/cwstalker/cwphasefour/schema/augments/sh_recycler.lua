--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Садист";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/recycler1";
AUGMENT.honor = "perma";
AUGMENT.description = "У вас есть 50% шанс востановить жизни, если вы убили игрока выстрелом в голову.";

AUG_RECYCLER = PhaseFour.augment:Register(AUGMENT);