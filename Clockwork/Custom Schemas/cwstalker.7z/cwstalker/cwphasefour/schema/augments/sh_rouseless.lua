--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Хорошая память";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/rouseless1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы узнаете персонажа, даже если на нем маска";

AUG_ROUSELESS = PhaseFour.augment:Register(AUGMENT);