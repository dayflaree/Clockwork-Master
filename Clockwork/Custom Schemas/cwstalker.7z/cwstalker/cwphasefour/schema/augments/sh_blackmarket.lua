--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Барыга";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/blackmarket1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы можете продать вещи на 20% дороже.";

AUG_BLACKMARKET = PhaseFour.augment:Register(AUGMENT);