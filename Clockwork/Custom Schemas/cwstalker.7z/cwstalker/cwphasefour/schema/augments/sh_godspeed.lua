--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Бегун";
AUGMENT.cost = 1600;
AUGMENT.image = "augments/godspeed1";
AUGMENT.honor = "perma";
AUGMENT.description = "Скорость вашего бега увеличивается на 10%";

AUG_GODSPEED = PhaseFour.augment:Register(AUGMENT);