--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Реаниматор";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/lifebringer1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы можете восресить убитого персонажа, жертвуя половиной своих жизней.";

AUG_LIFEBRINGER = PhaseFour.augment:Register(AUGMENT);