--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Стрелок";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/hollowpoint1";
AUGMENT.honor = "perma";
AUGMENT.description = "Стреляя с оружия вы наносите на 10% больше урона";

AUG_HOLLOWPOINT = PhaseFour.augment:Register(AUGMENT);