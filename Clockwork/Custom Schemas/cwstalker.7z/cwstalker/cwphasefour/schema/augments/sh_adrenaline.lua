--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Адреналин";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/adrenaline1";
AUGMENT.honor = "perma";
AUGMENT.description = "Если вы находитесь в крит.состоянии, вы медленно востановитесь";

AUG_ADRENALINE = PhaseFour.augment:Register(AUGMENT);