--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Ловкач";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/bluntdefense1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы получаете на 25% меньше урона в ближнем бою";

AUG_BLUNTDEFENSE = PhaseFour.augment:Register(AUGMENT);