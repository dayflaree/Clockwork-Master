--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Торговец";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/cashback1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы можете продать ваши вещи дороже на 25%";

AUG_CASHBACK = PhaseFour.augment:Register(AUGMENT);