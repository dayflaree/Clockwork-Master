--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Живучий";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/longlaster1";
AUGMENT.honor = "perma";
AUGMENT.description = "Находясь в крит. состоянии вы продержитесь дольше\nЕсли вы обладаете способностью <адреналин> вы востановитесь в два раза быстрее.";

AUG_LONGLASTER = PhaseFour.augment:Register(AUGMENT);