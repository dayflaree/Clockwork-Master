--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Прирожденный выживатель";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/bornsurvivor1";
AUGMENT.honor = "perma";
AUGMENT.description = "Когда вы находитесь в крит. состонии, вы притворяетесь мертвым, поэтому игроки не могут вас добить. Но зомби могут.";

AUG_BORNSURVIVOR = PhaseFour.augment:Register(AUGMENT);