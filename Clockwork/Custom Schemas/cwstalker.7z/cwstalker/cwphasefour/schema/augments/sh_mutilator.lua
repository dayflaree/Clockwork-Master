--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Канибал";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/mutilator1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы все же подхватили слабую форму вируса. Вы можете есть человеческое мясо востанавливая себе жизни. Будьте аккуратны, вас могут убить за это";

AUG_MUTILATOR = PhaseFour.augment:Register(AUGMENT);