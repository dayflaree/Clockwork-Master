--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Торопыга";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/hurryman1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы можете развязывать персонажей на 50% быстрее.";

AUG_HURRYMAN = PhaseFour.augment:Register(AUGMENT);