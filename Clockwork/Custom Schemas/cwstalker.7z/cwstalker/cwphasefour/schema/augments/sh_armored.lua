--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Эксперт защиты";
AUGMENT.cost = 2000;
AUGMENT.image = "augments/armored1";
AUGMENT.honor = "perma";
AUGMENT.description = "Каждый бронежилет будет защищать на 50% лучше";

AUG_ARMORED = PhaseFour.augment:Register(AUGMENT);