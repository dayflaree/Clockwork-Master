--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Драчун";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/rapidmelee1";
AUGMENT.honor = "perma";
AUGMENT.description = "В ближнем бою вы атакуете на 50% быстрее.";

AUG_RAPIDMELEE = PhaseFour.augment:Register(AUGMENT);