--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Твердолобый";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/headplate1";
AUGMENT.honor = "perma";
AUGMENT.description = "Из-за прошлой травмы вам вставили в голову железную пластину. У вас есть 50% шанс не умереть от попадания в голову.";

AUG_HEADPLATE = PhaseFour.augment:Register(AUGMENT);