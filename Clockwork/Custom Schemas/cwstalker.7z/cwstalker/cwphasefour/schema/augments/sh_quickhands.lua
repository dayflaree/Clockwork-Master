--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Ловкие руки";
AUGMENT.cost = 3000;
AUGMENT.image = "augments/hurryman1";
AUGMENT.honor = "perma";
AUGMENT.description = "Вы связываете игроков на 50% быстрее.";

AUG_QUICKHANDS = PhaseFour.augment:Register(AUGMENT);