--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local AUGMENT = {};

AUGMENT = {};
AUGMENT.name = "Прыгун";
AUGMENT.cost = 2400;
AUGMENT.image = "augments/legbraces1";
AUGMENT.honor = "perma";
AUGMENT.description = "Прыгая с большой высоты вы получаете на 50% меньше урона";

AUG_LEGBRACES = PhaseFour.augment:Register(AUGMENT);