--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Energy Drink 'HUNTER'";
ITEM.cost = 0;
ITEM.model = "models/props_junk/watermelon01.mdl";
ITEM.weight = 0.5;
ITEM.useText = "Drink";
ITEM.category = "Consumables"
ITEM.business = false;
ITEM.useSound = "itemz/Drink.wav"
ITEM.description = "High quality energy drink due to higher count of caffeine - a large influx of strength.\nEstimated time of action : 10 minutes.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth(math.Clamp(player:Health() + 1, 0, 100));
	player:BoostAttribute(self.name, ATB_ACROBATICS, 70, 600);
	player:BoostAttribute(self.name, ATB_AGILITY, 70, 600);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();