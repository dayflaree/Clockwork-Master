--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("alcohol_base");
ITEM.name = "Vodka 'PUTINKA'";
ITEM.cost = 30;
ITEM.model = "models/stalker/item/food/vokda.mdl";
ITEM.weight = 1;
ITEM.business = false;
ITEM.useSound = "itemz/Drink_vodka.wav"
ITEM.attributes = {Strength = 10};
ITEM.description = "Russian vodka which called 'PUTINKA'. Maybe it's in honor of Vladimir Vladimirovich Putin";

-- Called when a player drinks the item.
function ITEM:OnDrink(player)
	player:BoostAttribute(self.name, ATB_AGILITY, - 30, 200);
	player:SetCharacterData( "radiation", math.Clamp(player:GetCharacterData("radiation") - 25, 0, 100) )
end;

ITEM:Register();