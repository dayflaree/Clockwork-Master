--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

PhaseFour.lastHeartbeatAmount = 0;
PhaseFour.nextHeartbeatCheck = 0;
PhaseFour.heartbeatGradient = Material("gui/gradient_down");
PhaseFour.heartbeatOverlay = Material("effects/combine_binocoverlay");
PhaseFour.heartbeatPoints = {};
PhaseFour.nextGetSnipers = 0;
PhaseFour.heartbeatPoint = Material("sprites/glow04_noz");
PhaseFour.targetOutlines = {};
PhaseFour.damageNotify = {};
PhaseFour.laserSprite = Material("sprites/glow04_noz");
PhaseFour.hotkeyItems = Clockwork.kernel:RestoreSchemaData("hotkeys");
PhaseFour.stunEffects = {};

Clockwork.config:AddToSystem("Intro text small","intro_text_small", "The small text displayed for the introduction.");
Clockwork.config:AddToSystem("Intro text big", "intro_text_big", "The big text displayed for the introduction.");
Clockwork.config:AddToSystem("Alliance cost", "alliance_cost", "The amount of cash it costs to create an alliance.", 0, 10000);
Clockwork.config:AddToSystem("Maximum safebox weight", "max_safebox_weight", "The maximum weight a player's safebox can hold.", 0, 300);

Clockwork.datastream:Hook("Frequency", function(data)
	Derma_StringRequest("Frequency", "What would you like to set the frequency to?", data, function(text)
		Clockwork.kernel:RunCommand("SetFreq", text);
	end);	
end);

Clockwork.datastream:Hook("Notepad", function(data)
	if (PhaseFour.notepadPanel and PhaseFour.notepadPanel:IsValid()) then
		PhaseFour.notepadPanel:Close();
		PhaseFour.notepadPanel:Remove();
	end;
	
	PhaseFour.notepadPanel = vgui.Create("cw_Notepad");
	PhaseFour.notepadPanel:Populate(data or "");
	PhaseFour.notepadPanel:MakePopup();
	
	gui.EnableScreenClicker(true);
end);

Clockwork.datastream:Hook("HotkeyMenu", function(data)
	local hotkeyItems = {};
	
	for k, v in pairs(PhaseFour.hotkeyItems) do
		local itemTable = Clockwork.item:FindByID(v);
		
		if (itemTable and itemTable.OnUse) then
			hotkeyItems[#hotkeyItems + 1] = itemTable;
		end;
	end;
	
	if (hotkeyItems) then
		local options = {};
		
		for k, v in ipairs(hotkeyItems) do
			options[k..". "..v.name] = function()
				if (v.OnHandleUse) then
					v:OnHandleUse(function()
						Clockwork.kernel:RunCommand("InvAction", v.uniqueID, "use");
					end);
				else
					Clockwork.kernel:RunCommand("InvAction", v.uniqueID, "use");
				end;
			end;
		end;
		
		PhaseFour.hotkeyMenu = Clockwork.kernel:AddMenuFromData(nil, options);
		
		if (IsValid(PhaseFour.hotkeyMenu)) then
			print("i MADE IT HEH");
			PhaseFour.hotkeyMenu:SetPos(
				(ScrW() / 2) - (PhaseFour.hotkeyMenu:GetWide() / 2),
				(ScrH() / 2) - (PhaseFour.hotkeyMenu:GetTall() / 2)
			);
		end;
	end;
end);

Clockwork.datastream:Hook("TargetOutline", function(data)
	local curTime = CurTime();
	
	PhaseFour.targetOutlines[data] = curTime + 60;
end);


Clockwork.datastream:Hook("Disguise", function(data)
	Derma_StringRequest("Disguise", "Enter part of the character's name that you'd like to disguise as.", "", function(text)
		Clockwork.kernel:RunCommand("DisguiseSet", text);
	end);
end);

Clockwork.datastream:Hook("InviteAlliance", function(data)
	Derma_Query("Do you want to join the '"..data.."' alliance?", "Join Alliance", "Yes", function()
		Clockwork.datastream:Start("JoinAlliance", data);
		
		gui.EnableScreenClicker(false);
	end, "No", function()
		gui.EnableScreenClicker(false);
	end);
	
	gui.EnableScreenClicker(true);
end);

Clockwork.datastream:Hook("AllyKick", function(data)
	data:SetSharedVar("alliance", "");
	data:SetSharedVar("rank", RANK_RCT);
	
	if (IsValid(PhaseFour.alliancePanel)) then
		PhaseFour.alliancePanel:Rebuild();
	end;
end);

Clockwork.datastream:Hook("AllySetRank", function(data)
	data[1]:SetSharedVar("rank", data[2]);
	
	if (IsValid(PhaseFour.alliancePanel)) then
		PhaseFour.alliancePanel:Rebuild();
	end;
end);

Clockwork.datastream:Hook("CreateAlliance", function(data)
	Derma_StringRequest("Alliance", "What is the name of the alliance?", nil, function(text)
		Clockwork.datastream:Start("CreateAlliance", text);
	end);
end);

Clockwork.datastream:Hook("Death", function(data)
	if (type(data) == "boolean" or !IsValid(data)) then
		PhaseFour.deathType = "UNKNOWN CAUSES";
	else
		local itemTable = Clockwork.item:GetByWeapon(data);
		local class = data:GetClass();
		
		if (itemTable) then
			PhaseFour.deathType = "A "..string.upper(itemTable("name"));
		elseif (class == "cw_hands") then
			PhaseFour.deathType = "BEING PUNCHED TO DEATH";
		else
			PhaseFour.deathType = "UNKNOWN CAUSES";
		end;
	end;
end);

Clockwork.datastream:Hook("ShotEffect", function(data)
	local curTime = CurTime();
	
	if (!data or data == 0) then
		data = 0.5;
	end;
	
	PhaseFour.shotEffect = {curTime + data, data};
end);

Clockwork.datastream:Hook("TearGassed", function(data)
	PhaseFour.tearGassed = CurTime() + 25;
end);

Clockwork.datastream:Hook("Flashed", function(data)
	local curTime = CurTime();
	
	PhaseFour.stunEffects[#PhaseFour.stunEffects + 1] = {curTime + 10, 10};
	PhaseFour.flashEffect = {curTime + 20, 20};
	
	surface.PlaySound("hl1/fvox/flatline.wav");
end);

Clockwork.datastream:Hook("ClearEffects", function(data)
	PhaseFour.stunEffects = {};
	PhaseFour.flashEffect = nil;
	PhaseFour.tearGassed = nil;
	PhaseFour.shotEffect = nil;
end)

Clockwork.chatBox:RegisterClass("radio", "ic", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, Color(75, 150, 50, 255), info.name.." radios in \""..info.text.."\"");
end);

Clockwork.chatBox:RegisterClass("victory", "ooc", function(info)
	Clockwork.chatBox:Add(info.filtered, "icon16/star.png", info.speaker, " has achieved the ", Color(139, 174, 179, 255), info.text, " victory!");
end);

Clockwork.chatBox:RegisterClass("bounty", "ooc", function(info)
	Clockwork.chatBox:Add(info.filtered, nil, info.speaker, " has been given a new bounty. Their total bounty is ", Color(139, 174, 179, 255), tostring(Clockwork.kernel:FormatCash(tonumber(info.text), nil, true)), "!");
end);


local playerMeta = FindMetaTable("Player");

-- A function to get whether a player is good.
function playerMeta:IsGood()
	return self:GetSharedVar("honor") >= 50;
end;

-- A function to get whether a player is bad.
function playerMeta:IsBad()
	return self:GetSharedVar("honor") < 50;
end;

-- A function to get a player's bounty.
function playerMeta:GetBounty()
	return self:GetSharedVar("bounty");
end;

-- A function to get whether a player is wanted.
function playerMeta:IsWanted()
	return self:GetSharedVar("bounty") > 0;
end;

-- A function to get whether a player is a leader.
function playerMeta:IsLeader()
	return self:GetSharedVar("rank") == RANK_MAJ;
end;

-- A function to get a player's rank.
function playerMeta:GetRank(bString)
	local rank = self:GetSharedVar("rank");
	
	if (bString) then
		if (rank == RANK_PVT) then
			return "Pvt";
		elseif (rank == RANK_SGT) then
			return "Sgt";
		elseif (rank == RANK_LT) then
			return "Lt";
		elseif (rank == RANK_CPT) then
			return "Cpt";
		elseif (rank == RANK_MAJ) then
			return "Maj";
		else
			return "Rct";
		end;
	else
		return rank;
	end;
end;

-- A function to get a player's alliance.
function playerMeta:GetAlliance()
	local alliance = self:GetSharedVar("alliance");
	
	if (alliance != "") then
		return alliance;
	end;
end;

-- A function to get whether a text entry is being used.
function PhaseFour:IsTextEntryBeingUsed()
	if (self.textEntryFocused) then
		if (self.textEntryFocused:IsValid() and self.textEntryFocused:IsVisible()) then
			return true;
		end;
	end;
end;

local OUTLINE_MATERIAL = Material("white_outline");

-- A function to draw a basic outline.
function PhaseFour:DrawBasicOutline(entity, forceColor, throughWalls)
	local entityColor = entity:GetColor();
		local outlineColor = forceColor or Color(233, 100, 12, 255);

	
	if (throughWalls) then
		cam.IgnoreZ(true);
	end;
	
	render.SuppressEngineLighting(true);
	render.SetColorModulation(outlineColor.r / 255, outlineColor.g / 255, outlineColor.b / 255);
	render.SetAmbientLight(1, 1, 1);
	render.SetBlend(outlineColor.a / 255);
		entity:SetModelScale(1.025, 0);
			render.MaterialOverride(OUTLINE_MATERIAL);
				entity:DrawModel();
			render.MaterialOverride(nil);
		entity:SetModelScale(1, 0);
	render.SetBlend(1);
	render.SetColorModulation(entityColor.r / 255, entityColor.g / 255, entityColor.b / 255);
	render.SuppressEngineLighting(false);
	
	if (!throughWalls) then
		entity:DrawModel();
	else
		cam.IgnoreZ(false);
	end;
end;