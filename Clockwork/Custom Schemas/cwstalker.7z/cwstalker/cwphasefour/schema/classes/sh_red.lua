--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("Red Line");
	CLASS.color = Color(128, 0, 0, 255);
	CLASS.factions = {FACTION_RED};
	CLASS.isDefault = false;
	CLASS.description = "Red Line";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_RED = CLASS:Register();