--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("The Defenders of the Metro");
	CLASS.color = Color(130, 0, 0, 255);
	CLASS.factions = {FACTION_DEF};
	CLASS.isDefault = false;
	CLASS.description = "TDOTM";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_RED = CLASS:Register();