--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("Rangers");
	CLASS.color = Color(125, 249, 255, 255);
	CLASS.factions = {FACTION_RANGERS};
	CLASS.isDefault = false;
	CLASS.description = "Rangers";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_RANGERS = CLASS:Register();