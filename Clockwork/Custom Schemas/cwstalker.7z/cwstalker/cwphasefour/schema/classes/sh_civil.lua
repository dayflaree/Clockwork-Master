--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Survivors");
	CLASS.color = Color(112, 128, 144, 255);
	CLASS.factions = {FACTION_CIVILIAN};
	CLASS.isDefault = true;
	CLASS.description = "Survivors";
	CLASS.defaultPhysDesc = "Wearing tattered clothing";
CLASS_CIVILIAN = CLASS:Register();