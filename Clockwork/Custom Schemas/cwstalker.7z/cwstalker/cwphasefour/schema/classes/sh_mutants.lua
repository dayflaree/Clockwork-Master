--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("Mutants");
	CLASS.color = Color(225, 0, 0, 255);
	CLASS.factions = {FACTION_MUTANTS};
	CLASS.isDefault = false;
	CLASS.wagesName = "Supplies";
	CLASS.description = "Donate Admin";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_MUTANTS = CLASS:Register();