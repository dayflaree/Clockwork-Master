--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("Dark");
	CLASS.color = Color(0, 0, 0, 255);
	CLASS.factions = {FACTION_DARK};
	CLASS.isDefault = false;
	CLASS.wagesName = "Supplies";
	CLASS.description = "The Fraction Portal";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_DARK = CLASS:Register();