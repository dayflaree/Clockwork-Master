--[[
	� 2013 by Portal
--]]

local CLASS = Clockwork.class:New("4th Reich");
	CLASS.color = Color(0, 0, 102, 255);
	CLASS.factions = {FACTION_REICH};
	CLASS.isDefault = false;
	CLASS.description = "4th Reich's member";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_REICH = CLASS:Register();