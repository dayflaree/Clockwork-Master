--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Canadian Armed Forces");
	CLASS.color = Color(0, 128, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_CARMY}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.wagesName = "wages"; -- What is the name of the "wages" for this class.
	CLASS.description = "A soldier serving for Canadian Armed Forces."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Wearing Standard Issued Canadian Army Uniform."; -- The default physical description for this class.
CLASS_CARMY = CLASS:Register();