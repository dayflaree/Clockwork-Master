--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Canadian Armed Forces");
	FACTION.isWhitelisted = false; -- Do we need to be whitelisted to select this faction?
	FACTION.useFullName = true; -- Do we allow players to enter a full name, otherwise it only lets them select a first and second.
--	FACTION.material = "path/to/material"; -- The path to the faction material (shown on the creation screen).

FACTION.models = {
	female = {
		"models/army/female_01.mdl",
		"models/army/female_02.mdl",
		"models/army/female_03.mdl",
		"models/army/female_04.mdl",
		"models/army/female_05.mdl",
		"models/army/female_06.mdl",
		"models/army/female_07.mdl"
	},
	male = {
		"models/rusty/natguard/male_01_oc.mdl",
		"models/rusty/natguard/male_02_oc.mdl",
		"models/rusty/natguard/male_03_oc.mdl",
		"models/rusty/natguard/male_04_oc.mdl",
		"models/rusty/natguard/male_05_oc.mdl",
		"models/rusty/natguard/male_06_oc.mdl",
		"models/rusty/natguard/male_07_oc.mdl",
		"models/rusty/natguard/male_08_oc.mdl",
		"models/rusty/natguard/male_09_oc.mdl"
	};
};

FACTION_CARMY = FACTION:Register();