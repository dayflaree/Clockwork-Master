--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("United States Armed Forces");
	FACTION.isWhitelisted = false; -- Do we need to be whitelisted to select this faction?
	FACTION.useFullName = true; -- Do we allow players to enter a full name, otherwise it only lets them select a first and second.
--	FACTION.material = "path/to/material"; -- The path to the faction material (shown on the creation screen).

FACTION.models = {
	female = {
		"models/army/female_01.mdl",
		"models/army/female_02.mdl",
		"models/army/female_03.mdl",
		"models/army/female_04.mdl",
		"models/army/female_05.mdl",
		"models/army/female_06.mdl",
		"models/army/female_07.mdl"
	},
	male = {
		"models/rusty/natguard/male_01_nc.mdl",
		"models/rusty/natguard/male_02_nc.mdl",
		"models/rusty/natguard/male_03_nc.mdl",
		"models/rusty/natguard/male_04_nc.mdl",
		"models/rusty/natguard/male_05_nc.mdl",
		"models/rusty/natguard/male_06_nc.mdl",
		"models/rusty/natguard/male_07_nc.mdl",
		"models/rusty/natguard/male_08_nc.mdl",
		"models/rusty/natguard/male_09_nc.mdl"
	
	};
};


FACTION_USARMY = FACTION:Register();