--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Schema.voices = Clockwork.kernel:NewLibrary("Voices");
Schema.voices.stored = {
	normalVoices = {},
	dispatchVoices = {}
};

-- A function to add a voice.
function Schema.voices:Add(faction, command, phrase, sound, female, menu)
	self.stored.normalVoices[#self.stored.normalVoices + 1] = {
		command = command,
		faction = faction,
		phrase = phrase,
		female = female,
		sound = sound,
		menu = menu
	};
end;

--voices go here.

if (CLIENT) then
	table.sort(Schema.voices.stored.normalVoices, function(a, b) return a.command < b.command; end);

	for k, v in pairs(Schema.voices.stored.normalVoices) do
		Clockwork.directory:AddCode("Soldier", [[
			<div class="auraInfoTitle">]]..string.upper(v.command)..[[</div>
			<div class="auraInfoText">]]..v.phrase..[[</div>
		]], true);
	end;
end;