--[[
	Name: sh_info.lua.
	Author: LauScript
--]]

local PLUGIN = PLUGIN;