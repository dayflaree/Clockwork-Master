--[[
	Name: cl_hooks.lua.
	Author: TJjokerR.
--]]

local PLUGIN = PLUGIN;

function PLUGIN:GetPlayerInfoText(playerInfoText)
	local battery = Clockwork.Client:GetSharedVar("Battery");
	if (battery) then
		playerInfoText:Add("BAT", "Battery Level: "..battery);
	end;
end;