--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Dark Energy";
	ITEM.cost = 30;
	ITEM.classes = {CLASS_EENG};
	ITEM.model = "models/items/combine_rifle_cartridge01.mdl";
	ITEM.plural = "Dark Energy";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_ar2";
	ITEM.business = true;
	ITEM.ammoClass = "ar2";
	ITEM.ammoAmount = 30;
	ITEM.description = "A cartridge with a blue tint to it.";
ITEM:Register();