--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Enforcer Standard Soldier");
	CLASS.color = Color(150, 50, 50, 255);
	CLASS.wages = 50;
	CLASS.factions = {FACTION_ENF};
	CLASS.wagesName = "Gear";
	CLASS.description = "An Enforcer, sent by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing standard Enforcer gear";
CLASS_ENF = CLASS:Register();