--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Elite Enforcer");
	CLASS.color = Color(150, 50, 50, 255);
	CLASS.wages = 70;
	CLASS.factions = {FACTION_ENF};
	CLASS.wagesName = "Gear";
	CLASS.maleModel = "models/combine_super_soldier.mdl";
	CLASS.description = "An elite Enforcer, sent by the Universal Union";
	CLASS.defaultPhysDesc = "Wearing shiny Enforcer gear";
CLASS_EENF = CLASS:Register();