--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Laborer's");
	CLASS.color = Color(150, 130, 110, 255);
	CLASS.factions = {FACTION_LABOR};
	CLASS.wages = 5;
	CLASS.isDefault = false;
	CLASS.wagesName = "Paycheck";
	CLASS.description = "A upper-class human citizen enslaved by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing a clean uniform";
CLASS_LABORER = CLASS:Register();