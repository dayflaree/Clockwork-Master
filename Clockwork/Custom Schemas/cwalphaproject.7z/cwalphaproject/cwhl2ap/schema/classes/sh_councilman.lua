--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Councilman");
	CLASS.color = Color(210, 80, 110, 255);
	CLASS.wages = 50;
	CLASS.factions = {FACTION_COUNCIL};
	CLASS.isDefault = true;
	CLASS.wagesName = "Net Growth";
	CLASS.description = "A new world order councilman.";
	CLASS.defaultPhysDesc = "Wearing a clean suit.";
CLASS_COUNCILMAN = CLASS:Register();