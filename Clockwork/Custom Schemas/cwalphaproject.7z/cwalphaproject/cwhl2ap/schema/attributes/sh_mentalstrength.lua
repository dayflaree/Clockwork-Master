--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Mental Strength";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "end";
	ATTRIBUTE.description = "Affects how strong your brain is. IE. How well you can take pain.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_ENDURANCE = Clockwork.attribute:Register(ATTRIBUTE);