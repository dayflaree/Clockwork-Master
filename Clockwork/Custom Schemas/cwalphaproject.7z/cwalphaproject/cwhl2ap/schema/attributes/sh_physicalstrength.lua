--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Physical Strength";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "str";
	ATTRIBUTE.description = "How strong you are physically, IE. Your Punches ";
	ATTRIBUTE.isOnCharScreen = true;
ATB_STRENGTH = Clockwork.attribute:Register(ATTRIBUTE);