--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Quick Hands";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "qhands";
	ATTRIBUTE.description = "Affects the speed of your hands. IE. How fast you can tie/untie someone.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_DEXTERITY = Clockwork.attribute:Register(ATTRIBUTE);