--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Immunity";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "imm";
	ATTRIBUTE.description = "Affects how well you can be treated when sick. IE. Health Vials, Medkits, etc.";
	ATTRIBUTE.isOnCharScreen = true;
ATB_MEDICAL = Clockwork.attribute:Register(ATTRIBUTE);