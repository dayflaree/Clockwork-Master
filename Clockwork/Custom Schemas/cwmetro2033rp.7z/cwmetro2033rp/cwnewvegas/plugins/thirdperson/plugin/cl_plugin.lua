local PLUGIN = PLUGIN;

Clockwork.setting:AddCheckBox("Framework", "Enable third person view.", "cwThirdPerson", "Whether or not to enable third person view.");