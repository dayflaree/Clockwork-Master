IMPORTANT:You NEED M9K small arms, heavy weapons, and assault rifles mounted to the server to use all of these. You CAN remove the lua files that you do not need or want.

Flags are as follow: d = Shotgun and Assault rifles. f = Pistols and Submachine guns. F = Snipers and LMGs.