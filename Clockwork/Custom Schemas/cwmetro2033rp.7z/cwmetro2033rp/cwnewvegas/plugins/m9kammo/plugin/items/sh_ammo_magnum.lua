--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = ".44 Magnum Rounds";
	ITEM.cost = 30;
	ITEM.batch = 5;
	ITEM.model = "models/items/357ammo.mdl";
	ITEM.weight = 1;
	ITEM.access = "D";
	ITEM.uniqueID = "m9k_ammo_357";
	ITEM.business = true;
	ITEM.ammoClass = "357";
	ITEM.ammoAmount = 20;
	ITEM.description = "A small box filled with bullets and .44 printed on the side.";
ITEM:Register();
