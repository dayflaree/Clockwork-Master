--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = ".50 Rounds";
	ITEM.cost = 125;
	ITEM.model = "models/items/sniper_round_box.mdl";
	ITEM.weight = 1.5;
	ITEM.access = "D";
	ITEM.uniqueID = "m9k_ammo_sniper_rounds";
	ITEM.business = true;
	ITEM.ammoClass = "ar2";
	ITEM.ammoAmount = 12;
	ITEM.description = "A small box filled with bullets and .50 printed on the side.";
ITEM:Register();
