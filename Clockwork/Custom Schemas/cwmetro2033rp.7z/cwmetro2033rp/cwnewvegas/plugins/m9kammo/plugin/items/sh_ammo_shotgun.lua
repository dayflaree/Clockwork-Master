--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Buckshot Shells";
	ITEM.cost = 100;
	ITEM.batch = 5;
	ITEM.model = "models/items/boxbuckshot.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "m9k_ammo_buckshot";
	ITEM.business = true;
	ITEM.ammoClass = "buckshot";
	ITEM.ammoAmount = 16;
	ITEM.access = "D";
	ITEM.description = "A red box filled with shells. It has 'Buckshot' on the side.";
ITEM:Register();