--[[
	� 2012 CloudSixteen.com share, re-distribute and modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "5.56mm Bullets";
	ITEM.cost = 30;
	ITEM.model = "models/items/boxmrounds.mdl";
	ITEM.weight = 2;
	ITEM.batch = 5;
	ITEM.access = "D";
	ITEM.uniqueID = "m9k_ammo_smg";
	ITEM.business = true;
	ITEM.ammoClass = "smg1";
	ITEM.ammoAmount = 30;
	ITEM.description = "A heavy container filled with a lot of bullets. It has 5.56mm on the side.";
ITEM:Register();