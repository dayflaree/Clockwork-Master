Please make sure you have this downloaded on your server to prevent errors: 
http://steamcommunity.com/sharedfiles/filedetails/?id=146602537&searchtext=Bioshock+Infinite

Thanks to Tonttunator for making me aware of this pack through his plugin.