--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Cereal";
ITEM.cost = 15;
ITEM.model = "models/bioshockinfinite/loot_cereal_box_cornflakes.mdl";
ITEM.weight = 0.8;
ITEM.access = "l";
ITEM.useText = "Consume";
ITEM.category = "Food";
ITEM.business = true;
ITEM.description = "A mini packet of cereal. Just enough for breakfast.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 6, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 4, 120);
	player:BoostAttribute(self.name, ATB_STAMINA, 9, 120);
	-- Mmm.. Warm bread.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();