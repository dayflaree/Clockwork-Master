--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Pear";
ITEM.cost = 15;
ITEM.model = "models/bioshockinfinite/loot_pear.mdl";
ITEM.weight = 0.4;
ITEM.access = "l";
ITEM.useText = "Consume";
ITEM.category = "Fruit";
ITEM.business = true;
ITEM.description = "A fresh, green, dotted pear.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 8, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_STRENGTH, 5, 120);
	-- Pears.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();