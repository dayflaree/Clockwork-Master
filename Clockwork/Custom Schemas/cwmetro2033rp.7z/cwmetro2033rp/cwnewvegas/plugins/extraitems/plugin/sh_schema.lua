local PLUGIN = PLUGIN;

Clockwork.flag:Add("l", "Extra Items", "Permission to purchase Extra Items from the buisness menu.");
Clockwork.flag:Add("L", "Extra Items (Special)", "Permission to purchase special Extra Items from the buisness menu.");
Clockwork.flag:Add("P", "Alcohol and Cigarettes", "Permission to purchase alcohol from the buisness menu.");
Clockwork.flag:Add("D", "Drugs and Cigarettes", "Permission to purchase drugs and cigarettes from the buisness menu.");