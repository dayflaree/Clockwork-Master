--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Buttered Toast";
ITEM.cost = 24;
ITEM.model = "models/bioshockinfinite/sandwich.mdl";
ITEM.weight = 0.8;
ITEM.access = "l";
ITEM.useText = "Consume";
ITEM.category = "Food";
ITEM.business = true;
ITEM.description = "A stale looking toasted piece of bread. It is lightly covered with butter.";

function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 12, 0, player:GetMaxHealth() ) );
	
	player:BoostAttribute(self.name, ATB_ENDURANCE, 2, 120);
	player:BoostAttribute(self.name, ATB_STRENGTH, 2, 120);
	player:BoostAttribute(self.name, ATB_STAMINA, 2, 120);
	-- Mmm.. Warm bread.
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();