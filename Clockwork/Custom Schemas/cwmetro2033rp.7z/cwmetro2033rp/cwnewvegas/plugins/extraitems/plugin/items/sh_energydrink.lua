--[[
	© 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Energy Drink";
ITEM.cost = 25;
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl";
ITEM.weight = 1.1;
ITEM.access = "L";
ITEM.useText = "Drink";
ITEM.category = "Consumables";
ITEM.business = true;
ITEM.description = "An orange bottle labelled 'Energy Drink MAX'.  It seems to be filled with caffiene.";

function ITEM:OnUse(player, itemEntity)
	player:SetSharedVar("antidepressants", CurTime() + 15);

	player:BoostAttribute(self.name, ATB_AGILITY, 15, 120);
	player:BoostAttribute(self.name, ATB_STAMINA, 15, 120);

end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) 

end;


ITEM:Register();