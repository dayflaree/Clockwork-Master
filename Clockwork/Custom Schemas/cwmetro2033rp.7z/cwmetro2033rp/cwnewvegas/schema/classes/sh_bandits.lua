--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(165, 155, 95, 255);
	CLASS.factions = {FACTION_BANDITS};
	CLASS.isDefault = true;
	CLASS.description = "A bandit - don't get in their way.";
	CLASS.defaultPhysDesc = "Wearing dirty clothes and a small satchel";
CLASS_BANDITS = Clockwork.class:Register(CLASS, "Bandits");