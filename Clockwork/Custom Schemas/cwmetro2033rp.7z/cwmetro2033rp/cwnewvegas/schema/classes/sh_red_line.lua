--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(200, 200, 50, 255);
	CLASS.factions = {FACTION_REDLINE};
	CLASS.isDefault = true;
	CLASS.description = "A soldier of the Red Line.";
	CLASS.defaultPhysDesc = "Red Lime Soldier with a Red Line outfit.";
CLASS_REDLINE = Clockwork.class:Register(CLASS, "Red Line");