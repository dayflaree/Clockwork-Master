--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New();
	CLASS.color = Color(165, 155, 95, 255);
	CLASS.factions = {FACTION_RANGERS};
	CLASS.isDefault = true;
	CLASS.description = "A soldier of the Ranegr Order.";
	CLASS.defaultPhysDesc = "Wearing defult issued Ranger clothing";
CLASS_RANGERS = Clockwork.class:Register(CLASS, "Rangers");