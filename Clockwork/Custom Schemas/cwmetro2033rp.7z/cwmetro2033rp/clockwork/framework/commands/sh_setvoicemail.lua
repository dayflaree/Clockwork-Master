--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SetVoicemail");
COMMAND.tip = "Set your personal message voicemail.";
COMMAND.text = "[string Text]";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (arguments[1] == "none") then
		player:SetCharacterData("Voicemail", nil);
		Clockwork.player:Notify(player, "You have removed your voicemail.");
	else
		player:SetCharacterData("Voicemail", arguments[1]);
		Clockwork.player:Notify(player, "You have set your voicemail to '"..arguments[1].."'.");
	end;
end;

COMMAND:Register();