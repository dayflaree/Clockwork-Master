--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "AMD-65";
	ITEM.cost = 1600;
	ITEM.model = "models/weapons/w_amd_65.mdl";
	ITEM.weight = 3;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "m9k_amd65";
	ITEM.description = "A grey metal assault rifle with a tactical stock.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();