--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("weapon_base");
        ITEM.name = "Dragunov SVD";
        ITEM.cost = 2100;
        ITEM.model = "models/weapons/w_svd_dragunov.mdl";
        ITEM.weight = 2.6;
		ITEM.access = "V";
        ITEM.business = true;
        ITEM.uniqueID = "m9k_dragunov";
        ITEM.description = "A sniper rifle manafactured in Russia which consists of metal and wood.";
        ITEM.isAttachment = true;
        ITEM.hasFlashlight = false;
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();