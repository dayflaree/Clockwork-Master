--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "P229";
	ITEM.cost = 1600;
	ITEM.model = "models/weapons/w_sig_229r.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.business = true;
	ITEM.uniqueID = "m9k_sig_p229r";
	ITEM.description = "A pistol with a tactical sight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = false;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();