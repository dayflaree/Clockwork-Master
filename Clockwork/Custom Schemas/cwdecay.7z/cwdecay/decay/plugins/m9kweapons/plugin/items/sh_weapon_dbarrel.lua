--[[
        � 2013 CloudSixteen.com do not share, re-distribute or modify
        without permission of its author (kurozael@gmail.com).
--]]
 
local ITEM = Clockwork.item:New("weapon_base");
        ITEM.name = "Double Barrel Shotgun";
        ITEM.cost = 800;
        ITEM.model = "models/weapons/w_double_barrel_shotgun.mdl";
        ITEM.weight = 2;
		ITEM.access = "V";
        ITEM.business = true;
        ITEM.uniqueID = "m9k_dbarrel";
        ITEM.description = "A shotgun with two barrels and two triggers...";
        ITEM.isAttachment = true;
        ITEM.hasFlashlight = false;
        ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
        ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
        ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();