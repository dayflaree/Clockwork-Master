local Clockwork = Clockwork;

Clockwork.config:Add("advert_interval", 60);