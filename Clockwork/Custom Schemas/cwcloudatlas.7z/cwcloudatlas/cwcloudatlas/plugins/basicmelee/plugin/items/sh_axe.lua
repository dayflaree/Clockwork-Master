--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Splitting Axe";
	ITEM.cost = 15;
	ITEM.model = "models/weapons/w_axe.mdl";
	ITEM.weight = 1;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_axe";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A rusty Valleymen axe. It can be used to cut wood and to defend one's self.";
	ITEM.value = 0.3;
	ITEM.spawncategory = 7;
ITEM:Register();