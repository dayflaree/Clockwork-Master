--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Shovel";
	ITEM.cost = 15;
	ITEM.model = "models/weapons/w_shovel.mdl";
	ITEM.weight = 1;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_shovel";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A Kona combat shovel. It can be used to dig, but one can also use it for self-defense.";
	ITEM.value = 0.1;
	ITEM.spawncategory = 7;
ITEM:Register();