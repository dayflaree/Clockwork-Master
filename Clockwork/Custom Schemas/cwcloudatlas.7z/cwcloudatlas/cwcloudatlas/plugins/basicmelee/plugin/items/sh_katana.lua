--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Nea So Corpros Sword";
	ITEM.cost = 1000;
	ITEM.model = "models/weapons/w_katana.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_katana";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A sharp, heavt katana wielded by high ranking Enforcers of Neo Seoul.";
	ITEM.value = 0.9;
	ITEM.spawncategory = 7;
ITEM:Register();