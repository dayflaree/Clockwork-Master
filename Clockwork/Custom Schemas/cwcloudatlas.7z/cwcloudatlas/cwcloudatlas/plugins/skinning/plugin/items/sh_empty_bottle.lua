local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Empty Bottle";
	ITEM.worth = 1;
	ITEM.access = "j";
	ITEM.model = "models/props_junk/garbage_glassbottle001a.mdl";
	ITEM.weight = 0.1
	ITEM.description = "An empty bottle made of glass, it smells like beer.";
Clockwork.item:Register(ITEM);