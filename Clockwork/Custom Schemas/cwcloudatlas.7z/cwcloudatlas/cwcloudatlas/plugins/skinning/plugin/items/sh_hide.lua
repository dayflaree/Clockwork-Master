local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Hide
	ITEM.model = "models/gibs/gunship_gibs_wing.mdl";
	ITEM.weight = 0.35;
	ITEM.access = "j";
	ITEM.plural = "Hide";
	ITEM.useText = "Sell";
	ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
	ITEM.category = "Junk"
	ITEM.description = "A hide taken from an animal.";

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/flesh");
	end;
Clockwork.item:Register(ITEM);