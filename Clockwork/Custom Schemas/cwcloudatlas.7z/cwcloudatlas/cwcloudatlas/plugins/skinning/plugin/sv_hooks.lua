function Schema:GetEntityMenuOptions(entity, options)
	if (entity:GetClass() == "prop_ragdoll") then
		local player = Clockwork.entity:GetPlayer(entity);
		
		if ( !player or !player:Alive() ) then
			options["Skin"] = "cw_corpseskin";
		end;

function Schema:EntityHandleMenuOption(player, entity, option, arguments)
	if (entity:GetClass() == "prop_ragdoll") then
		if (arguments == "cw_corpseskin") then
			local entityPlayer = Clockwork.entity:GetPlayer(entity);
			local trace = player:GetEyeTraceNoCursor();
			
			if ( !entityPlayer or !entityPlayer:Alive() ) then
				if (!entity.mutilated or entity.mutilated < 3) then
					entity.mutilated = (entity.mutilated or 0) + 1;
						local instance = Clockwork.item:CreateInstance("sh_meat"); Clockwork.item:CreateInstance("sh_hide");

						player:GiveItem(instance, true);
						player:EmitSound("npc/barnacle/barnacle_crunch"..math.random(2, 3)..".wav");
					Clockwork.kernel:CreateBloodEffects(entity:NearestPoint(trace.HitPos), 1, entity);
				end;
			end;
		end;
