local ITEM = Clockwork.item:New("junk_base");
	ITEM.name = "Wood";
	ITEM.worth = 1;
	ITEM.access = "j";
	ITEM.model = "models/Gibs/wood_gib01a.mdl";
	ITEM.weight = 0.1
	ITEM.description = "Some wood.";
Clockwork.item:Register(ITEM);