local ITEM = Clockwork.item:New();
	ITEM.name = "Meat";
	ITEM.model = "models/Gibs/Antlion_gib_small_2.mdl";
	ITEM.weight = 0.35;
	ITEM.plural = "Meat";
	ITEM.useText = "Eat";
	ITEM.access = "j";
	ITEM.useSound = "npc/barnacle/barnacle_crunch3.wav";
	ITEM.category = "Consumables"
	ITEM.isRareItem = true;
	ITEM.description = "Meat taken from an animal.";

	-- Called when a player uses the item.
	function ITEM:OnUse(player, itemEntity)
		player:SetHealth( math.Clamp(player:Health() + 8, 0, 100) );
	end;

	-- Called when a player drops the item.
	function ITEM:OnDrop(player, position) end;

	-- Called when the item entity has spawned.
	function ITEM:OnEntitySpawned(entity)
		entity:SetMaterial("models/flesh");
	end;
Clockwork.item:Register(ITEM);