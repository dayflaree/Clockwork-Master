--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:AddDirectory("materials/skeleton/");

Clockwork.config:Add("intro_text_big", "Example Big Text.", true);
Clockwork.config:Add("intro_text_small", "Example Little Text.", true);

Clockwork.hint:Add("Universe", "It is 300 years after a massive nuclear war. Vegetation has had time to recover.");
Clockwork.hint:Add("World", "Vegitation has recovered post-nuke, however, tribers have grown resistant to radiation.");
Clockwork.hint:Add("Kona", "The Kona are brutal cannibals, who are not to be reckoned with.");
Clockwork.hint:Add("Prescient", "The Prescients are smart and civilized, and they retain knowledge of firearms.");
Clockwork.hint:Add("Valley", "The Valleymen are street-smart goat herders, or forest-smart that is.");
Clockwork.hint:Add("Hilo", "The Hilo are travelling trading tribes. Agents can be found around the island.");
Clockwork.hint:Add("Hon", "Honokaa Barter is an annual festival where tribes meet to trade proprietary goods.");
Clockwork.hint:Add("Le Hero", "Are you a hero? Would you shoot or stab innocents without remorse? If so, you are not FearRPing.");
Clockwork.hint:Add("Unanimity", "The Unanimity where the governing forces of Nea So Corpros, but what happened to them?");
Clockwork.hint:Add("Sonmi-451", "Sonmi is a graceful goddess. She guides the Valleymen and the Prescients, among other tribes, to fortune.");
Clockwork.hint:Add("Old Georgie", "There is a natural order to this world, and those who try to upend it will not fare well.");
Clockwork.hint:Add("Hunting", "Wild deer inhabit Hawaii. Hunt and collect hides to use as currency, and to better your tribe.");
Clockwork.hint:Add("Pre", "Some say the Prescient ship is powered by fusion engines, whatever those are.");
Clockwork.hint:Add("Papa Songs", "Legacy soda and fast food that remains bear a mysterious Papa Songs logo.");
Clockwork.hint:Add("Clones", "Hewitt-marked fabricants may remain on the island, and often do not reveal themselves.");
Clockwork.hint:Add("Building", "Help construct your tribe's living establishments, for both comfort and utility.");
Clockwork.hint:Add("Weapons", "Melee weapons and bows are the most common of weapons on Hawaii.");
Clockwork.hint:Add("Guns", "Firearms are a myth.");
Clockwork.hint:Add("power", "Do not force your actions upon others; That is called Powergaming.");
Clockwork.hint:Add("Meta", "Metagaming is using OOC information to prompt IC actions.");
Clockwork.hint:Add("Health", "Do not pull a knife out after being stabbed; Leaving it in will seal in blood from any arteries or vessels.");
Clockwork.hint:Add("Island", "Big I is slang for the main island of Hawaii.");
Clockwork.hint:Add("Truth", "Tru-Tru is slang for the absolute truth.");
Clockwork.hint:Add("Sunnup and sundown", "Sunnup is slang for morning, while sundown is slang for nightfall.");
Clockwork.hint:Add("Obs", "The Observatory is rumored to house a fangy devil, Old Georgie.");