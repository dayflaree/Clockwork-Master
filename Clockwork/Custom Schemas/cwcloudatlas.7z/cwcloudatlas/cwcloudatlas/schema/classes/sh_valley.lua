--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Triber");

CLASS.color = Color(2, 142, 27, 200); -- The color of this class.
CLASS.factions = {FACTION_VALLEY}; -- Which factions can select this class.
CLASS.isDefault = true; -- Is this the default class for these factions?
CLASS.wagesName = "Supplies"; -- What is the name of the "wages" for this class.
CLASS.description = "A tribesman of the island Ha-Why."; -- A short description of the class.
CLASS.defaultPhysDesc = "A triber. He could be of one of the three tribes."; -- The default physical description for this class.

CLASS_VALLEY = CLASS:Register();