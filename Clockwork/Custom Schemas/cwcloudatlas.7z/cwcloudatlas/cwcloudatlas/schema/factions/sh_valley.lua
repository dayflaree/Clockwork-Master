--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Valleymen");

FACTION.useFullName = true;
FACTION.material = "halfliferp/factions/valley";
FACTION.whitelist = false;
FACTION.models = {
	female = {
		"models/stalkertnb/bandit_cup2.mdl",
		"models/stalkertnb/bandit_dalla2.mdl",
		"models/stalkertnb/bandit_dogflower.mdl",
		"models/stalkertnb/bandit_female1.mdl",
		"models/stalkertnb/bandit_female3.mdl",
		"models/stalkertnb/bandit_female6.mdl",
		"models/stalkertnb/bandit_keep.mdl",
		"models/stalkertnb/bandit_nayalita.mdl",
		"models/stalkertnb/bandit_pink.mdl",
		"models/stalkertnb/bandit_rooster.mdl",
		"models/stalkertnb/bandit_vice.mdl",
		"models/stalkertnb/io7a_blonde.mdl",
		"models/stalkertnb/io7a_brunette.mdl",
		"models/stalkertnb/io7a_kate.mdl",
		"models/stalkertnb/psz9d_free_bird.mdl",
		"models/stalkertnb/psz9d_free_cawlin.mdl",
		"models/stalkertnb/psz9d_nazca.mdl",
		"models/stalkertnb/psz9d_ybarra2.mdl",
		"models/stalkertnb/rad_eagle.mdl",
		"models/stalkertnb/rad_zoya.mdl",
		"models/stalkertnb/seva_bird.mdl",
		"models/stalkertnb/sunrise_ana.mdl",
		"models/stalkertnb/sunrise_belowthebelt.mdl",
		"models/stalkertnb/sunrise_crimson.mdl",
		"models/stalkertnb/sunrise_dolch.mdl",
		"models/stalkertnb/sunrise_kate.mdl",
		"models/stalkertnb/sunrise_nayalita.mdl",
		"models/stalkertnb/sunrise_nazca.mdl",
		"models/stalkertnb/sunrise_nico.mdl",
		"models/stalkertnb/sunrise_trace.mdl",
		"models/stalkertnb/sunrise_xarec2.mdl"
	},
	male = {
		"models/stalkertnb/bandit_belowthebelt.mdl",
		"models/stalkertnb/bandit_capt.mdl",
		"models/stalkertnb/bandit_dalla1.mdl",
		"models/stalkertnb/bandit_das.mdl",
		"models/stalkertnb/bandit_hour.mdl",
		"models/stalkertnb/bandit_jack.mdl",
		"models/stalkertnb/bandit_journalist.mdl"
		"models/stalkertnb/bandit_male1.mdl",
		"models/stalkertnb/bandit_male2.mdl",
		"models/stalkertnb/bandit_male4.mdl",
		"models/stalkertnb/bandit_male40.mdl",
		"models/stalkertnb/bandit_overwatch.mdl",
		"models/stalkertnb/bandit_runner.mdl",
		"models/stalkertnb/bandit_shifty.mdl",
		"models/stalkertnb/bandit_smithy.mdl",
		"models/stalkertnb/bandit_zaku.mdl",
		"models/stalkertnb/cs2_adaption.mdl",  
		"models/stalkertnb/cs2_shisno.mdl",
		"models/stalkertnb/dave_bandit.mdl",
		"models/stalkertnb/io7a_jihad.mdl",
		"models/stalkertnb/io7a_splint.mdl",
		"models/stalkertnb/nikolai.mdl",
		"models/stalkertnb/psz9d_makarov.mdl",
		"models/stalkertnb/skat_rux.mdl",
		"models/stalkertnb/sunrise_captd2.mdl",
		"models/stalkertnb/sunrise_dima.mdl",
		"models/stalkertnb/sunrise_jem.mdl",
		"models/stalkertnb/sunrise_journalist.mdl",
		"models/stalkertnb/sunrise_kasparov.mdl",
		"models/stalkertnb/sunrise_scrote.mdl",
		"models/stalkertnb/sunrise_waptnt.mdl",
		"models/stalkertnb/sunrise_waptnt2.mdl",
		"models/stalkertnb/sunrise_ybarra.mdl",
		"models/stalkertnb/sunrise_zaku.mdl"
	};
};

FACTION_VALLEY = FACTION:Register();