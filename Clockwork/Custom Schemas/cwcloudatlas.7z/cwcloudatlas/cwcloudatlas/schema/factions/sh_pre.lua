local FACTION = Clockwork.faction:New("Prescient");

FACTION.useFullName = true;
FACTION.material = "halfliferp/factions/prescients";
FACTION.whitelist = true;
FACTION.models = {
	female = {
		"models/stalkertnb/bandit_brandon.mdl",
		"models/stalkertnb/bandit_chav4.mdl",
		"models/stalkertnb/bandit_eagle.mdl",
		"models/stalkertnb/bandit_female2.mdl",
		"models/stalkertnb/bandit_female4.mdl",
		"models/stalkertnb/bandit_female71.mdl",
		"models/stalkertnb/bandit_female8.mdl",
		"models/stalkertnb/bandit_hellfang.mdl",
		"models/stalkertnb/bandit_little.mdl",
		"models/stalkertnb/bandit_pink.mdl",
		"models/stalkertnb/bandit_reager.mdl",
		"models/stalkertnb/bandit_rosa.mdl",
		"models/stalkertnb/bandit_val.mdl",
		"models/stalkertnb/bandit_zaku4.mdl",
		"models/stalkertnb/psz9d_blonde.mdl",
		"models/stalkertnb/psz9d_brandon.mdl",
		"models/stalkertnb/psz9d_free_rensai.mdl",
		"models/stalkertnb/psz9d_reager.mdl",
		"models/stalkertnb/sunrise_ana2.mdl",
		"models/stalkertnb/sunrise_bean.mdl",
		"models/stalkertnb/sunrise_desrat.mdl",
		"models/stalkertnb/sunrise_dogflower.mdl",
		"models/stalkertnb/sunrise_hellfang.mdl",
		"models/stalkertnb/sunrise_ltdead.mdl",
		"models/stalkertnb/sunrise_rooster.mdl",
		"models/stalkertnb/sunrise_rosa.mdl"
	},
	male = {
		"models/stalkertnb/bandit_altair.mdl",
		"models/stalkertnb/bandit_chav3.mdl",
		"models/stalkertnb/bandit_edgar.mdl",
		"models/stalkertnb/bandit_flare.mdl",
		"models/stalkertnb/bandit_jester.mdl",
		"models/stalkertnb/bandit_male3.mdl",
		"models/stalkertnb/bandit_male5.mdl",
		"models/stalkertnb/bandit_muffin.mdl",
		"models/stalkertnb/bandit_nirri.mdl",
		"models/stalkertnb/bandit_splint.mdl",
		"models/stalkertnb/bandit_zaku2.mdl",
		"models/stalkertnb/cs1_altair.mdl",
		"models/stalkertnb/cs1_snood.mdl",
		"models/stalkertnb/cs2_rick.mdl",
		"models/stalkertnb/cs2_vivid.mdl",
		"models/stalkertnb/cs3_wolves.mdl",
		"models/stalkertnb/io7a_dima.mdl",
		"models/stalkertnb/io7a_jacque.mdl",
		"models/stalkertnb/psz9d_kibwe.mdl",
		"models/stalkertnb/psz9d_pool.mdl",
		"models/stalkertnb/seva_blonde.mdl",
		"models/stalkertnb/sunrise_capt.mdl",
		"models/stalkertnb/sunrise_secro.mdl",
		"models/stalkertnb/sunrise_wolfie.mdl",
		"models/stalkertnb/sunrise_xarec.mdl"
	};
};

FACTION_PRE = FACTION:Register();