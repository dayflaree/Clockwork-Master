local FACTION = Clockwork.faction:New("Kona");

FACTION.useFullName = true;
FACTION.material = "halfliferp/factions/kona";
FACTION.whitelist = true;
FACTION.models = {
 female = {
		"models/stalkertnb/bandit_cawlin.mdl",   
		"models/stalkertnb/bandit_ewok.mdl",
		"models/stalkertnb/bandit_female5.mdl",
		"models/stalkertnb/bandit_female7.mdl",
		"models/stalkertnb/bandit_female9.mdl",
		"models/stalkertnb/bandit_horizon.mdl",
		"models/stalkertnb/bandit_jamie1.mdl",
		"models/stalkertnb/bandit_reager2.mdl",
		"models/stalkertnb/bandit_wolfy.mdl"
 },
 male = {
		"models/stalkertnb/baldry_priest.mdl",
		"models/stalkertnb/bandit1.mdl",
		"models/stalkertnb/bandit2.mdl",
		"models/stalkertnb/bandit3.mdl",
		"models/stalkertnb/bandit4.mdl",
		"models/stalkertnb/bandit5.mdl",
		"models/stalkertnb/bandit7.mdl",
		"models/stalkertnb/bandit_daniel.mdl",
		"models/stalkertnb/bandit_dk.mdl",
		"models/stalkertnb/bandit_male6.mdl",
		"models/stalkertnb/bandit_male7.mdl",
		"models/stalkertnb/bandit_nikolai.mdl",
		"models/stalkertnb/bandit_zaku3.mdl",
		"models/stalkertnb/banditboss1.mdl",
		"models/stalkertnb/banditboss2.mdl",   
		"models/stalkertnb/beri_tyson.mdl",
		"models/stalkertnb/io7a_das.mdl",
		"models/stalkertnb/skat_bees.mdl",
		"models/stalkertnb/sunrise_faceplate1.mdl",
		"models/stalkertnb/sunrise_mardam.mdl",
		"models/stalkertnb/zombie_mutant.mdl"
 };
};

FACTION_KONA = FACTION:Register();