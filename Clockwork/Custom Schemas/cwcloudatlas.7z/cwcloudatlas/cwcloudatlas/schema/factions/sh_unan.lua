--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Unanimity");

FACTION.whitelist = true;
FACTION.material = "halfliferp/factions/un";
FACTION.models = {
	female = {"models/player/blacklight4npc.mdl"},
	male = {"models/player/blacklight2npc.mdl"}
};

-- Called when a player's name should be assigned for the faction.
function FACTION:GetName(player, character)
	local unitID = math.random(1, 999);
	
	return "Enforcer "..Clockwork.kernel:ZeroNumberToDigits(unitID, 5);
end;

-- Called when a player's model should be assigned for the faction.
function FACTION:GetModel(player, character)
	if (character.gender == GENDER_MALE) then
		return self.models.male[1];
	else
		return self.models.female[1];
	end;
end;

FACTION_UNAN = FACTION:Register();