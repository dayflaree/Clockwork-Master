--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Pistol Sonicshot Ammo";
	ITEM.cost = 50;
	ITEM.model = "models/items/boxsrounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "v";
	ITEM.uniqueID = "ammo_pistol";
	ITEM.business = true;
	ITEM.ammoClass = "pistol";
	ITEM.ammoAmount = 30;
	ITEM.description = "A green metal case carrying sonicshot ammo for use with the FN57.";
ITEM:Register();