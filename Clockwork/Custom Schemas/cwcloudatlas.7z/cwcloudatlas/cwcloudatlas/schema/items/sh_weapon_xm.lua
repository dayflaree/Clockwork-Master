--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "XM-589";
	ITEM.cost = 3000;
	ITEM.model = "models/weapons/w_rif_589.mdl";
	ITEM.weight = 6;
	ITEM.access = "v";
	ITEM.uniqueID = "xm589";
	ITEM.business = false;
	ITEM.description = "A matte grey bulky rifle with a panoramic sight on it's top rail and an under-barrel scan launcher.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();