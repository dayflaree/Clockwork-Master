--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Sack";
ITEM.model = "models/props_junk/garbage_bag001a.mdl";
ITEM.weight = 5;
ITEM.access = "v";
ITEM.category = "Storage";
ITEM.isRareItem = true;
ITEM.description = "A green burlap sack with twigs and twine holding it into a wearable shape.";
ITEM.addInvSpace = 8;
ITEM:Register();