--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Ebony Sword";
	ITEM.cost = 80;
	ITEM.model = "models/morrowind/ebony/shortsword/w_ebony_shortsword.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_mor_ebony_shortsword";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A sharp, heavy katana wielded by high ranking Enforcers of Neo Seoul.";
	ITEM.value = 0.9;
	ITEM.spawncategory = 7;
ITEM:Register();