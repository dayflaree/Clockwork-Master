--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Iron Sword";
	ITEM.cost = 80;
	ITEM.model = "models/morrowind/iron/shortsword/w_iron_shortsword.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_mor_iron_shortsword";
	ITEM.isMeleeWeapon = true;
	ITEM.description = "An iron sword crafted by the Valley's men.";
	ITEM.value = 0.9;
	ITEM.spawncategory = 7;
ITEM:Register();