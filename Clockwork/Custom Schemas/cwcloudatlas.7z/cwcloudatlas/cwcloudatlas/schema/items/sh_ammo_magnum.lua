--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Sonicshot Magnum Ammo";
	ITEM.cost = 20;
	ITEM.classes = {CLASS_PRE};
	ITEM.model = "models/items/357ammo.mdl";
	ITEM.weight = 1;
	ITEM.access = "v";
	ITEM.uniqueID = "ammo_357";
	ITEM.business = true;
	ITEM.ammoClass = "357";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box filled with canisters that can be inserted into the 92's magazine.";
ITEM:Register();