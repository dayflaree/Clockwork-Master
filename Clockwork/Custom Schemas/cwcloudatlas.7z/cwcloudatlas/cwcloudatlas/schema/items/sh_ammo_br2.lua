--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "BR2 Sonicshot Ammo";
	ITEM.cost = 90;
	ITEM.access = "v";
	ITEM.model = "models/items/combine_rifle_cartridge01.mdl";
	ITEM.plural = "BR2 Sonicshot Ammo";
	ITEM.weight = 2;
	ITEM.uniqueID = "ammo_ar2";
	ITEM.business = true;
	ITEM.ammoClass = "ar2";
	ITEM.ammoAmount = 30;
	ITEM.description = "A pack of ammunition, propietary for the BR2 rifle.";
ITEM:Register();