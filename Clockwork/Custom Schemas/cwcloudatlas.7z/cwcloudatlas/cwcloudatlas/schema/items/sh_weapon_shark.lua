--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Shark Gun";
	ITEM.cost = 10,000;
	ITEM.model = "models/weapons/w_rif_shark.mdl";
	ITEM.weight = 5;
	ITEM.access = "v";
	ITEM.uniqueID = "sharkgun";
	ITEM.business = false;
	ITEM.description = "A garishly coloured rifle with a metal shark fin up top and pinup stickers on it's sides.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();