--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "M92";
	ITEM.cost = 200;
	ITEM.model = "models/weapons/w_bm92_fiveseven.mdl";
	ITEM.weight = 1;
	ITEM.access = "v";
	ITEM.classes = {CLASS_PRE};
	ITEM.uniqueID = "beretta92";
	ITEM.business = false;
	ITEM.description = "An Unanimity pistol with an extended magazine and red night sights.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(0, 4, -8);
ITEM:Register();