--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Sonicshot SMG Ammo";
	ITEM.cost = 100;
	ITEM.model = "models/items/boxmrounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "v";
	ITEM.uniqueID = "ammo_smg1";
	ITEM.business = true;
	ITEM.ammoClass = "smg1";
	ITEM.ammoAmount = 30;
	ITEM.description = "A grey plastic container filled with SMG bullets.";
ITEM:Register();