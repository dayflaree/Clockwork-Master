--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "BR2 Prototype Rifle";
	ITEM.cost = 1000;
	ITEM.model = "models/weapons/w_br2_famas.mdl";
	ITEM.weight = 4;
	ITEM.access = "v";
	ITEM.uniqueID = "br2";
	ITEM.description = "A bullpup assault rifle with a large magazine, night sights and rails.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();