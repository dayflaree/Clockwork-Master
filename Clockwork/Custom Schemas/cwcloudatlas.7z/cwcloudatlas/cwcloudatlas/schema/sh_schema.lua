--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");

Clockwork.option:SetKey("default_date", {month = 1, year = 2323, day = 1});
Clockwork.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});

Clockwork.option:SetKey("intro_image", "materials/halfliferp/carp_logo.png");
Clockwork.option:SetKey("schema_logo", "materials/halfliferp/carp_logo.png");

Clockwork.option:SetKey("menu_music", "music/hl1_song3.mp3");
Clockwork.option:SetKey("model_shipment", "models/props_junk/cardboard_box002a.mdl");
Clockwork.option:SetKey("name_cash", "Hides");

Clockwork.config:ShareKey("intro_text_big");
Clockwork.config:ShareKey("intro_text_small");

Clockwork.quiz:SetEnabled(true);
Clockwork.quiz:AddQuestion("What universe does this roleplay take place in?", 1, "Cloud Atlas", "Half Life 2");
Clockwork.quiz:AddQuestion("Do you understand that you may be a primitive triber, who lacks weapons or certain survival skills?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Do you understand that you don't need weapons to roleplay?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Does your character have fear?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Do you understand the idea of ideology (ex. Nazism) is abolished?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Will you listen to the administrators and other players when they feel the need to inform you on any mistakes or infractions?", 1, "Yes.", "No, because screw you!");

Clockwork.flag:Add("v", "Admin Items", "Items that are available for admin positions.");
Clockwork.flag:Add("j", "Junk Flags", "Items that are used to be sold, via hunting or scavenging.");

Clockwork.animation.AddMaleHumanModel ("models/player/blacklight4npc.mdl");
Clockwork.animation.AddMaleHumanModel ("models/player/blacklight2npc.mdl");