local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SafeAreaRemove");
COMMAND.tip = "Remove a safe area at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);
	local safeAreas = 0;
	
	for k, v in pairs(Schema.safeAreas) do
		if (v:Distance(position) <= 256) then
			safeAreas = safeAreas + 1;
			
			Schema.safeAreas[k] = nil;
		end;
	end
	
	if (safeAreas > 0) then
		if (safeAreas == 1) then
			Clockwork.player:Notify(player, "You have removed "..safeAreas.." safe area.");
		else
			Clockwork.player:Notify(player, "You have removed "..safeAreas.." safe areas.");
		end;
	else
		Clockwork.player:Notify(player, "There are no safe areas near this position.");
	end;

	Schema:SaveSafeAreas();
end;

COMMAND:Register();