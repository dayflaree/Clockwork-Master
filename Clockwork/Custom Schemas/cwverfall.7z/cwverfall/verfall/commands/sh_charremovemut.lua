local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharRemoveMut");
COMMAND.tip = "Remove a character's mutation.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.text = "<string Name> <string Mutation>";
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	if (target) then
		local mutation = Schema.mutation:FindByID(arguments[2])
		if (mutation) then		
			Schema.mutation:RemovePlayerMutation(target, mutation.name)
			Clockwork.player:Notify(player, "You have removed the mutation "..mutation.name.." from "..target:GetName()..".");
		else
			Clockwork.player:Notify(player, "That mutation does not exist!");
		end;
	else
		Clockwork.player:Notify(player, "That player does not exist!");
	end;
end;

COMMAND:Register();