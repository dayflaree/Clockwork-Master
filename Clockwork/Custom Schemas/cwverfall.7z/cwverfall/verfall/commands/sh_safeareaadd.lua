local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SafeAreaAdd");
COMMAND.tip = "Add a safe area at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos + Vector(0, 0, 32);
	
	Schema.safeAreas = Schema.safeAreas or {}
	Schema.safeAreas[#Schema.safeAreas + 1] = position;
	
	Schema:SaveSafeAreas();
	Clockwork.player:Notify(player, "You have added a safe area.");
end;

COMMAND:Register();