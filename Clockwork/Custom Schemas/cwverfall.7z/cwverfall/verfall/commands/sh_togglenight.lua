local COMMAND = Clockwork.command:New("PlaySong");

COMMAND.tip = "Plays a song (test).";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	print("derp")
	Clockwork.datastream:Start( player, "PlaySong", tonumber(arguments[1]))
end;

COMMAND:Register();