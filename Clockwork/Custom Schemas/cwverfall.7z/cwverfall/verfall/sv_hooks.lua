--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]
local Clockwork = Clockwork;

-- Called when Clockwork has loaded all of the entities.
function Schema:ClockworkInitPostEntity()
	self:LoadSafeAreas();
	self:LoadBuckets();
end;

-- Called just after data should be saved.
function Schema:PostSaveData()
	self:SaveSafeAreas();
end;

-- Called when data should be saved.
function Schema:SaveData()
	self:SaveBuckets();
end;

-- Called when Clockwork has initialized.
function Schema:ClockworkInitialized()
end;

--Called when a character is loaded.
function Schema:PlayerCharacterLoaded(player)
	if !(player:GetCharacterData("mutationInfo")) then
		Schema.mutation:EstablishPlayerMutationInfo(player);
	end;
	if (player:GetModel() == "models/dogmeat.mdl") then
		if (!Schema.mutation:PlayerHasMutation(player, "Canine Senses")) then
			Schema.mutation:GivePlayerMutation(player, "Canine Senses")
		end;
	end;
end;

-- Called when a player attempts to use an item.
function Schema:PlayerCanUseItem(player, itemTable, noMessage)
end;

-- Called to get whether a player's weapon is raised.
function Schema:GetPlayerWeaponRaised(player, class, weapon)
	if (class == "cw_camera") then
		return true
	end;
end;

-- Called when an entity's menu option should be handled.
function Schema:EntityHandleMenuOption(player, entity, option, arguments)
	if (arguments == "cwBucketFill") then
	--	if (Clockwork.entity:IsPhysicsEntity(entity)) then
		--	local model = string.lower(entity:GetModel());
		--	if (model == "models/props_junk/metalbucket01a.mdl") then
				local fillCount = (entity:GetNWInt("Fill")) or 0
				if (fillCount != 5) then
					self:FillBucket(player, entity, 5);
				else
					Clockwork.player:Notify(player, "The bucket is already full!");
				end;
	--		end;
	--	end;
	elseif (arguments == "cwBottleFill") then
	--	if (Clockwork.entity:IsPhysicsEntity(entity)) then
	--		local model = string.lower(entity:GetModel());
	--		if (model == "models/props_junk/metalbucket01a.mdl") then
				local fillCount = (entity:GetNWInt("Fill")) or 0
				if (fillCount > 0) then
					local itemTable = player:FindItemByID("Empty Water Bottle");
					
					if itemTable then			
						player:TakeItem(itemTable);
						player:GiveItem(Clockwork.item:CreateInstance("water_dirty"), true);
						entity:SetNWInt("Fill", entity:GetNWInt("Fill")- 1) 
						Clockwork.player:Notify(player, "You have filled your water bottle with dirty water.");
					else
						Clockwork.player:Notify(player, "You do not have a bottle!");
					end;
				else
					Clockwork.player:Notify(player, "The bucket is empty!");
				end;
			end;
	--		end;
	--	end;
	
	if (arguments == "cw_corpseLoot") then
		print("a")
		if (!entity.cwInventory) then
			entity.cwInventory = {}
			local packItems = {
				Clockwork.item:CreateInstance("bag"),
				Clockwork.item:CreateInstance("backpack"),
				Clockwork.item:CreateInstance("pouch")
			};
			local foodItems = {
				Clockwork.item:CreateInstance("water_dirty"),
				Clockwork.item:CreateInstance("Sider's Apple Cyder"),
				Clockwork.item:CreateInstance("Onut's Peanuts Bag"),
				Clockwork.item:CreateInstance("Pack of Cigarettes"),
				Clockwork.item:CreateInstance("Zewritos"),
				Clockwork.item:CreateInstance("Can of beans"),
				Clockwork.item:CreateInstance("empty_bottle_water"),
				Clockwork.item:CreateInstance("empty_takeout"),
				Clockwork.item:CreateInstance("Purify Packet")
				};
			local randomNum = math.random(1, 10);
			if randomNum < 6 then
				entity.cwInventory[#entity.cwInventory+1] = foodItems[math.random(1,#fooditems)]
			elseif randomNum < 2 then
				entity.cwInventory[#entity.cwInventory+1] = packItems[math.random(1,#packitems)]
			end;
		end;
		if (!entity.cash) then 
			if math.random(1,10) == 5 then
				entity.cash = math.random(1,100);
			else
				entity.cash = 0;
			end;
				
			player:EmitSound("physics/body/body_medium_impact_soft"..math.random(1, 7)..".wav");
					
			Clockwork.storage:Open( player, {
				name = "Corpse",
				weight = 8,
				entity = entity,
				distance = 192,
				cash = entity.cash,
				inventory = entity.cwInventory,
				OnGiveCash = function(player, storageTable, cash)
					entity.cash = storageTable.cash;
				end,
				OnTakeCash = function(player, storageTable, cash)
					entity.cash = storageTable.cash;
				end
			} );
		end;
	end;	
end;

--Called when a player attempts to use their tool.
function Schema:CanTool( ply, tr, tool )
	 if ( IsValid( tr.Entity ) and tr.Entity:GetClass() == "npc_v_limper" ) then
		 return false
	 end
end

-- Called when a player takes damage.
function Schema:PlayerTakeDamage(player, inflictor, attacker, hitGroup, damageInfo)
end;

-- Called when death attempts to clear a player's recognised names.
function Schema:PlayerCanDeathClearRecognisedNames(player, attacker, damageInfo) return false; end;

-- Called when death attempts to clear a player's name.
function Schema:PlayerCanDeathClearName(player, attacker, damageInfo) return false; end;

-- Called when a player's default inventory is needed.
function Schema:GetPlayerDefaultInventory(player, character, inventory)
end;

--Called when a player spawns.
function Schema:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	
	if (firstSpawn) then
		Clockwork.datastream:Start(player, "PlayCalmSong")
	end;
	
	if !lightSpawn then 
		player:SetNetworkedVar("Ethereal", false)
		player:SetNetworkedVar("CanineSenses", false)
	end;
end;