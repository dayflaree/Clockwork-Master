local ITEM = Clockwork.item:New();
ITEM.name = "Purify Packet";
ITEM.cost = 5;
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
ITEM.weight = 0.1;
ITEM.access = "1v";
ITEM.useText = "Purify Water";
ITEM.category = "Medical"
ITEM.business = true;
ITEM.description = "It's a small packet of powder, there are instructions on the side describing a man pouring powder into a bottle.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local itemTable = player:FindItemByID("water_dirty");
					
	if itemTable then			
		player:TakeItem(itemTable);
		player:GiveItem(Clockwork.item:CreateInstance("water_purified"), true);
		Clockwork.player:Notify(player, "You pour the packet of powder into the bottle, bubbling can be heard as the water inside purifies.");
	else
		Clockwork.player:Notify(player, "You don't have any water to purify!")
	end;
	
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();