--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local Clockwork = Clockwork;

local ITEM = Clockwork.item:New();
ITEM.name = "Flashlight";
ITEM.model = "models/raviool/flashlight.mdl";
ITEM.weight = 0.5;
ITEM.category = "Tools";
ITEM.description = "This is a flashlight, used to illuminate dark areas.";
ITEM.access = "v";
ITEM.cost = 15;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	player:Flashlight(false)
 end;

Clockwork.item:Register(ITEM);