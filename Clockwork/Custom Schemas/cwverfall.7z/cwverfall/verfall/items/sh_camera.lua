--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local Clockwork = Clockwork;

local ITEM = Clockwork.item:New("weapon_base");
ITEM.name = "Camera";
ITEM.model = "models/maxofs2d/camera.mdl";
ITEM.weight = 0.5;
ITEM.category = "Tools";
ITEM.uniqueID = "cw_camera";
ITEM.description = "This is a camera, its zoom function can be used to see far distances.";
ITEM.access = "v";
ITEM.cost = 15;
ITEM.isAttachment = true;
ITEM.loweredOrigin = Vector(3, 0, -4);
ITEM.loweredAngles = Angle(0, 45, 0);
ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
ITEM.attachmentOffsetAngles = Angle(0, 0, -90);
ITEM.attachmentOffsetVector = Vector(-6.768, 0.1, -5.217);

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) return true end;

Clockwork.item:Register(ITEM);