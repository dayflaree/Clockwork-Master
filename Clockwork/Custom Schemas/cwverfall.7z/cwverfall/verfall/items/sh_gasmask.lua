--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local Clockwork = Clockwork;

local ITEM = Clockwork.item:New("accessory_base");
ITEM.name = "Gasmask";
ITEM.model = "models/dpfilms/metropolice/props/generic_gasmask.mdl";
ITEM.weight = 0.25;
ITEM.useText = "Wear";
ITEM.category = "Accessories";
ITEM.description = "This is a gasmask, complete with filter and visor.";
ITEM.isAttachment = true;
ITEM.attachmentBone = "ValveBiped.Bip01_Head1";
ITEM.attachmentOffsetAngles = Angle(-90, -93.74, 0);
ITEM.attachmentOffsetVector = Vector(0, 1.12, -0.3);
ITEM.access = "v";
ITEM.cost = 20;

-- Called when a player wears the accessory.
function ITEM:OnWearAccessory(player, bIsWearing)
	if (bIsWearing) then
		player:SetSharedVar("gasmask", true);
	else
		player:SetSharedVar("gasmask", false);
	end;
end;

function ITEM:AdjustAttachmentOffsetInfo(player, entity, info)
	if ( string.find(player:GetModel(), "female") ) then
		info.offsetVector = Vector(0, 0, 0);
	end;
end;



Clockwork.item:Register(ITEM);