--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Blackwatch");

FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "verfall3/factions/blackwatch";
FACTION.models = {
	female = {
		"garrysmod/models/pmc/pmc_01.mdl",
		"garrysmod/models/pmc/pmc_02.mdl",
		"garrysmod/models/pmc/pmc_03.mdl",
		"garrysmod/models/pmc/pmc_04.mdl",
		"garrysmod/models/pmc/pmc_05.mdl",
		"garrysmod/models/pmc/pmc_06.mdl",
		"garrysmod/models/pmc/pmc_07.mdl",
		"garrysmod/models/pmc/pmc_08.mdl",
		"garrysmod/models/pmc/pmc_09.mdl",
		"garrysmod/models/pmc/pmc_10.mdl",
		"garrysmod/models/pmc/pmc_11.mdl",
		"garrysmod/models/pmc/pmc_12.mdl",
		"garrysmod/models/pmc/pmc_13.mdl",
		"garrysmod/models/pmc/pmc_14.mdl",
		"garrysmod/models/pmc/pmc_15.mdl",
		"garrysmod/models/pmc/pmc_16.mdl",
		"garrysmod/models/pmc/pmc_17.mdl"
	},
	male = {
		"garrysmod/models/pmc/pmc_01.mdl",
		"garrysmod/models/pmc/pmc_02.mdl",
		"garrysmod/models/pmc/pmc_03.mdl",
		"garrysmod/models/pmc/pmc_04.mdl",
		"garrysmod/models/pmc/pmc_05.mdl",
		"garrysmod/models/pmc/pmc_06.mdl",
		"garrysmod/models/pmc/pmc_07.mdl",
		"garrysmod/models/pmc/pmc_08.mdl",
		"garrysmod/models/pmc/pmc_09.mdl",
		"garrysmod/models/pmc/pmc_10.mdl",
		"garrysmod/models/pmc/pmc_11.mdl",
		"garrysmod/models/pmc/pmc_12.mdl",
		"garrysmod/models/pmc/pmc_13.mdl",
		"garrysmod/models/pmc/pmc_14.mdl",
		"garrysmod/models/pmc/pmc_15.mdl",
		"garrysmod/models/pmc/pmc_16.mdl",
		"garrysmod/models/pmc/pmc_17.mdl"
		};
	};

FACTION_BLACKWATCH = FACTION:Register();