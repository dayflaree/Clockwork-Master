--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Haven");

FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "verfall3/factions/haven";
FACTION.models = { 
	female = {"models/stalkertnb/bandit_jamie.mdl"},
	male = {"models/stalkertnb/psz9d_drk.mdl"}
};
FACTION_HAVEN = FACTION:Register();