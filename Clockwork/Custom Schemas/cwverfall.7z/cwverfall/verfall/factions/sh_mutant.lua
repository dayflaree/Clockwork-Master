--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Mutant");

FACTION.whitelist = true;
FACTION.useFullName = true; -- Do we allow players to enter a full name, otherwise it only lets them select a first and second.
FACTION.material = "verfall3/factions/mutants"; -- The path to the faction material (shown on the creation screen).
FACTION.models = {};
FACTION.models.female = {
	"models/zombie/zm_classic.mdl",
	"models/zombie/zm_classic_01.mdl",
	"models/zombie/zm_classic_02.mdl",
	"models/zombie/zm_classic_03.mdl",
	"models/zombie/zm_classic_04.mdl",
	"models/zombie/zm_classic_05.mdl",
	"models/zombie/zm_classic_06.mdl",
	"models/zombie/zm_classic_07.mdl",
	"models/zombie/zm_classic_08.mdl",
	"models/zombie/zm_classic_09.mdl"
};

FACTION.models.male = FACTION.models.female

FACTION_MUTANT = FACTION:Register();