--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when the cinematic intro info is needed.
function Schema:GetCinematicIntroInfo()
	return {
		credits = "Developed by NightAngel, Legion and After-Effect.",
		title = Clockwork.config:Get("intro_text_big"):Get(),
		text = Clockwork.config:Get("intro_text_small"):Get()
	};
end;

-- Stops head bob when aiming.
function Schema:PlayerAdjustHeadbobInfo(info)
	if (Clockwork.Client:KeyDown(IN_ATTACK2)) then
		info.speed = 0
	end;
end;

-- Called when an entity's menu options are needed.
function Schema:GetEntityMenuOptions(entity, options)
--	print(entity:GetClass())
	if (Clockwork.entity:IsPhysicsEntity(entity)) then
		local model = string.lower(entity:GetModel());
		
		if (model == "models/props_junk/metalbucket01a.mdl") then
			if (entity:WaterLevel( ) == 3) then
				options["Fill Bucket"] = "cwBucketFill";
			end;
		--	options["Drink from Bucket"] = "cwBucketDrink";
			options["Fill Empty Bottle"] = "cwBottleFill";			
		end;
	end;
end;

-- Called when the character background blur should be drawn.
function Schema:ShouldDrawCharacterBackgroundBlur()
	return false;
end;

-- Called when the target's status should be drawn.
function Schema:DrawTargetPlayerStatus(target, alpha, x, y)
	local colorInformation = Clockwork.option:GetColor("information");
	local thirdPerson = "him";
	local mainStatus = nil;
	local gender = "He";
	local action = Clockwork.player:GetAction(target);
	
	if (target:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if ( target:Alive() ) then		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." appears to be unconscious.";
		end;
		
		if (mainStatus) then
			y = Clockwork.kernel:DrawInfo(mainStatus, x, y, colorInformation, alpha);
		end;
		
		return y;
	end;
end;

--Called when the screen space effects are needed.
function Schema:RenderScreenspaceEffects()
	if (Clockwork.kernel:IsChoosingCharacter()) then return false end;
	
	if (Clockwork.Client:GetNetworkedVar("Ethereal", true)) then
		local colormod = {}
		colormod[ "$pp_colour_contrast" ] = 1.0
		colormod[ "$pp_colour_addr" ] = 0 / 2550
		colormod[ "$pp_colour_addg" ] = 230 / 2550
		colormod[ "$pp_colour_addb" ] = 255 / 2550
		DrawColorModify(colormod)
	end;	
	
	if (Clockwork.Client:GetNetworkedInt("thirdperson") == 0) then
		if (Clockwork.Client:GetSharedVar("gasmask")) then
			render.UpdateScreenEffectTexture();
					
			self.gasmaskOverlay:SetFloat("$refractamount", 0.3);
			self.gasmaskOverlay:SetFloat("$envmaptint", 0);
			self.gasmaskOverlay:SetFloat("$envmap", 0);
			self.gasmaskOverlay:SetFloat("$alpha", 1);
			self.gasmaskOverlay:SetInt("$ignorez", 1);
					
			render.SetMaterial(self.gasmaskOverlay);
			render.DrawScreenQuad();
		end;
		if (IsValid(Clockwork.Client:GetActiveWeapon())) then
			if (Clockwork.Client:GetActiveWeapon():GetClass() == "cw_camera") then				
				render.UpdateScreenEffectTexture();
							
				self.cameraOverlay:SetFloat("$refractamount", 0.3);
				self.cameraOverlay:SetFloat("$envmaptint", 0);
				self.cameraOverlay:SetFloat("$envmap", 0);
				self.cameraOverlay:SetFloat("$alpha", 1);
				self.cameraOverlay:SetInt("$ignorez", 1);
							
				render.SetMaterial(self.cameraOverlay);
				render.DrawScreenQuad();
			end;
		end;
	end;
	
	if (Clockwork.Client:GetNetworkedVar("CanineSenses", true)) then
		for k, v in ipairs( ents.FindInSphere(Clockwork.Client:GetPos(),2000) ) do
			if ((v:IsPlayer() and v:GetMoveType()==MOVETYPE_WALK) or string.find(v:GetClass(), "npc_")) then
				halo.Add( { v }, Color( 0, 200, 255 ), 1, 1, 2, true, true)
			end;
		end;
		
		local colormod = {}
			colormod[ "$pp_colour_contrast" ] = 1.0
			colormod[ "$pp_colour_addr" ] = 255 / 2550
			colormod[ "$pp_colour_addg" ] = 180 / 2550
			colormod[ "$pp_colour_addb" ] = 130 / 2550
		DrawColorModify(colormod)
	end;	
end;

-- Called when a player's typing display position is needed.
function Schema:GetPlayerTypingDisplayPosition(player)
	if (Schema:PlayerIsAnimal(player)) then
		return player:GetPos() + Vector(0, 0, 70);
	end;
end;

-- Called when the local player attempts to zoom.
function Schema:PlayerCanZoom()
	return false
end;

-- Called when the target ID HUD should be drawn.
function Schema:HUDDrawTargetID()
	local targetIDTextFont = Clockwork.option:GetFont("target_id_text");
	local traceEntity = NULL;
	local colorWhite = Clockwork.option:GetColor("white");
	
	Clockwork.kernel:OverrideMainFont(targetIDTextFont);
	
	if (IsValid(Clockwork.Client) and Clockwork.Client:Alive() and !IsValid(Clockwork.EntityMenu)) then
		local fadeDistance = 196;
		local curTime = UnPredictedCurTime();
		local trace = Clockwork.player:GetRealTrace(Clockwork.Client);
			
		if (IsValid(trace.Entity) and !trace.Entity:IsEffectActive(EF_NODRAW)) then
			if (!Clockwork.TargetIDData or Clockwork.TargetIDData.entity != trace.Entity) then
				Clockwork.TargetIDData = {
					showTime = curTime + 0.5,
					entity = trace.Entity
				};
			end;
				
			if (Clockwork.TargetIDData) then
				Clockwork.TargetIDData.trace = trace;
			end;
				
			if (!IsValid(traceEntity)) then
				traceEntity = trace.Entity;
			end;
				
			if (curTime >= Clockwork.TargetIDData.showTime) then
				if (!Clockwork.TargetIDData.fadeTime) then
					Clockwork.TargetIDData.fadeTime = curTime + 1;
				end;
					
				local class = trace.Entity:GetClass();
					
				if (class == "prop_physics") then
					if (string.lower(trace.Entity:GetModel()) == string.lower("models/props_junk/MetalBucket01a.mdl")) then
	
						local alpha = math.Clamp(Clockwork.kernel:CalculateAlphaFromDistance(fadeDistance, Clockwork.Client, trace.HitPos) * 1.5, 0, 255);
							
						if (alpha > 0) then
							alpha = math.min(alpha, math.Clamp(1 - ((Clockwork.TargetIDData.fadeTime - curTime) / 3), 0, 1) * 255);
						end;
							
						Clockwork.TargetIDData.fadeDistance = fadeDistance;
						Clockwork.TargetIDData.alpha = alpha;
				
						if (Clockwork.Client:GetShootPos():Distance(trace.HitPos) <= fadeDistance) then
							local toScreen = (trace.HitPos + Vector(0, 0, 16)):ToScreen();
							local x, y = toScreen.x, toScreen.y;
							local colorInformation = Clockwork.option:GetColor("information");
											
							local newY;
												
							newY = Clockwork.kernel:DrawInfo("Water Bucket", x, y, colorInformation, alpha);
							
							local fillCount = trace.Entity:GetNWInt("Fill")
							local fillTranslate = {"empty",
								"slightly filled",
								"almost halfway filled",
								"halfway full",
								"almost full",
								"full"
							}
							
							local filly = y + 25
							
							newFill = Clockwork.kernel:DrawInfo("It appears to be "..fillTranslate[fillCount + 1].."!", x, filly, colorWhite, alpha);
																									
							if (newY) then
								y = newY;
							end;
							
							if (newFill) then
								filly = newFill;
							end;
						end;
					end;
				end;
			end;
		end;
	end;	
end;

--Simulates night-time with color modify brightness.
function Schema:PlayerAdjustColorModify(colorModify)

	local minute = Clockwork.time:GetMinute();
	local hour = Clockwork.time:GetHour();
	local brightNumber = (minute * hour) / 8;
	
--	print(tostring(brightNumber).." "..tostring(minute))
	
	if (hour > 18 or hour < 6) then
--	if (minute > 1080 or minute < 360) then
	--	print("minute > 1080 or minute < 360")
		colorModify["$pp_colour_brightness"] = -0.15;
--	elseif (minute < 960 or minute > 240) then
	elseif (hour < 16 or hour > 4) then
	--	print("minute < 960 or minute > 240")
		colorModify["$pp_colour_brightness"] = 0;
--	elseif (minute > 960 and minute < 1080) then
	elseif (hour > 16 and hour < 18) then
	--	print("minute > 960 and minute < 1080")
		colorModify["$pp_colour_brightness"] = brightNumber * -1;
--	elseif (minute < 240 and minute > 360) then
	elseif (hour < 4 and hour > 6) then
	--	print("minute < 240 and minute > 360")
		colorModify["$pp_colour_brightness"] = brightNumber;
	end;
	
end;

-- Called when the local player's default color modify should be set.
function Schema:PlayerSetDefaultColorModify(colorModify)
	colorModify["$pp_colour_brightness"] = 0;
	colorModify["$pp_colour_contrast"] = 1.1;
	colorModify["$pp_colour_colour"] = 0.6;
end;

-- Called when a player's footstep sound should be played.
function Schema:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	return true;
end;