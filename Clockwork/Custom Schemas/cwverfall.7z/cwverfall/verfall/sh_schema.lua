--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");

Clockwork.option:SetKey("default_date", {month = 1, year = 2061, day = 1});
Clockwork.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});

Clockwork.option:SetKey("intro_image", "verfall3/logopro");
Clockwork.option:SetKey("schema_logo", "verfall3/logopro");

Clockwork.option:SetKey("menu_music", "verfall/charselect.mp3");
Clockwork.option:SetKey("model_shipment", "models/props_junk/cardboard_box002a.mdl");
Clockwork.option:SetKey("name_cash", "USD");
Clockwork.option:SetKey("model_cash", "models/props/cs_assault/money.mdl");

Clockwork.config:ShareKey("intro_text_big");
Clockwork.config:ShareKey("intro_text_small");

Clockwork.quiz:SetEnabled(false);
--[[
Clockwork.quiz:AddQuestion("What do you think Serious Roleplaying is about?", 2, "Collecting items.", "Developing your character.");
Clockwork.quiz:AddQuestion("Do you need weapons to Roleplay?", 2, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Can you type using correct capitalization, full stops, and commas correctly?", 2, "yes, i can.", "Yes, I can.");
Clockwork.quiz:AddQuestion("What is the difference IC and OOC?", 1, "IC stands for 'In-Character', meaning what your character does.", "The difference between OOC and IC, is OOC having increased chatter range.");
Clockwork.quiz:AddQuestion("Do you understand that arguing with staff will only make things worse?", 1, "Yes, I do.", "Fuck those guys.");
Clockwork.quiz:AddQuestion("What universe is this RP server set in?", 1, "Post-Apocalyptic America.", "Real Life.");
Clockwork.quiz:AddQuestion("What is a /me?", 1, "A command used to describe a action of your character", "A stupid thing that no one uses.");
Clockwork.quiz:AddQuestion("What is more fun?", 2, "Shooting things.", "Developing your character by interacting with other characters.");
]]--

--Clockwork.flag:Add("E", "Example Flag", "Access to an example flag.");

function Schema:PlayerSwitchFlashlight(client, state)
	if (state and !client:HasItemByID("Flashlight")) then
		return false
	end

	return true
end

-- A function to get whether a player is an animal.
function Schema:PlayerIsAnimal(player)
	if (IsValid(player)) then
		local faction = player:GetFaction();
		
		if (faction == FACTION_BIRD or faction == FACTION_DOG) then
			return true;
		else
			return false;
		end;
	end;
end;

-- Called when the Clockwork shared variables are added.
function Schema:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Bool("gasmask", true);
end;