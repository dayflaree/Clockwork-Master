Schema.amb = Clockwork.kernel:NewLibrary("Ambience");
if (CLIENT) then

Schema.amb.AllSongs = {
	"music/hl2_song30.mp3",
	"music/hl2_song33.mp3",
	"music/hl2_song26.mp3",
	"music/hl2_song13.mp3",
	"music/hl2_song27_trainstation2.mp3"
}

Schema.amb.CalmSongs = {
	Schema.amb.AllSongs[1],
	Schema.amb.AllSongs[2],
	Schema.amb.AllSongs[3],
	Schema.amb.AllSongs[4],
	Schema.amb.AllSongs[5]
}

--[[
function Schema.amb:GetSong(song)
	return Schema.amb.AllSongs[song]
end;
]]--

function Schema.amb:GetRandomCalm()
	local newSong = Schema.amb.CalmSongs[math.random(1,#Schema.amb.CalmSongs)];
	if ( newSong == self.lastsongString ) then
		while (self.lastsongString == newSong) do
			newSong = Schema.amb.CalmSongs[math.random(1,#Schema.amb.CalmSongs)]
		end;
	end;
	self.lastsongString = newSong
	return newSong;
end;

function Schema.amb:StartSong(song)
	if (Schema.currentSong) then
		Schema.lastSong = Schema.currentSong
		Schema.currentSong = nil;
		Schema.lastSong:FadeOut(3)
		timer.Simple(4, function()
			Schema.lastSong:Stop()
		end)
	end;
	Schema.currentSong = CreateSound(Clockwork.Client, song)
	Schema.currentSong:PlayEx(0, 100)
	Schema.currentSong:ChangeVolume(1, 3)
	Schema.songDuration = CurTime() + math.random(SoundDuration(song)*0.75, SoundDuration(song) - 3);
	
end;

end;