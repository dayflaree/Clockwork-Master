Schema.mutation = Clockwork.kernel:NewLibrary("Mutation");
Schema.mutation.stored = {};

local MUTATION = {__index = MUTATION};

-- A function to register a new MUTATION.
function MUTATION:Register()
	Schema.mutation:Register(self, self.name);
end;

-- A function to set up or reset a player's MUTATION info.
function Schema.mutation:EstablishPlayerMutationInfo(player)
	local mutationInfo = {};

	player:SetCharacterData("mutationInfo", mutationInfo);
	Clockwork.plugin:Call("PlayerMutationInfoEstablished", player, mutationInfo);
end;

-- A function to get whether a player has mutations or not.
function Schema.mutation:PlayerMutated(player)
	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local mutationInfo = player:GetCharacterData("mutationInfo");

			if (mutationInfo and table.Count(mutationInfo) > 0) then
				return true;
			end;
		end;
	end;

	return false;
end;

-- A function to get whether a player has a certain mutation or not.
function Schema.mutation:PlayerHasMutation(player, mutationName)
	if !(self.stored[self:uniqueIDFormat(mutationName)]) then return; end;

	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local mutationInfo = player:GetCharacterData("mutationInfo");
			local uniqueID = self:uniqueIDFormat(mutationName);
						
			if (mutationInfo) then
				if (mutationInfo[uniqueID] == true) then
					return true;
				end;
			end;
		end;
	end;
			
	return false;
end;

-- A function to set a value for a player's mutation info.
function Schema.mutation:SetMutationData(player, key, value)
	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local mutationInfo = player:GetCharacterData("mutationInfo");

			if (mutationInfo[key]) then
				mutationInfo[key] = value;
			end;
		end;
	end;
end;

-- A function to get a player's mutation info.
function Schema.mutation:GetMutationInfo(player)
	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			return player:GetCharacterData("mutationInfo");
		end;
	end;
end;

-- A function to get a player's mutations.
function Schema.mutation:GetPlayerMutations(player)
	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local mutationInfo = player:GetCharacterData("mutationInfo");

			if (mutationInfo) then
				return mutationInfo;
			end;
		end;
	end;
end;

-- A function to create a new mutation syringe based on a mutation.
function Schema.mutation:MakeMutationSyringe(mutationInfo)
	if !(mutationInfo) then return; end;

	local ITEM = Clockwork.item:New();
	ITEM.name = mutationInfo.name.." syringe";
	ITEM.description = "A syringe containing the mutation "..string.lower(mutationInfo.name)..".";
	ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
	ITEM.business = false;
	ITEM.weight = 0.1;
	ITEM.category = "Mutations";
	ITEM.useText = "Inject";

	function ITEM:OnUse(player, itemEntity)
		if !(Schema.mutation:PlayerHasMutation(player, mutationInfo.name)) then
			Schema.mutation:GivePlayerMutation(player, mutationInfo.name);
			player:TakeItem(self);
		else
			Clockwork.player:Notify(player, "You already have that mutation!");
			return false
		end;
	end;
	
	function ITEM:OnDrop(player, position) return true end;

	ITEM:Register()
end;

-- A function to give a player a mutation.
function Schema.mutation:GivePlayerMutation(player, mutationName, bLog)
	if !(self.stored[self:uniqueIDFormat(mutationName)]) then return; end;
	local bLog = !bLog and true or false;

	if (player:IsValid() and player:HasInitialized() and player:Alive()) then
		if (player:GetCharacterData("mutationInfo")) then
			local characterMutationInfo = player:GetCharacterData("mutationInfo");
			local uniqueID = self:uniqueIDFormat(mutationName);
			local mutationInfo = self:FindByID(uniqueID);

			characterMutationInfo[uniqueID] = true;

			player:SetCharacterData("mutationInfo", characterMutationInfo);

			if (bLog) then
				Clockwork.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." has gained the mutation "..string.lower(mutationName)..".");
			end;
		end;
	end;
end;

-- A function to remove a mutation from a player.
function Schema.mutation:RemovePlayerMutation(player, mutationName, bLog)
	if !(self.stored[self:uniqueIDFormat(mutationName)]) then return; end;
	local bLog = !bLog and true or false;

	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local characterMutationInfo = player:GetCharacterData("mutationInfo");
			local uniqueID = self:uniqueIDFormat(mutationName);

			if (characterMutationInfo[uniqueID]) then
				characterMutationInfo[uniqueID] = nil;

				player:SetCharacterData("mutationInfo", characterMutationInfo);

				if (bLog) then
					Clockwork.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." has lost the mutation "..string.lower(mutationName)..".");
				end;
			end;
		end;
	end;
end;

-- A function to remove all mutations from a player.
function Schema.mutation:PlayerRemoveAll(player, bLog)
	local bLog = !bLog and true or false;

	if (player:IsValid() and player:HasInitialized()) then
		if (player:GetCharacterData("mutationInfo")) then
			local mutationInfo = player:GetCharacterData("mutationInfo");

			if (mutationInfo) then
				mutationInfo = nil;

				player:SetCharacterData("mutationInfo", mutationInfo);
			end;

			if (bLog) then
				Clockwork.kernel:PrintLog(LOGTYPE_MINOR, player:Name().." has lost all mutations.");
			end;
		end;
	end;
end;

-- A function to get a mutation as a regular table.
function Schema.mutation:GetTableVersion(mutationInfo)
	if !(mutationInfo) then return; end;
	local tableVer = {};
	
	for k, v in pairs(mutationInfo) do
		tableVer[k] = v;
	end;

	return tableVer;
end;

-- A function to register a new mutation.
function Schema.mutation:Register(data, name)
	local realName = string.gsub(name, "%s", "");
	local uniqueID = string.lower(realName);

	self:MakeMutationSyringe(data);
	self.stored[uniqueID] = data;
	return self.stored[uniqueID];
end;

-- A function to create a new mutation.
function Schema.mutation:New(name)
	local object = Clockwork.kernel:NewMetaTable(MUTATION);
		object.name = name;
		object.description = "A useless mutation.";
		object.image = "augments/adrenaline"
	return object;
end;

-- A function to return a string in uniqueID format.
function Schema.mutation:uniqueIDFormat(text)
	return string.lower(string.gsub(text, "%s", ""));
end

-- A function to find a mutation by an identifier.
function Schema.mutation:FindByID(identifier)
	for k, v in pairs(Schema.mutation:GetAll()) do
		if (string.find(string.lower(v.name), string.lower(identifier), 1, true)) then
			return v;
		end;
	end;
end;

-- A function to get all mutations.
function Schema.mutation:GetAll()
	return self.stored;
end;

Clockwork.kernel:IncludeDirectory(Clockwork.kernel:GetSchemaFolder().."/schema/mutations/");