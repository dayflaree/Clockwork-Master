--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local THEME = Clockwork.theme:Begin();

-- Called when fonts should be created.
function THEME:CreateFonts()
	surface.CreateFont("ver_ThickArial", 
	{
		font		= "Arial",
		size		= Clockwork.kernel:FontScreenScale(8),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	
	surface.CreateFont("ver_Large3D2D",
	{
		font		= "Orust",
		size		= Clockwork.kernel:GetFontSize3D(),
		weight		= 600,
		antialiase	= true,
		additive 	= false
	});
	
	surface.CreateFont("ver_intro_text_big", 
	{
		font		= "Orust",
		size		= Clockwork.kernel:FontScreenScale(18),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	
	surface.CreateFont("ver_intro_text_small", 
	{
		font		= "Orust",
		size		= Clockwork.kernel:FontScreenScale(12),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	
	surface.CreateFont("ver_main_text", 
	{
		font		= "Orust",
		size		= Clockwork.kernel:FontScreenScale(7),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	
	surface.CreateFont("ver_target_id_text", 
	{
		font		= "Orust",
		size		= Clockwork.kernel:FontScreenScale(8),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("ver_menu_text_small", 
	{
		font		= "Orust",
		size		= Clockwork.kernel:FontScreenScale(10),
		weight		= 700,
		antialiase	= true,
		additive 	= false
	});
end;

-- Called when to initialize the theme.
function THEME:Initialize()
	Clockwork.option:SetColor( "information", Color(190, 0, 0, 255) );
	Clockwork.option:SetColor( "background", Color(80, 80, 80, 255) );
	Clockwork.option:SetColor( "target_id", Color(155, 0, 0, 255) );
	Clockwork.option:SetColor( "sidemenucolor", Color(0, 0, 0, 255) );
	
	Clockwork.option:SetFont("bar_text", "ver_ThickArial");
	Clockwork.option:SetFont("main_text", "ver_main_text");
	Clockwork.option:SetFont("hints_text", "ver_ThickArial");
	Clockwork.option:SetFont("large_3d_2d", "ver_Large3D2D");
	Clockwork.option:SetFont("menu_text_big", "ver_ThickArial");
	Clockwork.option:SetFont("menu_text_huge", "ver_ThickArial");
	Clockwork.option:SetFont("target_id_text", "ver_target_id_text");
	Clockwork.option:SetFont("cinematic_text", "ver_ThickArial");
	Clockwork.option:SetFont("date_time_text", "ver_ThickArial");
	Clockwork.option:SetFont("intro_text_big", "ver_intro_text_big");
	Clockwork.option:SetFont("menu_text_tiny", "ver_ThickArial");
	Clockwork.option:SetFont("menu_text_small", "ver_menu_text_small");
	Clockwork.option:SetFont("intro_text_tiny", "ver_ThickArial");
	Clockwork.option:SetFont("intro_text_small", "ver_intro_text_small");
	Clockwork.option:SetFont("player_info_text", "ver_ThickArial");
end;

local BAR_TEXTURE = Material("verfall3/statusbar.png");
local MENU_TEXTURE = Material("verfall3/menu.png");
local MENU2_TEXTURE = Material("verfall3/f1menu.png");

-- Called just before a bar is drawn.
function THEME.module:PreDrawBar(barInfo)
	surface.SetDrawColor(255, 255, 255, 255);
	surface.SetMaterial(BAR_TEXTURE);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.width, barInfo.height);
	
	barInfo.drawBackground = false;
	barInfo.drawProgress = false;
	
	if (barInfo.text) then
		barInfo.text = string.upper(barInfo.text);
	end;
end;

-- Called just after a bar is drawn.
function THEME.module:PostDrawBar(barInfo)
	surface.SetDrawColor(barInfo.color.r, barInfo.color.g, barInfo.color.b, barInfo.color.a);
	surface.SetMaterial(BAR_TEXTURE);
	surface.DrawTexturedRect(barInfo.x, barInfo.y, barInfo.progressWidth, barInfo.height);
end;

-- Called just before the weapon selection info is drawn.
function THEME.module:PreDrawWeaponSelectionInfo(info)
	surface.SetDrawColor( 70, 70, 70, math.min(200, info.alpha) );
	surface.SetMaterial(MENU_TEXTURE);
	surface.DrawTexturedRect(info.x, info.y, info.width, info.height);
	
	info.drawBackground = false;
end;

-- Called just before the local player's information is drawn.
function THEME.module:PreDrawPlayerInfo(boxInfo, information, subInformation)
	surface.SetDrawColor(50, 50, 50, 255);
	surface.SetMaterial(MENU2_TEXTURE);
	surface.DrawTexturedRect(boxInfo.x, boxInfo.y, boxInfo.width, boxInfo.height);
	
	boxInfo.drawBackground = false;
end;

Clockwork.theme:Finish(THEME);