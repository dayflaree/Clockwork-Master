local MUTATION = Schema.mutation:New("Ethereal")

MUTATION.description = "Gives the ability to leave the body for a short amount of time.";
MUTATION.image = "augments/cursed"

MUTATION:Register();