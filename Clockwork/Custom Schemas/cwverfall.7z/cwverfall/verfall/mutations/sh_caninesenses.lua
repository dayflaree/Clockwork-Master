local MUTATION = Schema.mutation:New("Canine Senses")

MUTATION.description = "Gives the senses of a canine.";
MUTATION.image = "augments/cursed"

MUTATION:Register();