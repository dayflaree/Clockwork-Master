--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

resource.AddFile("resource/fonts/orust.ttf")

--Adds the workshop Verfall Content.
resource.AddWorkshop("325560086")

Clockwork.config:Add("intro_text_big", "Boston, 2061", true);
Clockwork.config:Add("intro_text_small", "This is how you die...", true);

Clockwork.config:Get("enable_gravgun_punt"):Set(false);
Clockwork.config:Get("default_inv_weight"):Set(2);
Clockwork.config:Get("enable_crosshair"):Set(false);
Clockwork.config:Get("scale_prop_cost"):Set(0);
Clockwork.config:Get("default_cash"):Set(50);
Clockwork.config:Get("door_cost"):Set(0);

Clockwork.hint:Add("Staff", "The staff are here to keep things moving, please respect them.");
Clockwork.hint:Add("Death", "Death happens, don't complain if it happens to you.");

Clockwork.config:Add("max_zomb", 15, true)


Schema.weaponTable = {
	"cw_hands",
	"cw_keys",
	"gmod_camera",
	"gmod_tool",
	"weapon_physgun",
	"weapon_crowbar"
};

-- A function to load the zombie spawns.
function Schema:LoadSafeAreas()
	self.safeAreas = Clockwork.kernel:RestoreSchemaData( "plugins/safeareas/"..game.GetMap());
	
	if (!self.safeAreas) then
		self.safeAreas = {};
	end;
end;

--Called every think.
function Schema:PlayerThink(player, curTime, infoTable)
	if (player:GetModel() == "models/crow.mdl") then
		if (!player:OnGround() and !player:GetMoveType() == MOVETYPE_FLY) then
			player:SetMoveType(MOVETYPE_FLY)
		elseif (player:OnGround() and player:GetMoveType() == MOVETYPE_FLY) then
			player:SetMoveType(MOVETYPE_WALK)
		end;
	end
	
	--Resets battle variables if the attacking zombie doesn't exist or is dead.
	if (player.inBattle) then
		if (!player.attacker:IsValid()) then
			player.inBattle = nil;
			player.attacker = nil;
		elseif (player.attacker.dead) then
			player.inBattle = nil;
			player.attacker = nil;
		end;
	end;
end;

--A function to determine if a player is in a safe area or not.
function Schema:IsSafe(player)
	local isSafe = false
	if (#self.safeAreas > 0) then
		for k, v in pairs(self.safeAreas) do
			if (v:Distance(player:GetPos()) < 1000) then
				isSafe = true
			end;
		end
	end;
	return isSafe;
end;

-- Called each tick.
function Schema:Tick()
	--Spawns in the zombies.
	local curTime = CurTime();

	if (!self.nextSpawn) then
		self.nextSpawn = curTime + 5;
	elseif (self.nextSpawn < curTime) then
		Schema:SpawnZombie();
		Schema:RemoveZombies();
		self.nextSpawn = nil
	end;
end;

--Called when zombies need to be removed.
function Schema:RemoveZombies()
	local players = {}
	local zombies = {}
	for k, v in ipairs(ents.GetAll()) do
		if (v:GetClass() == "npc_v_limper") then
			zombies[#zombies+1] = v
		elseif (v:IsPlayer()) then
			players[#players+1] = v
		end;
	end;
	
	for k, zombie in pairs(zombies) do
		canStay = false;
		for k2, player in pairs(players) do
			if (Clockwork.player:CanSeeEntity(player, zombie) and player:GetPos():Distance(zombie:GetPos()) < 4000) then
				canStay = true;
			end;
		end;
		if (canStay == false) then
			zombie:Remove()
		end;
	end
end;

--A function to spawn a zombie.
function Schema:SpawnZombie(position)
	local maxZomb = Clockwork.config:Get("max_zomb"):Get();
	if maxZomb > 0 then
		if (self:ZombieCount() < maxZomb) then
			local spawns = {};
			local yes = false;
			local canSpawn = false;
			local spawn;
			
			if !position then
				for k2, player in ipairs(player.GetAll( )) do
			--		if (!self:IsSafe(player)) then
						spawns[#spawns+1] = Schema:GetNavSpawn(player);
						if spawns then
							yes = true
						end;
			--		end;
				end;
			else
				
			end;
			
			if (yes == true) then
				local playerTables = spawns[math.random(1, #spawns)]
				spawn = playerTables[math.random(1, #playerTables)]
				if spawn then
					if (bit.band(util.PointContents( spawn )) == CONTENTS_EMPTY) then
						canSpawn = true;
					end;
				end;
			end;
			
			if (canSpawn == true) then
				local zombie = ents.Create("npc_v_limper")
				zombie:SetPos( spawn )
				print("Spawned zombie at "..tostring(spawn))
				zombie:Spawn()
				zombie:Activate()
			end;
		end;
	end;
end;

--A function to count the amount of zombies.
function Schema:ZombieCount()
	local zombies = 0
	for k, v in ipairs(ents.GetAll()) do
		if (v:IsValid()) then
			if (v:GetClass() == "npc_v_limper") then
				zombies = zombies + 1
			end;
		end;
	end;
	
	return zombies;
end;

--Finds spawnable navpoints near the player.
function Schema:GetNavSpawn(player)
	local position = player:GetPos();
	local spawns = navmesh.Find(position, 3000, 100, 100)
	local noSee = {};
	for k, v in pairs(spawns) do
		for i = 0, 3 do
			local corner = v:GetCorner(i)
			local noSafe = true;
			if (#self.safeAreas > 0) then
				for k2, v2 in pairs(self.safeAreas) do
					if (corner:Distance(v2) < 1000) then
						noSafe = false;
					end;
				end;
			end;
			if (noSafe == true) then
				if (!Schema:CanSeeSpawn(corner)) then
					noSee[#noSee + 1] = corner;
				end;
			end;
		end;
	end;
	return noSee;
end;

function Schema:CanSeeSpawn(spawn)
	local canSee = false;
	local spawnPos = spawn + Vector(0, 0, 100);
	for k, v in pairs(player.GetAll()) do
		if (Clockwork.player:CanSeePosition(v, spawnPos)) then
			canSee = true;
		end;
	end;
	return canSee
end;

-- A function to save the item spawns.
function Schema:SaveSafeAreas()
	Clockwork.kernel:SaveSchemaData("plugins/safeareas/"..game.GetMap(), self.safeAreas);
end;

--Fills a bucket.
function Schema:FillBucket(player, bucket, amount)
	bucket:SetNWInt("Fill", amount);
	Clockwork.player:Notify(player, "You filled the bucket with impure water!");
end;

-- A function to save buckets.
function Schema:SaveBuckets()
	local buckets = {};
	
	for k, v in pairs(ents.GetAll()) do
		if (IsValid(v)) then
			if (v:GetClass() == "prop_physics") then
				local model = v:GetModel();
				if (string.lower(model) == "models/props_junk/metalbucket01a.mdl") then
					local physicsObject = v:GetPhysicsObject();
					local bMoveable = nil;
					local startPos = v:GetStartPosition();
						
					if (IsValid(physicsObject)) then
						bMoveable = physicsObject:IsMoveable();
					end;
						
					buckets[#buckets + 1] = {
						fill = v:GetNWInt("Fill");
						color = { v:GetColor() },
						angles = v:GetAngles(),
						position = v:GetPos(),
						startPos = startPos,
						isMoveable = bMoveable
					};
				end;
			end;
		end;
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/buckets/"..game.GetMap(), buckets);
end;

-- A function to load the buckets.
function Schema:LoadBuckets()
	local buckets = Clockwork.kernel:RestoreSchemaData("plugins/buckets/"..game.GetMap());
	self.buckets = {};
	
	for k, v in pairs(buckets) do
		local entity = ents.FindInSphere((v.startPos or v.position), 16)[1];
			
		if (IsValid(entity) and entity:IsMapEntity()) then
			if (string.lower(entity:GetModel()) == "models/props_junk/metalbucket01a.mdl") then
				
				entity:SetNWInt("Fill", v.fill);
					
				if (IsValid(entity:GetPhysicsObject())) then
					if (!v.isMoveable) then
						entity:GetPhysicsObject():EnableMotion(false);
					else
						entity:GetPhysicsObject():EnableMotion(true);
					end;
				end;
					
				if (v.angles) then
					entity:SetAngles(v.angles);
					entity:SetPos(v.position);
				end;
					
				if (v.color) then
					entity:SetColor(unpack(v.color));
				end;
			end;

		else
			local entity = ents.Create("prop_physics");
			
			entity:SetAngles(v.angles);
			entity:SetModel("models/props_junk/MetalBucket01a.mdl");
			entity:SetPos(v.position);
			entity:Spawn();
			entity:SetNWInt("Fill", v.fill);
			
			if (IsValid(entity:GetPhysicsObject())) then
				if (!v.isMoveable) then
					entity:GetPhysicsObject():EnableMotion(false);
				end;
			end;
			
			if (v.color) then
				entity:SetColor(unpack(v.color));
			end;
		end;
	end;
end;

--A function to toggle Ethereal mode.
function Schema:ToggleEthereal(ply)
	if (ply:GetNetworkedVar("Ethereal", true)) then
		ply:SetNetworkedVar("Ethereal", false);
		ply:DrawWorldModel(true);
		ply:DrawShadow(true);
		ply:SetNoDraw(false);
		ply:SetSolid(SOLID_VPHYSICS)
		local position = ply.ethRag:GetPos();
		ply.ethRag:Remove()
		ply:SetPos(position)
		Clockwork.player:Notify(ply, "You have re-entered your body!");
	else
		local color = ply:GetColor();
		local position = ply:GetPos();
		ply.ethRag = ents.Create("prop_ragdoll")
		ply.ethRag:SetModel(ply:GetModel())
		ply.ethRag:SetPos(position)
		ply.ethRag:Spawn()
		ply.ethRag:SetCollisionGroup( COLLISION_GROUP_WEAPON )	
		ply:SetNetworkedVar("Ethereal", true)
		ply:DrawWorldModel(false);
		ply:DrawShadow(false);
		ply:SetNoDraw(true);
		ply:SetSolid(SOLID_NONE)
		ply:SetColor(Color(color.r, color.g, color.b, 0));
		Clockwork.player:Notify(ply, "You have left your body!");
	end;
end;