--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Schema.gasmaskOverlay = Material("OIIJIOT/respiratordmxmd");
Schema.cameraOverlay = Material("verfall3/outlastcamera");

Clockwork.config:AddToSystem("Big intro text", "intro_text_big", "The big text displayed for the introduction.");
Clockwork.config:AddToSystem("Small intro text", "intro_text_small", "The small text displayed for the introduction.");
Clockwork.config:AddToSystem("Maximum zombies", "max_zomb", "Maximum zombies allowed to spawn", 0, 50)

-- Called when the menu's items should be destroyed.
function Schema:MenuItemsDestroy(menuItems) 
	menuItems:Destroy( Clockwork.option:GetKey("name_business") )
end;

Clockwork.datastream:Hook("PlayCalmSong", function(data)
	Schema.amb:StartSong(Schema.amb:GetRandomCalm())
end)

-- Called each think.
function Schema:Tick()

	if (Clockwork.kernel:IsChoosingCharacter()) then
		if (Schema.currentSong) then
			if (Schema.currentSong:IsPlaying()) then
				Schema.currentSong:Stop()
			end
		end;
	else	
		
		if Schema.songDuration then
			if (Schema.songDuration < CurTime()) then
				Schema.amb:StartSong(Schema.amb:GetRandomCalm())
			end;
		end;

		--Gasmask sound effect.
		local sound = CreateSound(Clockwork.Client, Sound("verfall/gasmask.mp3"))
		if (Clockwork.Client:GetSharedVar("gasmask")) then
			if (!sound:IsPlaying()) then
				sound:Play()
			else
				if (Clockwork.Client:GetNetworkedInt("thirdperson") == 0) then
					sound:ChangeVolume(0.5)
				else
					sound:ChangeVolume(0.3)
				end;
			end;
		else
			if (sound:IsPlaying()) then
				sound:Stop()
			end;
		end;
	end;
	
end;

Clockwork.datastream:Hook("PlaySong", function(data)
	Schema.amb:StartSong(Schema.amb.CalmSongs[data])
end)