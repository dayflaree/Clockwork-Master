--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Blackwatch Soldier");
	CLASS.color = Color( 150, 50, 50, 255); -- The color of this class.
	CLASS.factions = {FACTION_BLACKWATCH}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.wagesName = "USD"; -- What is the name of the "wages" for this class.
	CLASS.description = "A Soldier of the Blackwatch Division."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Wearing A Military Uniform With Standard Equipment"; -- The default physical description for this class.
CLASS_BWS = CLASS:Register();