local CLASS = Clockwork.class:New("Bird");
	CLASS.color = Color( 40, 60, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_BIRD}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.description = "A wild bird."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Is a flying bird."; -- The default physical description for this class.
CLASS_BIRD = CLASS:Register();