local CLASS = Clockwork.class:New("Mutant");
	CLASS.color = Color( 205, 140, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_MUTANT}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.description = "A feral mutant."; -- A short description of the class.
	CLASS.defaultPhysDesc = "A Rotting, ugly, mutated being."; -- The default physical description for this class.
CLASS_MUTANT = CLASS:Register();