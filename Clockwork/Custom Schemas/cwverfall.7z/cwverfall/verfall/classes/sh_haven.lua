local CLASS = Clockwork.class:New("Haven");

	CLASS.color = Color( 255, 240, 0, 255); -- The color of this class.
	CLASS.factions = {FACTION_HAVEN}; -- Which factions can select this class.
	CLASS.isDefault = true; -- Is this the default class for these factions?
	CLASS.description = "An operative of the Haven corporation."; -- A short description of the class.
	CLASS.defaultPhysDesc = "Wearing A uniform bearing the Haven emblem."; -- The default physical description for this class.
	
CLASS_HAVEN = CLASS:Register();