

3 HOLY POINTS:


	1. You need Clockwork to run this at all. 
	2. You need somehow a valid license, I don't know how, work it out yourself. Just don't be an arse and remove my credits!
	3. Don't add me on Steam or send me any PMs for help. I'm DONE with Garry's Mod and I AM NOT offering any support.


Enjoy.
-Blt950