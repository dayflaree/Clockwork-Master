--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Pasta";
ITEM.cost = 5;
ITEM.model = "models/props_junk/MetalBucket01a.mdl";
ITEM.weight = 1.5;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Plain pasta ready to be added something and served.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();