--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Water";
ITEM.cost = 2;
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl";
ITEM.weight = 1;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "A bottle of the best water";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();