COMMAND = Clockwork.command:New("Help");
COMMAND.tip = "Request roleplay help to online admins.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local audience = {}
	local text = table.concat(arguments, " ");
	
	if (text == "") then
		Clockwork.player:Notify(player, "You did not specify enough text!");
		
		return;
	end;
	
	for k, v in ipairs( _player.GetAll() ) do
		local vt = v:IsAdmin() or v:IsUserGroup("operator");
		if vt == true then table.insert(audience, v) end;
	end;
	table.insert(audience, player);
	for k, v in pairs(audience) do
		v:SendLua("chat.AddText(Color(255,255,0),[[Help Request from "..player:Name()..": ]],Color(0,255,0),[["..text.."]])");
		v:SendLua("surface.PlaySound( 'buttons/button10.wav' )")
	end;
end;

COMMAND:Register()