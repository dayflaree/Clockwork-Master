local RECIPE = Clockwork.recipe:New("Pasta Carbonara");
	RECIPE:Require("egg", 2, 0);
	RECIPE:Require("pasta", 1, 0);
	RECIPE:Require("cheese_sauce", 1, 0);

	RECIPE:Output("pasta_carbonara", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/alfredo01/alfredo01.mdl";
	RECIPE.description = "Create pasta with cheese and egg sauce.";
	RECIPE.category = "Food"
RECIPE:Register();