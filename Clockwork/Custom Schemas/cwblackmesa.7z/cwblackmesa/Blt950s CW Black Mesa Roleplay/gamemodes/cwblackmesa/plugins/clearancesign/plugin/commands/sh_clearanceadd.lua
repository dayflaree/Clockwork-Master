--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("ClearanceAdd");
COMMAND.tip = "Add clearance sign to a surface.";
COMMAND.text = "<markup Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local traceLine = player:GetEyeTraceNoCursor();
	local fScale = 3;
	
	if (fScale) then
		fScale = fScale * 0.25;
	end;
	
	local data = {
		text = arguments[1],
		scale = fScale,
		angles = traceLine.HitNormal:Angle(),
		position = traceLine.HitPos + (traceLine.HitNormal * 1.25)
	};
	
	data.angles:RotateAroundAxis(data.angles:Forward(), 90);
	data.angles:RotateAroundAxis(data.angles:Right(), 270);
	
	Clockwork.datastream:Start(nil, "ClearanceSignsAdd", data);
	
	cwClearanceSigns.storedList[#cwClearanceSigns.storedList + 1] = data;
	cwClearanceSigns:SaveClearanceSigns();
	
	Clockwork.player:Notify(player, "You have added a clearance sign.");
end;

COMMAND:Register();