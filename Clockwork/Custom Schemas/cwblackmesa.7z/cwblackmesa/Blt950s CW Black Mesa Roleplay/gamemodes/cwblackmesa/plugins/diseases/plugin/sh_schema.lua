local PLUGIN = PLUGIN;

Clockwork.flag:Add("q", "Light Medicaments", "Access to light medicaments.");
Clockwork.flag:Add("Q", "Heavy Medicaments", "Access to heavy medicaments.");