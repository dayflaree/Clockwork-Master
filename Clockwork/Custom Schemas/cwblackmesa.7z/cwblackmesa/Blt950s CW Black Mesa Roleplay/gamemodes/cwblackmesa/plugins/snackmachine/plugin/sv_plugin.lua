--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;

-- A function to load the ration snackmachines.
function PLUGIN:LoadSnackMachines()
	local snackmachines = Clockwork.kernel:RestoreSchemaData("plugins/snackmachines/"..game.GetMap());
	
	for k, v in pairs(snackmachines) do
		local entity = ents.Create("cw_snackmachine");
		
		entity:SetPos(v.position);
		entity:Spawn();
		
		if ( IsValid(entity) ) then
			entity:SetAngles(v.angles);
			entity:SetStock(v.stock, v.defaultStock);
		end;
	end;
end;

-- A function to save the ration snackmachines.
function PLUGIN:SaveSnackMachines()
	local snackmachines = {};
	
	for k, v in pairs(ents.FindByClass("cw_snackmachine")) do
		snackmachines[#snackmachines + 1] = {
			stock = v:GetStock(),
			angles = v:GetAngles(),
			position = v:GetPos(),
			defaultStock = v:GetDefaultStock()
		};
	end;
	
	Clockwork.kernel:SaveSchemaData("plugins/snackmachines/"..game.GetMap(), snackmachines);
end;