--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Vegetables Mix";
ITEM.cost = 2;
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl";
ITEM.weight = 1;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Delicious canned vegetables mix.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();