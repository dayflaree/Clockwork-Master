--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Fast Green Liquid Syringe";
ITEM.uniqueID = "fast_green_liquid";
ITEM.cost = 50;
ITEM.model = "models/katharsmodels/syringe_out/syringe_out.mdl";
ITEM.weight = 0.2;
ITEM.factions = {FACTION_MPF};
ITEM.useText = "Use";
ITEM.category = "Medical";
ITEM.business = false;
ITEM.description = "A syringe with a green liqud only thing that the label says is 'Fast'";
ITEM.customFunctions = {"Inject"};

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetCharacterData( "diseases", "fast_deathinjection" );
	Clockwork.player:Notify(player, "You've injected the green liqud inside your own veins.");
end;

if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (name == "Inject") then
			local lookingPly = player:GetEyeTrace().Entity
			if lookingPly:IsPlayer() then
				lookingPly:SetCharacterData( "diseases", "fast_deathinjection" );
				Clockwork.player:Notify(player, "You injected the green liqud inside the person.");
				player:TakeItem(player:FindItemByID("fast_green_liqud"));
			else
				Clockwork.player:Notify(player, "You must target a person!");
				return false;
			end;
		end;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();