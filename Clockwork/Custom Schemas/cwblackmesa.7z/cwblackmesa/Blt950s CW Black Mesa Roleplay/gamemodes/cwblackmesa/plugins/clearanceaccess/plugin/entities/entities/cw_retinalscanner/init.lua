--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

-- Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/props_lab/retinalscanner.mdl");
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetUseType(SIMPLE_USE);
	self:SetHealth(100);
	self:SetSolid(SOLID_VPHYSICS);
	
	local physicsObject = self:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		physicsObject:Wake();
		physicsObject:EnableMotion(false);
	end;
end;

-- Called when the entity's transmit state should be updated.
function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS;
end;

-- A function to configure the scanner.
function ENT:Configure(ID, clearance, autoclose)
	self:SetDoorID(ID);
	self:SetDoorClearance(clearance);
	if autoclose != nil then
		self:SetAutoclose(autoclose);
	end
end;

local nextUse = CurTime()
function ENT:Use(activator)
	if CurTime() > nextUse then
		nextUse = CurTime() + 5
		for k,v in pairs(ents.GetAll()) do
			if v:GetNetworkedInt("doorID") == self:GetDoorID() then
				self:EmitSound("npc/roller/mine/combine_mine_deploy1.wav", 70, 50)
				timer.Simple(1.5, function()
					if Schema:HasClearance(activator, self:GetDoorClearance()) then
						self:EmitSound("buttons/button3.wav", 70, 100);
						v:Fire("Open", "", 1.5)
						if self:GetAutoclose() != nil and self:GetAutoclose() != 0 then 
							v:Fire("Close", "", self:GetAutoclose()+1.5)
						end
					else
						self:EmitSound("buttons/button8.wav", 70, 100);
					end		
				end)	
			end
		end
	end
end
