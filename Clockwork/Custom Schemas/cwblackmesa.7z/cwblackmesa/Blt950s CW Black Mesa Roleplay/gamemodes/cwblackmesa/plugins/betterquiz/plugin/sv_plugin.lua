local PLUGIN = PLUGIN;

function PLUGIN:Initialize()
	
end;
