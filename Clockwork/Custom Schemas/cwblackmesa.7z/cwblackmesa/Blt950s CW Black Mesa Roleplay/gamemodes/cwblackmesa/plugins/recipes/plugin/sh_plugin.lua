local Clockwork = Clockwork;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

-- Called when the schema has been loaded.
function PLUGIN:ClockworkSchemaLoaded()
	for k, v in pairs(Clockwork.plugin.stored) do
		if (!Clockwork.plugin:IsDisabled(v.name) and !Clockwork.plugin:IsUnloaded(v.name)) then
			local pluginDirectory = v:GetBaseDir().."/recipes/";

			Clockwork.kernel:IncludeDirectory(pluginDirectory);
		end;
	end;
end;

if (SERVER) then
	Clockwork.config:Add("crafting_enabled", true, true);
	Clockwork.config:Add("crafting_radius", 64, true);
else
	Clockwork.config:AddToSystem("Crafting enabled", "crafting_enabled", "Whether or not the crafting system is enabled.");
	Clockwork.config:AddToSystem("Crafting radius", "crafting_radius", "How close a player has to be to an entity when the recipe requires it.");
end;

Clockwork.config:ShareKey("crafting_enabled");
Clockwork.config:ShareKey("crafting_radius");