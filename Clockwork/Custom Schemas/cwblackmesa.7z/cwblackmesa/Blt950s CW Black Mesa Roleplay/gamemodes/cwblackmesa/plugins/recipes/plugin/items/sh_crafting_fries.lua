
--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "French Fries";
ITEM.cost = 2;
ITEM.model = "models/props_junk/glassjug01.mdl";
ITEM.weight = 0.8;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Delicious food french fries.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();