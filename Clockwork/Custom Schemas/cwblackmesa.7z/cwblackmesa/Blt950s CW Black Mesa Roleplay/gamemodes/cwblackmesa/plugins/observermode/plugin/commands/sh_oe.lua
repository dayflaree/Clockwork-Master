--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;

local COMMAND = Clockwork.command:New("Oe");
COMMAND.tip = "Enforce the observer exit position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (player:Alive() and !player:IsRagdolled() and !player.cwObserverReset) then
		PLUGIN:EnforcePlayerObserverMode(player);
	end;
end;

COMMAND:Register();