--[[
	� 2013 HeartBit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;
util.AddNetworkString("cw_runTutorial")

-- Called when a player's character data should be restored.
function PLUGIN:PlayerRestoreData(player, data)
	if ( !data["introplayed"] ) then
		data["introplayed"] = false;
	end

	if ( !data["tutorialsplayed"] ) then
		data["tutorialsplayed"] = {}
		data["tutorialsplayed"]["Scientist"] = false;
		data["tutorialsplayed"]["Security"] = false;
		data["tutorialsplayed"]["Visitor"] = false;
		data["tutorialsplayed"]["Director"] = false;
	end;
end;

-- Called when a character is loaded.
function PLUGIN:PlayerCharacterLoaded(player)
	local tutorialsplayed = player:GetData("tutorialsplayed") or {}
	local introplayed = player:GetData("introplayed")
	local link

	if player:GetFaction() == FACTION_SCIENTIST and tutorialsplayed["Scientist"] == false then

		timer.Simple(1.5, function() player:SendLua("LocalPlayer():ConCommand('stopsound')") end)
		link = "http://www.youtube.com/embed/mTko_5swv4o?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"

		tutorialsplayed["Scientist"] = true
		player:SetData("tutorialsplayed", tutorialsplayed)

	elseif player:GetFaction() == FACTION_SECURITY and tutorialsplayed["Security"] == false then

		timer.Simple(1.5, function() player:SendLua("LocalPlayer():ConCommand('stopsound')") end)
		link = "http://www.youtube.com/embed/XQHiEiZrw9U?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"

		tutorialsplayed["Security"] = true
		player:SetData("tutorialsplayed", tutorialsplayed)

	elseif player:GetFaction() == FACTION_VISITOR and tutorialsplayed["Visitor"] == false then
		
		timer.Simple(1.5, function() player:SendLua("LocalPlayer():ConCommand('stopsound')") end)
		link = "http://www.youtube.com/embed/Xe9sIqkbnw4?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"

		tutorialsplayed["Visitor"] = true
		player:SetData("tutorialsplayed", tutorialsplayed)

	elseif player:GetFaction() == FACTION_DIRECTOR and tutorialsplayed["Director"] == false then
		
		timer.Simple(1.5, function() player:SendLua("LocalPlayer():ConCommand('stopsound')") end)
		link = "http://www.youtube.com/embed/GSieRi0AgZg?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"

		tutorialsplayed["Director"] = true
		player:SetData("tutorialsplayed", tutorialsplayed)

	end

	if link then
		if !introplayed then player:SetData("introplayed", true) end
		net.Start("cw_runTutorial")
			net.WriteString(link)
			if introplayed then
				net.WriteBit(false)
			else
				net.WriteBit(true)
			end
		net.Send(player)
	end
end;