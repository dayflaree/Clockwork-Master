--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

surface.CreateFont( "ClearanceLevel", {
	 font = "Arial Black",
	 size = 106,
	 weight = 1400,
	 blursize = 0,
	 scanlines = 0,
	 antialias = true,
	 underline = false,
	 italic = false,
	 strikeout = false,
	 symbol = false,
	 rotary = false,
	 shadow = false,
	 additive = false,
	 outline = false
	} )

	surface.CreateFont( "Clearance", {
	 font = "Arial",
	 size = 50,
	 weight = 400,
	 blursize = 0,
	 scanlines = 0,
	 antialias = true,
	 underline = false,
	 italic = false,
	 strikeout = false,
	 symbol = false,
	 rotary = false,
	 shadow = false,
	 additive = false,
	 outline = false
	} )

-- Called just after the translucent renderables have been drawn.
function cwClearanceSigns:PostDrawTranslucentRenderables(bDrawingDepth, bDrawingSkybox)
	if (bDrawingSkybox or bDrawingDepth) then return; end;
	
	local large3D2DFont = Clockwork.option:GetFont("large_3d_2d");
	local colorWhite = Clockwork.option:GetColor("white");
	local eyeAngles = EyeAngles();
	local eyePos = EyePos();
	
	cam.Start3D(eyePos, eyeAngles);
		for k, v in pairs(self.storedList) do
			local alpha = math.Clamp(
				Clockwork.kernel:CalculateAlphaFromDistance(1024, eyePos, v.position) * 1.5, 0, 255
			);
			
			if (alpha > 0) then
				if (!v.markupObject) then
					v.markupObject = markup.Parse(
						"<font=ClearanceLevel><colour=255,0,0,255>"..string.gsub(" Level "..v.text, "\\n", "\n").."\n</colour></font><font=Clearance><colour=255,255,255,255>    CLEARANCE</colour></font>"
					);
					Clockwork.kernel:OverrideMarkupDraw(v.markupObject);
				end;
				
				cam.Start3D2D(v.position, v.angles, (v.scale or 0.25) * 0.2);
					//draw.RoundedBox( 8, -150, -50, 300, 200, Color(255,255,255,alpha))
					//draw.RoundedBox( 8, -125, -23, 250, 50, Color(0,0,0,alpha))
					render.PushFilterMin(TEXFILTER.ANISOTROPIC);
					render.PushFilterMag(TEXFILTER.ANISOTROPIC);
							v.markupObject:Draw(0, 40, 1, nil, alpha);
					render.PopFilterMag();
					render.PopFilterMin();
				cam.End3D2D();
			end;
		end;
	cam.End3D();
end;