--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;


Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");