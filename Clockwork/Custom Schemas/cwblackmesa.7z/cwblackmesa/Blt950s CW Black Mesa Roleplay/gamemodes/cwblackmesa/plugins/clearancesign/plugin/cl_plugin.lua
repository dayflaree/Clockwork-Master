--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.datastream:Hook("ClearanceSigns", function(data)
	cwClearanceSigns.storedList = data;
end);

Clockwork.datastream:Hook("ClearanceSignsAdd", function(data)
	cwClearanceSigns.storedList[#cwClearanceSigns.storedList + 1] = data;
end);

Clockwork.datastream:Hook("ClearanceSignsRemove", function(data)
	for k, v in pairs(cwClearanceSigns.storedList) do
		if (v.position == data) then
			cwClearanceSigns.storedList[k] = nil;
		end;
	end;
end);