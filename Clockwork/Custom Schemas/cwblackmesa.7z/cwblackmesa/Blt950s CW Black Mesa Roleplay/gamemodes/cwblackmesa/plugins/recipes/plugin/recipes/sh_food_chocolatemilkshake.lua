local RECIPE = Clockwork.recipe:New("Chocolate Milkshake");
	RECIPE:Require("milk", 1, 0);
	RECIPE:Require("chocolate_icecream", 1, 0);

	RECIPE:Output("chocolate_milkshake", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/chocolateshake01/chocolateshake01.mdl";
	RECIPE.description = "Create a burger with meat, and french fries.";
	RECIPE.category = "Food"
RECIPE:Register();