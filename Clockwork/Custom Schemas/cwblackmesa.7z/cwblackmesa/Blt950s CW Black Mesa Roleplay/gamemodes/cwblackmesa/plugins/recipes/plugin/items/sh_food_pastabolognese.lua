--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Pasta Bolognese";
ITEM.model = "models/bowlofspaghetti01/bowlofspaghetti01.mdl";
ITEM.weight = 1;
ITEM.useText = "Eat";
ITEM.category = "Crafted Food";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Delicious pasta with tomato sauce.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)	
	player:BoostAttribute(self.name, ATB_AGILIY, 2, 120);
	player:BoostAttribute(self.name, ATB_DEXTERITY, 1, 120);
end;


ITEM:Register();