local RECIPE = Clockwork.recipe:New("Pasta Bolognese");
	RECIPE:Require("meat", 1, 0);
	RECIPE:Require("fries", 1, 0);
	RECIPE:Require("hamburger_bread", 1, 0);

	RECIPE:Output("hamburger_with_fries", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/burgerplate01/burgerplate01.mdl";
	RECIPE.description = "Create a burger with meat, and french fries.";
	RECIPE.category = "Food"
RECIPE:Register();