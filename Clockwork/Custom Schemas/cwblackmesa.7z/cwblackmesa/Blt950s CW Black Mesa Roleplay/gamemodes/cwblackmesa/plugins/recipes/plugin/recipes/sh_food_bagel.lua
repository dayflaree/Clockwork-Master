local RECIPE = Clockwork.recipe:New("Bagel");
	RECIPE:Require("milk", 1, 0);
	RECIPE:Require("egg", 1, 0);
	RECIPE:Require("yeast", 1, 0);

	RECIPE:Output("bagel", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/twinkie01/twinkie01.mdl";
	RECIPE.description = "Create a burger with meat, and french fries.";
	RECIPE.category = "Food"
RECIPE:Register();