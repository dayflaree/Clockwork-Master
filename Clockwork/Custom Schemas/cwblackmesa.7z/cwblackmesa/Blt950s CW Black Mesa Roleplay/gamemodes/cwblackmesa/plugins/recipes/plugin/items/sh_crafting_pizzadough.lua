--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Pizza Dough";
ITEM.cost = 1;
ITEM.model = "models/props_junk/garbage_bag001a.mdl";
ITEM.weight = 1.5;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Fresh plain pizza dough packed in, needs to be added something more and put in oven to eat.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();