--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("TriggerEvent");
COMMAND.tip = "Trigger a map/script event.";
COMMAND.text = "<Event ID>";
COMMAND.access = "o";
COMMAND.optionalArguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local eventID = tonumber( arguments[1] );
	
	if eventID then
		if eventID == 1 then
			self:TriggerEvent("light_reception_trigger_START")
		elseif eventID == 2 then
			for k,v in pairs(ents.GetAll()) do
				local isComputer = (v:GetClass() == "prop_dynamic" or v:GetClass() == "prop_physics") and (v:GetModel() == "models/props_office/computer_monitor01.mdl" or v:GetModel() == "models/props_office/computer_monitor04.mdl")
				if isComputer then
					v:SetSkin(4)
				end
			end
		elseif eventID == 3 then
			Clockwork.kernel:SetSharedVar("comFailed", true);
		end
		Clockwork.player:Notify(player, "You've triggered EventID "..eventID);
	else
		Clockwork.player:Notify(player, "List of available events:");
		Clockwork.player:Notify(player, "1 - Light failure in reception.");
		Clockwork.player:Notify(player, "2 - BSOD all computers.");
		Clockwork.player:Notify(player, "3 - Communication servers crash.");
	end
end;

function COMMAND:TriggerEvent(name)
	for k,v in pairs(ents.FindByName(name)) do
		v:Fire("Trigger", "", 0);
	end
end

COMMAND:Register();