--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	self:LoadVendingMachines();
end;

-- Called just after data should be saved.
function PLUGIN:PostSaveData()
	self:SaveVendingMachines();
end;