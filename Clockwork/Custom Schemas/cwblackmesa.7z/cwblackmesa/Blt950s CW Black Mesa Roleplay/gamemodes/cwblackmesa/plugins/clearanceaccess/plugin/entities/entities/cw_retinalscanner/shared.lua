--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "Blt950";
ENT.PrintName = "Retinalscanner";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;

-- Called when the datatables are setup.
function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "DoorID" );
	self:NetworkVar( "String", 1, "DoorClearance" );
	self:NetworkVar( "Int", 2, "Autoclose" );
end;