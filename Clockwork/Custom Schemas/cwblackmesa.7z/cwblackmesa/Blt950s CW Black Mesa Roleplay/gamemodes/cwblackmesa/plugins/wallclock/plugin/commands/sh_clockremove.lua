--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("ClockRemove");
COMMAND.tip = "Remove clocks from a surface.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos;
	local iRemoved = 0;
	
	for k, v in pairs(cwClocks.storedList) do
		if (v.position:Distance(position) <= 256) then
			Clockwork.datastream:Start(nil, "ClocksRemove", v.position);
				cwClocks.storedList[k] = nil;
			iRemoved = iRemoved + 1;
		end;
	end;
	
	if (iRemoved > 0) then
		if (iRemoved == 1) then
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." clocks.");
		else
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." clocks.");
		end;
	else
		Clockwork.player:Notify(player, "There were no clocks near this position.");
	end;
	
	cwClocks:SaveClocks();
end;

COMMAND:Register();