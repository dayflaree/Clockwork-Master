--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when Clockwork has loaded all of the entities.
function cwClearanceSigns:ClockworkInitPostEntity() self:LoadClearanceSigns(); end;

-- Called when a player's data stream info should be sent.
function cwClearanceSigns:PlayerSendDataStreamInfo(player)
	Clockwork.datastream:Start(player, "ClearanceSigns", self.storedList);
end;