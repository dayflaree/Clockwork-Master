--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- A function to load the clearance signs.
function cwClocks:LoadClocks()
	self.storedList = Clockwork.kernel:RestoreSchemaData("plugins/clocks/"..game.GetMap());
end;

-- A function to save the clearance signs.
function cwClocks:SaveClocks()
	Clockwork.kernel:SaveSchemaData("plugins/clocks/"..game.GetMap(), self.storedList);
end;