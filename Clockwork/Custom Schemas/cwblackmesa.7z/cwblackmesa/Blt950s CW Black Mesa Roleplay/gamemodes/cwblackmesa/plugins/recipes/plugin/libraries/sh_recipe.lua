local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

Clockwork.recipe = Clockwork.kernel:NewLibrary("Recipe");
Clockwork.recipe.stored = {};

local RECIPE = {__index = RECIPE};

-- A function to register a new recipe.
function RECIPE:Register()
	return Clockwork.recipe:Register(self, self.name);
end;

-- A function to add an item to a recipe's requirements.
function RECIPE:Require(uniqueID, amountRequired, amountToTake)
	if (!uniqueID) then return; end;

	self.required[uniqueID] = amountRequired or 1;
	self.take[uniqueID] = amountToTake or amountRequired or 1;
end;

-- A function to require a nearby entity for the recipe.
function RECIPE:RequireEntity(class, name)
	if (!class) then return; end;

	self.requiredEnts[class] = name or class;
end

-- A function to require an attribute to be a certain percentage.
function RECIPE:RequireAttrib(attrib, value)
	if (!attrib) then return; end;

	self.requiredAttribs[attrib] = value;
end

-- A function to require a player to be in a certain faction.
function RECIPE:Factions(...)
	self.factions = {...};
end

-- A function to add an item to a recipe's output.
function RECIPE:Output(uniqueID, amount)
	if (!uniqueID) then return; end;

	self.output[uniqueID] = amount or 1;
end;

if (SERVER) then
	-- A function to craft the recipe.
	function RECIPE:Craft(player)
		for k, v in pairs(self.required) do
			local name = Clockwork.item:FindByID(k)("name");
			local itemsList = Clockwork.inventory:FindItemsByName(player:GetInventory(), k, name);
		
			if (!itemsList or table.Count(itemsList) < v) then
				Clockwork.plugin:Call("PlayerFailedToCraftRecipe", player, self);

				return;
			end;
		end;

		if (Clockwork.plugin:Call("ShouldPlayerCraftRecipe", player, self)) then
			Clockwork.plugin:Call("PlayerCraftedRecipe", player, self);
		else
			Clockwork.plugin:Call("PlayerFailedToCraftRecipe", player, self);
		end;
	end;

	local playerMeta = FindMetaTable("Player");

	function playerMeta:Craft(name)
		local RECIPE = Clockwork.recipe:FindByID(name);

		if (!RECIPE) then return; end;

		return RECIPE:Craft(self);
	end;

	function playerMeta:CanCraft(name)
		local RECIPE = Clockwork.recipe:FindByID(name);

		if (!RECIPE) then return; end;

		for k, v in pairs(RECIPE.required) do
			name = Clockwork.item:FindByID(k)("name");
			local itemsList = Clockwork.inventory:FindItemsByName(self:GetInventory(), k, name);
		
			if (!itemsList or table.Count(itemsList) < v) then
				return false;	
			end;
		end;

		return true;
	end;
end;

-- A function to register a new recipe.
function Clockwork.recipe:Register(data, name)
	local realName = string.gsub(name, "%s", "");
	local uniqueID = string.lower(realName);
	
	self.stored[uniqueID] = data;
	
	return self.stored[uniqueID];
end;

-- A function to create a new recipe.
function Clockwork.recipe:New(name)
	local object = Clockwork.kernel:NewMetaTable(RECIPE);
		object.name = name or "Unknown";
		object.required = {};
		object.requiredEnts = {};
		object.requiredAttribs = {};
		object.output = {};
		object.take = {};
		object.category = "Miscellaneous";
		object.model = "models/props_lab/clipboard.mdl"
		object.description = "An undescribed recipe.";
	return object;
end;

-- A function to find a recipe by an identifier.
function Clockwork.recipe:FindByID(identifier)
	return self.stored[string.lower(string.gsub(identifier, "%s", ""))];
end;

-- A function to get all recipes.
function Clockwork.recipe:GetAll()
	return self.stored;
end;