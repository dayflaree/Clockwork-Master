local RECIPE = Clockwork.recipe:New("Peperoni Pizza");
	RECIPE:Require("pizza_dough", 1, 0);
	RECIPE:Require("peperoni", 1, 0);

	RECIPE:Output("peperoni_pizza", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/peppizza02/peppizza02.mdl";
	RECIPE.description = "Create a burger with meat, and french fries.";
	RECIPE.category = "Food"
RECIPE:Register();