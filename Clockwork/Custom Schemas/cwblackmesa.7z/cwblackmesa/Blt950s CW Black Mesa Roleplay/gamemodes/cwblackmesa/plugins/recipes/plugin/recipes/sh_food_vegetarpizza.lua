local RECIPE = Clockwork.recipe:New("Vegetar Pizza");
	RECIPE:Require("pizza_dough", 1, 0);
	RECIPE:Require("vegetables_mix", 1, 0);

	RECIPE:Output("vegetar_pizza", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/workspizza03/workspizza03.mdl";
	RECIPE.description = "Create a burger with meat, and french fries.";
	RECIPE.category = "Food"
RECIPE:Register();