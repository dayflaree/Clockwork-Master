--[[
	� 2013 HeartBit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;

local nextTrigger = CurTime();
function PLUGIN:PlayerThink(player, curTime, infoTable)
	if CurTime() > nextTrigger then
		if math.random(1,50) == 25 then
			local random = math.random(1,2);
			
			if random == 1 then
				self:TriggerEvent("light_reception_trigger_START")
			elseif random == 2 then
				Clockwork.kernel:SetSharedVar("comFailed", true)
			end
			
		end
		nextTrigger = CurTime() + math.random(300,600);
	end
end;

function PLUGIN:TriggerEvent(name)
	for k,v in pairs(ents.FindByName(name)) do
		v:Fire("Trigger", "", 0);
	end
end

function PLUGIN:KeyPress(player, key)
	local ent = player:GetEyeTrace().Entity
	if (key == IN_USE and IsValid(ent) and ent:GetClass() == "prop_dynamic" and player:GetFaction() == FACTION_MAINTENANCE) then
		local entName = player:GetEyeTrace().Entity:GetName()
		if ent:GetPos() == Vector(473.000000, 1104.000000, 493.0000000) then
			Clockwork.kernel:SetSharedVar("comFailed", false)
		elseif entName == "light_reception_box" then
			self:TriggerEvent("light_reception_trigger_STOP");
		end
	end
end