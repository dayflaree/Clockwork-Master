--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.datastream:Hook("Clocks", function(data)
	cwClocks.storedList = data;
end);

Clockwork.datastream:Hook("ClocksAdd", function(data)
	cwClocks.storedList[#cwClocks.storedList + 1] = data;
end);

Clockwork.datastream:Hook("ClocksRemove", function(data)
	for k, v in pairs(cwClocks.storedList) do
		if (v.position == data) then
			cwClocks.storedList[k] = nil;
		end;
	end;
end);