local RECIPE = Clockwork.recipe:New("Pasta Bolognese");
	RECIPE:Require("pasta", 1, 0);
	RECIPE:Require("tomato_sauce", 1, 0);

	RECIPE:Output("pasta_bolognese", 1);

	RECIPE:Factions("Chef");
	RECIPE.model = "models/bowlofspaghetti01/bowlofspaghetti01.mdl";
	RECIPE.description = "Create a pasta with tomato sauce.";
	RECIPE.category = "Food"
RECIPE:Register();