--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "Great Minds Physically";
ITEM.cost = 6;
ITEM.model = "models/props_lab/bindergreenlabel.mdl";
ITEM.uniqueID = "book_aa";
ITEM.business = false;
ITEM.description = "A book with an antlion on the front.";
ITEM.bookInformation = [[
<h2>Great Minds Physically</h2>
<h3>The Importance of Mental and Physical Health.</h3>
<h4><font color='gray'>By: Peter Brayhem</font></h4>

Keeping your mental and physical health intact is extremely important when working with science. 
You may ask yourself, how come? Well, the mental health might be somewhat more obvious but 
science is in your brain which means the brain must be completely functional and stay such at
all times. 
   Our minds consists of five main cognitive functions:

* memory,
* attention,
* language,
* visual-spatial skills,
* and executive function.

It's important to challenge, stimulate and effectively exercise all five areas to stay mentally
sharp. There are many mental exercises, some are more intensive whilst other can be simple
such as solving crosswords, something you can do while sitting on the transit system waiting 
for arrival to your sector. Another exercise you can do while you are at home is; try to 
remember the grocery list before you go to the store, which will stimulate your memory. Games 
like chess is also a great activity for your brain. You can read more about mental activities
in my other book; "Great Brain - Great Result".

Physical health is another important matter. Results of not taking care of your body physically 
may impact your research and other work a lot more than you would expect. 
   There are ways to exercise, a lot of ways. This may sound somewhat boring, and not something
you would prefer doing. This requires motivation. Motivation is key for working out. I know at 
least one way which may motivate you, there is something called the "7-minute workout" which 
describes itself. It is a workout which only takes seven minutes of your day. It consist of
different exercises each 30 seconds and another ten seconds break after each exercise.
   These exercises are the following:
   
* jumping jacks,
* wall sit,
* push-up,
* abdominal crunch,
* step-up onto chair,
* squat,
* triceps dip on chair,
* plank,
* high knees running in place,
* lunge,
* push-up and rotation,
* and side plank.

Doing these 12 exercises, 30 seconds each and a 10 seconds break after each one two or three times
a day will keep you stable physically although it is highly recommended going to the gym once or
twice a week aswell, but start slowly, do not over-exercise your body as that is bad. Start with
the scientific 7-min workout once or twice a day and after a month go to the gym aswell once
a week and gradually do more and more and you will feel amazing.

Take all of this information into consideration and good luck!
]];

ITEM:Register();