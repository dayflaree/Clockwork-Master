--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- A function to load the clearance signs.
function cwClearanceSigns:LoadClearanceSigns()
	self.storedList = Clockwork.kernel:RestoreSchemaData("plugins/clearances/"..game.GetMap());
end;

-- A function to save the clearance signs.
function cwClearanceSigns:SaveClearanceSigns()
	Clockwork.kernel:SaveSchemaData("plugins/clearances/"..game.GetMap(), self.storedList);
end;