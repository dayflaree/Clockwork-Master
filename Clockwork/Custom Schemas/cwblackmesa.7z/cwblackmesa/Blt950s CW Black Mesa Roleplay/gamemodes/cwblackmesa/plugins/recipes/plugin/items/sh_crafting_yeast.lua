--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Yeast";
ITEM.cost = 1;
ITEM.model = "models/props_lab/box01b.mdl";
ITEM.weight = 0.2;
ITEM.category = "Food Crafting";
ITEM.factions = {FACTION_CHEF};
ITEM.business = false;
ITEM.description = "Yeast to grow your dough.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();