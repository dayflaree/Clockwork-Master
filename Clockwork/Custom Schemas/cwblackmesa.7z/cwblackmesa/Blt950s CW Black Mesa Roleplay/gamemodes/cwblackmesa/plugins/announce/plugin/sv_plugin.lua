local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PlayAnnouncement()
	if !nextPlay or CurTime() > nextPlay then
		local play = "heartbit/announcements/"..math.Round(math.random(1,20))..".wav"
		sound.Play( play, Vector(370.792755, 750.551147, 676.030640), 75, 100, 1 )
		sound.Play( play, Vector(-1901.190918, 392.885559, 2426.50244), 75, 100, 1 )
		sound.Play( play, Vector(-1005.466492, 3205.408203, 383.357849), 75, 100, 1 )
		
		nextPlay = CurTime() + math.random(60,300)
	end
end
hook.Add("Think", "PlayAnnouncement", PlayAnnouncement)