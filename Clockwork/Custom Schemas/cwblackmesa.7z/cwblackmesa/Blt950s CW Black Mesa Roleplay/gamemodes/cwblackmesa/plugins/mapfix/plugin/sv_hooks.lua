--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity()
	for k, v in pairs(ents.FindByClass("env_explosion")) do
		v:SetKeyValue("spawnflags","3")
	end
end;