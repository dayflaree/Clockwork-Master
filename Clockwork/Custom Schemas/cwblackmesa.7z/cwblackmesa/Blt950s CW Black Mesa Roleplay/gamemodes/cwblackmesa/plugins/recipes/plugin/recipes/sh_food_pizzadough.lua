local RECIPE = Clockwork.recipe:New("Pizza Dough");
	RECIPE:Require("egg", 1, 0);
	RECIPE:Require("flour", 1, 0);
	RECIPE:Require("yeast", 1, 0);
	RECIPE:Require("water", 1, 0);
	RECIPE:Require("oil", 1, 0);
	RECIPE:Output("pizza_dough", 1);
	RECIPE:Factions("Chef");
	RECIPE.model = "models/props_junk/garbage_bag001a.mdll";
	RECIPE.description = "Create a pizza dough for future use.";
	RECIPE.category = "Food"
RECIPE:Register();