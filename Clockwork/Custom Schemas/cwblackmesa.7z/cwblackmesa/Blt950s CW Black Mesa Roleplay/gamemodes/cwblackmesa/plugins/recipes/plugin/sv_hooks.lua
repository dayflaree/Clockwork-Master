local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

-- Called when a player crafts a recipe.
function Clockwork:PlayerCraftedRecipe(player, recipeTable)
	local message = "Success! Crafted the "..recipeTable.name.." recipe!";
	local requiredEnts = recipeTable.requiredEnts;

	for k, v in pairs(recipeTable.required) do
		local amountToTake = recipeTable.take[k];
		
		if (amountToTake) then
			if (amountToTake > 0) then
				for i = 1, amountToTake do
					player:TakeItem(player:FindItemByID(k));
				end;
			end;
		else
			for i = 1, v do
				player:TakeItem(player:FindItemByID(k));
			end;
		end;
	end;

	for k, v in pairs(recipeTable.output) do
		local itemTable = Clockwork.item:FindByID(k);

		for i = 1, v do
			itemTable = Clockwork.item:CreateInstance(k);
			player:GiveItem(itemTable, true);
		end;
	end;

	if (recipeTable.OnSuccess) then
		local returnedMessage = recipeTable:OnSuccess(player);

		player:Notify(returnedMessage or message);
	else
		player:Notify(message);
	end;
end;

-- Called when a player fails to craft a recipe.
function Clockwork:PlayerFailedToCraftRecipe(player, recipeTable)
	local message = "You do not have all of the requirements for this recipe!";

	if (recipeTable.OnFailure) then
		local returnedMessage = recipeTable:OnFailure(player);

		player:Notify(returnedMessage or message);
	else
		player:Notify(message);
	end;
end;

function Clockwork:ShouldPlayerCraftRecipe(player, recipeTable)
	local requiredEnts = recipeTable.requiredEnts;
	local cost = recipeTable.cost;
	local requiredAttribs = recipeTable.requiredAttribs;

	if (requiredEnts) then
		for k, v in pairs(requiredEnts) do
			for k2, v2 in pairs(ents.FindByClass(k)) do
				if !(player:GetPos():Distance(v2:GetPos()) <= Clockwork.config:Get("crafting_radius"):Get()) then
					return false;
				end;
			end;
		end;
	end;

	if (requiredAttribs) then
		local playerAttribs = player:GetAttributes();

		for k, v in pairs(requiredAttribs) do
			for k2, v2 in pairs(playerAttribs) do
				local attribName = self.attribute:GetAll()[k2].name;

				if (k == attribName) then
					if (v2.amount < v) then
						return false;
					end;
				end;
			end;
		end;
	end;

	if (cost) then
		if (!Clockwork.player:CanAfford(player, cost)) then
			return false;
		else
			player:GiveCash(-cost);
			return true;
		end;
	end;

	return true;
end;

Clockwork.datastream:Hook("Craft", function(player, data)
	player:Craft(data);
end);