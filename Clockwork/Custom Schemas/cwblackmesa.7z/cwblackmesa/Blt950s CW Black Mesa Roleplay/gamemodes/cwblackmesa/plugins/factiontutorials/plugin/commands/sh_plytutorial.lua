--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("PlyTutorial");
COMMAND.tip = "Trigger a tutorial on player.";
COMMAND.text = "<string Name> <string ID>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] );
	local tutorialID = tonumber(arguments[2]);
	
	local link

	if tutorialID then
		if tutorialID == 1 then
			link = "http://www.youtube.com/embed/mTko_5swv4o?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"
		elseif tutorialID == 2 then
			link = "http://www.youtube.com/embed/XQHiEiZrw9U?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"
		elseif tutorialID == 3 then
			link = "http://www.youtube.com/embed/Xe9sIqkbnw4?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"
		elseif tutorialID == 4 then
			link = "http://www.youtube.com/embed/GSieRi0AgZg?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1"
		elseif tutorialID == 5 then
			target:ConCommand("HB_Donated")
		end

		Clockwork.player:Notify(player, "You've tutorial ID "..tostring(tutorialID).." at "..target:Name());

		if tutorialID < 5 then
			net.Start("cw_runTutorial")
				net.WriteString(link)
				net.WriteBit(false)
			net.Send(target)
		end
	else
		Clockwork.player:Notify(player, "List of available tutorials:");
		Clockwork.player:Notify(player, "1 - Scientist.");
		Clockwork.player:Notify(player, "2 - Security.");
		Clockwork.player:Notify(player, "3 - Visitor.");
		Clockwork.player:Notify(player, "4 - Director.");
		Clockwork.player:Notify(player, "5 - Thank you for donating.");
	end
end;

COMMAND:Register();