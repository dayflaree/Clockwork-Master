local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:ChatBoxAdjustInfo(info)
	if (info.class == "ic" or info.class == "yell" or info.class == "radio" or info.class == "whisper" or info.class == "request") then
		// Add capital
		local editCapital = string.sub(info.text, 1, 1);
		info.text = (string.upper(editCapital)..string.sub(info.text, 2, string.len(info.text)));
		
		// Add period
		local endText = string.sub(info.text, -1);

		if ( (endText != ".") and (endText != "!") and (endText != "?" ) ) then
			info.text = (info.text..".");
		end;
	end
end;