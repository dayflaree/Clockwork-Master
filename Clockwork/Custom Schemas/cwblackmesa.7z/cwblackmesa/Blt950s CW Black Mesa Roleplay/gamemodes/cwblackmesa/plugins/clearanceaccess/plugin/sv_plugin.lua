--[[
    � 2013 CloudSixteen.com do not share, re-distribute or modify
    without permission of its author (kurozael@gmail.com).
--]]

local PLUGIN = PLUGIN;
local scanners = {}

-- Called when Clockwork has loaded all of the entities.
function PLUGIN:ClockworkInitPostEntity() 
    self:LoadClearanceDoors(); 
end;

function PLUGIN:LoadClearanceDoors()
	ConfigScanner("scannerbutton_corridor", "2");
	ConfigScanner("scannerbutton_officelock", "2");
	ConfigScanner("button_elevatorcorridor", "2");
	ConfigScanner("scannerbutton_levelthree", "3");
	ConfigScanner("scannerbutton_controlroom", "4");
	ConfigScanner("scannerbutton_controlroomexit", "4");
	ConfigScanner("scannerbutton_airlock", "X");
	ConfigScanner("scannerbutton_airlock2", "X");
	ConfigScanner("scannerbutton_security", "S");
	ConfigScanner("scannerbutton_securitypost", "S");
	ConfigScanner("scannerbutton_jail", "S");
	ConfigScanner("scannerbutton_lab04", "3B");
	ConfigScanner("scannerbutton_laba_locker", "3");
end

function ConfigScanner(name, clearance)
	for k,v in pairs(ents.FindByName(name)) do
		v:SetNetworkedString("clearance", clearance);
		v:SetKeyValue("spawnflags","1")
		//v:Fire("Lock", "", 0)
		table.insert( scanners, name )
	end
end

function PLUGIN:KeyRelease(player, key)
	local ent = player:GetEyeTrace().Entity
	if (key == IN_USE and ent:GetClass() == "func_button") then
		if (!player.nextUse or CurTime() >= player.nextUse)  then
			player.nextUse = CurTime() + 4

			local entName = player:GetEyeTrace().Entity:GetName()

			if(table.HasValue( scanners, entName)) then
				if(player:GetPos():Distance(ent:GetPos()) < 70) then
					//ErrorNoHalt("RUN CHECK\n")
					RunCheck(player, ent);
				end
			end
		end
	end
end

function RunCheck(activator, ent)
	ent:EmitSound("npc/roller/mine/combine_mine_deploy1.wav", 70, 50)
	timer.Simple(1.5, function()
		if Schema:HasClearance(activator, ent:GetNetworkedString("clearance")) then
			ent:EmitSound("buttons/button3.wav", 70, 100);
			//ent:Fire("Unlock", "", 0)
			ent:Fire("Press", "", 1.5)
			//ErrorNoHalt("PRESS SCANNER\n")
			//ent:Fire("Lock", "", 1.6)
		else
			ent:EmitSound("buttons/button8.wav", 70, 100);
		end		
	end)
end