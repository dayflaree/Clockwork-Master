local RECIPE = Clockwork.recipe:New("Pasta");
	RECIPE:Require("egg", 1, 0);
	RECIPE:Require("flour", 1, 0);
	RECIPE:Output("pasta", 2);
	RECIPE:Factions("Chef");
	RECIPE.model = "models/props_junk/MetalBucket01a.mdl";
	RECIPE.description = "Create a pasta for future use.";
	RECIPE.category = "Food"
RECIPE:Register();