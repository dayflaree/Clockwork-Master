--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;

function PLUGIN:ClockworkInitPostEntity()
	self:ReplaceBins();
end;

-- A function to load the ration machines.
function PLUGIN:ReplaceBins()
	for k, v in pairs(ents.GetAll()) do
		if v:GetModel() == "models/props_canteen/canteenbin.mdl" then
			local angles = v:GetAngles()
			local position = v:GetPos()
			v:Remove()
		
			local entity = ents.Create("cw_trashbin_tall");
			entity:SetPos(position);
			entity:Spawn();
			local l1 = entity:GetPhysicsObject()
			l1:EnableMotion(false)
			if ( IsValid(entity) ) then
				entity:SetAngles(angles);
				entity:SetMoveType(MOVETYPE_NONE);
			end;
		elseif v:GetModel() == "models/props_office/metalbin01.mdl" then
			local angles2 = v:GetAngles()
			local position2 = v:GetPos()
			v:Remove()
		
			local entity2 = ents.Create("cw_trashbin");
			entity2:SetPos(position2);
			entity2:Spawn();
			local l2 = entity2:GetPhysicsObject()
			l2:EnableMotion(false)
			if ( IsValid(entity2) ) then
				entity2:SetAngles(angles2);
				entity2:SetMoveType(MOVETYPE_NONE);
			end;
		end;
	end;
end;