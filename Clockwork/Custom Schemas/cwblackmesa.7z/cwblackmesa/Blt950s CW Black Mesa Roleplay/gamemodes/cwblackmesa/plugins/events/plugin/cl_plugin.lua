--[[
	� 2013 HeartBit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;


local pos,material = Vector(471.718445, 1116.958618, 524.378113), Material("sprites/glow04_noz")

hook.Add( "RenderScreenspaceEffects", "paintsprites", function()

	local color = Color(0,255,0,255) 
	if Clockwork.kernel:GetSharedVar("comFailed") then
		color = Color(255,0,0,255) 
	else
		color = Color(0,255,0,255) 
	end

	cam.Start3D(EyePos(),EyeAngles())
		render.SetMaterial( material )
		render.DrawSprite( pos, 16, 16, color)
	cam.End3D()
end )