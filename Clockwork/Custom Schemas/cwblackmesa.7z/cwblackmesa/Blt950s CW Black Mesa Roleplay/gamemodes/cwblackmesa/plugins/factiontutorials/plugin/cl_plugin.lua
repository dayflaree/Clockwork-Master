--[[
	� 2013 HeartBit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

net.Receive("cw_runTutorial", function()
	local link = net.ReadString()
	local intro = tobool(net.ReadBit())
	createTutorial(intro, link)
end)

function createTutorial(intro, url)
	
	if IsValid( html ) then html:Remove() end
	
	local frame = vgui.Create( "DFrame" )
	if intro then
		frame:SetTitle( "Introduction Tutorial" )
	else
		frame:SetTitle( "Faction Tutorial" )
	end
	frame:SetSize( 1334, 798 )
	frame:SetPos( ScrW()-(ScrW()/2)-(1334/2), ScrH()-(ScrH()/2)-(798/2) )
	frame:MakePopup()
	frame:ShowCloseButton( false )

	local close = vgui.Create( "DButton", frame )
	close:SetPos(1280, 3)
	close:SetSize(50, 20)
	close:SetText("Close")
	close:SetDisabled(true)
	close.DoClick = function( button )
		if intro then
			frame:Close()
			createTutorial(false, url)
		else
			frame:Close()
		end
	end
	timer.Simple(10, function() close:SetDisabled(false) end)
	
	local html = vgui.Create( "HTML", frame )
	html:SetSize( 1324, 768 )
	html:SetPos( 5, 26 )
	if intro then
		html:OpenURL( "http://www.youtube.com/embed/D9cLFlSztCo?rel=0&autoplay=1&vq=hd1080&autohide=1&controls=0&cc_load_policy=1" )
	else
		html:OpenURL( url )
	end
	
	html = frame
	
end