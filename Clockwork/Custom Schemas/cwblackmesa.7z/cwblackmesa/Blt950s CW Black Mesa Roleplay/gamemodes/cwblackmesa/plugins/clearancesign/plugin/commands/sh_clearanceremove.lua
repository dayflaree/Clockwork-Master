--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("ClearanceRemove");
COMMAND.tip = "Remove clearance sign from a surface.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local position = player:GetEyeTraceNoCursor().HitPos;
	local iRemoved = 0;
	
	for k, v in pairs(cwClearanceSigns.storedList) do
		if (v.position:Distance(position) <= 256) then
			Clockwork.datastream:Start(nil, "ClearanceSignsRemove", v.position);
				cwClearanceSigns.storedList[k] = nil;
			iRemoved = iRemoved + 1;
		end;
	end;
	
	if (iRemoved > 0) then
		if (iRemoved == 1) then
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." clearance sign.");
		else
			Clockwork.player:Notify(player, "You have removed "..iRemoved.." clearance signs.");
		end;
	else
		Clockwork.player:Notify(player, "There were no clearance signs near this position.");
	end;
	
	cwClearanceSigns:SaveClearanceSigns();
end;

COMMAND:Register();