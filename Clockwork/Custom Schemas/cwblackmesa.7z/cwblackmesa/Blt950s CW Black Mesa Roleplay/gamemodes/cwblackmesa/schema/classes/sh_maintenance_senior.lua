--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Senior Maintenance");
	CLASS.color = Color(255, 166, 64, 255);
	CLASS.factions = {FACTION_MAINTENANCE};
	CLASS.wages = 14;
	CLASS.wagesName = "Salary";
	CLASS.description = "A more experienced Maintenance.";
	CLASS.defaultPhysDesc = "Wearing casual clothes.";
CLASS_SENIOR_MAINTENANCE = CLASS:Register();