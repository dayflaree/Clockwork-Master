--[[
	� 2013 HeartBit Roleplay do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local CLASS = Clockwork.class:New("Governmental Official");
	CLASS.color = Color(255, 200, 100, 255);
	CLASS.wages = 40;
	CLASS.factions = {FACTION_GOVERNMENT};
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A person from the US Government.";
	CLASS.defaultPhysDesc = "Wearing a clean brown suit.";
CLASS_GOVERNMENT = CLASS:Register();