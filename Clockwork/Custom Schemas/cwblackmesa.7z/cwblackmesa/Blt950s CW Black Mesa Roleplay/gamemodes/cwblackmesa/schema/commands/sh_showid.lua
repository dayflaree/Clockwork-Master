--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("ShowID");
COMMAND.tip = "Show your Citizen ID card to currenty looking at player.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;


-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local lookingPly = player:GetEyeTrace().Entity
	local gender = player:GetGender()
	
	if lookingPly:IsPlayer() then
		Clockwork.chatBox:SendColored(lookingPly, Color(200, 100, 100), "[ID CARD] ", Color(255, 93, 0), player:Name() .." | Levels: "..player:GetSharedVar("Clearances"))
		Clockwork.player:SetRecognises(lookingPly, player, RECOGNISE_SAVE);
		if gender == GENDER_FEMALE then
			Clockwork.chatBox:AddInTargetRadius(player, "me", string.gsub("shows her ID.", "^.", string.lower), player:GetPos(), Clockwork.config:Get("talk_radius"):Get());
		else
			Clockwork.chatBox:AddInTargetRadius(player, "me", string.gsub("shows his ID.", "^.", string.lower), player:GetPos(), Clockwork.config:Get("talk_radius"):Get());
		end
	else
		Clockwork.player:Notify(player, "You must look at a player!");
	end
	
end;


COMMAND:Register();