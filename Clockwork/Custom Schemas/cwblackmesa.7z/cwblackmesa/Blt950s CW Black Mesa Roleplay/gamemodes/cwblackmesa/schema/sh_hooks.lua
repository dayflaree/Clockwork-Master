--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

-- Called when the Clockwork shared variables are added.
function Schema:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:String("Clearances");
	playerVars:Number("clothes", true);
	playerVars:Number("cuffed");
	playerVars:Bool("inXen");
	playerVars:Bool("wearingHEV");
end;

-- Called when a player's storage should close.
function Schema:PlayerStorageShouldClose(player, storage)
	local entity = player:GetStorageEntity();
	
	if (player.searching and entity:IsPlayer() and entity:GetSharedVar("cuffed") == 0) then
		return true;
	end;
end;

-- Called when a player attempts to spray their tag.
function Schema:PlayerSpray(player)
	return true -- we don't have sprays
end;