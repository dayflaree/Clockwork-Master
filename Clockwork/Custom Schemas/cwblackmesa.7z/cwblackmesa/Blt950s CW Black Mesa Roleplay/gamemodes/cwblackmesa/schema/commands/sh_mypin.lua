--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("MyPin");
COMMAND.tip = "Get your pin. Used for donations.";
COMMAND.text = "<string Item>";
COMMAND.flags = CMD_DEFAULT;


-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local pin = util.CRC(player:SteamID())%661+1000%786+1000
	player:SendLua("chat.AddText(Color(255,50,0),[[=PIN CODE= ]],Color(255,0,50),[["..pin.."]])");
end;


COMMAND:Register();