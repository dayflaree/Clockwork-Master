--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("Alarm");
COMMAND.tip = "Toggle alarm on or off.";
COMMAND.text = "<none>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER);

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if Schema:HasClearance(player, "3") then
		for k,v in pairs(ents.FindByName("alarm_toggle")) do
			v:Fire("Trigger", "", 0);
		end
		Clockwork.kernel:PrintLog(LOGTYPE_MAJOR, player:Name().." ("..player:SteamID()..") has toggeled alarm.");
	else
		Clockwork.player:Notify(player, "Clearance Level 3 is required to use this command!");
	end;
end;

COMMAND:Register();