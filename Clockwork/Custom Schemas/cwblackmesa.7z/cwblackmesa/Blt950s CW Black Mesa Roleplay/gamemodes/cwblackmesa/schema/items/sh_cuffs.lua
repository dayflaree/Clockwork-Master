--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Cuffs";
ITEM.cost = 100;
ITEM.model = "models/katharsmodels/handcuffs/handcuffs-1.mdl";
ITEM.weight = 0.2;
ITEM.access = "v";
ITEM.useText = "Cuff";
ITEM.factions = {FACTION_SECURITY};
ITEM.business = true;
ITEM.description = "Metal cuffs where you can tie peoples hands with.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (player.isCuffing) then
		Clockwork.player:Notify(player, "You are already cuffing a character!");
		
		return false;
	else
		local trace = player:GetEyeTraceNoCursor();
		local target = Clockwork.entity:GetPlayer(trace.Entity);
		local cuffTime = Schema:GetDexterityTime(player);
		
		if (target) then
			if (target:GetSharedVar("cuffed") == 0) then
				if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
					if (target:GetAimVector():DotProduct( player:GetAimVector() ) > 0 or target:IsRagdolled()) then
						Clockwork.player:SetAction(player, "cuff", cuffTime);
						
						Clockwork.player:EntityConditionTimer(player, target, trace.Entity, cuffTime, 192, function()
							if (player:Alive() and !player:IsRagdolled() and target:GetSharedVar("cuffed") == 0
							and target:GetAimVector():DotProduct( player:GetAimVector() ) > 0) then
								return true;
							end;
						end, function(success)
							if (success) then
								player.isCuffing = nil;
								
								Schema:CuffPlayer( target, true, nil);
								
								player:TakeItem(self);
								player:ProgressAttribute(ATB_DEXTERITY, 15, true);
							else
								player.isCuffing = nil;
							end;
							
							Clockwork.player:SetAction(player, "cuff", false);
						end);
					else
						Clockwork.player:Notify(player, "You cannot cuff characters that are facing you!");
						
						return false;
					end;
					
					player.isCuffing = true;
					
					Clockwork.player:SetMenuOpen(player, false);
					
					return false;
				else
					Clockwork.player:Notify(player, "This character is too far away!");
					
					return false;
				end;
			else
				Clockwork.player:Notify(player, "This character is already cuffed!");
				
				return false;
			end;
		else
			Clockwork.player:Notify(player, "That is not a valid character!");
			
			return false;
		end;
	end;
	return false;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player.isCuffing) then
		Clockwork.player:Notify(player, "You are currently cuffing a character!");
		
		return false;
	end;
end;

ITEM:Register();