--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Radio");
//local COMMAND = Clockwork.command:FindByID("Radio")
COMMAND.tip = "Send a radio message out to other characters.";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if Clockwork.kernel:GetSharedVar("comFailed") then
		Clockwork.chatBox:SendColored(player, Color(100, 255, 100), "[Radio] *Shhhhhhhhhhh* (Seems like connection is lost)")
		return;
	end
	if player:GetSharedVar("inXen") then
		Clockwork.chatBox:SendColored(player, Color(100, 255, 100), "[Radio] *Shhhhhhhhhhh* (Seems like no connection can be made)")
		return;
	end
	Schema:SayRadio(player, table.concat(arguments, " "), true);
end;

COMMAND:Register();