--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_protected_base");
	ITEM.name = "Fire Extinguisher";
	ITEM.cost = 50;
	ITEM.model = "models/weapons/w_fire_extinguisher.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "weapon_extinguisher";
	ITEM.business = true;
	ITEM.description = "A red rounded tall metal container with foam to extinguish fires.";
	ITEM.isAttachment = false;
	ITEM.hasFlashlight = false;
ITEM:Register();