--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_protected_base");
	ITEM.name = "Crowbar";
	ITEM.cost = 50;
	ITEM.model = "models/weapons/w_crowbar.mdl";
	ITEM.weight = 2.5;
	ITEM.access = "v";
	ITEM.uniqueID = "cw_crowbar";
	ITEM.business = true;
	ITEM.description = "A red crowbar, it has a convenient handle.";
	ITEM.isAttachment = false;
	ITEM.hasFlashlight = false;
ITEM:Register();