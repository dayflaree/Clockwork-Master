--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");

Clockwork.option:SetKey("default_date", {month = 1, year = 1998, day = 1});
Clockwork.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});
Clockwork.option:SetKey("format_singular_cash", "%a");
Clockwork.option:SetKey("model_shipment", "models/items/item_item_crate.mdl");
Clockwork.option:SetKey("intro_image", "blackmesarp/bmrp_logo");
Clockwork.option:SetKey("schema_logo", "blackmesarp/bmrp_logo");
Clockwork.option:SetKey("format_cash", "%a %n");
Clockwork.option:SetKey("menu_music", "heartbit/menumusic.mp3");
Clockwork.option:SetKey("name_cash", "Dollars");
Clockwork.option:SetKey("model_cash", "models/props_lab/box01a.mdl");
Clockwork.option:SetKey("gradient", "blackmesarp/bg_gradient");

Clockwork.flag:Add("v", "Trusted Player", "Access to trusted only sweps and similar.");
Clockwork.flag:Add("V", "Weapons Purchases", "Access for purchasing weapons in business menu.");

Clockwork.config:ShareKey("intro_text_small");
Clockwork.config:ShareKey("intro_text_big");

Clockwork.quiz:SetEnabled(true);
Clockwork.quiz:AddQuestion("Do you understand that roleplaying is slow paced and relaxed?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("Do you understand how to type properly, using capital letters and full-stops?", 1, "Yes, I do.", "yes i do");
Clockwork.quiz:AddQuestion("You do not need weapons to roleplay, do you understand?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("You do not need items to roleplay, do you understand?", 1, "Yes.", "No.");
Clockwork.quiz:AddQuestion("What do you think serious roleplaying is about?", 2, "Collecting items and upgrades.", "Developing your character.");
Clockwork.quiz:AddQuestion("What is meta-gaming?", 1, "Using information gained from OOC means of communication in IC roleplay.", "Using metal devices in roleplay.");
Clockwork.quiz:AddQuestion("What is power-gaming?", 2, "Increasing attributes at a rapid speed.", "Forcing an action upon someone via the /me command.");
Clockwork.quiz:AddQuestion("What is IC?", 2, "In-Context", "In-Character");
Clockwork.quiz:AddQuestion("What is OOC?", 1, "Out-of-Character", "Out-of-Context");
Clockwork.quiz:AddQuestion("What universe is this gamemode set in?", 2, "Real Life", "Black Mesa");
Clockwork.quiz:AddQuestion("Will you promise to read the guides at www.heartbit.me?", 1, "Yes.", "No, just let me in and let me roleplay.");
Clockwork.quiz:AddQuestion("Which is the correct physical description?", 2, "A scientist who is well educated, and got PhD in his field.", "1,7m Tall | Short Beard | Brown Eyes | Brown Hair");