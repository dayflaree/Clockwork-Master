--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Director of Science");
	CLASS.color = Color(255,200,50);
	CLASS.factions = {FACTION_SCIENTIST};
	CLASS.isDefault = false;
	CLASS.wages = 45;
	CLASS.wagesName = "Salary";
	CLASS.description = "A scientist with a labcoat and a ID badge.";
	CLASS.defaultPhysDesc = "Wearing a labcoat and a ID badge.";
CLASS_SCIENTIST_DIRECTOR = CLASS:Register();