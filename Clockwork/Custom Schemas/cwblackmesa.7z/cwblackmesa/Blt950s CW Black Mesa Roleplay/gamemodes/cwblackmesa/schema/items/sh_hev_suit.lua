--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "HEV Suit";
ITEM.cost = 250;
ITEM.batch = 1;
ITEM.weight = 5;
ITEM.access = "V";
ITEM.business = true;
ITEM.protection = 0.05;
ITEM.description = "An impenetrable uniform with insulated coverings and mask.";

-- Called when a replacement is needed for a player.
function ITEM:GetReplacement(player)
	if ( player:GetGender() == GENDER_FEMALE ) then
		return "models/sgg/hev_helmet.mdl";
	else
		return "models/sgg/hev_helmet.mdl";
	end;
end;

-- Called to get whether a player has the item equipped.
function ITEM:HasPlayerEquipped(player, arguments)
	return player:GetSharedVar("wearingHEV");
end;

-- Called when a player has unequipped the item.
function ITEM:OnPlayerUnequipped(player, arguments)
	player:SetSharedVar("wearingHEV", false);
    player:RemoveClothes();
	player:RebuildInventory();
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position)
	if (player:GetSharedVar("wearingHEV") and player:HasItem(self.uniqueID) == 1) then
		Clockwork.player:Notify(player, "You cannot drop this while you are wearing it!");
		
		return false;
	end;
end;

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if ( player:Alive() and !player:IsRagdolled() ) then
		player:SetSharedVar("wearingHEV", true);
		player:SetClothesData(self);
		player:RebuildInventory();

		if (itemEntity) then
			return true;
		end;
	else
		Clockwork.player:Notify(player, "You don't have permission to do this right now!");
	end;
	
	return false;
end;

ITEM:Register();