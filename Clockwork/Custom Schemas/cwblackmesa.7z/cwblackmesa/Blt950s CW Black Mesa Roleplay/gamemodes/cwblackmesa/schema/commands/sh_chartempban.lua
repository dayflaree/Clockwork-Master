--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharTempBan");
COMMAND.tip = "Temporary charban a character.";
COMMAND.text = "<string Name> <number Minutes>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	local duration = tonumber(arguments[2]);
	
	if (target) then
		target:SetData("chartempban", tostring(target:GetSharedVar("key")..":"..math.Round(os.time() + duration*60)))
		Clockwork.player:SaveData(target);
		
		if duration < 60 then
			Clockwork.player:NotifyAll(player:Name().." has temporary charbanned "..target:Name().." for "..duration.." minutes.");
		else
			Clockwork.player:NotifyAll(player:Name().." has temporary charbanned "..target:Name().." for "..tostring(math.Round(duration / 60)).." hour(s).");
		end
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();