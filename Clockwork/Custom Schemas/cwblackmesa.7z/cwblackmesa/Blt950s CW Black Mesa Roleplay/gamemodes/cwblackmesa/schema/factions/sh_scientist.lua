--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Scientist");

FACTION.useFullName = false;
FACTION.material = "blackmesarp/factions/scientist";
FACTION.models = {
	female = {
		"models/humans/scientist_female.mdl"
	},
	male = {
		"models/blackmesasciences/eli.mdl",
		"models/blackmesasciences/kleiner.mdl",
		"models/blackmesasciences/male_01.mdl",
		"models/blackmesasciences/male_02.mdl",
		"models/blackmesasciences/male_03.mdl",
		"models/blackmesasciences/male_04.mdl",
		"models/blackmesasciences/male_05.mdl",
		"models/blackmesasciences/male_06.mdl",
		"models/blackmesasciences/male_07.mdl",
		"models/blackmesasciences/male_08.mdl",
		"models/blackmesasciences/male_09.mdl"
	};
};


FACTION_SCIENTIST = FACTION:Register();