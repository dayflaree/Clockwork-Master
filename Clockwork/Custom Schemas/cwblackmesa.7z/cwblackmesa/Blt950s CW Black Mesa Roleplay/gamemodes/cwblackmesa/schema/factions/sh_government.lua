--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Governmental Official");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "";
FACTION.models = {
	female = {
		"models/humans/suitfem/female_02.mdl"
	},
	male = {
		"models/taggart/gallahan.mdl"
	};
};

FACTION_GOVERNMENT = FACTION:Register();