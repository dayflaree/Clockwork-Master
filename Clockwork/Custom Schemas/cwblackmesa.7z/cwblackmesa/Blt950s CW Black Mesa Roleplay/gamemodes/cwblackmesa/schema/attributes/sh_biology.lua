--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Biology";
	ATTRIBUTE.maximum = 100;
	ATTRIBUTE.uniqueID = "bio";
	ATTRIBUTE.description = "Your knowledge level in the Biology field, accessing you more crafting options.";
	ATTRIBUTE.isOnCharScreen = false;
ATB_BIOLOGY = Clockwork.attribute:Register(ATTRIBUTE);