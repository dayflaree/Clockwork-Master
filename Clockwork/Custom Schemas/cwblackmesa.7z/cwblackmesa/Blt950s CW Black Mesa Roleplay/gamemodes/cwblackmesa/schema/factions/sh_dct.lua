--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Disturbance Control Team");

FACTION.whitelist = true;
FACTION.useFullName = false;
FACTION.material = "blackmesarp/factions/dct";
FACTION.models = {
	female = {
		"models/ddok1994/1980_hazmat.mdl"
	};
	male = {
		"models/ddok1994/1980_hazmat.mdl"
	};
};

-- Called when a player's model should be assigned for the faction.
function FACTION:GetModel(player, character)
	if (character.gender == GENDER_MALE) then
		return self.models.male[1];
	else
		return self.models.female[1];
	end;
end;

FACTION_DCT = FACTION:Register();