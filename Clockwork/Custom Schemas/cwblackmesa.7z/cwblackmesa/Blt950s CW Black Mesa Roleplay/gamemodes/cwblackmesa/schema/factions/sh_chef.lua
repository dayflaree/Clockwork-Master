--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Chef");

FACTION.useFullName = false;
FACTION.whitelist = false;
FACTION.material = "";
FACTION.models = {
	female = {
		"models/mossman.mdl"
	},
	male = {
		"models/Characters/Hostage_01.mdl",
		"models/Characters/hostage_04.mdl"
	};
};

FACTION_CHEF = FACTION:Register();