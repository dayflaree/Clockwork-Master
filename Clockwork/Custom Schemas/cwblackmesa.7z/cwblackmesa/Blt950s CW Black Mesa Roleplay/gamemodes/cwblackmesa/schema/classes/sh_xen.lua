--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Xen Creature");
	CLASS.color = Color(0, 255, 57, 255);
	CLASS.factions = {FACTION_XEN};
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A weird looking xen creature.";
	CLASS.defaultPhysDesc = "Seems like an odd creature for Xen.";
CLASS_XEN = CLASS:Register();