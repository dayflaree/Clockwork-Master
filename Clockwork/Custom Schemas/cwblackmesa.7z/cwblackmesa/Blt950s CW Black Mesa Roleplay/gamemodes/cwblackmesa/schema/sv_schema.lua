--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]
 
resource.AddWorkshop( "108761337" ) // black mesa source models
resource.AddWorkshop( "110607312" ) // Black Mesa Source Lab Props
resource.AddWorkshop( "110472963" ) // Black Mesa Office Models
resource.AddWorkshop( "105042805" ) // Combine Administrators v2
resource.AddWorkshop( "126181015" ) // HEV Helmet (suit)
resource.AddWorkshop( "284495706" ) // HB Content Pack
resource.AddWorkshop( "172374701" ) // Hazmat Conscripts (DCT)
resource.AddWorkshop( "210202335" ) // Sector C Map
resource.AddWorkshop( "104607228" ) // Fire Extinguisher
resource.AddWorkshop( "163806212" ) // Adv. Dupe
resource.AddWorkshop( "104815552" ) // SmartSnap
resource.AddWorkshop( "104479831" ) // StackerTool
resource.AddWorkshop( "110138917" ) // Suits and Robbers
resource.AddWorkshop( "163221745" ) // Food mod


Clockwork.config:Add("intro_text_small", "Lambda Complex, 1998", true);
Clockwork.config:Add("intro_text_big", "BLACK MESA RESEARCH FACILITY", true);

-- A function to add a security hint.
function Clockwork.hint:AddSecurityHint(name, text)
	Clockwork.hint:Add(name, text, function(player)
		if (player) then
			return !player:GetFaction() == FACTION_SECURITY;
		end;
	end);
end;

-- A function to add a scientist hint.
function Clockwork.hint:AddScientistHint(name, text)
	Clockwork.hint:Add(name, text, function(player)
		if (player) then
			return !player:GetFaction() == FACTION_SCIENTIST;
		end;
	end);
end;

Clockwork.hint:AddSecurityHint("F3 Hotkey", "Press F3 while looking at a character to use cuffs.");
Clockwork.hint:AddSecurityHint("F4 Hotkey", "Press F4 while looking at a cuffed character to search them.");

Clockwork.hint:AddScientistHint("Research", "Not sure what to research on? Contact a higher ranked scientist.");
Clockwork.hint:AddScientistHint("PassiveRP", "Lots of the time as a scientist is based on passive roleplay.");

Clockwork.hint:Add("Admins", "The admins are here to help you, please respect them.");
Clockwork.hint:Add("Action", "Action. Stop looking for it, this is Black Mesa. Not ArmyRP.");
Clockwork.hint:Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
Clockwork.hint:Add("Running", "Got somewhere to go? Fancy a run? Well don't, it's unserious.");

Clockwork.hint:Add("Clearances", "Black Mesa is split into clearance levels, rank up to achieve new levels.");
Clockwork.hint:Add("Metagaming", "Metagaming is when you use OOC information in-character.");
Clockwork.hint:Add("Passive RP", "If you're bored and there's no action, try some passive roleplay.");
Clockwork.hint:Add("Development", "Develop your character, give them a story to tell.");
Clockwork.hint:Add("Powergaming", "Powergaming is when you force your actions on others.");

-- A function to cuff or uncuff a player.
function Schema:CuffPlayer(player, isCuffed, reset)
	if (isCuffed) then
		player:SetSharedVar("cuffed", 1);
	else
		player:SetSharedVar("cuffed", 0);
	end;
	
	if (isCuffed) then
		Clockwork.player:DropWeapons(player);
		Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name().." has been cuffed.");
		
		player:Flashlight(false);
		player:StripWeapons();
	elseif (!reset) then
		if (player:Alive() and !player:IsRagdolled()) then 
			Clockwork.player:LightSpawn(player, true, true);
		end;
		
		Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name().." has been uncuffed.");
	end;
end;

-- A function to get a player's dexterity time.
function Schema:GetDexterityTime(player)
	return 7 - Clockwork.attributes:Fraction(player, ATB_DEXTERITY, 5, 5);
end;

-- A function to check if a player is blacklisted for a faction.
function Schema:IsBlacklisted(player, faction)
	return table.HasValue(player:GetData("Blacklisted"), faction);
end;

-- A function to set whether a player is blacklisted for a faction.
function Schema:SetBlacklisted(player, faction, isBlacklisted)
	local blacklisted = player:GetData("Blacklisted");
	
	if (isBlacklisted) then
		if (!self:IsBlacklisted(player, faction)) then
			blacklisted[table.Count(blacklisted) + 1] = faction;
		end;
	else
		for k, v in pairs(blacklisted) do
			if (v == faction) then
				blacklisted[k] = nil;
			end;
		end;
	end;
	
	Clockwork.datastream:Start(
		player, "SetBlacklisted", {faction, isBlacklisted}
	);
end;

-- A function to set whether a character is tempbanned.
function Schema:isTempBanned(player, key)
	if(player:GetData("chartempban")) then

		local ban = string.Explode(":", player:GetData("chartempban"))
		if tonumber(ban[1]) == key then
			if tonumber(ban[2]) > os.time() then
				return true;
			else
				return false;
			end
		else
			return false;
		end

	else
		return false;
	end
end

-- A function to take clearances from a player.
function Schema:GetClearances(player)
	return player:GetCharacterData("Clearances");
end;

-- A function to give clearances to a player.
function Schema:GiveClearances(player, clearances)
	for i = 1, #clearances do
		local clearance = string.sub(clearances, i, i);
		
		if (!string.find(Schema:GetClearances(player), clearance)) then
			player:SetCharacterData("Clearances", Schema:GetClearances(player)..clearance);
			
			Clockwork.plugin:Call("PlayerClearancesGiven", player, clearance);
		end;
	end;
end;

-- A function to take clearances from a player.
function Schema:TakeClearances(player, clearances)
	for i = 1, #clearances do
		local clearance = string.sub(clearances, i, i);
		if (string.find(Schema:GetClearances(player), clearance)) then
			local newLevels = string.gsub(Schema:GetClearances(player), clearance, "")
			player:SetCharacterData("Clearances", newLevels);
			
			Clockwork.plugin:Call("PlayerClearancesTaken", player, clearance);
		end;
	end;
end;

-- A function to check if a player has clearances.
function Schema:HasClearance(player, clearances)
	clearances = tostring(clearances)
	local playerClearances = Schema:GetClearances(player);
	local foundOne = false
	for i = 1, #clearances do
		local clearance = string.sub(clearances, i, i);
		if string.find(playerClearances, clearance) then
			foundOne = true
		end
	end
	if foundOne then
		return true;
	else
		return false;
	end
end;

function Schema:PlayerIsSecurity(player)
	if player:GetFaction() == FACTION_SECURITY then
		return true
	else
		return false
	end
end

-- A function to say a message as a request.
function Schema:SayRequest(player, text)
	local isXen = (player:GetFaction() == FACTION_XEN);
	local listeners = { request = {}, eavesdrop = {} };
	
	for k, v in ipairs( _player.GetAll() ) do
		if (v:HasInitialized()) then
			if (v:GetFaction() == FACTION_XEN and isXen and player != v) then
				if (v:GetShootPos():Distance( player:GetShootPos() ) <= Clockwork.config:Get("talk_radius"):Get()) then
					listeners.eavesdrop[v] = v;
				end;
			else
				listeners.request[v] = v;
			end;
		end;
	end;

	local info = Clockwork.chatBox:Add(listeners.request, player, "request", text);
	
	if (info and IsValid(info.speaker)) then
		Clockwork.chatBox:Add(listeners.eavesdrop, info.speaker, "request_eavesdrop", info.text);
	end;
end;

-- A function to make a player wear clothes.
function Schema:PlayerWearClothes(player, itemTable, noMessage)
	local clothes = player:GetCharacterData("clothes");
	
	if (itemTable) then
		local model = Clockwork.class:GetAppropriateModel(player:Team(), player, true);
		
		if (!model) then
			itemTable:OnChangeClothes(player, true);
			
			player:SetCharacterData("clothes", itemTable.index);
			player:SetSharedVar("clothes", itemTable.index);
		end;
	else
		itemTable = Clockwork.item:FindByID(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
			player:SetSharedVar("clothes", 0);
		end;
	end;
end;

-- A function to get a player's heal amount.
function Schema:GetHealAmount(player, scale)
	local healAmount = (15) * (scale or 1);
	
	return healAmount;
end;