--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Security Lieutenant");
	CLASS.color = Color(50, 100, 150, 255);
	CLASS.wages = 20;
	CLASS.factions = {FACTION_SECURITY};
	CLASS.wagesName = "Salary";
	CLASS.description = "A newly trained security unit.";
	CLASS.defaultPhysDesc = "Wearing a security uniform and a radio.";
CLASS_SECURITY_LIEUTENANT = CLASS:Register();