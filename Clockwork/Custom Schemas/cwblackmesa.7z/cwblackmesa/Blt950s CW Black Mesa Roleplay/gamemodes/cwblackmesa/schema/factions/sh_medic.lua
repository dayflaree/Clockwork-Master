--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Medic");

FACTION.useFullName = false;
FACTION.material = "blackmesarp/factions/medic";
FACTION.models = {
	female = {
		"models/humans/group02/female_02.mdl",
		"models/humans/group02/female_04.mdl",
		"models/humans/group02/female_07.mdl"
	},
	male = {
		"models/humans/group02/male_02.mdl",
		"models/humans/group02/male_04.mdl",
		"models/humans/group02/male_06.mdl",
		"models/humans/group02/male_08.mdl"
	};
};

FACTION_MEDIC = FACTION:Register();