	--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Glock";
	ITEM.cost = 100;
	ITEM.model = "models/weapons/w_pist_glock18.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.classes = {CLASS_SECURITY_CHIEF, CLASS_DCT};
	ITEM.uniqueID = "rcs_glock";
	ITEM.business = true;
	ITEM.description = "A small pistol coated in a dull grey and black.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(180, 180, 90);
	ITEM.attachmentOffsetVector = Vector(-6, 2, -8);
ITEM:Register();