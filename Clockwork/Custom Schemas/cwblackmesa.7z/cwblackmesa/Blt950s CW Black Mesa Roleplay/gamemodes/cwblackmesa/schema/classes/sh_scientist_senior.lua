--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Senior Scientist");
	CLASS.color = Color(255,200,50);
	CLASS.factions = {FACTION_SCIENTIST};
	CLASS.isDefault = false;
	CLASS.wages = 25;
	CLASS.wagesName = "Salary";
	CLASS.description = "A scientist with a labcoat and a ID badge.";
	CLASS.defaultPhysDesc = "Wearing a labcoat and a ID badge.";
CLASS_SCIENTIST_SENIOR = CLASS:Register();