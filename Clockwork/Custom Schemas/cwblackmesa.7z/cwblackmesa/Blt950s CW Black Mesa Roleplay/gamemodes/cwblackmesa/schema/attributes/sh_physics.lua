--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Physics";
	ATTRIBUTE.maximum = 100;
	ATTRIBUTE.uniqueID = "phy";
	ATTRIBUTE.description = "Your knowledge level in the Physics field, accessing you more crafting options.";
	ATTRIBUTE.isOnCharScreen = false;
ATB_PHYSICS = Clockwork.attribute:Register(ATTRIBUTE);