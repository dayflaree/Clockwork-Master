--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

-- Called when the cinematic intro info is needed.
function Schema:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = Clockwork.config:Get("intro_text_big"):Get(),
		text = Clockwork.config:Get("intro_text_small"):Get()
	};
end;

-- Called when the target's status should be drawn.
function Schema:DrawTargetPlayerStatus(target, alpha, x, y)
	local informationColor = Clockwork.option:GetColor("information");
	local thirdPerson = "him";
	local mainStatus;
	local uncuffText;
	local gender = "He";
	local action = Clockwork.player:GetAction(target);
	
	if (target:GetGender() == GENDER_FEMALE) then
		thirdPerson = "her";
		gender = "She";
	end;
	
	if (target:Alive()) then
		if (action == "die") then
			mainStatus = gender.." is in critical condition.";
		end;
		
		if target:Health() < 50 then
			mainStatus = gender.." is clearly injured.";
		end
		
		if (target:GetRagdollState() == RAGDOLL_KNOCKEDOUT) then
			mainStatus = gender.." is clearly unconscious.";
		end;
		
		if (target:GetSharedVar("cuffed") != 0) then
			if (Clockwork.player:GetAction(Clockwork.Client) == "uncuff") then
				mainStatus = gender.. " is being uncuffed.";
			else
				local uncuffText;
				
				if (target:GetShootPos():Distance( Clockwork.Client:GetShootPos() ) <= 192) then
					if (Clockwork.Client:GetSharedVar("cuffed") == 0) then
						mainStatus = "Press :+use: to uncuff "..thirdPerson..".";
						
						uncuffText = true;
					end;
				end;
				
				if (!uuncuffText) then
					mainStatus = gender.." has been cuffed.";
				end;
			end;
		elseif (Clockwork.player:GetAction(Clockwork.Client) == "cuff") then
			mainStatus = gender.." is being cuffed.";
		end;
		
		if (mainStatus) then
			y = Clockwork.kernel:DrawInfo(Clockwork.kernel:ParseData(mainStatus), x, y, informationColor, alpha);
		end;
		
		return y;
	end;
end;

-- Called when a player's scoreboard options are needed.
function Schema:GetPlayerScoreboardOptions(player, options, menu)
	if (Clockwork.command:FindByID("CharSetCustomClass")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharSetCustomClass").access)) then
			options["Custom Class"] = {};
			options["Custom Class"]["Set"] = function()
				Derma_StringRequest(player:Name(), "What would you like to set their custom class to?", player:GetSharedVar("customClass"), function(text)
					Clockwork.kernel:RunCommand("CharSetCustomClass", player:Name(), text);
				end);
			end;
			
			if (player:GetSharedVar("customClass") != "") then
				options["Custom Class"]["Take"] = function()
					Clockwork.kernel:RunCommand( "CharTakeCustomClass", player:Name() );
				end;
			end;
		end;
	end;

	if (Clockwork.command:FindByID("CharTakeClearances")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharTakeClearances").access)) then
			options["Take Clearances"] = function()
				Derma_StringRequest(player:Name(), "Which clearance levels to remove?", player:GetSharedVar("Clearances"), function(text)
					Clockwork.kernel:RunCommand("CharTakeClearances", player:Name(), text);
				end);
			end;
		end;
	end;
	
	if (Clockwork.command:FindByID("CharGiveClearances")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharTakeClearances").access)) then
			options["Give Clearances"] = function()
				Derma_StringRequest(player:Name(), "Which clearance levels to add?", "", function(text)
					Clockwork.kernel:RunCommand("CharGiveClearances", player:Name(), text);
				end);
			end;
		end;
	end;
end;

-- Called to get the screen text info.
function Schema:GetScreenTextInfo()
	local blackFadeAlpha = Clockwork.kernel:GetBlackFadeAlpha();
	if (Clockwork.Client:GetSharedVar("beingCuffed")) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "YOU ARE BEING CUFFED"
		};
	elseif (Clockwork.Client:GetSharedVar("cuffed") != 0) then
		return {
			alpha = 255 - blackFadeAlpha,
			title = "YOU HAVE BEEN CUFFED"
		};
	end;
end;

-- Called when the local player's character screen faction is needed.
function Schema:GetPlayerCharacterScreenFaction(character)
	if (character.customClass and character.customClass != "") then
		return character.customClass;
	end;
end;

-- Called when the local player attempts to see a class.
function Schema:PlayerCanSeeClass(class)
	return false; -- We don't use this in our gamemode.
end;

function Schema:ChatBoxAdjustInfo(info)
	if (IsValid(info.speaker)) then
		if (info.data.anon) then
			info.name = "Somebody";
		end;
	end;
end;

-- Called when the local player's vignette should be drawn.
function Schema:DrawPlayerVignette()
	return true;
end;

-- Called to check if a player does recognise another player.
function Schema:PlayerDoesRecognisePlayer(player, status, isAccurate, realValue)
	if (player:GetFaction() == FACTION_SECURITY or player:GetFaction() == FACTION_DIRECTOR or player:GetFaction() == FACTION_DCT) then
		return true;
	end;
end;


-- Called when the target player's name is needed.
function Schema:GetTargetPlayerText(player, targetPlayerText)
	targetPlayerText:Add("RANK", Clockwork.class:Query(player:Team(), "name"), Color(200,200,200,255));
end;

/*
-- Called when needed to get current Content server version.
local ServerContentVersion = 0
function getServerContentVersion(body, len, headers, code)
	ServerContentVersion = tonumber(body);
end
http.Fetch( "http://heartbit.me/hbcontent_version.php", getServerContentVersion);*/

-- Called when player initally spawns.
function PlayerInitSpawn( ent )
	if !ent:IsPlayer() then return end

	/*if tonumber(file.Read( "addons/HeartBitContent/data/hbc_version.txt", "GAME" )) < ServerContentVersion then
		Clockwork.player:Notify(ply, "Your content pack is outdated. Please update it with the Content Manager or download a new ZIP.");
	end
	*/

	if !tobool(file.Exists( "addons/HeartBitContent/models/props_vehicles/inbound_tram.mdl", "GAME" )) and !tobool(file.Exists( "models/props_vehicles/inbound_tram.mdl", "GAME" )) then
		LocalPlayer():SetNWBool("nocontent", true)
	end
end
hook.Add( "OnEntityCreated", "OnEntityCreated", PlayerInitSpawn ) 

function Schema:HUDPaint()
	if LocalPlayer():GetNWBool("nocontent") then
		if LocalPlayer():Alive() then
			draw.WordBox( 16, ScrW()/2-225, ScrH()/2, "Detected missing content. Check 'HeartBit.me/content' for more information!", "Trebuchet18", Color(255,0,0,255), Color(255,255,255,255) )
		end
	end
end

