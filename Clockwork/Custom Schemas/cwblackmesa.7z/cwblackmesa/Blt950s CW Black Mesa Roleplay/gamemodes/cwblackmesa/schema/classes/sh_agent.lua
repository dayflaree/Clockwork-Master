--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Espionage Agent");
	CLASS.color = Color(145, 145, 145, 255);
	CLASS.factions = {FACTION_AGENT};
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A regular human citizen on a visit in the Facility.";
	CLASS.defaultPhysDesc = "Wearing casual clothes.";
CLASS_AGENT = CLASS:Register();