--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Xen Creature");

FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "blackmesarp/factions/xen";
FACTION.models = {
	female = {
		"models/blackmesa/houndeye.mdl",
		"models/blackmesa/bullsquid.mdl",
		"models/vortigaunt.mdl"
	};
	male = {
		"models/blackmesa/houndeye.mdl",
		"models/blackmesa/bullsquid.mdl",
		"models/vortigaunt.mdl"

	};
};

FACTION_XEN = FACTION:Register();