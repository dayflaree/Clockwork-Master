--[[
	� 2013 HeartBit Roleplay do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local CLASS = Clockwork.class:New("Visitor");
	CLASS.color = Color(255, 200, 100, 255);
	CLASS.wages = 40;
	CLASS.factions = {FACTION_VISITOR};
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A visitor in the faciliy.";
	CLASS.defaultPhysDesc = "Wearing a clean brown suit.";
CLASS_VISITOR = CLASS:Register();