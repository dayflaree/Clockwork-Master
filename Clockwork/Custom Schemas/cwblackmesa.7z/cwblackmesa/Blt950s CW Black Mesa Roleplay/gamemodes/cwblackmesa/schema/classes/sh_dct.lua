--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Disturbance Control Team");
	CLASS.color = Color(89, 11, 86, 255);
	CLASS.wages = 25;
	CLASS.isDefault = true;
	CLASS.factions = {FACTION_DCT};
	CLASS.wagesName = "Salary";
	CLASS.description = "A newly trained security unit.";
	CLASS.defaultPhysDesc = "Wearing a security uniform and a radio.";
CLASS_DCT = CLASS:Register();