--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Security");

FACTION.useFullName = false;
FACTION.material = "blackmesarp/factions/security";
FACTION.models = {
	female = {
		"models/securityguards/barney.mdl"
	},
	male = {
		"models/securityguards/barney.mdl",
		"models/securityguards/male_01.mdl",
		"models/securityguards/male_02.mdl",
		"models/securityguards/male_03.mdl",
		"models/securityguards/male_04.mdl",
		"models/securityguards/male_05.mdl",
		"models/securityguards/male_06.mdl",
		"models/securityguards/male_07.mdl",
		"models/securityguards/male_08.mdl",
		"models/securityguards/male_09.mdl"
	};
};

FACTION_SECURITY = FACTION:Register();