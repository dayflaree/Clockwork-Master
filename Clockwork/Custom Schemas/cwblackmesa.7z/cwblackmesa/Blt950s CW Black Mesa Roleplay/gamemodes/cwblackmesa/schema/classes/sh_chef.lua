--[[
	� 2013 HeartBit Roleplay do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local CLASS = Clockwork.class:New("Chef");
	CLASS.color = Color(0, 127, 127, 255);
	CLASS.wages = 3;
	CLASS.factions = {FACTION_CHEF};
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A chef in the faciliy.";
	CLASS.defaultPhysDesc = "Wearing a clean a chef hat.";
CLASS_CHEF = CLASS:Register();