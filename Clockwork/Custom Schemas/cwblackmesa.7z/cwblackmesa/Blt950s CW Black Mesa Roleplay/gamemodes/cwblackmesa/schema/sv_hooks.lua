--[[
	� 2013 Heartbit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

-- Called when a player's character has loaded.
function Schema:PlayerCharacterLoaded(player)
	player:SetSharedVar("cuffed", 0);
	player:SetSharedVar("inXen", false);
	player:SendLua("LocalPlayer():ConCommand('stopsound')"); // Fixing the MAX_CHANNELS bug.

	if !player:GetCharacterData("initLoaded") then
		if (player:GetFaction() == FACTION_AGENT) then
			player:SetCharacterData("Clearances", "1")
		elseif (player:GetFaction() == FACTION_SCIENTIST) then
			player:SetCharacterData("Clearances", "12")
			player:SetCharacterData("frequency", "124.7");
		elseif (player:GetFaction() == FACTION_SECURITY) then
			player:SetCharacterData("Clearances", "12S")
			player:SetCharacterData("frequency", "156.8");	
		elseif (player:GetFaction() == FACTION_MAINTENANCE) then
			player:SetCharacterData("Clearances", "1")
			player:SetCharacterData("frequency", "122.7");
		elseif (player:GetFaction() == FACTION_DIRECTOR) then
			player:SetCharacterData("Clearances", "1234BDSPX")
		elseif (player:GetFaction() == FACTION_DCT) then
			player:SetCharacterData("Clearances", "1234BDSPX")
			player:SetCharacterData("frequency", "149.2");
		elseif (player:GetFaction() == FACTION_MEDIC) then
			player:SetCharacterData("Clearances", "1")
			player:SetCharacterData("frequency", "152.9");
		elseif (player:GetFaction() == FACTION_VISITOR) then
			player:SetCharacterData("Clearances", "1")
		elseif (player:GetFaction() == FACTION_CHEF) then
			player:SetCharacterData("Clearances", "1")
		end;
		player:SetCharacterData("initLoaded", true)
	end;
	if player:GetCharacterData("Rank") != nil and Clockwork.class:FindByID(player:GetCharacterData("Rank")) then
		Clockwork.class:Set(player, player:GetCharacterData("Rank"));
	end

	player:SetCustomCollisionCheck( true ) // For tram nocollide stuff.

end;

-- Called when a player's shared variables should be set.
function Schema:PlayerSetSharedVars(player, curTime)
	player:SetSharedVar( "customClass", player:GetCharacterData("customclass", "") );
	player:SetSharedVar( "Clearances", player:GetCharacterData("Clearances") );
	player:SetSharedVar( "clothes", player:GetCharacterData("clothes", 0) );

	if (player:Alive() and !player:IsRagdolled() and player:GetVelocity():Length() > 0) then
		local inventoryWeight = player:GetInventoryWeight();
		
		if (inventoryWeight >= player:GetMaxWeight() / 4) then
			player:ProgressAttribute(ATB_STRENGTH, inventoryWeight / 400, true);
		end;
	end;
end;

-- Called just after a player spawns.
function Schema:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local clothes = player:GetCharacterData("clothes");
	if (player:GetSharedVar("cuffed") != 0) then
		self:CuffPlayer(player, true);
	end;

	if (clothes) then
		local itemTable = Clockwork.item:FindByID(clothes);
		
		if (itemTable and player:HasItemByID(itemTable.uniqueID)) then
			self:PlayerWearClothes(player, itemTable);
		else
			player:SetCharacterData("clothes", nil);
		end;
	end;

	if (player:GetFaction() == FACTION_SECURITY) then
		player:SetArmor(100);
	end;

end;

-- Called when a player spawns lightly.
function Schema:PostPlayerLightSpawn(player, weapons, ammo, special)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes) then
		local itemTable = Clockwork.item:FindByID(clothes);
		
		if (itemTable) then
			itemTable:OnChangeClothes(player, true);
		end;
	end;
end;

-- Called just before a player dies.
function Schema:DoPlayerDeath(player, attacker, damageInfo)	
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes) then
		player:GiveItem(Clockwork.item:CreateInstance(clothes));
		player:SetCharacterData("clothes", nil);
	end;

	self:CuffPlayer(player, false, true);
end;

-- Called when a player presses F3.
function Schema:ShowSpare1(player)
	local itemTable = player:FindItemByID("cuffs");
	
	if (!itemTable) then
		Clockwork.player:Notify(player, "You do not own cuffs!");
		
		return;
	end;

	Clockwork.player:RunClockworkCommand(player, "InvAction", "use", itemTable("uniqueID"), tostring(itemTable("itemID")));
end;

-- Called when a player presses F4.
function Schema:ShowSpare2(player)
	Clockwork.player:RunClockworkCommand(player, "CharSearch");
end;

-- Called when a player attempts to use a character.
function Schema:PlayerCanUseCharacter(player, character)
	if self:IsBlacklisted(player, character.faction) then
		return "You're blacklisted from "..character.faction.." faction!";
	elseif self:isTempBanned(player, tonumber(character.key)) then
		return "This character is temporary banned!";
	end
end;

-- Called when a player's data should be saved.
function Schema:PlayerSaveData(player, data)
	if (data["Blacklisted"] and table.Count(data["Blacklisted"]) == 0) then
		data["Blacklisted"] = nil;
	end;
end;

-- Called when a player's data should be restored.
function Schema:PlayerRestoreData(player, data)
	if (!data["Blacklisted"]) then
		data["Blacklisted"] = {};
	end;
end;

function Schema:PlayerRestoreCharacterData(player, data)
	if ( !data["Clearances"] ) then
		data["Clearances"] = "";
	end;
end;

-- Called when a player presses a key.
function Schema:KeyPress(player, key)
	if (key == IN_USE) then
		local uncuffTime = Schema:GetDexterityTime(player);
		local target = player:GetEyeTraceNoCursor().Entity;
		local entity = target;
		
		if (IsValid(target)) then
			target = Clockwork.entity:GetPlayer(target);
			
			if (target and player:GetSharedVar("cuffed") == 0) then
				if (target:GetShootPos():Distance( player:GetShootPos() ) <= 192) then
					if (target:GetSharedVar("cuffed") != 0) then
						Clockwork.player:SetAction(player, "uncuff", uncuffTime);
						
						Clockwork.player:EntityConditionTimer(player, target, entity, uncuffTime, 192, function()
							return player:Alive() and !player:IsRagdolled() and player:GetSharedVar("cuffed") == 0;
						end, function(success)
							if (success) then
								self:CuffPlayer(target, false);
								
								// Give the player who uncuffs their cuffs back?
								player:GiveItem(Clockwork.item:CreateInstance("cuffs"), true);
								
								player:ProgressAttribute(ATB_DEXTERITY, 15, true);
							end;
							
							Clockwork.player:SetAction(player, "uncuff", false);
							
						end);
					end;
				end;
			end;
		end;
	end;
end;

function Schema:PlayerUse(player, entity)
	local overlayText = entity:GetNetworkedString("GModOverlayText");
	local curTime = CurTime();
	local faction = player:GetFaction();
	
	if (player:GetSharedVar("cuffed") != 0) then
		if (entity:IsVehicle()) then
			if (Clockwork.entity:IsChairEntity(entity) or Clockwork.entity:IsPodEntity(entity)) then
				return;
			end;
		end;
		
		if (!player.nextCuffNotify or player.nextCuffNotify < CurTime()) then
			Clockwork.player:Notify(player, "You cannot use that when you are cuffed!");
			
			player.nextCuffNotify = CurTime() + 2;
		end;
		
		return false;
	end;
end;

-- Called when attempts to use a command.
function Schema:PlayerCanUseCommand(player, commandTable, arguments)
	if (player:GetSharedVar("cuffed") != 0) then
		local blacklisted = {
			"OrderShipment",
			"Broadcast",
			"Dispatch",
			"Request",
			"Radio"
		};
		
		if (table.HasValue(blacklisted, commandTable.name)) then
			Clockwork.player:Notify(player, "You cannot use this command when you are cuffed!");
			
			return false;
		end;
	end;
end;

-- Called when a player attempts to use a door.
function Schema:PlayerCanUseDoor(player, door)
	return false; -- Fuck you, no-one can open doors with their fists ;)
end;

-- Called when a player switches their flashlight on or off.
function Schema:PlayerSwitchFlashlight(player, on)
	if (on and (player:GetSharedVar("cuffed") != 0)) then
		return false;
	end;
end;

-- Called when a player spawns an object.
function Schema:PlayerSpawnObject(player)
	if (player:GetSharedVar("cuffed") != 0) then
		Clockwork.player:Notify(player, "You don't have permission to do this right now!");
		
		return false;
	end;
end;

-- Called when a player attempts to switch to a character.
function Schema:PlayerCanSwitchCharacter(player, character)	
	if (player:GetSharedVar("cuffed") != 0) then
		return false, "You cannot switch to this character while cuffed!";
	end;
end;

-- Called when a player attempts to destroy an item.
function Schema:PlayerCanDestroyItem(player, itemTable, noMessage)
	if (player:GetSharedVar("cuffed") != 0) then
		if (!noMessage) then
			Clockwork.player:Notify(player, "You cannot destroy items when you are cuffed!");
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to drop an item.
function Schema:PlayerCanDropItem(player, itemTable, noMessage)
	if (player:GetSharedVar("cuffed") != 0) then
		if (!noMessage) then
			Clockwork.player:Notify(player, "You cannot drop items when you are cuffed!");
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to use an item.
function Schema:PlayerCanUseItem(player, itemTable, noMessage)
	if (player:GetSharedVar("cuffed") != 0) then
		if (!noMessage) then
			Clockwork.player:Notify(player, "You cannot use items when you are cuffed!");
		end;
		
		return false;
	end;
end;

-- Called when a player attempts to use the radio.
function Schema:PlayerCanRadio(player, text, listeners, eavesdroppers)
	if (player:HasItemByID("handheld_radio")) then
		if (!player:GetCharacterData("frequency")) then
			Clockwork.player:Notify(player, "You need to set the radio frequency first!");
			
			return false;
		end;
	else
		Clockwork.player:Notify(player, "You do not own a radio!");
		
		return false;
	end;
end;

-- Called when a chat box message has been added.
function Schema:ChatBoxMessageAdded(info)
	if (info.class == "ic") then
		local eavesdroppers = {};
		local talkRadius = Clockwork.config:Get("talk_radius"):Get();
		local listeners = {};
		local players = _player.GetAll();
		local data = {};
		
		if (IsValid(data.entity) and data.frequency != "") then
			for k, v in ipairs(players) do
				if (v:HasInitialized() and v:Alive() and !v:IsRagdolled(RAGDOLL_FALLENOVER)) then
					if (( v:GetCharacterData("frequency") == data.frequency and v:GetSharedVar("cuffed") == 0
					and v:HasItemByID("handheld_radio") ) or info.speaker == v) then
						listeners[v] = v;
					elseif (v:GetPos():Distance(data.position) <= talkRadius) then
						eavesdroppers[v] = v;
					end;
				end;
			end;
			
			if (table.Count(listeners) > 0) then
				Clockwork.chatBox:Add(listeners, info.speaker, "radio", info.text);
			end;
			
			if (table.Count(eavesdroppers) > 0) then
				Clockwork.chatBox:Add(eavesdroppers, info.speaker, "radio_eavesdrop", info.text);
			end;
			
			table.Merge(info.listeners, listeners);
			table.Merge(info.listeners, eavesdroppers);
		end;
	end;
end;

-- Called when a player's radio info should be adjusted.
function Schema:PlayerAdjustRadioInfo(player, info)
	for k, v in ipairs( _player.GetAll() ) do
		if (v:HasInitialized() and v:HasItemByID("handheld_radio")) then
			if (v:GetCharacterData("frequency") == player:GetCharacterData("frequency")) then
				if (v:GetSharedVar("cuffed") == 0) then
					info.listeners[v] = v;
				end;
			end;
		end;
	end;
end;

-- Called at an interval while a player is connected.
function Schema:PlayerThink(player, curTime, infoTable)

	player:SetSharedVar("inXen", false);
	for k,v in pairs(ents.FindInBox( Vector(-8242.894531, -2099.332275, 907.571594), Vector(-10754.748047, -4291.157715, -1398.618042) )) do
		if v:IsPlayer() and v:IsValid() then
			v:SetSharedVar("inXen", true);
			if !v:GetSharedVar("wearingHEV") and v:GetMoveType() != MOVETYPE_NOCLIP and v:GetFaction() != FACTION_XEN then
			
				if( !v.LastPainSound or v.LastPainSound < CurTime() and v:Alive() )then
					v.LastPainSound = CurTime() + 1.5;
					if v:Health() >= 5 then
						v:SetHealth(v:Health()-10);
					else
						v:Kill()
					end;
					if v:GetGender() == GENDER_FEMALE then
						v:EmitSound("vo/npc/female01/pain0"..math.random(1, 9)..".wav", 60, 100 );
					else
						v:EmitSound("vo/npc/male01/pain0"..math.random(1, 9)..".wav", 60, 100 );
					end;
				end;
			end
		end
	end

	if (clothes != "") then
		local itemTable = Clockwork.item:FindByID(clothes);
		
		if (itemTable and itemTable.pocketSpace) then
			infoTable.inventoryWeight = infoTable.inventoryWeight + itemTable.pocketSpace;
		end;
	end;
	if (player:Alive() and !player:IsRagdolled()) then
		if (!player:InVehicle() and player:GetMoveType() == MOVETYPE_WALK) then
			if (player:IsInWorld()) then
				if (!player:IsOnGround()) then
					player:ProgressAttribute(ATB_ACROBATICS, 0.25, true);
				elseif (infoTable.isRunning) then
					player:ProgressAttribute(ATB_AGILITY, 0.200, true);
				elseif (infoTable.isJogging) then
					player:ProgressAttribute(ATB_AGILITY, 0.0500, true);
				end;
			end;
		end;
	end;
end

-- Called when a player attempts to change class.
function Schema:PlayerCanChangeClass(player, class)
	Clockwork.player:Notify(player, "You don't have permission to do this!");
	return false;
end;

-- Called when a player's inventory item has been updated.
function Schema:PlayerInventoryItemUpdated(player, itemTable, amount, force)
	local clothes = player:GetCharacterData("clothes");
	
	if (clothes == itemTable.index) then
		if (!player:HasItemByID(itemTable.uniqueID)) then
			itemTable:OnChangeClothes(player, false);
			
			player:SetCharacterData("clothes", nil);
		end;
	end;
end;

-- Called when a player's default inventory is needed.
function Schema:GetPlayerDefaultInventory(player, character, inventory)
	if (character.faction == FACTION_SECURITY) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		);
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("cuffs")
		);
	elseif (character.faction == FACTION_SCIENTIST) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		);
	elseif (character.faction == FACTION_MAINTENANCE) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		);
	elseif (character.faction == FACTION_MEDIC) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		);
	elseif (character.faction == FACTION_DCT) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("handheld_radio")
		);
	elseif (character.faction == FACTION_CHEF) then
		Clockwork.inventory:AddInstance(
			inventory, Clockwork.item:CreateInstance("chef hat")
		);
	end;
end;

-- Called when a player has been healed.
function Schema:PlayerHealed(player, healer, itemTable)
	if (itemTable.uniqueID == "health_vial") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 2, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 15, true);
	elseif (itemTable.uniqueID == "health_kit") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 3, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 25, true);
	elseif (itemTable.uniqueID == "bandage") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 1, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 5, true);
	end;
end;

-- Called when a player throws a punch.
function Schema:PlayerPunchThrown(player)
	player:ProgressAttribute(ATB_STRENGTH, 0.25, true);
end;

-- Called when a player punches an entity.
function Schema:PlayerPunchEntity(player, entity)
	if (entity:IsPlayer() or entity:IsNPC()) then
		player:ProgressAttribute(ATB_STRENGTH, 1, true);
	else
		player:ProgressAttribute(ATB_STRENGTH, 0.5, true);
	end;
end;


-- Called when a player's limb damage is healed.
function Schema:PlayerLimbDamageHealed(player, hitGroup, amount)
	if (hitGroup == HITGROUP_HEAD) then
		player:BoostAttribute("Limb Damage", ATB_MEDICAL, false);
	elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_STOMACH) then
		player:BoostAttribute("Limb Damage", ATB_ENDURANCE, false);
	elseif (hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG) then
		player:BoostAttribute("Limb Damage", ATB_ACROBATICS, false);
		player:BoostAttribute("Limb Damage", ATB_AGILITY, false);
	elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM) then
		player:BoostAttribute("Limb Damage", ATB_DEXTERITY, false);
		player:BoostAttribute("Limb Damage", ATB_STRENGTH, false);
	end;
end;

-- Called when a player's limb damage is reset.
function Schema:PlayerLimbDamageReset(player)
	player:BoostAttribute("Limb Damage", nil, false);
end;

-- Called when a player's limb takes damage.
function Schema:PlayerLimbTakeDamage(player, hitGroup, damage)
	local limbDamage = Clockwork.limb:GetDamage(player, hitGroup);
	
	if (hitGroup == HITGROUP_HEAD) then
		player:BoostAttribute("Limb Damage", ATB_MEDICAL, -limbDamage);
	elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_STOMACH) then
		player:BoostAttribute("Limb Damage", ATB_ENDURANCE, -limbDamage);
	elseif (hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG) then
		player:BoostAttribute("Limb Damage", ATB_ACROBATICS, -limbDamage);
		player:BoostAttribute("Limb Damage", ATB_AGILITY, -limbDamage);
	elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM) then
		player:BoostAttribute("Limb Damage", ATB_DEXTERITY, -limbDamage);
		player:BoostAttribute("Limb Damage", ATB_STRENGTH, -limbDamage);
	end;
end;


-- Called to check if a player does recognise another player.
function Schema:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
	if (target:GetFaction() == FACTION_DIRECTOR) then
		return true;
	end;
end;


-- Called when chat box info should be adjusted.
function Schema:ChatBoxAdjustInfo(info)
	if (info.class != "ooc" and info.class != "looc") then
		if (IsValid(info.speaker) and info.speaker:HasInitialized()) then
			if (string.sub(info.text, 1, 1) == "?") then
				info.text = string.sub(info.text, 2);
				info.data.anon = true;
			end;
		end;
	end;
	
	/*if (info.class == "request" or info.class == "radio") then
		voice.global = true;
	end;*/
end;

-- A function to make a player say text as a radio broadcast.
function Schema:SayRadio(player, text, check, noEavesdrop)
	local eavesdroppers = {};
	local listeners = {};
	local canRadio = true;
	local info = {listeners = {}, noEavesdrop = noEavesdrop, text = text};
	
	Clockwork.plugin:Call("PlayerAdjustRadioInfo", player, info);
	
	for k, v in pairs(info.listeners) do
		if (type(k) == "Player") and !v:GetSharedVar("inXen") then
			listeners[k] = k;
		elseif (type(v) == "Player") and !v:GetSharedVar("inXen") then
			listeners[v] = v;
		end;
	end;
	
	if (!info.noEavesdrop) then
		for k, v in pairs(cwPlayer.GetAll()) do
			if (v:HasInitialized() and !listeners[v]) then
				if (v:GetShootPos():Distance(player:GetShootPos()) <= Clockwork.config:Get("talk_radius"):Get()) then
					eavesdroppers[v] = v;
				end;
			end;
		end;
	end;
	
	if (check) then
		canRadio = Clockwork.plugin:Call("PlayerCanRadio", player, info.text, listeners, eavesdroppers);
	end;
	
	if (canRadio) then
		info = Clockwork.chatBox:Add(listeners, player, "radio", info.text);
		
		if (info and IsValid(info.speaker)) then
			Clockwork.chatBox:Add(eavesdroppers, info.speaker, "radio_eavesdrop", info.text);
			
			Clockwork.plugin:Call("PlayerRadioUsed", player, info.text, listeners, eavesdroppers);
		end;
	end;
end;

-- Called to check if a player does recognise another player.
function Schema:PlayerDoesRecognisePlayer(player, target, status, isAccurate, realValue)
	if (target:GetFaction() == FACTION_SECURITY or target:GetFaction() == FACTION_DIRECTOR or target:GetFaction() == FACTION_DCT) then
		return true;
	end;
end;

-- Called when a player's footstep sound should be played.
function Schema:PlayerFootstep(player, position, foot, sound, volume, recipientFilter)
	local running = nil;
	
	if (player:IsRunning() or player:IsJogging()) then
		running = true;
	end;
	
	if (running) then
		if (player:GetFaction() == FACTION_DCT) then
			if (foot == 0) then
				local randomSounds = {1, 3, 5};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
			else
				local randomSounds = {2, 4, 6};
				local randomNumber = math.random(1, 3);
				
				sound = "npc/combine_soldier/gear"..randomSounds[randomNumber]..".wav";
			end;
		end;
	end;
	
	player:EmitSound(sound);
	
	return true;
end
