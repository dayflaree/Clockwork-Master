--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Page");
COMMAND.tip = "Send a pager message to a player.";
COMMAND.text = "<string Name> <string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	
	if !Clockwork.kernel:GetSharedVar("comFailed") then
		if (target) then
			Clockwork.chatBox:SendColored({player, target}, Color(64, 127, 250), "[PAGER] "..player:Name(), ": ", Color(200, 127, 79), table.concat(arguments, " ", 2))
			target:EmitSound("HL1/fvox/beep.wav", 70, 100)
			Clockwork.chatBox:AddInTargetRadius(target, "me", string.gsub("'s pager beeps.", "^.", string.lower), target:GetPos(), Clockwork.config:Get("talk_radius"):Get());
		else
			Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
		end;
	else
		Clockwork.chatBox:SendColored(player, Color(64, 127, 250), "[PAGER] Error: Server connection lost.")
	end
end;

COMMAND:Register();