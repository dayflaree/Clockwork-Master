--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("CharGiveClearances");
COMMAND.tip = "Give clearances to a character.";
COMMAND.text = "<string Name> <string Clearance(s)>";
COMMAND.access = "o";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	
	if (target) then
		
		Schema:GiveClearances(target, arguments[2]);
		
		Clockwork.player:NotifyAll(player:Name().." gave "..target:Name().." level '"..arguments[2].."' clearance(s).");
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

COMMAND:Register();