--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Medical Nurse");
	CLASS.color = Color(218, 19, 192, 255);
	CLASS.factions = {FACTION_MEDIC};
	CLASS.wages = 15;
	CLASS.wagesName = "Salary";
	CLASS.description = "A regular human citizen on a visit in the Facility.";
	CLASS.defaultPhysDesc = "Wearing casual clothes.";
CLASS_MEDICAL_NURSE = CLASS:Register();