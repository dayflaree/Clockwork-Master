--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Medical Assistant");
	CLASS.color = Color(218, 19, 192, 255);
	CLASS.factions = {FACTION_MEDIC};
	CLASS.wages = 10;
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A regular human citizen on a visit in the Facility.";
	CLASS.defaultPhysDesc = "Wearing casual clothes.";
CLASS_MEDICAL_ASSISTANT = CLASS:Register();