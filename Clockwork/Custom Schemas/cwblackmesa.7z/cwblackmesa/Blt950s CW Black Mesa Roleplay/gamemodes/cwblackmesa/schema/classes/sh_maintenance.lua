--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Maintenance");
	CLASS.color = Color(255, 166, 64, 255);
	CLASS.factions = {FACTION_MAINTENANCE};
	CLASS.wages = 7;
	CLASS.isDefault = true;
	CLASS.wagesName = "Salary";
	CLASS.description = "A regular human citizen on a visit in the Facility.";
	CLASS.defaultPhysDesc = "Wearing casual clothes.";
CLASS_MAINTENANCE = CLASS:Register();