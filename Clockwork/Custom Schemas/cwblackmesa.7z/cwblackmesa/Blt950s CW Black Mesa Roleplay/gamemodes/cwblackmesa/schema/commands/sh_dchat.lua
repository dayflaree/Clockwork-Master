--[[
	� 2013 HeartBit.me do not share, re-distribute or modify
	without permission of its author (blt950@heartbit.me).
--]]

local COMMAND = Clockwork.command:New("Dchat");
COMMAND.tip = "Talk to other donators or admins through this chat.";
COMMAND.text = "<string Text>";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local audience = {}
	local text = table.concat(arguments, " ");

	if !Clockwork.player:HasFlags(player, "D") and !player:IsAdmin() and !player:IsUserGroup("operator") then 
		Clockwork.chatBox:SendColored(audience, Color(255,50,0), "You need to be a donator or admin to use this chat!")
		return
	end
	
	if (text == "") then
		Clockwork.player:Notify(player, "You did not specify enough text!");
	else
		for k, v in ipairs( _player.GetAll() ) do
			if Clockwork.player:HasFlags(v, "D") or v:IsAdmin() or v:IsUserGroup("operator") then 
				table.insert(audience, v) 
			end;
		end;
		Clockwork.chatBox:SendColored(audience, Color(255,50,0), "[ Donor Chat ] ", Color(255,255,255), player:Name()..": ", Color(255,200,50), text)
	end;
end;

COMMAND:Register();