local ITEM = Clockwork.item:New();
    ITEM.name = "Military Tablet";
    ITEM.cost = 5;
    ITEM.model = "models/nirrti/tablet/tablet_sfm.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A polymer military tablet containing enemy information.";
    ITEM.category = "Objectives";
	ITEM.skin = 19;
	
function ITEM:OnDrop() end
	
ITEM:Register();
