local ITEM = Clockwork.item:New();
    ITEM.name = "Chlorine";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A white bottle filled to the brim with a yellow liquid.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
