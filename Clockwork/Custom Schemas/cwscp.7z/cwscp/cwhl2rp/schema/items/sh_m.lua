local ITEM = Clockwork.item:New();
    ITEM.name = "Metal Fragments";
    ITEM.cost = 10;
    ITEM.model = "models/props_junk/cardboard_box003a.mdl";
    ITEM.weight = 0.5;
    ITEM.access = "v";
    ITEM.description = "A cardboard box containing assorted metal fragments.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
