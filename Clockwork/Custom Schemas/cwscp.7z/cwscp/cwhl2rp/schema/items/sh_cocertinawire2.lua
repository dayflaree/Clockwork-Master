local ITEM = Clockwork.item:New();
    ITEM.name = "Concertina Wire Barricade";
    ITEM.cost = 400;
    ITEM.model = "models/warz/items/barbed_built.mdl";
    ITEM.weight = 8;
    ITEM.access = "v";
    ITEM.description = "A set of wood and aluminium razor wire that shreds at passing organics.";
    ITEM.category = "Secure Containment Procedures";
	
function ITEM:OnDrop() end

ITEM:Register();
