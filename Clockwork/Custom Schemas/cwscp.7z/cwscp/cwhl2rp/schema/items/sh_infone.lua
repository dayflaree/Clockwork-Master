local ITEM = Clockwork.item:New();
    ITEM.name = "Intel Phone";
    ITEM.cost = 5;
    ITEM.model = "models/lt_c/tech/cellphone.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A smartphone containing classified intelligence.";
    ITEM.category = "Objectives";
	ITEM.skin = 9;
	
function ITEM:OnDrop() end
	
ITEM:Register();
