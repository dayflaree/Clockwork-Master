local ITEM = Clockwork.item:New();
    ITEM.name = "File Bin";
    ITEM.cost = 5;
    ITEM.model = "models/props/cs_office/file_box.mdl";
    ITEM.weight = 0.8;
    ITEM.access = "v";
    ITEM.description = "A large paper box carrying dozens of manilla folders.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
