local ITEM = Clockwork.item:New();
    ITEM.name = "Rubidium";
    ITEM.cost = 110;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.4;
    ITEM.access = "v";
    ITEM.description = "A silver-white cylinder of metal suspended in mineral oil. Rubidium is an alkali metal and will combust when exposed to air.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
