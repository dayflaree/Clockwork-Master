local ITEM = Clockwork.item:New();
    ITEM.name = "Wooden Shield Kit";
    ITEM.cost = 100;
    ITEM.model = "models/warz/items/woodshield_unbuilt.mdl";
    ITEM.weight = 5;
    ITEM.access = "v";
    ITEM.description = "A set of wooden planks and nails that can be used to create a primitive barricade.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
