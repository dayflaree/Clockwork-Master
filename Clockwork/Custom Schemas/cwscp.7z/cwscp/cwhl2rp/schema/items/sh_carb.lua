local ITEM = Clockwork.item:New();
    ITEM.name = "Carbon";
    ITEM.cost = 8;
    ITEM.model = "models/props_junk/PropaneCanister001a.mdl";
    ITEM.weight = 0.5;
    ITEM.access = "v";
    ITEM.description = "A small green canister with a gas valve. The building blocks of all life.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
