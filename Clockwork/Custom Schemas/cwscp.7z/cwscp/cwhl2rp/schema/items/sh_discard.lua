local ITEM = Clockwork.item:New();
    ITEM.name = "Crumpled Paper";
    ITEM.cost = 5;
    ITEM.model = "models/props/cs_office/trash_can_p5.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "An unknown sheet of crumpled paper. It is ruined forever!";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
