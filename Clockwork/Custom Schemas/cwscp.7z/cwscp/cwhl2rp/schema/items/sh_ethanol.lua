local ITEM = Clockwork.item:New();
    ITEM.name = "Ethanol";
    ITEM.cost = 5;
    ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A red bottle filled with a clear, yeasty liquid. A 'flammable' graphic is printed on the side. It smells of alchohol.";
    ITEM.category = "Chemical Compound";
	
function ITEM:OnDrop() end
	
ITEM:Register();
