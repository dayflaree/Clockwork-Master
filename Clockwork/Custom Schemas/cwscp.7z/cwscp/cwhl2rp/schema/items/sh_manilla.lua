local ITEM = Clockwork.item:New();
    ITEM.name = "Classified Folder";
    ITEM.cost = 5;
    ITEM.model = "models/props_junk/garbage_carboard002a.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A large manilla folder containing classified intelligence.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
