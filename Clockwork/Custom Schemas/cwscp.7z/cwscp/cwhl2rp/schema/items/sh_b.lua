local ITEM = Clockwork.item:New();
    ITEM.name = "Human Blood Cells";
    ITEM.cost = 8;
    ITEM.model = "models/items/redammo.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A small vial containing a compressed red mass.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
