local ITEM = Clockwork.item:New();
    ITEM.name = "Hard Drive";
    ITEM.cost = 5;
    ITEM.model = "models/gaming-models/nebukadnezar/gibs/pc_gibs/pc_harddrive.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A solid-state hard drive carrying classified intelligence.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
