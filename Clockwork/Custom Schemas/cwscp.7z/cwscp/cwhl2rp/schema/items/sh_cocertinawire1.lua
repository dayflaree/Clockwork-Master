local ITEM = Clockwork.item:New();
    ITEM.name = "Concertina Wire Kit";
    ITEM.cost = 400;
    ITEM.model = "models/warz/items/barbed_unbuilt.mdl";
    ITEM.weight = 8;
    ITEM.access = "v";
    ITEM.description = "A set of wood and aluminium razor wire that shreds at passing organics.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
