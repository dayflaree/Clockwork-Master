local ITEM = Clockwork.item:New();
    ITEM.name = "Oxygen";
    ITEM.cost = 8;
    ITEM.model = "models/props_junk/propane_tank001a.mdl";
    ITEM.weight = 0.5;
    ITEM.access = "v";
    ITEM.description = "A small red canister with a gas valve.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
