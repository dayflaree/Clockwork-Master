local ITEM = Clockwork.item:New();
    ITEM.name = "Plasma";
    ITEM.cost = 8;
    ITEM.model = "models/katharsmodels/syringe_out/heroine_out.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A white container filled with large white crystals.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
