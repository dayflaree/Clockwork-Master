local ITEM = Clockwork.item:New();
    ITEM.name = "Potassium";
    ITEM.cost = 105;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.4;
    ITEM.access = "v";
    ITEM.description = "A rough metal pearl suspended in paraffin oil. Potassium is an alkali metal and will combust when exposed to air.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
