local ITEM = Clockwork.item:New();
    ITEM.name = "Sugar";
    ITEM.cost = 5;
    ITEM.model = "models/cocn.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A white container of industrial refined powder.";
    ITEM.category = "Chemical Compound";
	
function ITEM:OnDrop() end
	
ITEM:Register();
