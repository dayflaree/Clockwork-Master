local ITEM = Clockwork.item:New();
    ITEM.name = "Intelligence Binder";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/binderblue.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A binder carrying classified intelligence.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
