local ITEM = Clockwork.item:New();
    ITEM.name = "Glucose";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A small vial containing a refined powder.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
