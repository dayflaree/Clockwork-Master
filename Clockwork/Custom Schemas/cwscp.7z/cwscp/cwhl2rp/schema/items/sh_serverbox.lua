local ITEM = Clockwork.item:New();
    ITEM.name = "Server";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/reciever01b.mdl";
    ITEM.weight = 2;
    ITEM.access = "v";
    ITEM.description = "A server box that can be disconnected and carried.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
