local ITEM = Clockwork.item:New();
    ITEM.name = "Lithium";
    ITEM.cost = 100;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.4;
    ITEM.access = "v";
    ITEM.description = "A cloudy crystalline compound suspended in mineral oil. Lithium is an alkali metal and will combust when exposed to air.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
