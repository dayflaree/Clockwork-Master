local ITEM = Clockwork.item:New();
    ITEM.name = "Hydrogen";
    ITEM.cost = 8;
    ITEM.model = "models/props_junk/PropaneCanister001a.mdl";
    ITEM.weight = 0.5;
    ITEM.access = "v";
    ITEM.description = "A small copper canister with a gas valve.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
