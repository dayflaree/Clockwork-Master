local ITEM = Clockwork.item:New();
    ITEM.name = "Heroin (Raw)";
    ITEM.cost = 8;
    ITEM.model = "models/katharsmodels/syringe_out/heroine_out.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A small vial of brown saturated liquid.";
    ITEM.category = "Chemical Compound";
	
function ITEM:OnDrop() end
	
ITEM:Register();
