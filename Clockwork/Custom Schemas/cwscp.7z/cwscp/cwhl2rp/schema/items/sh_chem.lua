local ITEM = Clockwork.item:New();
    ITEM.name = "Chemical Synthesizer";
    ITEM.cost = 10;
    ITEM.model = "models/pg_props/pg_hospital/pg_ekg.mdl";
    ITEM.weight = 3;
    ITEM.access = "v";
    ITEM.description = "A device capable of creating chemical synthesis between two or more molecules.";
    ITEM.category = "Lab Equipment";
	
function ITEM:OnDrop() end
	
ITEM:Register();
