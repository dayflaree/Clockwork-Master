local ITEM = Clockwork.item:New();
    ITEM.name = "Docile C4";
    ITEM.cost = 5;
    ITEM.model = "models/weapons/w_c4.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A safe, deactivated C4 explosive device.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
