local ITEM = Clockwork.item:New();
    ITEM.name = "Pure Table Salt";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A white container marked 'NaCl' that holds a white crystalline substance.";
    ITEM.category = "Chemical Compound";
	
function ITEM:OnDrop() end
	
ITEM:Register();
