local ITEM = Clockwork.item:New();
    ITEM.name = "Magnesium";
    ITEM.cost = 100;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.4;
    ITEM.access = "v";
    ITEM.description = "A roll of silver metal strips. Magnesium is an Alkaline Earth metal, and will tarnish when exposed to air. When ignited, it would be powdered and shed by flame.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
