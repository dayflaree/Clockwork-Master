local ITEM = Clockwork.item:New();
    ITEM.name = "Global Positioning System";
    ITEM.cost = 180;
    ITEM.model = "models/lt_c/tech/tablet_civ.mdl";
    ITEM.weight = 0.1;
    ITEM.access = "v";
    ITEM.description = "A tablet that can be used to recieve sattelite scans of a certain area.";
    ITEM.category = "Electronics";
	ITEM.skin = 5;
	
function ITEM:OnDrop() end
	
ITEM:Register();
