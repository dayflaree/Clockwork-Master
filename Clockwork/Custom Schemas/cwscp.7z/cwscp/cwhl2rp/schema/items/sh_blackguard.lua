local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "B-2 Blackguard Task Suit";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 2,000;
ITEM.weight = 7;
ITEM.business = true;
ITEM.access = "V";
ITEM.useText = "Wear";
ITEM.category = "Clothing";
ITEM.protection = 0.5;
ITEM.description = "A black heavily modified powered uniform which greatly enhances the speed, strength, and integrity of the wearer.";
ITEM.replacement = "models/pac.mdl"

ITEM:Register();