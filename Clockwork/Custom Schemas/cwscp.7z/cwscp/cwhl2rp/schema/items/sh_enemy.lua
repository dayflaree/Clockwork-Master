local ITEM = Clockwork.item:New();
    ITEM.name = "Confiscated Weapon";
    ITEM.cost = 5;
    ITEM.model = "models/weapons/w_eq_eholster_elite.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A holstered firearm retrieved from a hostile group of interest.";
    ITEM.category = "Objectives";
	
function ITEM:OnDrop() end
	
ITEM:Register();
