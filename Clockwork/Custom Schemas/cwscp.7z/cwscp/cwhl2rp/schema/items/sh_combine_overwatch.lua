local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Urban Combat Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 500;
ITEM.weight = 7;
ITEM.business = true;
ITEM.access = "V";
ITEM.useText = "Wear";
ITEM.category = "Clothing";
ITEM.protection = 0.5;
ITEM.description = "A heavy set of black and tan BDU, as well as plate carriers and a helmet, marked with FBI brandings.";
ITEM.replacement = "models/combine_soldier_pmc.mdl"

ITEM:Register();
