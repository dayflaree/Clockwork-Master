local ITEM = Clockwork.item:New();
    ITEM.name = "Beryllium";
    ITEM.cost = 110;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.4;
    ITEM.access = "v";
    ITEM.description = "A chunk of silver-grey crystal. Beryllium is an Alkaline Earth metal, and is prone to extreme polarization, as well as transparency to electromagnetic waves.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
