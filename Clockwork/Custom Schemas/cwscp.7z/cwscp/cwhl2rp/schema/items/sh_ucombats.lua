local ITEM = Clockwork.item:New("clothes_base");
ITEM.name = "Urban Combat Uniform";
ITEM.model = "models/props_c17/BriefCase001a.mdl";
ITEM.cost = 500;
ITEM.weight = 7;
ITEM.business = true;
ITEM.access = "V";
ITEM.useText = "Wear";
ITEM.category = "Clothing";
ITEM.protection = 0.5;
ITEM.description = "A set of dirty civilian clothing and a set of plate carriers and kneepads.";
ITEM.replacement = "models/mfc_new.mdl"

ITEM:Register();
