local ITEM = Clockwork.item:New();
    ITEM.name = "Heroin";
    ITEM.cost = 10;
    ITEM.model = "models/katharsmodels/syringe_out/heroine_out.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A white container full of a contrasted grainy substance.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
