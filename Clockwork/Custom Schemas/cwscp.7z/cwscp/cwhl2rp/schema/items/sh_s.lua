local ITEM = Clockwork.item:New();
    ITEM.name = "Sodium";
    ITEM.cost = 5;
    ITEM.model = "models/props_lab/jar01b.mdl";
    ITEM.weight = 0.3;
    ITEM.access = "v";
    ITEM.description = "A white container filled with large white crystals.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end
	
ITEM:Register();
