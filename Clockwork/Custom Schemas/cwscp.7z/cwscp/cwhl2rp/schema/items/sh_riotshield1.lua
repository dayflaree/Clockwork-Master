local ITEM = Clockwork.item:New();
    ITEM.name = "Riot Shield Kit";
    ITEM.cost = 300;
    ITEM.model = "models/warz/items/riot_crate.mdl";
    ITEM.weight = 5;
    ITEM.access = "v";
    ITEM.description = "A heavy metal crate that can be unfolded into a secure anti-anomaly barricade.";
    ITEM.category = "Ingredient";
	
function ITEM:OnDrop() end

ITEM:Register();
