local PLUGIN = PLUGIN;

PLUGIN.text = [[Introduction

Mankind in its present state has existed for a quarter of a million years,
yet only the last 4,000 have been of any significance.



So, what did we do for nearly 250,000 years? 
We huddled in caves and around small fires, fearful of the things that we didn't understand.



It was more than explaining why the sun came up, it was the mystery of enormous birds with heads of men and rocks that came to life. 
So we called them 'gods' and 'demons', begged them to spare us, and prayed for salvation.



In time, their numbers dwindled and ours rose. 
The world began to make more sense when there were fewer things to fear,
yet the unexplained can never truly go away, as if the universe demands the absurd and impossible.


Mankind must not go back to hiding in fear. No one else will protect us, and we must stand up for ourselves.
While the rest of mankind dwells in the light, we must stand in the darkness to fight it,
contain it, and shield it from the eyes of the public, 
so that others may live in a sane and normal world.

We secure, we contain, we protect.

-A word from "The Administrator"

If you have recieved this message, you have made numerous advancements for employment in a research position
at the SCP Foundation.

Due to the sensitive nature of our Foundation, most information regarding the nature of our buisiness has
been omitted from all applicants.

As the offer stands, and if you decide to accept said offer, you will be provided with one residential apartment
with all expenses paid in the Wholesale Warehouse District of Los Angeles, California. You will recieve
a weekly salary of $1,000 USD, as well as optimized Health Insurance benefits for all family members.

Entry-Level Work includes;

Ensuring sanitary conditions throughout the facility
Synthesis and production of chemical compounds for specific use
Optimizing and enhancing experimental containment procedures
Archiving and collecting data through the on-site intranet

On behalf of Site 86 administration, we hope you choose to accept this offer. As of now, your operational
security clearence is default Level 0.
