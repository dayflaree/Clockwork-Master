local ITEM = Clockwork.item:New();
ITEM.name = "Foilo 5.5 Aware";
ITEM.cost = 180;
ITEM.uniqueID = "sony";
ITEM.model = "models/lt_c/tech/cellphone.mdl";
ITEM.weight = 0.8;
ITEM.access = "1";
ITEM.category = "Communication";
ITEM.business = true;
ITEM.description = "A traffic, construction, and general application model of the Foilo. It is currently favoured as the Foundation's standard issue.";
ITEM.skin = 8;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();