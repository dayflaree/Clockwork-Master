local ITEM = Clockwork.item:New();
ITEM.name = "Foilo 5.5 Air";
ITEM.cost = 180;
ITEM.uniqueID = "nokia";
ITEM.model = "models/lt_c/tech/cellphone.mdl";
ITEM.weight = 0.8;
ITEM.access = "1";
ITEM.category = "Communication";
ITEM.business = true;
ITEM.description = "A designer phone model crafted for the creative mind. It is currently favoured as the Foundation's standard issue.";
ITEM.skin = 3;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();