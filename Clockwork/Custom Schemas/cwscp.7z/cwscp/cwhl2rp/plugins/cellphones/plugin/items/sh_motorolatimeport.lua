local ITEM = Clockwork.item:New();
ITEM.name = "Foilo 5.5 Sleek";
ITEM.cost = 180;
ITEM.uniqueID = "motorola";
ITEM.model = "models/deadbodies/dead_male_civilian_radio.mdl";
ITEM.weight = 0.8;
ITEM.access = "1";
ITEM.category = "Communication";
ITEM.business = true;
ITEM.description = "A general, high-tech phone designed to be used by high-speed on-the-clock businessmen. Currently favoured by the Foundation as standard-issue.";

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();