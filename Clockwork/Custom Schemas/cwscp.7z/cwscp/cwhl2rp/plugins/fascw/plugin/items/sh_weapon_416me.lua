--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "H&K HK416 Magnified EOTECH";
	ITEM.model = "models/weapons/j_rif_hm.mdl";
	ITEM.weight = 4;
	ITEM.uniqueID = "weapon_fas_416me";
	ITEM.description = "A modern German assault carbine, based on the iconic M4, fitted with a magnifier and EOTECH sight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();













