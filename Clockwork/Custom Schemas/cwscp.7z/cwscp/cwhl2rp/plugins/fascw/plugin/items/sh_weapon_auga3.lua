--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Steyr AUG A3";
	ITEM.model = "models/weapons/j_rif_au.mdl";
	ITEM.weight = 5;
	ITEM.uniqueID = "weapon_fas_auga3";
	ITEM.description = "A modern Austrian bullpup assault rifle, fitted with a special sight.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();












