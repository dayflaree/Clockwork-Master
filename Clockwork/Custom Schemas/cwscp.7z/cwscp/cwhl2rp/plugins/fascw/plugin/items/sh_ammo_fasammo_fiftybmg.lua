--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = ".50 BMG Ammo";
	ITEM.batch = 1;
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 2;
	ITEM.uniqueID = "ammo_fasammo_fiftybmg";
	ITEM.ammoClass = "fiftybmg";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box of .50 BMG ammo.";
Clockwork.item:Register(ITEM);
