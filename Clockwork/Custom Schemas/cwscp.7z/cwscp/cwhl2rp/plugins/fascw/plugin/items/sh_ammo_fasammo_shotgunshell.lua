--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Shotgun Shells";
	ITEM.batch = 1;
	ITEM.model = "models/Items/BoxBuckshot.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_fasammo_shotgunshell";
	ITEM.ammoClass = "shotgunshell";
	ITEM.ammoAmount = 16;
	ITEM.description = "A box of shotgun shells.";
Clockwork.item:Register(ITEM);


