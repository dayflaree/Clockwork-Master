--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "H&K HK53";
	ITEM.batch = 1;
	ITEM.model = "models/weapons/j_rif_hk534u.mdl";
	ITEM.weight = 3;
	ITEM.uniqueID = "weapon_fas_53";
	ITEM.business = false;
	ITEM.description = "A heavy, but compact German submachine gun, based on the MP5.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();














