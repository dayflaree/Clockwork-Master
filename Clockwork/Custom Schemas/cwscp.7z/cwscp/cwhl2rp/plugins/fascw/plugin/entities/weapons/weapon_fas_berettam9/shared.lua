if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5

	SWEP.HoldType			= "pistol"

end
if ( CLIENT ) then
	SWEP.PrintName			= "Beretta M92FS"	
	SWEP.Author				= "MikkoK"
	SWEP.SlotPos			= 1
	SWEP.IconLetter			= "m"
	SWEP.Slot				= 1
		
	SWEP.NameOfSWEP			= "weapon_fas_berettam9" --always make this the name of the folder the SWEP is in.
	killicon.AddFont( SWEP.NameOfSWEP, "CSKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
end
SWEP.ViewModelFOV      = 60
SWEP.Instructions		= "Uses 9mm ammo, Switch Weapons: E + Left Click"
SWEP.Base				= "weapon_fas_sim_base"
SWEP.ViewModelFlip		= false
SWEP.HoldType				= "pistol"
SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.ViewModel			= "models/weapons/a_m9.mdl"
SWEP.WorldModel			= "models/weapons/b_92f.mdl"

SWEP.Weight				= 5
SWEP.AutoSwitchTo		= false
SWEP.AutoSwitchFrom		= false

SWEP.Primary.Sound			= Sound("Weapof_Beretta92fs.Shoot")
SWEP.Primary.Recoil			= 2.5
SWEP.Primary.Damage			= 17
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.021
SWEP.Primary.ClipSize		= 15
SWEP.Primary.Delay			= 0.15
SWEP.Primary.DefaultClip	= 0
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo 		= "ninemmgerman"

SWEP.Secondary.ClipSize 	= -1
SWEP.Secondary.DefaultClip 	= -1
SWEP.Secondary.Automatic 	= false
SWEP.Secondary.Ammo 		= "none"
SWEP.secondaryWeapon 		= true
SWEP.ShellDelay			= 0.02
SWEP.ShellEffect			= "sim_shelleject_fas_9x19mm"	// "effect_mad_shell_pistol" or "effect_mad_shell_rifle" or "effect_mad_shell_shotgun"

SWEP.Type				= 2
SWEP.Mode				= false

SWEP.Pistol				= true
SWEP.Rifle				= false
SWEP.Shotgun			= false
SWEP.Sniper				= false

SWEP.IronSightsPos = Vector (-3.4915, -3.0001, 1.3414)
SWEP.IronSightsAng = Vector (-0.1484, 0.0126, 0)

SWEP.Speed = 0.6
SWEP.Mass = 0.95
SWEP.WeaponName = "weapon_fas_m9"
SWEP.WeaponEntName = "sim_fas_m9"
/*---------------------------------------------------------
   Name: SWEP:Precache()
   Desc: Use this function to precache stuff.
---------------------------------------------------------*/
function SWEP:Precache()
    util.PrecacheSound("weapons/pistol_beretta92fs/m9_fire1.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_fire2.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_fire3.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_fire4.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_fire5.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_magout.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_magin.wav")
	util.PrecacheSound("weapons/pistol_beretta92fs/m9_slidestop.wav")
end

/*---------------------------------------------------------
   Name: SWEP:ShootAnimation()
---------------------------------------------------------*/
function SWEP:ShootAnimation()
	
	if (self.Weapon:Clip1() == 0) then
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("fire_last_nosup"))
	else
		self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	end
end




