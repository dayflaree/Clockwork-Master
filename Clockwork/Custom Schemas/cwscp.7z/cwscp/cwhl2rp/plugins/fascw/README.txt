You may need to download this and upload it manually to addons folder:
http://gmod.gamebanana.com/skins/122672
1: Go to server.cfg and add these two lines there: sim_manualholster_t 0 sim_crosshair_t 0
2: Copy the facw folder over to gamemodeschema\plugins
3: Done.

If you want to edit weapon damages go over to plugins\facw\entities\weapons\weaponname and open the shared.lua, find the SWEP.primaryDamage line and edit the damage there, same with recoil.

There are around 50+ weapons, I made them so they won�t show up in business menu, if you want to edit the description/name go to sh_weapon_weaponname.lua and do it there.

To edit ammo names/descriptions/amounts/models go to sh_ammo_fasammo_ammoname.lua and edit them there.

Thanks for the help to scrubmcnoob and Bork, love ya.