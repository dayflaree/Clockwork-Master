
local COMMAND = Clockwork.command:New("ToggleWinter");
COMMAND.tip = "Toggles your winter coat on/off.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local model = player:GetModel();
	-- Check if player has the correct model (the '^' matches to the start of the string)
	if (string.find(model, "^models/tnb/citizens/")) then
		-- Get the player's toggle bodygroups
		local toggleBodygroup = player:GetCharacterData("toggle_bodygroup", {});
		-- If there is no table for this model yet or it is not set to one, and the player's bodygroup is not one
		if ((!toggleBodygroup[model] or toggleBodygroup[model]["1"] != 16) and player:GetBodygroup(1) != 16) then
			-- Ensure the table is made
			toggleBodygroup[model] = toggleBodygroup[model] or {};
			-- Set the value
			toggleBodygroup[model]["1"] = 16;
			Clockwork.player:Notify(player, "You have put on your nylon jacket.");
		else
			-- Ensure we have a table to avoid lua errors
			toggleBodygroup[model] = toggleBodygroup[model] or {};
			-- Set bodygroup 1 to nil so it reverts to 0/whatever it should be add
			toggleBodygroup[model]["1"] = nil;
			Clockwork.player:Notify(player, "You have taken off your winter coat.");
		end;
		-- Update character data
		player:SetCharacterData("toggle_bodygroup", toggleBodygroup);
		-- Update player's bodygroups
		player:SetBodyGroups();
	else
		Clockwork.player:Notify(player, "Your model cannot use a jacket.");
	end;
end;

COMMAND:Register();
-- Add F1 menu option
if (CLIENT) then
	Clockwork.quickmenu:AddCallback("Toggle Winter Coat", nil, function()
		local commandTable = Clockwork.command:FindByID("ToggleWinter");
		
		if (commandTable) then
			return {
				toolTip = commandTable.tip,
				Callback = function(option)
					Clockwork.kernel:RunCommand("ToggleWinter");
				end
			};
		else
			return false;
		end;
	end);
end;