
local COMMAND = Clockwork.command:New("ToggleNone");
COMMAND.tip = "Takes off your head gear.";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local model = player:GetModel();
	-- Check if player has the correct model (the '^' matches to the start of the string)
	if (string.find(model, "^models/tlsaudrl2548/blackops2/")) then
		-- Get the player's toggle bodygroups
		local toggleBodygroup = player:GetCharacterData("toggle_bodygroup", {});
		-- If there is no table for this model yet or it is not set to one, and the player's bodygroup is not one
		if ((!toggleBodygroup[model] or toggleBodygroup[model]["2"] != 3) and player:GetBodygroup(2) != 3) then
			-- Ensure the table is made
			toggleBodygroup[model] = toggleBodygroup[model] or {};
			-- Set the value
			toggleBodygroup[model]["2"] = 3;
			Clockwork.player:Notify(player, "You have removed all your headgear.");
		else
			-- Ensure we have a table to avoid lua errors
			toggleBodygroup[model] = toggleBodygroup[model] or {};
			-- Set bodygroup 1 to nil so it reverts to 0/whatever it should be add
			toggleBodygroup[model]["1"] = nil;
			Clockwork.player:Notify(player, "You have replaced your headgear.");
		end;
		-- Update character data
		player:SetCharacterData("toggle_bodygroup", toggleBodygroup);
		-- Update player's bodygroups
		player:SetBodyGroups();
	else
		Clockwork.player:Notify(player, "You are not wearing a guard uniform!");
	end;
end;

COMMAND:Register();
-- Add F1 menu option
if (CLIENT) then
	Clockwork.quickmenu:AddCallback("Remove All Headgear [SWAT]", nil, function()
		local commandTable = Clockwork.command:FindByID("ToggleNone");
		
		if (commandTable) then
			return {
				toolTip = commandTable.tip,
				Callback = function(option)
					Clockwork.kernel:RunCommand("ToggleNone");
				end
			};
		else
			return false;
		end;
	end);
end;