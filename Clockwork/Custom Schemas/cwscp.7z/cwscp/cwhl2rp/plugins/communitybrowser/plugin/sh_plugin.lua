--[[
		Created by Polis - 2014.
		If contact is required, please add 'Polis' on Steam.
]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");