--[[
	� March 2014 - Polis
    You may re-distribute this plugin with permission from the author.
--]]

local COMMAND = Clockwork.command:New("Community");
COMMAND.tip = "Open a window to display the community website/forums.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.text = "<none>";

-- Called when the command has been run.
function COMMAND:OnRun(player)
	player:ConCommand("PoMen")
end;

COMMAND:Register();