--[[
		Created by Polis - 2014.
		If contact is required, please add 'Polis' on Steam.
]]

Clockwork.hint:Add("Community", "Need to take a quick look at the community website/forums? Try doing /community in the chat box.");