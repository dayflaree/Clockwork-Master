--[[
		Created by Polis - 2014.
		If contact is required, please add 'Polis' on Steam.
]]

local PLUGIN = PLUGIN;

WindowName = "Site Network PDA"  -- Name of the the window.
website = "http://86.site.nfoservers.com/index.php" -- The page displayed.
dragable = true; -- Set to true or false depending on whether the window should be dragable or not.


function StartMenu()
	local scrW = ScrW();
	local scrH = ScrH();

    Menu = vgui.Create( "DFrame" )
	Menu:SetPos( 50, 50 );
    Menu:SetSize( 1200, 900 )
    Menu:SetTitle( WindowName )
    Menu:SetBackgroundBlur( true )
    Menu:SetVisible( true )
    Menu:SetDraggable( dragable )
    Menu:ShowCloseButton( true )
    Menu:MakePopup()
    Menu.Paint = function()
	draw.RoundedBox( 8, 0, 0, Menu:GetWide(), Menu:GetTall(), Color( 139, 137, 137, 240 ) )
end

    local FHTML = vgui.Create("HTML")
    FHTML:SetParent( Menu )
    FHTML:SetPos(5,25)
    FHTML:SetSize(1190, 865)
    FHTML:OpenURL(website)

    local FHTMLControls = vgui.Create( "DHTMLControls", FHTML ) 
    FHTMLControls:SetHTML( FHTML )

end;
concommand.Add("PoMen", StartMenu)