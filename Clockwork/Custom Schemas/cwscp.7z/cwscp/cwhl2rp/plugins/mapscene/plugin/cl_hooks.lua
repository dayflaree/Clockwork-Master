--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

-- Called when the character background should be drawn.
function cwMapScene:ShouldDrawCharacterBackground()
	if (self.curStored) then 
		return false; 
	end;
end;

function cwMapScene:TranslateVector(num1, num2, speed)
		
	local sum = Vector (0, 0, 0);
	
	if (self.sumz) then
		sum.z = self.sumz
	end;
	if (self.sumx) then
		sum.x = self.sumx
	end;
	if (self.sumy) then
		sum.y = self.sumy
	end;
	
	num1.x = math.floor(num1.x)
	num1.y = math.floor(num1.y)
	num1.z = math.floor(num1.z)
	num2.x = math.floor(num2.x)
	num2.y = math.floor(num2.y)
	num2.z = math.floor(num2.z)
	
	local diff = {}
	diff.x = num1.x - num2.x
	diff.y = num1.y - num2.y
	diff.z = num1.z - num2.z
--	print("Diff x "..tostring(diff.x))
--	print("Diff y "..tostring(diff.y))
--	print("Diff z "..tostring(diff.z))
	if diff.z < 0 then
		diff.z = diff.z-diff.z*2
	end;
	if diff.y < 0 then
		diff.y = diff.y-diff.y*2
	end;
	if diff.x < 0 then
		diff.x = diff.x-diff.x*2
	end;
	
--	print("Positive Number X "..tostring(diff.x))
--	print("Positive Number Y "..tostring(diff.y))
--	print("Positive Number Z "..tostring(diff.z))
	
	self.factor = cwMapScene:CommonFactor(diff.x, diff.y, diff.z)
--	print("Greatest Factor "..self.factor)
	
	if !self.xCompare then
		if num1.x > num2.x then
			self.xCompare = "subtract"
		elseif num1.x < num2.x then
			self.xCompare = "add"
		else
			self.xCompare = "equal"
		end;
	end;
	
	if !self.yCompare then
		if num1.y > num2.y then
			self.yCompare = "subtract"
		elseif num1.y < num2.y then
			self.yCompare = "add"
		else
			self.yCompare = "equal"
		end;
	end;
	
	if !self.zCompare then
		if num1.z > num2.z then
			self.zCompare = "subtract"
		elseif num1.z < num2.z then
			self.zCompare = "add"
		else
			self.zCompare = "equal"
		end;
	end;
	
	if !self.counter then
		self.counter = 0
	end;
		
	self.counter = self.counter + 1;
	
	if !self.xDone then
--		print("X")
	--	print(self.xCompare)
		sum.x = self:TranslateNumber(num1.x, num2.x, speed, self.xCompare)
	end;
	
	if ((sum.x == num2.x) or self.xCompare == "equal") then
		self.sumx = num2.x
		self.xDone = true
	end;
		
	if !self.yDone then
	--	print("Y")
--		print(self.yCompare)
		sum.y = self:TranslateNumber(num1.y, num2.y, speed, self.yCompare)
	end;
	
	if ((sum.y == num2.y) or self.yCompare == "equal") then
		self.sumy = num2.y
		self.yDone = true
	end;
	
	if !self.zDone then
	--	print("Z")
--		print(self.zCompare)
		sum.z = self:TranslateNumber(num1.z, num2.z, speed, self.zCompare)
	end;
	
	if ((sum.z == num2.z) or self.zCompare == "equal") then
		self.sumz = num2.z
		self.zDone = true
	end;
	
	local done = false
	
	if (self.zDone == true and self.xDone == true and self.yDone == true) then
		done = true;
	end;
	
	return sum, done;
	
end;
 
function cwMapScene:FactorNum(num)
	local factors = {}

	for i = 1, num do
		if num % i == 0 then
			factors[#factors+1] = i
--			print("- "..tostring(i))
		end;
	end;
	return factors
end;
 
function cwMapScene:CommonFactor(num1, num2, num3)
	local temp = {}
	local factors = {}
	for k, v in ipairs(self:FactorNum(num1)) do
		for k2, v2 in ipairs(self:FactorNum(num2)) do
			if v == v2 then
				temp[#temp] = v
			end;
		end;
	end;
	
	for k, v in ipairs(temp) do
		for k2, v2 in ipairs(self:FactorNum(num3)) do
			if v == v2 then
				print("V "..tostring(v))
				factors[#factors] = v
			end;
		end;
	end;
	
	return table.maxn(factors)
end;

function cwMapScene:TranslateNumber(num1, num2, speed, compare)

	local numSum;
	local difference = num1 - num2
	local portion = difference / self.factor
--	print(tostring(speed * self.counter))
--	print("Start "..tostring(num1))
--	print("End "..tostring(num2))
--	print("Portion "..tostring(portion))
--	print("Offset Percent "..tostring(((difference*0.01*speed)/difference)*100))
	if (compare == "add") then	
		numSum = num1 + ((difference*0.01*speed)/difference)*self.counter*100--( (((difference*0.01)/difference)*100) + (speed*self.counter))
		if numSum > num2 then
			numSum = num2
		end;
	elseif (compare == "subtract") then
		numSum = num1 - ((difference*0.01*speed)/difference)*self.counter*100--( (((difference*0.01)/difference)*100) + (speed*self.counter))
		if numSum < num2 then
			numSum = num2
		end;
	end;

--	print("Sum "..tostring(numSum))
	return numSum
	
end;

-- Called when the view should be calculated.
function cwMapScene:CalcView(player, origin, angles, fov)
	if (Clockwork.kernel:IsChoosingCharacter() and (self.curStored)) then	
		
		local addVector = Vector(0,0,0)
		local addAngle = Angle(0,0,0)
		local done;
		
		if (!self.scene) then
			if !self.sceneNum then
				self.sceneNum = 0
			end;
			self.sceneNum = self.sceneNum + 1
			if self.sceneNum > #self.curStored then
				self.sceneNum = 1
			end;
			self.scene = self.curStored[self.sceneNum];		
		end;
		
		local speed = self.scene.speed or 0.6
		
		if (self.scene.endPoint) then

			addVector, done = self:TranslateVector(self.scene.position, self.scene.endPoint.position, speed)
			addAngle = self.scene.angle;
			
--			print("AddVector "..tostring(addVector))
--			print("Difference "..tostring((addVector - self.scene.endPoint.position)))
--			print("Original "..tostring(self.scene.endPoint.position))
			
			if (done == true) then
				self.scene = nil
				self.counter = nil
				self.xDone = nil
				self.yDone = nil
				self.zDone = nil
				self.xCompare = nil
				self.yCompare = nil
				self.zCompare = nil
			end;
			
		end;	
		
		return {
			origin = addVector,
			angles = addAngle,
			fov = fov
		};
	end;
end;