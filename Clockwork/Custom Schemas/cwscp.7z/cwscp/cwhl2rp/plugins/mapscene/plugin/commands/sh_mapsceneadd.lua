--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	https://creativecommons.org/licenses/by-nc-nd/3.0/legalcode
--]]

local COMMAND = Clockwork.command:New("MapSceneAdd");
COMMAND.tip = "Add a map scene at your current position, then add an end point to transition to.";
COMMAND.text = "<Number Speed> <Should Be Still>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.optionalArguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)	
	local data = {};
	
	if !player.endScene then

		if arguments[1]	then
			local number = tonumber(arguments[1])
			if (number) then
			
				data.speed = number or 0.2;
				
			else
			
				Clockwork.player:Notify(player, "That is not a number!");			
				return				
				
			end;
			
		end;	
		
		if !arguments[2] then
			player.endScene = {};
			player.speed = data.speed
			player.endScene.position = player:EyePos()
			player.endScene.angle = player:EyeAngles()
			Clockwork.player:Notify(player, "Now add the endpoint!");
		else
			data.position = player:EyePos()
			data.angle = player:EyeAngles()
			cwMapScene.storedList[#cwMapScene.storedList + 1] = data;
			cwMapScene:SaveMapScenes();
			for k, v in pairs(player.GetAll()) do
				cwMapScene:PlayerSendDataStreamInfo(v)
			end;
			Clockwork.player:Notify(player, "You have added a map scene.");
		end;
		
	else
		data.position = player.endScene.position;
		data.angle = player.endScene.angle;
		data.speed = player.endScene.speed;
		data.endPoint = {}
		data.endPoint.position = player:EyePos()
		data.endPoint.angle = player:EyeAngles()
		player.endScene = nil;
		
		Clockwork.player:Notify(player, "You have added a map scene.");
		
		cwMapScene.storedList[#cwMapScene.storedList + 1] = data;
		cwMapScene:SaveMapScenes();
		for k, v in pairs(player.GetAll()) do
			cwMapScene:PlayerSendDataStreamInfo(v)
		end;
		
	end;
	
end;

COMMAND:Register();