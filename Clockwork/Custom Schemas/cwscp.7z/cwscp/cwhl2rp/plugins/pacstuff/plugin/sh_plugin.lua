--[[
	Plugin by Otto The Pup
--]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_hooks.lua");