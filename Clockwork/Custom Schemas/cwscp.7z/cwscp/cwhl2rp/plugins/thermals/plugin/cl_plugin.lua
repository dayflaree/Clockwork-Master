local PLUGIN = PLUGIN;

PLUGIN.shinyMaterial = Material("models/shiny");