--[[
		Created by Polis - June 2014.
		Do not re-distribute as your own.  The .ini file of this plugin is protected!
]]

local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("cl_plugin.lua");