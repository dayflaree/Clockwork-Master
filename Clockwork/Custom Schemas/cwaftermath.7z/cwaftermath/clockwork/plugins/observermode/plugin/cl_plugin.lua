local Clockwork = Clockwork;

Clockwork.config:AddToSystem("Observer Reset", "observer_reset", "Whether or not observer mode resets the player's position to where they were originally.", true);
