
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

Clockwork.flag:Add("P", "PAC", "Access to use PAC.");

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");