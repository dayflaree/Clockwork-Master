
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:PrePACEditorOpen(player)
	if (!Clockwork.player:HasFlags(player, "P")) then
		return false;
	end
end