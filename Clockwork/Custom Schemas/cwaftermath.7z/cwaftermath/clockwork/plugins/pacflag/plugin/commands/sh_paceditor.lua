
local COMMAND = Clockwork.command:New("PACEditor");
COMMAND.tip = "Opens the PAC editor.";
COMMAND.access = "P";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	player:ConCommand("pac_editor");
end;



COMMAND:Register();