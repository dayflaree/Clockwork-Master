
local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

function PLUGIN:PrePACConfigApply(player)
	if (!Clockwork.player:HasFlags(player, "P")) then
		return false;
	end;
end;

-- Called when a player's character has loaded.
function PLUGIN:PlayerCharacterLoaded(player)
	if (pac) then
		player:ConCommand("pac_clear_parts");
	end;
end;