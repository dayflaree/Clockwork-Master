
local COMMAND = Clockwork.command:New("WearPAC");
COMMAND.tip = "Wears your PAC creation.";
COMMAND.access = "P";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	player:ConCommand("pac_wear_parts");
end;

COMMAND:Register();