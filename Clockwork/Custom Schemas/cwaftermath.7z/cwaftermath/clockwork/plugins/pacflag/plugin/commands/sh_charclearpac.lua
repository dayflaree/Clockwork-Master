
local COMMAND = Clockwork.command:New("CharClearPAC");
COMMAND.tip = "Clears someone's PAC.";
COMMAND.text = "<string Name>";
COMMAND.access = "o";
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	if (target) then
		target:ConCommand("pac_clear_parts");
		if (target != player) then
			Clockwork.player:Notify(player, "You have cleared "..target:Name().."'s PAC.");
			Clockwork.player:Notify(target, player:Name().." has cleared your PAC.");
		else
			Clockwork.player:Notify(player, "You ahve cleared your PAC.");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player.");
	end;
end;



COMMAND:Register()