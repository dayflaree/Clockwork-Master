
local COMMAND = Clockwork.command:New("ClearPAC");
COMMAND.tip = "Clears your current PAC.";
COMMAND.access = "P";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	player:ConCommand("pac_clear_parts");
	Clockwork.player:Notify(player, "You have cleared your PAC.");
end;

COMMAND:Register();