Clockwork.kernel:IncludePrefixed("sv_plugin.lua");


--[[
	This fix will stop the toolgun from making sounds and playing effects while invisible.
	Remove it if you'd like, but it ruins immersion.
--]]

function PLUGIN:ClockworkInitPostEntity()
	local SWEP = weapons.GetStored("gmod_tool");
	SWEP.ClockworkDoShootEffect = SWEP.ClockworkDoShootEffect or SWEP.DoShootEffect;

	function SWEP:DoShootEffect(hitpos, hitnormal, entity, physbone, bFirstTimePredicted)
		if (self:GetOwner():GetNoDraw()) then
			return false;
		end;

		self.ClockworkDoShootEffect(self, hitpos, hitnormal, entity, physbone, bFirstTimePredicted);
	end;

	weapons.Register(SWEP, "gmod_tool");
end;