local PLUGIN = PLUGIN;

function PLUGIN:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:String("tempFlags");
end;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");

function PLUGIN:HasPermanentFlag(player, flag)
	local flags = "";

	if (CLIENT) then
		flags = Clockwork.Client:GetSharedVar("Flags");
	else
		flags = self:GetFlags();
	end;

	if (string.find(flags, flag)) then
		return true;
	end;
end;

function PLUGIN:HasTempFlag(player, flag)
	local playerFlags = {};

	if (CLIENT) then
		playerFlags = PLUGIN:GetClientTempFlags();
	else
		playerFlags = player:GetCharacterData("tempFlags", {});
	end;

	local bHasFlag = false;

	if (type(playerFlags) == "table") then
		for k, v in pairs (playerFlags) do
			if (k == flag) then
				bHasFlag = true;
				break;
			end;
		end;
	end;

	return bHasFlag;
end;

if (CLIENT) then

	function PLUGIN:GetClientTempFlags()
		if Clockwork.Client:GetSharedVar("tempFlags") then
			return util.JSONToTable(Clockwork.Client:GetSharedVar("tempFlags"));
		else
			return {};
		end;
	end;

	function PLUGIN:PlayerDoesHaveFlag(player, flag)
		if (self:HasTempFlag(player, flag)) then
			return true;
		end;
	end;

end;