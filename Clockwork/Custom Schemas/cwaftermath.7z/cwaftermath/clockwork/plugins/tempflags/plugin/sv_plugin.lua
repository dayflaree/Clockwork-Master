local PLUGIN = PLUGIN;

local playerMeta = FindMetaTable("Player");

function playerMeta:GetTempFlags()
	return self:GetCharacterData("tempFlags") or false;
end;

function playerMeta:GetTempFlagsInfo()
	local playerFlags = self:GetTempFlags();
	if !playerFlags then return false; end;
	local flagData = {}
	for k, v in pairs (playerFlags) do
		if type(v) != "number" then return; end;
		local timeLeft = v - os.time();
		local timeUnit = "minutes";
		if timeLeft < 60 then
			timeUnit = "seconds";
		else
			timeLeft = math.Round(((v - os.time()) / 60), 2);
		end;
		table.insert(flagData, "'"..k.."' Flag - Expires in "..timeLeft.." "..timeUnit..".");
	end;
	return flagData;
end;

function playerMeta:GiveTempFlags(flags, duration, giver, bSilent)
	local playerFlags = self:GetCharacterData("tempFlags") or {}
	for i = 1, #flags do
		local flag = string.sub(flags, i, i);
		Clockwork.plugin:Call("PlayerFlagsGiven", self, flag);
		playerFlags[flag] = os.time() + duration;
	end;
	self:SetCharacterData("tempFlags", playerFlags);
	if bSilent then return; end;
	if IsValid(giver) then
		Clockwork.player:NotifyAll(self:Name().." was given '"..flags.."' flags for "..(duration / 60).." minutes by "..giver:GetName()..".");
	else
		Clockwork.player:NotifyAll(self:Name().." was given '"..flags.."' flags for "..(duration / 60).." minutes by an unknown admin.");
	end;
end;

function playerMeta:TakeTempFlags(flags, taker, bSilent)
	local playerFlags = self:GetCharacterData("tempFlags") or {}
	for i = 1, #flags do
		local flag = string.sub(flags, i, i);
		for k, v in pairs (playerFlags) do
			if k == flag then
				playerFlags[k] = nil;
			end;
			if !Clockwork.player:HasFlags(self, flag) then
				Clockwork.plugin:Call("PlayerFlagsTaken", self, flag);
			end;
		end;
	end;
	if table.Count(playerFlags) != 0 then
		self:SetCharacterData("tempFlags", playerFlags);
	else
		self:SetCharacterData("tempFlags", nil);
	end;
	if bSilent then return; end;
	if IsValid(taker) then
		Clockwork.player:NotifyAll(self:Name().."'s temporary '"..flags.."' flags were revoked by "..taker:GetName()..".")
	else
		Clockwork.player:NotifyAll(self:Name().."'s temporary '"..flags.."' flags were revoked by an unknown admin.")
	end;
end;

-- A shortcut to Clockwork.player:Notify(player, text, class)
function playerMeta:Notify(text, class)
	Clockwork.player:Notify(self, text, class)
end

function PLUGIN:PlayerDoesHaveFlag(player, flag)
	if (self:HasTempFlag(player, flag)) then
		return true;
	end;
end;

function PLUGIN:PlayerThink(player, curTime, infoTable)
	local playerFlags = player:GetCharacterData("tempFlags") or {};
	player:SetSharedVar("tempFlags", util.TableToJSON(playerFlags));
	local expiredFlags = nil;
	for k, v in pairs (playerFlags) do
		if tonumber(v) then
			if v < os.time() then
				expiredFlags = (expiredFlags or "")..k;
			end;
		end;
	end;
	if expiredFlags then
		player:Notify("The following flags have expired: '"..expiredFlags.."'.")
		Clockwork.hint:Send(player, "The following flags have expired: '"..expiredFlags.."'.", 4, Color(255, 0, 0, 255))
		player:TakeTempFlags(expiredFlags, nil, true);
	end;
end;