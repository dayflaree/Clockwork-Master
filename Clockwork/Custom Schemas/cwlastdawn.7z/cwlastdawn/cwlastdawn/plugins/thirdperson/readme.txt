Be warned, players can use this to peak around corners.
Also, note that I will be releasing an update in the future with third person customization and limitations.
These customizations will be accessible under the settings tab with a new drop down menu catagory.