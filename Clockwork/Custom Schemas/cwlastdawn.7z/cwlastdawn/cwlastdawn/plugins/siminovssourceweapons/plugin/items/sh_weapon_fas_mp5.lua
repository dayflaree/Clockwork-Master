--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 650;
	ITEM.name = "MP5 SMG";
	ITEM.model = "models/weapons/b_mp5.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_mp5"
	ITEM.weight = 2;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_mp5";
	ITEM.description = "A Compact, light SMG capable of raipdfire at and short-range accuracy.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);
	ITEM.value = 0.0;
Clockwork.item:Register(ITEM);