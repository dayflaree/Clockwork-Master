--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 1550;
	ITEM.name = "M249 Machine-Gun";
	ITEM.model = "models/weapons/b_m249.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_m249"
	ITEM.weight = 7;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_m249";
	ITEM.description = "A Heavy Machine-gun that has a high rate of fire and a large magazine.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);

Clockwork.item:Register(ITEM);