--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 1500;
	ITEM.name = "G36c";
	ITEM.model = "models/weapons/b_g36.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_g36c"
	ITEM.weight = 4;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_g36c";
	ITEM.description = "A military-grade high-class Assault rifle. Uses G36 Mag..";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);
	--ITEM.attachmentOffsetVector = Vector(-5.96, 10.95, 50.97);

Clockwork.item:Register(ITEM);