--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 750;
	ITEM.name = "Mac11";
	ITEM.model = "models/weapons/b_mac11.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_mac11"
	ITEM.weight = 2;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_mac11";
	ITEM.description = "A Compact SMG with rapidfire, which lacks accuracy.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);

Clockwork.item:Register(ITEM);