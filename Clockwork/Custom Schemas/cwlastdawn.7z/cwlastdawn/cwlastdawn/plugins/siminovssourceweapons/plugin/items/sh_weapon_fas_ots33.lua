--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 750;
	ITEM.name = "OTS-33";
	ITEM.model = "models/weapons/b_ots33.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_ots33"
	ITEM.weight = 1;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_ots33";
	ITEM.description = "A Small pistol similar to the Glock, but more accurate and a better grip.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
	ITEM.value = 0.3;
Clockwork.item:Register(ITEM);