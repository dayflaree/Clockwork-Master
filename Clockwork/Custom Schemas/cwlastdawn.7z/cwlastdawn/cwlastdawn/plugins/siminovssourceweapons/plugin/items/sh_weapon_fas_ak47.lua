--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 1100;
	ITEM.name = "AK-47";
	ITEM.model = "models/weapons/b_ak47.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_ak47"
	ITEM.weight = 3;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_ak47";
	ITEM.description = "A high-powered AK-47, very powerful, a common assault rifle. Uses 7.62mm Short ammo.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);
	ITEM.value = 0.0;
Clockwork.item:Register(ITEM);