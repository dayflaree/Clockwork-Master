--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 550;
	ITEM.name = "Deagle";
	ITEM.model = "models/weapons/b_deserteagle.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_deagle"
	ITEM.weight = 2;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_deagle";
	ITEM.description = "A Shiny Solid Silver Desert Eagle. Heavy and Shiny.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);

Clockwork.item:Register(ITEM);
