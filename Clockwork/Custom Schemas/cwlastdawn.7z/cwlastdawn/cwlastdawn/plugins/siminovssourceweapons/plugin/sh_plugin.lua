local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sh_schema.lua");