--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 750;
	ITEM.name = "R870 hunting Shotgun";
	ITEM.model = "models/weapons/b_870.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_r870"
	ITEM.weight = 4;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_r870";
	ITEM.description = "A Hunting Shotgun with a Heavy Barrel and a pump-action firing Mechanism.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);
	ITEM.value = 0.0;
Clockwork.item:Register(ITEM);