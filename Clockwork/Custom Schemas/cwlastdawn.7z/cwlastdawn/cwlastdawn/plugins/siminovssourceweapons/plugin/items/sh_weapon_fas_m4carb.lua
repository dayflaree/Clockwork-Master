--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 1150;
	ITEM.name = "M4 AR Carbine";
	ITEM.model = "models/weapons/b_m4.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_m4carb"
	ITEM.weight = 3;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_m4carb";
	ITEM.description = "A Carbine version of the Military-grade standard Assault-rifle.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);

Clockwork.item:Register(ITEM);