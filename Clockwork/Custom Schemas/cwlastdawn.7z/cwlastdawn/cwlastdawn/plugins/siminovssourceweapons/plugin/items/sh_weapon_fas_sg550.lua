--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 950;
	ITEM.name = "SG550 AR";
	ITEM.model = "models/weapons/b_sg550.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_sg550"
	ITEM.weight = 4;
	ITEM.access = "W";
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_sg550";
	ITEM.description = "A Solid Assault Rifle with Semi-auto or Full-auto capabilities.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);

Clockwork.item:Register(ITEM);