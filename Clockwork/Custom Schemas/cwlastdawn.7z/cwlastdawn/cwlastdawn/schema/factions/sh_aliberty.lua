--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Columbus State Army");
	FACTION.useFullName = true;
	FACTION.whitelist = true;
	FACTION.material = "cidertwo/factions/columbus";
	FACTION.models = {
		female = {
			"models/models/army/female_01.mdl",
			"models/models/army/female_02.mdl",
			"models/models/army/female_03.mdl",
			"models/models/army/female_04.mdl",
			"models/models/army/female_05.mdl",
			"models/models/army/female_06.mdl",
			"models/models/army/female_07.mdl"
		},
		male = {
			"models/rusty/natguard/male_01.mdl",
			"models/rusty/natguard/male_01_nc.mdl",
			"models/rusty/natguard/male_01_oc.mdl",
			"models/rusty/natguard/male_02.mdl",
			"models/rusty/natguard/male_02_oc.mdl",
			"models/rusty/natguard/male_02_nc.mdl",
			"models/rusty/natguard/male_03.mdl",
			"models/rusty/natguard/male_03_oc.mdl",
			"models/rusty/natguard/male_03_nc.mdl",
			"models/rusty/natguard/male_04.mdl",
			"models/rusty/natguard/male_04_oc.mdl",
			"models/rusty/natguard/male_04_nc.mdl",
			"models/rusty/natguard/male_05.mdl",
			"models/rusty/natguard/male_05_oc.mdl",
			"models/rusty/natguard/male_05_nc.mdl",
			"models/rusty/natguard/male_06.mdl",
			"models/rusty/natguard/male_06_oc.mdl",
			"models/rusty/natguard/male_06_nc.mdl",
			"models/rusty/natguard/male_07.mdl",
			"models/rusty/natguard/male_07_oc.mdl",
			"models/rusty/natguard/male_07_nc.mdl",
			"models/rusty/natguard/male_08.mdl",
			"models/rusty/natguard/male_08_oc.mdl",
			"models/rusty/natguard/male_08_nc.mdl",
			"models/rusty/natguard/male_09.mdl",
			"models/rusty/natguard/male_09_oc.mdl",
			"models/rusty/natguard/male_09_nc.mdl"
		};
	};
FACTION_ALIBERTY = FACTION:Register();