--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Texas Diplomat");
CLASS.wages = 75;
CLASS.color = Color(211, 151, 23, 255);
CLASS.limit = 5;
CLASS.classes = {"Texas Civilian"};
CLASS.description = "The guy that keeps the diplomatic relation fine";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a clean, brown suit with a tie";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group06");
end;
CLASS_TDIPLOMAT = CLASS:Register();