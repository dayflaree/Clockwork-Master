--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Columbus State Army");
	CLASS.wages = 150;
	CLASS.color = Color(5, 25, 170, 255);
	CLASS.factions = {FACTION_ALIBERTY};
	CLASS.description = "A regular military rookie of the city.";
	CLASS.defaultPhysDesc = "Wearing military sheets and uniform";
CLASS_CARMY = CLASS:Register();