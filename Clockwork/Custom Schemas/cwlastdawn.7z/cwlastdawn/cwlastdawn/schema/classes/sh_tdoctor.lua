--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Texas Doctor");
CLASS.wages = 50;
CLASS.color = Color(211, 151, 23, 255);
CLASS.limit = 16;
CLASS.classes = {"Texas Civilian"};
CLASS.description = "Supplies the civilians with medical attention if needed, also state soldiers.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a doctor uniform";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group07");
end;
CLASS_TDOCTOR = CLASS:Register();