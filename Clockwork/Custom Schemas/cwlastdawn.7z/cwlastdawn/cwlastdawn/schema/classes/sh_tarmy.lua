--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Texas Republic Army");
	CLASS.wages = 150;
	CLASS.color = Color(211, 151, 23, 255);
	CLASS.factions = {FACTION_AREPUBLIC};
	CLASS.description = "A regular military rookie of the city.";
	CLASS.defaultPhysDesc = "Wearing military sheets and uniform";
CLASS_TARMY = CLASS:Register();