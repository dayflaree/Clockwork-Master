--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Allied State Military");
	CLASS.wages = 150;
	CLASS.color = Color(198, 12, 16, 255);
	CLASS.factions = {FACTION_AALLIED};
	CLASS.description = "A regular military rookie of the city.";
	CLASS.defaultPhysDesc = "Wearing military sheets and uniform";
CLASS_AARMY = CLASS:Register();