--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Bandit");
CLASS.wages = 0;
CLASS.color = Color(150, 125, 100, 255);
CLASS.limit = 8;
CLASS.classes = {"Survivor"};
CLASS.description = "A Bandit that is living by stealing and murdering survivors and state soldiers.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a ragged and dirty bandit cloaks";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group08");
end;
CLASS_SECRETARY = CLASS:Register();