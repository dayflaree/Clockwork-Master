--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Texas Republic Militia");
	CLASS.wages = 35;
	CLASS.limit = 10;
	CLASS.color = Color(211, 151, 23, 255);
	CLASS.classes = {"Texas Civilian"};
	CLASS.description = "An armed militia unit, fighting for the freedom of their land.\nThey are not working with any state and are a threat to them.";
	CLASS.headsetGroup = 1;
	CLASS.defaultPhysDesc = "Wearing a guerilla suit, with some weapons on their shoulders.";

-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group04");
end;
CLASS_TMILITIA = CLASS:Register();