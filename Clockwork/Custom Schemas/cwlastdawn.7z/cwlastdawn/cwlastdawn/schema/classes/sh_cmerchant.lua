--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Columbus Liberty Merchant");
	CLASS.wages = 50;
	CLASS.limit = 16;
	CLASS.color = Color(5, 25, 170, 255);
	CLASS.classes = {"Columbus Civilian"};
	CLASS.description = "An state merchant.\nThey have alot of general needs for the civilians and soldiers";
	CLASS.defaultPhysDesc = "Wearing dirty and ragged clothes";
	
-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group7");
end;
CLASS_CMERCHANT = CLASS:Register();