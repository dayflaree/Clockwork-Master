--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Columbus Civilian");
	CLASS.wages = 15;
	CLASS.color = Color(5, 25, 170, 255);
	CLASS.factions = {FACTION_LIBERTY};
	CLASS.isDefault = true;
	CLASS.description = "A regular survived inhabitant of the city.";
	CLASS.defaultPhysDesc = "Wearing dirty and ragged clothes";
CLASS_CCIVILIAN = CLASS:Register();