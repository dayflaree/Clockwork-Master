--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Survivor");
	CLASS.wages = 0;
	CLASS.color = Color(150, 125, 100, 255);
	CLASS.factions = {FACTION_SURVIVOR};
	CLASS.isDefault = true;
	CLASS.description = "A regular survived inhabitant of the city.";
	CLASS.defaultPhysDesc = "Wearing dirty and ragged clothes";
CLASS_SURVIVOR = CLASS:Register();