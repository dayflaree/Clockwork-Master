--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Ravenwood");
CLASS.wages = 25;
CLASS.limit = 10;
CLASS.ammo = {pistol = 64};
CLASS.color = Color(150, 125, 100, 255);
CLASS.weapons = {"weapon_glock"};
CLASS.classes = {"Survivor"};
CLASS.model = {"models/pmc/pmc_4/pmc__07.mdl"};
CLASS.description = "A hard working Ravenwood mercenary. They are hired by the three states to do their dirty work.";
CLASS.headsetGroup = 1;
CLASS.defaultPhysDesc = "Wearing a armoured military suit";

CLASS_RAVENWOOD = CLASS:Register();