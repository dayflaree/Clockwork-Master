--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Allied Civilian");
	CLASS.wages = 10;
	CLASS.color = Color(198, 12, 16, 255);
	CLASS.factions = {FACTION_ALLIED};
	CLASS.isDefault = true;
	CLASS.description = "A regular survived inhabitant of the city.";
	CLASS.defaultPhysDesc = "Wearing dirty and ragged clothes";
CLASS_ACIVILIAN = CLASS:Register();