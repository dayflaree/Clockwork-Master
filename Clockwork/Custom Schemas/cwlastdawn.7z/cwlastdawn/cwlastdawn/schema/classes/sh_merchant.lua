--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Merchant");
	CLASS.wages = 25;
	CLASS.limit = 16;
	CLASS.color = Color(150, 125, 100, 255);
	CLASS.classes = {"Survivor"};
	CLASS.description = "An underground merchant.\nThey have alot of dangerous wares for the civilians.";
	CLASS.defaultPhysDesc = "Wearing dirty and ragged clothes";
	
-- Called when the model for the class is needed for a player.
function CLASS:GetModel(player, defaultModel)
	return string.gsub(defaultModel, "group%d%d", "group7");
end;
CLASS_MERCHANT = CLASS:Register();