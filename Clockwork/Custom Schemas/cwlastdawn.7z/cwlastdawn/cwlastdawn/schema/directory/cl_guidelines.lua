<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice.org 3.4.1  (Win32)">
	<META NAME="CREATED" CONTENT="0;0">
	<META NAME="CHANGED" CONTENT="20131111;21403046">
</HEAD>
<BODY LANG="en-US" DIR="LTR">
<P>Clockwork.directory:AddCategoryPage( &quot;Guidelines&quot;,
&quot;Cider Two&quot;, [[ 
</P>
<P><I>These are just guidelines, there is not a full rules list
because there would be too many to list. Use these guidelines and
your <B>common sense</B> and you should be able to play the game
without suffering from a very long ban, death or kick. </I>
</P>
<P><B>1.</B> Do not say anything unnecessary, stupid or irrelavant in
OOC. 
</P>
<P><B>2.</B> Type properly and use correct grammar at all times to
keep it professional and realistic. 
</P>
<P><B>3.</B> If somebody breaks a rule,it doesn't take seven of you
to tell them, if one person tells them to go and read the guidelines,
you do not need to back them up. 
</P>
<P><B>4.</B> It is not your duty to become a vigilante, if somebody
tries to prop-kill you or something similiar, you should disconnect
and report it to an administrator. Trying to kill them yourself will
only result in you being banned. Counter-Breaking the rules will
result in a ban. 
</P>
<P><B>5.</B> Do not kill another character from a state or a survivor
without a good reason. If you are being shot at you may shoot back.</P>
<P><B>6.</B> When your character is killed, you must follow the 'new
life rule', that being you forget twenty four hours prior to your
death. 
</P>
<P><B>7.</B> Never take revenge on somebody that killed you, or
randomly killed you, report them instead. 
</P>
<P><B>8.</B> If you want to contact one person directly, do not use
OOC (out of character), use the personal message command instead /pm
*player*. 
</P>
<P><B>9.</B> Do not powergame, this means you cannot force an action
that other characters <I>must</I> abide by. The person may
counter-attack you with other actions if you force actions upon them
(/me). If the person has no chance to fight back your /me's, then you
are breaking the Powergame rule. Shooting someone in the head like a
hitman, from behind, giving him the knowledge of your intentions is
not considered powergame. The person may then turn around and kill
the attacker immediately without using any /me's.</P>
<P><B>8.</B> The roll command will NOT be used for acts (/me's) if
the person tries to shoot you with legitimate /me's, then you must
either run, or kill him.</P>
<P><B>9.</B> If a character performs a valid action such as disarming
your character and it is genuinly impossible for your character to do
some matrix-move to prevent them, you must abide by it. It is only a
weapon after all and survival is much more important in this
environment.</P>
<P><B>10.</B> If for example you are about to execute a character and
that character's friend shoots you from a distance without being in
range to perform an action then that player has broken the S2M rule.
You must S2M from long ranges, and will be permitted to S2K from
close ranges. If the person is unaware of your presence, you must S2M
to start with, then give the opportunity to the person to run, or be
noted of your actions.</P>
<P><B>11.</B> Do not attempt to kill another character by using
props. If you do you will be possibly banned, and loose your flags.
We do have logs and it will result in a permanent ban. 
</P>
<P><B>12.</B> Your physical description must be in full English.
Valid examples are displayed in green, and invalid examples are
displayed in red. See below for the examples. <BR><BR><FONT COLOR="#008000"><I>A
black man with a beanie hat on. <BR>A sixteen year old white female
with brown hair. <BR></I></FONT><FONT COLOR="#ff0000"><I>Black|Male|BeanieHat.
<BR>16|White|Female|BrownHair. </I></FONT>
</P>
<P><B>13.</B> You need to roleplay fear. Fear is a basic human
emotion, if you are outnumbered and are being threatened to give up a
posession, your character should (as almost any human would) show
fear and give in to their demands. Unless you have a valid reason not
to. Soldiers trained in the harshest terrain, as elite soldiers in
states may not show Fear to everything. The higher rank, the harder
it is to intimidate them.</P>
<P><B>14.</B> Have respect for the staff, they are here to make sure
your playing experience is fun and enjoyable. We understand that
sometimes our staff's judgement can be wrong, and if you believe that
is so then please report it on the forums. If you do report an action
made by our staff, be sure not to disrespect them in doing so.
Everyone does a mistake, at least once a day, be aware of that.</P>
<P><B>15.</B> The advertisement command must be used seriously, and
not for out-of-character purposes. It must be used as if a person has
read a sign, or a notice informing them of something.</P>
<P><B>Example: /advert The Texas state border is now shut, nobody may
enter it without illegaly trespassing. Further notice in 1 hour.</B></P>
<P><B>16.</B> Laws are chosen by the states themselves, if weapons
are illegal or not, that is up to the state to decide. If a
gunlicense is required, that's the state to decide. Questioning a
state may result in your execition, being arrested, or even shut down
for good.</P>
<P><B>17.</B> If you have joined a state and sell weapons to the
state, you may never sell weapons to other states or people without
permission. If you do so, you will be considered corrupt, and a
reason for PK if caught. However, you may not scam by changing prices
etc, scamming in this situation will result in the same thing. This
means you will loose your job and rank. 
</P>
<P><B>18.</B> Do not kill another character out of the blue unless
you have a <I>very</I> good reason for doing so. When you kill
someone you will expect a random personal conversation with the staff
for you to explain, in detail why you took their life. If we do not
find the reason valid, you could face anything up to a permanant ban.
</P>
<P><B>19.</B> If you do kill someone for a very good reason, you
should try not to do so in public. If you do kill someone in public
or kill any members of the state, you should expect to be killed, and
asked why you did it. 
</P>
<P><B>20.</B> Do not do anything stupid or things that you wouldn't
dare to do in real-life. You are not a super-hero, and neither is
your character. If the staff tells you that you wouldn't do that in
real-life, you accept it and do not do it, you do not reply back to
them arguing that you would, doing so is just childish and annoying.</P>
<P><B>21.</B> As a State soldier, you are given a temporary weapon
and some ammo. Do not abuse this, you should only shoot at a
character if they are shooting you or threatening your life.
Exception to this is if you are given a direct order by a leading
officer. If you do not follow this rule, you will most certainly be
PK for not following orders, demoted and possibly banned. Always get
a reason to open fire / kill, in this situation &ndash; getting
orders. 
</P>
<P><B>22.</B> Using voice chat for anything other than in-character
talking, e.g: using it for out-of-character discussion or streaming
music or whatever is not allowed. /Me's etc has to be written.</P>
<P><B>23.</B> Members of the State (Military and such) are allowed to
randomly search any apartment or building at any time. Whining about
it is no good, they are allowed to do it as long as their laws state
so. 
</P>
<P><B>24.</B> If you are the Military and you ask someone to do as
you say and they refuse to do as you say, you will be permitted to
arrest or use any necessary force to stop the person. Including
killing him / her.</P>
<P><B>25.</B> The secretaries and the president have big powers. <SPAN STYLE="font-style: normal">The
secretaries job is to take calls and make appointments for the
president, not to be his or her personal bodyguard. </SPAN>
</P>
<P STYLE="font-style: normal"><B>26.</B> If you state that somebody
is trying to kill you 'randomly' in OOC, or that somebody has killed
you, nobody will listen. It is not intelligent, and is very ignorant,
to assume that something is random just because you are not aware of
the reason. When somebody is killed, the admins will privately
investigate the killing and you do not need to get involved. Rather
PM the admins if you feel the kill is breaking any rules.</P>
<P STYLE="font-style: normal"><B>27.</B> The president cannot change
the guidelines, ever. To do so requires big talk with the High ranked
officers. For example a president cannot make a certain item legal,
if the guidelines state that it is illegal. It must be discussed with
the rest of the people in power. The president may release people if
he wishes to, but this might dramaticly cause drama within the Army,
and loosing power and control of the army = your doom. The army have
huge powers, and if the president doesn't do as the Army wishes, he
or her may be taken out of power, or even killed. Loyalty to the
Military is 1<SUP>st</SUP> priority, they are your main defences.</P>
<P STYLE="font-style: normal"><B>29.</B> The Military can fine
characters for commiting crimes instead of arresting them, if they
wish, but if they can't pay it then you must arrest them. This is up
to individuals to decide. There are borders, if you enter them
illegaly, you might be killed or arrested. It is up to individual
States to decide wether they want border controls, paid border
controls, or nothing at all.</P>
<P STYLE="font-style: normal"><B>30.</B> Military Soldiers that are
not doing their jobs, like blatently ignoring a criminal in the
street, will be PK and demoted / blacklisted. There is a difference
between letting sombody slide, and blatently ignoring the crime all
together and not doing anything about it. Once again, corruptness. If
it is seen, it will be punished by a Military Court run by the top
ranks. These people will decide your faith, live, imprisonment or
death.</P>
<P STYLE="font-style: normal"><B>31.</B> Grafiting will be either
illegal or legal, depending on the state. Grafiting on military
property will be seen upon as destruction of military property, and
will result in arrest / death depending on state law.</P>
<P STYLE="font-style: normal"><B>32.</B> The president has the power
to change laws, turn his country into a dictatorship, a democracy
(dangerous in this case), republic or whatever he wants to. Creating
too many negative effects and laws might result in uprising, military
coups, or assasination of the President himself.</P>
<P STYLE="font-style: normal"><B>33.</B> If you are the police, and a
character is commiting an offence but you are physically unable to
reach them. Whether it be due to lack of an attribute that requires
you to get there, or the character has blocked themselves somewhere,
you are allowed to shoot them in the leg. 
</P>
<P STYLE="font-style: normal"><B>34.</B> If you are a Military
Soldier, and you have managed to get a character to stand still and
have begun the detainment process, you are allowed to fire upon them
if they try to flee from you. You are allowed to  use lethal force if
commanded by an officer. If you can shoot him without depends on
state laws. 
</P>
<P STYLE="font-style: normal"><B>35.</B> As the Military, you should
always try to capture the individual where possible (unless commanded
otherwise); and only use the sidearm as a last resort. Your number
one priority should be to attempt to detain the suspect at all costs
as long as you are not ordered to kill him otherwise, do not to have
them killed. 
</P>
<P STYLE="font-style: normal"><B>35.</B> If you are caught using a
class to buy items for yourself, you will receive a hefty ban. You
are allowed to buy a shipment and keep some of it, with the intent to
sell the rest on. If you are Blackmarket, Merchant, Caterer, Hustler
or Dispenser, you must own a business or a store (depending on the
legality of the class). 
</P>
<P STYLE="font-style: normal"><B>36.</B> As a soldier, you cannot
change clothing and go undercover without the president's or armies
permission. You can do it of course, but not legally. Doing so
blatently in public without the president's or armies permission
would be idiotic and stupid. The individual state will be able to
decide wether this is required. If not, you will be punished by
Military Court for violating military laws.</P>
<P STYLE="font-style: normal"><B>37.</B> Modifying your vehicles
using ToolTrust is okay, but not to the extent where you're being
really stupid with it. For example, placing saw blades and harpoons
on your car is just rediculous. 
</P>
<P STYLE="font-style: normal"><B>38.</B> Have fun, be nice, and
respect everybody. Gameplay will be a lot more fun if you do ;)</P>
</BODY>
</HTML>