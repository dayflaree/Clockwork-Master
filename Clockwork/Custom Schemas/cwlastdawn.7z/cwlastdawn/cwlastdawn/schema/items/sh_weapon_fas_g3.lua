--	� 2012 CloudSixteen.com do not share, re-distribute or modify
--	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 850;
	ITEM.name = "G3A1";
	ITEM.model = "models/weapons/b_g3a3.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_g3"
	ITEM.weight = 3;
	ITEM.business = true;
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.weaponClass = "weapon_fas_g3";
	ITEM.description = "A solid Assault rifle, single-shots, accurate. Uses G3A1 Mag.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);

ITEM:Register();