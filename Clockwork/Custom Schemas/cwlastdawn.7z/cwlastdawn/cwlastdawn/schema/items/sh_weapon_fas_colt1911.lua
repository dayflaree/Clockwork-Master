--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 750;
	ITEM.name = "Colt 1911";
	ITEM.value = 0.3;
	ITEM.model = "models/weapons/b_1911.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_colt1911"
	ITEM.weight = 1;
	ITEM.business = true;
	ITEM.weaponClass = "weapon_fas_colt1911";
	ITEM.classes = {CLASS_MERCHANT, CLASS_AMERCHANT, CLASS_TMERCHANT, CLASS_CMERCHANT};
	ITEM.description = "A Colt Pistol, excellent design and an all-round great handgun.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
	ITEM.value = 0.2;
ITEM:Register();