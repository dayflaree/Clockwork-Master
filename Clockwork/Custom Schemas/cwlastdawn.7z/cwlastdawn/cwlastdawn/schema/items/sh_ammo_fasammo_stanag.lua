--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 71;
	ITEM.value = 0.3;
	ITEM.name = "STANAG Magazine";
	ITEM.batch = 1;
	ITEM.model = "models/items/stanagmag.mdl";
	ITEM.weight = 0.8;
	ITEM.business = true;
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.uniqueID = "ammo_fasammo_stanag";
	ITEM.ammoClass = "fivefivesix";
	ITEM.ammoAmount = 30;
	ITEM.description = "A magazine Assorted Rifles.";
	ITEM.value = 0.3;
ITEM:Register();