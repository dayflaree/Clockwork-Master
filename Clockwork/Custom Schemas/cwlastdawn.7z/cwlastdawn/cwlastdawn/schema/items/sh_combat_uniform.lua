--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.cost = 80;
	ITEM.value = 0.6;
	ITEM.name = "Combat Gear";
	ITEM.group = "group03";
	ITEM.weight = 0.5;
	ITEM.uniqueID = "combat_uniform";
	ITEM.classes = {CLASS_MERCHANT, CLASS_AMERCHANT, CLASS_TMERCHANT, CLASS_CMERCHANT};
	ITEM.business = true;
	ITEM.description = "Combat gear uniform with a yellow insignia.";
ITEM:Register();