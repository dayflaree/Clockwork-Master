--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 350;
	ITEM.name = "Dv2 Combat Knife";
	ITEM.model = "models/weapons/b_dv2.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_dv2"
	ITEM.weight = 1;
	ITEM.business = true;
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.category = "Melee";
	ITEM.weaponClass = "weapon_fas_dv2";
	ITEM.description = "A Combat knife.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(285, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-7, -2, -8);
	ITEM.value = 0.0;
ITEM:Register();