--[[
	? 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Grenade";
	ITEM.cost = 750;
	ITEM.model = "models/weapons/b_m67.mdl";
	ITEM.weight = 0.8;
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_frag";
	ITEM.category = "Grenades";
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.business = true;
	ITEM.description = "A Frag Grenade, pull and throw.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);

ITEM:Register();