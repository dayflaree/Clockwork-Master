--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.cost = 1350;
	ITEM.name = "MC51 Vollmer";
	ITEM.value = 0.2;
	ITEM.model = "models/weapons/b_mc51.mdl";
	ITEM.batch = 1;
	ITEM.uniqueID = "weapon_fas_vollmer"
	ITEM.weight = 4;
	ITEM.business = true;
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.weaponClass = "weapon_fas_vollmer";
	ITEM.description = "A modified MP5 that has a machine-gun mag, capable of long firerates with additional power.";
	ITEM.isAttachment = true;
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.weaponCopiesItem = true;
	ITEM.attachmentOffsetAngles = Angle(0, 0, 275);
	ITEM.attachmentOffsetVector = Vector(-1.31, 3.80, 10.00);

ITEM:Register();