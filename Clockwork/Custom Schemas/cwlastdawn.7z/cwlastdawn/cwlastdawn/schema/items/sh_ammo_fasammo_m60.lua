--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.cost = 71;
	ITEM.value = 0.3;
	ITEM.name = "M60 Rounds";
	ITEM.batch = 1;
	ITEM.model = "models/items/762box.mdl";
	ITEM.weight = 0.8;
	ITEM.business = true;
	ITEM.classes = {CLASS_MERCHANT};
	ITEM.uniqueID = "ammo_fasammo_m60";
	ITEM.ammoClass = "sevensixtwobyfiftyone";
	ITEM.ammoAmount = 100;
	ITEM.description = "Rounds for an M60 Machine-Gun";
	ITEM.value = 0.01;
ITEM:Register();