--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("clothes_base");
	ITEM.name = "Texas Republic Soldier Uniform 10";
	ITEM.weight = 2;
	ITEM.runSound = {
	"npc/combine_soldier/gear1.wav",
	"npc/combine_soldier/gear2.wav",
	"npc/combine_soldier/gear3.wav",
	"npc/combine_soldier/gear4.wav",
	"npc/combine_soldier/gear5.wav",
	"npc/combine_soldier/gear6.wav"
};
	ITEM.iconModel = "models/pmc/pmc_2/pmc__10.mdl";
	ITEM.description = "A Tactical Texas Republic Uniform";
	ITEM.model = "models/props_c17/SuitCase_Passenger_Physics.mdl";
	ITEM.replacement = "models/pmc/pmc_2/pmc__10.mdl";
	ITEM.cost = 1;
	ITEM.business = false;
ITEM:Register();