--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when the Clockwork shared variables are added.
function Clockwork.kernel:ClockworkAddSharedVars(globalVars, playerVars)
	globalVars:Number("noWagesTime");
	globalVars:Number("lottery");
	globalVars:String("agenda");
	playerVars:Bool("beingChloro", true);
	playerVars:Bool("skullMask");
	playerVars:Bool("beingTied", true);
	playerVars:String("alliance", true);
	playerVars:Entity("disguise");
	playerVars:Number("clothes", true);
	playerVars:Bool("lottery", false);
	playerVars:Bool("sensor", true);
	playerVars:Bool("dead", false);
	playerVars:Number("hunger", true);
	playerVars:Number("thirst", true);
	playerVars:Bool("leader", true);
	playerVars:Number("tied", true);
end;