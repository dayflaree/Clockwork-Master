--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Medical Stimulant";
ITEM.cost = 15;
ITEM.model = "models/items/personalmedkit/personalmedkit.mdl";
ITEM.weight = 0.5;
ITEM.access = "X";
ITEM.useText = "Use";
ITEM.factions = {};
ITEM.category = "Medical"
ITEM.business = true;
ITEM.useSound = "items/medshot4.wav";
ITEM.description = "Single-shot application of magical medical goodness.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( 100 );
	
	Clockwork.plugin:Call("PlayerHealed", player, player, self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();