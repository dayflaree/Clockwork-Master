--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New(); -- Derives from the ammo_base item in Clockwork.
	ITEM.name = "U-Fix-It Kit"; -- What is the name of this item?
	ITEM.cost = 150; -- How much does this item cost?
	ITEM.model = "models/Items/item_item_crate.mdl"; -- What is the model of this item?
	ITEM.weight = 1; -- What is the weight of the item in KG.
	ITEM.access = "X"; -- What flags are required to purchase this item (remove the line to not require flags).
	ITEM.classes = {}; -- What classes can purchase this item (remove the line to not require a specific class).
	ITEM.uniqueID = "armor_package"; -- This needs to be unique (remove the line to have a unique ID generated).
	ITEM.category = "Utility"
	ITEM.business = true; -- Is this item available for purchase at all?
	ITEM.description = "Useful for patching gaping holes in armor after you've been mauled to near-death by something 3 times the size of your platoon."; -- A short description of the item.
	
	
function ITEM:OnUse(player, itemEntity)
	if(Clockwork.player:HasFlags(player, "K"))then
		player:SetArmor(200)
	else
		player:SetArmor(100)
	end
end;


function ITEM:OnDrop(player, position) end;

ITEM:Register();