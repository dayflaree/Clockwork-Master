--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New(); -- Derives from the ammo_base item in Clockwork.
	ITEM.name = "Big Ammunition Package"; -- What is the name of this item?
	ITEM.cost = 500; -- How much does this item cost?
	ITEM.model = "models/items/itembox/itemboxlarge.mdl"; -- What is the model of this item?
	ITEM.weight = 1; -- What is the weight of the item in KG.
	ITEM.access = "X"; -- What flags are required to purchase this item (remove the line to not require flags).
	ITEM.classes = {}; -- What classes can purchase this item (remove the line to not require a specific class).
	ITEM.uniqueID = "ammo_package_big"; -- This needs to be unique (remove the line to have a unique ID generated).
	ITEM.category = "Ammunition"
	ITEM.business = true; -- Is this item available for purchase at all?
	--ITEM.ammoClass = "357"; -- What type of ammo does this item give us?
	--ITEM.ammoAmount = 21; -- How much ammo does this item give us?
	ITEM.description = "Contains various types of ammunition, loaded into magazines. But it's a lot bigger."; -- A short description of the item.
	
	
function ITEM:OnUse(player, itemEntity)
	player:GiveAmmo(2000, "smg1")
	player:GiveAmmo(2000, "ar2")
	player:GiveAmmo(500, "pistol")
	player:GiveAmmo(500, "357")
	player:GiveAmmo(150, "RPG_Round")
	player:GiveAmmo(800, "buckshot")
end;


function ITEM:OnDrop(player, position) end;

ITEM:Register();