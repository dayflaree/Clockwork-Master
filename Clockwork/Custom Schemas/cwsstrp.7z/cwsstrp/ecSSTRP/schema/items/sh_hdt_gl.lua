--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "HDT-03 40MM Grenade Launcher Turret";
ITEM.cost = 25000;
ITEM.batch = 1;
ITEM.model = "models/turret/gl_turret.mdl";
ITEM.weight = 8;
ITEM.access = "X";
ITEM.useText = "Deploy";
ITEM.factions = {FACTION_ENG};
ITEM.category = "Emplacements"
ITEM.business = true;
ITEM.useSound = "items/ammocrate_open.wav";
ITEM.description = "A heavy defensive turret.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	local pos = player:GetShootPos()
	local ang = player:GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos+(ang*100)
	tracedata.filter = player
	local trace = util.TraceLine(tracedata)
	local hitpos = trace.HitPos +Vector(0,0,10)
	local turretAng=player:EyeAngles()
	local turretNewAng=Angle(0,turretAng.y+-90,turretAng.r)
	
	local PlaceAng=turretNewAng
	local turretReal=ents.Create("turret_grenade")
		turretReal:SetPos(hitpos+Vector(0,0,10))
		turretReal:SetAngles(PlaceAng)
		turretReal:Spawn()
	--player:SetHealth( 100 );
	
	--Clockwork.plugin:Call("PlayerHealed", player, player, self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();