--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Health Kit";
ITEM.cost = 30;
ITEM.model = "models/items/healthkit.mdl";
ITEM.weight = 1;
--ITEM.access = "v";
ITEM.useText = "Apply";
ITEM.factions = {FACTION_MED};
ITEM.category = "Medical"
ITEM.business = true;
ITEM.useSound = "items/medshot4.wav";
ITEM.blacklist = {};
ITEM.description = "A white packet filled with medication.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if(!itemEntity)then
		player:SetHealth( math.Clamp( player:Health() + Schema:GetHealAmount(player, 2), 0, player:GetMaxHealth() ) );
	else
	local ragdolls = {};
	local entities = ents.FindInSphere(itemEntity:GetPos(), 30);

	for k, v in pairs(entities) do
		local class = v:GetClass();
	
		if (IsValid(v) and class == "prop_ragdoll" and (v:GetNetworkedEntity("Player") != nil)) then
			table.insert(ragdolls, v);
		end;
	end;

	if (#ragdolls > 1) then
		Clockwork.player:Notify(player, "**F.A.K. - MULTIPLE BODIES, ERROR!");
		--player:ChatPrint("** bzzt, found mulitply bodies! Not enough power to support.");
		return false;
	elseif (#ragdolls <= 0) then
		Clockwork.player:Notify(player, "**F.A.K. - NO BODY, ERROR!");
		--player:ChatPrint("** bzzt, found no body!");
		return false;
	else
		for k, v in pairs(ragdolls) do
			local ragPlayer = v:GetNetworkedEntity("Player");
			local position = v:GetPos();
			
			ragPlayer:Spawn();
			ragPlayer:SetPos(position);
			Clockwork.player:Notify(player, "**F.A.K. - STIMULANTS PACKAGE DELIVERED, COMBAT MEDICAL WOUND HEALED!");
			Clockwork.player:Notify(ragPlayer, "You've been brought back in the fight by: " .. player:Name() .. ".");
			v:Remove();
		end;
	end;
	end
	Clockwork.plugin:Call("PlayerHealed", player, player, self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();