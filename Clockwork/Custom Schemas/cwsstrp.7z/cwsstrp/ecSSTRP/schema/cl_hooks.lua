--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

if (CLIENT) then
	usermessage.Hook("nx_plsound", function(um)
		local sound = um:ReadString();
		
		surface.PlaySound(sound);
	end);
	
	usermessage.Hook("nx_stopsnd", function(um)
		RunConsoleCommand("stopsound");
	end);
end;

-- Called when the cinematic intro info is needed.
function Schema:GetCinematicIntroInfo()
	return {
		credits = "Designed and developed by "..self:GetAuthor()..".",
		title = "",
		text = ""
	};
end;


function Schema:GetPlayerScoreboardOptions(player, options, menu)
	if (Clockwork.command:FindByID("CharPermaKill")) then
		if (Clockwork.player:HasFlags(Clockwork.Client, Clockwork.command:FindByID("CharPermaKill").access)) then
			options["Perma-Kill"] = function()
				RunConsoleCommand( "aura", "CharPermaKill", player:Name() );
			end;
		end;
	end;
end;