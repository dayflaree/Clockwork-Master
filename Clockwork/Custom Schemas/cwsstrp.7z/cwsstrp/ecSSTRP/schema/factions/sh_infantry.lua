--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local FACTION = Clockwork.faction:New("Mobile Infantry");
FACTION.useFullName = true;
FACTION.whitelist = true;
FACTION.material = "halfliferp/factions/mobinfi";
FACTION.models = {
	female = {
	"models/senscith/sst/mi/fmi_01.mdl",
	"models/senscith/sst/mi/fmi_02.mdl",
	"models/senscith/sst/mi/fmi_04.mdl",
	"models/senscith/sst/mi/fmi_06.mdl"
	},
	male = {
	"models/senscith/sst/mi/mi_01.mdl",
	"models/senscith/sst/mi/mi_02.mdl",
	"models/senscith/sst/mi/mi_03.mdl",
	"models/senscith/sst/mi/mi_04.mdl",
	"models/senscith/sst/mi/mi_05.mdl",
	"models/senscith/sst/mi/mi_06.mdl",
	"models/senscith/sst/mi/mi_07.mdl",
	"models/senscith/sst/mi/mi_08.mdl",
	"models/senscith/sst/mi/mi_09.mdl"
	},
};


-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
--[[
	if (faction.name == FACTION_MPF) then
		Clockwork.player:SetName(player, string.gsub(player:QueryCharacter("name"), ".+(%d%d%d%d%d)", "OTA-ECHO.OWS-%1"), true);
	else
		Clockwork.player:SetName(player, self:GetName( player, player:GetCharacter() ), true);
	end;
	
	if (player:QueryCharacter("gender") == GENDER_MALE) then
		player:SetCharacterData("model", self.models.male[1], true);
	else
		player:SetCharacterData("model", self.models.female[1], true);
	end;
	]]--
end;

FACTION_MI = FACTION:Register();