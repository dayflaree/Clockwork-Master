--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[ This is where you might add any functions for your schema. --]]
function Schema:PrintConsole(text)
	MsgC(text, Color(255, 0, 0, 255));
end;

Clockwork.datastream:Hook("cwFrequency", function(data)
	Derma_StringRequest("Frequency", "What would you like to set the frequency to?", data, function(text)
		Clockwork.kernel:RunCommand("SetFreq", text);
		
		if (!Clockwork.menu:GetOpen()) then
			gui.EnableScreenClicker(false);
		end;
	end);
	
	if (!Clockwork.menu:GetOpen()) then
		gui.EnableScreenClicker(true);
	end;
end);

Clockwork.chatBox:RegisterClass("officer", "ic", function(info)
	Clockwork.chatBox:Add(info.listeners, nil, Color(0, 119, 255, 255), info.text);
end);