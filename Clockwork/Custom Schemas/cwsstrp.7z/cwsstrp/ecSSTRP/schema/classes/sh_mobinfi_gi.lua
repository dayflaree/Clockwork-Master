--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Mobile Infantry");
	CLASS.color = Color(0, 101, 255, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_MI};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "Infantry of the Federation.";
	CLASS.defaultPhysDesc = "Clean fatigues, ready for combat.";
CLASS_MI = CLASS:Register();