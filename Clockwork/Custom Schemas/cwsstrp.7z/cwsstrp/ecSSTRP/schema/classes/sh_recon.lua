--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Mobile Infantry Reconnaissance Detachment");
	CLASS.color = Color(220, 0, 255, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_HOMO};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "Keeping an eye out.";
	CLASS.defaultPhysDesc = "Keeping an eye out for your comrades.";
CLASS_RECON = CLASS:Register();