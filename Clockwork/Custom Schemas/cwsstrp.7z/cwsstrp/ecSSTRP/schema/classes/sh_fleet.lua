--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Federal Fleet");
	CLASS.color = Color(150, 50, 50, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_FLEET};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "These people do the flyin'.";
	CLASS.defaultPhysDesc = "Clean fatigues, ready for flight.";
CLASS_FLEET = CLASS:Register();