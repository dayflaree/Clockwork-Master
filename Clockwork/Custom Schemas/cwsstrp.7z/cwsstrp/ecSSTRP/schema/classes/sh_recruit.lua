--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Recruit");
	CLASS.color = Color(150, 125, 100, 255);
	CLASS.factions = {FACTION_RECRUIT};
	CLASS.isDefault = true;
	CLASS.wagesName = "Credits";
	CLASS.description = "Do you want to live forever?";
	CLASS.defaultPhysDesc = "Ready and willing.";
CLASS_RECRUIT = CLASS:Register();