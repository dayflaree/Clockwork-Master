--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Mobile Infantry Engineering Division");
	CLASS.color = Color(255, 106, 0, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_ENG};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "Engineers of the Federation.";
	CLASS.defaultPhysDesc = "Gonna fix you up!";
CLASS_ENG = CLASS:Register();