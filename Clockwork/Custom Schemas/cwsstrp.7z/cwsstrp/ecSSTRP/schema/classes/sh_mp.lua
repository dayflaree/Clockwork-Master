--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Military Police");
	CLASS.color = Color(0, 188, 198, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_MP};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "Taking out the trash.";
	CLASS.defaultPhysDesc = "Working to make a better tomorrow. Kind of an asshole.";
CLASS_MP = CLASS:Register();