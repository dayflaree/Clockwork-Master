--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Mobile Infantry Medics");
	CLASS.color = Color(198, 0, 0, 255);
	CLASS.wages = 100;
	CLASS.factions = {FACTION_MED};
	CLASS.wagesName = "Requisition Points";
	CLASS.description = "Medics of the Federation.";
	CLASS.defaultPhysDesc = "Gonna patch you up!";
CLASS_MED = CLASS:Register();