--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]


local COMMAND = Clockwork.command:New("playsound");
COMMAND.tip = "Play a sound on all players.";
COMMAND.text = "<sound>";
COMMAND.access = "a";
COMMAND.arguments = 1;

function COMMAND:OnRun(player, arguments)
	local sound = arguments[1];
	
	for _, v in pairs(_player.GetAll()) do
		umsg.Start("nx_plsound", v);
			umsg.String(sound);
		umsg.End();
	end;
end;

COMMAND:Register();