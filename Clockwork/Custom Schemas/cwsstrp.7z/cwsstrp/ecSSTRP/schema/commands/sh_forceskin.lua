--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("forceskin");
COMMAND.tip = "Change a player's skin for the Mobile Infantry models.";
COMMAND.text = "<string Name> <skin ID>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] )
	local skin = tonumber( arguments[2] );
	local forceSkin = player:GetCharacterData("forceSkin")
	local forcedSkin = player:GetCharacterData("forcedSkin")
	
	if (target) then
		if !(skin == forcedSkin) then
			if(skin != 0)then
				target:SetCharacterData("forceSkin", true)
				target:SetCharacterData("forcedSkin", skin)
				Clockwork.player:Notify(target, "Your skin was changed to " .. skin .. ".")
				Clockwork.player:Notify(player, target:Name() .. "'s skin was changed to " .. skin .. ".")
			else
				target:SetCharacterData("forceSkin", false)
				target:SetCharacterData("forcedSkin", 0)
				Clockwork.player:Notify(target, "Your skin was disabled.")
				Clockwork.player:Notify(player, target:Name() .. "'s skin disabled.")
			end
		end
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

COMMAND:Register();