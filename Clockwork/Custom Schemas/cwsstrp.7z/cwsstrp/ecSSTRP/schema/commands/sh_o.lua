--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("o");
COMMAND.tip = "Send a message to other officers.";
COMMAND.text = "<string Text>";
COMMAND.access = "!"
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER);
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
		local listeners = {};
		local text = table.concat(arguments, " ")
		local players = _player.GetAll();
		--local OfcFlag = Clockwork.player:HasFlags(player, "!")
		
		
		
		for k, v in ipairs(players) do
			if(v:HasInitialized() and v:Alive() and !v:IsRagdolled(RAGDOLL_FALLENOVER)) then
				if(Clockwork.player:HasFlags(v, "!"))then
					listeners[v] = v;
				end
			end
		end
		if (table.Count(listeners) > 0) then
			Clockwork.chatBox:Add(listeners, player, "officer", player:Name() .. " radios in to officers \"" .. text ..  "\"");
			--Clockwork.chatBox:AddInRadius(player, "ic", "radios in to officers \"" .. info.text "\".", player:GetPos(), Clockwork.config:Get("talk_radius"):Get(), info.data)
			--Clockwork.chatBox:Add(players, nil, Color(0, 119, 255, 255), info.name .. " radios in to officers \"" .. info.text "\"." );
		end;
end;
COMMAND:Register();