--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("Helmet");
COMMAND.tip = "Toggles whether your helmet is on or off.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local headgear = tonumber(player:GetCharacterData("headgear"))
	if(headgear == 0)then
		player:SetCharacterData("headgear", 1)
	end
	if(headgear == 1)then
		player:SetBodygroup(1,1)
		Clockwork.player:Notify(player, "You've put your helmet on. Safety is #1.");
		player:SetCharacterData("headgear", 2)
	elseif(headgear == 2)then
		player:SetBodygroup(1,0)
		Clockwork.player:Notify(player, "You've taken your helmet off. Hope you're not at risk of losing your head.");
		player:SetCharacterData("headgear", 1)
	elseif(headgear == 3)then
		player:SetBodygroup(1,1)
		Clockwork.player:Notify(player, "You've put your helmet on. Safety is #1.");
		player:SetCharacterData("headgear", 2)
	end
	
	--[[ OLD CODE
	if(tonumber(arguments[1]) <4) and (tonumber(arguments[1]) > -1)then
		print(type(arguments[1]))		
		print(player:GetBodygroup(1))
		Clockwork.player:Notify(player, "Headwear value set to: " .. arguments[1] .. ".");
		player:SetCharacterData("headgear", arguments[1]);
		player:SetBodyGroups( 1, tonumber(headgear) -1)
	end
	]]--
end;

COMMAND:Register();