--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]


local COMMAND = Clockwork.command:New("stopsound");
COMMAND.tip = "Stop sound on all players.";
COMMAND.access = "a";

function COMMAND:OnRun(player, arguments)
	for _, v in pairs(_player.GetAll()) do
		umsg.Start("nx_stopsnd", v);
		umsg.End();
	end;
end;

COMMAND:Register();