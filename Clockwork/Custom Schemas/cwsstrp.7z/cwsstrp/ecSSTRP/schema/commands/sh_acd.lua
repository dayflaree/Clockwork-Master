--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("acd");
COMMAND.tip = "Accept death and respawn.";

function COMMAND:OnRun(player)
	if (!player:Alive()) then
		player:Spawn();
	end;
end;

COMMAND:Register();