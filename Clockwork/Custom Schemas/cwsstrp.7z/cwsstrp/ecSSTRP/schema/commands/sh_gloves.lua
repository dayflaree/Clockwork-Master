--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("gloves");
COMMAND.tip = "Toggles whether your gloves are on or off.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local gloves = tonumber(player:GetCharacterData("gloves"))
	if(gloves == nil)then
		player:SetCharacterData("gloves", 0)
	end
	if(gloves == 0)then
		player:SetBodygroup(3,1)
		Clockwork.player:Notify(player, "You've put your gloves on.");
		player:SetCharacterData("gloves", 1)
	elseif(gloves == 1)then
		player:SetBodygroup(3,0)
		Clockwork.player:Notify(player, "You've taken your gloves off.");
		player:SetCharacterData("gloves", 0)
	end
	
	
end;

COMMAND:Register();