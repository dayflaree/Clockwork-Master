--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

resource.AddFile("materials/halfliferp/factions/mobinfi.vmt")
resource.AddFile("materials/halfliferp/factions/fleet.vmt")
resource.AddFile("materials/halfliferp/factions/recruit.vmt")
resource.AddFile("materials/halfliferp/factions/mp.vmt")
resource.AddFile("materials/halfliferp/factions/engi.vmt")
resource.AddFile("materials/halfliferp/factions/medics.vmt")
resource.AddFile("materials/halfliferp/factions/homo_recon_homo.vmt")

resource.AddFile("models/bloocobalt/w40k/vehicles/ig_valkyrie.mdl")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/mtl_valkyrie_missile_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/sentinel_multilaser_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valk_int_front_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valk_int_roof_floor_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valk_int_sidepanel_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_blue.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_cadian.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_desert.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_inq.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_med.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_mutlicam.vmt")
resource.AddFile("materials/models/bloocobalt/w40k/vehicles/ig_valkyrie/valkyrie_dif_winter.vmt")
resource.AddFile("models/tiberium/weapons/v_autorifle.mdl")
resource.AddFile("models/tiberium/weapons/w_autorifle.mdl")
resource.AddFile("materials/models/tiberium/autorifle/AutomaticRifle_Diffuse.vmt")
resource.AddFile("materials/models/tiberium/autorifle/sight.vmt")
resource.AddFile("materials/models/tiberium/nod/nod_soldier_body_d.vmt")
resource.AddFile("sound/weapons/autorifle2.wav")
resource.AddFile("models/renx/weapons/pistol/w_pistol.mdl")
resource.AddFile("models/renx/weapons/pistol/v_pistol.mdl")
resource.AddFile("materials/models/renx/pistol/Pistol_D.vmt")
resource.AddFile("sound/newsstrp/tmp-11.wav")
resource.AddFile("sound/sstrp/intro.mp3")
resource.AddFile("models/renx/weapons/gl/v_gl.mdl")
resource.AddFile("models/renx/weapons/gl/w_gl.mdl")
resource.AddFile("materials/models/renx/gl/Gren_D.vmt")
resource.AddFile("materials/models/renx/gl/Gren_N.vtf")
resource.AddFile("materials/models/renx/gl/Gren_S.vtf")
resource.AddFile("models/renx/weapons/lasgun/v_lasgun.mdl")
resource.AddFile("models/renx/weapons/lasgun/w_lasgun.mdl")
resource.AddFile("materials/models/renx/lasgun/LaserRifle_D.vmt")
-- Called when a player's default model is needed.
function Schema:GetPlayerDefaultModel(player)
	--return "models/police.mdl";
end;

function Schema:OnNPCKilled(npc, player, weapon)
	local npcValueTable = {
	{"npc_combine_s", 350},
	{"npc_antlion", 100},
	{"npc_antlionguard", 500},
	{"npc_headcrab", 50}
	}
	local globalBonus = Clockwork.config:Get("merc_wage_event_bonus"):Get()
	local personalBonus = player:GetNWFloat("r_total") + 1
	local npcClass = npc:GetClass()
	for k, v in pairs(npcValueTable)do
		if(npcClass == v[1])then
				local reward = tonumber(v[2])
				reward = math.random(reward*0.75, reward*1.25)
				reward = reward*tonumber(globalBonus)*tonumber(personalBonus)
				Clockwork.player:GiveCash(player, reward, "Killing an enemy of the Federation. ( " .. v[1] .. " ).")
			end
		end
	end

function Schema:EntityHandleMenuOption(player, entity, option, arguments)
if (entity:GetClass() == "cw_radio") then
		if (option == "Set Frequency" and type(arguments) == "string") then
			if (string.find(arguments, "^%d%d%d%.%d$")) then
				local start, finish, decimal = string.match(arguments, "(%d)%d(%d)%.(%d)");
				
				start = tonumber(start);
				finish = tonumber(finish);
				decimal = tonumber(decimal);
				
				if (start == 1 and finish > 0 and finish < 10 and decimal > 0 and decimal < 10) then
					entity:SetFrequency(arguments);
					
					Clockwork.player:Notify(player, "You have set this stationary radio's arguments to "..arguments..".");
				else
					Clockwork.player:Notify(player, "The radio arguments must be between 101.1 and 199.9!");
				end;
			else
				Clockwork.player:Notify(player, "The radio arguments must look like xxx.x!");
			end
		end
	end;
end;

function Schema:SetupPlayerVisibility(player)
end;

function Schema:PlayerAdjustDropWeaponInfo(player, info)
end;

function Schema:GetPlayerDefaultInventory(player, character, inventory)
Clockwork.inventory:AddInstance( inventory, Clockwork.item:CreateInstance("handheld_radio")	);
	if(player:GetFaction() == "Medical Support Division")then
		Clockwork.inventory:AddInstance( inventory, Clockwork.item:CreateInstance("health_kit")	);
	end
	
end;

function Schema:PlayerGiveWeapons(player)
	local donationFlags = {};
	donationFlags["d"] = "federation_bz-70";
	donationFlags["f"] = "federation_dlt19";
	donationFlags["g"] = "federation_mag021";
	donationFlags["h"] = "federation_hmg";
	donationFlags["i"] = "federation_mp15s";
	donationFlags["j"] = "federation_br2";
	donationFlags["k"] = "federation_p33";
	donationFlags["l"] = "federation_pp2000";
	donationFlags["m"] = "federation_thor";
	donationFlags["u"] = "federation_saat1";
	donationFlags["v"] = "federation_900k";
	donationFlags["w"] = "federation_as12";
	donationFlags["x"] = "federation_arc3";
	donationFlags["y"] = "federation_type19";
	donationFlags["T"] = "federation_kvk";
	donationFlags["A"] = "weapon_mad_rpg";
	donationFlags["F"] = "weapon_mad_grenade";
	donationFlags["M"] = "heal_gun";
	donationFlags["O"] = "federation_type19s";
	for k, v in pairs(donationFlags) do
		if(Clockwork.player:HasFlags(player, k))then
			player:Give(v)
			Clockwork.player:Notify(player, "[DONATION] Weapon ... " .. v .. " granted.")
		end
	end
	
	
end;

function Schema:PlayerCanRadio(player, text, listeners, eavesdroppers)
	if (player:HasItemByID("handheld_radio"))then
		if (!player:GetCharacterData("frequency")) then
			Clockwork.player:Notify(player, "Set the frequency, you big dummy!");
			return false;
		end;
	else
		Clockwork.player:Notify(player, "You do not own a radio!");
		
		return false;
	end;
end;



function Schema:ChatBoxMessageAdded(info)
	if (info.class == "radio") then
		local talkRadius = Clockwork.config:Get("talk_radius"):Get();
		local listeners = {};
		local players = _player.GetAll();

		
		--if (IsValid(data.entity) ) then
			for k, v in ipairs(players) do
				if (v:HasInitialized() and v:Alive() and !v:IsRagdolled(RAGDOLL_FALLENOVER)) then
					if (( v:GetCharacterData("frequency") == frequency and v:HasItemByID("handheld_radio") ) or info.speaker == v) then
						listeners[v] = v;
					end;
				end;
			end;
			
			if (table.Count(listeners) > 0) then
				
			end;
			
			
			--table.Merge(info.listeners, listeners);
		--end;
	end;
	
		
end;

function Schema:PlayerAdjustRadioInfo(player, info)
	for k, v in ipairs( _player.GetAll() ) do
		if (v:HasInitialized() and v:HasItemByID("handheld_radio")) then
			if (v:GetCharacterData("frequency") == player:GetCharacterData("frequency")) then
				--if (v:GetSharedVar("tied") == 0) then
					info.listeners[v] = v;
					--Clockwork.chatBox:Add(listeners, info.speaker, "radio", info.text);
				--end;
			end;
		end;
	end;
end;

-- Called when a player attempts to switch to a character.
function Schema:PlayerCanSwitchCharacter(player, character)
	if (player:GetCharacterData("permakilled")) then
		return true;
	end;
end;

-- Called when a player's death info should be adjusted.
function Schema:PlayerAdjustDeathInfo(player, info)
	if (player:GetCharacterData("permakilled")) then
		info.spawnTime = 0;
	end;
end;

-- Called when a player's character screen info should be adjusted.
function Schema:PlayerAdjustCharacterScreenInfo(player, character, info)
	if (character.data["permakilled"]) then
		info.details = "This character is permanently killed.";
	end;
end;

-- Called when a player attempts to delete a character.
function Schema:PlayerCanDeleteCharacter(player, character)
	if (character.data["permakilled"]) then
		return true;
	end;
end;

-- Called when a player attempts to use a character.
function Schema:PlayerCanUseCharacter(player, character)
	if (character.data["permakilled"]) then
		return character.name.." is permanently killed and cannot be used!";
	
	end;
end;

function Schema:GetHealAmount(player, scale)
	local medical = Clockwork.attributes:Fraction(player, ATB_MEDICAL, 35);
	local healAmount = (15 + medical) * (scale or 1);
	
	return healAmount;
end;


-- Called when a player's character has loaded.
function Schema:PlayerCharacterLoaded(player)
	player:SetSharedVar("permaKilled", false);
end;

function Schema:PostPlayerSpawn(player, lightSpawn, changeClass, firstSpawn)
	local forceSkin = false
	local skinNum = 0
	if(player:GetCharacterData("forcedSkin") == nil)then
			forceSkin = player:GetCharacterData("forceSkin")
			skinNum = tonumber(player:GetCharacterData("forcedSkin"))
			player:SetCharacterData("forceSkin", false)
		else
			forceSkin = player:GetCharacterData("forceSkin")
			skinNum = tonumber(player:GetCharacterData("forcedSkin"))
	end
	if(player:GetCharacterData("headgear") != nil)then
		local headgear = player:GetCharacterData("headgear")
		
		if(headgear != 0)then
			player:SetBodygroup(1, headgear -1)
			if(headgear == 1)then
				Clockwork.player:Notify(player, "No headgear equipped.")
			elseif(headgear == 2)then
				Clockwork.player:Notify(player, "Helmet equipped.")
			elseif(headgear == 3)then
				Clockwork.player:Notify(player, "Beret equipped.")
			end
			--Clockwork.player:Notify(player, "Headgear equipped... " .. headgear .. ".")
		end
		--[[if(headgear != 0) and (player:GetModel() == "models/senscith/sst/mi/fmi_01.mdl")then
			if(headgear == 1)then
					player:SetBodygroup(1, 0)
				elseif(headgear == 2)then
					player:SetBodygroup(1, 2)
				elseif(headgear == 3)then
					player:SetBodygroup(1, 3)
			end
			Clockwork.player:Notify(player, "Headgear equipped... " .. headgear .. ".")
			
		end]]--
		else
			player:SetCharacterData("headgear", 0)
	end
	if(player:GetCharacterData("gloves") != nil)then
		local glovesOn = tonumber(player:GetCharacterData("gloves"))
		if(glovesOn == 1)then
			player:SetBodygroup(3,1)
			Clockwork.player:Notify(player, "Your gloves are on.")
		else
			player:SetBodygroup(3,0)
			Clockwork.player:Notify(player, "Your gloves are off.")
		end
		print(glovesOn)
	else
		player:SetCharacterData("gloves", 0)
	end
	
	if(player:GetFaction() != "Recruit")then
		local fac = player:GetFaction()
		-- MOBILE INFANTRY
		if(fac == "Mobile Infantry")then
			player:SetSkin(0)
			player:SetBodygroup(5,1)
			player:Give("federation_assault")
			--player:GiveAmmo("smg1", 500)
			player:SetArmor(100)
		end
		if(fac == "Military Police")then
			player:SetSkin(2)
			player:SetBodygroup(6,1)
			player:Give("federation_bz-70")
			player:Give("weapon_stunstick")
			player:SetArmor(100)
		end
		if(fac == "Federal Fleet")then
			player:SetSkin(3)
			player:SetBodygroup(5,0)
			player:Give("federation_bz-70")
		end
		if(fac == "Medical Support Division")then
			player:SetSkin(1)
			player:SetBodygroup(6,1)
			player:Give("federation_thor")
			player:Give("heal_gun")
			player:SetArmor(100)
		end
		if(fac == "Reconnaissance Detachment")then
			player:SetSkin(0)
			player:SetBodygroup(5,1)
			player:Give("federation_900k")
			player:SetArmor(100)
		end
		if(fac == "Engineering Division")then
			player:Give("federation_thor")
			player:Give("federation_mmgl")
			player:Give("heal_gun")
			player:SetSkin(0)
			player:SetBodygroup(5,1)
			player:SetArmor(100)
		end
		if(fac != "Military Police")then
			player:SetBodygroup(6,0)
		end
		player:Give("federation_pistol")
		--player:Give("federation_morita")
	end
	print(forceSkin)
	print(skinNum)
	if (forceSkin == true) then
		player:SetSkin(skinNum)
	end
	
	
	if(Clockwork.player:HasFlags(player, "R"))then
		player:SetHealth(200);
		Clockwork.player:Notify(player, "[DONATOR::HEALTH::GRANT]  to " .. player:Name() );
	end
	if(Clockwork.player:HasFlags(player, "K")) then
		player:SetArmor(200);
		Clockwork.player:Notify(player, "[DONATOR::ARMOR::GRANT]  to " .. player:Name() );
	end
	
end

function Schema:PlayerHealed(player, healer, itemTable)
	if (itemTable.uniqueID == "health_vial") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 2, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 15, true);
	elseif (itemTable.uniqueID == "health_kit") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 3, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 25, true);
	elseif (itemTable.uniqueID == "bandage") then
		healer:BoostAttribute(itemTable.name, ATB_DEXTERITY, 1, 120);
		healer:ProgressAttribute(ATB_MEDICAL, 5, true);
	end;
end;

concommand.Add("rp_toggleholster", function(player, command, arguments) 
										Clockwork.player:ToggleWeaponRaised(player)
									end)
