--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

ITEM = Clockwork.item:New("book_base");
ITEM.name = "A Blood Stained Journal";
ITEM.model = "models/props_lab/bindergraylabel01b.mdl";
ITEM.uniqueID = "book_absj";
ITEM.description = "A journal with blood all over it. it's nearly illegible.";
ITEM.bookInformation = [[
<font color='red' size='4'>Written by [A name covered in blood].</font>

For it was said, they had become like these peculiar demons which dwell in matter, but in whom no light may be found.
Iniquity snares our cunning, but by the light of lights; mine are greater still.
Woe to all, for our dwelling place is distant, and we wander through the domiciles of chaos!

Although they call me crazy, I care not, for thou art my helper, my strength, and my saviour.
Thy will be done oh light of lights, I bless the glory of thy greatness through the day and through the darkness of this night.
I pray do never turn away thy light, give heed to me, and spring thy traps upon mine enemies, when I cry out to thee!

Turn not thy face away from me; incline thy ear and hear me! When I shall cry to thee in my affliction.
For the days of my life have vanished like smoke, and my bones are parched like ash...
And let all my impurities be as... fuel for that fire! Until nothing remains, but the light alone.

For the dead know no sleep in their graves, nor dost thou remember them until they are destroyed through thy hands.
And what terrible wonders are these thou hast done among the dead, what shades rise to confess thee...
And what spectres shall know thee by thy name. Thy rages have come down upon thee, and thy pains have agitated me.
May their paths become dark and slippery, and may the angel of the Lord afflict them... And may the snare that they do not
know come to them, and may the net they have hidden for me catch them in my place. My power was lost in places which where not mine.

Affliction besought me, and the merciless ones attacked me without cause. From the voice of my groaning bones cleaved to my flesh, for
my soul is filled with evil, and like this place, must be purged. And all thy cares have come down upon me. And from this bed I cry out
for the kindling of thy Light! Oh, light may thy name be spoken in the graves, and spelled in bones and ashes. Judge those
who do injustice to me, fight with those who fight with me! Take hold of a weapon, a shield, a sword, and rise to help me!
Draw for the sword, and sheath it in those who afflict me, and say to my soul, I am thy salvation!

[The last few pages are completely unreadable].
]];

ITEM:Register();