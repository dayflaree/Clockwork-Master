Contaminant
========

A schema created by the following.

Credits:
Alex Grist
kurozael
RJ
HappyGoLucky