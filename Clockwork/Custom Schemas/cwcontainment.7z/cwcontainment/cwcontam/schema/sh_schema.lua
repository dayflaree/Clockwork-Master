--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("cl_theme.lua");
Clockwork.kernel:IncludePrefixed("sh_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");

Clockwork.option:SetKey("default_date", {month = 11, year = 2018, day = 24});
Clockwork.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});

Clockwork.option:SetKey("intro_image", "example/example");
Clockwork.option:SetKey("schema_logo", "example/example_logo");

Clockwork.option:SetKey("menu_music", "music/contam_theme.mp3");
Clockwork.option:SetKey("model_shipment", "models/props_junk/cardboard_box002a.mdl");
Clockwork.option:SetKey("name_cash", "Dollars");
Clockwork.option:SetKey("model_cash", "models/props_lab/box01a.mdl");

Clockwork.config:ShareKey("intro_text_big");
Clockwork.config:ShareKey("intro_text_small");

Clockwork.quiz:SetEnabled(true);
Clockwork.quiz:AddQuestion("Do you know how to use your grammatical skills?", 1, "Yes, I do know how.", "noplzhelpme_lern!");
Clockwork.quiz:AddQuestion("What is the current situation in the gamemode?", 1, "The world has been destroyed by a disease.", "Everyone is happy and life is good.");
Clockwork.quiz:AddQuestion("You do not need to have weapons or items to roleplay.", 1, "Understood", "Plz give me ak111!!!");
Clockwork.quiz:AddQuestion("You will not ask for administration rights.", 2, "Admunplz!", "Understood");
Clockwork.quiz:AddQuestion("If you do not understand what this gamemode is about, will you read the directory?", 2, "No, I don't care!", "Yes, I will read the directory.");

Clockwork.flag:Add("e", "Example Flag", "Access to an example flag.");