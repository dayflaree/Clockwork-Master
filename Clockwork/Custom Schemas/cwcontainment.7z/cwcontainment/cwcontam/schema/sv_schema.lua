--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

Clockwork.kernel:AddDirectory("materials/skeleton/");

Clockwork.config:Add("intro_text_big", "Example Big Text.", true);
Clockwork.config:Add("intro_text_small", "Example Little Text.", true);

function Clockwork.hint:AddHumanHint(name, text)
	Clockwork.hint:Add(name, text, function(player)

	end);
end;

Clockwork.hint:AddHumanHint("Life", "Your character is only human, refrain from jumping off high ledges.", false);
Clockwork.hint:AddHumanHint("Sleep", "Don't forget to sleep, your character does get tired.", false);
Clockwork.hint:AddHumanHint("Eating", "Just because you don't have to eat, it doesn't mean your character isn't hungry.", false);
Clockwork.hint:AddHumanHint("Friends", "Try to make some friends, misery loves company.", false);

Clockwork.hint:AddHumanHint("Curfew", "Curfew? Bored? Ask to be assigned a roommate.");
Clockwork.hint:AddHumanHint("Prison", "Don't do the crime if you're not prepared to do the time.");
Clockwork.hint:AddHumanHint("Rebels", "Don't chase the resistance, the Combine may group you together.");
Clockwork.hint:AddHumanHint("Talking", "The Combine don't like it when you talk, so whisper.");
Clockwork.hint:AddHumanHint("Rations", "Rations, they're bags filled with goodies. Behave.");
Clockwork.hint:AddHumanHint("Combine", "Don't mess with the Combine, they took over Earth in 7 hours.");
Clockwork.hint:AddHumanHint("Jumping", "Bunny hopping is uncivilized, and the Combine will remind you with their stunsticks.");
Clockwork.hint:AddHumanHint("Punching", "Got that feeling you just wanna punch somebody? Don't.");
Clockwork.hint:AddHumanHint("Compliance", "Obey the Combine, you'll be glad that you did.");
Clockwork.hint:AddHumanHint("Combine Raids", "When the Combine come knocking, get your ass on the floor.");
Clockwork.hint:AddHumanHint("Request Device", "Need to reach Civil Protection? Invest in a request device.");
Clockwork.hint:AddHumanHint("Civil Protection", "Civil Protection, protecting civilized society, not you.");

Clockwork.hint:Add("Admins", "The admins are here to help you, please respect them.");
Clockwork.hint:Add("Action", "Action. Stop looking for it, wait until it comes to you.");
Clockwork.hint:Add("Grammar", "Try to speak correctly in-character, and don't use emoticons.");
Clockwork.hint:Add("Running", "Got somewhere to go? Fancy a run? Well don't, it's uncivilized.");
Clockwork.hint:Add("Healing", "You can heal players by using the Give command in your inventory.");
Clockwork.hint:Add("F3 Hotkey", "Press F3 while looking at a character to use a zip tie.");
Clockwork.hint:Add("F4 Hotkey", "Press F3 while looking at a tied character to search them.");
Clockwork.hint:Add("Attributes", "Whoring *(name_attributes)* is a permanant ban, we don't recommend it.");
Clockwork.hint:Add("Firefights", "When engaged in a firefight, shoot to miss to make it enjoyable.");
Clockwork.hint:Add("Metagaming", "Metagaming is when you use OOC information in-character.");
Clockwork.hint:Add("Passive RP", "If you're bored and there's no action, try some passive roleplay.");
Clockwork.hint:Add("Development", "Develop your character, give them a story to tell.");
Clockwork.hint:Add("Powergaming", "Powergaming is when you force your actions on others.");

function Schema:PermaKillPlayer(player, ragdoll)
	if (player:Alive()) then
		player:Kill(); ragdoll = player:GetRagdollEntity();
	end;
	
	local inventory = player:GetInventory();
	local cash = player:GetCash();
	local info = {};
	
	if (!player:GetCharacterData("permakilled")) then
		info.inventory = inventory;
		info.cash = cash;
		
		if (!IsValid(ragdoll)) then
			info.entity = ents.Create("cw_belongings");
		end;
		
		Clockwork.plugin:Call("PlayerAdjustPermaKillInfo", player, info);
		
		for k, v in pairs(info.inventory) do
			local itemTable = Clockwork.item:FindByID(k);
			
			if (itemTable and itemTable.allowStorage == false) then
				info.inventory[k] = nil;
			end;
		end;
		
		player:SetCharacterData("permakilled", true);
		player:SetCharacterData("inventory", {}, true);
		player:SetCharacterData("cash", 0, true);
		
		if (!IsValid(ragdoll)) then
			if (table.Count(info.inventory) > 0 or info.cash > 0) then
				info.entity:SetData(info.inventory, info.cash);
				info.entity:SetPos( player:GetPos() + Vector(0, 0, 48) );
				info.entity:Spawn();
			else
				info.entity:Remove();
			end;
		else
			ragdoll.areBelongings = true;
			ragdoll.inventory = info.inventory;
			ragdoll.cash = info.cash;
		end;
		
		Clockwork.player:SaveCharacter(player);
	end;
end;