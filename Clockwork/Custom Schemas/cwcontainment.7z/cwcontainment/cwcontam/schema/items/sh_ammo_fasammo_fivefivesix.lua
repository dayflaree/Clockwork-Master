--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "5.56 Ammo";
	ITEM.batch = 1;
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_fasammo_fivefivesix";
	ITEM.ammoClass = "fivefivesix";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box of 5.56 ammo.";
Clockwork.item:Register(ITEM);