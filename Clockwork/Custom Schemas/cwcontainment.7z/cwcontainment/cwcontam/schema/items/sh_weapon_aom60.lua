--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Auto Ordnance M60";
	ITEM.model = "models/weapons/b_m60e3.mdl";
	ITEM.weight = 10;
	ITEM.uniqueID = "weapon_fas_aom60";
	ITEM.description = "An iconic and heavy American general purpose machine gun.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 90);
	ITEM.attachmentOffsetVector = Vector(-1, 4, 3);
ITEM:Register();






