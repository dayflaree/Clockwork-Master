--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "9mm Russian Ammo";
	ITEM.batch = 1;
	ITEM.model = "models/Items/BoxSRounds.mdl";
	ITEM.weight = 1;
	ITEM.uniqueID = "ammo_fasammo_ninemmrussian";
	ITEM.ammoClass = "ninemmrussian";
	ITEM.ammoAmount = 30;
	ITEM.description = "A box of 9mm Russian ammo.";
Clockwork.item:Register(ITEM);


