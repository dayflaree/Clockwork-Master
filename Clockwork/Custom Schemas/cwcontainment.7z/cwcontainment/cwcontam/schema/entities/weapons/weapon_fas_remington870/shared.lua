// Variables that are used on both client and server
if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5

	SWEP.HoldType			= "shotgun"

end
if ( CLIENT ) then
	SWEP.PrintName			= "Remington 870AE"	
	SWEP.SlotPos			= 3
	SWEP.IconLetter			= "m"
		
	SWEP.NameOfSWEP			= "weapon_fas_remington870" --always make this the name of the folder the SWEP is in.
	killicon.AddFont( SWEP.NameOfSWEP, "CSKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
end
local Walkspeed = CreateConVar ("sim_walk_speed", "250", {FCVAR_REPLICATED, FCVAR_ARCHIVE})
local Runspeed = CreateConVar ("sim_run_speed", "500", {FCVAR_REPLICATED, FCVAR_ARCHIVE})
local WeightMod	= CreateClientConVar("sim_weightmod_t", 1, true, false)		// Enable/Disable

SWEP.Instructions			= "Uses 12 Gauge Buckshot, Switch Weapons: E + Left Click"
SWEP.Base 				= "weapon_fas_sim_base_shot"

SWEP.HoldType				= "shotgun"
SWEP.ViewModelFlip		= false
SWEP.ViewModel			= "models/weapons/a_870.mdl"
SWEP.WorldModel			= "models/weapons/b_870.mdl"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.Primary.Sound 		= Sound("Weapof_Rem870.Shoot")
SWEP.Primary.Recoil		= 6
SWEP.Primary.Damage		= 5.0
SWEP.Primary.NumShots		= 20
SWEP.Primary.Cone			= 0.06
SWEP.Primary.Delay 		= 1

SWEP.Primary.ClipSize		= 6					// Size of a clip
SWEP.Primary.DefaultClip	= 0					// Default number of bullets in a clip
SWEP.Primary.Automatic		= false				// Automatic/Semi Auto
SWEP.Primary.Ammo			= "shotgunshell"
SWEP.ShellEffect			= ""	// "effect_mad_shell_pistol" or "effect_mad_shell_rifle" or "effect_mad_shell_shotgun"
SWEP.Secondary.ClipSize		= -1					// Size of a clip
SWEP.Secondary.DefaultClip	= -1					// Default number of bullets in a clip
SWEP.Secondary.Automatic	= false				// Automatic/Semi Auto
SWEP.Secondary.Ammo		= "none"

SWEP.IronSightsPos = Vector (-2.4875, -4, 1.5118)
SWEP.IronSightsAng = Vector (0.1861, 0.0258, 0)
SWEP.RunArmOffset  = Vector (4.0928, 0.4246, 2.3712)
SWEP.RunArmAngle   = Vector (-18.4406, 33.1846, 0)

SWEP.ShotgunReloading		= true
SWEP.ShotgunFinish		= 1.5
SWEP.ShotgunBeginReload		= 1.5

SWEP.Speed = 0.6
SWEP.Mass = 0.8
SWEP.WeaponName = "weapon_fas_r870"
SWEP.WeaponEntName = "sim_fas_r870"
SWEP.ScopeAfterShoot =  true 
/*---------------------------------------------------------
   Name: SWEP:Precache()
   Desc: Use this function to precache stuff.
---------------------------------------------------------*/
function SWEP:Precache()
	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire1.wav")
    	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire2.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire3.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire4.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire5.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_fire2.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_draw.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_holster.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_start.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_insert1.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_insert2.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_insert3.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_pump1.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_pump2.wav")
	util.PrecacheSound("weapons/shotgun_rem870/rem870_pump_end.wav")
	util.PrecacheSound(")weapons/shotgun_rem870/rem870_nopump_end.wav")
end

/*---------------------------------------------------------
   Name: SWEP:SetIronsights()
---------------------------------------------------------*/
function SWEP:SetIronsights(b)

	if (self.Owner) then
		if (b) then
			if (SERVER) then
				self.Owner:SetFOV(65, 0.2)
			end
	
			if self.AllowIdleAnimation then
		
				self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
				self.Owner:GetViewModel():SetPlaybackRate(0)
			end

			if WeightMod:GetBool() then
				self.Weapon:EmitSound("Defaulf.Iron_In")
				self.Owner:SetRunSpeed(Walkspeed:GetFloat()*self.Speed*self.Mass)
				self.Owner:SetWalkSpeed(Walkspeed:GetFloat()*self.Speed*self.Mass)
			else
				self.Weapon:EmitSound("Defaulf.Iron_In")
			end
		else
			if (SERVER) then
				self.Owner:SetFOV(0, 0.2)
			end

			if self.AllowPlaybackRate and self.AllowIdleAnimation then
				self.Owner:GetViewModel():SetPlaybackRate(1)
			end	
			if WeightMod:GetBool() then
				self.Owner:SetRunSpeed(Runspeed:GetFloat()*self.Mass)
				self.Owner:SetWalkSpeed(Walkspeed:GetFloat()*self.Mass)
				self.Weapon:EmitSound("Defaulf.Iron_Out")
			else
				self.Weapon:EmitSound("Defaulf.Iron_Out")
			end
		end
	end

	if (self.Weapon) then
		self.Weapon:SetDTBool(1, b)
	end
end

/*---------------------------------------------------------
   Name: SWEP:PrimaryAttack()
   Desc: +attack1 has been pressed.
---------------------------------------------------------*/
function SWEP:PrimaryAttack()

	// Holst/Deploy your fucking weapon
	if (not self.Owner:IsNPC() and not self.Owner:KeyDown(IN_SPEED) and not self.Weapon:GetDTBool(3) and not self.Owner:KeyDown(IN_RELOAD) and self.Owner:KeyDown(IN_USE)) then
		bHolsted = !self.Weapon:GetDTBool(0)
		self:SetHolsted(bHolsted)

		self.Weapon:SetNextPrimaryFire(CurTime() + 1.0)
		self.Weapon:SetNextSecondaryFire(CurTime() + 1.0)

		self:SetIronsights(false)

		return
	end

	if (not self:CanPrimaryAttack()) then return end

	self.Reloadaftershoot = CurTime() + self.Primary.Delay
	self.ActionDelay = (CurTime() + self.Primary.Delay + 0.05)
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Primary.Delay)
	self.Weapon:EmitSound(self.Primary.Sound)
	self:TakePrimaryAmmo(1)
	
	self:ShootBulletInformation()
	
	if (IsValid(self.Owner) and self.Owner:GetViewModel()) then
		self:IdleAnimation(self.Owner:GetViewModel():SequenceDuration() + 0.5)
	end

	if (not self.Owner:IsNPC()) and (self.Weapon:GetDTBool(1)) then
	
		timer.Simple(self.Primary.Delay, function()
			if not IsValid(self.Owner) then return end

			if (self.ScopeAfterShoot) and (self.Weapon:Clip1() > 0) then
				self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)
				self.Weapon:SetNextSecondaryFire(CurTime() + 0.5)
				self:SetIronsights(true)
			end
		end)
	end

	timer.Simple(0.5, function()
		if not IsValid(self.Owner) or not IsFirstTimePredicted() or self.Weapon:Clip1() == 0 then return end
		self:ResetVariables()
		self:ResetSpeed()
		self.Weapon:SendWeaponAnim(ACT_SHOTGUN_PUMP)
		self.ShellEffect = "sim_shelleject_fas_12gabuck"
		
		timer.Simple(0.3, function()
			if not IsValid(self.Owner) or not IsFirstTimePredicted() then return end
			local effectdata = EffectData()
				effectdata:SetEntity(self.Weapon)
				effectdata:SetNormal(self.Owner:GetAimVector())
				effectdata:SetAttachment(2)
			util.Effect(self.ShellEffect, effectdata)
		end)
	end)

	if ((game.SinglePlayer() and SERVER) or CLIENT) then
		self.Weapon:SetNetworkedFloat("LastShootTime", CurTime())
	end
end


/*---------------------------------------------------------
   Name: SWEP:ResetVariables()
   Desc: Reset all varibles.
---------------------------------------------------------*/
function SWEP:ResetVariables()

	self.bLastIron = false
	self.Weapon:SetDTBool(1, false)
	self.CurScopeZoom 		= 1
	self.fLastScopeZoom 		= 1
	self.bLastScope 			= false
	self.Weapon:SetDTBool(2, false)
	self.Weapon:SetNetworkedFloat("ScopeZoom", self.ScopeZooms[1])
	
	
	if (SERVER) then
		self.Owner:SetFOV(0, 0.2)
	end
	
end

/*---------------------------------------------------------
   Name: SWEP:ShootAnimation()
   Desc: You have to be smarter than TheCake to understand it's purpose.
---------------------------------------------------------*/
function SWEP:ShootAnimation()

	self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK) 		// View model animation
	self.ShellEffect = "none"
end
/*---------------------------------------------------------
   Name: SWEP:SetHolsted()
---------------------------------------------------------*/
function SWEP:SetHolsted(b)

	if (self.Owner) then
		if (b) then
			self.Weapon:SendWeaponAnim(ACT_VM_HOLSTER)
		else
			self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
		
		end
	end

	if (self.Weapon) then
		self.Weapon:SetDTBool(0, b)
	end
end


/*---------------------------------------------------------
   Name: SWEP:DeployAnimation()
---------------------------------------------------------*/
function SWEP:DeployAnimation()
		
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
end
