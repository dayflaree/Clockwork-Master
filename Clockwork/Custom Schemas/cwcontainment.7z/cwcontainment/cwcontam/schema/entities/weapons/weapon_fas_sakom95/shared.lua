// Variables that are used on both client and server
if (SERVER) then

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "smg"

end
if ( CLIENT ) then
	SWEP.PrintName			= "Valmet Rk 62"	
	SWEP.SlotPos			= 3
	SWEP.IconLetter			= "m"
	SWEP.Slot				= 3	
	SWEP.NameOfSWEP			= "weapon_fas_sakom95" --always make this the name of the folder the SWEP is in.
	killicon.AddFont( SWEP.NameOfSWEP, "CSKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
end
SWEP.Instructions			= "Uses 7.62mm Short ammo, Alternate Mode: E + Right Click, Switch Weapons: E + Left Click"
SWEP.Base 				= "weapon_fas_sim_base_reg"
SWEP.HoldType				= "smg"
SWEP.ViewModelFlip		= false
SWEP.ViewModel			= "models/weapons/a_sako.mdl"
SWEP.WorldModel			= "models/weapons/b_sako.mdl"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.Primary.Sound 		= Sound("Weapof_sako.Shoot")
SWEP.Primary.Recoil		= 2
SWEP.Primary.Damage		= 32
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.007
SWEP.Primary.Delay 		= 0.08

SWEP.Primary.ClipSize		= 30					// Size of a clip
SWEP.Primary.DefaultClip	= 0				// Default number of bullets in a clip
SWEP.Primary.Automatic		= true				// Automatic/Semi Auto
SWEP.Primary.Ammo			= "sevensixtwoshort"

SWEP.Secondary.ClipSize		= -1					// Size of a clip
SWEP.Secondary.DefaultClip	= -1					// Default number of bullets in a clip
SWEP.Secondary.Automatic	= false				// Automatic/Semi Auto
SWEP.Secondary.Ammo		= "none"

SWEP.ShellEffect			= "sim_shelleject_fas_762x39"	// "effect_mad_shell_pistol" or "effect_mad_shell_rifle" or "effect_mad_shell_shotgun"
SWEP.ShellDelay			= 0.02

SWEP.IronSightsPos = Vector (-2.7896, -5.0002, 1.35)
SWEP.IronSightsAng = Vector (-0.0659, 0.0126, 0)
SWEP.RunArmOffset  = Vector (4.0928, 0.4246, 2.3712)
SWEP.RunArmAngle   = Vector (-18.4406, 33.1846, 0)

SWEP.Pistol				= false
SWEP.Rifle				= true
SWEP.Shotgun			= false
SWEP.Sniper				= false

SWEP.Type				= 1 					// 1 = Automatic/Semi-Automatic mode, 2 = Suppressor mode, 3 = Burst fire mode
SWEP.Mode				= true

SWEP.data 				= {}
SWEP.data.NormalMsg		= "Switched to automatic."
SWEP.data.ModeMsg			= "Switched to semi-automatic."

SWEP.Speed = 0.6
SWEP.Mass = 0.75
SWEP.WeaponName = "weapon_fas_sako"
SWEP.WeaponEntName = "sim_fas_sako"
/*---------------------------------------------------------
   Name: SWEP:Precache()
   Desc: Use this function to precache stuff.
---------------------------------------------------------*/
function SWEP:Precache()

    	util.PrecacheSound("weapons/ar_sako92/sako_fire1.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_fire2.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_fire3.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_fire4.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_fire5.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_cock.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_magin.wav")
	util.PrecacheSound("weapons/ar_sako92/sako_magout.wav")
end
