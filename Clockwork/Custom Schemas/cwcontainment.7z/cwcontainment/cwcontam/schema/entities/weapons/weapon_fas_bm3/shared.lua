if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5

	SWEP.HoldType			= "ar2"

end
if ( CLIENT ) then
	SWEP.PrintName			= "Benelli M3"	
	SWEP.Author				= "MikkoK"
	SWEP.SlotPos			= 3
	SWEP.IconLetter			= "m"
		
	SWEP.NameOfSWEP			= "weapon_fas_bm3" --always make this the name of the folder the SWEP is in.
	killicon.AddFont( SWEP.NameOfSWEP, "CSKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
end
// Variables that are used on both client and server
SWEP.Instructions			= "Uses 12 Gauge Buckshot, Switch Weapons: E + Left Click"
SWEP.Base 				= "weapon_fas_sim_base"

SWEP.HoldType				= "ar2"
SWEP.ViewModelFlip		= false
SWEP.ViewModel			= "models/weapons/a_m3.mdl"
SWEP.WorldModel			= "models/weapons/b_m3s90.mdl"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.Primary.Sound 		= Sound("Weapof_M3S90.Shoot")
SWEP.Primary.Recoil		= 6
SWEP.Primary.Damage		= 4.3
SWEP.Primary.NumShots		= 20
SWEP.Primary.Cone			= 0.065
SWEP.Primary.Delay 		= 0.35

SWEP.Primary.ClipSize		= 8					// Size of a clip
SWEP.Primary.DefaultClip	= 0				// Default number of bullets in a clip
SWEP.Primary.Automatic		= false				// Automatic/Semi Auto
SWEP.Primary.Ammo			= "shotgunshell"

SWEP.ShellDelay			= 0.04
SWEP.ShellEffect			= "sim_shelleject_fas_12gabuck"	// "effect_mad_shell_pistol" or "effect_mad_shell_rifle" or "effect_mad_shell_shotgun"

SWEP.Secondary.ClipSize		= -1					// Size of a clip
SWEP.Secondary.DefaultClip	= -1					// Default number of bullets in a clip
SWEP.Secondary.Automatic	= false				// Automatic/Semi Auto
SWEP.Secondary.Ammo		= "none"

SWEP.IronSightsPos = Vector (-2.2631, -4.0007, 1.6813)
SWEP.IronSightsAng = Vector (0.2298, 0.0043, 0)
SWEP.RunArmOffset  = Vector (4.0928, 0.4246, 2.3712)
SWEP.RunArmAngle   = Vector (-18.4406, 33.1846, 0)

SWEP.Speed = 0.6
SWEP.Mass = 0.8
SWEP.WeaponName = "weapon_fas_m3s90"
SWEP.WeaponEntName = "sim_fas_m3s90"
/*---------------------------------------------------------
   Name: SWEP:Precache()
   Desc: Use this function to precache stuff.
---------------------------------------------------------*/
function SWEP:Precache()
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_Boltcatch.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_distance_fire1.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_distance_fire2.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_distance_fire3.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_distance_fire4.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_distance_fire5.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_fire1.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_fire2.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_fire3.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_fire4.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_fire5.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_getammo1.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_getammo2.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_getammo3.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load1.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load2.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load3.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load4.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load5.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load6.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load7.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_load8.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_pumpback.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_pumpforward.wav")
    	util.PrecacheSound("weapons/shotgun_m3s90p/m3s90_restock.wav")
end

/*---------------------------------------------------------
   Name: SWEP:ShootAnimation()
---------------------------------------------------------*/
function SWEP:ShootAnimation()

	if (self.Weapon:Clip1() == 0) then
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("fire_last"))
	else
		self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	end

end

/*---------------------------------------------------------
   Name: SWEP:ReloadAnimation()
---------------------------------------------------------*/
function SWEP:ReloadAnimation()
	
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) > 7) then
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload8"))
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1_empty"))	
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2_empty"))		
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3_empty"))	
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 4) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload4_empty"))
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 5) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload5_empty"))
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 6) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload6_empty"))
	end
	if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) == 7) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload7_empty"))
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))	
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))	
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3"))
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 4) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload4"))
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 5) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload5"))
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 6) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload6"))
	end
	if (self.Weapon:Clip1() == 1) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 7) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload7"))
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))	
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))	
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3"))
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 4) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload4"))
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 5) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload5"))
	end
	if (self.Weapon:Clip1() == 2) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 6) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload6"))
	end
	if (self.Weapon:Clip1() == 3) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))
	end
	if (self.Weapon:Clip1() == 3) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))
	end
	if (self.Weapon:Clip1() == 3) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3"))
	end
	if (self.Weapon:Clip1() == 3) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 4) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload4"))
	end
	if (self.Weapon:Clip1() == 3) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 5) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload5"))
	end
	if (self.Weapon:Clip1() == 4) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))
	end
	if (self.Weapon:Clip1() == 4) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))	
	end
	if (self.Weapon:Clip1() == 4) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3"))
	end
	if (self.Weapon:Clip1() == 4) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 4) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload4"))
	end
	if (self.Weapon:Clip1() == 5) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))		
	end
	if (self.Weapon:Clip1() == 5) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))	
	end
	if (self.Weapon:Clip1() == 5) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 3) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload3"))
	end
	if (self.Weapon:Clip1() == 6) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))	
	end
	if (self.Weapon:Clip1() == 6) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 2) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload2"))	
	end
	if (self.Weapon:Clip1() == 7) and (self.Owner:GetAmmoCount(self.Primary.Ammo) >= 1) then 
		self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
		local Animation = self.Owner:GetViewModel()
		Animation:SetSequence(Animation:LookupSequence("reload1"))
	end
	if self.ReloadingTime and CurTime() <= self.ReloadingTime then return end
 
	if ( self:Clip1() < self.Primary.ClipSize and self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
       	    	     local AnimationTime = self.Owner:GetViewModel():SequenceDuration()
       	    	     self.ReloadingTime = CurTime() + AnimationTime
       	    	     self:SetNextPrimaryFire(CurTime() + AnimationTime)
       	    	     self:SetNextSecondaryFire(CurTime() + AnimationTime)
	end

end

