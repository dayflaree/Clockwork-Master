if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5

	SWEP.HoldType			= "smg"

end
if ( CLIENT ) then
	SWEP.PrintName			= "Simonov SKS"	
	SWEP.SlotPos			= 3
	SWEP.IconLetter			= "m"
		
	SWEP.NameOfSWEP			= "weapon_fas_simonovsks" --always make this the name of the folder the SWEP is in.
	killicon.AddFont( SWEP.NameOfSWEP, "CSKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
end
// Variables that are used on both client and server
local Jamming	= CreateClientConVar("sim_jam_t", 1, true, false)		// Enable/Disable
SWEP.Base 				= "weapon_ins_sim_base"
SWEP.ViewModelFlip		= false
SWEP.HoldType				= "smg"
SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.ViewModelFOV			= 65
SWEP.ViewModel			= Model("models/weapons/i_rif_sks.mdl")
SWEP.WorldModel			= Model("models/weapons/j_rif_sks.mdl")


SWEP.Primary.Sound			= Sound( "Weapoi_SKS.Single" )
SWEP.Primary.Recoil			= 2.2
SWEP.Primary.Damage			= 33
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.007
SWEP.Primary.ClipSize		= 10
SWEP.Primary.Delay			= 0.29
SWEP.Primary.DefaultClip	= 0
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "sevensixtwoshort"

SWEP.ShellEffect			= "sim_shelleject_fas_762x51"

SWEP.ShellDelay			= 0.03
SWEP.Pistol				= false
SWEP.Rifle				= true
SWEP.Shotgun			= false
SWEP.Sniper				= false

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
SWEP.IronSightsPos = Vector (-1.7649, -2.5, 1.0281)
SWEP.IronSightsAng = Vector (0.0087, 0.0192, 0)

SWEP.RunArmOffset  = Vector (4.0928, 0.4246, 2.3712)
SWEP.RunArmAngle   = Vector (-18.4406, 33.1846, 0)

SWEP.Speed = 0.6
SWEP.Mass = 0.8

/*---------------------------------------------------------
   Name: SWEP:Precache()
   Desc: Use this function to precache stuff.
---------------------------------------------------------*/
function SWEP:Precache()
    util.PrecacheSound("weapons_ins/sks/sks_01.wav")
	util.PrecacheSound("weapons_ins/sks/sks_02.wav")
	util.PrecacheSound("weapons_ins/sks/sks_bolt_back.wav")
	util.PrecacheSound("weapons_ins/sks/sks_bolt_close.wav")
	util.PrecacheSound("weapons_ins/sks/sks_clipin.wav")
	util.PrecacheSound("weapons_ins/sks/sks_clipin2.wav")	
	util.PrecacheSound("weapons_ins/sks/sks_bipodup.wav")
	util.PrecacheSound("weapons_ins/sks/sks_stripper_off.wav")
end

/*---------------------------------------------------------
   Name: SWEP:ShootAnimation()
---------------------------------------------------------*/
function SWEP:ShootAnimation()

	if (self.Weapon:Clip1() <= 0) then
		self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
		self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)
	else
		self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	end
end

/*---------------------------------------------------------
   Name: SWEP:PrimaryAttack()
   Desc: +attack1 has been pressed.
---------------------------------------------------------*/
function SWEP:PrimaryAttack()
		// Holst/Deploy your fucking weapon

	if (self.Owner:KeyDown(IN_SPEED) or self:GetNWBool("LittleJammed") or self:GetNWBool("BigJammed")) then return end 
	if (not self.Owner:KeyDown(IN_RELOAD) and self.Owner:KeyDown(IN_USE)) then
		
		if (SERVER) then
			bHolsted = !self.Weapon:GetDTBool(0)
			self:SetHolsted(bHolsted)
		end

		self.Weapon:SetNextPrimaryFire(CurTime() + 1.0)
		self.Weapon:SetNextSecondaryFire(CurTime() + 1.0)

		self:SetIronsights(false)

		return
	end
	
	if (not self:CanPrimaryAttack()or self:GetNWBool("LittleJammed") or self:GetNWBool("BigJammed")) then return end
	
	self.Reloadaftershoot = CurTime() + self.Primary.Delay
	self.ActionDelay = (CurTime() + self.Primary.Delay + 0.05)
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Primary.Delay)

	// If the burst mode is activated, it's going to shoot the three bullets (or more if you're dumb and put 4 or 5 bullets for your burst mode)
	if self.Weapon:GetDTBool(3) and self.Type == 3 then
		self.BurstTimer 	= CurTime()
		self.BurstCounter = self.BurstShots - 1
		self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)
	end

	self.Weapon:EmitSound(self.Primary.Sound)

	self:TakePrimaryAmmo(1)
	
	self:ShootBulletInformation()
	
	local jamchance = math.random(1,1000) // 1000
	
	if Jamming:GetBool() then
		if self.Weapon:GetDTBool(0) or self.Weapon:Clip1()  <= 1 then return end
		if jamchance > 995 then
			self:SetNWBool("LittleJammed",true)
			self:Jammed()
		end
		if jamchance < 3 then
			self:SetNWBool("BigJammed",true)
			self:Jammed()
		end
	end
end

function SWEP:Reload()

	if (self.Owner:KeyDown(IN_USE)) then
		
		if self.Weapon:GetDTBool(0) or self.Owner:KeyDown(IN_SPEED) then return end
		self.Weapon:SetNextPrimaryFire(CurTime() + 3)
		self.Weapon:SetNextSecondaryFire(CurTime() + 3)

		if (SERVER) then
			
			local knife = ents.Create("weapon_ins_sim_ent_sks")
			knife:SetAngles(self.Owner:EyeAngles())

//			if (self:GetIronsights() == false) then
				local pos = self.Owner:GetShootPos()
					pos = pos + self.Owner:GetForward() * 5
					pos = pos + self.Owner:GetRight() * 9
					pos = pos + self.Owner:GetUp() * -5
				knife:SetPos(pos)
//			else
//				knife:SetPos (self.Owner:EyePos() + (self.Owner:GetAimVector()))
//			end

			knife:Spawn()
			knife:Activate()

			local phys = knife:GetPhysicsObject()
			phys:SetVelocity(self.Owner:GetAimVector() * 100)
			phys:AddAngleVelocity(Vector(0, 0, 0))
			
			self.Owner:StripWeapon("weapon_ins_sim_sks")
			if (SERVER) then
				RunConsoleCommand("lastinv")
			end
		end
	else

		
		// When the weapon is already doing an animation, just return end because we don't want to interrupt it
		if (self.ActionDelay > CurTime()) or self.Owner:KeyDown(IN_SPEED) then return end 
		if self.Weapon:GetDTBool(0) or (self:GetNWBool("BigJammed") or self:GetNWBool("LittleJammed")) or (self:Clip1() == (self.Primary.ClipSize + 1)) then return end

		if (SERVER) then
			if ( self.Reloadaftershoot > CurTime() ) then return end 
		end
			
		if (self.Weapon:Clip1() == 0) and (self.Owner:GetAmmoCount(self.Primary.Ammo) > 0) then
		// Need to call the default reload before the real reload animation (don't try to understand my reason)
		self.Weapon:DefaultReload(ACT_VM_RELOAD)

			self:SetIronsights(false)
			self:ReloadAnimation()
		end
	end	
end

/*---------------------------------------------------------
   Name: SWEP:ReloadAnimation()
---------------------------------------------------------*/
function SWEP:ReloadAnimation()

	self.Weapon:DefaultReload(ACT_VM_MISSCENTER2)
end
