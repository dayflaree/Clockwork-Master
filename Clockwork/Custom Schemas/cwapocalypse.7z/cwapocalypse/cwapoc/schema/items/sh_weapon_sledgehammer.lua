--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Large Sledgehammer";
	ITEM.cost = 100;
	ITEM.model = "models/weapons/w_sledgehammer.mdl";
	ITEM.weight = 5;
	ITEM.access = "V";
	ITEM.uniqueID = "weapon_sledgehammer";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A large, heavy sledgehammer.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(-12, 2, 0);
	ITEM.loweredAngles = Angle(-25, 15, -80);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 255, -90);
	ITEM.attachmentOffsetVector = Vector(5, 5, -8);
ITEM:Register();