--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Large Rusty Shovel";
	ITEM.cost = 50;
	ITEM.model = "models/weapons/w_shovel.mdl";
	ITEM.weight = 4;
	ITEM.access = "V";
	ITEM.uniqueID = "weapon_shovel";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A large, rusty shovel.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(-12, 2, 0);
	ITEM.loweredAngles = Angle(-25, 15, -80);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 255, 0);
	ITEM.attachmentOffsetVector = Vector(5, 5, -8);
ITEM:Register();