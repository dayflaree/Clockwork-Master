--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken Kettle";
ITEM.cost = 10;
ITEM.value = 0.5;
ITEM.model = "models/props_interiors/pot01a.mdl";
ITEM.weight = 1;
ITEM.access = "v";
ITEM.useText = "Scrap";
ITEM.business = true;
ITEM.description = "A kettle with a faulty handle and a fair bit of scratches.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 4);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();