--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Box of SMG Ammo";
ITEM.cost = 20;
ITEM.value = 0.1;
ITEM.model = "models/items/boxmrounds.mdl";
ITEM.weight = 1.5;
ITEM.access = "v";
ITEM.useText = "Salvage";
ITEM.business = true;
ITEM.description = "An empty box of Pistol rounds.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 7);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();