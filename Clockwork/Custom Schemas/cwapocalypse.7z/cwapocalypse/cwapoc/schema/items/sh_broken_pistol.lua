--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "A Broken Rusty Pistol";
ITEM.cost = 50;
ITEM.value = 0.1;
ITEM.model = "models/weapons/w_pistol.mdl";
ITEM.weight = 0.8;
ITEM.access = "V";
ITEM.business = true;
ITEM.description = "A smashed up, unusable weapon. Maybe someone with the right knowledge can fix it...";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 8);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();