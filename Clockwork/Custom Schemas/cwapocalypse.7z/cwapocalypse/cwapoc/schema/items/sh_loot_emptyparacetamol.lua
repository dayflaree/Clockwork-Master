--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Paracetamol Tin";
ITEM.cost = 10;
ITEM.value = 0.6;
ITEM.model = "models/props_junk/garbage_metalcan002a.mdl";
ITEM.weight = 0.1;
ITEM.access = "v";
ITEM.useText = "Scrap";
ITEM.business = true;
ITEM.description = "An empty tin of weak Paracetamol, half of the label is ripped off";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 3);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();