--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Small Combat Knife";
	ITEM.cost = 70;
	ITEM.model = "models/weapons/w_extreme_ratio.mdl";
	ITEM.weight = 1.5;
	ITEM.access = "V";
	ITEM.uniqueID = "m9k_knife";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A small, deadly knife. It is reliable in combat.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(-12, 2, 0);
	ITEM.loweredAngles = Angle(-25, 15, -80);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 255, -90);
	ITEM.attachmentOffsetVector = Vector(5, 5, -8);
ITEM:Register();