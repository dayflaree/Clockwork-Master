--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Empty Box of Pistol Ammo";
ITEM.cost = 20;
ITEM.value = 0.2;
ITEM.model = "models/Items/BoxSRounds.mdl";
ITEM.weight = 0.8;
ITEM.access = "v";
ITEM.useText = "Scrap";
ITEM.business = true;
ITEM.description = "An empty box of Pistol rounds.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 5);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();