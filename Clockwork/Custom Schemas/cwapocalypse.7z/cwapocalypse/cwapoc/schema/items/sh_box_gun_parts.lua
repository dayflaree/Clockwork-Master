--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Box of Gun Parts";
ITEM.cost = 100;
ITEM.value = 0.1;
ITEM.model = "models/props_lab/box01a.mdl";
ITEM.weight = 1;
ITEM.access = "V";
ITEM.business = true;
ITEM.description = "A small box of assorted gun parts.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 9);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();