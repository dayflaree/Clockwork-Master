--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Crowbar";
	ITEM.cost = 100;
	ITEM.model = "models/weapons/w_crowbar.mdl";
	ITEM.weight = 3;
	ITEM.access = "V";
	ITEM.uniqueID = "weapon_crowbar";
	ITEM.business = true;
	ITEM.isMeleeWeapon = true;
	ITEM.description = "A large, red, rusty crowbar. The logo of a company is worn down on the side.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(-12, 2, 0);
	ITEM.loweredAngles = Angle(-25, 15, -80);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 255, -90);
	ITEM.attachmentOffsetVector = Vector(5, 5, -8);
ITEM:Register();