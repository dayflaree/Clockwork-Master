--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Broken Television";
ITEM.cost = 20;
ITEM.value = 0.3;
ITEM.model = "models/props_c17/tv_monitor01.mdl";
ITEM.weight = 4;
ITEM.access = "v";
ITEM.useText = "Scrap";
ITEM.business = true;
ITEM.description = "A broken television. The screen is smashed through, several wires poking out.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	Clockwork.player:GiveCash(player, 7);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();