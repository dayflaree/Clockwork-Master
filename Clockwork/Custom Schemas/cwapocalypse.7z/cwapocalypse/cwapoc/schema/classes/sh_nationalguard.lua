--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("National Guard");
	CLASS.color = Color(50, 100, 150, 255);
	CLASS.wages = 30;
	CLASS.factions = {FACTION_NATIONALGUARD};
	CLASS.isDefault = true;
	CLASS.wagesName = "Dollars";
	CLASS.description = "A soldier of the National Guard.";
	CLASS.defaultPhysDesc = "A well equiped soldier, a large assault rifle on his back.";
CLASS_EXAMPLE = CLASS:Register();