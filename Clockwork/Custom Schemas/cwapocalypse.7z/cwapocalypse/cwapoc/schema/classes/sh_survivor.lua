--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local CLASS = Clockwork.class:New("Survivor");
	CLASS.color = Color(255, 200, 100, 255);
	CLASS.wages = 20;
	CLASS.factions = {FACTION_SURVIVOR};
	CLASS.isDefault = true;
	CLASS.wagesName = "Dollars";
	CLASS.description = "A normal survivor of the outbreak, fighting to survive.";
	CLASS.defaultPhysDesc = "A dirty, depressed survivor of the outbreak.";
CLASS_EXAMPLE = CLASS:Register();