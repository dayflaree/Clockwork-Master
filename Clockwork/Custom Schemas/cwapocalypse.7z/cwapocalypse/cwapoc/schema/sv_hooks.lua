--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

-- Called when a player's default model is needed.
function Schema:GetPlayerDefaultModel(player)
	return "models/police.mdl";
end;