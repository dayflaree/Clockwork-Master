--[[
	� 2012 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

--[[ This is where you might add any functions for your schema. --]]
function Schema:PrintConsole(text)
	MsgC(text, Color(255, 0, 0, 255));
end;