Skeleton
========

A skeleton schema for the clockwork roleplaying framework.