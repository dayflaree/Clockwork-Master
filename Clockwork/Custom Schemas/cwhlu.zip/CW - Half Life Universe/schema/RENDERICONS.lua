hook.Remove("f")

local MODELS = {
"models/props_junk/watermelon01.mdl",
"models/weapons/w_suitcase_passenger.mdl",
"models/healthvial.mdl",
"models/weapons/w_pistol.mdl",
"models/props_junk/garbage_plasticbottle003a.mdl",
"models/weapons/w_357.mdl",
"models/weapons/w_crossbow.mdl",
"models/props_lab/jar01b.mdl",
"models/error.mdl",
"models/props_junk/garbage_metalcan001a.mdl",
"models/items/crossbowrounds.mdl",
"models/props_junk/cardboard_box004a.mdl",
"models/roller.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/props_c17/suitcase_passenger_physics.mdl",
"models/props_lab/bindergraylabel01b.mdl",
"models/items/boxbuckshot.mdl",
"models/weapons/w_missile_launch.mdl",
"models/props_junk/cardboard_box004a.mdl",
"models/error.mdl",
"models/props_lab/binderredlabel.mdl",
"models/props_lab/clipboard.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/props_junk/garbage_metalcan002a.mdl",
"models/gibs/shield_scanner_gib1.mdl",
"models/props_lab/binderredlabel.mdl",
"models/deadbodies/dead_male_civilian_radio.mdl",
"models/props_combine/combine_lock01.mdl",
"models/props_combine/combine_mine01.mdl",
"models/props_junk/popcan01a.mdl",
"models/Fallout 3/backpack_1.mdl",
"models/weapons/w_rocket_launcher.mdl",
"models/props_junk/garbage_plasticbottle001a.mdl",
"models/props_c17/suitcase_passenger_physics.mdl",
"models/items/combine_rifle_cartridge01.mdl",
"models/props_junk/garbage_metalcan002a.mdl",
"models/props_lab/citizenradio.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/props_junk/garbage_glassbottle002a.mdl",
"models/props_junk/garbage_takeoutcarton001a.mdl",
"models/props_junk/garbage_plasticbottle002a.mdl",
"models/items/grenadeammo.mdl",
"models/props_junk/garbage_milkcarton001a.mdl",
"models/items/combine_rifle_ammo01.mdl",
"models/items/grenadeammo.mdl",
"models/items/healthkit.mdl",
"models/lagmite/lagmite.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/Fallout 3/backpack_2.mdl",
"models/items/ar2_grenade.mdl",
"models/props_lab/frame002a.mdl",
"models/error.mdl",
"models/props_lab/binderredlabel.mdl",
"models/items/crossbowrounds.mdl",
"models/props_junk/garbage_milkcarton002a.mdl",
"models/props_lab/binderredlabel.mdl",
"models/props_junk/popcan01a.mdl",
"models/props_lab/binderbluelabel.mdl",
"models/items/boxsrounds.mdl",
"models/items/boxmrounds.mdl",
"models/props_wasteland/prison_toiletchunk01f.mdl",
"models/props_c17/paper01.mdl",
"models/props_wasteland/prison_padlock001a.mdl",
"models/weapons/w_shotgun.mdl",
"models/items/357ammo.mdl",
"models/props_c17/suitcase_passenger_physics.mdl",
"models/props_junk/popcan01a.mdl",
"models/weapons/w_irifle.mdl",
"models/props_junk/garbage_glassbottle003a.mdl",
"models/weapons/w_package.mdl",
"models/props_lab/bindergreenlabel.mdl",
"models/items/grenadeammo.mdl",
"models/props_lab/bindergraylabel01b.mdl",
"models/props_lab/jar01b.mdl",
"models/error.mdl",
"models/props_lab/binderredlabel.mdl",
"models/sprayca2.mdl",
"models/props_lab/bindergraylabel01b.mdl",
"models/weapons/w_smg1.mdl",
"models/error.mdl"
}

local DUPES = {
	
}

for k, MODEL in pairs(MODELS) do
	local entity = ents.CreateClientProp(MODEL);
			entity:SetAngles(Angle(0, 0, 0));
			entity:SetPos(Vector(0, 0, 0));
			entity:SetModel(MODEL);
			entity:Spawn();
			entity:Activate();
		entity:PhysicsInit(SOLID_VPHYSICS);

		local mins, maxs = entity:WorldSpaceAABB()
	entity:Remove()	

	DUPES[k] = {
		Maxs = maxs,
		Mins = mins,
		Entities = {
			{Model = MODEL, Pos = Vector(0, 0, 0), Angle = Angle(0, 0, 0)}
		},
		Good = PositionSpawnIcon(entity, Vector(0, 0, 0))
	}	
end

local DONE = {}
local INT = 1
local CSIZE = 1

	
local Sizes = {
	"slidefuse/icons/bg48.png",
	"slidefuse/icons/bg64.png",
	"slidefuse/icons/bg128.png",
	"slidefuse/icons/bg256.png",
	"slidefuse/icons/bg512.png"
}
local PXSizes = {
	48,
	64,
	128,
	256,
	512
}


hook.Add( "PostRender", "f", function()
	
	if (!Sizes[CSIZE]) then
		INT = INT + 1
		CSIZE = 1
		return
	end

	if (!MODELS[INT]) then
		return
	end

	local CurrentModel = MODELS[INT]
	print(CurrentModel)
	local Explode = string.Explode("/", CurrentModel)
	PrintTable(Explode)
	ModelName = Explode[#Explode]

	local MODEL = CurrentModel
	RENDERED = false

	local Dupe = DUPES[INT]
	
	local GOODPOS = Dupe.Good
	local FOV = GOODPOS.fov+1
	local gOrigin = GOODPOS.origin
	local gLookAt = GOODPOS.angles


	local v = Sizes[CSIZE]
	local pixels = PXSizes[CSIZE]

		render.SetMaterial( Material( v ) )
		render.DrawScreenQuadEx( 0, 0, pixels, pixels )

		--
		-- This is gonna take some cunning to look awesome!
		--
		local Size		= Dupe.Maxs - Dupe.Mins;
		local Radius	= Size:Length() * 0.5;
		local CamDist	= Radius / math.sin( math.rad( FOV ) / 2 ) -- Works out how far the camera has to be away based on radius + fov!
		local Center	= LerpVector( 0.5, Dupe.Mins, Dupe.Maxs );
		local CamPos	= Center + Vector( -1, 0, 0.5 ):GetNormal() * CamDist;
		local EyeAng	= ( Center - CamPos ):GetNormal():Angle();
		

		local CamPos = gOrigin
		local EyeAng = gLookAt


		--
		-- The base view
		--
		local view = 
		{
			type		= "3D",
			origin		= CamPos,
			angles		= EyeAng,
			x			= 0,
			y			= 0,
			w			= pixels,
			h			= pixels,
			aspect		= 1,
			fov			= FOV
		}

		--
		-- Create a bunch of entities we're gonna use to render.
		--
		local entities = {}

		for k, v in pairs( Dupe.Entities ) do


				entities[ k ] = ClientsideModel( v.Model or "error.mdl", RENDERGROUP_OTHER )


		end

		--
		-- BLACK OUTLINE
		-- AWESOME BRUTE FORCE METHOD
		--
		render.SuppressEngineLighting( true )

		local BorderSize	= CamDist * 0.004
		local Up			= EyeAng:Up() * BorderSize
		local Right			= EyeAng:Right() * BorderSize

		render.SetColorModulation( 186/255, 95/255, 228/255, 1 )
		
		render.MaterialOverride( Material( "models/debug/debugwhite" ) )

		-- Render each entity in a circle
		for k, v in pairs( Dupe.Entities ) do

			for i=0, math.pi*2, 0.2 do

				view.origin = CamPos + Up * math.sin( i ) + Right * math.cos( i )

				cam.Start( view )

					render.Model( 
					{
						model	=	v.Model,
						pos		=	v.Pos,
						angle	=	v.Angle,

					}, entities[k] )

				cam.End()

			end

		end

		-- Because ee just messed up the depth
		render.ClearDepth()
		render.SetColorModulation( 0, 0, 0, 1 )

		-- Try to keep the border size consistent with zoom size
		local BorderSize	= CamDist * 0.002
		local Up			= EyeAng:Up() * BorderSize
		local Right			= EyeAng:Right() * BorderSize

		-- Render each entity in a circle
		for k, v in pairs( Dupe.Entities ) do

			for i=0, math.pi*2, 0.2 do
				
				view.origin = CamPos + Up * math.sin( i ) + Right * math.cos( i )
				cam.Start( view )

				render.Model( 
				{
					model	=	v.Model,
					pos		=	v.Pos,
					angle	=	v.Angle,
					skin	=	v.Skin
				}, entities[k] )

				cam.End()
					
			end
		end


		--
		-- ACUAL RENDER!
		--

		-- We just fucked the depth up - so clean it
		render.ClearDepth()

		-- Set up the lighting. This is over-bright on purpose - to make the ents pop
		render.SetModelLighting( 0, 1.5, 1.5, 1.5 )
		render.SetModelLighting( 1, 1.5, 1.5, 1.5 )
		render.SetModelLighting( 2, 1.5, 1.5, 1.5 )
		render.SetModelLighting( 3, 1.5, 1.5, 1.5 )
		render.SetModelLighting( 4, 1.5, 1.5, 1.5 ) -- top
		render.SetModelLighting( 5, 1.5, 1.5, 1.5 )
		render.MaterialOverride( nil )

		view.origin = CamPos
		cam.Start( view )

		-- Render each model
		for k, v in pairs( Dupe.Entities ) do

			render.SetColorModulation( 1, 1, 1, 1 )

			if ( istable( v.EntityMods ) ) then
					
				if ( istable( v.EntityMods.colour ) ) then
					render.SetColorModulation( v.EntityMods.colour.Color.r/255, v.EntityMods.colour.Color.g/255, v.EntityMods.colour.Color.b/255, v.EntityMods.colour.Color.a/255 )
				end

				if ( istable( v.EntityMods.material ) ) then
					render.MaterialOverride( Material( v.EntityMods.material.MaterialOverride ) )
				end

			end
			
			render.Model( 
			{
				model	=	v.Model,
				pos		=	v.Pos,
				angle	=	v.Angle,
				skin	=	v.Skin
			}, entities[k] )
				
			render.MaterialOverride( nil )

		end

		cam.End()

		-- Enable lighting again (or it will affect outside of this loop!)
		render.SuppressEngineLighting( false )
		render.SetColorModulation( 1, 1, 1, 1 )

		--
		-- Finished with the entities - remove them all
		--
		

		local jpegdata = render.Capture(
		{
			format		=	"jpeg",
			x			=	0,
			y			=	0,
			w			=	pixels,
			h			=	pixels,
			quality		=	100
		});

		if (!file.IsDir("icons/"..CurrentModel, "DATA")) then
			file.CreateDir("icons/"..CurrentModel)
		end

		//file.Write("icons/"..pixels.."_"..".txt", util.Base64Encode(jpegdata))
		local f = file.Open("icons/"..CurrentModel.."/"..pixels..".txt", "wb", "DATA")
		f:Write(jpegdata)
		f:Close()

		for k, v in pairs( entities ) do
			v:Remove()
		end


	
	//print(type(jpegdata))
	//
	//RENDERED = true
	CSIZE = CSIZE + 1

end)

