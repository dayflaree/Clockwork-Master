--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local THEME = Clockwork.theme:Begin();

-- Called when fonts should be created.
function THEME:CreateFonts()
	surface.CreateFont("hl2_ThickArial", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(10),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_PlayerInfoText", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(9),
		weight		= 350,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_Large3D2D", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:GetFontSize3D(),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_IntroTextSmall", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(12),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_IntroTextTiny", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(11),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_CinematicText", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(10),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_IntroTextBig", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(20),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_MainText", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(9),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_TargetIDText", 
	{
		font		= "Open Sans",
		size		= Clockwork.kernel:FontScreenScale(9),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_MenuTextHuge", 
	{
		font		= "AvantGardeMdITC-Bold",
		size		= Clockwork.kernel:FontScreenScale(32),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
	surface.CreateFont("hl2_MenuTextBig", 
	{
		font		= "AvantGardeMdITC-Bold",
		size		= Clockwork.kernel:FontScreenScale(20),
		weight		= 400,
		antialiase	= true,
		additive 	= false
	});
end;

-- Called when to initialize the theme.
function THEME:Initialize()
	Clockwork.option:SetColor("information", Color(130, 96, 169, 255));
	Clockwork.option:SetColor("background", Color(0, 0, 0, 255));
	Clockwork.option:SetColor("target_id", Color(109, 83, 138, 255));
	Clockwork.option:SetFont("bar_text", "hl2_TargetIDText");
	Clockwork.option:SetFont("main_text", "hl2_MainText");
	Clockwork.option:SetFont("hints_text", "hl2_IntroTextTiny");
	Clockwork.option:SetFont("large_3d_2d", "hl2_Large3D2D");
	Clockwork.option:SetFont("menu_text_big", "hl2_MenuTextBig");
	Clockwork.option:SetFont("menu_text_huge", "hl2_MenuTextHuge");
	Clockwork.option:SetFont("target_id_text", "hl2_TargetIDText");
	Clockwork.option:SetFont("cinematic_text", "hl2_CinematicText");
	Clockwork.option:SetFont("date_time_text", "hl2_IntroTextSmall");
	Clockwork.option:SetFont("intro_text_big", "hl2_IntroTextBig");
	Clockwork.option:SetFont("menu_text_tiny", "hl2_IntroTextTiny");
	Clockwork.option:SetFont("menu_text_small", "hl2_IntroTextSmall");
	Clockwork.option:SetFont("intro_text_tiny", "hl2_IntroTextTiny");
	Clockwork.option:SetFont("intro_text_small", "hl2_IntroTextSmall");
	Clockwork.option:SetFont("player_info_text", "hl2_PlayerInfoText");
end;

-- Called just before a bar is drawn.
function THEME.module:PreDrawBar(barInfo)
	surface.SetDrawColor(255, 255, 255, 150);
	surface.DrawRect(barInfo.x, barInfo.y, barInfo.width, barInfo.height);
	
	barInfo.drawBackground = false;
	barInfo.drawProgress = false;
	barInfo.drawForeground = false;
	
	if (barInfo.text) then
		barInfo.text = string.upper(barInfo.text);
	end;
end;

-- Called just after a bar is drawn.
function THEME.module:PostDrawBar(barInfo)
	surface.SetDrawColor(barInfo.color.r, barInfo.color.g, barInfo.color.b, barInfo.color.a);
	render.SetScissorRect(barInfo.x, barInfo.y, barInfo.x + barInfo.progressWidth, barInfo.y + barInfo.height, true)
		surface.DrawRect(barInfo.x, barInfo.y, barInfo.width, barInfo.height);
	render.SetScissorRect(barInfo.x, barInfo.y, barInfo.x + barInfo.progressWidth, barInfo.height, false)
end;

-- Called just before the weapon selection info is drawn.
function THEME.module:PreDrawWeaponSelectionInfo(info)
	surface.SetDrawColor(21, 21, 21, 100);
	surface.DrawRect(info.x, info.y, info.width, info.height);
	
	info.drawBackground = false;
end;

-- Called just before the local player's information is drawn.
function THEME.module:PreDrawPlayerInfo(boxInfo, information, subInformation)
	surface.SetDrawColor(21, 21, 21, 100);
	surface.DrawRect(boxInfo.x, boxInfo.y, boxInfo.width, boxInfo.height);
	
	boxInfo.drawBackground = false;
end;

-- Called after the character menu has initialized.
function THEME.hooks:PostCharacterMenuInit(panel) end;

-- Called every frame that the character menu is open.
function THEME.hooks:PostCharacterMenuThink(panel) end;

-- Called after the character menu is painted.
function THEME.hooks:PostCharacterMenuPaint(panel) end;

-- Called after a character menu panel is opened.
function THEME.hooks:PostCharacterMenuOpenPanel(panel) end;

-- Called after the main menu has initialized.
function THEME.hooks:PostMainMenuInit(panel) end;

-- Called after the main menu is rebuilt.
function THEME.hooks:PostMainMenuRebuild(panel) end;

-- Called after a main menu panel is opened.
function THEME.hooks:PostMainMenuOpenPanel(panel, panelToOpen) end;

-- Called after the main menu is painted.
function THEME.hooks:PostMainMenuPaint(panel) end;

-- Called every frame that the main menu is open.
function THEME.hooks:PostMainMenuThink(panel) end;

THEME.skin.frameBorder = Color(255, 255, 255, 255);
THEME.skin.frameTitle = Color(255, 255, 255, 255);

THEME.skin.bgColorBright = Color(150, 150, 150, 255);
THEME.skin.bgColorSleep = Color(70, 70, 70, 255);
THEME.skin.bgColorDark = Color(50, 50, 50, 255);
THEME.skin.bgColor = Color(40, 40, 40, 225);

THEME.skin.controlColorHighlight = Color(70, 70, 70, 255);
THEME.skin.controlColorActive = Color(175, 175, 175, 255);
THEME.skin.controlColorBright = Color(100, 100, 100, 255);
THEME.skin.controlColorDark = Color(30, 30, 30, 255);
THEME.skin.controlColor = Color(60, 60, 60, 255);

THEME.skin.colPropertySheet = Color(255, 255, 255, 255);
THEME.skin.colTabTextInactive = Color(0, 0, 0, 255);
THEME.skin.colTabInactive = Color(255, 255, 255, 255);
THEME.skin.colTabShadow = Color(0, 0, 0, 170);
THEME.skin.colTabText = Color(255, 255, 255, 255);
THEME.skin.colTab = Color(0, 0, 0, 255);

THEME.skin.fontCategoryHeader = "hl2_ThickArial";
THEME.skin.fontMenuOption = "hl2_ThickArial";
THEME.skin.fontFormLabel = "hl2_ThickArial";
THEME.skin.fontButton = "hl2_ThickArial";
THEME.skin.fontFrame = "hl2_ThickArial";
THEME.skin.fontTab = "hl2_ThickArial";


Clockwork.theme:Finish(THEME);