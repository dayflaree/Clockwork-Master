--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local ATTRIBUTE = Clockwork.attribute:New();
	ATTRIBUTE.name = "Endurance";
	ATTRIBUTE.maximum = 75;
	ATTRIBUTE.uniqueID = "end";
	ATTRIBUTE.description = "Affects your overall endurance, e.g: how much pain you can take.";
	ATTRIBUTE.isOnCharScreen = false;
ATB_ENDURANCE = Clockwork.attribute:Register(ATTRIBUTE);