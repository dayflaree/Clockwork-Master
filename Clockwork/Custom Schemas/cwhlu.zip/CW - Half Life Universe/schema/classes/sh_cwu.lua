--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local CLASS = Clockwork.class:New("Civil Workers Union");
	CLASS.color = Color(105, 148, 240, 255);
	CLASS.wages = 100
	CLASS.factions = {FACTION_UU};
	CLASS.isDefault = false;
	CLASS.wagesName = "Contribution";
	CLASS.description = "A member of the elite Worker's Union.";
	CLASS.defaultPhysDesc = "Wearing a clean shirt and freshly ironed slacks.";
CLASS_CWU = CLASS:Register();