--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local CLASS = {};

CLASS.color = Color(60, 125, 215, 255);
CLASS.factions = {FACTION_CPS};
CLASS.description = "A Civil Protection Service Unit";
CLASS.defaultPhysDesc = "Wearing a Civil Protection jacket with a radio";

CLASS_CPS = Clockwork.class:Register(CLASS, "Civil Protection Service Unit");