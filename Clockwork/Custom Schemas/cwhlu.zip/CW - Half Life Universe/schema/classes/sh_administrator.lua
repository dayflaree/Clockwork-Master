--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local CLASS = Clockwork.class:New("Administrator");
	CLASS.color = Color(255, 200, 100, 255);
	CLASS.wages = 250;
	CLASS.factions = {FACTION_ADMIN};
	CLASS.isDefault = true;
	CLASS.wagesName = "Allowance";
	CLASS.description = "A human Administrator advised by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing a clean brown suit";
CLASS_ADMIN = CLASS:Register();