--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local CLASS = Clockwork.class:New("Citizen");
	CLASS.color = Color(219, 147, 91, 255);
	CLASS.factions = {FACTION_CITIZEN};
	CLASS.isDefault = true;
	CLASS.wagesName = "Supplies";
	CLASS.description = "A regular human citizen enslaved by the Universal Union.";
	CLASS.defaultPhysDesc = "Wearing dirty clothes.";
CLASS_CITIZEN = CLASS:Register();