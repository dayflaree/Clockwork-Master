--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

-- Called when Clockwork loads the schema.
function Schema:ClockworkSchemaLoaded()
	Clockwork.kernel:IncludeDirectory(Clockwork.kernel:GetSchemaFolder().."/schema/ranks")
	Clockwork.kernel:IncludeDirectory(Clockwork.kernel:GetSchemaFolder().."/schema/widgets")

	if (SERVER) then
		Schema.resource:AddGamemode(Clockwork.kernel:GetClockworkFolder())
		Schema.resource:AddGamemode(Clockwork.kernel:GetSchemaFolder())		
	end

	Schema.rank:DefineRankOrder()
end

-- Called when the Clockwork shared variables are added.
function Schema:ClockworkAddSharedVars(globalVars, playerVars)
	playerVars:Number("antidepressants", true);
	playerVars:String("customClass");
	playerVars:String("citizenID", true);
	playerVars:Number("scanner", true);
	playerVars:Number("clothes", true);
	playerVars:Number("tied");
	playerVars:String("cpsRank");
	playerVars:String("cpsID");
	globalVars:Number("PKMode");
end;