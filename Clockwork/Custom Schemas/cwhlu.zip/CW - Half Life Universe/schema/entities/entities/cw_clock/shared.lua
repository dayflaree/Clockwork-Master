--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

ENT.Type = "anim";
ENT.Base = "base_anim";

ENT.RenderGroup		= RENDERGROUP_TRANSLUCENT;
 
ENT.PrintName		= "Server Clock";
ENT.Author			= "Slidefuse - Hunger";
ENT.Contact			= "slidefuse.net";
ENT.Purpose			= "Tell the server time!";
ENT.Instructions	= "Once spawned, place where you want :D";

ENT.Spawnable		= false;
ENT.AdminSpawnable	= true;

ENT.Category		= "Half Life Universe";
