--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

include("shared.lua");

local time = {Hours=0, Minutes=0, Seconds=0};

local mFace = Material("slidefuse/clock/face.png")
local mHour = Material("slidefuse/clock/hour.png")
local mMinute = Material("slidefuse/clock/minute.png")

local cWhite = Color(255, 255, 255)
function ENT:Draw()
	self:DrawModel();

	local light = (render.ComputeDynamicLighting(self:GetPos(), self:GetForward()) + render.ComputeLighting(self:GetPos(), self:GetForward()))/2 + Vector(0.1, 0.1, 0.1)

	local cAngle = self:GetAngles()
	cAngle:RotateAroundAxis(self:GetForward(), 90)
	cAngle:RotateAroundAxis(self:GetUp(), 90)
	cam.Start3D2D(self:GetPos() + self:GetForward(), cAngle, 1)
		surface.SetDrawColor(Color(cWhite.r*light.x, cWhite.g*light.y, cWhite.b*light.z))

		surface.DrawRect(-14, -14, 28, 28)

		surface.SetMaterial(mFace)
		surface.DrawTexturedRect(-28, -28, 56, 56)

		surface.SetMaterial(mHour)
		surface.DrawTexturedRectRotated(0, 0, 56, 56, 180-((time.Hours/12 * 360)+((360/12)*(time.Minutes/60))+(360/12/60*time.Seconds/60)))

		surface.SetMaterial(mMinute)
		surface.DrawTexturedRectRotated(0, 0, 56, 56, 180-(time.Minutes/60 * 360 + 360/60*time.Seconds/60))

	cam.End3D2D()
end

usermessage.Hook("UpdateTime", function(um)
	local hours = um:ReadShort();
	local minutes = um:ReadShort();
	local seconds = um:ReadShort();
	local sct = um:ReadShort();
	local offset = CurTime() - sct;
	seconds = seconds + offset;
	if seconds > 59 then
		seconds = seconds - 60;
		minutes = minutes + 1;
	end
	local houroffset = hours-time.Hours;
	local minoffset = minutes-time.Minutes;
	local secoffset = seconds-time.Seconds;
	time.Hours = hours;
	time.Minutes = minutes;
	time.Seconds = seconds;
end);

timer.Create("TimeUpdate", 1, 0, function()
	for _, clock in ipairs(ents.FindByClass("sf_clock")) do
		clock:EmitSound("clock/tick.wav", 60);
	end
	time.Seconds = time.Seconds + 1;
	if time.Seconds >= 60 then
		time.Seconds = 0;
		time.Minutes = time.Minutes + 1;
		if time.Minutes == 60 then
			time.Mintues = 0;
			time.Hours = time.Hours + 1;
			if time.Hours == 12 then
				time.Hours = 0;
			end
		end
	end
end);