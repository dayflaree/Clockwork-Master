--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

include("shared.lua");


function ENT:SpawnFunction(ply, tr)
	if tr.HitWorld then
		local ent = ents.Create("cw_clock");
		ent:SetPos(tr.HitPos + Vector(0, 0, 50));
		ent:Spawn();
		return ent;
	end
end

function ENT:Initialize()
	self:SetModel("models/props_trainstation/trainstation_clock001.mdl");
	self:PhysicsInit(SOLID_VPHYSICS); 
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);
    local phys = self.Entity:GetPhysicsObject();
	if (phys:IsValid()) then
		phys:Wake();
	end
end


timer.Create("TimeUpdate", 15, 0, function()
	if (SERVER) then
		umsg.Start("UpdateTime");
			umsg.Short(tonumber(os.date("%I")));
			umsg.Short(tonumber(os.date("%M")));
			umsg.Short(tonumber(os.date("%S")));
			umsg.Short(CurTime());
		umsg.End();
	end
end)

hook.Add("PlayerInitialSpawn", "UpdateTime", function(ply)
	if (SERVER) then
		umsg.Start("UpdateTime", ply);
			umsg.Short(tonumber(os.date("%I")));
			umsg.Short(tonumber(os.date("%M")));
			umsg.Short(tonumber(os.date("%S")));
			umsg.Short(CurTime());
		umsg.End();
	end
end);

