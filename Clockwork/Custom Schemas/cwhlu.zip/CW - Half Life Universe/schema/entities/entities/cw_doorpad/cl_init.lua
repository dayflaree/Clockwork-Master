--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

surface.CreateFont( "doorpadfont", {
    font = "Arial",
    size = 20
})

include("shared.lua")

local glowMaterial = Material("sprites/glow04_noz")

-- Called when the entity should draw.
function ENT:Draw()
	self:DrawModel()
	
    local width = 120
    local height = 280
    
    local mBackground = Material("cwhlu/bg_gradient.png") -- temp
    
    cam.Start3D2D(self:GetPos() + Vector(1, - 4, 5 ), self:GetAngles() + Angle(90, 180, 0), 0.2)
    
        --Black background
        surface.SetDrawColor(Color(0, 0, 0))
        surface.DrawRect(0, 0, 10, 15)
        
        surface.SetMaterial(mBackground)
        surface.DrawTexturedRect(0, 0, 10, 15)
        
        
        --Okay just go about
    
    cam.End3D2D()
end