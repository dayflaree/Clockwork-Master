--[[
Hunger Johnson: But even making things like cigarettes
Hunger Johnson: I don't knwo if Jovan or Mojo wants cigs
(WBA Inf.) M-Sgt. Trenchman-: Jovan liked the idea
--]]

local ITEM = Clockwork.item:New();
ITEM.cost = 8;
ITEM.model = "models/roller.mdl" -- TO BE DETERMINED
ITEM.weight = 1;
ITEM.access = "v";
ITEM.useText = "Smoke";
ITEM.category = "Consumables";
ITEM.business = false;
ITEM.description = "A full pack of the finest tobacco in England, grew by your own Dutch Uncle."
ITEM:AddData("cigs", 20, true)

function ITEM:GetName()
	return self:GetData("cigs").." Dutch Finest Cigarettes"
end

ITEM:AddQueryProxy("name", ITEM:GetName())

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	
	if (self:GetData("cigs") < 1) then
		Clockwork.player:Notify(player, "Your pack is emptyh")
		return false
	end

	local s = EffectData();
	s:SetOrigin(player:EyePos());
	util.Effect("cw_effect_smoke_cig", s);

	local coughrandom = math.random(1,10)
	if (coughrandom >= 5) then
		local cough = {
			"ambient/voices/cough1.wav",
			"ambient/voices/cough2.wav",
			"ambient/voices/cough3.wav",
			"ambient/voices/cough4.wav"
		}
		player:EmitSound(cough[math.random(1,#cough)], 50, 100)
	end;

	self:SetData("cigs", self:GetData("cigs") - 1)

	return false;
end;

function ITEM:GetClientSideInfo()
	return Clockwork.kernel:AddMarkupLine(
		"", "Cigarettes: "..self:GetData("cigs")
	);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();