--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Boxed Satchel";
ITEM.cost = 25;
ITEM.model = "models/props_junk/cardboard_box004a.mdl";
ITEM.weight = 1;
ITEM.access = "1v";
ITEM.useText = "Open";
ITEM.category = "Storage"
ITEM.business = true;
ITEM.description = "A brown box, open it to reveal its contents.";

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	if (player:HasItemByID("satchel") and #player:GetItemsByID("satchel") >= 1) then
		Clockwork.player:Notify(player, "You've hit the satchel limit!");
		
		return false;
	end;
	
	player:GiveItem(Clockwork.item:CreateInstance("satchel"));
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();