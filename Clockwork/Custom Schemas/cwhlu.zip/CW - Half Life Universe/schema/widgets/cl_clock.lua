--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local WIDGET = {}

function WIDGET:WidgetInit()
	self:SetWidgetSize(256, 256)
	self.time = {Hours=0, Minutes=0, Seconds=0}
end

function WIDGET:ThinkTime()
	if (!self.lastMinute or self.lastMinute != Clockwork.time:GetMinute()) then
		self.lastMinute = Clockwork.time:GetMinute()
		self.lastMinuteTime = CurTime()
		print("Setting last min "..self.lastMinute.." - "..self.lastMinuteTime)
	end

	print(self.lastMinute.." - "..Clockwork.time:GetMinute())

	self.time = {
		Hours = Clockwork.time:GetHour(),
		Minutes = Clockwork.time:GetMinute(),
		Seconds = (CurTime() - self.lastMinuteTime)*60
	}
end

local mFace = Material("slidefuse/clock/face.png")
local mHour = Material("slidefuse/clock/hour.png")
local mMinute = Material("slidefuse/clock/minute.png")

local cWhite = Color(255, 255, 255)

function WIDGET:WidgetPaint(w, h)
	self:ThinkTime()
	surface.SetDrawColor(cWhite)
	
	//surface.DrawRect(-14, -14, 28, 28)

	surface.SetMaterial(mFace)
	surface.DrawTexturedRect(0, 0, 256, 256)

	surface.SetMaterial(mHour)
	surface.DrawTexturedRectRotated(128, 128, 210, 210, 0-((self.time.Hours/12 * 360)+((360/12)*(self.time.Minutes/60))+(360/12/60*self.time.Seconds/60)))

	surface.SetMaterial(mMinute)
	surface.DrawTexturedRectRotated(128, 128, 210, 210, 0-(self.time.Minutes/60 * 360 + 360/60*self.time.Seconds/60))
end

Schema.widget:Register("Clock", WIDGET)