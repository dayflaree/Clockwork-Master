--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local PANEL = {}

AccessorFunc(PANEL, "ContextMenu", "ContextMenu", FORCE_BOOL)

function PANEL:Init()

	self:SetPaintShadow(false)
	self:SetDraggable(true)
	self:ShowCloseButton(false)
	self:SetSizable(false)
	self:SetTitle("")

	if (self.WidgetInit) then
		self:WidgetInit()
	end

	self.panel = vgui.Create("DPanel", self)
	self.panel:SetPos(0, 24)

	self.panel.Paint = function(w, h) 
		if (self.WidgetPaint) then
			self:WidgetPaint(w, h)
		end
	end
end

function PANEL:SetWidgetSize(w, h)
	self:SetSize(w, h+24)
	self.panel:SetSize(w, h)
	self.panel:SetPos(0, 24)
end

local cBar = Color(255, 255, 255, 200)
local cBlack = Color(110, 110, 110, 200)
local cRed = Color(240, 140, 140, 200)
function PANEL:Paint(w, h)

	if (self:GetContextMenu()) then
		surface.SetDrawColor(cBar)
		surface.DrawRect(0, 0, w, 24)
	end

end

vgui.Register("widgetBase", PANEL, "DFrame")