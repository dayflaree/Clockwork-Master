--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local WIDGET = {}

function WIDGET:WidgetInit()
	self:SetWidgetSize(512, 128)


	local categoryList = vgui.Create("DPanelList", self);
	categoryList:EnableHorizontal(true);
	categoryList:SetAutoSize(true);
	categoryList:SetPadding(4);
	categoryList:SetSpacing(4);

	self.categoryList = categoryList
end

-- A function to handle unequipping for the panel.
function WIDGET:HandleUnequip(itemTable)
	if (itemTable.OnHandleUnequip) then
		itemTable:OnHandleUnequip(
		function(arguments)
			if (arguments) then
				Clockwork.datastream:Start(
					"UnequipItem", {itemTable("uniqueID"), itemTable("itemID"), arguments}
				);
			else
				Clockwork.datastream:Start(
					"UnequipItem", {itemTable("uniqueID"), itemTable("itemID")}
				);
			end;
		end);
	else
		Clockwork.datastream:Start(
			"UnequipItem", {itemTable("uniqueID"), itemTable("itemID")}
		);
	end;
end;

function WIDGET:SetInventory(categories, invPanel)
	self.inv = categories
	self.invPanel = invPanel
	self:Rebuild()
end

function WIDGET:Rebuild()

	self.categoryList:Clear()
	if (self.inv.equipment) then

		for k, v in pairs(self.inv.equipment) do
			
			table.sort(v.itemsList, function(a, b)
				return a("itemID") < b("itemID");
			end);
			
			for k2, v2 in pairs(v.itemsList) do
				local itemData = {
					itemTable = v2, OnPress = function()
						self:HandleUnequip(v2);
						self:Rebuild()
					end
				};
				
				self.itemData = itemData;
				self.categoryList:AddItem(
					vgui.Create("cwInventoryItem", self)
				);
			end;
		end;
	end
	self.built = true
end

Schema.widget:Register("Equipment", WIDGET)