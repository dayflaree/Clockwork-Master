--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SFName");
COMMAND.tip = "Set a user's Name.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])
	if (target) then
		Schema.dermaRequest:RequestString(player, "Name", "What should their new name be?", "", function(text)
			name = text;
			Clockwork.kernel:ServerLog(player:Name().." set "..target:Name().."'s name to "..name..".");
			
			Clockwork.player:SetName(target, name);
		end)
	else
		Clockwork.player:Notify(player, target.." is not a valid character!");
	end;
end;

COMMAND.pLabel = "Set Name"
COMMAND.pIcon = "icon16/table_edit.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);