--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

COMMAND = Clockwork.command:New();
COMMAND.tip = "Set your radio frequency.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (!Schema:PlayerIsCombine(player)) then
		local frequency = arguments[1];
		
		if (string.find(frequency, "^%d%d%d%.%d$")) then
			local start, finish, decimal = string.match(frequency, "(%d)%d(%d)%.(%d)");
			start = tonumber(start); finish = tonumber(finish); decimal = tonumber(decimal);
			
			if ( !player:HasItemByID("handheld_radio") ) then
				Clockwork.player:Notify(player, "You do not own a radio item!");
				return;
			end;
			
			if (start == 1 and finish > 0 and finish < 10 and decimal > 0 and decimal < 10) then
				player:SetCharacterData("Frequency", frequency);
				Clockwork.player:Notify(player, "You have set your radio frequency to "..frequency..".");
			else
				Clockwork.player:Notify(player, "The radio frequency must be between 101.1 and 199.9!");
			end;
		else
			Clockwork.player:Notify(player, "The radio frequency must look like xxx.x!");
		end;
	else
		Clockwork.player:Notify(player, "Your radio is combine-locked");
		player:SetCharacterData("Frequency", "911.9");
	end;
end;

Clockwork.command:Register(COMMAND, "SetFreq");