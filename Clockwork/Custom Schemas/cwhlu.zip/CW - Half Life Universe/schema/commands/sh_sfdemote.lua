--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SFDemote");
COMMAND.tip = "Demote a player from their user group.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])
	
	if (target) then
		local userGroup = target:GetClockworkUserGroup();
		
		if (userGroup != "user") then
			Clockwork.kernel:ServerLog(player:Name().." has demoted "..target:Name().." from "..userGroup.." to user.");
				target:SetClockworkUserGroup("user");
			Clockwork.player:LightSpawn(target, true, true);
		else
			Clockwork.player:Notify(player, "This player is only a user and cannot be demoted!");
		end;
	else
		Clockwork.player:Notify(player, "That is not a valid player!");
	end;
end;

COMMAND.pLabel = "Demote User"
COMMAND.pIcon = "icon16/user.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);