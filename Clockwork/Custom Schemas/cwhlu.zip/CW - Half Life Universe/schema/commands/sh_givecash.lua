﻿--[[
	? 2013 Slidefuse.net
	Half-Life Universe
--]]

local COMMAND = Clockwork.command:New("CharGiveCash");
COMMAND.tip = "Gives cash to a player";
COMMAND.text = "<string Target> <number Amount>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 2;
COMMAND.access = "s"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
		local target = Clockwork.player:FindByID( arguments[1] );
		
		if (target) then
			Clockwork.player:Notify(target, player:Name().." tickled your pockets with some wealth.")
			Clockwork.player:GiveCash(target, arguments[2], "Admin");
			Clockwork.player:Notify(player, "You've given "..arguments[2].." money to "..target:Name())
		else
			Clockwork.player:Notify(player, "There was an error finding the target you specified.")
		end
end;

COMMAND:Register();