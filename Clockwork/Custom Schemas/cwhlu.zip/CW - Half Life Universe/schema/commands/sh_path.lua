--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local COMMAND = Clockwork.command:New("Path");
COMMAND.tip = "Helps you out!";
COMMAND.text = "";
COMMAND.flags = CMD_DEFAULT;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local path = Path("Follow")
	local ent = ents.Create("cw_dummynextbot")
	ent:SetPos(player:GetPos() + player:GetForward()*90)
	ent:SetAngles(player:GetAngles())
	ent:Spawn()
	ent:Activate()

	path:SetMinLookAheadDistance(300)
	path:SetGoalTolerance(500)
	path:Compute(ent, Vector(3287, 682, 978))

	
	hook.Add("Think", "test", function()
		
		path:Draw()
		print("Updated path", path:GetLength(), ent:GetPos())
	end)
	print(path:GetLength())
	print("Pathed")
end;

COMMAND:Register();