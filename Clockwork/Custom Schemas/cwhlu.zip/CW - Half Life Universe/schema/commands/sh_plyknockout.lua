--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork

local COMMAND = Clockwork.command:New("plyKnockOut")
COMMAND.tip = "Knock a person out for x seconds"
COMMAND.text = "[x Seconds]"
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

function COMMAND:OnRun(player, arguments, entity)
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if target then
		Schema.dermaRequest:RequestString(player, "Seconds to knock out for", "How many seconds would you like the target to be knocked out for?", "", function(seconds)
			Clockwork.player:ServerLog(player:Nick() .. " has knocked out " .. target:Nick() .. " for " .. seconds .. " seconds!")

			Clockwork.player:SetRagdollState(target, RAGDOLL_FALLENOVER, seconds)
			Clockwork.player:Notify(target, "An administrator has knocked you out for " .. seconds .. " seconds!")
		end)
	else
		Clockwork.player:Notify(player, "The player you tried to find does not exist!")
	end
end

COMMAND:RegisterProperty(CMDFILTER_PLAYER)