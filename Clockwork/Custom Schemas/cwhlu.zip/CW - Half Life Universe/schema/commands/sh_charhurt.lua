﻿--[[
	2013 Slidefuse.net
	Half-Life Universe
--]]

local COMMAND = Clockwork.command:New("CharHurt");
COMMAND.tip = "Hurts you.";
COMMAND.text = "<number Amount>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	player:SetHealth(player:Health()-arguments[1]);
end;

COMMAND:Register();