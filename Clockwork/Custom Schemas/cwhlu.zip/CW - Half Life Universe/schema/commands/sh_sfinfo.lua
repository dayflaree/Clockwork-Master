--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("Informaion");
COMMAND.tip = "Get all of a player's information.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])
	if (target) then
		Clockwork.player:Notify(player, "Name:"..target:Name().."Steam Name:"..target:SteamName().." Steam ID:"..target:SteamID().."Steam ID:(64)"..target:SteamID64()..".");
		Clockwork.player:Notify(player, "Kills:"..target:Frags().."Deaths:"..target:Deaths().."Holding:"..target:GetActiveWeapon()".");
		Clockwork.player:Notify(player, "Health/Maxhealth:"..target:Health().."/"..target:GetMaxHealth().."Armor:"..target:Armor().."." );
	else
		Clockwork.player:Notify(player, "You did not select a valid player!");
	end;
end;

COMMAND.pLabel = "Player Info"
COMMAND.pIcon = "icon16/table_edit.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);