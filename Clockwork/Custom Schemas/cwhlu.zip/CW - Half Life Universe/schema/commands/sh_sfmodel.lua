--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SFModel");
COMMAND.tip = "Set a user's model.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if (target) then
		Schema.dermaRequest:RequestString(player, "Model", "What model would you like to set?", "models/", function(text)
			model = text;
			
			target:SetCharacterData("Model", model, true);
			target:SetModel(model);
			
			Clockwork.kernel:ServerLog(player:Name().." set "..target:Name().."'s model to "..model..".");
		end);
	else
		Clockwork.player:Notify(player, target.." is not a valid character!");
	end;

end;

COMMAND.pLabel = "Set Model"
COMMAND.pIcon = "icon16/palette.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);