--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("LockerSave");
COMMAND.tip = "Saves the locker configuration.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	Schema:SavePersonalStorage();
	Clockwork.player:Notify(player, "Saved the lockers.");
end;

COMMAND:Register();