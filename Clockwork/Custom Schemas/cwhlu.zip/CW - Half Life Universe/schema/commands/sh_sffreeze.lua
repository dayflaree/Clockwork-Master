--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork

local COMMAND = Clockwork.command:New("SFFreeze")
COMMAND.tip = "Freeze a player"
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

function COMMAND:OnRun(player, arguments, entity)
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if target then
		Clockwork.player:ServerLog(player:Name() .. " has froze '" .. target:Name() .. "'.")
		target:Freeze(true)
	else
		Clockwork.player:Notify(player, "The player you tried to find does not exist!")
	end
end
COMMAND.pLabel = "Player Freeze"
COMMAND.pIcon = "icon16/cut_red.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER)

local Clockwork = Clockwork

local COMMAND = Clockwork.command:New("SFUnFreeze")
COMMAND.tip = "Un-Freeze a player"
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

function COMMAND:OnRun(player, arguments, entity)
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if target then
		Clockwork.player:ServerLog(player:Name() .. " has unfroze '" .. target:Name() .. "'.")
		target:Freeze(false)
	else
		Clockwork.player:Notify(player, "The player you tried to find does not exist!")
	end
end
COMMAND.pLabel = "Player Un-Freeze"
COMMAND.pIcon = "icon16/cut_red.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER)