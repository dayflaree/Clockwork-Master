--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork

local COMMAND = Clockwork.command:New("SFForceGuide")
COMMAND.tip = "Forces the guide on a player."
COMMAND.flags = CMD_DEFAULT
COMMAND.access = "o"

function COMMAND:OnRun(player, arguments, entity)
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if target then
		target:SendLua("gui.OpenURL('http://slidefuse.net/aguideorwhatever')")
	else
		Clockwork.player:Notify(player, "The player you tried to find does not exist!")
	end
end
COMMAND.pLabel = "Force Guide"
COMMAND.pIcon = "icon16/table_edit.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER)