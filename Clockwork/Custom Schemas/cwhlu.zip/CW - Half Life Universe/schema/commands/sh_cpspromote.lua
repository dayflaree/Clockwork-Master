﻿--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local COMMAND = Clockwork.command:New("CPSPromote");
COMMAND.tip = "Promotes them through the ranks of the wonderful CPS!";
COMMAND.text = "<string Target>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;
COMMAND.access = "s"

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID( arguments[1] );
	
	if (target) then
		local order = Schema.rank:GetOrder(player)
		print(order .. " - ")
		local newRank = Schema.rank:FindByOrder(order+1)
		print(newRank)
		local newRankTable = Schema.rank:FindByID(newRank)
		PrintTable(newRankTable)

		if (newRank) then
			Schema.rank:PlayerSetRank(target, newRank)
		end
		Clockwork.player:Notify(target, "You have been promoted to "..newRankTable.name.." by "..player:Name())
		Clockwork.player:Notify(player, "You have promoted "..target:Name().." to rank "..newRankTable.name)
	else
		Clockwork.player:Notify(player, "There was an error finding the target you specified!")
	end
end;

COMMAND:Register();