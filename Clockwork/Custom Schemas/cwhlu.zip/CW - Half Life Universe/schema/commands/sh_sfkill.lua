--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlyKill");
COMMAND.tip = "Kill a player.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if (target:Alive()) then
		target:Kill()
		Clockwork.player:ServerLog(player:Name().."has killed " ..target:Name()..".");
	else
		Clockwork.player:Notify(target, "The target is already dead.");
	end
	
end;

COMMAND.pLabel = "Kill Player"
COMMAND.pIcon = "icon16/bomb.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);