--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SFKick");
COMMAND.tip = "Kick a player from the server.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "o";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments, entity)
	
	local target = entity or Clockwork.player:FindByID(arguments[1])

	if (target) then
		Clockwork.player:ServerLog(player:Name().." has kicked '"..target:Name().."'.");
			target:Kick();
		target.kicked = true;
	else
		Clockwork.player:Notify(player, "You did not select a valid player!");
	end;
end;

COMMAND.pLabel = "Kick Player"
COMMAND.pIcon = "icon16/cut_red.png"

COMMAND:RegisterProperty(CMDFILTER_PLAYER);