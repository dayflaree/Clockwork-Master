--[[
	© 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local COMMAND = Clockwork.command:New("LockerRemove");
COMMAND.tip = "Remove lockers at your target position.";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local trace = player:GetEyeTraceNoCursor();
	local removed = 0;
	
	for k, v in pairs(Schema.personalStorage) do
		if (v.position:Distance(trace.HitPos) <= 256) then
			if (IsValid(v.entity)) then
				v.entity:Remove();
			end;
			
			Schema.personalStorage[k] = nil;
			
			removed = removed + 1;
		end;
	end;
	
	if (removed > 0) then
		if (removed == 1) then
			Clockwork.player:Notify(player, "You have removed "..removed.." locker.");
		else
			Clockwork.player:Notify(player, "You have removed "..removed.." lockers.");
		end;
	else
		Clockwork.player:Notify(player, "There were no lockers near this position.");
	end;
	
	Schema:SavePersonalStorage();
end;

COMMAND:Register();