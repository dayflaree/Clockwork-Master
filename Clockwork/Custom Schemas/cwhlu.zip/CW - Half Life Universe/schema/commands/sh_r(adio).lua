--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

COMMAND = Clockwork.command:New();
COMMAND.tip = "Send a radio message out to other characters.";
COMMAND.text = "<string Text>";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_DEATHCODE, CMD_FALLENOVER)
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:IsPlayerCombine(player)) then
		player:SetCharacterData("Frequency", "911.9");
	end;
	Clockwork.player:SayRadio(player, table.concat(arguments, " "), true);
end;

Clockwork.command:Register(COMMAND, "R");