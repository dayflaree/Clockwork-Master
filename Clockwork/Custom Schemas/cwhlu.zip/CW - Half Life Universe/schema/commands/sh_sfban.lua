--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("SFBan");
COMMAND.tip = "Ban a user.";
COMMAND.text = "<string Name>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "a";

-- Called when the command has been run.
function COMMAND:OnRun(player, entity)
	local schemaFolder = Clockwork.kernel:GetSchemaFolder();
	
	
	Schema.dermaRequest:RequestString(player, "Duration", "How long would you like to ban them for? (Minutes)", "", function(text)
		duration = text;
		Schema.dermaRequest:RequestString(player, "Reason", "What is the reason for banning?", "", function(text)
			reason = text;	
			if (duration) then
				Clockwork.bans:Add(entity, duration * 60, reason, function(steamName, duration, reason)
					if (IsValid(player)) then
						if (steamName) then
							if (duration > 0) then
								local hours = math.Round(duration / 3600);
								
								if (hours >= 1) then
									Clockwork.kernel:ServerLog(player:Name().." has banned '"..steamName.."' for "..hours.." hour(s) ("..reason..").");
								else
									Clockwork.kernel:ServerLog(player:Name().." has banned '"..steamName.."' for "..math.Round(duration / 60).." minute(s) ("..reason..").");
								end;
							else
								Clockwork.kernel:ServerLog(player:Name().." has banned '"..steamName.."' permanently ("..reason..").");
							end;
						else
							Clockwork.player:Notify(player, "This is not a valid identifier!");
						end;
					end;
				end);
			else
				Clockwork.player:Notify(player, "This is not a valid duration!");
			end;	
		end)
	end)
end;

COMMAND.pLabel = "Ban User"
COMMAND.pIcon = "icon16/exclamation.png"

COMMAND:RegisterProperty(FILTER_PLAYER);