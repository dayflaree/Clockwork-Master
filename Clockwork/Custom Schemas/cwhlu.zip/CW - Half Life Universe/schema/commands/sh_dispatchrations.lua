--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

COMMAND = Clockwork.command:New();
COMMAND.tip = "Notifies rations are availble";
COMMAND.text = "";
COMMAND.flags = bit.bor(CMD_DEFAULT, CMD_FALLENOVER)
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if ( Schema:PlayerIsCombine(player) ) then
		Schema:SayDispatch(player, "Rations are now available at the distribution terminal.");
	else
		Clockwork.player:Notify(player, "You are not the Combine!");
	end;
end;

Clockwork.command:Register(COMMAND, "DispatchRations");