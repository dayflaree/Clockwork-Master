--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;
local Color = Color;
local vgui = vgui;
local math = math;

local PANEL = {};

-- A function to yeah.
function PANEL:Init()
	self.realLabel = vgui.Create("DLabel", self)
end

-- A few functions to re-route the data to the real label
function PANEL:SetFont(f)
	self.realLabel:SetFont(f)
end

function PANEL:SetRealText(t)
	self.realLabel:SetText(t)
	self.realLabel:SizeToContents()
end

function PANEL:GetRealText()
	return self.realLabel:GetText()
end

function PANEL:SetIcon(material)
	self.mIcon = Material(material)
end

function PANEL:OverrideTextColor(color)
	if (color) then
		self.OverrideColorNormal = color;
		self.OverrideColorHover = Color(math.max(color.r - 50, 0), math.max(color.g - 50, 0), math.max(color.b - 50, 0), color.a);
	else
		self.OverrideColorNormal = nil;
		self.OverrideColorHover = nil;
	end;
end;

-- A function to set whether the panel is disabled.
function PANEL:SetDisabled(disabled)
	self.Disabled = disabled;
end;

-- A function to get whether the panel is disabled.
function PANEL:GetDisabled()
	return self.Disabled;
end;

-- A function to set whether the panel is depressed.
function PANEL:SetDepressed(depressed)
	self.Depressed = depressed;
end;

-- A function to get whether the panel is depressed.
function PANEL:GetDepressed()
	return self.Depressed;
end;

-- A function to set whether the panel is hovered.
function PANEL:SetHovered(hovered)
	self.Hovered = hovered;
end;

-- A function to get whether the panel is hovered.
function PANEL:GetHovered()
	return self.Hovered;
end;

-- Called when the cursor has entered the panel.
function PANEL:OnCursorEntered()
	if (!self:GetDisabled()) then
		self:SetHovered(true);
		Clockwork.option:PlaySound("rollover");
	end;
	
	DLabel.ApplySchemeSettings(self);
end;

-- Called when the cursor has exited the panel.
function PANEL:OnCursorExited()
	self:SetHovered(false);
	DLabel.ApplySchemeSettings(self);
end;

-- Called when the mouse is pressed.
function PANEL:OnMousePressed(code)
	self:MouseCapture(true);
	self:SetDepressed(true);
end;

-- Called when the mouse is released.
function PANEL:OnMouseReleased(code)
	self:MouseCapture(false);
	
	if (!self:GetDepressed()) then
		return;
	end;
	
	self:SetDepressed(false);
	
	if (!self:GetHovered()) then
		return;
	end;
	
	if (code == MOUSE_LEFT and self.DoClick
	and !self:GetDisabled()) then
		self.DoClick(self);
	end;
end;

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
		panel:SetAlpha(255 - (delta * 255));
		
		if (animation.Finished) then
			panel:SetVisible(false);
				if (Callback) then
					Callback();
				end;
			self.animation = nil;
		end;
	end);
	
	if (self.animation) then
		self.animation:Start(speed);
	end;
	
	Clockwork.option:PlaySound("rollover");
end;

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	local xx, yy = self:GetPos()
	self.xx = xx
	self.yy = yy	
	self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
		panel:SetAlpha(delta * 255);
		self:SetPos(-1*self:GetWide() + self:GetWide()*delta, self.yy)
		
		if (animation.Finished) then
			if (Callback) then
				Callback();
			end;
			
			self.animation = nil;
		end;
	end);
	

	Clockwork.option:PlaySound("click_release");
	self:SetVisible(true);
end;

function PANEL:SetActive(speed, Callback)
	local width = self:GetWide()
	self.activeAnim = Derma_Anim("Activate Panel", self, function(panel, animation, delta, data)
		panel:SetWide(width + delta*20);
		//self:SetPos(-1*self:GetWide() + self:GetWide()*delta, self.yy)
		
		if (animation.Finished) then
			if (Callback) then
				Callback();
			end;
			
			self.activeAnim = nil;
		end;
	end);

	if (self.activeAnim) then
		self.activeAnim:Start(speed);
	end;
end

function PANEL:SetInactive(speed, Callback)
	local width = self:GetWide()
	self.activeAnim = Derma_Anim("Inactivate Panel", self, function(panel, animation, delta, data)
		panel:SetWide(width - delta*20);
		//self:SetPos(-1*self:GetWide() + self:GetWide()*delta, self.yy)
		
		if (animation.Finished) then
			if (Callback) then
				Callback();
			end;
			
			self.activeAnim = nil;
		end;
	end);

	if (self.activeAnim) then
		self.activeAnim:Start(speed);
	end;
end

function PANEL:Paint(w, h) 
	//surface.SetDrawColor(Color(40, 40, 40, 50))
	
	surface.SetDrawColor(Color(190, 190, 215, 160));
	surface.DrawRect(0, 0, w, h)

	if (self.Hovered) then
		surface.SetDrawColor(Clockwork.option:GetColor("information"))
	end

	local addY = 0
	if (self.Depressed) then
		addY = 4
	end

	if (self.mIcon) then
		render.PushFilterMag( TEXFILTER.ANISOTROPIC )
		render.PushFilterMin( TEXFILTER.ANISOTROPIC )

		surface.SetDrawColor(Color(50, 50, 50))
		if (self.Hovered) then
			surface.SetDrawColor(Color(140, 100, 180))
		end
		
		surface.SetMaterial(self.mIcon)
		local iconW = 32;
		local iconH = 32;
		local iconX = self:GetWide() - 53;
		local iconY = self:GetTall()/2 - iconH/2;
		surface.DrawTexturedRect(iconX, iconY, iconW, iconH)
		render.PopFilterMag()
		render.PopFilterMin()
	end
end;

-- A function to set the anim delay
function PANEL:SetFadeStart(t)
	self.animDelay = t
end

-- Called every frame.
function PANEL:Think()
	self:SetText("")

	local subtract = 26;

	if (self.Depressed) then
		self.realLabel:SetPos(self:GetWide()-self.realLabel:GetWide() - 6 - 32 - subtract - 4 + 4, (self:GetTall()-4)/2 - self.realLabel:GetTall()/2 + 4)
	else
		self.realLabel:SetPos(self:GetWide()-self.realLabel:GetWide() - 6 - 32 - subtract - 4, (self:GetTall()-4)/2 - self.realLabel:GetTall()/2)
	end
	

	if (self.animation and CurTime() >= self.animDelay ) then
		if (self.animation and !self.startedAnim) then
			self.startedAnim = true
			self.animation:Start(0.25);
		end;
		self.animation:Run();
	end;

	if (self.activeAnim) then
		self.activeAnim:Run()
	end
	
	local colorWhite = Clockwork.option:GetColor("white");
	local colorDisabled = Color(
		math.max(colorWhite.r - 50, 0),
		math.max(colorWhite.g - 50, 0),
		math.max(colorWhite.b - 50, 0),
		255
	);
	local colorInfo = Clockwork.option:GetColor("information");
	
	if (self:GetDisabled()) then
		self.realLabel:SetTextColor(self.OverrideColorHover or colorDisabled);
	elseif (self:GetHovered()) then
		self.realLabel:SetTextColor(self.OverrideColorHover or colorInfo);
	else
		self.realLabel:SetTextColor(self.OverrideColorNormal or colorWhite);
	end;

	self.realLabel:SetTextColor(Color(10, 10, 10))
	if (self:GetHovered()) then
		self.realLabel:SetTextColor(Color(140, 100, 180));
	end
	
	self.realLabel:SetExpensiveShadow(2, Color(150, 150, 150, 100));
end;

-- A function to set the panel's Callback.
function PANEL:SetCallback(Callback)
	self.DoClick = function(button)
		Clockwork.option:PlaySound("click");
		Callback(button);
	end;
end;


vgui.Register("cwMenuButton", PANEL, "DLabel");