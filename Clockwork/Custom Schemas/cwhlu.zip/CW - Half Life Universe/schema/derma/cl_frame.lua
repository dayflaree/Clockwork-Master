--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PANEL = {};

function PANEL:MakePanel()
	self:SetTitle("")
	self:SetSizable(false)
	self:SetDraggable(false)
	self:ShowCloseButton(false)

end

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255))
			
			if (animation.Finished) then
				panel:SetVisible(false)
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("rollover")
	else
		self:SetVisible(false)
		self:SetAlpha(0)
		
		if (Callback) then
			Callback()
		end
	end
end

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetVisible(true)
			panel:SetAlpha(delta * 255)
			
			if (animation.Finished) then
				self.animation = nil
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("click_release")
	else
		self:SetVisible(true)
		self:SetAlpha(255)
		
		if (Callback) then
			Callback()
		end
	end
end

function PANEL:AThink()
	self:InvalidateLayout(true)
	
	if (self.animation) then
		self.animation:Run()
	end
end
-- Called each frame.
function PANEL:Think()
	self:AThink()
end

vgui.Register("sfFrame", PANEL, "EditablePanel");

