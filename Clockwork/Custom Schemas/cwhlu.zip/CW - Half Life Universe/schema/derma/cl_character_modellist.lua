--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetTitle("")
	self:SetSizable(false)
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self.selectedIdx = 1
	self.characterPanels = {}
end

-- Called when the panel is painted.
function PANEL:Paint() end

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255))
			
			if (animation.Finished) then
				panel:SetVisible(false)
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("rollover")
	else
		self:SetVisible(false)
		self:SetAlpha(0)
		
		if (Callback) then
			Callback()
		end
	end
end

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetVisible(true)
			panel:SetAlpha(delta * 255)
			
			if (animation.Finished) then
				self.animation = nil
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("click_release")
	else
		self:SetVisible(true)
		self:SetAlpha(255)
		
		if (Callback) then
			Callback()
		end
	end
end

-- A function to clear the panel's panels.
function PANEL:Clear()
	for k, v in ipairs(self.characterPanels) do
		v:Remove()
	end
	
	self.characterPanels = {}
end

-- A function to add a panel to the panel.
function PANEL:AddPanel(panel)
	table.insert(self.characterPanels, panel)
	self:SetSelectedIdx(math.ceil(#self.characterPanels/2))
end

-- Called to get whether the previous button is disabled.
function PANEL:GetPreviousDisabled()
	return (self.characterPanels[self.selectedIdx - 1] == nil)
end

-- Called to get whether the next button is disabled.
function PANEL:GetNextDisabled()
	return (self.characterPanels[self.selectedIdx + 1] == nil)
end

-- A function to get the panel's character panels.
function PANEL:GetCharacterPanels()
	return self.characterPanels
end

-- A function to get the panel's selected model.
function PANEL:GetSelectedModel()
	return self.characterPanels[self.selectedIdx]
end

-- A function to manage a panel's targets.
function PANEL:ManageTargets(panel, position, alpha)
	if (!panel.TargetPosition) then
		panel.TargetPosition = position
	end
	
	if (!panel.TargetAlpha) then
		panel.TargetAlpha = alpha
	end
	
	local moveSpeed = math.abs(panel.TargetPosition - position) * 6
	local interval = moveSpeed * FrameTime()
	
	panel.TargetPosition = math.Approach(panel.TargetPosition, position, interval)
	panel.TargetAlpha = math.Approach(panel.TargetAlpha, alpha, interval)
	panel.Tar = math.Approach(panel.TargetAlpha, alpha, interval)
	panel:SetAlpha(panel.TargetAlpha)
	//panel.characterModel.modelPanel:SetColor(Color(255, 255, 255, panel.TargetAlpha))
	panel:SetPos(panel.TargetPosition, 0)
	//panel:SetSize(panel.TargetSize)
end

-- A function to set the panel's selected index.
function PANEL:SetSelectedIdx(index)
	self.selectedIdx = index
end

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true)
	
	if (self.animation) then self.animation:Run() end
	
	while (self.selectedIdx > #self.characterPanels) do
		self.selectedIdx = self.selectedIdx - 1
	end
	
	if (self.selectedIdx == 0) then self.selectedIdx = 1 end
	
	if (self.characterPanels[self.selectedIdx]) then
		local centerPanel = self.characterPanels[self.selectedIdx]
			centerPanel:SetActive(true)
		self:ManageTargets(centerPanel, (self:GetWide() / 2) - (centerPanel:GetWide() / 2), 255)
		
		local rightX = centerPanel.x + centerPanel:GetWide() + 16
		local leftX = centerPanel.x - 16
		
		for i = self.selectedIdx - 1, 1, -1 do
			local previousPanel = self.characterPanels[i]
			
			if (previousPanel) then
				previousPanel:SetActive(false)
					self:ManageTargets(previousPanel, leftX - previousPanel:GetWide(), (255 / self.selectedIdx)/2 * i)
				leftX = previousPanel.x - 16
			end
		end
		
		for k, v in ipairs(self.characterPanels) do
			if (k > self.selectedIdx) then
				v:SetActive(false)
					self:ManageTargets(v, rightX, (255 / ((#self.characterPanels + 1) - self.selectedIdx)) * ((#self.characterPanels + 1) - k)/2)
				rightX = v.x + v:GetWide() + 16
			end
		end
	end
end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	//self:SetPos(self:GetParent():GetWide()/8, 0)
	self:SetSize(self:GetParent():GetWide()-self:GetParent():GetWide()/4, (ScrH()/2 - 20) * 1.5)
end

vgui.Register("sfModelList", PANEL, "DFrame")


local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	local smallTextFont = Clockwork.option:GetFont("menu_text_small")
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny")
	local buttonsList = {}
	local colorWhite = Clockwork.option:GetColor("white")
	
	local customData = self:GetParent().customData

	for k, v in pairs(customData) do
		self[k] = v
	end
	

	self.active = false
	self.buttonPanels = {}
	self:SetPaintBackground(false)
	
	self.characterModel = vgui.Create("cwCharacterModel", self)
	self.characterModel:SetModel(self.model)
	self.characterModel:SetPos(0, 0)
	self.characterModel:SetSize(ScrH()/2 -20, ScrH()/2 - 20)

	local modelPanel = self.characterModel:GetModelPanel()
	
	-- Called when the character model is clicked.
	function modelPanel.DoClick(modelPanel)
		for k, v in ipairs(self:GetParent():GetCharacterPanels()) do
			if (v == self) then
				self:GetParent():SetSelectedIdx(k)
			end
		end
	end
	
	self.characterModel:SetPos(0, self.characterModel.y)
	
end

-- A function to set whether the panel is active.
function PANEL:SetActive(bActive)
	self.active = bActive
end

function PANEL:Paint()
	Clockwork.kernel:DrawGradient(GRADIENT_DOWN, 0, self:GetTall()/16, self:GetWide(), self:GetTall() - self:GetTall()/4, Color(80, 0, 255, (self.active and 200) or self:GetAlpha()/2))
end

-- Called each frame.
function PANEL:Think()
	local mult = 1
	if (self.active) then
		mult = 1.5
	end

	if (!self.sizeX) then
		self.sizeX = (ScrH()/4)
		self.sizeY = (self.characterModel.y + self.characterModel:GetTall() + 40)
		self.sizeM = ScrH()/2 -20
	end

	local moveSpeed = math.abs((ScrH()/4) * mult - self.sizeX) * 6
	local interval = moveSpeed * FrameTime()

	self.sizeX = math.Approach(self.sizeX, (ScrH()/4) * mult, interval)
	self.sizeY = math.Approach(self.sizeY, (self.characterModel.y + self.characterModel:GetTall() + 40) * mult, interval)
	self.sizeM = math.Approach(self.sizeM, (ScrH()/2 - 20) * mult, interval)
	self:SetSize(self.sizeX, self.sizeY)
	self.characterModel:SetSize(self.sizeM, self.sizeM)
end
	
vgui.Register("sfModelItem", PANEL, "DPanel")


local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetPaintBackground(false)
	
	self.modelPanel = vgui.Create("DModelPanel", self)
	self.modelPanel:SetAmbientLight(Color(255, 255, 255, 255))
	Clockwork.kernel:CreateMarkupToolTip(self.modelPanel)
	
	-- Called when the entity should be laid out.
	function self.modelPanel.LayoutEntity(p, entity)
		if (!p.ang) then
			p.ang = 0
			p.mod = 50
		end

		if (p.ang >= 360) then
			p.ang = 0
		end
		
		if (p.ang >= 25 and p.ang <= 315) then
			p.mod = math.Approach(p.mod, 600, 5000*FrameTime())
		else
			p.mod = math.Approach(p.mod, 10, 5000*FrameTime())
		end


		p.ang = p.ang + FrameTime()*p.mod

		entity:SetAngles( Angle( 0, p.ang,  0) )

		entity.isCharacter = true
	end
end

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255))
			
			if (animation.Finished) then
				panel:SetVisible(false)
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("rollover")
		
		return true
	else
		self:SetVisible(false)
		self:SetAlpha(0)
		
		if (Callback) then
			Callback()
		end
	end
end

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(delta * 255)
			
			if (animation.Finished) then
				self.animation = nil
			end
			
			if (animation.Finished and Callback) then
				Callback()
			end
		end)
		
		if (self.animation) then
			self.animation:Start(speed)
		end
		
		Clockwork.option:PlaySound("click_release")
		self:SetVisible(true)
		
		return true
	else
		self:SetVisible(true)
		self:SetAlpha(255)
		
		if (Callback) then
			Callback()
		end
	end
end

-- A function to set the alpha of the panel.
function PANEL:SetAlpha(alpha)
	local color = self.modelPanel:GetColor()
	self.modelPanel:SetColor(Color(color.r, color.g, color.b, alpha))
end

-- A function to get the alpha of the panel.
function PANEL:GetAlpha(alpha)
	return self.modelPanel:GetColor().a
end

-- Called each frame.
function PANEL:Think()
	local entity = self.modelPanel.Entity
	
	if (IsValid(entity)) then
		entity:SetPos(Vector(0, 0, 0))
	end
	
	if (self.animation) then
		self.animation:Run()
	end
	
	self:InvalidateLayout(true)
end

-- A function to get the panel's model panel.
function PANEL:GetModelPanel()
	return self.modelPanel
end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	self.modelPanel:SetSize(self:GetWide(), self:GetTall())
end

-- A function to set the model details.
function PANEL:SetDetails(details)
	self.modelPanel:SetMarkupToolTip(details)
end

-- A function to set the model weapon.
function PANEL:SetWeaponModel(weaponModel)
	if (!weaponModel and IsValid(self.weaponEntity)) then
		self.weaponEntity:Remove();
		return;
	end;
	
	if (!weaponModel and !IsValid(self.weaponEntity)
	or IsValid(self.weaponEntity) and self.weaponEntity:GetModel() == weaponModel) then
		return;
	end;
	
	if (IsValid(self.weaponEntity)) then
		self.weaponEntity:Remove();
	end;
	
	self.weaponEntity = ClientsideModel(weaponModel, RENDER_GROUP_OPAQUE_ENTITY);
	self.weaponEntity:SetParent(self.modelPanel.Entity);
	self.weaponEntity:AddEffects(EF_BONEMERGE);
end;

-- A function to set the model.
function PANEL:SetModel(model)

	self.modelPanel:SetModel(model)

	local entity = ents.CreateClientProp(model)
		entity:SetAngles(Angle(0, 0, 0))
		entity:SetPos(Vector(0, 0, 0))
		entity:SetModel(model)
		entity:Spawn()
		entity:Activate()
	entity:PhysicsInit(SOLID_VPHYSICS)
	
	local obbCenter = entity:OBBCenter()
		obbCenter.z = obbCenter.z * 1.09
	local distance = entity:BoundingRadius() * 1.2
	
	self.modelPanel:SetLookAt(obbCenter + Vector(0, 25, 0))
	self.modelPanel:SetCamPos(
		obbCenter + Vector(distance * 1.56, distance * 0.31, distance * 0.4)
	)
	
	entity:Remove()
	
	if (IsValid(self.modelPanel.Entity)) then
		local sequence = self.modelPanel.Entity:LookupSequence("idle")
		local menuSequence = Clockwork.animation:GetMenuSequence(model, true)
		local leanBackAnims = {"LineIdle01", "LineIdle02", "LineIdle03"}
		local leanBackAnim = self.modelPanel.Entity:LookupSequence(leanBackAnims[math.random(1, #leanBackAnims)])
		
		if (leanBackAnim > 0) then
			sequence = leanBackAnim
		end
		
		if (menuSequence) then
			menuSequence = self.modelPanel.Entity:LookupSequence(menuSequence)
			
			if (menuSequence > 0) then
				sequence = menuSequence
			end
		end
		
		if (sequence <= 0) then
			sequence = self.modelPanel.Entity:LookupSequence("Wave")
		end
		
		if (sequence <= 0) then
			sequence = self.modelPanel.Entity:LookupSequence("idle_unarmed")
		end
		
		if (sequence <= 0) then
			sequence = self.modelPanel.Entity:LookupSequence("idle1")
		end
		
		if (sequence <= 0) then
			sequence = self.modelPanel.Entity:LookupSequence("walk_all")
		end
		
		self.modelPanel.Entity:ResetSequence(sequence)
	end
end
	
vgui.Register("cwCharacterModel", PANEL, "DPanel")