--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	if (!Clockwork.theme:Call("PreCharacterMenuInit", self)) then
		local smallTextFont = Clockwork.option:GetFont("menu_text_small");
		local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny");
		local hugeTextFont = Clockwork.option:GetFont("menu_text_huge");
		local scrH = ScrH();
		local scrW = ScrW();
		
		self:SetPos(0, 0);
		self:SetSize(scrW, scrH);
		self:SetDrawOnTop(false);
		self:SetPaintBackground(false);
		self:SetMouseInputEnabled(true);
		
		self.titleLabel = vgui.Create("cwLabelButton", self);
		self.titleLabel:SetDisabled(true);
		self.titleLabel:SetFont(hugeTextFont);
		self.titleLabel:SetText(string.upper(Schema:GetName()));
		
		local schemaLogo = Clockwork.option:GetKey("schema_logo");
		
		self.subLabel = vgui.Create("cwLabelButton", self);
		self.subLabel:SetDisabled(true);
		self.subLabel:SetFont(smallTextFont);
		self.subLabel:SetText(string.upper(Schema:GetDescription()));
		self.subLabel:SizeToContents();
		
		if (schemaLogo == "") then
			self.titleLabel:SetVisible(true);
			self.titleLabel:SizeToContents();
			self.titleLabel:SetPos((scrW / 2) - (self.titleLabel:GetWide() / 2), scrH * 0.4);
			self.subLabel:SetPos((scrW / 2) - (self.subLabel:GetWide() / 2), self.titleLabel.y + self.titleLabel:GetTall() + 8);
		else
			self.titleLabel:SetVisible(false);
			self.titleLabel:SetSize(512, 256);
			self.titleLabel:SetPos((scrW / 2) - (self.titleLabel:GetWide() / 2), scrH * 0.4 - 128);
			self.subLabel:SetPos(self.titleLabel.x + (self.titleLabel:GetWide() / 2) - (self.subLabel:GetWide() / 2), self.titleLabel.y + self.titleLabel:GetTall() + 8);
		end;
		
		self.authorLabel = vgui.Create("cwLabelButton", self);
		self.authorLabel:SetDisabled(true);
		self.authorLabel:SetFont(tinyTextFont);
		self.authorLabel:SetText("DEVELOPED BY "..string.upper(Schema:GetAuthor()));
		self.authorLabel:SizeToContents();
		self.authorLabel:SetPos(self.subLabel.x + (self.subLabel:GetWide() - self.authorLabel:GetWide()), self.subLabel.y + self.subLabel:GetTall() + 4);
		
		self.createButton = vgui.Create("cwLabelButton", self);
		self.createButton:SetFont(smallTextFont);
		self.createButton:SetText("New Citizen");
		self.createButton:FadeIn(0.5);
		self.createButton:SetCallback(function(panel)
			if (table.Count(Clockwork.character:GetAll()) >= Clockwork.player:GetMaximumCharacters()) then
				return Clockwork.character:SetFault("You cannot create any more characters!");
			end;
			
			Clockwork.character:ResetCreationInfo();
			Clockwork.character:OpenNextCreationPanel();
		end);
		self.createButton:SizeToContents();
		self.createButton:SetMouseInputEnabled(true);
		self.createButton:SetPos(scrW * 0.25, 16);
		
		self.loadButton = vgui.Create("cwLabelButton", self);
		self.loadButton:SetFont(smallTextFont);
		self.loadButton:SetText("Character List");
		self.loadButton:FadeIn(0.5);
		self.loadButton:SetCallback(function(panel)
			self:OpenPanel("cwCharacterList", nil, function(panel)
				Clockwork.character:RefreshPanelList();
			end);
		end);
		self.loadButton:SetDisabled(true)
		self.loadButton:SizeToContents();
		self.loadButton:SetMouseInputEnabled(true);
		self.loadButton:SetPos(scrW * 0.75, 16);
		
		self.disconnectButton = vgui.Create("cwLabelButton", self);
		self.disconnectButton:SetFont(smallTextFont);
		self.disconnectButton:SetText("LEAVE");
		self.disconnectButton:FadeIn(0.5);
		self.disconnectButton:SetCallback(function(panel)
			if (Clockwork.Client:HasInitialized() and !Clockwork.character:IsMenuReset()) then
				Clockwork.character:SetPanelMainMenu();
				Clockwork.character:SetPanelOpen(false);
			else
				RunConsoleCommand("disconnect");
			end;
		end);
		self.disconnectButton:SizeToContents();
		self.disconnectButton:SetPos((scrW / 2) - (self.disconnectButton:GetWide() / 2), 16);
		self.disconnectButton:SetMouseInputEnabled(true);
		
		self.previousButton = vgui.Create("cwLabelButton", self);
		self.previousButton:SetFont(tinyTextFont);
		self.previousButton:SetText("<< PREVIOUS");
		self.previousButton:SetCallback(function(panel)
			if (!Clockwork.character:IsCreationProcessActive()) then
				local activePanel = Clockwork.character:GetActivePanel();
				
				if (activePanel and activePanel.OnPrevious) then
					activePanel:OnPrevious();
				end;
			else
				Clockwork.character:OpenPreviousCreationPanel()
			end;
		end);
		self.previousButton:SizeToContents();
		self.previousButton:SetMouseInputEnabled(true);
		self.previousButton:SetPos((scrW * 0.2) - (self.previousButton:GetWide() / 2), scrH * 0.9);
		
		self.nextButton = vgui.Create("cwLabelButton", self);
		self.nextButton:SetFont(tinyTextFont);
		self.nextButton:SetText("NEXT >>");
		self.nextButton:SetCallback(function(panel)
			if (!Clockwork.character:IsCreationProcessActive()) then
				local activePanel = Clockwork.character:GetActivePanel();
				
				if (activePanel and activePanel.OnNext) then
					activePanel:OnNext();
				end;
			else
				Clockwork.character:OpenNextCreationPanel()
			end;
		end);
		self.nextButton:SizeToContents();
		self.nextButton:SetMouseInputEnabled(true);
		self.nextButton:SetPos((scrW * 0.8) - (self.nextButton:GetWide() / 2), scrH * 0.9);
		
		self.cancelButton = vgui.Create("cwLabelButton", self);
		self.cancelButton:SetFont(tinyTextFont);
		self.cancelButton:SetText("Back to Menu");
		self.cancelButton:SetCallback(function(panel)
			self:ReturnToMainMenu();
		end);
		self.cancelButton:SizeToContents();
		self.cancelButton:SetMouseInputEnabled(true);
		self.cancelButton:SetPos((scrW * 0.5) - (self.cancelButton:GetWide() / 2), scrH * 0.9);
		
		self.characterModel = vgui.Create("cwCharacterModel", self);
		self.characterModel:SetSize(512, 512);
		self.characterModel:SetAlpha(0);
		self.characterModel:SetModel("models/error.mdl");
		self.createTime = SysTime();
		
		Clockwork.theme:Call("PostCharacterMenuInit", self)

		timer.Simple(3.5, function()
			self:OpenPanel("cwCharacterList", nil, function(panel)
				Clockwork.character:RefreshPanelList();
				self.loadButton:SetDisabled(false)
			end);
		end)
	end;
end;

-- A function to fade in the model panel.
function PANEL:FadeInModelPanel(model)
	local panel = Clockwork.character:GetActivePanel();
	local x, y = ScrW() - self.characterModel:GetWide() - 8, 16;
	
	if (panel) then
		x, y = panel.x + panel:GetWide() - 16, panel.y - 80;
	end;
	
	self.characterModel:SetPos(x, y);
	
	if (self.characterModel:FadeIn(0.5)) then
		self:SetModelPanelModel(model);
		return true;
	else
		return false;
	end;
end;

-- A function to fade out the model panel.
function PANEL:FadeOutModelPanel()
	self.characterModel:FadeOut(0.5);
end;

-- A function to set the model panel's model.
function PANEL:SetModelPanelModel(model)
	if (self.characterModel.currentModel != model) then
		self.characterModel.currentModel = model;
		self.characterModel:SetModel(model);
	end;
	
	local modelPanel = self.characterModel:GetModelPanel();
	local weaponModel = Clockwork.plugin:Call(
		"GetModelSelectWeaponModel", model
	);
	local sequence = Clockwork.plugin:Call(
		"GetModelSelectSequence", modelPanel.Entity, model
	);
	
	if (weaponModel) then
		self.characterModel:SetWeaponModel(weaponModel);
	else
		self.characterModel:SetWeaponModel(false);
	end;
	
	if (sequence) then
		modelPanel.Entity:ResetSequence(sequence);
	end;
end;

-- A function to return to the main menu.
function PANEL:ReturnToMainMenu()
	local panel = Clockwork.character:GetActivePanel();
	
	if (panel) then
		panel:FadeOut(0.5, function()
			Clockwork.character.activePanel = nil;
				panel:Remove();
			self:FadeInTitle();
		end);
	else
		self:FadeInTitle();
	end;
	
	self:FadeOutModelPanel();
	self:FadeOutNavigation();
end;

-- A function to fade out the navigation.
function PANEL:FadeOutNavigation()
	self.previousButton:FadeOut(0.5);
	self.cancelButton:FadeOut(0.5);
	self.nextButton:FadeOut(0.5);
end;

-- A function to fade in the navigation.
function PANEL:FadeInNavigation()
	self.previousButton:FadeIn(0.5);
	self.cancelButton:FadeIn(0.5);
	self.nextButton:FadeIn(0.5);
end;

-- A function to fade out the title.
function PANEL:FadeOutTitle()
	self.subLabel:FadeOut(0.5);
	self.titleLabel:FadeOut(0.5);
	self.authorLabel:FadeOut(0.5);
end;

-- A function to fade in the title.
function PANEL:FadeInTitle()
	self.subLabel:FadeIn(0.5);
	self.titleLabel:FadeIn(0.5);
	self.authorLabel:FadeIn(0.5);
end;

-- A function to open a panel.
function PANEL:OpenPanel(vguiName, childData, Callback)
	if (!Clockwork.theme:Call("PreCharacterMenuOpenPanel", self, vguiName, childData, Callback)) then
		local panel = Clockwork.character:GetActivePanel();
		
		if (panel) then
			panel:FadeOut(0.5, function()
				panel:Remove(); self.childData = childData;
				
				Clockwork.character.activePanel = vgui.Create(vguiName, self);
				Clockwork.character.activePanel:SetAlpha(0);
				Clockwork.character.activePanel:FadeIn(0.5);
				Clockwork.character.activePanel:MakePopup();
				Clockwork.character.activePanel:SetPos(0, 64);
				Clockwork.character.activePanel:SetSize(ScrW(), ScrH()-64)
				Clockwork.character.activePanel:MakePopup()
				
				if (Callback) then
					Callback(Clockwork.character.activePanel);
				end;
				
				if (childData) then
					Clockwork.character.activePanel.bIsCreationProcess = true;
					Clockwork.character:FadeOutNavigation();
				end;
			end);
		else
			self.childData = childData;
			self:FadeOutTitle();
			
			Clockwork.character.activePanel = vgui.Create(vguiName, self);
			Clockwork.character.activePanel:SetAlpha(0);
			Clockwork.character.activePanel:FadeIn(0.5);
			Clockwork.character.activePanel:SetPos(0, 64);
			Clockwork.character.activePanel:SetSize(ScrW(), ScrH()-64)
			Clockwork.character.activePanel:MakePopup()
			
			if (Callback) then
				Callback(Clockwork.character.activePanel);
			end;
			
			if (childData) then
				Clockwork.character.activePanel.bIsCreationProcess = true;
				Clockwork.character:FadeOutNavigation();
			end;
		end;
		
		--[[ Fade out the model panel, we probably don't need it now! --]]
		self:FadeOutModelPanel();
		
		Clockwork.theme:Call("PostCharacterMenuOpenPanel", self);
	end;
end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	if (!Clockwork.theme:Call("PreCharacterMenuPaint", self)) then
		local schemaLogo = Clockwork.option:GetKey("schema_logo");
		local subLabelAlpha = self.subLabel:GetAlpha();
		
		if (subLabelAlpha > 0) then
			if (!self.logoTextureID) then
				self.logoTextureID = Material("cwhlu/bannerv2.png");
			end;
			
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawRect(0, 0, w, h)
			
			surface.SetDrawColor(255, 255, 255, math.min(self:GetAlpha(), subLabelAlpha));
			surface.SetMaterial(self.logoTextureID);
			surface.DrawTexturedRect(self.titleLabel.x, self.titleLabel.y, 512, 256);
		end;
		
		Clockwork.theme:Call("PostCharacterMenuPaint", self)
	end;
	
	local backgroundColor = Clockwork.option:GetColor("background");
	local foregroundColor = Clockwork.option:GetColor("foreground");
	local colorTargetID = Clockwork.option:GetColor("target_id");
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny");
	local colorWhite = Clockwork.option:GetColor("white");
	local scrW, scrH = ScrW(), ScrH();
	local height = (self.createButton.y * 2) + self.createButton:GetTall();
	local x, y = x, 0;
	
	Clockwork.kernel:DrawSimpleGradientBox(0, 0, y, scrW, height, Color(
		backgroundColor.r, backgroundColor.g, backgroundColor.b, 100
	));
	
	surface.SetDrawColor(
		foregroundColor.r, foregroundColor.g, foregroundColor.b, 200
	);
	surface.DrawRect(0, y + height, scrW, 1);
	
	if (Clockwork.character:IsCreationProcessActive()) then
		local creationPanels = Clockwork.character:GetCreationPanels();
		local numCreationPanels = #creationPanels;
		local creationProgress = Clockwork.character:GetCreationProgress();
		local progressHeight = 20;
		local creationInfo = Clockwork.character:GetCreationInfo();
		local progressY = y + height + 1;
		local boxColor = Color(
			math.min(backgroundColor.r + 50, 255),
			math.min(backgroundColor.g + 50, 255),
			math.min(backgroundColor.b + 50, 255),
			100
		);
		
		Clockwork.kernel:DrawSimpleGradientBox(0, 0, progressY, scrW, progressHeight, boxColor);
			for i = 1, numCreationPanels do
				surface.SetDrawColor(
					foregroundColor.r, foregroundColor.g, foregroundColor.b, 150
				);
				surface.DrawRect((scrW / numCreationPanels) * i, progressY, 1, progressHeight);
			end;
		Clockwork.kernel:DrawSimpleGradientBox(
			0, 0, progressY, (scrW / 100) * creationProgress, progressHeight, colorTargetID
		);
		
		if (creationProgress > 0 and creationProgress < 100) then
			surface.SetDrawColor(
				foregroundColor.r, foregroundColor.g, foregroundColor.b, 200
			);
			surface.DrawRect((scrW / 100) * creationProgress, progressY, 1, progressHeight);
		end;
		
		for i = 1, numCreationPanels do
			local Condition = creationPanels[i].Condition;
			local textX = (scrW / numCreationPanels) * (i - 0.5);
			local textY = progressY + (progressHeight / 2);
			local color = Color(colorWhite.r, colorWhite.g, colorWhite.b, 200);
			
			if (Condition and !Condition(creationInfo)) then
				color = Color(colorWhite.r, colorWhite.g, colorWhite.b, 100);
			end;
			
			Clockwork.kernel:DrawSimpleText(creationPanels[i].friendlyName, textX, textY - 1, color, 1, 1);
		end;
		
		surface.SetDrawColor(
			foregroundColor.r, foregroundColor.g, foregroundColor.b, 200
		);
		surface.DrawRect(0, progressY + progressHeight, scrW, 1);
	end;
	
	return true;
end;

-- Called each frame.
function PANEL:Think()
	if (!Clockwork.theme:Call("PreCharacterMenuThink", self)) then
		local characters = table.Count(Clockwork.character:GetAll());
		local bIsLoading = Clockwork.character:IsPanelLoading();
		local schemaLogo = Clockwork.option:GetKey("schema_logo");
		local activePanel = Clockwork.character:GetActivePanel();
		local fault = Clockwork.character:GetFault();
		
		if (Clockwork.plugin:Call("ShouldDrawCharacterBackgroundBlur")) then
			Clockwork.kernel:RegisterBackgroundBlur(self, self.createTime);
		else
			Clockwork.kernel:RemoveBackgroundBlur(self);
		end;
		
		if (self.characterModel) then
			if (!self.characterModel.currentModel
			or self.characterModel.currentModel == "models/error.mdl") then
				self.characterModel:SetAlpha(0);
			end;
		end;
		
		if (!Clockwork.character:IsCreationProcessActive()) then
			if (activePanel) then
				if (activePanel.GetNextDisabled
				and activePanel:GetNextDisabled()) then
					self.nextButton:SetDisabled(true);
				else
					self.nextButton:SetDisabled(false);
				end;
				
				if (activePanel.GetPreviousDisabled
				and activePanel:GetPreviousDisabled()) then
					self.previousButton:SetDisabled(true);
				else
					self.previousButton:SetDisabled(false);
				end;
			end;
		else
			local previousPanelInfo = Clockwork.character:GetPreviousCreationPanel();
			
			if (previousPanelInfo) then
				self.previousButton:SetDisabled(false);
			else
				self.previousButton:SetDisabled(true);
			end;
			
			self.nextButton:SetDisabled(false);
		end;
		
		if (schemaLogo == "") then
			self.titleLabel:SetVisible(true);
		else
			self.titleLabel:SetVisible(false);
		end;
		
		if (characters == 0 or bIsLoading) then
			self.loadButton:SetDisabled(true);
		else
			self.loadButton:SetDisabled(false);
		end;
		
		if (characters >= Clockwork.player:GetMaximumCharacters()
		or Clockwork.character:IsPanelLoading()) then
			self.createButton:SetDisabled(true);
		else
			self.createButton:SetDisabled(false);
		end;
		
		if (Clockwork.Client:HasInitialized() and !Clockwork.character:IsMenuReset()) then
			self.disconnectButton:SetVisible(true)
			self.disconnectButton:SetText("CANCEL");
			self.disconnectButton:SizeToContents();
		else
			self.disconnectButton:SetVisible(false)
		end;
		
		if (self.animation) then
			self.animation:Run();
		end;
		
		self:SetSize(ScrW(), ScrH());
		
		Clockwork.theme:Call("PostCharacterMenuThink", self)
	end;
end;

vgui.Register("cwCharacterMenu", PANEL, "DPanel");

--[[
	Add a hook to control clicking outside of the active panel.
--]]

hook.Add("VGUIMousePressed", "Clockwork.character:VGUIMousePressed", function(panel, code)
	local characterPanel = Clockwork.character:GetPanel();
	local activePanel = Clockwork.character:GetActivePanel();
	
	if (Clockwork.character:IsPanelOpen() and activePanel
	and characterPanel == panel) then
		activePanel:MakePopup();
	end;
end);

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	self.selectedIdx = 1;

	self.characterPanels = {}
	self.isCharacterList = true
	
	Clockwork.character:FadeInNavigation()
end

-- Called when the panel is painted.
function PANEL:Paint() end

-- A function to clear the panel's panels.
function PANEL:Clear()
	for k, v in ipairs(self.characterPanels) do
		v:Remove()
	end
	
	self.characterPanels = {}
end

-- A function to add a panel to the panel.
function PANEL:AddPanel(panel)
	table.insert(self.characterPanels, panel)
end

-- Called each frame.
function PANEL:Think()
	self:InvalidateLayout(true)
	
	if (self.animation) then self.animation:Run() end
	
	if (!self.choseFirst) then
		for k, v in ipairs(self.characterPanels) do
			v:SetVisible(false)
			v:KillFocus()
			if (k > 1) then continue end
			v:SetVisible(true)
			v:RequestFocus()
		end
		self.choseFirst = true
	end

end

-- A function to make the panel fade out.
function PANEL:FadeOut(speed, Callback)
	if (self:GetAlpha() > 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetAlpha(255 - (delta * 255));
			
			if (animation.Finished) then
				panel:SetVisible(false);
			end;
			
			if (animation.Finished and Callback) then
				Callback();
			end;
		end);
		
		if (self.animation) then
			self.animation:Start(speed);
		end;
		
		Clockwork.option:PlaySound("rollover");
	else
		self:SetVisible(false);
		self:SetAlpha(0);
		
		if (Callback) then
			Callback();
		end;
	end;
end;

-- A function to make the panel fade in.
function PANEL:FadeIn(speed, Callback)
	if (self:GetAlpha() == 0 and (!self.animation or !self.animation:Active())) then
		self.animation = Derma_Anim("Fade Panel", self, function(panel, animation, delta, data)
			panel:SetVisible(true);
			panel:SetAlpha(delta * 255);
			
			if (animation.Finished) then
				self.animation = nil;
			end;
			
			if (animation.Finished and Callback) then
				Callback();
			end;
		end);
		
		if (self.animation) then
			self.animation:Start(speed);
		end;
		
		Clockwork.option:PlaySound("click_release");
	else
		self:SetVisible(true);
		self:SetAlpha(255);
		
		if (Callback) then
			Callback();
		end;
	end;
end;

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	self:SetPos(0, 64)
	self:SetSize(ScrW(), ScrH()-160)
end

-- Reloads the selected idx
function PANEL:Select()
	for k, v in ipairs(self.characterPanels) do
		v:SetVisible(false)
		v:KillFocus()
		if (k != self.selectedIdx) then continue end
		v:SetVisible(true)
		v:RequestFocus()
	end
end

-- Called by the prev/next buttons :>
function PANEL:OnPrevious()
	self.selectedIdx = math.Clamp(self.selectedIdx - 1, 1, #self.characterPanels)
	self:Select()
end

function PANEL:OnNext()
	self.selectedIdx = math.Clamp(self.selectedIdx + 1, 1, #self.characterPanels)
	self:Select()
end


vgui.Register("cwCharacterList", PANEL, "EditablePanel");


local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()

	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny");
	local hugeTextFont = Clockwork.option:GetFont("menu_text_huge");

	local buttonsList = {}
	local customData = self:GetParent().customData
	local colorWhite = Clockwork.option:GetColor("white")
	local buttonX = 20
	local buttonY = 0
	
	for k, v in pairs(customData) do
		self[k] = v
	end

	self:SetSize(ScrW(), ScrH()-64)
	self.buttonPanels = {}

	self.characterModel = vgui.Create("cwCharacterModel", self)
	self.characterModel:SetModel(self.model)
	self.characterModel:SetPos(0, 32)
	self.characterModel:SetSize(ScrH()-64, ScrH()-64)

	self.characterBox = vgui.Create("DPanel", self)
	self.characterBox:SetPos(ScrH()/2, 32)
	self.characterBox:SetSize(ScrW() - (ScrH()/2) - 32, ScrH()-128)
	self.characterBox.Paint = function() end

	self.nameLabel = vgui.Create("sfTitleGrad", self.characterBox)
	self.nameLabel:SetFont(hugeTextFont)
	self.nameLabel:SetText(self.name)
	self.nameLabel:SizeToContents()

	self.factionLabel = vgui.Create("sfTitleGrad", self.characterBox)
	self.factionLabel:SetFont(smallTextFont)
	self.factionLabel:SetText(self.faction)
	self.factionLabel:SizeToContents()
	
	self.descLabel = vgui.Create("sfTitleGrad", self.characterBox)
	self.descLabel:SetFont(smallTextFont)
	self.descLabel:SetText(self.details or "No Physical Description")
	self.descLabel:SizeToContents()	

	self.startButton = vgui.Create("cwEnterButton", self.characterBox)
	self.startButton:SetText("Enter the Universe as "..self.name)
	self.startButton:SetFont(smallTextFont)
	self.startButton:SetSize(512, 96)
	self.startButton:SetMouseInputEnabled(true)
	self.startButton:SetCallback(function(panel)
		Clockwork.datastream:Start("InteractCharacter", {characterID = self.characterID, action = "use"})
		surface.PlaySound("cwhlu/enter.mp3")
	end)

	self.removeButton = vgui.Create("cwLabelButton", self.characterBox)
	self.removeButton:SetText("Remove this character from the Universe")
	self.removeButton:OverrideTextColor(Color(197, 90, 90))
	self.removeButton:SetFont(tinyTextFont)
	self.removeButton:SizeToContents()

	self.removeButton:SetMouseInputEnabled(true)
	self.removeButton:SetCallback(function(action)
		Schema:DermaConfirm("Really remove this character from the universe?",
		function() Clockwork.datastream:Start("InteractCharacter", {characterID = self.characterID, action = "delete"}) Clockwork.character:GetPanel():ReturnToMainMenu() end,
		function() return end)
	end)

	local wide = self.nameLabel:GetWide()
	self.nameLabel:SetPos(0, 0)
	local y = self.nameLabel:GetTall() + 12

	self.factionLabel:SetPos(0, y)
	wide = math.max(wide, self.factionLabel:GetWide())
	y = y + self.factionLabel:GetTall() + 12

	self.descLabel:SetPos(0, y)
	wide = math.max(wide, self.descLabel:GetWide())
	y = y + self.descLabel:GetTall() + 12

	self.startButton:SetPos(0, y)
	wide = math.max(wide, self.startButton:GetWide())
	y = y + self.startButton:GetTall() + 12

	self.removeButton:SetPos(0, y)
	wide = math.max(wide, self.removeButton:GetWide())
	y = y + self.removeButton:GetTall() + 7


	self.nameLabel:SetWide(wide)
	self.factionLabel:SetWide(wide)
	self.descLabel:SetWide(wide)
	self.startButton:SetWide(wide)
	self.removeButton:SetWide(wide)
end

function PANEL:Paint()
end

vgui.Register("cwCharacterPanel", PANEL, "DPanel")

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()

	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny");
	local hugeTextFont = Clockwork.option:GetFont("menu_text_huge");

	local descExamples = {
		"'5.4\" Tall | White | Blue Eyes | Scar on right eye lid | Muscular Build'",
		"'Skimmed Skin | Bruise on right cheek bone | American accent | Black | Small build'"
	}	

	self.question = vgui.Create("cwLabelButton", self)
	self.question:SetFont(tinyTextFont)
	self.question:SetText("A brief physical description")
	self.question:FadeIn(0)
	self.question:SizeToContents()

	self.DExample = vgui.Create("DLabel", self)
	self.DExample:SetFont(tinyTextFont)
	self.DExample:SetColor( Color(150, 150, 150, 255) )
	self.DExample:SetText("Ex: " .. table.Random(descExamples))
	self.DExample:SizeToContents()

	self.info = Clockwork.character:GetCreationInfo()

	self.descinput = vgui.Create("DTextEntry", self)
	self.descinput:SetFont(smallTextFont)
	self.descinput:SetText("")

	self.nextbutton = vgui.Create("cwLabelButton", self)
	self.nextbutton:SetFont(hugeTextFont)
	self.nextbutton:SetText("Finish")
	self.nextbutton:FadeIn(0)
	self.nextbutton:SizeToContents()
	self.nextbutton:SetMouseInputEnabled(true)
	self.nextbutton.DoClick = function(p)
		Clockwork.character:OpenNextCreationPanel()
	end

	self.prevbutton = vgui.Create("cwLabelButton", self)
	self.prevbutton:SetFont(tinyTextFont)
	self.prevbutton:SetText("Go Back")
	self.prevbutton:FadeIn(0)
	self.prevbutton:SizeToContents()
	self.prevbutton:SetMouseInputEnabled(true)
	self.prevbutton.DoClick = function(p)
		Clockwork.character:OpenPreviousCreationPanel()
	end
	self.prevbutton:SetPos(32, ScrH()-self.prevbutton:GetTall()-32)


end

-- Called when the next button is pressed.
function PANEL:OnNext()
	self.info.physDesc = string.Replace(self.descinput:GetValue(), '"', "'") 
end

-- Called when the panel is painted.
function PANEL:Paint()
	local sw = self:GetWide()
	local sh = self:GetTall()

	local y = (sh/2 - 128) + self.DExample:GetTall() + 16
	Clockwork.kernel:DrawGradient(GRADIENT_RIGHT, sw/4, y, sw/2, 64, Color(200, 200, 200, 70))

 end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	local sw = self:GetWide()
	local sh = self:GetTall()

	self.question:SetPos(sw/4, sh/2 - 142 )
	self.DExample:SetPos(sw/4, sh/2 - 118 )
	local x = sw/4 + 16
	local y = (sh/2 - 128) + self.DExample:GetTall() + 32
	self.descinput:SetPos(x, y)
	self.descinput:SetSize(sw/2 - 32, 32)

	y = y + 64
	self.nextbutton:SetPos(self:GetWide()/2 - self.nextbutton:GetWide()/2, y)
end

vgui.Register("sfCharacterStageFour", PANEL, "sfFrame")

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()

	local smallTextFont = Clockwork.option:GetFont("menu_text_small");
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny");
	local hugeTextFont = Clockwork.option:GetFont("menu_text_huge");

	self.info = Clockwork.character:GetCreationInfo()

	self.title = vgui.Create("cwLabelButton", self)
	self.title:SetFont(hugeTextFont)
	self.title:SetText("Choose your model")
	self.title:FadeIn(0)
	self.title:SizeToContents()

	self.modelList = vgui.Create("sfModelList", self)
	local lowerGender = string.lower(self.info.gender)

	for k, v in pairs(Clockwork.faction.stored) do
		if (v.isDefault) then
			if (self.modelList and v.models[lowerGender]) then
				for k2, v2 in pairs(v.models[lowerGender]) do 
					local paths = string.Explode("/", v2)
					local name = paths[#paths]
					local parts = string.Explode(".", name)
					local name = parts[1]
					local name = string.Replace(name, "_", "")
					self.modelList.customData = {
						name = name,
						model = v2
					}
					local panel = vgui.Create("sfModelItem", self.modelList)
					if (IsValid(panel)) then
						self.modelList:AddPanel(panel)
					end
				end
			end
		end
	end

	self.nextbutton = vgui.Create("cwLabelButton", self)
	self.nextbutton:SetFont(tinyTextFont)
	self.nextbutton:SetText("Select this Model")
	self.nextbutton:FadeIn(0)
	self.nextbutton:SizeToContents()
	self.nextbutton:SetMouseInputEnabled(true)
	self.nextbutton.DoClick = function(p)
		Clockwork.character:OpenNextCreationPanel()
	end

	self.prevbutton = vgui.Create("cwLabelButton", self)
	self.prevbutton:SetFont(smallTextFont)
	self.prevbutton:SetText("Go Back")
	self.prevbutton:FadeIn(0)
	self.prevbutton:SizeToContents()
	self.prevbutton:SetMouseInputEnabled(true)
	self.prevbutton.DoClick = function(p)
		Clockwork.character:OpenPreviousCreationPanel()
	end
	self.prevbutton:SetPos(32, ScrH()-self.prevbutton:GetTall()-32)

end

-- Called when the panel is painted.
function PANEL:Paint() end

-- Called when the next button is pressed.
function PANEL:OnNext()
	local smodel = self.modelList:GetSelectedModel().model
	self.info.model = smodel
	if (!self.info.model) then
		Clockwork.character:SetFault("You did not choose a model, or the model that you chose is not valid!")
		return false
	end
	return true
end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	self.title:SetPos(32, 32)
	local y = self.title:GetTall() + 48
	self.modelList:SetPos(self:GetParent():GetWide()/8, y)
	local y = y + self.modelList:GetTall() + 16
	self.nextbutton:SetPos(self:GetWide()/2 - self.nextbutton:GetWide()/2, y)

end

vgui.Register("sfCharacterStageThree", PANEL, "sfFrame")

local PANEL = {}
PANEL.LastNames = {
"Petties","Leis","Gunther","Runnels","Shy","Stowe","Elswick","Landgraf","Toups","Maez","Riding","Ned","Gimenez",
"Elzey","Roll","Hillyer","Babineau","Evins","Devin","Ihle","Desalvo","Juliano","Stukes","Haubert","Delamora","Reddix",
"Willman","Espino","Castillo","Aberle","Riccio","Sweatt","Lagarde","Rowser","Arzu","Moultrie","Ferretti","Maier",
"Jacks","Lucero","Belgrave","Chynoweth","Monsour","Ellery","Tillson","Jorgensen","Jenks","Bufkin","Tillmon","Merlino",
"Bayn","Bearden","Ray","Craven","Finklestein","Rammist"}
PANEL.MaleNames = {
"Jamel","Filiberto","Fernando","Jerald","Barton","Kraig","Solomon","Walton","Rickey","Marlin","Ethan","Darius","Jack",
"Toney","Caleb","Mariano","Bradly","Claudio","Richie","Will","Anderson","Maria","Alexander","Jimmy","Dean","Gregorio",
"Dee","Myron","Hal","Hobert","Jeremiah","Wendell","William","Jan","Nathanial","Issac","Ray","Sean","Antonia","Blair",
"Stacey","Genaro","Freddie","Vincenzo","Damon","Terrence","Armand","Dorian","Lamont","Josef","Rorick","James","Steven",
"Dwayne","Bobby","Max"}
PANEL.FemaleNames = {
"Brittani","Mindi","Keira","Mari","Cecilia","Ilana","Mardell","Henriette","Virgina","Dottie","Retha","Angelique","Mahalia",
"Kallie","Clorinda","Grace","Alaine","Lyndsay","Wonda","Pilar","Estela","Shalon","Clarissa","Magnolia","Bree","Britta",
"Kristal","Paulette","Brandi","Jenette","Oralee","Aleen","Dawna","Hedwig","Charmaine","Shondra","Bethany","Ruthann",
"Tegan","Elva","Otelia","Meg","Belen","Xiomara","Tamara","Mariette","Toshiko","Danita","Delilah","Queenie"}
-- Called when the panel is initialized.
function PANEL:Init()

	local hugeTextFont = Clockwork.option:GetFont("menu_text_huge")
	local smallTextFont = Clockwork.option:GetFont("menu_text_small")
	local mediumTextFont = Clockwork.option:GetFont("menu_text_medium")
	local tinyTextFont = Clockwork.option:GetFont("menu_text_tiny")
	local largeTextFont = Clockwork.option:GetFont("menu_text_big")

	self.question = vgui.Create("cwLabelButton", self)
	self.question:SetFont(largeTextFont)
	self.question:SetText("What is your name?")
	self.question:FadeIn(0)
	self.question:SizeToContents()

	self.info = Clockwork.character:GetCreationInfo()

	self.fnameinput = vgui.Create("DTextEntry", self)
	self.fnameinput:SetFont(largeTextFont)
	if (self.info.gender == GENDER_FEMALE) then
		self.fnameinput:SetText(self.FemaleNames[math.random(0,#self.FemaleNames)])
	else
		self.fnameinput:SetText(self.MaleNames[math.random(0,#self.MaleNames)])
	end

	self.lnameinput = vgui.Create("DTextEntry", self)
	self.lnameinput:SetFont(largeTextFont)
	self.lnameinput:SetText(self.LastNames[math.random(0,#self.LastNames)])


	self.randomize = vgui.Create("cwLabelButton", self)
	self.randomize:SetFont(smallTextFont)
	self.randomize:SetText("Randomize")
	self.randomize:FadeIn(0)
	self.randomize:SizeToContents()
	self.randomize:SetMouseInputEnabled(true)
	self.randomize.DoClick = function(p)
		if (self.info.gender == GENDER_FEMALE) then
			self.fnameinput:SetText(self.FemaleNames[math.random(0,#self.FemaleNames)])
		else
			self.fnameinput:SetText(self.MaleNames[math.random(0,#self.MaleNames)])
		end
		self.lnameinput:SetText(self.LastNames[math.random(0,#self.LastNames)])
	end

	self.nextbutton = vgui.Create("cwLabelButton", self)
	self.nextbutton:SetFont(smallTextFont)
	self.nextbutton:SetText("Continue")
	self.nextbutton:FadeIn(0)
	self.nextbutton:SizeToContents()
	self.nextbutton:SetMouseInputEnabled(true)
	self.nextbutton.DoClick = function(p)
		Clockwork.character:OpenNextCreationPanel()
	end

	self.prevbutton = vgui.Create("cwLabelButton", self)
	self.prevbutton:SetFont(tinyTextFont)
	self.prevbutton:SetText("Go Back")
	self.prevbutton:FadeIn(0)
	self.prevbutton:SizeToContents()
	self.prevbutton:SetMouseInputEnabled(true)
	self.prevbutton.DoClick = function(p)
		Clockwork.character:OpenPreviousCreationPanel()
	end
	self.prevbutton:SetPos(32, ScrH()-self.prevbutton:GetTall()-32)

end

-- Called when the next button is pressed.
function PANEL:OnNext()
	self.info.forename = string.Replace(self.fnameinput:GetValue(), '"', "'")
	self.info.surname = string.Replace(self.lnameinput:GetValue(), '"', "'")
	
	if (self.info.forename == "" or self.info.surname == "") then
		Clockwork.character:SetFault("You did not choose a name, or the name that you chose is not valid!")
		return false
	end
	
	if (string.find(self.info.forename, "[%p%s%d]") or string.find(self.info.surname, "[%p%s%d]")) then
		Clockwork.character:SetFault("Your first ane last name must not contain punctuation, spaces or digits!")
		return false
	end
	
	if (!string.find(self.info.forename, "[aeiou]") or !string.find(self.info.surname, "[aeiou]")) then
		Clockwork.character:SetFault("Your first and last name must both contain at least one vowel!")
		return false
	end
	
	if (string.len(self.info.forename) < 2 or string.len(self.info.surname) < 2) then
		Clockwork.character:SetFault("Your first and last name must both be at least 2 characters long!")
		return false
	end
	
	if (string.len(self.info.forename) > 16 or string.len(self.info.surname) > 16) then
		Clockwork.character:SetFault("Your first and last name must not be greater than 16 characters long!")
		return false
	end

end

-- Called when the panel is painted.
function PANEL:Paint()
	local sw = self:GetWide()
	local sh = self:GetTall()

	local y = (sh/2 - 128) + self.question:GetTall() + 16
	Clockwork.kernel:DrawGradient(GRADIENT_RIGHT, sw/4, y, sw/2, 96, Color(200, 200, 200, 70))

 end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	local sw = self:GetWide()
	local sh = self:GetTall()

	self.question:SetPos(sw/4, sh/2 - 128)
	local x = sw/4 + 16
	local y = (sh/2 - 128) + self.question:GetTall() + 32
	self.fnameinput:SetPos(x, y)
	self.fnameinput:SetSize((sw/2 - 64)/2 - 16, 64)
	self.lnameinput:SetPos(x + self.fnameinput:GetWide() + 16, y)
	self.lnameinput:SetSize((sw/2 - 64)/2 - 16, 64)

	self.nextbutton:SetPos(x + sw/2 - self.nextbutton:GetWide(), y + 104)
	self.randomize:SetPos(sw/4, y + 84)
end

vgui.Register("sfCharacterStageTwo", PANEL, "sfFrame")

local PANEL = {}

-- Called when the panel is initialized.
function PANEL:Init()

	self.info = Clockwork.character:GetCreationInfo();

	self.male = vgui.Create("DImageButton", self)
	self.male.m_Image:SetMaterial(Material("slidefuse/charmale.png"))
	self.male:SetSize(256, 256)
	self.male:SetMouseInputEnabled(true)
	self.male.DoClick = function(p)
		self.gender = GENDER_MALE
		Clockwork.character:OpenNextCreationPanel()
	end

	self.female = vgui.Create("DImageButton", self)
	self.female.m_Image:SetMaterial(Material("slidefuse/charfemale.png"))
	self.female:SetSize(256, 256)
	self.female:SetMouseInputEnabled(true)
	self.female.DoClick = function(p)
		self.gender = GENDER_FEMALE
		Clockwork.character:OpenNextCreationPanel()
	end
end

-- Called when the next button is pressed.
function PANEL:OnNext()
	
	local gender = self.gender
	for k, v in pairs(Clockwork.faction.stored) do
		if (v.isDefault) then
			self.info.faction = v.name
			self.info.gender = gender
			return true
		end
	end
	return false
end

-- Called when the layout should be performed.
function PANEL:PerformLayout()
	local sw = self:GetWide()
	local sh = self:GetTall()

	self.male:SetPos(sw/2 - 384, sh/2 - 128)
	self.female:SetPos(sw/2 + 128, sh/2 - 128)
end

vgui.Register("sfCharacterStageOne", PANEL, "sfFrame")

Clockwork.datastream:Hook("cwCharacterRemove", function(data)
	local characters = Clockwork.character:GetAll();
	local characterID = data;
	
	if (table.Count(characters) == 0) then
		return;
	end;
	
		
	if (!characters[characterID]) then
		return;
	end;
	
	characters[characterID] = nil;
	
	if (!Clockwork.character:IsPanelLoading()) then
		Clockwork.character:RefreshPanelList();
	end;
	
	if (Clockwork.character:GetPanelList()) then
		if (table.Count(characters) == 0) then
			Clockwork.character:GetPanel():ReturnToMainMenu();
		end;
	end;
end);

Clockwork.datastream:Hook("SetWhitelisted", function(data)
	local whitelisted = Clockwork.character:GetWhitelisted();
	
	for k, v in pairs(whitelisted) do
		if (v == data[1]) then
			if (!data[2]) then
				whitelisted[k] = nil;
				
				return;
			end;
		end;
	end;
	
	if (data[2]) then
		whitelisted[#whitelisted + 1] = data[1];
	end;
end);

Clockwork.datastream:Hook("CharacterAdd", function(data)
	Clockwork.character:Add(data.characterID, data);
	
	if (!Clockwork.character:IsPanelLoading()) then
		Clockwork.character:RefreshPanelList();
	end;
end);

Clockwork.datastream:Hook("CharacterMenu", function(data)
	local menuState = data;

	if (menuState == CHARACTER_MENU_LOADED) then
		if (Clockwork.character:GetPanel()) then
			Clockwork.character:SetPanelLoading(false);
			Clockwork.character:RefreshPanelList();
		end;
	elseif (menuState == CHARACTER_MENU_CLOSE) then
		Clockwork.character:SetPanelOpen(false);
	elseif (menuState == CHARACTER_MENU_OPEN) then
		Clockwork.character:SetPanelOpen(true);
	end;
end);

Clockwork.datastream:Hook("cwCharacterOpen", function(data)
	Clockwork.character:SetPanelOpen(true);
	
	if (data) then
		Clockwork.character.isMenuReset = true;
	end;
end);

Clockwork.datastream:Hook("cwCharacterFinish", function(data)
	if (data.bSuccess) then
		Clockwork.character:SetPanelMainMenu();
		Clockwork.character:SetPanelOpen(false, true);
		Clockwork.character:SetFault(nil);
	else
		Clockwork.character:SetFault(data.fault);
	end;
end);

Clockwork.character.creationPanels = {};
Clockwork.character:RegisterCreationPanel("Gender", "sfCharacterStageOne")
Clockwork.character:RegisterCreationPanel("Name", "sfCharacterStageTwo")
Clockwork.character:RegisterCreationPanel("Appearance", "sfCharacterStageThree")
Clockwork.character:RegisterCreationPanel("Personalization", "sfCharacterStageFour")