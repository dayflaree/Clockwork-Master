--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local Clockwork = Clockwork;
local pairs = pairs;
local ScrH = ScrH;
local ScrW = ScrW;
local table = table;
local vgui = vgui;
local math = math;

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()

	self:SetSize(Clockwork.menu:GetWidth(), Clockwork.menu:GetHeight());
	
	self.inventoryList = vgui.Create("cwPanelList", self);
 	self.inventoryList:SetPadding(2);
 	self.inventoryList:SetSpacing(2);
 	self.inventoryList.Paint = function(p, w, h)
 		return true
 	end

	Clockwork.inventory.panel = self;
	Clockwork.inventory.panel:Rebuild();
end;



-- Called to by the menu to get the width of the panel.
function PANEL:GetMenuWidth()
	return ScrW() * 0.6;
end;

-- A function to handle unequipping for the panel.
function PANEL:HandleUnequip(itemTable)
	if (itemTable.OnHandleUnequip) then
		itemTable:OnHandleUnequip(
		function(arguments)
			if (arguments) then
				Clockwork.datastream:Start(
					"UnequipItem", {itemTable("uniqueID"), itemTable("itemID"), arguments}
				);
			else
				Clockwork.datastream:Start(
					"UnequipItem", {itemTable("uniqueID"), itemTable("itemID")}
				);
			end;
		end);
	else
		Clockwork.datastream:Start(
			"UnequipItem", {itemTable("uniqueID"), itemTable("itemID")}
		);
	end;
end;


-- A function to rebuild the panel.
function PANEL:Rebuild()
	self.inventoryList:Clear();

	self.inventoryList:AddItem(vgui.Create("cwInventoryWeight", self));
	
	local itemsList = {inventory = {}, equipment = {}};
	local categories = {inventory = {}, equipment = {}};
	
	for k, v in pairs(Clockwork.Client:GetWeapons()) do
		local itemTable = Clockwork.item:GetByWeapon(v);
		
		if (itemTable and itemTable.HasPlayerEquipped
		and itemTable:HasPlayerEquipped(Clockwork.Client, true)) then
			local itemCategory = itemTable("equippedCategory", itemTable("category"));
			itemsList.equipment[itemCategory] = itemsList.equipment[itemCategory] or {};
			itemsList.equipment[itemCategory][#itemsList.equipment[itemCategory] + 1] = itemTable;
		end;
	end;
	
	for k, v in pairs(Clockwork.inventory:GetClient()) do
		for k2, v2 in pairs(v) do
			local itemCategory = v2("category");
			
			if (v2.HasPlayerEquipped and v2:HasPlayerEquipped(Clockwork.Client, false)) then
				itemCategory = v2("equippedCategory", itemCategory);
				itemsList.equipment[itemCategory] = itemsList.equipment[itemCategory] or {};
				itemsList.equipment[itemCategory][#itemsList.equipment[itemCategory] + 1] = v2;
			else
				itemsList.inventory[itemCategory] = itemsList.inventory[itemCategory] or {};
				itemsList.inventory[itemCategory][#itemsList.inventory[itemCategory] + 1] = v2;
			end;
		end;
	end;
	
	for k, v in pairs(itemsList.equipment) do
		categories.equipment[#categories.equipment + 1] = {
			itemsList = v,
			category = k
		};
	end;
	
	table.sort(categories.equipment, function(a, b)
		return a.category < b.category;
	end);
	
	for k, v in pairs(itemsList.inventory) do
		categories.inventory[#categories.inventory + 1] = {
			itemsList = v,
			category = k
		};
	end;
	
	table.sort(categories.inventory, function(a, b)
		return a.category < b.category;
	end);
	
	Clockwork.plugin:Call("PlayerInventoryRebuilt", self, categories);

	local equipmentList = vgui.Create("DIconLayout")
	equipmentList:SetSpaceY(5)
	equipmentList:SetSpaceX(5)
	equipmentList:SetBorder(3)

	if (#categories.equipment > 0) then
		for k, v in pairs(categories.equipment) do
			table.sort(v.itemsList, function(a, b)
				return a("itemID") < b("itemID");
			end);
			
			for k2, v2 in pairs(v.itemsList) do
				local itemData = {
					itemTable = v2, OnPress = function()
						self:HandleUnequip(v2);
						Clockwork.inventory:Rebuild();
					end
				};
				
				self.itemData = itemData;
				equipmentList:Add(
					vgui.Create("cwInventoryItem", self)
				);
			end;
		end;
	end;

	local inventoryList = vgui.Create("DIconLayout")
	inventoryList:SetSpaceY(5)
	inventoryList:SetSpaceX(5)
	inventoryList:SetBorder(3)
	
	if (#categories.inventory > 0) then
		for k, v in pairs(categories.inventory) do
			table.sort(v.itemsList, function(a, b)
				return a("itemID") < b("itemID");
			end);
			
			for k2, v2 in pairs(v.itemsList) do
				local itemData = {
					itemTable = v2
				};
				
				self.itemData = itemData;
				inventoryList:Add(
					vgui.Create("cwInventoryItem", self)
				);
			end;
		end;
	end;

	self.inventoryList:AddItem(equipmentList)
	self.inventoryList:AddItem(inventoryList)
	self.inventoryList:InvalidateLayout(true);
end;

-- Called when the menu is opened.
function PANEL:OnMenuOpened()
	if (Clockwork.menu:IsPanelActive(self)) then
		self:Rebuild();
	end;
end;

-- Called when the panel is selected.
function PANEL:OnSelected() self:Rebuild(); end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	self:SetSize(w, ScrH() * 0.75);
	self.inventoryList:StretchToParent(4, 4, 4, 4);
end;

-- Called when the panel must be painted
function PANEL:Paint(w, h)
	surface.SetDrawColor(Color(69, 69, 69))
	surface.DrawRect(0, 0, w, h)

	return true;
end

-- Called each frame.
function PANEL:Think()
	for k, v in pairs(Clockwork.Client:GetWeapons()) do
		local weaponItem = Clockwork.item:GetByWeapon(v);
		if (weaponItem and !v.cwIsWeaponItem) then
			Clockwork.inventory:Rebuild();
			v.cwIsWeaponItem = true;
		end;
	end;
	
	self:InvalidateLayout(true);
end;

vgui.Register("cwInventory", PANEL, "EditablePanel");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetText("")
	self:SetSize(64, 64);
	
	local customData = self:GetParent().customData or {};
	local toolTip = "";
	self.customData = table.Copy(customData)
	
	if (customData.information) then
		if (type(customData.information) == "number") then
			customData.information = customData.information.."kg";
		end;
	end;
	
	if (customData.description) then
		toolTip = Clockwork.config:Parse(customData.description);
	end;
	
	if (toolTip == "") then
		toolTip = nil;
	end;
	
	self.nameLabel = vgui.Create("DLabel", self);
	self.nameLabel:SetPos(36, 2);
	self.nameLabel:SetText(customData.name);
	self.nameLabel:SetDark(true);
	self.nameLabel:SizeToContents();
	
	self.infoLabel = vgui.Create("DLabel", self);
	self.infoLabel:SetPos(36, 2);
	self.infoLabel:SetText(customData.information);
	self.infoLabel:SetDark(true);
	self.infoLabel:SizeToContents();
	
	self.spawnIcon = Clockwork.kernel:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self));
	self.spawnIcon:SetColor(customData.spawnIconColor);
	
	-- Called when the spawn icon is clicked.
	function self.spawnIcon.DoClick(spawnIcon)
		if (customData.Callback) then
			customData.Callback();
		end;
	end;
	
	self.spawnIcon:SetModel(customData.model, customData.skin);
	self.spawnIcon:SetToolTip(toolTip);
	self.spawnIcon:SetSize(32, 32);
end;

-- Called each frame.
function PANEL:Think()
	self.infoLabel:SetPos(self.infoLabel.x, 30 - self.infoLabel:GetTall());
end;
	
-- Called each paint think
function PANEL:Paint()
	--[[local mat = Material("cwhlu/itemicons/rev1/"..self.customData.model.."/64.png")
	surface.SetDrawColor(Color(255, 255, 255))
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(0, 0, 64, 64)]]--
end

vgui.Register("cwInventoryCustom", PANEL, "Panel");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local itemData = self:GetParent().itemData;
	self:SetSize(82, 78);
	self:SetText("")
	self.itemTable = itemData.itemTable;
	self.spawnIcon = Clockwork.kernel:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self));
	
	if (!itemData.OnPress) then
		self.spawnIcon.OpenMenu = function(spawnIcon)
			Clockwork.kernel:HandleItemSpawnIconRightClick(self.itemTable, spawnIcon);
		end;
	end;

	-- Called when the spawn icon is clicked.
	function self.spawnIcon.DoClick(spawnIcon)
		if (itemData.OnPress) then
			itemData.OnPress();
			return;
		end;
		
		Clockwork.kernel:HandleItemSpawnIconClick(self.itemTable, spawnIcon);
	end;

	self.spawnIcon.OnCursorEntered = function()
		self.hovering = true
	end

	self.spawnIcon.OnCursorExited = function()
		self.hovering = false
	end

	self.spawnIcon:IsMouseInputEnabled(false)
	
	local model, skin = Clockwork.item:GetIconInfo(self.itemTable);
		self.spawnIcon:SetModel(model, skin);
		self.spawnIcon:SetSize(64, 64);
		self.spawnIcon:SetPos(9, 0)
	self.cachedInfo = {model = model, skin = skin};
end;

function PANEL:OnCursorEntered() 
	self.hovering = true
end

function PANEL:OnCursorExited()
	self.hovering = false
end

-- Called each frame.
function PANEL:Think()
	self.spawnIcon:SetMarkupToolTip(Clockwork.item:GetMarkupToolTip(self.itemTable));
	self.spawnIcon:SetColor(self.itemTable("color"));
	
	--[[ Check if the model or skin has changed and update the spawn icon. --]]
	local model, skin = Clockwork.item:GetIconInfo(self.itemTable);
	
	if (model != self.cachedInfo.model or skin != self.cachedInfo.skin) then
		self.spawnIcon:SetModel(model, skin);
		self.cachedInfo.model = model
		self.cachedInfo.skin = skin;

		if (self.itemTable.spawnIconData) then
			self.spawnIcon:RebuildspawnIconEx(self.itemTable.spawnIconData)
		end
	end;
end;

function PANEL:DoClick()
	if (self.itemTable.OnPress) then
		self.itemTable:OnPress();
		return;
	end;
	Clockwork.kernel:HandleItemSpawnIconClick(self.itemTable, self);
end

-- Called each paint think
function PANEL:Paint(w, h)
	surface.SetDrawColor(Color(40, 40, 40))
	if (self.hovering) then
		local colorInfo = Clockwork.option:GetColor("information");
		surface.SetDrawColor(colorInfo)
	end
	surface.DrawRect(0, 0, w, h)

	draw.DrawText(self.itemTable("name"), "DermaDefault", w/2, h-14, Color(255, 255, 255), TEXT_ALIGN_CENTER)
end

vgui.Register("cwInventoryItem", PANEL, "DButton");

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local maximumWeight = Clockwork.player:GetMaxWeight();
	local colorWhite = Clockwork.option:GetColor("white");
	
	self.spaceUsed = vgui.Create("DPanel", self);
	self.spaceUsed:SetPos(1, 1);
	
	self.weight = vgui.Create("DLabel", self);
	self.weight:SetText("N/A");
	self.weight:SetTextColor(colorWhite);
	self.weight:SizeToContents();
	self.weight:SetExpensiveShadow(1, Color(0, 0, 0, 150));
	
	-- Called when the panel should be painted.
	function self.spaceUsed.Paint(spaceUsed)
		local inventoryWeight = Clockwork.inventory:CalculateWeight(
			Clockwork.inventory:GetClient()
		);
		local maximumWeight = Clockwork.player:GetMaxWeight();
		
		local color = Color(100, 100, 100, 255);
		local width = math.Clamp((spaceUsed:GetWide() / maximumWeight) * inventoryWeight, 0, spaceUsed:GetWide());
		local red = math.Clamp((255 / maximumWeight) * inventoryWeight, 0, 255) ;
		
		if (color) then
			color.r = math.min(color.r - 25, 255);
			color.g = math.min(color.g - 25, 255);
			color.b = math.min(color.b - 25, 255);
		end;
		
		Clockwork.kernel:DrawSimpleGradientBox(0, 0, 0, spaceUsed:GetWide(), spaceUsed:GetTall(), color);
		Clockwork.kernel:DrawSimpleGradientBox(0, 0, 0, width, spaceUsed:GetTall(), Color(139, 215, 113, 255));
	end;
end;

-- Called each frame.
function PANEL:Think()
	local inventoryWeight = Clockwork.inventory:CalculateWeight(
		Clockwork.inventory:GetClient()
	);
	self:SetTall(28)
	self.spaceUsed:SetSize(self:GetWide() - 2, self:GetTall() - 2);
	self.weight:SetText(inventoryWeight.."/"..Clockwork.player:GetMaxWeight().."kg");
	self.weight:SetPos(self:GetWide() / 2 - self.weight:GetWide() / 2, self:GetTall() / 2 - self.weight:GetTall() / 2);
	self.weight:SizeToContents();
end;
	
vgui.Register("cwInventoryWeight", PANEL, "DPanel");