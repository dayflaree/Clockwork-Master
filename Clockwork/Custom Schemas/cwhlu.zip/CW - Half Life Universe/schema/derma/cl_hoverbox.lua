--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local PANEL = {};

-- Called when the panel is initialized.
function PANEL:Init()
	local itemData = self:GetParent().itemData;
	self:SetSize(40, 40);
	self.itemTable = itemData.itemTable;
	self.spawnIcon = Clockwork.kernel:CreateMarkupToolTip(vgui.Create("cwSpawnIcon", self));

	if (!itemData.OnPress) then
		self.spawnIcon.OpenMenu = function(spawnIcon)
			Clockwork.kernel:HandleItemSpawnIconRightClick(self.itemTable, spawnIcon);
		end;
	end;
	
	-- Called when the spawn icon is clicked.
	function self.spawnIcon.DoClick(spawnIcon)
		if (itemData.OnPress) then
			itemData.OnPress();
			return;
		end;
		
		Clockwork.kernel:HandleItemSpawnIconClick(self.itemTable, spawnIcon);
	end;
	
	local model, skin = Clockwork.item:GetIconInfo(self.itemTable);
		self.spawnIcon:SetModel(model, skin);
		self.spawnIcon:SetSize(40, 40);
	self.cachedInfo = {model = model, skin = skin};
	if (self.itemTable.HoverBox) then
		self.spawnIcon:SetMouseInputEnabled(false)
	end
end;

function PANEL:OnCursorEntered()
	if (self.itemTable.HoverBox) then
		Schema.hoverBox:SetPaintFunction(function(x, y)
			self.itemTable:HoverBox(x, y)
		end)
	end
	
end

function PANEL:OnCursorExited()
	if (self.itemTable.HoverBox) then
		Schema.hoverBox:ClearPaintFunction()
	end
end

-- Called each frame.
function PANEL:Think()
	if (!self.itemTable.HoverBox) then
		self.spawnIcon:SetMarkupToolTip(Clockwork.item:GetMarkupToolTip(self.itemTable));
	end
	
	self.spawnIcon:SetColor(self.itemTable("color"));
	
	--[[ Check if the model or skin has changed and update the spawn icon. --]]
	local model, skin = Clockwork.item:GetIconInfo(self.itemTable);
	
	if (model != self.cachedInfo.model or skin != self.cachedInfo.skin) then
		self.spawnIcon:SetModel(model, skin);
		self.cachedInfo.model = model
		self.cachedInfo.skin = skin;
	end;
end;

vgui.Register("cwInventoryItem", PANEL, "DPanel");
