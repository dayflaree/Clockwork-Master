--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

DAYNIGHT = Clockwork.kernel:NewLibrary("DayNight");

if SERVER then
DAYNIGHT.StaticProps = {}
DAYNIGHT.Time = 0
DAYNIGHT.TimeScale = 1
DAYNIGHT.Resolution = 60
DAYNIGHT.DayLength = DAYNIGHT.Resolution * 24
DAYNIGHT.SunBegin = 6*DAYNIGHT.Resolution
DAYNIGHT.SunEnd = 19*DAYNIGHT.Resolution
DAYNIGHT.MoonBegin = 20*DAYNIGHT.Resolution
DAYNIGHT.MoonEnd = 5*DAYNIGHT.Resolution
DAYNIGHT.LightAtTime = {
    [0] = {
        pattern = string.byte("a"),
        SkyTop = Vector(0.005, 0.01, 0.025),
        SkyBottom = Vector(0.02, 0.025, 0.04),
        HDRScale = 0.05,
    },
    [6*DAYNIGHT.Resolution] = {
        pattern = string.byte("a"),
        SkyTop = Vector(0.005, 0.01, 0.025),
        SkyBottom = Vector(0.02, 0.025, 0.04),
        HDRScale = 0.05,
    },
	[8*DAYNIGHT.Resolution] = {
        pattern = string.byte("d"),
        SkyTop = Vector(0.05, 0.1, 0.25),
        SkyBottom = Vector(1, 0.3, 0.1),
        HDRScale = 0.1,
    },
    [9*DAYNIGHT.Resolution] = {
        pattern = string.byte("m"),
        SkyTop = Vector(0.2, 0.5, 1.0),
        SkyBottom = Vector(0.8, 1.0, 1.0),
        HDRScale = 0.2,
    },
    [17*DAYNIGHT.Resolution] = {
        pattern = string.byte("m"),
        SkyTop = Vector(0.2, 0.5, 1.0),
        SkyBottom = Vector(0.8, 1.0, 1.0),
        HDRScale = 0.2,
    },
	[18*DAYNIGHT.Resolution] = {
        pattern = string.byte("d"),
        SkyTop = Vector(0.05, 0.1, 0.25),
        SkyBottom = Vector(1, 0.3, 0.1),
        HDRScale = 0.1,
    },
    [20*DAYNIGHT.Resolution] = {
        pattern = string.byte("a"),
        SkyTop = Vector(0.005, 0.01, 0.025),
        SkyBottom = Vector(0.02, 0.025, 0.04),
        HDRScale = 0.05,
    },
    [24*DAYNIGHT.Resolution] = {
        pattern = string.byte("a"),
        SkyTop = Vector(0.005, 0.01, 0.025),
        SkyBottom = Vector(0.02, 0.025, 0.04),
        HDRScale = 0.05,
    },
} 

function DAYNIGHT.CacheLight()
	if (!DAYNIGHT.SkyPaint) then
		return
	end

	local trans = {}
	for k,v in pairs(DAYNIGHT.LightAtTime) do
		local up = DAYNIGHT.DayLength
		for k2,v2 in pairs(DAYNIGHT.LightAtTime) do
			if k2 < up and k2 > k then
				up = k2
			end
		end
		table.insert(trans, {k, up})
	end
	for k,v in pairs(trans) do
		local start = DAYNIGHT.LightAtTime[v[1]]
		local final = DAYNIGHT.LightAtTime[v[2]]
		local HDRScaleInc = (final.HDRScale - start.HDRScale) / (v[2] - v[1])
		local patternInc = (final.pattern - start.pattern) / (v[2] - v[1])
		local SkyTXInc = (final.SkyTop[1] - start.SkyTop[1]) / (v[2] - v[1])
		local SkyTYInc = (final.SkyTop[2] - start.SkyTop[2]) / (v[2] - v[1])
		local SkyTZInc = (final.SkyTop[3] - start.SkyTop[3]) / (v[2] - v[1])
		local SkyBXInc = (final.SkyBottom[1] - start.SkyBottom[1]) / (v[2] - v[1])
		local SkyBYInc = (final.SkyBottom[2] - start.SkyBottom[2]) / (v[2] - v[1])
		local SkyBZInc = (final.SkyBottom[3] - start.SkyBottom[3]) / (v[2] - v[1])
		for i=v[1]+1,v[2]-1 do
			DAYNIGHT.LightAtTime[i] = {}
			DAYNIGHT.LightAtTime[i].HDRScale = math.Approach( DAYNIGHT.LightAtTime[i-1].HDRScale, final.HDRScale, HDRScaleInc )
			DAYNIGHT.LightAtTime[i].pattern = math.Approach( DAYNIGHT.LightAtTime[i-1].pattern, final.pattern, patternInc )
			DAYNIGHT.LightAtTime[i].SkyTop = Vector(math.Approach( DAYNIGHT.LightAtTime[i-1].SkyTop[1], final.SkyTop[1], SkyTXInc ),
													math.Approach( DAYNIGHT.LightAtTime[i-1].SkyTop[2], final.SkyTop[2], SkyTYInc ),
													math.Approach( DAYNIGHT.LightAtTime[i-1].SkyTop[3], final.SkyTop[3], SkyTZInc ))
			DAYNIGHT.LightAtTime[i].SkyBottom = Vector(math.Approach( DAYNIGHT.LightAtTime[i-1].SkyBottom[1], final.SkyBottom[1], SkyBXInc ),
													math.Approach( DAYNIGHT.LightAtTime[i-1].SkyBottom[2], final.SkyBottom[2], SkyBYInc ),
													math.Approach( DAYNIGHT.LightAtTime[i-1].SkyBottom[3], final.SkyBottom[3], SkyBZInc ))
		end
	end
	return trans
end
function DAYNIGHT.TimeHook()
	if (!DAYNIGHT.SkyPaint) then
		return
	end
	
	DAYNIGHT.Time = Clockwork.time:GetMinute() + Clockwork.time:GetHour()*60
	if DAYNIGHT.Time < DAYNIGHT.SunEnd and DAYNIGHT.Time > DAYNIGHT.SunBegin then
		local fraction = math.TimeFraction(DAYNIGHT.SunBegin,DAYNIGHT.SunEnd,DAYNIGHT.Time)
		DAYNIGHT.SkyPaint:SetSunNormal( Angle( 150+(220*fraction), 0, 0 ):Forward() )
		if 180*fraction<=90 then
			DAYNIGHT.Shadow:Fire("SetAngles",180*fraction.." 0 0")
		elseif 180*fraction>90 then
			DAYNIGHT.Shadow:Fire("SetAngles",90-((180*fraction)/2).." 180 0")
		end
		if 200*fraction<50 then
			local fractionsun = math.TimeFraction(0,50,200*fraction)
			DAYNIGHT.SkyPaint:SetSunSize( 1 - 0.93*fractionsun )
		elseif 220*fraction>190 then
			local fractionsun = math.TimeFraction(190,220,220*fraction)
			DAYNIGHT.SkyPaint:SetSunSize( 0.93*fractionsun + 0.07 )
		else
			DAYNIGHT.SkyPaint:SetSunSize( 0.07 )
		end
		if 200*fraction<30 then
			DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,0.5, 0 ) )
		elseif 220*fraction>200 then
			DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,0.5, 0 ) )
		end
		if 200*fraction<50 and 200*fraction>30 then
			local fractionsun = math.TimeFraction(30,50,200*fraction)
			DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,0.5 + 0.5*fractionsun, 1*fractionsun ) )
		elseif 220*fraction<200 and 220*fraction>180 then
			local fractionsun = math.TimeFraction(180,200,220*fraction)
			DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,1 - 0.5*fractionsun, 1 - 1*fractionsun) )
		elseif 200*fraction<180 and 200*fraction>50 then
			DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,1, 1) )
		end
	elseif DAYNIGHT.Time > DAYNIGHT.MoonBegin then
		DAYNIGHT.SkyPaint:SetSunSize( 0.04 )
		local fraction = math.TimeFraction(DAYNIGHT.MoonBegin,DAYNIGHT.DayLength,DAYNIGHT.Time)
		DAYNIGHT.SkyPaint:SetSunNormal( Angle( 170+(100*fraction), 0, 0 ):Forward() )
	elseif DAYNIGHT.Time < DAYNIGHT.MoonEnd then
		DAYNIGHT.SkyPaint:SetSunSize( 0.04 )
		local fraction = math.TimeFraction(0,DAYNIGHT.MoonEnd,DAYNIGHT.Time)
		DAYNIGHT.SkyPaint:SetSunNormal( Angle( 270+(100*fraction), 0, 0 ):Forward() )
	else
		DAYNIGHT.SkyPaint:SetSunNormal( Vector( 0, 0, -1 ) )
		DAYNIGHT.SkyPaint:SetSunColor( Vector( 1,1, 1 ) )
		DAYNIGHT.SkyPaint:SetSunSize( 0.07 )
	end
	if DAYNIGHT.LightAtTime[DAYNIGHT.Time] and DAYNIGHT.SkyPaint then
		DAYNIGHT.SkyPaint:SetTopColor( DAYNIGHT.LightAtTime[DAYNIGHT.Time].SkyTop )
		DAYNIGHT.SkyPaint:SetBottomColor( DAYNIGHT.LightAtTime[DAYNIGHT.Time].SkyBottom )
		DAYNIGHT.SkyPaint:SetDuskColor( DAYNIGHT.LightAtTime[DAYNIGHT.Time].SkyBottom )
		DAYNIGHT.SkyPaint:SetHDRScale( DAYNIGHT.LightAtTime[DAYNIGHT.Time].HDRScale )
	elseif DAYNIGHT.SkyPaint then
		DAYNIGHT.CacheLight()
	end
	if DAYNIGHT.LightAtTime[DAYNIGHT.Time] and IsValid(DAYNIGHT.Light) then
		DAYNIGHT.Light:Fire( 'FadeToPattern' , string.char( math.ceil(DAYNIGHT.LightAtTime[DAYNIGHT.Time].pattern) ) , 0 );
		DAYNIGHT.Light:Activate( );
	else
		DAYNIGHT.Light = ents.FindByClass( "light_environment" )[1]
	end

	for k,v in pairs(DAYNIGHT.StaticProps) do
		if v[1]:GetPos()!=v[2] then
			v[1]:SetPos(v[2])
			local phys = v[1]:GetPhysicsObject()
 
			if phys and phys:IsValid() then
				phys:EnableMotion(false) -- Freezes the object in place.
			end
		end
		if v[1]:GetAngles()!=v[3] then
			v[1]:SetAngles(v[3])
			local phys = v[1]:GetPhysicsObject()
 
			if phys and phys:IsValid() then
				phys:EnableMotion(false) -- Freezes the object in place.
			end
		end
	end
end

hook.Add("Tick","DAYNIGHT.TimeHook",DAYNIGHT.TimeHook)

function DAYNIGHT.Init()
	DAYNIGHT.SkyPaint = ents.FindByName( "daynight_skypaint" )[1]
	DAYNIGHT.Shadow = ents.FindByName( "daynight_shadow" )[1]
	for k,v in pairs(ents.FindByClass( "prop_physics_multiplayer" )) do
		table.insert(DAYNIGHT.StaticProps, {v,v:GetPos(),v:GetAngles()})
	end

	if (!DAYNIGHT.SkyPaint) then
		print("[CWHLU] Not registering daynight, no skypaint ent")
		return
	end
	
	DAYNIGHT.SkyPaint:SetStarTexture( "skybox/clouds" )
	DAYNIGHT.SkyPaint:SetStarScale( 1 )
	DAYNIGHT.SkyPaint:SetStarFade( 0.25 )
	DAYNIGHT.SkyPaint:SetSunSize(0.07)
	DAYNIGHT.SkyPaint:SetSunColor( Vector( 1, 1, 1 ) )
end

hook.Add( "InitPostEntity", "DAYNIGHT.Init", DAYNIGHT.Init );
end
function DAYNIGHT.StopRemove(ply , trace, tool)
	local ent = trace.Entity
	if ent:GetClass() == "prop_physics_multiplayer" then
		//Disallow Tool Usage
		return false
	end
end
 
hook.Add("CanTool", "DAYNIGHT.StopRemove", DAYNIGHT.StopRemove)
