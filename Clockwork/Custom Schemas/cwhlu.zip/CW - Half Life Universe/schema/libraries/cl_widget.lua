--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

Schema.widget = Clockwork.kernel:NewLibrary("Widget")

Schema.widget.stored = {}
Schema.widget.buffer = {}

-- Called when we should open the context panels
function Schema.widget:Open()
	for _, v in pairs(self:GetBuffer()) do
		v:Enter()
	end
end

-- Called when we should close the context panels
function Schema.widget:Close()
	for _, v in pairs(self:GetBuffer()) do
		v:Exit()
	end
end

-- Called to request the entire panel buffer
function Schema.widget:GetBuffer()
	return self.buffer
end

-- Called to register a widget panel
function Schema.widget:Register(name, panel)
	vgui.Register("widget"..name, panel, "widgetBase") -- Add base widget in later!
	self.stored[name] = panel.info or {}
end

function Schema.widget:FindByID(name)
	return self.stored[name]
end

-- Widget Class (Individual panels, not stored register tables)
local CLASS_TABLE = {__index = CLASS_TABLE}

-- Called to load the panel into the widget
function CLASS_TABLE:Load(type)
	self._type = type
	if (!Schema.widget:FindByID(type)) then 
		Error("[Widgets] Attempt to index undefined context widget '"..type.."'")
	end
	
	self._panel = vgui.Create("widget"..type)
	self._panel:SetVisible(false)

	self:LoadData()
end

-- A function to get the cookie name
function CLASS_TABLE:CookieName()
	return "hluWidget_"..Clockwork.player:GetCharacterKey(Clockwork.Client).."_"..self:GetType()
end

-- A function to load and save the data
function CLASS_TABLE:LoadData()
	local widgetData = von.deserialize(cookie.GetString(self:CookieName()) or "")
	self._data = table.Copy(widgetData)

	-- If there's a position, lets set it to the panel
	if (self._data["pos"]) then
		print("Setting panel position: ", unpack(self._data["pos"]))
		self._panel:SetPos(self._data["pos"][1], self._data["pos"][2])
	end
end

-- A function to save the widget data to a cookie
function CLASS_TABLE:SaveData()
	self:UpdatePosition()
	cookie.Set(self:CookieName(), von.serialize(self._data))
end

-- A function to update the position in the data
function CLASS_TABLE:UpdatePosition()
	local x, y = self._panel:GetPos()
	self:SetDataKey("pos", {x, y})
end

-- Called when a widget should enter
function CLASS_TABLE:Enter()
	self._panel:SetVisible(true) --Animate later
	self._panel:SetContextMenu(true)
end

-- A few get/set functions
function CLASS_TABLE:GetType()
	return self._type
end

-- A function to get a data key
function CLASS_TABLE:GetDataKey(key)
	if (self._data[key]) then
		return self._data[key]
	end
end

-- A function to save a data key
function CLASS_TABLE:SetDataKey(key, value)
	self._data[key] = value
end

-- Called when a widget should exit
function CLASS_TABLE:Exit()
	self:SaveData()
	self._panel:SetVisible(false)
	self._panel:SetContextMenu(false)
end

-- A function to initialize a new panel on the context menu
function Schema.widget:NewInstance(type)
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE)
	object:Load(type)
	table.insert(self.buffer, object)
	return object
end
