--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

Schema.dermaRequest = Clockwork.kernel:NewLibrary("DermaRequest");
local REQUEST_INDEX = 0

if (SERVER) then

	Schema.dermaRequest.hooks = {}

	function Schema.dermaRequest:RequestString(player, title, question, default, Callback)
		local rID = self:GenerateID()
		Clockwork.datastream:Start(player, "dermaRequest_stringQuery", {id = rID, title = title, question = question, default = default})
		self.hooks[rID] = {Callback = Callback, player = player}
	end

	function Schema.dermaRequest:Message(player, message, title, button)
		Clockwork.datastream:Start(player, "dermaRequest_message", {message = message, title = title or nil, button = button or nil})
	end

	
	Clockwork.datastream:Hook("dermaRequestCallback", function(player, data)
		if (!Schema.dermaRequest:Validate(player, data)) then return end
		Schema.dermaRequest.hooks[data.id].Callback(data.recv)
		Schema.dermaRequest.hooks[data.id] = nil
	end)

	function Schema.dermaRequest:Validate(player, data)
		if (data.id and data.recv and self.hooks[data.id] and self.hooks[data.id].player == player) then
			return true
		end
		return false
	end

else

	Clockwork.datastream:Hook("dermaRequest_stringQuery", function(data)
		Derma_StringRequest(data.title, data.question, data.default, function(recv)
			Schema.dermaRequest:Send(data.id, recv)
		end)
	end)

	Clockwork.datastream:Hook("dermaRequest_message", function(data)
		local title = data.title or nil
		local button = data.button or nil
		Derma_Message(data.message, data.title, data.button)
	end)
	
	function Schema.dermaRequest:Send(id, recv)
		Clockwork.datastream:Start("dermaRequestCallback", {id = id, recv = recv})
	end

end

function Schema.dermaRequest:GenerateID()
	REQUEST_INDEX = REQUEST_INDEX + 1
	return os.time() + REQUEST_INDEX
end