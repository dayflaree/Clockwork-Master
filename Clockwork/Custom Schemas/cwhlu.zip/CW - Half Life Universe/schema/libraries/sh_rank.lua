--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

Schema.rank = {}
Schema.rank.stored = {}
Schema.rank.classes = {}
Schema.rank.lookup = {}
Schema.rank.order = {}
Schema.rank.orderLookup = {}
Schema.rank.specialRanks = {}

local RANK_INDEX = 0

function Schema.rank:DefineRankOrder()
	Schema.rank:DefineOrder(1, RANK_RCT)
	Schema.rank:DefineOrder(2, RANK_PTRU)
	Schema.rank:DefineOrder(3, RANK_SQDLD)
	Schema.rank:DefineOrder(4, RANK_SCTOFC)
	Schema.rank:DefineOrder(5, RANK_DIVCOM)
	Schema.rank:DefineOrder(6, RANK_OPSCOM)

	Schema.rank:DefineSpecial(RANK_SPCOPS)
	Schema.rank:DefineSpecial(RANK_SCN)
end

-- A function to register a new CPS rank
function Schema.rank:Register(data, prefix)
	self.stored[prefix] = data 
	print("[CWHLU] Regstering CPS Rank: "..prefix.." ("..data.name..")")

	RANK_INDEX = RANK_INDEX + 1

	-- Register as a Clockwork class as well.
	local CLASS = Clockwork.class:New(data.name)
		CLASS.factions = {FACTION_CPS}
		CLASS.wagesName = "Voucher"
		CLASS.description = data.description or "A CPS Unit"
		CLASS.defaultPhysDesc = data.defaultPhysdesc or "Wearing a shiny uniform"
		if (data.model) then
			CLASS.maleModel = data.model
		end
		CLASS.rank = RANK_INDEX
		CLASS.color = Color(60, 125, 215, 255);
	self.classes[prefix] = CLASS:Register()

	self.lookup[prefix] = RANK_INDEX

	return prefix;
end

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE};

-- A function to register a new class.
function CLASS_TABLE:Register()
	return Schema.rank:Register(self, self.prefix);
end;

-- A function to set the rank order in the hiearchy of the CPS
function Schema.rank:DefineOrder(order, rank)
	self.order[rank] = order
	self.orderLookup[order] = rank
end

function Schema.rank:DefineSpecial(rank)
	self.specialRanks[rank] = true
end

-- A function to get the player's rank order
function Schema.rank:GetOrder(player)
	local rank = self:GetPlayerRank(player)
	if (self.order[rank]) then
		return self.order[rank]
	else
		return -1;
	end
end

-- A function to get the player's rank order
function Schema.rank:FindByOrder(id)
	if (self.orderLookup[id]) then
		return self.orderLookup[id]
	else
		return false;
	end
end

-- A function to get a new class.
function Schema.rank:New(prefix)
	if (!prefix) then Error("No prefix defined for CPS Rank") end
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE);
	object.prefix = string.lower(prefix);
	return object;
end;

-- A function to lookup a rank prefix
function Schema.rank:GetPrefix(rank)
	local rank = string.lower(rank)
	if (self.lookup[rank]) then
		return rank
	end
	return false
end

-- A function to get a class
function Schema.rank:GetClass(rank)
	local rank = self:GetPrefix(rank) or rank
	return self.classes[rank]
end

-- A function to get by ID (standard function name :V)
function Schema.rank:FindByID(rank)
	local rank = self:GetPrefix(rank) or rank
	return self.stored[rank]
end

-- A function to check if a player is a CPS
function Schema.rank:IsCPS(player)
	//print (player:GetFaction(), FACTION_CPS)
	return (player:GetFaction() == FACTION_CPS)
end

-- A function to set a player to a rank
function Schema.rank:PlayerSetRank(player, rank)
	if (!self:IsCPS(player)) then return end
	local rank = self:GetPrefix(rank) or rank
	local rankTable = self:FindByID(rank)
	local class = self:GetClass(rank)

	player:SetModel(rankTable.model)
	Clockwork.class:Set(player, class)
	player:SetSharedVar("cpsRank", rank)
	player:SetCharacterData("cpsRank", rank)
	player:SetName("Ci18."..rank.."."..player:GetCharacterData("cpsID"))
end

-- A function to fetch the model of a rank
function Schema.rank:GetModel(rank)
	local rank = self:GetPrefix(rank) or rank
	local rankTable = self:FindByID(rank)
	return rankTable.model
end

-- A function to get the rank of a player
function Schema.rank:GetPlayerRank(player)
	print("rank " .. player:GetSharedVar("cpsRank"))
	return self:FindByID(player:GetSharedVar("cpsRank"))
end

-- A function to see if a player is a CPS rank
function Schema.rank:IsRank(player, rank)
	if (!rank) then
		return (self:IsCPS(player))
	end

	local checkRanks = {}
	if (type(rank) == type({})) then
		for _, v in pairs(rank) do
			table.insert(checkRanks, v)
		end
	else
		table.insert(checkRanks, rank)
	end

	for _, rank in pairs(checkRanks) do
		local rank = self:GetPrefix(rank) or rank
		if (!rank) then error("Rank "..rank.." non-existant") end
		if (self:IsCPS(player) and player:GetSharedVar("cpsRank") == rank) then
			return true
		end
	end

	return false
end