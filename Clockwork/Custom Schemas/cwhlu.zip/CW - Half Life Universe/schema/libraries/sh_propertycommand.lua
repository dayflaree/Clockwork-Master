--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local Clockwork = Clockwork;

CMDFILTER_PLAYER = function(player, entity) return (entity:IsPlayer()) end
CMDFILTER_PROP = function(player, entity) return (entity:GetClass() == "prop_physics") end

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE};

-- A function to register a new command.
function CLASS_TABLE:Register()
	return Clockwork.command:Register(self, self.name);
end;

function CLASS_TABLE:RegisterProperty(Filter)
	return Clockwork.command:RegisterProperty(self, self.name, Filter);
end;

-- A function to get a new command.
function Clockwork.command:New(name)
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE);
		object.name = name or "Unknown";
	return object;
end;

-- A function to register a new command for properties.
function Clockwork.command:RegisterProperty(data, name, Filter)
	local realName = string.gsub(name, "%s", "");
	local uniqueID = string.lower(realName);
	
	if (!self.stored[uniqueID]) then
		self.stored[uniqueID] = data;
		self.stored[uniqueID].name = realName;
		self.stored[uniqueID].text = data.text or "<none>";
		self.stored[uniqueID].flags = data.flags or 0;
		self.stored[uniqueID].access = data.access or "b";
		self.stored[uniqueID].arguments = data.arguments or 0;
		if (CLIENT) then
			self:AddHelp(self.stored[uniqueID]);
		end;
	end;

	self.stored[uniqueID].pOrder = data.pOrder or 0;
	self.stored[uniqueID].pIcon = data.pIcon or nil;
	self.stored[uniqueID].pLabel = data.pLabel or data.name;
	self.stored[uniqueID].pFilter = Filter

	local commandTable = self.stored[uniqueID];

	properties.Add(uniqueID, {
		MenuLabel	=	commandTable.pLabel,
		Order		=	commandTable.pOrder,
		MenuIcon	=	commandTable.pIcon,
		Filter		=	function(self, ent, ply) 
							if (!commandTable.pFilter) then return false end
							if (!Clockwork.player:HasFlags(ply, commandTable.access)) then return false end
							if (!IsValid(ent)) then return false end
							if (!commandTable.pFilter(ply, ent)) then return false end
							return true 
						end,
						
		Action		=	function( self, ent )
							self:MsgStart()
								net.WriteEntity( ent )
							self:MsgEnd()
						end,
						
		Receive		=	function( self, length, player )
							local entity = net.ReadEntity()
							if (Clockwork.plugin:Call("PlayerCanUseCommand", player, commandTable, {}, entity)) then
								if (Clockwork.player:HasFlags(player, commandTable.access)) then
									if (commandTable.OnRun) then
										local bSuccess, value = pcall(commandTable.OnRun, commandTable, player, {}, entity);

										if (!bSuccess) then
											ErrorNoHalt("[Clockwork] The "..commandTable.name.." (PROPERTY USE) command has failed to run on "..tostring(entity)..".\n");
											ErrorNoHalt(value.."\n");
										elseif (Clockwork.player:GetDeathCode(player, true)) then
											Clockwork.player:UseDeathCode(player, commandTable.name, {}, entity);
										end;
										
										if (bSuccess) then
											Clockwork.kernel:PrintLog(LOGTYPE_GENERIC, player:Name().." (PROPERTY USE) has used '"..commandTable.name.."' on "..tostring(entity));
											return value;
										end;
									end;
								end
							end
						end
	});

	return commandTable
end;