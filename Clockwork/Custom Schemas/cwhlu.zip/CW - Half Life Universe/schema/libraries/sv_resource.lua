--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

Schema.resource = Clockwork.kernel:NewLibrary("Resource")

function Schema.resource:AddDirectory(GamemodeDir, Dir)
	local FoundDir = false
	local files, dirs = file.Find("gamemodes/"..GamemodeDir.."/content/"..Dir.."/*", "MOD")
 	for k, v in pairs(dirs) do
		local File = Dir.."/"..v
		self:AddDirectory(GamemodeDir, File)
	end

	for k, v in pairs(files) do
		if (!string.find(v, ".bz2", 1, true) and !string.find(v, ".bat", 1, true)) then
			local File = Dir.."/"..v
			resource.AddFile(File)
		end
 	end
end

function Schema.resource:AddGamemode(gm)
	self:AddDirectory(gm, "models")
	self:AddDirectory(gm, "materials")
	self:AddDirectory(gm, "sound")
	self:AddDirectory(gm, "resource")
end