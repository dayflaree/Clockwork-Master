--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

Schema.hoverBox = Clockwork.kernel:NewLibrary("HoverBox")
Schema.hoverBox.x = 0
Schema.hoverBox.y = 0

function Schema.hoverBox:UpdatePosition()
	local x, y = gui.MouseX(), gui.MouseY()
	self.x = x
	self.y = y
end

function Schema.hoverBox:SetPaintFunction(Func)
	self.paintFunction = Func
end

function Schema.hoverBox:ClearPaintFunction(Func)
	self.paintFunction = nil
end

function Schema.hoverBox:Paint()
	cam.Start2D()
		if (self.paintFunction) then
			self.paintFunction(self.x, self.y)
		end
	cam.End2D()
end