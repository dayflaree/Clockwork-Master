--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

Clockwork.apartment = Clockwork.kernel:NewLibrary("Apartment");
Clockwork.apartment.doors = {}
Clockwork.apartment.whitelist = {"prop_physics","cw_clock"}
Clockwork.apartment.playerData = {}
Clockwork.apartment.data = {
	["Level 1 Room 1"] = {
		["Pos1"] = Vector(-1356,12,820),
		["Pos2"] = Vector(-1724,-476,948),
		["Group"] = "apart45l1"
	},
	["Level 1 Room 2"] = {
		["Pos1"] = Vector(-1356,500,820),
		["Pos2"] = Vector(-1724,12,948),
		["Group"] = "apart45l2"
	},
	["Level 2 Room 1"] = {
		["Pos1"] = Vector(-1356,12,948),
		["Pos2"] = Vector(-1724,-476,1076),
		["Group"] = "apart45l1"
	},
	["Level 2 Room 2"] = {
		["Pos1"] = Vector(-1356,500,948),
		["Pos2"] = Vector(-1724,12,1076),
		["Group"] = "apart45l2"
	},
	["Level 3 Room 1"] = {
		["Pos1"] = Vector(-1356,12,1076),
		["Pos2"] = Vector(-1724,-476,1200),
		["Group"] = "apart45l1"
	},
	["Level 3 Room 2"] = {
		["Pos1"] = Vector(-1356,500,1076),
		["Pos2"] = Vector(-1724,12,1200),
		["Group"] = "apart45l2"
	},
	["Level 4 Room 1"] = {
		["Pos1"] = Vector(-1356,12,1200),
		["Pos2"] = Vector(-1724,-476,1324),
		["Group"] = "apart45l1"
	},
	["Level 4 Room 2"] = {
		["Pos1"] = Vector(-1356,500,1200),
		["Pos2"] = Vector(-1724,12,1324),
		["Group"] = "apart45l2"
	},
	["Level 5 Room 1"] = {
		["Pos1"] = Vector(-1356,12,1324),
		["Pos2"] = Vector(-1724,-476,1448),
		["Group"] = "apart45l1"
	},
	["Level 5 Room 2"] = {
		["Pos1"] = Vector(-1356,500,1324),
		["Pos2"] = Vector(-1724,12,1448),
		["Group"] = "apart45l2"
	},
}

function Clockwork.apartment:SaveData()
	Clockwork.kernel:SaveSchemaData("apartments/"..game.GetMap(), Clockwork.apartment.playerData);
end

function Clockwork.apartment:LoadData()
	self.playerData = Clockwork.kernel:RestoreSchemaData("apartments/"..game.GetMap());
end

function Schema:DoorLoadDoorDataEach(data, v)
	Clockwork.apartment.doors[v] = data.apartment
	v.apartment = data.apartment
end

function Schema:DoorSaveDoorDataEach(data, v)
	data.apartment = v.apartment
	return data
end

function Schema:DoorGiven(player, door)
	if door.apartment and Clockwork.apartment.data[door.apartment] and Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)][Clockwork.apartment.data[door.apartment].Group] then
		local entities = Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)][Clockwork.apartment.data[door.apartment].Group];
		for k,v in pairs(entities) do
			local ent = ents.Create(v.class)
			ent:SetModel(v.model)
			ent:SetPos(v.pos + Clockwork.apartment.data[door.apartment].Pos1)
			ent:SetAngles(v.angle)
			ent:Spawn()
			Clockwork.entity:MakeSafe(ent, true, true, true);
		end
	end
end

function Schema:DoorTaken(player, door)

	if door.apartment and Clockwork.apartment.data[door.apartment] then
		local entities = {}
		for k,v in pairs(ents.FindInBox( Clockwork.apartment.data[door.apartment].Pos2, Clockwork.apartment.data[door.apartment].Pos1 )) do
			if table.HasValue(Clockwork.apartment.whitelist,v:GetClass()) then
				entities[#entities + 1] = {
					class = v:GetClass(),
					model = v:GetModel(),
					angle = v:GetAngles(),
					pos = v:GetPos() - Clockwork.apartment.data[door.apartment].Pos1
				}
				v:Remove()
			end
		end

		Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)] = Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)] or {}
		Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)][Clockwork.apartment.data[door.apartment].Group] = entities
		Clockwork.apartment:SaveData()
	end
end

Clockwork.datastream:Hook("DoorEditApartment", function(player, data)
	local door = data[1]
	if (door.apartment and !player:GetSharedVar("EditApartment")) then
		player:SetSharedVar("EditApartment", true)
		player:Give("weapon_physgun")
		door:Fire("Lock", "", 0);
		door:EmitSound("doors/door_latch3.wav");
	end
end)
Clockwork.datastream:Hook("DoorStopEditApartment", function(player, data)
	player:SetSharedVar("EditApartment", false)
	player:StripWeapon("weapon_physgun")
	local door = data[1]
	door:Fire("Unlock", "", 0);
	door:EmitSound("doors/door_latch3.wav");
	local entities = {}
	for k,v in pairs(ents.FindInBox( Clockwork.apartment.data[door.apartment].Pos2, Clockwork.apartment.data[door.apartment].Pos1 )) do
		if table.HasValue(Clockwork.apartment.whitelist,v:GetClass()) then
			entities[#entities + 1] = {
				class = v:GetClass(),
				model = v:GetModel(),
				angle = v:GetAngles(),
				pos = v:GetPos() - Clockwork.apartment.data[door.apartment].Pos1
			}
		end
	end

	Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)] = Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)] or {}
	Clockwork.apartment.playerData[player:SteamID()..Clockwork.player:GetCharacterID(player)][Clockwork.apartment.data[door.apartment].Group] = entities
	Clockwork.apartment:SaveData()
end)