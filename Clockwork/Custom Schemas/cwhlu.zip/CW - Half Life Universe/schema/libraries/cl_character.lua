--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

-- A function to fade in the navigation.
function Clockwork.character:FadeOutNavigation()
	if (IsValid(self.panel)) then
		self.panel:FadeOutNavigation();
	end;
end;