--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("SctOfc")

RANK.name = "Section Officer"
RANK.model = "models/leet_police_bt.mdl"

RANK_SCTOFC = RANK:Register()