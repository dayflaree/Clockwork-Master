--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("RCT")

RANK.name = "Recruit"
RANK.model = "models/urban_police.mdl"

RANK_RCT = RANK:Register()