--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("SqdLd")

RANK.name = "Squad Leader"
RANK.model = "models/policetrench.mdl"

RANK_SQDLD = RANK:Register()