--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("SCN")

RANK.name = "Scanner"
RANK.model = "models/combine_scanner.mdl"

RANK_SCN = RANK:Register()