--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("SpcOps")

RANK.name = "Special Operative"
RANK.model = "models/urban_police.mdl"

RANK_SPCOPS = RANK:Register()