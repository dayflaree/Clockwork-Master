--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("PtrU")

RANK.name = "Patrol Unit"
RANK.model = "models/urban_police.mdl"

RANK_PTRU = RANK:Register()