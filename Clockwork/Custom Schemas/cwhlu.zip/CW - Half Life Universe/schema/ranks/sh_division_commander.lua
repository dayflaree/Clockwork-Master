--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("DivCom")

RANK.name = "Divisional Commander"
RANK.model = "models/phoenix_police.mdl"

RANK_DIVCOM = RANK:Register()