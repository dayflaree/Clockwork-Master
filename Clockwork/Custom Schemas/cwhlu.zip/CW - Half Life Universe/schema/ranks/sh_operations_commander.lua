--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local RANK = Schema.rank:New("OpsCom")

RANK.name = "Operations Commander"
RANK.model = "models/phoenix_police.mdl"

RANK_OPSCOM = RANK:Register()