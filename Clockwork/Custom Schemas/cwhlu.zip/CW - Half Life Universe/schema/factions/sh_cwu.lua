--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local FACTION = Clockwork.faction:New("Civil Workers Union");

FACTION.useFullName = false;
FACTION.whitelist = true;
FACTION.material = "cwhlu/factions/citizen";
FACTION.models = {
	male = {"models/Humans/Group02/male_02.mdl",
 			"models/Humans/Group02/Male_04.mdl",
 			"models/Humans/Group02/male_06.mdl",
 			"models/Humans/Group02/male_08.mdl"},
	female = {"models/Humans/Group02/Female_02.mdl",
			  "models/Humans/Group02/Female_04.mdl",
			  "models/Humans/Group02/Female_07.mdl"}
};
FACTION.isDefault = false;

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	if (Schema:PlayerIsCombine(player)) then
		if (name) then
			local models = self.models[ string.lower( player:QueryCharacter("gender") ) ];
			
			if (models) then
				player:SetCharacterData("model", self.models[ math.random(#models) ], true);
				
				Clockwork.player:SetName(player, name, true);
			end;
		else
			return false, "You need to specify a name as the third argument!"; -- This clearly wasn't copy pasta'd.
		end;
	end;
end;

FACTION_CWU = FACTION:Register();