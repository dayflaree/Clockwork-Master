--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local FACTION = {};

FACTION.isCombineFaction = true;
FACTION.whitelist = true;
FACTION.material = "cwhlu/factions/mpf";
FACTION.models = {
	female = {"models/tnb/combine/metrocop_female.mdl"},
	male = {"models/tnb/combine/metrocop.mdl"}
};

-- Called when a player's name should be assigned for the faction.
function FACTION:GetName(player, character)
	local combineID = Clockwork.kernel:ZeroNumberToDigits(math.random(101, 990), 3)
	player:SetSharedVar("cpsRank", RANK_RCT)
	player:SetCharacterData("cpsRank", RANK_RCT)
	player:SetSharedVar("cpsID", combineID)
	player:SetCharacterData("cpsID", combineID)
	local prefix = Schema.rank:GetPrefix(player:GetCharacterData("cpsRank"))
	return "Ci18."..prefix.."-"..combineID;
end;
-- Called when a player's model should be assigned for the faction.
function FACTION:GetModel(player, character)
	if (character.gender == GENDER_MALE) then
		return self.models.male[1];
	else
		return self.models.female[1];
	end;
end;

-- Called when a player is transferred to the faction.
function FACTION:OnTransferred(player, faction, name)
	Clockwork.player:SetName( player, self:GetName( player, player:GetCharacter() ) );
	
	if (player:QueryCharacter("gender") == GENDER_MALE) then
		player:SetCharacterData("model", self.models.male[1], true);
	else
		player:SetCharacterData("model", self.models.female[1], true);
	end;
end;

FACTION_CPS = Clockwork.faction:Register(FACTION, "Civil Protection Service");