local Clockwork = Clockwork;
local PLUGIN = PLUGIN;

function PLUGIN:PlayerThink(player)
	local health = player:Health()

	if (health <= 80 and health >= 10) then
		if (!player.nextBleedTime or player.nextBleedTime <= CurTime()) then
			player:SetHealth(health - 5)
			player.nextBleedTime = CurTime() + 15
		end
	end
end