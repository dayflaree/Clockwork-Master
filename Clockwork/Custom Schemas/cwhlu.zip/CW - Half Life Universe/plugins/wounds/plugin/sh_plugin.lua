local PLUGIN = PLUGIN;

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

--[[
	Here we'll define the possible locations for bodily harm.
--]]

PLUGIN.bodyStructure = {name = "Body", children = {
		{name = "Head", children = {}},
		{name = "Torso", children = {
			{name = "Left Leg", children = {
				{name = "Left Foot", children = {}}
			}},
			{name = "Right Leg", children = {
				{name = "Right Foot", children = {}}
			}},
			{name = "Left Arm", children = {
				{name = "Left Hand", children = {}}
			}},
			{name = "Right Arm", children = {
				{name = "Right Hand", children = {}}
			}}
		}}
	}
}