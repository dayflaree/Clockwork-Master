--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

PANEL = {}

function PANEL:Init()
	
	self:SetSize(512, 512)
	self:Center()
	self:MakePopup()
	
end

vgui.Register("cwWounds", PANEL, "DFrame")