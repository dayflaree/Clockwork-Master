--[[
	© 2013 Slidefuse.net
	Half-Life Universe
--]]

local ITEM = Clockwork.item:New("accessory_base");
ITEM.name = "Citizen Identification Card";
ITEM.cost = 8;
ITEM.model = "models/dorado/tarjeta2.mdl";
ITEM.weight = 0.1;
ITEM.access = "v";
ITEM.useText = "Wear";
ITEM.category = "Identification";
ITEM.uniqueID = "citizen_id_card"
ITEM.business = false;
ITEM.description = "A standard issue identification card."
ITEM.customFunctions = {"Show"};
ITEM.isAttachment = true;
ITEM.attachmentBone = "ValveBiped.Bip01_R_Hand";
ITEM.attachmentOffsetAngles = Angle(0, 90, -10);
ITEM.attachmentOffsetVector = Vector(0, 0, 4);

function ITEM:GetDescription(item)
	if (true && (!true || false)) then
		return "A standard issue identification card. It belongs to "..self:GetData("playerName")
	end
end

ITEM:AddQueryProxy("description", ITEM.GetDescription)

ITEM:AddData("playerName", "", true);
ITEM:AddData("citizenID", "", true);

-- Called when a player wears the accessory.
function ITEM:OnWearAccessory(player, bIsWearing)
	if (bIsWearing) then
		Clockwork.player:CreateGear(player, "idcard", self);
		player:SetSharedVar("fakeRecog", true)
		Clockwork.chatBox:AddInRadius(player, "me", "clips an ID card to their shirt.", player:GetPos(), Clockwork.config:Get("talk_radius"):Get(), data)
	else
		local gearEntity = Clockwork.player:GetGear(player, "idcard");

		if (IsValid(gearEntity)) then
			gearEntity:Remove();
		end;

		player:SetSharedVar("fakeRecog", false)
		Clockwork.chatBox:AddInRadius(player, "me", "un-clips an ID card from their shirt.", player:GetPos(), Clockwork.config:Get("talk_radius"):Get(), data)
	end;
end

-- A function to get whether the attachment is visible.
function ITEM:GetAttachmentVisible(player, entity)
        if (player:GetSharedVar("fakeRecog")) then
                return true;
        end;
end;

function ITEM:OnCustomFunction(player, name)
	if (SERVER) then
		if (player:Alive() and !player:IsRagdolled() and (player:GetSharedVar("tied") == 0)) then
			if (name == "Show") then
				local entity = player:GetEyeTraceNoCursor().Entity;
				local target = Clockwork.entity:GetPlayer(entity);
				local text = "Name: "..self:GetData("playerName").." - Citizen ID: "..self:GetData("citizenID");

				if (target) then
					if (entity:GetPos():Distance( player:GetShootPos() ) <= 192) then
						Clockwork.chatBox:Add(target, player, "it", text)
					else
						Clockwork.player:Notify(player,"This character is too far away!");
					end;
				else
					Clockwork.player:Notify(player,"You must look at a character!");
				end;
			end;
		end;
	end
end;

ITEM:Register();

