--[[
	� 2013 Slidefuse.net
	Half-Life Universe
--]]

local PLUGIN = PLUGIN;

PLUGIN.allowAnimate = {
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Neck1"
}

Clockwork.datastream:Hook("sfRequestBones", function(player, data)
	local boneTable = {}
	for i = 0, player:GetBoneCount()-1 do
		local name = player:GetBoneName(i)
		if (player:GetBoneParent(i) <= 0) then continue end
		if (!player:BoneHasFlag(i, BONE_USED_BY_VERTEX_LOD0)) then continue end
		boneTable[i] = {name = name, parent = player:GetBoneParent(i)}
	end
	Clockwork.datastream:Start(player, "sfSendBones", boneTable)
end)