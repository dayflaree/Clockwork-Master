COMMAND = Clockwork.command:New();

COMMAND.tip = "Starts the animation builder.";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (!player.animationBuilding) then
		Clockwork.datastream:Start(player, "sfAnim_BuildStart", true)
		player:Lock()
	else
		Clockwork.player:Notify(player, "You're already building an animation!")
	end
end;

Clockwork.command:Register(COMMAND, "AnimBuilder");