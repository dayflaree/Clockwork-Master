StoreFlag
=================

Purpose
----

Any character with the 'N' flag will have access to all store items.