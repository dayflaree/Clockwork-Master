This schema is not finished. Minor things remain, such as the items, factions, classes and some other misc script.
This does not include the models, materials or any other assets used in the schema.