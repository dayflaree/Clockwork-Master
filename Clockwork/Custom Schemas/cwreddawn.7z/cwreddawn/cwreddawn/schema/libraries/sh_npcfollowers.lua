-- Library for NPC followers for players
local Clockwork = Clockwork;

Clockwork.NPC = Clockwork.kernel:NewLibrary("NPC");

function Clockwork.NPC:Spawn(ply, model)
	-- Nothing yet
end;