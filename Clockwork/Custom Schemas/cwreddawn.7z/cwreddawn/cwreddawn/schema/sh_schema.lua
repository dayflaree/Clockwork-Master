
-- Checks if a player is a National Guard
function Schema:PlayerIsNationalGuard(player)
	return player:GetFaction() == FACTION_NG;
end;

-- Include the rest of the gamemode
Clockwork.kernel:IncludePrefixed("cl_schema.lua");
Clockwork.kernel:IncludePrefixed("sv_schema.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

-- Variable setup
Clockwork.option:SetKey("default_date", {month = 3, year = 2037, day = 2});
Clockwork.option:SetKey("default_time", {minute = 0, hour = 0, day = 1});
Clockwork.option:SetKey("format_singular_cash", "%a");
Clockwork.option:SetKey("model_shipment", "models/items/item_item_crate.mdl");
Clockwork.option:SetKey("intro_image", "reddawn/512x256placeholder");
Clockwork.option:SetKey("schema_logo", "reddawn/512x256placeholder");
Clockwork.option:SetKey("format_cash", "%a %n");
-- Clockwork.option:SetKey("menu_music", "music/hl2_song19.mp3");
Clockwork.option:SetKey("name_cash", "Bullets");
Clockwork.option:SetKey("model_cash", "models/Items/357ammo.mdl");