-- Red Dawn server switcher

if (SERVER) then
	function ENT:Initialize()
		self:SetUseType(SIMPLE_USE);
		self:SetModel("models/props_lab/blastdoor001c.mdl");
		self:SetMoveType(MOVETYPE_NONE);
		self:PhysicsInit(SOLID_VPHYSICS);
		self:SetHealth(9999);
		self:SetSolid(SOLID_VPHYSICS);
	end;

	function ENT:Use(player)
		if (IsValid(player)) then
			if (player:IsPlayer()) then
				Schema:SwitchPlayer(player);
			end;
		end;
	end;
end;