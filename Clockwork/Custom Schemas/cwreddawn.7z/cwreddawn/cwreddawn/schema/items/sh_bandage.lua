--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New();
ITEM.name = "Bandage";
ITEM.cost = 8;
ITEM.model = "models/props_wasteland/prison_toiletchunk01f.mdl";
ITEM.weight = 0.5;
ITEM.access = "1v";
ITEM.useText = "Apply";
ITEM.category = "Medical"
ITEM.business = true;
ITEM.description = "A fresh packaged bandage, it is slightly damp.";
ITEM.customFunctions = {"Give"};

-- Called when a player uses the item.
function ITEM:OnUse(player, itemEntity)
	player:SetHealth( math.Clamp( player:Health() + 25, 0, player:GetMaxHealth() ) );
	
	Clockwork.plugin:Call("PlayerHealed", player, player, self);
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

if (SERVER) then
	function ITEM:OnCustomFunction(player, name)
		if (name == "Give") then
			local trace = player:GetEyeTraceNoCursor();
			if (IsValid(trace.Entity)) then
				if (trace.Entity:IsPlayer()) then
					trace.Entity:SetHealth(math.Clamp(trace.Entity:Health() + 25, 0, trace.Entity:GetMaxHealth()));
				else
					Clockwork.player:Notify(player, "Player must be on your crosshair!");
					player:GiveItem(self);
				end;
			else
				Clockwork.player:Notify(player, "Player must be on your crosshair!");
				player:GiveItem(self);
			end;
		end;
	end;
end;

ITEM:Register();