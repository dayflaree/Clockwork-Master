--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Flash";
	ITEM.cost = 25;
	ITEM.classes = {CLASS_NG};
	ITEM.model = "models/items/grenadeammo.mdl";
	ITEM.weight = 0.8;
	ITEM.uniqueID = "cw_flashgrenade";
	ITEM.business = true;
	ITEM.description = "A clean grey metal tube. It has a small red button on the top. The label reads 'FLASH GRENADE'.";
ITEM:Register();