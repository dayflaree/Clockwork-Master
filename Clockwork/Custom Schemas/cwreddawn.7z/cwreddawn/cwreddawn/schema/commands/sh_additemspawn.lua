local COMMAND = Clockwork.command:New("AddItemSpawn");
COMMAND.tip = "Adds an item spawn point.";
COMMAND.text = "<none>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsOwner(player)) then
		local eyetrace = player:GetEyeTraceNoCursor();
		Schema.spawnablePos[#Schema.spawnablePos + 1] = eyetrace.HitPos + Vector(0, 0, 30);
		Clockwork.player:Notify(player, "Item spawn added.");
	else
		Clockwork.player:Notify(player, "You must be a server owner to use this command!");
	end;
end;

COMMAND:Register();