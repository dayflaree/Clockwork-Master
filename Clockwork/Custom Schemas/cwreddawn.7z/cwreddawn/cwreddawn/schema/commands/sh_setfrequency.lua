local COMMAND = Clockwork.command:New("SetFrequency");
COMMAND.tip = "Set your radio frequency.";
COMMAND.text = "<float Frequency>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local freq = tonumber(arguments[1]);
	if (freq > 1000) or (freq < 1) or !(freq) then
		Clockwork.player:Notify(player, "Radio frequency must be between 1 and 999!");
		return;
	else
		player:SetCharacterData("radioFreq", freq);
	end;
end;

COMMAND:Register();