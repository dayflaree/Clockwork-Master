local COMMAND = Clockwork.command:New("Radio");
COMMAND.tip = "Talk into your radio.";
COMMAND.text = "<string Text>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local text = string.Implode(" ", arguments);
	Schema:RadioTalk(player, text);
end;

COMMAND:Register();