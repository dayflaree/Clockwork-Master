local COMMAND = Clockwork.command:New("AddZombieSpawn");
COMMAND.tip = "Adds a zombie spawn point.";
COMMAND.text = "<none>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 0;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	if (Schema:PlayerIsOwner(player)) then
		local eyetrace = player:GetEyeTraceNoCursor();
		Schema.zombieSpawns[#Schema.zombieSpawns + 1] = eyetrace.HitPos + Vector(0, 0, 30);
		Clockwork.player:Notify(player, "Zombie spawn added.");
	else
		Clockwork.player:Notify(player, "You must be a server owner to use this command!");
	end;
end;

COMMAND:Register();