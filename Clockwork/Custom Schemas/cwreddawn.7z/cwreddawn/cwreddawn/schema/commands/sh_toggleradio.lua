local COMMAND = Clockwork.command:New("ToggleRadio");
COMMAND.tip = "Toggles the state of the radio.";
COMMAND.text = "<none>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.arguments = 1;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local radioOn = player:GetCharacterData("radioOn");
	if (radioOn) then
		player:SetCharacterData("radioOn", false);
		Clockwork.player:Notify(player, "Radio turned off.");
	else
		player:SetCharacterData("radioOn", true);
		Clockwork.player:Notify(player, "Radio turned on.");
	end;
end;

COMMAND:Register();