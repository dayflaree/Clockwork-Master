Schema.spawnableItems = {};
--[[Schema.spawnablePos = {};
Schema.zombieSpawns = {};]]--

-- A function to handle handheld radios
function Schema:RadioTalk(player, text)
	if !(player:GetCharacterData("radioFreq")) then
		Clockwork.player:Notify("You need to specify a radio frequency!");
	else
		for k, v in pairs(player.GetAll()) do
			if (v:GetCharacterData("radioFreq") == player:GetCharacterData("radioFreq")) and (v:GetCharacterData("radioOn")) and !(player:SteamID() == v:SteamID()) then
				Clockwork.player:Notify(v, player:Nick() .. " radios in \"" .. text .. "\"");
			end;
		end;
	end;
end;

-- Checks if a spawnpoint is suitable
function Schema:ZombieSpawnSuitable(pos)
	for k, v in pairs(player.GetAll()) do
		if (v:IsLineOfSightClear(pos)) then
			return false;
		end;
	end;
	return true;
end;

-- Spawns a zombie, derp
function Schema:SpawnZombie()
	local pos = self.zombieSpawns[math.random(1, #self.zombieSpawns)];
	local rand = math.random(1, 20);

	if (game.GetMap() == "rp_apocalypse") then
		print("[Zombie Spawns] Zombie spawned.");
		if (rand >= 10) then
			local zambie = ents.Create("npc_zombie");
			zambie:SetPos(pos);
			zambie:Spawn();
			zambie:Activate();
		elseif (rand < 6) then
			local zambie = ents.Create("npc_fastzombie");
			zambie:SetPos(pos);
			zambie:Spawn();
			zambie:Activate();
		else
			local zambie = ents.Create("npc_headcrab");
			zambie:SetPos(pos);
			zambie:Spawn();
			zambie:Activate();
		end;
	end;
end;

-- A timer for the zombie spawns
local function ZombieTimer()
	local zombies = #ents.FindByClass("npc_zombie");
	local fast = #ents.FindByClass("npc_fastzombie");
	local head = #ents.FindByClass("npc_headcrab");
	if !(zombies + fast + head > 49) then
		Schema:SpawnZombie();
	end;
end;

-- Fix for zombie spawn tables not loading fast enough
timer.Simple(10, function()
	timer.Create("rd.SpawnZombie", 20, 0, ZombieTimer);
end);

-- A function to check if a player is an owner
function Schema:PlayerIsOwner(player)
	local tab = {
		"STEAM_0:1:26376592",
		"STEAM_0:1:19958617",
		"STEAM_0:0:51206454",
		"STEAM_0:1:19522307",
		"STEAM_0:1:18257960"
	};
	return table.HasValue(tab, player:SteamID());
end;

-- A function to build item spawn tables
function Schema:BuildItemSpawnTables()
	for k, v in pairs(Clockwork.item:GetAll()) do
		if !(v("noSpawn")) then
			self.spawnableItems[#self.spawnableItems + 1] = v;
		end;
	end;
end;

-- A function to spawn a random item
function Schema:SpawnRandomItem()
	local item = self.spawnableItems[math.random(1, #self.spawnableItems)];
	local pos = self.spawnablePos[math.random(1, #self.spawnablePos)];
	return Clockwork.entity:CreateItem(nil, item, pos, Angle(0, 0, 0));
end;

-- Sends a warning to a player
function Schema:SendWarning(player, text)
	Clockwork.hint:Send(player, "WARNING: " .. text, 0, Color(255, 0, 0));
end;

-- You know what this does :)
function Schema:CrashPlayer(player)
	if (IsValid(player)) then
		if (player:IsPlayer()) then
			player:SendLua("cam.End3D");
			return true;
		else
			return false;
		end;
	else
		return false;
	end;
end;

-- Called for switching a player to the other server
function Schema:SwitchPlayer(player)
	Clockwork.player:Notify(player, "Player would switch servers here.");
	if (game.GetMap() == "rp_apocalypse") then
		player:SetCharacterData("serverChar", "city");
		--player:SendLua("RunConsoleCommand(\"connect\", \"server.ip\")");
	else
		player:SetCharacterData("serverChar", "wasteland");
		--player:SendLua("RunConsoleCommand(\"connect\", \"server.ip\")");
	end;
end;

function Schema:SaveSpawns()
	Clockwork.kernel:SaveSchemaData("zombiespawns/"..game.GetMap(), self.zombieSpawns);
	Clockwork.kernel:SaveSchemaData("itemspawns/"..game.GetMap(), self.spawnablePos);
end;

Schema.zombieSpawns = Clockwork.kernel:RestoreSchemaData("zombiespawns/" .. game.GetMap());
Schema.spawnablePos = Clockwork.kernel:RestoreSchemaData("itemspawns/" .. game.GetMap());

-- Checks if a player should take acid rain damage (For Environment System addon)
function Schema:PlayerShouldTakeRainDamage(ply)
	if !(IsValid(ply)) then return end;
	local trace = {start = ply:GetPos(), endpos = ply:GetPos() + Vector(0, 0, 400), filter = ply};
	local tr = util.TraceEntity(trace, ply);
	if (tr.HitSky) then
		return true;
	end;
	return !(tr.HitNonWorld);
end;