--[[
-- Auto recognise for when people say their name (Has to be full name)
function Schema:PlayerFinishTypingDisplay(player, text)
	if (string.find(player:Nick(), text)) then
		for k, v in pairs(ents.FindInSphere(player:GetPos(), Clockwork.config:Get("talk_radius"):Get())) do
			if (v:IsPlayer()) then
				Clockwork.player:SetRecognises(v, player, RECOGNISE_TOTAL);
			end;
		end;
	end;
end; ]]--

-- Load things
function Schema:ClockworkInitPostEntity()
	self:BuildItemSpawnTables();
end;

-- Save things
function Schema:SaveData()
	self:SaveSpawns();
end;

-- When the server initializes
function Schema:Initialize()
	resource.AddWorkshop(144557422); -- The radio music
	resource.AddWorkshop(104495009); -- Insurgency Weapons
	resource.AddWorkshop(104700241); -- Insurgency Expansion
end;

-- Spawns loot from killing zombies
function Schema:OnNPCKilled(ent, att, wep)
	if !(IsValid(ent)) or !(IsValid(att)) then return end;
	
	local vel = Vector(math.random(1, 10), math.random(1, 10), math.random(1, 10));
	
	local rand = math.random(1, 20);
	if (rand == 20) then
		local item = Schema.spawnableItems[math.random(1, #Schema.spawnableItems)];
		local ent = Clockwork.entity:CreateItem(nil, item, ent:GetPos(), Angle(0, 0, 0));
		ent:SetVelocity(vel);
	else
		local cash = Clockwork.entity:CreateCash(nil, math.random(1, 10), ent:GetPos(), Angle(0, 0, 0));
		cash:SetVelocity(vel);
	end;
end;