--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_ENGLISH = Clockwork.lang:GetTable("English");

CW_ENGLISH["CrossServerChatEnabled"] = "Cross Server Chat Enabled";
CW_ENGLISH["CrossServerChatEnabledDesc"] = "Whether or not cross server chat is enabled.";
CW_ENGLISH["CrossServerChatName"] = "Cross Server Chat Name";
CW_ENGLISH["CrossServerChatNameDesc"] = "A unique server name for cross server chat.";