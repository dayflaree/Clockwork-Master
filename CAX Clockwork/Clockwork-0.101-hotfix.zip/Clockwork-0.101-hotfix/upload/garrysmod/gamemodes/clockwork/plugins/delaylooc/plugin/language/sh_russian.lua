﻿--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

--[[
	Contributor(s):
		ROSS <pootiswwe@gmail.com>
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Русский");

CW_RUSSIAN["WaitTalkInLOOC"] = "Вы не можете писать в LOOC еще #1 секунд(ы)!";
CW_RUSSIAN["LocalOOCInterval"] = "Интервал LOOCa";
CW_RUSSIAN["LocalOOCIntervalDesc"] = "Сколько секунд должно пройти, чтобы игрок снова мог писать в LOOC.\nУстановите 0 для отключения времени интервала.";