--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_ENGLISH = Clockwork.lang:GetTable("English");

CW_ENGLISH["SpawnWhereLeft"] = "Spawn Where Left";
CW_ENGLISH["SpawnWhereLeftDesc"] = "Whether or not players spawn where they disconnected.";