--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["RemoveMapPhysics"] = "Eliminar entidades físicas mapa";
CW_SPANISH["RemoveMapPhysicsDesc"] = "Eliminar o no eliminar las entidades con físicas al realizar un cargado de mapa.";