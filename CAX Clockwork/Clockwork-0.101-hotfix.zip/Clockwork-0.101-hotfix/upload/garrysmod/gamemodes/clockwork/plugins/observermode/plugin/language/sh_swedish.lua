--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["ObserverReset"] = "Observatör Reset";
CW_SWEDISH["ObserverResetDesc"] = "Om observatörer hamnar på deras föredetta position eller inte när de går ur observationen.";