--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["DisplayTypingWhisper"] = "Susurrando...";
CW_SPANISH["DisplayTypingPerform"] = "Realizando una acción...";
CW_SPANISH["DisplayTypingTalk"] = "Hablando...";
CW_SPANISH["DisplayTypingRadio"] = "Hablando por radio...";
CW_SPANISH["DisplayTypingYell"] = "Gritando...";
CW_SPANISH["DisplayTypingType"] = "Escribiendo...";