--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["DynamicAdvertRemoved"] = "Du har lyckats ta bort #1 dynamisk advertisering(ar).";
CW_SWEDISH["DynamicAdvertAdded"] = "Du har lyckats lägga till en dynamisk advertisering.";
CW_SWEDISH["DynamicAdvertNoneNearPosition"] = "Det finns inga dynamiska advertiseringar i närheten.";