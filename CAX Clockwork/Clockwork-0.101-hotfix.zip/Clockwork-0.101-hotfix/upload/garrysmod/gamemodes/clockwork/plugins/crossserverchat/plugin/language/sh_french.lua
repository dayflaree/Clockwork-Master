--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_FRENCH = Clockwork.lang:GetTable("French");

CW_FRENCH["CrossServerChatEnabled"] = "Cross Server Chat activé";
CW_FRENCH["CrossServerChatEnabledDesc"] = "Que le chat cross-server soit activé ou non.";
CW_FRENCH["CrossServerChatName"] = "Nom du Chat cross-server";
CW_FRENCH["CrossServerChatNameDesc"] = "Un nom de serveur unique pour le chat cross-server.";