--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_KOREAN = Clockwork.lang:GetTable("Korean");

CW_KOREAN["WaitTalkInLOOC"] = "당신은 #1 초 동안 LOOC 를 사용할 수 없습니다!";

CW_KOREAN["LocalOOCInterval"] = "LOOC 인터벌";
CW_KOREAN["LocalOOCIntervalDesc"] = "플레이어가 LOOC를 다시 사용하기 위해서 얼마나 기다려야 하는지에 대한 값입니다. (초)";