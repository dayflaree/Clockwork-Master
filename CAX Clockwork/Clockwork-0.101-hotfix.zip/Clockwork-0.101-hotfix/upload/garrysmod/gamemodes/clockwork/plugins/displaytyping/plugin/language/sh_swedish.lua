--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["DisplayTypingWhisper"] = "Viskar...";
CW_SWEDISH["DisplayTypingPerform"] = "Agerar...";
CW_SWEDISH["DisplayTypingTalk"] = "Talar...";
CW_SWEDISH["DisplayTypingRadio"] = "Anropar...";
CW_SWEDISH["DisplayTypingYell"] = "Ropar...";
CW_SWEDISH["DisplayTypingType"] = "Skriver...";