--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SPANISH = Clockwork.lang:GetTable("Spanish");

CW_SPANISH["WaitTalkInLOOC"] = "No puedes utilizar el chat LOOC hasta dentro de #1 segundo(s)!";

CW_SPANISH["LocalOOCInterval"] = "Intervalo chat LOOC";
CW_SPANISH["LocalOOCIntervalDesc"] = "El tiempo que un jugador debe esperar para utilizar el canal de chat LOOC (en segundos).\nUtiliza 0 para prohibir el uso del chat.";
