﻿--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]
--[[
   CONTRIBUTOR(s)
   ROSS  pootiswwe@gmail.com 
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Русский");

CW_RUSSIAN["ObserverReset"] = "Перезагрузка режима наблюдения";
CW_RUSSIAN["ObserverResetDesc"] = "Будет ли режим наблюдения возвращать вас обратно на стартовую позицию при выходе из него.";