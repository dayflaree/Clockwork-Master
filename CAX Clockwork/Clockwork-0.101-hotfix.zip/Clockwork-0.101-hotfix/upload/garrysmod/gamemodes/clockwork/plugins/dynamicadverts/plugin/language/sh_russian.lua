﻿--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

--[[
	Contributor(s):
		ROSS <pootiswwe@gmail.com>
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Русский");

CW_RUSSIAN["DynamicAdvertRemoved"] = "Вы успешно удалили #1 динамических новостей.";
CW_RUSSIAN["DynamicAdvertAdded"] = "Вы успешно добавили динамическую новость.";
CW_RUSSIAN["DynamicAdvertNoneNearPosition"] = "Здесь нету динамических новостей.";