--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_SWEDISH = Clockwork.lang:GetTable("Swedish");

CW_SWEDISH["TakePhyscannon"] = "Ta Physcannon";
CW_SWEDISH["TakePhyscannonDesc"] = "Om man ska ta physgunnen från spelare.";