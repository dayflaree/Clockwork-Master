--[[
	© CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_ENGLISH = Clockwork.lang:GetTable("English");

CW_ENGLISH["DisplayTypingWhisper"] = "Whispering...";
CW_ENGLISH["DisplayTypingPerform"] = "Performing...";
CW_ENGLISH["DisplayTypingTalk"] = "Talking...";
CW_ENGLISH["DisplayTypingRadio"] = "Radioing...";
CW_ENGLISH["DisplayTypingYell"] = "Yelling...";
CW_ENGLISH["DisplayTypingType"] = "Typing...";