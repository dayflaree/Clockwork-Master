--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

Clockwork.kernel:AddFile("materials/gmod/scope-refract.vtf");
Clockwork.kernel:AddFile("materials/gmod/scope-refract.vmt");
Clockwork.kernel:AddFile("materials/gmod/scope.vtf");
Clockwork.kernel:AddFile("materials/gmod/scope.vmt");