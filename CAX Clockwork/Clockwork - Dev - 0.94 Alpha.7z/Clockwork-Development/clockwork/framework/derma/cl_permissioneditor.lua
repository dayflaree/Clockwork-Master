--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;
local pairs = pairs;
local vgui = vgui;
local math = math;

local PANEL = {};
local permissionTable = {};

-- Called when the panel is initialized.
function PANEL:Init()
	self:SetSize(Clockwork.menu:GetWidth() - 20, Clockwork.menu:GetHeight());
	
	self.panelList = vgui.Create("cwPanelList", self);
 	self.panelList:SetPadding(4);
 	self.panelList:StretchToParent(4, 4, 4, 4);
	
	Clockwork.permission.panel = self;
	
	for k, v in pairs(Clockwork.command.stored) do
		Clockwork.permission:AddCheckBox(string.lower(v.name));
	end;
	
	self:Rebuild();
end;

-- A function to rebuild the panel.
function PANEL:Rebuild()
	self.panelList:Clear();

	self.navigationForm = vgui.Create("DForm", self);
		self.navigationForm:SetPadding(4);
		self.navigationForm:SetName("Permission Editor");
		self.navigationForm:SetTall(100);
	self.panelList:AddItem(self.navigationForm);
	
	local backButton = vgui.Create("DButton", self);
		backButton:SetText("Close");
		backButton:SetWide(self:GetParent():GetWide());
			
		-- Called when the button is clicked.
		function backButton.DoClick(button)
			self:SetVisible(false)
		end;
	self.navigationForm:AddItem(backButton);
	
	local label = vgui.Create("cwInfoText", self);
		label:SetText("Permission Editor allows you to edit player's or usergroup's permissions.");
		label:SetInfoColor("blue");
	self.panelList:AddItem(label);
		
	local totalY = 0;
	local catTable = {};
--	local permissionTable = Clockwork.permission.stored[self.groupName].permissions;
	
	for k, v in pairs(Clockwork.permission.checkBox) do
		if (!catTable[v.category]) then
			catTable[v.category] = {};
			
			self.permissionCategoryForm = vgui.Create("DForm", self);
				self.permissionCategoryForm:SetPadding(4);
				self.permissionCategoryForm:SetName(v.category);
				self.permissionCategoryForm:SetTall(100);
			self.panelList:AddItem(self.permissionCategoryForm);
			
			for k2, v2 in pairs(Clockwork.permission.checkBox) do
				if (v2.category == v.category) then
					local clr = "green";

					if (Clockwork.permission:HasPermission("admin", v2.text)) then
						clr = "green";
					else
						clr = "orange";
					end;
					
					local permissionCheckBox = vgui.Create("cwInfoText", self.permissionCategoryForm);
						permissionCheckBox:SetText(v2.text);
						permissionCheckBox:SetTextToLeft(false);
						permissionCheckBox:SetInfoColor(clr);
						permissionCheckBox:SetButton(true);
						
						function permissionCheckBox:DoClick()
							local infoColor = "orange";
							local bVal = false;
							if (permissionTable[v2.text]) then
								bVal = false;
								infoColor = "orange";
							else
								bVal = true;
								infoColor = "green";
							end;
							print(permissionTable.uniqueID)
							Clockwork.datastream:Start("PermissionDoClick", {v2.text, bVal, permissionTable.uniqueID})
							permissionTable[v2.text] = bVal;
							permissionCheckBox:SetInfoColor(infoColor);
						end;
						
					self.panelList:AddItem(permissionCheckBox);
				end;
			end;
		end;
	end;
		
	self.panelList:InvalidateLayout(true);
end;

-- A function to get whether the button is visible.
function PANEL:IsButtonVisible()
	for k, v in pairs(Clockwork.system:GetAll()) do
		if (v:HasAccess()) then
			return true;
		end;
	end;
end;

function PANEL:SetPermissionTable(groupName)
	local groupTable = Clockwork.permission.stored[groupName];

	if (groupTable) then
		permissionTable = groupTable.permissions;
		self:Rebuild();
	end;
end;

function PANEL:GetPermissionTable()
	return permissionTable;
end;

-- Called when the panel is selected.
function PANEL:OnSelected() self:Rebuild(); end;

-- Called when the layout should be performed.
function PANEL:PerformLayout(w, h)
	--self.panelList:StretchToParent(4, 4, 4, 4);
	--self:SetSize(w, math.min(self.panelList.pnlCanvas:GetTall() + 32, ScrH() * 0.75));
end;

-- Called when the panel is painted.
function PANEL:Paint(w, h)
	--DERMA_SLICED_BG:Draw(0, 0, w, h, 8, COLOR_WHITE);
	return true;
end;

vgui.Register("cwPermissionEditor", PANEL, "EditablePanel");