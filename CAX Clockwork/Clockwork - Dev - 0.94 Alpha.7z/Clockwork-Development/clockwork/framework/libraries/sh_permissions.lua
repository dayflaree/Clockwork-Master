--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

Clockwork.permission = Clockwork.kernel:NewLibrary("Permissions");
Clockwork.permission.stored = Clockwork.permission.stored or {};
Clockwork.permission.checkBox = Clockwork.permission.checkBox or {};

--[[ Set the __index meta function of the class. --]]
local CLASS_TABLE = {__index = CLASS_TABLE};

CLASS_TABLE.name = "Base Group";
CLASS_TABLE.description = "A usergroup with no description.";
CLASS_TABLE.icon = "icons/user";

-- A function to register a new usergroup.
function CLASS_TABLE:Register()
	return Clockwork.permission:Register(self);
end;

-- A function to get all items.
function Clockwork.permission:GetAll()
	return self.stored;
end;

-- A function to create a new suergroup object.
function Clockwork.permission:NewUsergroup(id, parentGroup, bIsBase)
	local object = Clockwork.kernel:NewMetaTable(CLASS_TABLE);
		object.isBase = bIsBase or false;
		object.base = parentGroup or "user";
		object.uniqueID = id or "unknown";
		object.permissions = {};
	return object;
end;

-- A function to register a new item.
function Clockwork.permission:Register(groupTable)
	if (type(groupTable) != "table") then return; end;
	
	groupTable.uniqueID = string.lower(string.gsub(groupTable.uniqueID or string.gsub(groupTable.name, "%s", "_"), "['%.]", ""));
	
	self.stored[groupTable.uniqueID] = groupTable;
	self.stored[groupTable.uniqueID].name = groupTable.name or "Base Group";
	self.stored[groupTable.uniqueID].description = groupTable.description or "No description";
	self.stored[groupTable.uniqueID].permissions = groupTable.permissions;
	self.stored[groupTable.uniqueID].uniqueID = groupTable.uniqueID or "unknown"
	self.stored[groupTable.uniqueID].base = groupTable.base or "user";
	self.stored[groupTable.uniqueID].icon = groupTable.icon or "icon16/user.png";
	self.stored[groupTable.uniqueID].immunity = groupTable.immunity or 100;
	
	if (!Clockwork.kernel:SchemaDataExists("permissions/"..groupTable.uniqueID)) then
		Clockwork.kernel:SaveSchemaData("permissions/"..groupTable.uniqueID, groupTable);
	else
		Clockwork.permission:Restore(groupTable.uniqueID);
	end;
end;

function Clockwork.permission:Save(groupID, groupTable)
	if (groupTable and groupID) then
		self.stored[groupID] = groupTable
		Clockwork.kernel:SaveSchemaData("permissions/"..groupID, groupTable);
	end;
end;

function Clockwork.permission:Exists(groupID)
	if (self.stored[groupID]) then
		return true;
	end;
end;

function Clockwork.permission:MakePermissions(flag, categoriesTable)
	local permissionTable = {};
	local flag = flag or "b";
	local cT = categoriesTable;
	
	for k, v in pairs(Clockwork.command.stored) do
		local realName = string.gsub(v.name, "%s", "");
		local uniqueID = string.lower(realName);
		
		if (v.access == flag or v.access == "b"or v.category == "basic") then
			permissionTable[uniqueID] = true;
		end;
		
		if (cT) then
			for k2, v2 in pairs(cT) do
				if (v.category == v2) then
					permissionTable[uniqueID] = true;
				end;
			end;
		end;
	end;
	
	return permissionTable;
end;

function Clockwork.permission:GetPermissions(groupID)
	if (self:Exists(groupID)) then
		return self:FindByID(groupID).permissions;
	end;
end;

function Clockwork.permission:Derive(groupID, parentID)
	if (self:Exists(groupID) and self:Exists(parentID)) then
		local finalPermissions = table.Merge(self:GetPermissions(groupID), self:GetPermissions(parentID));
		
		self.stored[groupID].permissions = finalPermissions;
		Clockwork.permission:Save(groupID, self.stored[groupID]);
	end;
end;

function Clockwork.permission:Restore(groupID)
	local gID = groupID or "unknown";
	if (Clockwork.kernel:SchemaDataExists("permissions/"..gID)) then
		local groupTable = Clockwork.kernel:RestoreSchemaData("permissions/"..gID, false);
		
		if (groupTable) then
			self.stored[gID] = groupTable;
		end;
	else
		ErrorNoHalt("[CW:Permissions] Trying to restore non-existant user group data! ("..gID..")\n");
	end;
end;

function Clockwork.permission:FindByID(groupID)
	return self.stored[groupID] or false;
end;

function Clockwork.permission:SetPermission(groupID, permission, state)
	if (type(permission) != "string") then return; end;
	
	if (permission and self:Exists(groupID)) then
		self.stored[groupID].permissions[permission] = state;

		if (SERVER) then
			Clockwork.permission:Save(groupID, self.stored[groupID])
		end;
	end;
end;

function Clockwork.permission:Get(player)
	if (IsValid(player)) then
		if (!player:GetPData("cwPermissions")) then return {}; end;
		
		return Clockwork.kernel:Deserialize(player:GetPData("cwPermissions"));
	end;
end;

function Clockwork.permission:Set(player, permission, state)
	if (type(permission) != "string") then return; end;
	
	if (permission and IsValid(player)) then
		local playerPermissions = self:Get(player);
		playerPermissions[permission] = state;
		
		player:SetPData("cwPermissions", Clockwork.kernel:Serialize(permission));
	end;
end;

function Clockwork.permission:Give(player, permission)
	if (type(permission) != "string") then return; end;
	
	if (permission and IsValid(player)) then
		self:Set(player, permission, true);
	end;
end;

function Clockwork.permission:Take(player, permission)
	if (type(permission) != "string") then return; end;
	
	if (permission and IsValid(player)) then
		self:Set(player, permission, false);
	end;
end;

function Clockwork.permission:Clear(player)
	if (IsValid(player)) then
		player:SetPData("cwPermissions", {});
	end;
end;

function Clockwork.permission:HasPermission(groupID, command)
	local groupTable = self:FindByID(groupID);
	
	if (command and groupTable) then
		if (groupTable.permissions[command]) then
			return true;
		else
			return false;
		end;
	else
		return false;
	end;
end;

function Clockwork.permission:HasAccess(player, command)
	if (command and IsValid(player)) then
		if (player:GetUserGroup() == "owner") then
			return true;
		end;
		
		if (self:HasPermission(player:GetUserGroup(), command)) then
			return true;
		end;
		
		local permissionTable = Clockwork.permission:Get(player);
		if (permissionTable[command] == true) then
			return true;
		end;
	end;
end;

local playerMeta = FindMetaTable("Player");

function playerMeta:HasPermission(command)
	return Clockwork.permission:HasAccess(self, command);
end;

function playerMeta:GetImmunity()
	local groupID = self:GetClockworkUserGroup();
	
	return Clockwork.permission.stored[groupID].immunity;
end;

function playerMeta:IsHigherImmunity(target)
	if (IsValid(target)) then
		return self:GetImmunity() >= target:GetImmunity();
	end;
end;

if (CLIENT) then
	Clockwork.datastream:Hook("PermissionSync", function(data)
		if (data) then
			Clockwork.permission.stored = data;
		end;
	end);
	
	-- A function to add a check box.
	function Clockwork.permission:AddCheckBox(command)
		self.checkBox[command] = {
			category = Clockwork.command.stored[command].category,
			class = "checkBox",
			text = command
		};
	end;
	
	for k, v in pairs(Clockwork.command.stored) do
		Clockwork.permission:AddCheckBox(string.lower(v.name));
	end;
else
	-- A function to reset permission saved data.
	function Clockwork.permission:Reset()
		for k, v in pairs(Clockwork.permission.stored) do
			Clockwork.kernel:DeleteSchemaData("permissions/"..k.uniqueID);
		end;
	end;
	
	Clockwork.datastream:Start("PermissionSync", Clockwork.permission.stored);
	
	Clockwork.datastream:Hook("PermissionDoClick", function(data)
		local permission = data[1];
		local state = data[2];
		local groupID = data[3];

		Clockwork.permission:SetPermission(groupID, permission, state);
	end);
end;

concommand.Add("permprint", function(player, command, arguments)
	PrintTable(Clockwork.permission.stored[arguments[1]]);
end);