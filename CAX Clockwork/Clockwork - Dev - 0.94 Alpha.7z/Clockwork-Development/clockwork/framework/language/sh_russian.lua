--[[
	© 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

CW_RUSSIAN = Clockwork.lang:GetTable("Russian");

CW_RUSSIAN["CannotChangeClassFor"] = "Вы не можете менять класс еще #1 секунд(у)!";
CW_RUSSIAN["CannotActionRightNow"] = "В данный момент вы не можете выполнить это действие!";
CW_RUSSIAN["DroppedItemsOtherChar"] = "Вы не можете подбирать предметы, принадлежащие одному из ваших персонажей!";
CW_RUSSIAN["DroppedCashOtherChar"] = "Вы не можете поднять '#1', принадлежащий одному из ваших персонажей!";
CW_RUSSIAN["CannotPurchaseAnotherDoor"] = "Вы не можете приобрести еще одну дверь!";
CW_RUSSIAN["YouNeedAnother"] = "Вам необходимо еще #1!";
CW_RUSSIAN["CannotHolsterWeapon"] = "Вы не можете убрать данное оружие!";
CW_RUSSIAN["CannotDropWeapon"] = "Вы не можете выбросить данное оружие!";
CW_RUSSIAN["CannotUseWeapon"] = "Вы не можете использовать данное оружие!";