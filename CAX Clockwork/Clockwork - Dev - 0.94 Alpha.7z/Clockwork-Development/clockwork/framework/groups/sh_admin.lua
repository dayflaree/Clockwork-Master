--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

-- This is the basic 'admin' group class.
-- Do not edit it to prevent issues.

local GROUP = Clockwork.permission:NewUsergroup("admin", "operator");
GROUP.name = "Admin";
GROUP.uniqueID = "admin";
GROUP.description = "An admin that helps with minor setup, and managing operators.";
GROUP.permissions = Clockwork.permission:MakePermissions("a", {});
GROUP.icon = "icon16/user.png";
GROUP.immunity = 100;

GROUP:Register();