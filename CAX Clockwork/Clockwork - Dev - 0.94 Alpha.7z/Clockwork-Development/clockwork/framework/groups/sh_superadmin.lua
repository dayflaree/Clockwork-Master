--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

-- This is the basic 'superadmin' group class.
-- Do not edit it to prevent issues.

local GROUP = Clockwork.permission:NewUsergroup("superadmin", "admin");
GROUP.name = "Super Admin";
GROUP.uniqueID = "superadmin";
GROUP.description = "An admin that handles most of the server, while managing admins and operators.";
GROUP.permissions = Clockwork.permission:MakePermissions("s", {});
GROUP.icon = "icon16/shield.png";
GROUP.immunity = 500;

GROUP:Register();