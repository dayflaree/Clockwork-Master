--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

-- This is the basic 'owner' group class.
-- Do not edit it to prevent issues.

local GROUP = Clockwork.permission:NewUsergroup("owner", "superadmin");
GROUP.name = "Owner";
GROUP.uniqueID = "owner";
GROUP.description = "An owner of the server that has control over most, if not all of the server's systems.";
GROUP.permissions = Clockwork.permission:MakePermissions("s", {});
GROUP.icon = "icon16/key.png";
GROUP.immunity = 1000;

GROUP:Register();