--[[
	� 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlyTakeFlags");
COMMAND.tip = "Take flags from a player.";
COMMAND.text = "<string Name> <string Flag(s)>";
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.category = "players";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1])
	
	if (target) then
		if (player:IsHigherImmunity(target)) then
			Clockwork.player:TakePlayerFlags(target, arguments[2]);
		
			Clockwork.player:NotifyAll(player:Name().." took '"..arguments[2].."' flags from "..target:SteamName()..".");
		else
			Clockwork.player:Notify(player, target:SteamName().." is higher immunity than you!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();