--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlySetGroup");
COMMAND.tip = "Set a player's user group.";
COMMAND.text = "<string Name> <string UserGroup>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.category = "management";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local userGroup = string.lower(arguments[2]);
	
	if (!Clockwork.permission:Exists(userGroup)) then
		Clockwork.player:Notify(player, "'"..arguments[2].."' is not a valid user group!");
		return false;
	end;
	
	if (target) then
		if (player:IsHigherImmunity(target)) then
			Clockwork.player:NotifyAll(player:Name().." has set "..target:Name().."'s user group to "..userGroup..".");
				target:SetClockworkUserGroup(userGroup);
			Clockwork.player:LightSpawn(target, true, true);
		else
			Clockwork.player:Notify(player, target:Name().." is higher immunity than you!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();