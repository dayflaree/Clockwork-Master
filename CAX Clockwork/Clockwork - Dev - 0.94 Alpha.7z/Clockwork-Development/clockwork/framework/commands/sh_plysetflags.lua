--[[
	� 2014 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlySetFlags");
COMMAND.tip = "Set a player's flags.";
COMMAND.text = "<string Name> <string Flag(s)>";
COMMAND.access = "s";
COMMAND.arguments = 2;
COMMAND.category = "players";

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	
	if (target) then
		if (player:IsHigherImmunity(target)) then
			Clockwork.player:SetPlayerFlags(target, arguments[2]);		
			Clockwork.player:NotifyAll(player:Name().." set "..target:SteamName().."'s flags to "..arguments[2]..".");
		else
			Clockwork.player:Notify(player, target:Name().." is higher immunity than you!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid character!");
	end;
end;

COMMAND:Register();