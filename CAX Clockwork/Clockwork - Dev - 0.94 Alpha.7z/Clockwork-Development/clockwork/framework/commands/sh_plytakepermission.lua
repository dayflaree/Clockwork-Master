--[[
	� 2015 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).

	Clockwork was created by Conna Wiles (also known as kurozael.)
	http://cloudsixteen.com/license/clockwork.html
--]]

local Clockwork = Clockwork;

local COMMAND = Clockwork.command:New("PlyTakePermission");
COMMAND.tip = "Take permission from player.";
COMMAND.text = "<string Name> <string permission>";
COMMAND.flags = CMD_DEFAULT;
COMMAND.category = "management";
COMMAND.arguments = 2;

-- Called when the command has been run.
function COMMAND:OnRun(player, arguments)
	local target = Clockwork.player:FindByID(arguments[1]);
	local permission = string.lower(arguments[2]);
	
	if (target) then
		if (player:IsHigherImmunity(target)) then
			Clockwork.player:NotifyAll(player:Name().." took permission to use '"..permission.."' command from "..target:Name()..".");
			Clockwork.permission:Take(target, permission)
		else
			Clockwork.player:Notify(player, target:Name().." is higher immunity than you!");
		end;
	else
		Clockwork.player:Notify(player, arguments[1].." is not a valid player!");
	end;
end;

COMMAND:Register();