# Clockwork-Development
TeslaCloud Studio's Clockwork Derivative. Pre-Submit versions of CW go here.
Changes so far:

0.94:
- Permissions can now be command-based, instead of flag-based.
- Players and usergroups can have permission to use certain commands.
- New usergroups can be created.
- Existing usergroups can be modified from in-game menu.
- Usergroup immunity system.
- Multiple owners support via clockwork.cfg.
- Item descriptions now show up when player is looking at them.
- Moved local definitions outside of tick hook.
- Fixed menu music.
